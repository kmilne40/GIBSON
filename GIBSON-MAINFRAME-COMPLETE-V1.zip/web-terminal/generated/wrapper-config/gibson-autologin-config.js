window.GIBSON_GUAC_CONFIG = {
  username: "gibson",
  password: "SBGbAOvnhY78284P3ahL6peU",
  connectionName: "Gibson VTAM Console",
  guacamoleBase: "/guacamole/"
};
