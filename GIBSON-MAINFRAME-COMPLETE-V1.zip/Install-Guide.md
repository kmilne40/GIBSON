# Installing GIBSON & PHOSPHOR

*A practical setup guide for the mainframe security training lab. GIBSON is the
z/OS training simulator (the target); PHOSPHOR is the native TN3270 audit client
and CRT terminal. Everything here is for authorised, defensive training on
simulated systems with fake data.*

---

## Part 1 — GIBSON (the lab target)

GIBSON runs well on a Raspberry Pi (Kali) or any Linux/macOS box with Python 3.9+.

**1. Unpack the release**

```bash
mkdir ~/gibson && cd ~/gibson
unzip GIBSON-MAINFRAME-COMPLETE-V21-REVSHELL-LANDING.zip
cd gibson-mainframe
```

**2. Requirements**

GIBSON is pure Python and standard-library-first. If a `requirements.txt` is
present, install it; otherwise no third-party packages are needed for the core
services:

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt        # only if the file is present
```

**3. Run it**

```bash
python3 -m gibson
```

This starts the mainframe services on their standard ports: **TN3270 on 23**,
**FTP on 21**, **DB2/DRDA on 50000** (plus USS/OMVS and others). On a Pi you may
need `sudo` to bind port 23, or set a higher port in the config.

**4. Verify**

From another machine (or the same one), point a 3270 emulator — x3270, c3270,
or PHOSPHOR — at the Pi's address and log on with a lab credential such as
`IBMUSER / SYS1` or `BOB / BOB`. You should reach the BANKSYS1 VTAM welcome
screen, from which `LOGON APPLID(TSO)`, `LOGON APPLID(CICS)` and
`LOGON APPLID(DB2)` all work.

**5. Lab toggles (optional)**

Environment variables switch scenarios on and off:

```bash
GIBSON_CICS_LOCKED=1        python3 -m gibson   # RACF-protect CECI (forces --bypass)
GIBSON_REVSHELL_LANDING=0   python3 -m gibson   # disable the reverse-shell connect-back
```

---

## Part 2 — PHOSPHOR (the audit client)

PHOSPHOR runs anywhere with Python 3.9+. The core tool needs no third-party
packages; the CRT terminal and reporting features have optional extras.

**1. Unpack and install**

```bash
cd ~
unzip PHOSPHOR-FINAL.zip && cd phosphor_work
pip install -e .                 # core tool (scanner / auditor / menu / report)
pip install -e ".[crt]"          # also install the CRT terminal (moderngl, pyglet, pillow, numpy)
```

**2. First run**

```bash
python -m phosphor <gibson-host>            # or the installed 'phosphor' command
python -m phosphor <gibson-host> --menu     # interactive recon menu + notepad
python -m phosphor <gibson-host> --scan --report assessment.html
```

**3. The CRT terminal (optional)**

```bash
python -m phosphor.crt <gibson-host> --profile boardroom   # gentle effects
python -m phosphor.crt --preview ./previews                # still previews, no GPU needed
```

For the authentic look, drop Ricardo Bánffy's open **3270** font into
`phosphor/crt/fonts/3270.ttf` (see the README there); PHOSPHOR falls back to any
installed monospace if it's absent.

**4. Driving CICSpwn through PHOSPHOR (no x3270)**

Place the Python-3 `cicspwn.py` alongside PHOSPHOR and run:

```bash
python -m phosphor.run_cicspwn ./cicspwn.py <gibson-host> 23
```

PHOSPHOR presents CICSpwn a compatible emulator, so the real tool runs with no
x3270 dependency.

---

## Part 3 — A compiled binary (optional)

To hand testers a single executable with no Python install, compile PHOSPHOR with
Nuitka (see `BUILD-BINARY.md` for the full guide):

```bash
pip install nuitka
python build.py core        # -> dist/phosphor  (lean scanner/auditor)
python build.py crt         # -> dist/phosphor-crt (the terminal; needs OpenGL)
```

Build **on** the target architecture (e.g. on the Kali Pi for an ARM64 binary) —
Nuitka is not a cross-compiler.

---

## Quick reference — default ports & credentials

| Service | Port | Notes |
|---|---|---|
| TN3270 | 23 | VTAM welcome → TSO / CICS / DB2 |
| FTP | 21 | dataset transfer + JES submit |
| DB2 / DRDA | 50000 | EXCSAT fingerprint |
| Lab logins | — | `IBMUSER / SYS1`, `BOB / BOB` (fake) |

*Authorised testing only. GIBSON contains no real data.*
