#!/usr/bin/env bash
# PHOSPHOR - Linux uninstall.
set -euo pipefail
PREFIX="${1:-$HOME/.local}"
rm -rf "$PREFIX/lib/phosphor"
rm -f  "$PREFIX/bin/phosphor-gui"
rm -f  "$PREFIX/share/applications/phosphor.desktop"
rm -f  "$PREFIX/share/icons/hicolor/256x256/apps/phosphor.png"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$PREFIX/share/applications" || true
echo ">> PHOSPHOR removed from $PREFIX"
