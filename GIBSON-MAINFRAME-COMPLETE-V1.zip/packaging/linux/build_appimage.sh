#!/usr/bin/env bash
# PHOSPHOR - build a portable Linux AppImage (one file, no install needed).
# Requires: appimagetool (https://github.com/AppImage/AppImageKit/releases).
set -euo pipefail
cd "$(dirname "$0")/../.."

[ -d dist/PHOSPHOR ] || { echo "build first -> pyinstaller packaging/phosphor.spec"; exit 1; }

APPDIR=dist/PHOSPHOR.AppDir
rm -rf "$APPDIR"; mkdir -p "$APPDIR/usr/bin" "$APPDIR/usr/share/applications" \
    "$APPDIR/usr/share/icons/hicolor/256x256/apps"
cp -r dist/PHOSPHOR/. "$APPDIR/usr/bin/"
cp packaging/icons/phosphor-256.png "$APPDIR/phosphor.png"
cp packaging/icons/phosphor-256.png "$APPDIR/usr/share/icons/hicolor/256x256/apps/phosphor.png"
cp packaging/linux/phosphor.desktop "$APPDIR/phosphor.desktop"
cp packaging/linux/phosphor.desktop "$APPDIR/usr/share/applications/phosphor.desktop"
cat > "$APPDIR/AppRun" <<'RUN'
#!/bin/bash
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/PHOSPHOR" "$@"
RUN
chmod +x "$APPDIR/AppRun"

if command -v appimagetool >/dev/null 2>&1; then
    ARCH=x86_64 appimagetool "$APPDIR" dist/PHOSPHOR-1.0.0-x86_64.AppImage
    echo ">> built dist/PHOSPHOR-1.0.0-x86_64.AppImage (chmod +x, then double-click)"
else
    echo ">> AppDir ready at $APPDIR. Install appimagetool to produce the .AppImage,"
    echo "   or just run $APPDIR/AppRun."
fi
