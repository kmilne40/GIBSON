#!/usr/bin/env bash
# PHOSPHOR - Linux install: copies the built app to ~/.local and registers the
# menu icon.  Run AFTER building:  pyinstaller packaging/phosphor.spec
set -euo pipefail
cd "$(dirname "$0")/../.."

APPDIR="dist/PHOSPHOR"
[ -d "$APPDIR" ] || { echo "ERROR: build first -> pyinstaller packaging/phosphor.spec"; exit 1; }

PREFIX="${1:-$HOME/.local}"
DEST="$PREFIX/lib/phosphor"
BIN="$PREFIX/bin"
APPS="$PREFIX/share/applications"
ICONS="$PREFIX/share/icons/hicolor/256x256/apps"

echo ">> installing to $DEST"
rm -rf "$DEST"; mkdir -p "$DEST" "$BIN" "$APPS" "$ICONS"
cp -r "$APPDIR/." "$DEST/"

# launcher on PATH
ln -sf "$DEST/PHOSPHOR" "$BIN/phosphor-gui"

# icon + menu entry
cp packaging/icons/phosphor-256.png "$ICONS/phosphor.png"
sed "s|Exec=phosphor-gui|Exec=$BIN/phosphor-gui|" packaging/linux/phosphor.desktop > "$APPS/phosphor.desktop"
chmod +x "$APPS/phosphor.desktop" || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache "$PREFIX/share/icons/hicolor" 2>/dev/null || true

echo ">> installed. Launch from your app menu (PHOSPHOR) or run: phosphor-gui"
echo "   (ensure $BIN is on your PATH). Uninstall: packaging/linux/uninstall.sh"
echo ""
echo ">> EZrecon external tools (nmap, whois, subfinder, amass) are optional."
echo "   Install them now with:  bash packaging/install_ezrecon_deps.sh"
if [ "${1:-}" = "--with-recon" ]; then
    bash "$(dirname "$0")/../install_ezrecon_deps.sh" || true
fi
