# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for PHOSPHOR (run on each target OS - not a cross-compiler).

    pyinstaller packaging/phosphor.spec

Produces dist/PHOSPHOR/ (onedir) and, on macOS, dist/PHOSPHOR.app.  The platform
installer scripts (packaging/windows|macos|linux) wrap that into a native package.
"""
import os
import sys
from PyInstaller.utils.hooks import collect_submodules

# SPECPATH is the directory containing this spec (…/packaging); ROOT is the project root.
ROOT = os.path.dirname(SPECPATH)


def R(*p):
    return os.path.join(ROOT, *p)


# runtime data files: the 3270 bezel, bundled fonts, CRT assets, skills
datas = [
    (R("phosphor", "app", "assets"), os.path.join("phosphor", "app", "assets")),
    (R("phosphor", "fonts"), os.path.join("phosphor", "fonts")),
]
for rel in (
    os.path.join("phosphor", "crt", "fonts"),
    os.path.join("phosphor", "crt", "demo_screen.json"),
    os.path.join("phosphor", "skills"),
):
    src = R(rel)
    if os.path.exists(src):
        dest = rel if os.path.isdir(src) else os.path.dirname(rel)
        datas.append((src, dest))

hiddenimports = (
    collect_submodules("phosphor")
    + collect_submodules("cryptography")
    + ["numpy", "PIL", "PIL._imaging", "pygame"]
    # EZrecon python backends (bundled; CLI tools stay external - see install_ezrecon_deps.sh)
    + collect_submodules("dns")            # dnspython
    + ["requests", "bs4", "shodan"]
)

ICON_WIN = R("packaging", "icons", "phosphor.ico")
ICON_MAC = R("packaging", "icons", "phosphor.icns")
icon = ICON_MAC if sys.platform == "darwin" else (ICON_WIN if sys.platform.startswith("win") else None)

a = Analysis(
    [R("packaging", "phosphor_gui.py")],
    pathex=[ROOT],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "test", "unittest", "pytest"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="PHOSPHOR",
    debug=False,
    strip=False,
    upx=False,
    console=False,            # windowed app (no console)
    icon=icon,
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="PHOSPHOR")

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="PHOSPHOR.app",
        icon=ICON_MAC if os.path.exists(ICON_MAC) else None,
        bundle_identifier="org.offensivesec.phosphor",
        info_plist={
            "CFBundleName": "PHOSPHOR",
            "CFBundleDisplayName": "PHOSPHOR",
            "CFBundleShortVersionString": "1.0.0",
            "NSHighResolutionCapable": True,
        },
    )
