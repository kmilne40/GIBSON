#!/usr/bin/env python3
"""Launcher for the packaged PHOSPHOR desktop app (double-click / installed icon).

PyInstaller bundles this as the app entry point; it just starts the pygame GUI.
"""
import sys


def main():
    from phosphor.app.__main__ import main as app_main
    return app_main(sys.argv[1:])      # so `PHOSPHOR host:port [--5250]` auto-connects


if __name__ == "__main__":
    sys.exit(main())
