; PHOSPHOR - Windows installer (Inno Setup 6).
; Build the app first:  pyinstaller packaging\phosphor.spec
; Then compile this in Inno Setup (iscc packaging\windows\phosphor.iss) to get
; PHOSPHOR-Setup.exe - a proper installer with Start Menu + desktop icons and an
; entry in Add/Remove Programs (clean uninstall).

#define AppName "PHOSPHOR"
#define AppVersion "1.0.0"
#define AppPublisher "OffensiveSec"
#define AppURL "https://offensivesec.org"
#define AppExe "PHOSPHOR.exe"

[Setup]
AppId={{8F1B4E20-3270-4A50-9C17-5250PHOSPHOR}}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
UninstallDisplayIcon={app}\{#AppExe}
UninstallDisplayName={#AppName} {#AppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputBaseFilename=PHOSPHOR-Setup
SetupIconFile=..\icons\phosphor.ico
DisableProgramGroupPage=yes
LicenseFile=..\..\LICENSE.txt

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
; the whole PyInstaller onedir output
Source: "..\..\dist\PHOSPHOR\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent
