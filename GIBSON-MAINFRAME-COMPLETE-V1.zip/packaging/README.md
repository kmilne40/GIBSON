# Packaging PHOSPHOR into installers (Windows / macOS / Linux)

PHOSPHOR ships as a native desktop app. We use **PyInstaller** to bundle the app +
Python + all dependencies into a self-contained folder, then wrap that in the
installer each platform expects. PyInstaller is **not a cross-compiler** — you must
build on each OS you want to ship for (Windows→.exe, macOS→.app, Linux→ELF).

Everything below assumes you start in the project root.

## One command (any OS)
```
python packaging/build.py
```
This installs PyInstaller, builds `dist/PHOSPHOR/`, and prints the next (installer)
step for your OS. Or do it by hand:

---

## Windows → `PHOSPHOR-Setup.exe`
1. Install Python 3.11+, then build the app:
   ```
   pip install pyinstaller pygame numpy pillow cryptography
   pyinstaller packaging\phosphor.spec
   ```
2. Install **Inno Setup 6** (https://jrsoftware.org/isdl.php) and compile the script:
   ```
   "C:\Program Files (x86)\Inno Setup 6\iscc.exe" packaging\windows\phosphor.iss
   ```
3. Ship `Output\PHOSPHOR-Setup.exe`. It installs to *Program Files*, adds Start-Menu
   and (optional) desktop icons, and registers a clean **Uninstall** in Add/Remove
   Programs. No Python needed on the user's machine.

> Tip: for a trusted, warning-free installer, buy a code-signing certificate and
> `signtool sign` both `PHOSPHOR.exe` and the setup. Unsigned installers trigger a
> SmartScreen prompt on first run.

---

## macOS → `PHOSPHOR-1.0.0.dmg`
```
bash packaging/macos/build_dmg.sh
```
This builds `dist/PHOSPHOR.app`, ad-hoc signs it, and packages a drag-to-Applications
`.dmg`. Users open the dmg, drag PHOSPHOR to Applications; uninstall = drag to Trash.

> Unsigned apps need a one-time right-click → **Open**. For a seamless launch,
> sign + **notarise** with an Apple Developer ID (`codesign` then `xcrun notarytool`).

---

## Linux → menu icon *or* portable AppImage
Build once:
```
pip install pyinstaller pygame numpy pillow cryptography
pyinstaller packaging/phosphor.spec
```
Then either:
- **Install with a menu icon** (per-user, ~/.local):
  ```
  bash packaging/linux/install.sh          # uninstall: packaging/linux/uninstall.sh
  ```
- **Portable AppImage** (one file, no install; needs `appimagetool` on PATH):
  ```
  bash packaging/linux/build_appimage.sh   # -> dist/PHOSPHOR-1.0.0-x86_64.AppImage
  ```

On the Raspberry Pi (ARM), build on the Pi itself — the same commands work; the
AppImage/binary will be `aarch64`.

---


## Command-line auto-connect
Launch straight into a connected session (no connect panel):
```
phosphor 192.168.0.195:23        # TN3270
phosphor pub400.com:23 --5250    # TN5250 / IBM i
phosphor 10.0.0.5 --gui          # explicit GUI launch
```
The installed binary accepts the same:  `PHOSPHOR 192.168.0.195:23`.

## What gets bundled
The spec (`packaging/phosphor.spec`) includes the 3270/5250 bezel, the bundled
mono font (`phosphor/fonts/PhosphorMono.ttf`, so text renders even on a machine
with no matching system font), CRT assets, and the `cryptography` backend used for
skin licensing. The app icon lives in `packaging/icons/` (`.ico` Windows, `.icns`
macOS, `.png` Linux).

## Licensing note
Do **not** ship `vendor/` (it holds the private signing key). The client only needs
`phosphor/app/license.py` (public key). See `vendor/README.md`.
