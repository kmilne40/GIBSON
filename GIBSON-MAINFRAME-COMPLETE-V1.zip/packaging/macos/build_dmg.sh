#!/usr/bin/env bash
# PHOSPHOR - macOS build: PyInstaller -> PHOSPHOR.app -> PHOSPHOR.dmg
# Run on a Mac (PyInstaller is not a cross-compiler).
set -euo pipefail
cd "$(dirname "$0")/../.."

echo ">> building the .icns from the iconset"
if command -v iconutil >/dev/null 2>&1; then
    iconutil -c icns packaging/icons/phosphor.iconset -o packaging/icons/phosphor.icns
fi

echo ">> installing build deps"
python3 -m pip install --upgrade pip pyinstaller pygame numpy pillow cryptography

echo ">> running PyInstaller"
python3 -m PyInstaller --noconfirm packaging/phosphor.spec

APP="dist/PHOSPHOR.app"
DMG="dist/PHOSPHOR-1.0.0.dmg"
[ -d "$APP" ] || { echo "ERROR: $APP not built"; exit 1; }

echo ">> (optional) ad-hoc code sign so Gatekeeper is happier"
codesign --force --deep --sign - "$APP" 2>/dev/null || true

echo ">> creating the .dmg (drag-to-Applications)"
rm -f "$DMG"
STAGE="$(mktemp -d)"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "PHOSPHOR" -srcfolder "$STAGE" -ov -format UDZO "$DMG"
rm -rf "$STAGE"

echo ">> done: $DMG"
echo "   Users open the .dmg and drag PHOSPHOR to Applications. Uninstall = drag to Trash."
echo "   NOTE: unsigned apps need right-click > Open the first time (or notarise for a"
echo "   seamless launch - requires an Apple Developer ID)."
