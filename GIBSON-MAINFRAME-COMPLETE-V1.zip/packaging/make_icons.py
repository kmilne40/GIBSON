#!/usr/bin/env python3
"""Regenerate every PHOSPHOR icon asset from one master PNG.

    python3 packaging/make_icons.py [assets_src/phosphor_icon_master.png]

The master is the CRT app icon: a rounded-square dark chassis whose corners sit on
black.  We turn those corners transparent with a matching rounded mask (radius ~20.7%
of the side, measured from the artwork) so the icon reads cleanly on any background,
then emit:

    packaging/icons/phosphor.png            1024 master (RGBA)
    packaging/icons/phosphor-256.png        Linux menu icon
    packaging/icons/phosphor.ico            Windows (multi-size)
    packaging/icons/phosphor.icns           macOS (if Pillow can write it)
    packaging/icons/phosphor.iconset/*.png  macOS iconset (iconutil source)
    phosphor/app/assets/phosphor_icon.png   256px runtime window icon (bundled)

Re-run after changing the master; it is deterministic.
"""
import os
import sys
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICONS = os.path.join(ROOT, "packaging", "icons")
ICONSET = os.path.join(ICONS, "phosphor.iconset")
RUNTIME = os.path.join(ROOT, "phosphor", "app", "assets", "phosphor_icon.png")
DEFAULT_MASTER = os.path.join(ROOT, "assets_src", "phosphor_icon_master.png")

RADIUS_FRAC = 259 / 1254          # corner radius measured from the source artwork
SS = 4                            # supersample factor for a smooth mask edge


def rounded(img: Image.Image, size: int) -> Image.Image:
    """Return img resized to size x size with rounded-corner transparency."""
    base = img.convert("RGBA").resize((size, size), Image.LANCZOS)
    m = Image.new("L", (size * SS, size * SS), 0)
    d = ImageDraw.Draw(m)
    r = int(round(RADIUS_FRAC * size * SS))
    d.rounded_rectangle((0, 0, size * SS - 1, size * SS - 1), radius=r, fill=255)
    mask = m.resize((size, size), Image.LANCZOS)
    out = base.copy()
    # source art is opaque, so the rounded mask becomes the alpha channel directly
    out.putalpha(mask)
    return out


def main():
    master_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MASTER
    master = Image.open(master_path).convert("RGBA")
    # square the master if needed (centre-crop)
    w, h = master.size
    if w != h:
        s = min(w, h)
        master = master.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))

    os.makedirs(ICONS, exist_ok=True)
    os.makedirs(ICONSET, exist_ok=True)
    os.makedirs(os.path.dirname(RUNTIME), exist_ok=True)

    master1024 = rounded(master, 1024)
    master1024.save(os.path.join(ICONS, "phosphor.png"))
    rounded(master, 256).save(os.path.join(ICONS, "phosphor-256.png"))
    rounded(master, 256).save(RUNTIME)

    # Windows .ico - a real multi-resolution icon
    ico_sizes = [16, 24, 32, 48, 64, 128, 256]
    master1024.save(os.path.join(ICONS, "phosphor.ico"),
                    sizes=[(s, s) for s in ico_sizes])

    # macOS .iconset (iconutil turns this into .icns on a Mac)
    iconset = {
        "icon_16x16.png": 16, "icon_16x16@2x.png": 32,
        "icon_32x32.png": 32, "icon_32x32@2x.png": 64,
        "icon_64x64.png": 64, "icon_64x64@2x.png": 128,
        "icon_128x128.png": 128, "icon_128x128@2x.png": 256,
        "icon_256x256.png": 256, "icon_256x256@2x.png": 512,
        "icon_512x512.png": 512, "icon_512x512@2x.png": 1024,
    }
    for name, size in iconset.items():
        rounded(master, size).save(os.path.join(ICONSET, name))

    # macOS .icns directly, when Pillow can write it (so the spec has it even off-Mac)
    try:
        icns = master.convert("RGBA")
        rounded(master, 1024).save(os.path.join(ICONS, "phosphor.icns"))
        wrote_icns = True
    except Exception as e:                       # pragma: no cover
        wrote_icns = False
        print("  (.icns not written here: %s - iconutil will build it on macOS)" % e)

    print("wrote:")
    print("  packaging/icons/phosphor.png  (1024)")
    print("  packaging/icons/phosphor-256.png")
    print("  packaging/icons/phosphor.ico  sizes=%s" % ico_sizes)
    print("  packaging/icons/phosphor.iconset/  (%d files)" % len(iconset))
    if wrote_icns:
        print("  packaging/icons/phosphor.icns")
    print("  phosphor/app/assets/phosphor_icon.png  (256, runtime window icon)")


if __name__ == "__main__":
    main()
