#!/usr/bin/env python3
"""One-command build for the current OS.

    python packaging/build.py

Installs PyInstaller if needed, builds the app, then points you at the platform
installer step (Inno Setup / dmg / AppImage).  PyInstaller is not a cross-compiler,
so run this on each OS you want to ship for.
"""
import os
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def run(cmd):
    print("::", " ".join(cmd))
    subprocess.check_call(cmd, cwd=ROOT)


def main():
    run([sys.executable, "-m", "pip", "install", "--upgrade",
         "pyinstaller", "pygame", "numpy", "pillow", "cryptography",
         # EZrecon python backends - bundled so recon works out of the box
         "dnspython", "requests", "beautifulsoup4", "shodan"])
    # regenerate all icon assets from the master so the packaged icon is always current
    master = os.path.join(ROOT, "assets_src", "phosphor_icon_master.png")
    if os.path.exists(master):
        run([sys.executable, "packaging/make_icons.py", master])
    run([sys.executable, "-m", "PyInstaller", "--noconfirm", "packaging/phosphor.spec"])

    print("\nBuilt: dist/PHOSPHOR" + (".app" if sys.platform == "darwin" else "/"))
    if sys.platform.startswith("win"):
        print("Next (Windows installer): compile packaging\\windows\\phosphor.iss with Inno Setup")
        print("  \"C:\\Program Files (x86)\\Inno Setup 6\\iscc.exe\" packaging\\windows\\phosphor.iss")
        print("  -> Output\\PHOSPHOR-Setup.exe")
    elif sys.platform == "darwin":
        print("Next (macOS dmg): bash packaging/macos/build_dmg.sh")
    else:
        print("Next (Linux):")
        print("  installed menu icon:  bash packaging/linux/install.sh")
        print("  portable AppImage:    bash packaging/linux/build_appimage.sh")


if __name__ == "__main__":
    main()
