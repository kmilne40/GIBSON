#!/usr/bin/env bash
# Install EZrecon's external CLI tools.  The python backends (dnspython, requests,
# beautifulsoup4, shodan) ship inside the PyInstaller build; these are the native
# binaries that cannot be bundled cleanly, so they are installed here.
#
#   bash packaging/install_ezrecon_deps.sh
#
# nmap + whois come from the OS package manager.  subfinder + amass are single static
# Go binaries; we prefer a prebuilt GitHub release, falling back to `go install`.
set -u
BIN="${HOME}/.local/bin"
mkdir -p "$BIN"
say(){ printf '>> %s\n' "$*"; }

# ---- nmap + whois via the platform package manager -------------------------
install_pkg() {
  if   command -v apt-get >/dev/null 2>&1; then sudo apt-get update -y && sudo apt-get install -y nmap whois
  elif command -v dnf     >/dev/null 2>&1; then sudo dnf install -y nmap whois
  elif command -v pacman  >/dev/null 2>&1; then sudo pacman -Sy --noconfirm nmap whois
  elif command -v brew    >/dev/null 2>&1; then brew install nmap whois
  else say "no known package manager - install nmap and whois manually"; fi
}

# ---- subfinder / amass: prefer a prebuilt release, else go install ---------
os_arch() {
  local os arch
  os=$(uname -s | tr '[:upper:]' '[:lower:]')          # linux / darwin
  arch=$(uname -m)
  case "$arch" in x86_64|amd64) arch=amd64;; aarch64|arm64) arch=arm64;; esac
  echo "${os}_${arch}"
}

get_release() {   # $1 tool  $2 owner/repo  $3 asset-grep
  local tool=$1 repo=$2 pat=$3 oa; oa=$(os_arch)
  command -v "$tool" >/dev/null 2>&1 && { say "$tool already installed"; return; }
  say "fetching latest $tool release for $oa"
  local url
  url=$(curl -fsSL "https://api.github.com/repos/${repo}/releases/latest" \
        | grep -oE "https://[^\" ]+" | grep -i "$oa" | grep -iE "$pat" | head -n1)
  if [ -z "$url" ]; then
    say "no prebuilt $tool for $oa - trying: go install"
    command -v go >/dev/null 2>&1 || { say "go not found; skip $tool"; return; }
    case "$tool" in
      subfinder) go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest ;;
      amass)     go install github.com/owasp-amass/amass/v4/...@master ;;
    esac
    [ -x "$(go env GOPATH)/bin/$tool" ] && cp "$(go env GOPATH)/bin/$tool" "$BIN/"
    return
  fi
  local tmp; tmp=$(mktemp -d)
  ( cd "$tmp" && curl -fsSL "$url" -o dl && \
    ( unzip -o dl >/dev/null 2>&1 || tar xzf dl >/dev/null 2>&1 || true ) && \
    f=$(find . -type f -name "$tool" | head -n1) && [ -n "$f" ] && \
    install -m755 "$f" "$BIN/$tool" && say "installed $tool -> $BIN/$tool" )
  rm -rf "$tmp"
}

install_pkg
get_release subfinder projectdiscovery/subfinder "$(os_arch)"
get_release amass     owasp-amass/amass         "$(os_arch)"

case ":$PATH:" in *":$BIN:"*) : ;; *) say "add to PATH:  export PATH=\"$BIN:\$PATH\"";; esac
say "done - launch PHOSPHOR and open EZrecon; :backend lists what is available"
