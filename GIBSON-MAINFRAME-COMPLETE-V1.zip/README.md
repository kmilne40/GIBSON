# PHOSPHOR — TN3270 audit client (engine, Stage 1)

A native, clean-room TN3270 client in pure Python.  No x3270/s3270 dependency, no
subprocess — it speaks the 3270 data stream directly, carries **full colour** for
every cell (so ISPF/3279 screens render in real colour), and exposes a
py3270-`Emulator`-style API so it can also drive audit modules and a ported CICSpwn.

This is the engine.  On top of it will sit: IND$FILE transfer, FTP/JES, the audit
modules (vtam/tso/cics/ftp/db2 enumeration), and the GLSL CRT frontend that
consumes `screen.colour_grid()`.

## Layout
- `phosphor/core/screen.py`      colour-carrying screen model (Cell, Field, ScreenBuffer)
- `phosphor/protocols/tn3270/`   telnet + TN3270E negotiation, datastream parse/build, client
- `phosphor/frontend_ansi.py`    lightweight ANSI colour renderer (CRT frontend is separate)
- `tests/`                       self-contained engine tests

## Status (Stage 1 + audit — proven live)
- Parses real 3270 screens incl. **SFE colour** (blue/red/pink/green/turquoise/yellow/white) + highlighting
- Detects input fields; builds correct inbound frames (AID + cursor + modified fields)
- Proper **IAC EOR** end-of-record sync (no sleeps) — a full recon scan runs in ~0.2s
- **Audit modules**: tn3270-screen, vtam-enum, cics-enum (more to come) + a CLI
- Verified **end-to-end over real TCP** against a live GIBSON TN3270 server: captures the
  logon banner, finds TSO/CICS/DB2/IMS applids (rejects invalid ones), enumerates CICS
  transactions (rejects DFHAC2001 unknowns)

## Run a scan
```
python -m phosphor <host> [port] --scan [--applids TSO,CICS,DB2] [--json] [--lab]
```

## Quick use
```python
from phosphor.protocols.tn3270.client import TN3270Client
c = TN3270Client()
c.connect("192.168.0.195", 23)
c.move_to(20, 14); c.send_string("LOGON APPLID(CICS)"); c.send_enter()
for line in c.screen_get(): print(line)
```

Clean-room.  Credit the lineage (CICSpwn / Ayoub Elaassal; TN3270 research /
mainframed767) in CREDITS.  Your licence.


## Runs the real CICSpwn (py3270 replacement)
`phosphor/compat_py3270.py` presents a PHOSPHOR-backed `em` so the py3-ported
CICSpwn runs with no x3270. Proven end-to-end against GIBSON: the real
`get_cics_value`, `get_version`, `get_hql_files`, `get_users` all return correct
data over PHOSPHOR's native client.

## Interactive terminal (client only)
```
python -m phosphor <host> [port] --client
```
Renders the live 3270 screen in colour; drive it with plain text (types + ENTER),
or `:type` `:at r c` `:enter` `:clear` `:pf3` `:pa1` `:mono` `:q`.

## DB2 / DRDA probe
`phosphor/protocols/drda/probe.py` sends an EXCSAT and parses EXCSATRD for the DB2
server name / release (db2-das-info). Verified against GIBSON: GIBSONDB2 / DSN12015.

## FTP module
`phosphor/protocols/ftp/client.py` (MainframeFTP): banner, login, SITE, LIST,
RETR/STOR, and JES submit (`SITE FILETYPE=JES`). Powers the `ftp-anon` audit.
Verified against GIBSON: anon detection, authenticated LIST, and JES job submission.

## phosphor-crt — cathode-ray terminal (native GPU window)
A standalone CRT-styled TN3270 terminal (its own window, not a browser):
```
pip install moderngl pyglet pillow numpy
python -m phosphor.crt <host> [port]        # live
python -m phosphor.crt --demo               # offline colour demo screen
python -m phosphor.crt --demo --profile boardroom   # gentle effects
```
Every effect (bloom, burn-in, scanlines, curvature, glow-line, flicker, RGB-shift,
noise, vignette, bevel) is an adjustable intensity. Presets: authentic / amber /
green / **boardroom** (gentle) / **off** (flat). Live controls: Ctrl+[ / Ctrl+]
select an effect, Ctrl+ +/- adjust it, Ctrl+P cycle presets, Ctrl+M cycle palette,
Ctrl+S save. Runs on your GPU — I can't display it in the build sandbox, so shader
tuning is done on your hardware (send screenshots and I'll iterate).

## Recon menu + notepad (no switches to memorise)
```
python -m phosphor --menu                 # or:  python -m phosphor <host> --menu
```
Pick a scan (tn3270-screen, vtam-enum, tso-enum, cics-enum, cics-user-enum,
cics-info, ftp-anon, db2-das-info); fill a short form (defaults pre-filled); run
it with the **Native** engine (no nmap needed) or have the menu emit the exact
`nmap --script ... --script-args ...` command. If a wordlist (users.txt etc.) is
missing it opens a built-in **notepad** (add/del/list/seed/save, with starter
lists). Collected findings export to the HTML/Markdown report.

## Live IND$FILE over TSO
PHOSPHOR now navigates the full-screen TSO/E LOGON panel to a READY prompt, so
IND$FILE transfers run over a real session:
```python
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.tso import tso_login
from phosphor.protocols.indfile.dft import IndFileClient
c = TN3270Client(); c.connect(host, 23); tso_login(c, "IBMUSER", "SYS1")
IndFileClient(c).put("IBMUSER.MY.TEXT", b"...")      # upload
data = IndFileClient(c).get("IBMUSER.MY.TEXT")        # download (EBCDIC; decode cp037 for ASCII)
```
