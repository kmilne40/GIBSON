# GIBSON & PHOSPHOR — What's New and Component Guide

*A quick-reference to everything implemented in this phase of work, and what each
tool component does.*

---

## Part 1 — What's new (quick reference table)

| # | Area | Feature | What it does | Status |
|---|------|---------|--------------|--------|
| 1 | GIBSON / CICS | Real CECI/CEMT/CEDA interpreter | Makes the real CICSpwn tool work against GIBSON: `EXEC CICS` recon, file/queue reads, region inquiry | Done |
| 2 | GIBSON / CICS | CEDA RACF bypass | Cloning CECI to an unprotected transaction name defeats a name-based RACF lock (`--bypass`) | Done |
| 3 | GIBSON / CICS | Byte-exact `--submit` payload | CICSpwn's real reverse-shell JCL (edited via the CECI variables screen) reaches JES verbatim, not a placeholder | Done (V20) |
| 4 | GIBSON / RCE | Sandboxed reverse-shell landing | Submitted job connects back to the attacker's listener and serves a simulated OMVS/TSO shell; scope-limited to loopback/RFC1918 | Done (V21) |
| 5 | PHOSPHOR / core | Native TN3270 engine | Clean-room 3270 datastream + telnet, colour screen model, no x3270 dependency | Done |
| 6 | PHOSPHOR / protocols | IND$FILE (DFT) | Standard structured-field file transfer, upload and download | Done |
| 7 | PHOSPHOR / protocols | FTP client | Login, listing, get/put, and JES submit via `SITE FILETYPE=JES` | Done |
| 8 | PHOSPHOR / protocols | DB2 DRDA probe | EXCSAT handshake to fingerprint the DB2 server and version | Done |
| 9 | PHOSPHOR / audit | 8 audit modules | tn3270-screen, vtam-enum, tso-enum, cics-enum, cics-user-enum, cics-info, ftp-anon, db2-das-info | Done |
| 10 | PHOSPHOR / UX | Recon menu | Configure & run every scan from one console — native engine or exact nmap command | Done |
| 11 | PHOSPHOR / UX | Built-in notepad | Build a missing users.txt/passwords.txt on the spot, with starter seed lists | Done |
| 12 | PHOSPHOR / output | HTML + Markdown reporting | Turns findings into a client-ready report with severity, evidence, remediation | Done |
| 13 | PHOSPHOR / TSO | TSO/E panel login | Navigates the full-screen LOGON panel to READY, unblocking live IND$FILE | Done |
| 14 | PHOSPHOR / CRT | Cathode-ray terminal | Native GPU TN3270 terminal with fully adjustable effects (bloom, scanlines, curvature…) and gentle/off presets | Done |
| 15 | PHOSPHOR / CRT | CPU preview mode | `--preview` renders stills of every profile without a GPU | Done |
| 16 | PHOSPHOR / integration | CICSpwn adapter | Runs the real (py3-ported) CICSpwn on PHOSPHOR instead of py3270/x3270 | Done |
| 17 | Packaging | Nuitka binary build | Compile PHOSPHOR to a single native executable (lean core, optional CRT) | Ready to build |
| 18 | Docs | Chapter 11 & 13 labs | Full kill-chain and data-exfiltration lab walkthroughs | Done |

---

## Part 2 — Tool component rundown

### GIBSON (the training target)

- **CICS 3270 session (`cics_session.py`)** — the interactive CECI/CEMT/CEDA
  interpreter that CICSpwn drives. Handles the command interpreter, the variables
  (working-storage) screen, the SPOOL→JES bridge, and the RACF-bypass logic.
- **Reverse-shell lander (`net/revshell_lander.py`)** — when a reverse-shell job
  is submitted, extracts the callback address, connects back (loopback/RFC1918
  only), and serves GIBSON's simulated OMVS/TSO shell over it. Fully sandboxed.
- **IND$FILE hosts (`net/indfile/`)** — the DFT (modern) and CUT (legacy) host
  sides of IND$FILE, serving the standard protocol any 3270 emulator speaks.
- **Core services** — TN3270, FTP, DB2/DRDA, USS/OMVS, RACF, JES, all as
  simulated network services with fake data.

### PHOSPHOR (the audit client)

- **TN3270 engine (`protocols/tn3270/`)** — telnet + 3270 datastream, a colour
  screen buffer, and a py3270-compatible client API (connect, send, PF keys,
  screen scraping, structured-field exchange).
- **TSO login helper (`protocols/tn3270/tso.py`)** — drives the TSO/E LOGON panel
  to a live READY prompt so TSO commands and IND$FILE can run.
- **IND$FILE / FTP / DRDA clients (`protocols/`)** — the three data-movement and
  fingerprinting protocols, each a clean-room implementation.
- **Audit modules (`audit/enumerate.py`)** — the eight enumeration/assessment
  checks, each returning structured findings with severity and evidence.
- **Recon menu (`recon_menu.py`)** — the interactive cockpit: pick a scan, fill a
  short form, run it natively or emit the exact nmap command, collect findings.
- **Notepad (`notepad.py`)** — a dependency-free wordlist editor with seed lists,
  opened automatically when a scan needs a wordlist that isn't there.
- **Reporting (`report.py`)** — dependency-free HTML and Markdown report generator
  with executive summary, grouped findings, evidence, and remediation.
- **CRT terminal (`crt/`)** — a native GPU cathode-glass terminal: adjustable
  shader effects (`config.py` + GLSL in `shaders/`), a live effect HUD, profiles
  from full-glass to flat, and a CPU preview mode.
- **CICSpwn adapter (`compat_py3270.py`, `run_cicspwn.py`)** — presents the real
  CICSpwn a compatible emulator so it runs on PHOSPHOR with no x3270.
- **CLI (`cli.py`, `__main__.py`)** — one entry point for scanning, the menu, the
  interactive client, and reporting.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (bezel + speed + FTP transfer mode)

- **IBM 3270 bezel** — the live screen now renders inside a photoreal IBM 3270
  bezel (`phosphor/app/assets/ibm3270_bezel.png`). The glass shows only the
  terminal; every control (sidebar, keypad, command line, colour/font bar,
  packet monitor) sits **outside** the CRT area. Toggle with the **Bezel**
  button on the bottom bar (falls back to the plain framed viewport if off or
  if the asset is missing).
- **Much faster UI.** The 80×24 raster and the CRT pass are now cached and only
  recomputed when the screen content actually changes, fonts are memoised, and
  the pygame loop is dirty-driven (it renders on input / state change instead of
  a heavy fixed 30 fps). Idle/typing dropped from ~7 fps to ~38 fps; a full
  screen update from ~9 fps to ~22 fps. Typing into the command line is instant.
- **FTP transfer mode.** The FTP client now switches between **BINARY (TYPE I,
  raw bytes)** and **ASCII (TYPE A, host EBCDIC↔ASCII translation)** — a **Mode**
  button in the FTP dialog, honoured by download/upload. Use ASCII for readable
  text datasets, Binary for load modules / archives.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (Model M restyle + bigger screen + fullscreen)

- **IBM Model M workstation styling.** The chrome around the monitor now reads as
  a beige Model M workstation: a warm-greige case, raised section plates, and
  sculpted two-tone grey **keycap buttons** with dark charcoal legends (top-light
  bevel, bottom/right seat shadow, press/hover states). Input fields are recessed
  pale nameplates. The dark 3270 bezel, the terminal glass, and the OUTPUT /
  PACKETS / command-line readouts stay dark — displays set into the beige case.
- **Much bigger terminal.** The screen area grew ~1.8× (glass ≈ 828×556, up from
  ~602×404). The canvas is 1500×900, the sidebar is a single tight column, and
  the PF keypad is narrower with taller keycaps.
- **Fullscreen + resizable.** The window is resizable and **F11 / Alt+Enter**
  toggle fullscreen (**Esc** exits). The design canvas is letterbox-scaled to the
  display and mouse coordinates are transformed back, so hit-testing stays exact
  at any size.
- **POWER button quits.** Clicking the **POWER** button on the 3270 bezel shuts
  the application down (same as Quit).
- **Header cleanup.** The "mainframe terminal build…" subtitle next to PHOSPHOR
  has been removed; the wordmark sits over an IBM-blue rule.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (idle/render efficiency pass)

The app now does almost nothing when you are not interacting with it, and a
keystroke or host-screen update is far cheaper than before.

- **Event-driven loop (sleeps when idle).** The main loop now blocks on
  `pygame.event.wait(timeout)` instead of spinning at 60 Hz. When nothing is
  happening the process sleeps (near-zero CPU); a short timeout (100 ms, or
  ~33 ms while CRT animation is on) still lets background scans / shell output
  surface promptly. Measured: **0 renders across 600 ms of idle.**
- **O(1) change detection.** The per-iteration "did anything change?" check no
  longer hashes all 1,920 screen cells; a `grid_gen` counter bumps on each screen
  write instead. The idle fingerprint dropped from ~128 µs to ~1.7 µs per check.
- **Cached chrome, dynamic overlays.** The static UI (sidebar, keypad, bottom
  bar, panels, bezel, command-line box, popups) is composed once and cached; only
  the live terminal glass and the command-line text are redrawn each frame. Result:
  typing in the command line went from ~27 ms to ~1.2 ms per frame, and a host
  screen update from ~57 ms to ~34 ms. The cache is provably transparent (the
  composited output is pixel-identical to a full re-render).

Net effect: idle ≈ free, typing feels instant, and the screen only refreshes when
something actually changes.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (Phosphor Skins - theme system)

- **Swappable themes.** A new theme engine re-skins the whole UI by rebinding the
  colour palette; every drawing routine already reads those globals, so switching
  is instant and needs no per-widget changes. Themes cover the chrome (case,
  keycaps, legends, panels), the dark readouts/popups, and the terminal glass
  (foreground tint + field colour).
- **Skins picker.** A "Skins" button on the bottom bar opens a modal with a live
  swatch for each skin; the active one is marked, add-on skins show a PRO tag.
- **Skin set (inspired-by palettes; no logos/trade dress):** Classic 3270
  (default), Green Room (the original all-green look), Amber Glass, Workstation
  Grey, ISPF Blue are included; Enterprise Z, Breadbin Blue, LCARS Console,
  Cyberdeck, Dark Ops are the add-on pack (gated by an `unlocked` set, with a
  hook for a future licence check).
- Chrome-cache and change-detection integrate with the theme (theme is part of
  the cache key), so the render stays cheap and the cached output is still
  pixel-identical to a fresh render on every skin.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (NTL bezel, Focus mode, font zoom, persistence)

- **De-branded bezel.** The monitor wordmark is now "NTL" (the "IBM" mark was
  painted out and replaced); the asset is `assets/ntl3270_bezel.png`. Swap in your
  own mark by editing that file. (The generic "3270" model text is still present -
  say the word if you want it changed too.)
- **Focus mode (detached full-screen terminal).** A "Focus" button on the bottom
  bar - or F10 - hides all the chrome and fills the window with just the bezel +
  glass, for heads-down work. Esc or F10 exits (or click the top-right corner).
- **Font zoom.** Ctrl +/- (and Ctrl 0 to reset) changes the screen font size, as
  do the A-/A+ buttons. In the fixed windowed layout the 80x24 screen fills the
  glass, so zoom mainly sharpens/weights the text there; the big size change is in
  Focus mode, where zoom scales the whole terminal.
- **Persistence + skin licensing.** The active skin, font size, bezel, and any
  unlocked add-on skins are saved to `~/.config/phosphor/prefs.json` and restored
  on launch. Add-on skins unlock via that file, a `licence.json` dropped in the
  same folder, or the env vars `PHOSPHOR_UNLOCK="lcars,cyber"` /
  `PHOSPHOR_UNLOCK_ALL=1` - a clean hook to wire to a real store later.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (UX fixes: dialogs, startup, layout, transfer type)

- **File dialogs no longer hang.** The old open/save/name prompts built a Tk root
  on the pygame main thread, which deadlocks SDL. All dialogs now run in a
  separate process (zenity / kdialog / osascript / a one-shot Tk subprocess) from
  a background thread (`app/filepick.py`), so the UI keeps running while a dialog
  is open. Copy/Paste use the system clipboard via subprocess too (no more Tk).
- **Faster startup / no blank-until-click.** Tool discovery (which shells out per
  tool) now runs in the background instead of blocking launch, and the loop
  repaints on window-expose events so the first frame shows without needing a
  click.
- **Bottom-bar overlap fixed.** The second row of buttons (which was drawn under
  the packet panel) is gone; skins, bezel, focus and about now live inside the
  Settings window. The bottom bar is a single clean row with a prominent
  \u2699 Settings button and a Focus button.
- **ASCII / BINARY transfer type.** Upload/Download (IND$FILE) now has a
  "Type: ASCII/BINARY" toggle in the TRANSFER panel; the FTP dialog's download
  also honours its BINARY/ASCII mode for the save extension.
- **Clickable packet monitor.** The PACKETS strip is now clickable and expands
  into the scrollable console view for the full EBCDIC/ASCII log.
- **OUTPUT repurposed.** The redundant "connected to \u2026" line was removed; the
  panel is now dedicated to scan findings.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (popups on top, bezel mark fixes)

- **Popups now render on top of the terminal.** Scan output, the console, settings
  and every other dialog were being drawn into the cached chrome and then painted
  over by the terminal glass (a regression from the render-cache work). Popups and
  tooltips are now composited AFTER the glass, as proper dark modal windows over
  the green screen, and can be closed as before. The chrome cache stays pixel-exact
  on non-popup frames.
- **Bezel wordmark fits.** "NTL" was too wide for the badge; it's resized to match
  the original mark footprint. Added a "5250" model line directly under "3270"
  (the client will support both data streams).

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (TN5250 / IBM i scaffold)

- **5250 protocol support (first cut).** Added a TN5250 client so the tool can
  talk to IBM i (AS/400) hosts, not just z/OS. Architecture:
  - `protocols/session.py` - the interface both clients implement, so the app,
    field editor and tools work against either data stream unchanged.
  - `protocols/tn5250/datastream.py` - clean-room 5250 Write-To-Display parser
    (SBA, RA, SF with field-format word, IC, EBCDIC placement) plus a matching
    builder, so it's round-trip unit-tested without a live host (9 tests).
  - `protocols/tn5250/client.py` - `TN5250Client`, same surface as the 3270
    client, reusing the telnet negotiator with the 5250 device type (RFC 1205
    basic mode).
  - A **TN3270 / TN5250 selector** in the CONNECT panel picks the client; 5250
    screens render through the same colour grid.
- **What still needs a live host (pub400.com):** TN5250E (GDS-wrapped) mode, the
  full outbound field-read format, extended attributes/colour, and on-screen field
  editing for 5250. The scaffold renders panels and sends AIDs; these are the
  refinement steps against a real IBM i.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (licensing, Beeb Cream skin, bezel tweaks)

- **Skin licensing (Ed25519, offline-verifiable).** Paid skins now unlock via a
  signed licence. The vendor holds an Ed25519 private key (in `vendor/`, never
  shipped); the client (`app/license.py`) has only the public key, so the app can
  *verify* but never *forge* a licence — reverse-engineering it yields nothing
  useful. A licence embeds the buyer's email + entitled skins + expiry and is
  emailed to them; the client refuses it under any other email. Activation
  ("Enter licence" in the Skins picker) verifies the signature, checks the email
  and expiry, and caches it (re-verified every launch). Tamper/forge/wrong-email/
  expiry are all rejected (7 unit tests). Vendor issuer + SMTP sender + a security
  README are in `vendor/` — **regenerate the keypair before selling** (see README).
- **Free vs paid.** Free: Classic 3270, Green Room, LCARS Console. Everything else
  (Amber, Workstation Grey, ISPF Blue, Enterprise Z, Breadbin Blue, Cyberdeck,
  Dark Ops, Beeb Cream) is part of the paid pack.
- **Beeb Cream skin** — a British 8-bit micro look: cream case, bright red accent,
  white-on-black screen. (Built from the general aesthetic; send the reference
  image to fine-tune the palette.)
- **Bezel:** the dark square below the model text is now the quit button; the
  "3270" and "5250" labels are a little larger.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (Bubblegum skin + Beeb Cream tune)

- **Bubblegum skin (FREE).** A hot-pink dollhouse workstation: bubblegum case,
  light-pink keycaps, deep-magenta readouts, hot-pink accents, green screen -
  matching the pink reference. Free set is now Classic 3270, Green Room, LCARS
  Console and Bubblegum; all others are the paid pack.
- **Beeb Cream** retuned to a lighter, cooler cream to match the real BBC Micro B
  case, keeping the red function-key accent.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (master unlock code + picker fit)

- **Master unlock code.** A shared password unlocks every skin (hand it to
  friends). Only a memory-hard **scrypt hash** of the password is stored in the
  source - never the password itself - so it can't be read out of the code or the
  binary. Entering it re-derives the same hash and unlocks all skins; a wrong
  password or a hand-edited config grants only the free set. Enter it in the Skins
  picker's "Enter licence" window, as the token.
- **Skins picker fit.** With 12 skins the grid overflowed its modal box onto the
  dimmed background; the picker is now a 3-column grid sized so every card sits
  inside the window. Bubblegum is confirmed free.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (bezel labels up, pink screen text)

- **Bezel:** "3270" / "5250" moved up ~an inch, into the upper area between the
  NTL wordmark and the power square.
- **Bubblegum screen:** the terminal now renders in pink instead of green, with
  red highlights where the host uses attention colours (red/yellow). Added a
  per-skin screen colour map (`Theme.screen_palette`) threaded through the glass
  renderer, so any skin can recolour the screen text per 3270 colour attribute.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (skins x4 + professional installers)

- **New skins.** BBC Micro B (now FREE, red function-key accents + red screen
  highlights), Mainframe Z (FREE, blacked-out big-iron with an electric-blue
  accent), Grid (PAID, neon cyan/orange "light-cycle" look), ZX Rubber (PAID,
  black rubber-key micro with a rainbow accent). Free set is now Classic 3270,
  Green Room, LCARS, Bubblegum, BBC Micro B, Mainframe Z (6 free, 9 paid). The
  skins picker auto-sizes to the number of skins so it never overflows.
- **Installers (Windows / macOS / Linux).** A full packaging kit under
  `packaging/`: a PyInstaller spec that bundles the app + a fallback font + the
  bezel + the crypto backend; an Inno Setup script for a Windows `PHOSPHOR-Setup.exe`
  (Start-Menu + desktop icon + clean uninstall); a macOS `build_dmg.sh`
  (.app -> drag-to-Applications .dmg); Linux `install.sh` (menu icon) and
  `build_appimage.sh` (portable AppImage); an app icon (.ico/.icns/.png); a
  one-command `build.py`; and `packaging/README.md` with per-OS steps. The Linux
  build was validated here end-to-end (bundle boots, assets/fonts/crypto load).
  PyInstaller isn't a cross-compiler, so build each OS on that OS.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (crisp screen, tools lock, LCARS, report, fixes)

- **Crisp screen font.** The glass now renders the 80x24 grid at the screen's
  native resolution (integer cells, no fractional downscale), which was the source
  of the softness. Font size is honoured via the render + focus zoom.
- **Focus mode fills the screen** (cover scale, minimal surround).
- **Rounded glass.** The screen is masked to rounded corners so it follows the
  curved CRT instead of showing as a hard square.
- **BBC Micro B** PF/keypad keys are now RED.
- **LCARS** retuned to the authentic black / bright-orange scheme with lilac + gold
  accents, and the screen text is orange. (Added header/field colour decoupling so
  black-on-orange keys coexist with a visible wordmark.)
- **Pen-test tools locked** behind a one-time code (default TN3270tools!), scrypt-
  hashed in source (never the plaintext). Unlock popup; stays unlocked per machine.
- **Removed** the CICSpwn and John buttons; credential grid rearranged.
- **OUTPUT findings are clickable** - each opens its full detail in the console.
- **Markdown pen-test report** (Report button): combines notes + captured screens
  + findings. Grab button snapshots the current terminal screen (real text grab).
- **Paste token** now uses the in-app SDL clipboard first, so it actually pastes.
- **TN5250** parser now consumes field-attribute bytes (the stray corner/¬ glyphs
  on PUB400) - best-effort; still needs live-host iteration for full fidelity.
- **Bezel** flat patch above the power button blended into the panel texture.

*Authorised, defensive training use only.*

---

## Update — 2026-07-11  (hack3270 field-input + injection fixes)

Fixed three real bugs in the hack3270 workflow (reproduced with a DVCA-style
protected+hidden PIN screen; the PIN is now obtained end-to-end):

- **Typing with 'unprotect' on landed in the wrong field.** `unprotect` turns
  former label fields into input fields, and the editor re-synced the cursor onto
  the first field (a label) after every ENTER, so typed numbers went into the label
  instead of the target field. The cursor is now preserved whenever it's already in
  an input field.
- **Injection never cleared the target field.** The old clear (click-to-start then
  backspace) was a no-op - you can't backspace before a field start - so mask /
  previous-guess characters corrupted each guess. Injection now writes the whole
  field width via a proper `set_field`, clearing residuals.
- **Injection could never detect a hit.** The response was the raw 24x80 screen,
  which is a constant size, so the size-based hit detection never fired. It now
  compares the actual (rstripped) screen content, so the winning PIN's changed
  screen is flagged. Verified: injecting a wordlist against a DVCA-style host now
  finds the correct PIN.

*Authorised, defensive training / GIBSON use only.*

---

## Update — 2026-07-11  (About, master-password fix, startup + speed)

- **About** is now a proper dialog: PHOSPHOR is a TN3270/TN5250 app by Kev Milne
  (offensivesec.org); free to use; extra skins £5 from the OffensiveSec site; carries
  security tooling that needs authorisation; tools unlock code is in the No Starch
  Press book "Hacking Mainframes" or by PMing Kev on LinkedIn. Plus version,
  authorised-use notice and copyright.
- **Master unlock password fixed.** The licence popup's token box was paste-only, so
  a typed code like `TN3270Acc,ess4me!` never registered ("wrong password"). The box
  is now a normal text field - type the code (or Paste a long licence token) and
  Activate. Verified the master code unlocks all skins.
- **~30s startup fixed.** `pygame.init()` also starts the audio/mixer subsystem,
  which on machines with no / an unusual audio device blocks for ~30s probing
  hardware. PHOSPHOR uses no audio, so it now inits only display + font.
- **Snappier UI.** Hovering a control used to recompose the entire chrome (~27ms per
  mouse-move); the hover/press cue is now a cheap overlay and the chrome cache key was
  slimmed, so hover, opening a popup, and console/packet updates no longer trigger a
  full re-composite. Measured: hover frame 27ms -> ~2.7ms.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (5250 input, cursor, scroll, CLI connect, fixes)

- **TN5250 input now works.** Two bugs: field editing was hard-disabled for 5250
  (`editor = None`), and (per RFC 1205) the 5250 data is wrapped in a GDS header the
  host sends and requires back - PHOSPHOR neither stripped it on input nor added it on
  output, so IBM i silently ignored typed data. Now: GDS wrap/unwrap wired, the field
  editor runs for 5250 (bypass bit 0x2000 = protected), and the outbound is GDS-wrapped.
  Verified end-to-end against a constructed PUB400-style sign-on (input field detected,
  typing lands, outbound carries the data). Live pub400.com validation still recommended.
- **Terminal cursor.** A solid light-blue cursor is drawn on the glass, aligned to the
  cell grid, and moves as you type. No blink animation (kept it static so there's no
  continuous re-render - speed over the blink). Optional **crosshair cursor** (full
  row/column guide) via the Settings toggle.
- **Scrollable popups.** Mouse-wheel now scrolls the console / PCAP / report / findings
  view and the Help popup (in addition to F7/F8). Important for reading long captures.
- **CLI auto-connect.** `phosphor <host>` or `phosphor <host>:<port>` (add `--5250` for
  IBM i) launches the desktop app already connecting to that target - no need to use the
  connect panel. `phosphor <host> --gui` works too.
- **Settings no longer covers the Skins picker** (opening Skins closes Settings; pickers
  also draw above Settings as a safety net).
- **BBC Micro B** PF keys are red with **black** legend text.
- Cursor/keyboard toggles (Monocase, Cursor blink, Typeahead, Crosshair) are now real
  state, not cosmetic.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (--client shell: visible cursor + transfer menu)

- **`--client` shell terminal** now shows a **visible light-blue cursor block** on the
  live screen (not just the row/col in the prompt), and gains a **`:menu`** with
  IND$FILE upload/download, an FTP sub-menu (ls / get / put), and save-screen-to-file.
  It also takes `--5250` for IBM i. This is intentionally lighter than the desktop app
  (no skins / pen-test tooling / packet view) - for SSH / headless use.
- **`phosphor --help`** now documents every mode (desktop connect, `--client`, `--scan`,
  `--menu`, and `--5250`) in a modes section, so it's clear what each does.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (GUI font overlap FIXED + adjustable size)

- **The bunched/overlapping GUI font is fixed.** Root cause: glyphs were sized to the
  cell *height* (~21pt), but at that size a monospace glyph is far wider than the ~10px
  cell, so every character was clipped/cramped into its neighbour. Glyphs are now sized
  to fit the cell **width** and centred, via a binary-search fit. Verified: a full row
  of the widest glyphs (M/W) has zero ink crossing any cell boundary - crisp, evenly
  spaced text at every size.
- **Font size is adjustable (A- / A+).** Since 80x24 fills the fixed glass, size is a
  scale of the glyph *within* the cell (55-100%): A- gives smaller text with more space,
  A+ fills the cell. It never overlaps at any setting. (For bigger overall text, resize
  the window or use Focus mode / F10.)
- Studied the wren-creator/web3270 reference: its key protocol lesson is exact
  SF/SBA/SFE parsing with correct SBA address decode - the reference for the 5250
  "wrong position" work still outstanding.

### Still outstanding (next)
- Shell `--client`: make it a proper c3270-style full-screen curses TUI (direct field
  typing, real PF keys), and diagnose the logon input issue.
- TN5250 on-screen positioning against a live pub400 capture.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (12px font fix + c3270-style shell TUI)

- **12px font no longer looks sparse/dotty.** The size control now scales the glyph
  between 82% and 100% of the cell (not down to ~55%), so at every setting the text
  is solid and readable - the CRT scanlines no longer break tiny strokes into dots.
  12px now renders ~2.6x the ink it did before; 24px fills the cell. Still zero overlap
  at any size.
- **`--client` is now a full-screen curses TUI, like c3270.** Type directly into the
  fields on screen (visible hardware cursor), move with arrows, Tab / Back-Tab between
  fields, real F1-F24 = PF1-PF24, Enter sends, and a ':' command line for :menu /
  :upload / :download / :ftp / :pf N / :save FILE / :q. Works for TN3270 and (--5250)
  TN5250. `--repl` keeps the old simple line prompt. Verified in a pseudo-terminal:
  draws in colour, field typing lands, cursor tracks the field, arrows/Tab work.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (5250 positioning + --client help)

- **TN5250 positioning is more correct.** Added the 5250 orders that were unhandled and
  therefore scattering the layout: Erase-to-Address (0x03), Write Extended Attribute
  (0x12), Write-to-Display Structured Field (0x15), and Move Cursor (0x14). Unhandled,
  each was rendered as stray cells that shifted everything after it; now they consume
  their operands correctly. Verified: SBA places text at the exact row/col, and text
  after a WEA no longer shifts. (A live pub400 capture is still the way to confirm full
  fidelity against that specific host.)
- **`phosphor --help`** now describes `--client` as the full-screen curses TUI (c3270
  style) rather than the old one-liner.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (--client TUI: Tab / Enter / logon fixed)

- **Tab now works in the shell TUI, and logon works.** curses `get_wch()` returns Tab
  as the string "\t", but the handler only matched the integer 9 in the special-key
  branch, so Tab was silently dropped - which meant you could never reach the password
  field and logon always failed. Tab (and Shift-Tab, Enter) are now handled as the
  strings the terminal actually sends. Verified in a pseudo-terminal: type userid ->
  Tab -> type password -> Enter sends both credentials to the host as an ENTER AID.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (password gating + install docs)

- **CLI scans are now gated behind the tools unlock code**, exactly like the GUI. A
  plain `phosphor <host> --scan` (or --menu) refuses until you enter the code:
  `phosphor <host> --scan --unlock TN3270tools!` unlocks and remembers it on that
  machine. The terminal (`--client`) needs no code.
- **GUI master unlock code fixed.** The code `TN3270Acc,ess4me!` was correct all along,
  but the licence popup did not focus the code box on open, so typing went nowhere
  until you clicked it. The box is now focused automatically - open Enter Licence, type
  the code, Activate.
- **BUILD-INSTALLERS.md / PDF** - a clear, step-by-step guide for building the Windows,
  macOS and Linux installers, with signing/notarisation notes and troubleshooting.

*Authorised, defensive / training use only.*

---

## Update — 2026-07-12  (field navigation, password entry, arrows, typing speed)

Fundamental input fixes, in both the GUI and the --client TUI (they share the field
editor, so both benefit):

- **Password would not enter / was rejected (TSO and TN5250).** Navigating to the
  password field kept the *column* from the previous field, so typing produced a value
  with leading blanks (e.g. "       SECRET") that the host rejected. Now: Up/Down are
  field-aware and land at the field start, and typing into an empty field left-justifies
  regardless of where the cursor sat. Verified: password is sent clean at the field
  start.
- **Up/Down arrows now work.** In the TUI they were dropped; in the GUI they were never
  handled. Both now move between input fields (Up/Down) with Left/Right for free
  movement, Home to field start, and Shift-Tab for back-tab.
- **GUI: you can type as soon as you connect** - the screen is focused on connect, so you
  no longer have to click the glass first.
- **Typing is much faster.** The CRT pass was re-processing the whole ~460k-pixel glass
  through a float pipeline on every keystroke even with no effects enabled (the default).
  Added a fast path that skips it in flat mode: per-keystroke render dropped from ~15ms to
  ~6.5ms here (a bigger win on the Pi).

*Authorised, defensive / training use only.*

---

## `--client` rebuilt as a boxed operator console

The full-screen curses terminal (`phosphor <host> --client`) is now framed by the
physical 3270 operator keypad, drawn as boxes around the terminal glass and arranged to
match the reference 3270 keypad and the positions of the desktop (`--gui`) client:

- **Top:** the PF grid, PF13-24 over PF1-12.
- **Left:** PA1/PA2, Attn/PA3, Erase EOF/Erase Input, SysReq/Clear.
- **Right:** Home, Cursor Select/Compose, Insert/Delete, Dup/Field Mark.
- **Bottom band:** Tab, Back-Tab, Reset, New Line, Enter, then the tool boxes MENU,
  Settings, Help, Quit.
- **Bottom line:** the `:` command line stays pinned at the very bottom (`:q` to quit).

Every box works two ways, as on the desktop client: click it with the mouse, or press
Ctrl-K to enter keypad navigation, move the highlight with the arrows, and press Enter.
The glass keeps focus by default so you type straight into the fields; real F1-F24 fire
PF1-24 and Esc then 1/2/3 fires PA1/PA2/PA3, exactly as before.

`MENU` opens the same option set as the GUI: Upload, Download, transfer-mode toggle, FTP
client / submit JCL, Save screen, the scan/audit tools (Scan all, VTAM, TSO, CICS
trans/users/info, FTP anon, DB2), and a markdown pen-test report. The scan tools stay
behind the one-time unlock code, exactly like the GUI and the CLI `--scan` path; the
terminal itself needs no code.

Insert/Delete/Dup/Field Mark are handled locally in the client (insert/overtype toggle,
delete-under-cursor, and the DUP / field-mark placeholders). Cursor Select, Compose and
SysReq have no host mapping in basic TN3270 and report that in the status line rather than
pretending to send something.

Layout, hit-testing and box navigation live in `phosphor/client_panels.py` (no curses, so
it is unit tested headless); the curses front-end is `phosphor/client_tui.py`. Tests:
`tests/test_client_panels.py` (27 assertions) plus a pty smoke test of the live render and
event loop. The layout degrades gracefully on narrow/short terminals, folding the outer
clusters into MENU while keeping the glass and command line usable.

*Authorised, defensive / training use only.*

---

## Real-host fixes: z/OS (zPDT) rendering + TN5250 (PUB400) input

**z/OS panels showed stray box glyphs and TAB/field movement broke.** The 3270
parser defined but never handled three orders that real ISPF emits constantly:
Erase Unprotected to Address (EUA, 0x12), Graphic Escape (GE, 0x08), and Modify
Field (MF, 0x2C). When one arrived, the parser printed the order byte and its
operands as characters (the boxes) and, worse, never advanced the buffer address,
so every following write landed in the wrong cell. That desync shifted the whole
field map, which is why TAB and field-to-field movement misbehaved. Fixes:

- EUA now nulls unprotected cells up to the stop address and advances correctly,
  leaving protected text and field attributes intact.
- GE renders the next byte from the alternate (line-draw) set and advances one
  position, so box-border panels stay aligned. The glyph mapping is best-effort
  for the common line-draw code points.
- MF consumes its type/value pairs and keeps buffer alignment.
- EBCDIC null (0x00) and any byte that decodes to a control character now render
  as a blank, the way a real 3270 shows nulls and orders, so no cell ever shows a
  box/replacement glyph.
- Character cells now carry their field's protection (previously every body cell
  was marked protected), which is what lets EUA and field logic behave correctly.

TAB was also rewritten to cycle only through input fields, land on the field
start, wrap correctly, and (back-tab) return to the current field's start before
stepping to the previous field.

**TN5250 input did nothing against PUB400.** In basic 5250 mode (RFC 1205) the
inbound record is the raw cursor+AID+fields stream framed by IAC EOR - it must not
be GDS-wrapped. The client was always wrapping, so a basic-mode host silently
ignored the keystrokes. Fixes: send the raw frame in basic mode (with IAC byte
stuffing) and only GDS-wrap when the host actually uses TN5250E enhanced mode
(auto-detected from the 0x12A0 record header). The telnet negotiator now also
answers NEW-ENVIRON with WONT (the IBM i host then auto-creates the device) and
agrees SGA, so the IBM i transparent-mode handshake completes cleanly.

Tests: `tests/test_ds_orders_eua_ge.py` (10) and `tests/test_tn5250_negotiation.py`
(12). Honest caveat: the TN5250 fixes are validated by round-trip tests and the
protocol references (RFC 1205 / 2877 / 4777), not against a live PUB400 from here.
If a specific panel still misbehaves, capture the trace (the packet tap) and it can
be confirmed against the real byte stream.

**Settings menu:** the Cursor blink and Crosshair cursor toggles were removed.

*Authorised, defensive / training use only.*

---

## TUI keypad trimmed + EZrecon toolkit + ZX rainbow

**`--client` operator column reworked.** The cursor/edit cluster (Home, Cursor
Select, Compose, Insert, Delete, Dup, Field Mark) was removed from the screen, and
Erase EOF / Erase Input were dropped. The kept operator keys - PA1, PA2, Attn,
PA3, SysRq, Clear - now stack in a single column on the right-hand side of the
glass, in that order. Insert / Delete / Home still work from the physical keyboard;
Erase EOF is still on Ctrl-U. The PF grid, bottom band, and `:` command line are
unchanged.

**`:help` is now a `:` command reference.** Typing `:help` (or `:?`, or the Help
box) lists the colon-commands with downloads front and centre: `:download`,
`:upload`, `:ftp`, `:menu`, `:recon`, `:scan`, `:settings`, `:save FILE`, `:pf N`,
`:pa N`, `:clear`, `:mono`, `:q`.

**EZrecon - OSINT / recon toolkit, in both clients.** A clean-room re-implementation
of the core operations from the reccy_toolkit (reckit.py), wired into the TUI
(MENU -> EZrecon, or `:recon`) and the GUI (TOOLS -> EZrecon). Operations: DNS
records, WHOIS, subdomain enumeration, dangling-DNS / takeover check, zone-transfer
attempt, email scraper, port scan / banner grab, Shodan host lookup, and Shodan
search. It lives in `phosphor/audit/ezrecon.py` as a UI-agnostic core so both
front-ends share one implementation.

No API keys are stored in the source. Keys are prompted for on first use and saved
to `~/.config/phosphor/ezrecon_keys.json` (chmod 600), the same place as the
licence. Decline a prompt and the tool aborts cleanly; nothing secret is committed.

Backend tools EZrecon can use (each optional; it reports what is missing and how to
get it via the "Backend tool / key status" entry):

- **subfinder** - passive subdomain enumeration.  Without it, EZrecon falls back to
  resolving a small builtin wordlist, so subdomain discovery still works, just with
  less coverage.  `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest`
- **nmap** - service / version detection for the port scan.  Without it, EZrecon
  does a plain socket banner grab.  `apt install nmap`
- **whois** - domain registration lookups.  `apt install whois`
- **amass** (optional) - deeper subdomain enumeration.
- Python libraries: **dnspython** (DNS), **requests** (HTTP), **beautifulsoup4**
  (email scraper), **shodan** (host/search).  Install them all with the extra:
  `pip install "phosphor[ezrecon]"`.
- Shodan needs an API key (prompted on first use). Get one from your Shodan account.

**ZX Rubber skin - the ZX Spectrum rainbow.** The zx skin now shows the well-known
Sinclair rainbow flash (red / yellow / green / cyan) as a small badge in the keypad
header, well clear of the screen and the keys. It only appears on the zx theme.

Tests: `tests/test_ezrecon.py` (17) plus the updated `tests/test_client_panels.py`.

*Authorised, defensive / training use only.*

---

## Green/amber fix, PCAP save location + copy-all, Vertali skin, and a proven 3270 engine

**Green / Amber now switch again in the GUI.** When a skin defines a colour
palette, the renderer was using that palette and ignoring the Green/Amber mode, so
the buttons did nothing on any palette skin. Now the skin palette is used only in
"Colour" mode; picking Green or Amber forces the monochrome phosphor tint.

**PCAP: where it saves, and Copy all.** Starting/stopping a capture now reports the
full path (not just the filename), and the expanded PACKETS view shows where
captures are written (the tools dir, overridable with `PHOSPHOR_TOOLS_DIR`). The
"Copy all" button now falls back to saving a `.txt` in the tools dir when no
clipboard tool is present (common on a headless Kali box) and tells you the path,
so it always does something. On Linux, clipboard needs one of `xclip`, `xsel`, or
`wl-copy` for a true copy.

**Vertali skin.** A new "Vertali" skin (Skins list) using the vertali.com colour
scheme: a charcoal chassis with Vertali's signature lime-green accent and a green
phosphor screen, and the lowercase **vertali** wordmark in place of PHOSPHOR. Skins
can now override the wordmark text via a `wordmark` field. Colour scheme and
wordmark only - no logo, font, or other trade dress.

**Proven protocol engines (the big one).** Rather than force everything through the
built-in clean-room parser, PHOSPHOR now has a pluggable engine layer
(`phosphor/session/`). For TN3270 you can select **IBM tnz**
(github.com/IBM/tnz) - a genuine, actively maintained Python 3270 data-stream
engine - which is the robust choice against real z/OS / zPDT where a hand-rolled
parser struggles. The clean-room engine remains the default (zero dependencies).

- CLI: `phosphor HOST --client --engine tnz` (or `--engine native`).
- GUI: Settings -> "TN3270 engine: Native / IBM tnz".
- Install: `pip install "phosphor[tnz]"` (or `pip install tnz ebcdic`).

The tnz backend (`phosphor/session/tnz_backend.py`) drives tnz and rebuilds
PHOSPHOR's ScreenBuffer from tnz's screen planes after every host interaction, so
the existing renderer, FieldEditor, and both clients work unchanged - they only
touch `.screen` / `move_to` / `send_string` / `send_enter`, which the adapter
provides. tnz owns the protocol (negotiation, MDT, field attributes, AID inbound),
which is exactly the part that must be correct on real hosts. Note: the live PCAP
tap and the hack3270 proxy are native-engine features and are skipped on the tnz
backend.

**TN5250.** There is still no mature pure-Python 5250 engine. The native clean-room
5250 client (with the earlier basic-mode / framing fixes) stays the default. For a
production-grade 5250 the right path is the C library **lib5250** (from the tn5250
project) wrapped with CFFI/ctypes, or the **tn5250** binary as a subprocess, or
**tn5250j** as a Java sidecar. The engine factory (`phosphor/session/__init__.py`)
is the seam to slot a `tn5250` backend in without touching the UI.

Tests: `tests/test_session_tnz.py` (32) - screen conversion from tnz planes, AID/key
routing to tnz, the engine factory, and a FieldEditor-over-tnz end-to-end check.

*Authorised, defensive / training use only.*

---

## tnz typing fix + Vertali skin corrected

**Typing on the tnz backend now works.** The tnz engine connected and drew the
screen, but you could not type: PHOSPHOR was trying to drive tnz through its own
field model, and if that model did not line up, keystrokes were dropped. Fixed by
giving the tnz backend its own editor (`TnzEditor`) that routes every keystroke,
tab, arrow and AID straight to tnz's own input handling - tnz owns the field model,
protection, insert mode and local echo, which is the whole point of using it. The
screen re-syncs from tnz after each key. Both clients now pick the right editor
automatically (`make_editor`): tnz sessions use the tnz-native editor, everything
else uses the clean-room FieldEditor.

**Vertali skin corrected.** Reworked to match the actual Vertali logo: colours
sampled straight from it - the lime-green hexagon (#80BC00) and the dark-teal
"VERTALI" wordmark (#006548) - on a white chassis (more white, as on the site).
The lowercase **vertali** wordmark sits in dark teal, and the Vertali hexagon "C"
mark is drawn beside it. Lime is the bright accent; dark teal is the active/links
colour. The glass stays green phosphor on black.

Tests: `tests/test_session_tnz.py` now covers the TnzEditor keystroke/AID routing
(41 assertions total).

*Authorised, defensive / training use only.*

---

## Cursor lands on the right field, Copy all feedback, real Vertali logo

**Cursor now honours the host's Insert-Cursor (and Enter works first time).** The
parser recorded the IC position (e.g. "Option ===>") but the editor ignored it and
sat at top-left, so you typed into the wrong place and had to press Enter twice.
The editor now moves the cursor to the IC field when a screen loads and re-applies
it after every AID. IC handling is shared by the 3270 and 5250 parsers, so the
sign-on cursor lands correctly on both.

**Copy all gives visible feedback.** The copy fallback (save a .txt when there is
no clipboard tool) was working but its confirmation went to the OUTPUT panel, hidden
behind the popup, so it looked dead. It now echoes the result into the open console
("copied N lines" or "saved to <path>"), and the main Copy button uses the same
path. On Linux a real clipboard copy still needs xclip, xsel or wl-copy.

**Vertali logo from the real SVG.** The hexagon "C" mark is now drawn from the
actual Vertali logo path (open lime hexagon, stroke #8ACD00) and the palette matches
the logo exactly: lime #8ACD00 and dark-teal #00785F on a #f4f4f4 white chassis.

**TN5250 status.** The IC fix lands the sign-on cursor correctly, but the native
5250 field / inbound handling is still not complete enough for a clean IBM i logon -
this matches the guidance that a correct 5250 needs the C library lib5250 (wrapped
with CFFI) rather than a hand-rolled parser. The engine seam
(`phosphor/session/`) is ready for a lib5250 / tn5250 backend. To fix the native
path precisely, capture the PUB400 sign-on datastream (Capture PCAP) so the exact
field format can be matched against real bytes.

Tests: `tests/test_ic_cursor.py` (4).

*Authorised, defensive / training use only.*

---

## Extra-Enter fix, EZrecon made interactive, Vertali logo from SVG

**No more extra Enters on real z/OS.** TSO and ISPF often answer one Enter with
several 3270 records (a message write, then the real screen). PHOSPHOR applied only
the first record and discarded the rest, so it was always one screen behind and you
had to press Enter again. The telnet layer now splits the stream at every EOR
boundary and the client applies every complete record in order, draining any
further records the host queued for that response. Records split across TCP
segments are reassembled. Confirmed against the attached zPDT capture.

**EZrecon is now an interactive console, not a menu.** The GUI EZrecon opened the
generic shell console, so typing "subs" ran it as a shell command ("subs: not
found"). It is now its own console: type an operation and target in the command box
and press Run - "dns example.com", "subs vertali.com", "shodan_host 8.8.8.8" - and
it runs the recon operation and streams results, prompting for API keys on first
use. The operations are listed in the panel. This mirrors reckit's command-driven
interaction rather than shelling out.

**Vertali logo drawn from the real SVG, V inside the hexagon.** The mark is the
actual logo path (open lime hexagon, #8ACD00) and the wordmark's first letter now
sits inside the hexagon with the rest flowing out the open side, matching the logo.

Tests: `tests/test_multi_record.py` (5).

Note: the attached PUB400 5250 capture was empty (0 packets), so the 5250 issues
still need a capture with traffic in it - connect first, then Capture PCAP, then
interact.

*Authorised, defensive / training use only.*

---

## Fluid Enter (lag + GIBSON hang fixed), TN5250 removed, no wordmark underline

**The post-Enter delay and the GIBSON hang are gone.** The multi-record fix was
correct, but it waited for an empty read (a full 1.5s socket timeout) before
returning after every Enter - that was the "serious delay", and against a host
that holds the connection open (GIBSON) it looked like a hang. The client now
returns as soon as the screen record arrives and only does a short ~80ms poll for
any straggler records the host queued. Measured: an Enter round-trip dropped from
~1500ms to ~85ms. A WSF Query reply is no longer mistaken for the screen, so the
loop keeps reading for the real panel. Multi-record responses still apply in full.

**TN5250 removed.** The protocol toggle, the `--5250` flag and the 5250 connect
path are gone - PHOSPHOR is a TN3270 client (native or IBM tnz engine). This keeps
the app simple and fast; the 5250 modules remain in the tree but are no longer
wired into the UI or CLI.

**Vertali wordmark:** the underline under "vertali" was removed to match the logo.

Tests: `tests/test_multi_record.py` still green; full suite 261 assertions.

*Authorised, defensive / training use only.*

---

## TSO cursor fix + TN5250 rebuilt and working

**Cursor lands under READY.** On an unformatted TSO screen (line mode, no input
fields) the editor ignored the host's Insert-Cursor and sat at top-left. It now
honours the IC position even when the screen has no formatted fields, so the cursor
lands where the host put it - after READY, at "Option ===>", on the sign-on field.

**TN5250 re-implemented and re-enabled.** The 3270 / 5250 switch above Connect is
back, and the 5250 datastream parser was rebuilt. The core bug was Start-of-Field
handling: a 5250 SF is either output-only (just an attribute byte) or an input
field (Field Format Word, optional Field Control Word pairs, attribute, then a
2-byte length). The old parser always read a FFW, which ate the first characters of
every label and left the real input fields undetectable - which is why the PUB400
sign-on could not be driven. Now:

- output-only fields vs input fields are distinguished by peeking the byte after SF
  (an attribute byte has its top three bits = 001, 0x20-0x3F);
- input-field length is consumed correctly;
- protection is derived properly (no FFW, or the BYPASS bit, means protected);
- field colour comes from the 5250 attribute byte;
- the IC cursor lands on the right field and Tab moves between fields.

The 5250 client uses the same FieldEditor as 3270, so typing, Tab, Enter and the
PF/PA keys all work through the shared path; the inbound frame is cursor + AID +
each modified field. Approach informed by the public web3270 / lib5250 references
and implemented clean-room.

Tests: `tests/test_tn5250_fields.py` (12); full suite 273 assertions.

Honest note: validated against constructed PUB400-style sign-on streams and the
suite, not a live IBM i from here. A capture with traffic in it would let me confirm
the last mile against real bytes.

*Authorised, defensive / training use only.*

---

## Turn N+1 — protocol field-model fixes (5250 labels + explicit length, IND$FILE record framing, unformatted TSO typing)

Continuing the open issues from the handoff (A: TN5250 pub400 tab/enter, B: IND$FILE
empty downloads, C: zPDT TSO 6-character typing limit). The uploaded package this turn
was source + handoff only, so the work was validated against the handoff's decoded
ground truth (reconstructed streams) and the test suite, not the raw pcaps.

**A. TN5250 field model — labels protected + explicit lengths honoured.**
The input-field path already used the explicit SF length correctly (username at
(5,25) len 10, password at (6,25) len 128, IC on username, Tab to password all
verified against the decoded pub400 sign-on). The remaining defect was that the
explicit 5250 field table held ONLY the input fields, so the protected labels
vanished from `screen.fields()`. Now the parser records EVERY field (protected
label and input) in the table: input fields keep their exact host-given SF length,
and output/label fields get their length computed post-parse as the distance to the
next field-start (the classic 3270 extent). Labels are protected again, input fields
stay bounded, and Tab moves to the next field instead of wrapping inside the current
one. Two 5250 tests that were dead code (defined after the file's own `__main__`
runner, so never executed) now run, and one of them - which genuinely failed against
the real parser - was rebuilt on a well-formed SF stream. Added
`tests/test_tn5250_pub400.py` locking the decoded QINTER sign-on end to end.

**B. IND$FILE download — one record per read, no merged or lost frames.**
`recv_record` concatenated every EOR-terminated record that arrived in a single TCP
read into one blob; `process_frame` then parsed only the first structured field, so
every DATA frame after the first was silently dropped - empty or truncated files.
It now returns exactly one record per call, queues any further records from the same
read, and carries a record split across two reads. The IND$FILE driver also only
feeds genuine `0xD0` structured fields to the terminal state machine, skipping screen
writes, Query replies and negotiation echoes instead of aborting on them. Added
`tests/test_indfile_live.py` driving OPEN/DATA/DATA/CLOSE over a scripted fake socket
with records both packed into one read and split across two.

**C. zPDT TSO typing — unformatted line-mode command entry.**
Reproduced two mechanisms: an unformatted READY screen (no field attributes at all)
left the command line untypable because `fields()` was empty, and a field bounded a
few columns later clips typing at that boundary. The general native bug is the first:
native TSO line mode (READY, `IKJ56700A ENTER USERID`) is an unformatted buffer where
the whole area from the host cursor is writable. The FieldEditor now synthesises a
single unprotected field from the Insert-Cursor position to the end of the buffer when
the screen is unformatted, and `type_char`/`backspace`/`_field_at` use linear buffer
addressing so a command can run across the row edge. A full `ADDUSER`/`LISTGRP` line
now types and flushes into the inbound frame. If the real zPDT screen turns out to be
formatted with a genuinely short field rather than unformatted, that is a host layout
question the referenced capture (`capture-192_168_0_248-*.pcap`, not in this upload)
would settle.

Tests: `tests/test_tn5250_pub400.py` and `tests/test_indfile_live.py` added;
`tests/test_tn5250.py` now runs its two previously-dead tests. Full suite green
(all files except `test_license.py`, which needs pytest).

Honest note: A is validated against the decoded pub400 ground truth, B against the
live client path with a scripted host, C against constructed TSO screens. The raw
pcaps (`tn5250.pcap`, `capture-192_168_0_248-*.pcap`) were not in this upload - re-add
them and I will replay the exact bytes to confirm the last mile.

*Authorised, defensive / training use only.*

---

## 2026-07-13 — zPDT native 3270 typing and cursor, root-caused from a real capture

A zPDT capture (`tn3270.pcap`, host 192.168.0.248) settled the earlier open question
and it was not what the previous entry guessed. The TSO READY screen is not
unformatted. It is a formatted buffer. Record 23 in the capture writes it as
`EW SBA(23,79) SF(0x40) SBA(0,0) SF(0xc8) SBA(0,1) 'READY ' SF(0x40) IC SBA(1,0) IC`.
That is a six-column label field holding `READY ` at (0,1) through (0,6), then a single
unprotected input field that starts at (0,8) and runs the rest of the screen, with the
host Insert-Cursor set inside it.

The real fault was field membership. A 3270 field runs from its attribute cell to the
next attribute cell and normally spans several rows. The command field here is one field
1911 cells long covering rows 1 to 24. The editor recorded a field by the row and column
of its body start but then matched the cursor against a field with `f.row == row`, so a
multi-row field was only ever found on its first row. The cursor could not be recognised
inside the big command field, so `sync_cursor` could not honour the host Insert-Cursor and
fell back to the first field on the screen, which is the small label at top-left. That is
the "cursor stuck at top-left" report. Typing then went into the label field and was
clipped to its width. On the READY screen that width is six, so `LISTCAT` arrived as a
six-character, transposed `LSITCT` addressed to (0,1). On the logon panel the first field
is the twenty-four column `IKJ56700A ENTER USERID -` label, so a seven-character userid
slipped through and logon appeared to work, which is why the fault looked intermittent.

Fix. `_field_at` now matches every field by its linear buffer span, with wrap handling,
so a field that crosses rows is found on any of its rows. `sync_cursor` therefore honours
the Insert-Cursor into a multi-row input field, and the no-cursor fallback is now the
deterministic top-left-most input field. The attribute decode was not the problem and was
not changed. In this ADCD build the line-mode output fields (`0xc8`) are genuinely
unprotected in the datastream, and protected labels (`0xe8`) are still rejected for typing.

Result against the captured bytes. The cursor lands in the command field, `LISTCAT` and a
full `LISTCAT ENTRIES('SYS1.PARMLIB') ALL` type in without clipping and record after
`READY ` rather than over it, the seven-character logon userid still works, and a
protected label still refuses input. New regression `tests/test_tn3270_tso_ready.py`,
seventeen assertions built from the exact record 23 bytes, all green. Full suite green
across twenty-six files, `test_license.py` still needs pytest.

TN5250 double-ENTER. The uploaded capture is 3270 only, so it carries no evidence for the
5250 behaviour. The first ENTER is not being swallowed on the client side, `keyboard_locked`
does not gate the send, so this is a host read handshake question that a 3270 capture cannot
answer. Rather than change the working 5250 wire on a guess, this needs a short `tn5250.pcap`
of one ENTER that misbehaves. With that I can confirm whether the first AID record is sent,
its GDS opcode and flags, and whether the host re-invites, then fix it precisely.

*Authorised, defensive / training use only.*

---

## 2026-07-14 — TN5250 single-Enter fix (from tn5250.pcap), and STRIP3270 rename

### TN5250 double-ENTER, root-caused from a real pub400 capture
A TN5250 capture (`tn5250.pcap`, client 172.25.242.186 to pub400 185.113.5.134,
client side only) settled this. Every option or number entry needed Enter pressed
twice; function keys worked on the first press. Decoding the client records showed
the outbound side is byte-correct. Each record is a well-formed GDS frame
(`00 LL 12 a0 00 00 04 00 00 03` header, opcode 0x03), the cursor address, the AID,
and the modified fields as SBA plus EBCDIC. The sign-on record uses that exact
format and signs on in one press, so the format is accepted by the host. The Enter
records that carried a field, and even bare Enter continue records, showed up twice
or were followed by a second bare Enter. Function keys (PF3, AID 0x33) never doubled.

That pattern points at the read side, not the wire. An IBM i host answers an Enter
that reads input fields with, commonly, two records back to back: a message or
acknowledgement record, then the new screen. The old 5250 read loop stopped at the
first record, joined the rest into one blob, and applied only the message. The panel
did not change, so the operator pressed Enter again and the queued screen record was
picked up on the second press. Function keys drew a single-record reply, so they
always worked first time.

Fix. The 5250 client now uses the same robust read path the 3270 client already had.
`_apply_record` applies one complete EOR-terminated GDS record on its own (detecting
enhanced mode and stripping that record's header). `_consume` folds telnet segments
through the carried partial and applies every complete record, carrying any trailing
partial to the next read. `_read_until_eor` reads until a record updates the screen,
then `_drain_fast` briefly polls (0.08s) for the straggler screen record before
returning, so one Enter shows the resulting panel with no per-Enter lag. The outbound
side was left untouched because the capture proves it is correct. New regression
`tests/test_tn5250_double_enter.py` drives a scripted host that returns the reply as
two separate reads and asserts one Enter renders the final panel, that a
single-record function-key reply still works, that both records arriving together
still resolve to the screen, and that a resolved Enter clears the pending field so no
duplicate re-send. Full suite green across 27 files.

### STRIP3270 rename
The hack3270 button is now labelled STRIP3270, along with its popup title, its
settings and help headings, the settings tooltip, and the inject console lines. The
references that name the real external tool are left as hack3270 on purpose: the
install hint, the "hack3270 binary detected" status, the MITM proxy launch text, the
`PHOSPHOR_HACK3270_CMD` environment variable, and the tool-status key. Internal
identifiers are unchanged too (the `a_hack3270` button id, the `h3_*` and
`hack3270_open` state fields, the `hack3270_proxy` module and `Hack3270Proxy` class),
so nothing in the toolchain or proxy path moved.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (b) — zPDT READY cursor no longer jumps up a line when typing

The attached `tn3270-session.pcap` arrived empty (a 24-byte pcap header with zero
packets, so the capture recorded no traffic), but the fault is fully reproducible
from the earlier record-23 READY bytes and does not need it.

At the READY prompt the host paints "READY " on the top line and sets the cursor on
the line below it with its final Insert-Cursor
(`... SF(0x40) IC SBA(1,0) IC` - the last IC wins, at (1,0)).  The command field runs
from just after "READY " on the top line all the way down, so the line below is
inside it.  A real terminal types where the host left the cursor, on that lower line.
PHOSPHOR was snapping the first keystroke back to the field start, up on the "READY "
line, so the cursor jumped up a line the moment you started typing.

The snap-to-field-start step exists so that arrowing or clicking into a blank field
and typing left-justifies the value (a userid or password sent with leading blanks is
rejected).  The fix keeps that only for operator-driven cursor moves.  A cursor the
host placed with Insert-Cursor is now authoritative: the editor tracks whether the
cursor is host-placed (set when `sync_cursor` honours the IC, cleared on any arrow,
click, tab or keystroke) and does not snap it.  So on READY the command types on the
line below "READY ", exactly where the host put the cursor, and on formatted panels
(TSO/E LOGON places its IC right on the Userid field) typing still lands at the field
start with no leading blanks.  The colour grid also now overlays typed text by true
buffer address, so a command typed on the lower line renders there instead of being
clipped at column 80.

Tests: `tests/test_tn3270_tso_ready.py` gains cursor-stays-below-READY and
manual-move-still-left-justifies cases and updates the userid case to assert the
host-cursor behaviour (24 assertions, all green).  Full suite green across 27 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (c) — new CRT app icon, wired for runtime and PyInstaller

The green-screen CRT icon is now the PHOSPHOR icon everywhere. The supplied artwork is
a rounded-square dark chassis whose corners sit on black; a matching rounded mask
(radius ~20.7% of the side, measured from the art) turns those corners transparent so
it reads cleanly on any background.

`packaging/make_icons.py` regenerates every asset from one master
(`assets_src/phosphor_icon_master.png`): the 1024 `phosphor.png`, the Linux menu
`phosphor-256.png`, a multi-resolution Windows `phosphor.ico` (16 through 256), the
macOS `.iconset` and a ready-built `phosphor.icns`, and the 256px runtime window icon
`phosphor/app/assets/phosphor_icon.png`. `packaging/build.py` runs it before
PyInstaller so the packaged icon can never drift from the master.

Wiring:
- Running app: `pygame.display.set_icon` loads the bundled runtime icon right after
  the window is created, so the window, taskbar and dock show the CRT icon live.
- Windows: the spec's `ICON_WIN` and the Inno Setup `SetupIconFile` both point at
  `phosphor.ico`.
- macOS: the spec's `ICON_MAC` and the `.app` BUNDLE use `phosphor.icns` (also built
  from the iconset by `iconutil` in `build_dmg.sh`).
- Linux: `install.sh` installs `phosphor-256.png` into the hicolor theme for the
  `.desktop` entry.

The runtime icon ships inside `phosphor/app/assets`, which the spec already bundles, so
it resolves both in a dev checkout and inside a PyInstaller build. Suite green across
27 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (d) — TLS / AT-TLS connections, Injector button, EZrecon deps

### TLS / AT-TLS (with an optional no-verify testing mode)
New `phosphor/protocols/tls.py` gives both clients an implicit TLS tunnel - the socket
is wrapped in TLS as soon as TCP connects, before any telnet negotiation. That is what
x3270 calls the `L:` prefix and it is exactly what a z/OS AT-TLS policy looks like from
the client (the stack does TLS transparently on a policy port), so the same code path
covers "SSL", "TLS" and "AT-TLS". Port 992 (telnets) auto-enables it, matching x3270.

For security testing, verification can be turned off (x3270's `Y:` prefix /
`-noverifycert`): PHOSPHOR then completes the handshake against a self-signed, expired,
wrong-name or otherwise untrusted certificate, and relaxes the minimum TLS version and
cipher security level so old / misconfigured mainframe stacks (TLS 1.0, legacy ciphers)
can still be reached. This mode is loud - a note fires on connect and a warning is set
on the session - and is never a silent default.

Driving it: state fields (`tls`, `tls_verify`, `tls_accept_hostname`) plus x3270-style
prefixes straight in the host box - `L:host` (tunnel), `Y:host` (no verify, implies
tunnel), `L:Y:host`, `host=certname` (name to match the cert), and the `tn3270s://` /
`tn5250s://` secure URI schemes. Client auth (client cert + key) and an extra CA bundle
are supported too. `TLSInfo` records the negotiated version, cipher, peer CN and the
verified/unverified state for the status line. New `tests/test_tls.py` (21 assertions)
runs a real self-signed server: no-verify connects, verify rejects, port 992 tunnels,
options wire through, prefixes parse. Note: implicit tunnels only; the negotiated
TELNET START-TLS option is a documented follow-up.

### Injector button
"Injector" now sits next to EZrecon in the tools panel and opens the field injector
(the "Inject Into Fields" controls in the STRIP3270 toolset).

### EZrecon dependencies
The python backends (dnspython, requests, beautifulsoup4, shodan) are now installed by
`packaging/build.py` and listed in the spec's hiddenimports, so they ship inside the
PyInstaller build. The native CLI tools (nmap, whois, subfinder, amass) cannot be
bundled cleanly, so `packaging/install_ezrecon_deps.sh` installs them: nmap + whois via
the OS package manager, subfinder + amass from a prebuilt GitHub release (falling back
to `go install`). The Linux `install.sh` points at it (or runs it with `--with-recon`).

*Authorised, defensive / training use only.*

---

## 2026-07-14 (e) — iNJEctor is now an NJE recon tool; live GIBSON DB2 client

### iNJEctor -> NJE (Network Job Entry) security testing
The iNJEctor button (next to EZrecon) now drives real NJE reconnaissance instead of
field injection. NJE is how mainframes trust each other by node name, usually with no
encryption and often no / a weak node password - a classic lateral-movement surface
(Soldier of Fortran / bigendiansmalls, DEF CON 23). New `phosphor/toolchain/nje.py` is a
clean-room client (no GPL njelib, no bitstring) for the two highest-value, read-only
checks:

  * OPEN probe - send an OPEN control record claiming to be RHOST, targeting OHOST. The
    1-byte reason code enumerates without signing on: ACK (0x00) = OHOST exists and
    trusts RHOST (spoofable for job submission); 0x04 = OHOST exists but RHOST not
    trusted (still confirms the node); 0x01 = unknown node.
  * sign-on password test - after ACK, complete SOH/ENQ -> DLE/ACK and send the
    I-record with the node password. 'J' = accepted, 'B' = rejected. An empty password
    that returns 'J' is a no-password NJE node - a serious finding.

Console grammar: `probe <OHOST> [RHOST]`, `enum [RHOST]`, `signon <OHOST> <RHOST> [PW]`,
`tls on|off` (175 clear / 2252 TLS). Job submission (the RCE / RACF-backdoor step) is a
separate, explicit call (`bundled_jcl()`), never automatic. Records were cross-validated
against GIBSON's own `nje_protocol.py`: GIBSON parses PHOSPHOR's OPEN and I-record and
PHOSPHOR parses GIBSON's replies. `tests/test_nje.py`, 13 assertions.

### Live GIBSON DB2 (WebSocket) client
The SQL / DB2 button now offers a live path in addition to the DRDA command-builder.
New `phosphor/protocols/db2ws.py` is a dependency-free RFC 6455 WebSocket client (no
async `websockets` library needed) that speaks GIBSON's DB2 shell on port 50001 - the
protocol from the user's db2-connect.py: connect, `LOGIN <user> <pass>` (checked against
GIBSON's RACF), then SQL. In the SQL console: `gibson [host] [port]` opens it, then
`LOGIN ...` and SQL statements run live; the password is never echoed. Tested against a
real `websockets` server (the same library GIBSON uses): handshake, login success /
failure, SQL round-trip, large frames, ping/pong. `tests/test_db2ws.py`, 7 assertions.

Real DB2 for z/OS over DRDA/DDF (446) stays on the driver path (ibm_db / db2 CLP) for
now; `db2ws.drda_setup_notes()` documents the handshake and setup, and GIBSON's
`gibson/net/drda.py` is the reference for a future native DRDA client.

Suite green across 30 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (f) — RACF PassTicket generation (forging), and a STRIP3270 integrity check

### PassTicket generation
The PassTicket tool was a passive classifier; it now also *forges* PassTickets. Given
the secured-signon application key (RACF PTKTDATA / SESSKEY, 16 hex = an 8-byte DES key),
an applid and a userid, `passticket.generate_passticket()` produces the 8-character,
single-use, time-bound credential RACF accepts in place of that user's password for that
application - the real privilege-escalation / impersonation capability. It is a faithful
port of the published RACF algorithm (IBM SKALGO/ALGOR; VanVleet; Soldier of Fortran's
gen_passticket) and reuses PHOSPHOR's existing DES provider, so no new dependency.

Validated byte-for-byte against GIBSON's own generator at a fixed timestamp; those
outputs are baked into `tests/test_passticket_gen.py` as golden vectors (11 assertions).
`passticket_window()` forges the current second +/-N to absorb host-clock skew (tickets
are valid +/-10 min of host GMT). The PassTicket button is now an interactive console:
`scan` (classify captured credentials, as before), `gen <user> <applid> <keyhex>`, and
`genwin <user> <applid> <keyhex>`.

Together with the NJE tool this gives the two classic mainframe lateral-movement
primitives: NJE to reach and submit work on a trusted node, PassTickets to authenticate
to its applications (CICS/TSO/DB2/IMS) without the password once the app key is recovered.

### STRIP3270 integrity (verification)
Confirmed that repurposing the iNJEctor button to NJE did NOT touch STRIP3270 or its
field injector: `a_hack3270` still opens the STRIP3270 popup, all `h3_inject_*` handlers
and the "Inject now" control are unchanged, and `a_injector` now only calls the NJE
console (never `hack3270_open`). test_injections (15) and test_toolchain (16) stay green.

Suite green across 31 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (g) — native DRDA client (real DB2 for z/OS: fingerprint + credential test)

The SQL / DB2 button now reaches *real* DB2 for z/OS over DRDA without any driver.
New `phosphor/protocols/drda/client.py` performs the DDF connect handshake -
EXCSAT -> EXCSATRD, ACCSEC -> ACCSECRD, SECCHK -> SECCHKRM, and optionally ACCRDB -
giving two security-testing capabilities:

  * fingerprint - product class, release level, location and external name from the
    server's EXCSATRD (what nmap's drda-info reports).
  * credential test / spray - SECCHK returns a security-check code (0x00 accepted,
    0x0F password invalid, 0x10 userid invalid, 0x12 revoked, ...), so DB2 DDF logins
    can be validated or sprayed over the wire.

In the SQL console:  `drda <host> [port] [userid] [password] [rdb]`  fingerprints and,
if a userid is given, tests the credentials and (with an RDB name) opens the database.
The DSS/DDM framing was validated end to end against GIBSON's *actual* DRDA server
(`gibson/net/drda.py respond()`): fingerprint, accept, reject and spray. New
`tests/test_drda.py`, 11 assertions.

Running SQL statements and returning result sets (EXCSQLIMM / OPNQRY + FD:OCA) is a much
larger DDM surface and stays on the ibm_db / db2 CLP driver path for now; the native
client covers connect, fingerprint and authentication. `db2ws.drda_setup_notes()`
documents the zPDT/DDF setup (DDF started, LISTENER on 446, location name, RACF CONNECT).

The SQL button now offers three routes: live GIBSON WebSocket shell (`gibson ...`),
native DRDA fingerprint/cred-test (`drda ...`), and the ibm_db/CLP builder for SQL.

Suite green across 32 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (h) — iNJEctor sends operator commands (NMR) over NJE

iNJEctor now goes past reconnaissance: after sign-on it sends Nodal Message Records -
JES2 operator commands that run on the target node and stream their reply back. This is
the tool's headline capability (send $D NODE to map the network, $D NJEDEF, $D JOBQ,
etc.). In the iNJEctor console: `signon <OHOST> <RHOST> [PW]` establishes the session,
then `cmd $D NODE` runs the command against it.

The record framing is the intricate part - SCB string-control-byte compression, TTB/TTR
lengths, DLE/STX, BCB sequence and the FCS - and it is byte-for-byte identical to Soldier
of Fortran's njelib (validated by driving njelib as an oracle across several commands; the
exact bytes are baked into `tests/test_nje_nmr.py` as golden vectors, 14 assertions).

Honest scope: the command *reply* round-trip needs a live JES2 NJE node. GIBSON's NJE
service stops after sign-on (it models the OPEN/sign-on attack surface, not command
processing), so against GIBSON this confirms send + sign-on; the send bytes themselves are
confirmed correct against njelib. Full job submission (/*XEQ JCL) remains a later step;
the bundled attack JCL is in `nje.bundled_jcl()`.

The NJE toolset now spans the chain: probe/enum (node discovery + trust), signon (node
password / no-password), and cmd (operator command execution).

Suite green across 33 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (i) — NJE job submission (/*XEQ), and a GIBSON NJE update

### iNJEctor job submission - the lateral-movement / RCE step
Over a trusted NJE session iNJEctor now submits a job that runs on the *target* node. The
NJE Job Header (NJH) carries NJHTOUSR/NJHTOGRP - the identity the job runs under - so a
trusted (or spoofed) node can submit a job that executes as IBMUSER, OMVSKERN or any
SPECIAL user on the target (the classic NJE RACF-backdoor / privilege escalation). Console:
after `signon`, `submit <run-as-user> <id|racf_backdoor|file>`. Bundled attack JCL (id,
racf_backdoor) is in `nje.bundled_jcl()`; a file path works too.

The whole build path - NJH header, SYSIN records, SCB string-control-byte compression,
TTB/TTR framing - is a byte-for-byte port of Soldier of Fortran's njelib, validated by
driving njelib as an oracle (golden vectors in `tests/test_nje_job.py`, 9 assertions,
including the run-as-arbitrary-user check). SCB compression now has a decompressor too, with
a random round-trip test. Also fixed: `submit_job` and the session now use a single
connection (was double-connecting).

### GIBSON updated to receive jobs (not just sign-on)
The latest GIBSON's NJE service was byte-identical to the previous one and still stopped at
sign-on. I updated it so it now RECEIVES and processes submitted jobs: `gibson/net/
nje_protocol.py` gains `scb_decompress` + `parse_sysin_stream` (recover the JCL and the
run-as identity), and `gibson/services/nje_server.py` now reads the SYSIN stream after
sign-on, logs an "NJE JOB SUBMIT" security event with the run-as user, routes the JCL into
JES2 (if available) and acknowledges. Delivered as GIBSON-NJE-JOBSUBMIT-UPDATE.zip.

End-to-end verified: PHOSPHOR spoofs a trusted node, signs on to GIBSON, submits a job to
run as OMVSKERN; GIBSON receives it, extracts run-as OMVSKERN and the ADDUSER backdoor JCL,
queues it and replies "JOB ... RECEIVED VIA NJE, RUN-AS OMVSKERN - QUEUED".

Suite green across 34 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (j) — local shell, STARTTLS, terminal models, DRDA SQL

Four items done this pass (each tested):

### 1. Scrollable local shell (the Shell button)
The Shell button now opens a local command prompt with scrollable history instead of
only a reverse-shell listener. Type a command, it runs on this machine (via subprocess in
the tracked working directory) and the output streams into the 2000-line scrollback you
page with the wheel / PgUp-PgDn. Built-ins: `cd` (persists between commands), `clear`, and
`listen [host:port]` (the reverse-shell listener is still here, and once a shell connects
your commands go to the remote). `tests/test_localshell.py`, 9 assertions.

### 2. Negotiated TELNET START-TLS (RFC 2946)
Complements the implicit TLS tunnel: when a host offers DO START-TLS and STARTTLS is
enabled (`tls_starttls`), PHOSPHOR answers WILL, exchanges SB FOLLOWS, and wraps the live
socket in TLS mid-stream, then finishes TN3270 negotiation over the encrypted channel.
No-verify and legacy-cipher options apply as with implicit TLS. `tests/test_starttls.py`,
7 assertions (negotiator logic + a full client wrapping TLS against a real server).

### 3. 3270 terminal-model selection (x3270 parity)
`term_model` selects model 2/3/4/5 - IBM-3278-2/3/4/5 at 24x80 / 32x80 / 43x80 / 27x132 -
setting both the screen geometry and the terminal-type string the host reads in the TTYPE
sub-negotiation. `client_for_model()` builds the right client. `tests/test_models.py`, 9
assertions. (Remaining x3270 parity, larger: TN3270E LU-name CONNECT, NVT/line mode, and an
s3270-style scripting interface.)

### 4. Immediate SQL over native DRDA (EXCSQLIMM)
The native DRDA client now runs SQL without a driver: after auth + ACCRDB it sends
EXCSQLIMM + an SQLSTT object and parses the SQLCARD (SQLCODE + rows). Console:
`drda <host> [port] [user] [pass] [rdb] [SQL...]` - add a statement to run it. GIBSON's DRDA
server was updated to match (extract_sqlstt + respond_sql run the statement through the DB2
sim and return an SQLCARD). Validated end-to-end against the updated GIBSON:
`tests/test_drda.py` now 14 assertions (fingerprint, cred test, spray, EXCSQLIMM rows,
bad-creds-block-SQL). Real-host result sets (FD:OCA) still use ibm_db.

Suite green across 37 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (l) — SQL/DB2 is now a live client; command-quoting + overrun fixed

### Live DB2 client connection area
The SQL / DB2 button is now a real connect-login-run client. `connect <host> [port]
[user] [pass] [rdb]` opens a persistent DRDA session (new `DrdaSession`), you `LOGIN
<userid> <password>` if you didn't pass creds, and then every line is a SQL statement run
over the one open connection - just like a db2 shell. `gibson [host] [port]` still gives
the GIBSON WebSocket shell. Verified interactively against GIBSON: open -> fingerprint ->
login -> several SELECTs over one connection, SQLID reflecting the logged-in user.

### Fixed: ibm_db command quoting (the SyntaxError in the screenshot)
The built `ibm_db` one-liner nested double quotes inside `python3 -c "..."`, which closed
the outer quote early and truncated the command ("'(' was never closed"). It is now
base64-encoded (`python3 -c 'import base64;exec(base64.b64decode("...")...)'`), so quotes
in the connection string, SQL or password can't break it.

### Fixed: screen overrun
Long console lines (connection strings, wide result rows) now wrap instead of running off
the right edge, via a `_console_wrapped` helper used by the SQL client and the shell echo.

### GIBSON: per-connection DRDA session
`gibson/net/drda.py respond()` now takes a per-connection `session` dict; the SECCHK
userid is remembered so EXCSQLIMM statements run with the correct SQLID, and the
`Db2DasHandler` keeps that session across the whole connection. So an interactive DRDA
login+SQL session against GIBSON reports the logged-in user, not a default.

`tests/test_drda.py` now 21 assertions (adds the interactive session + the command-quoting
regression). Suite green across 37 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (m) — native DRDA result sets (OPNQRY -> QRYDSC + QRYDTA)

The native DRDA client now retrieves SELECT result sets without a driver. A SELECT runs
via PRPSQLSTT + OPNQRY; the client reads the QRYDSC (an FD:OCA-style column descriptor)
and QRYDTA (the rows), decodes the FD:OCA for the common column types (CHAR/VARCHAR/
SMALLINT/INTEGER, incl. nulls and negative ints), and returns typed row dicts.
`DrdaSession.query(sql)` gives (columns, rows); `execute()` routes SELECTs here and renders
an aligned result table in the SQL console.

GIBSON was updated to emit real result sets over DRDA: `gibson/net/drda.py` now answers
OPNQRY with OPNQRYRM + QRYDSC + QRYDTA + ENDQRYRM (build_qrydsc/build_qrydta/respond_query),
inferring column types from the DB2 simulator's rows. So a native DRDA SELECT against
GIBSON returns structured rows (verified: SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES ->
63 typed rows) - not just the SQLCARD text blob.

Honest scope: the QRYDSC/QRYDTA format is spec-shaped and validated end-to-end PHOSPHOR
<-> GIBSON, but a real z/OS DB2 carries more FD:OCA detail (DECIMAL, DATE/TIME, packed
decimal, mixed CCSID). Those need confirming on the metal; the ibm_db driver path stays as
the guaranteed real-host route for full result sets. `tests/test_drda.py` now 30 assertions
(adds the native result set + an FD:OCA codec round-trip).

Suite green across 37 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (n) — live-host smoke-test harness

The metal itself I can't reach, so here's the turnkey way to confirm the not-yet-live-
validated paths on your zPDT/z/OS host. `tools/smoketest.py` drives PHOSPHOR's own modules
against a real host and prints PASS / FAIL / UNCONF / SKIP per feature: TN3270 negotiation
+ model, TLS / AT-TLS / STARTTLS wrapping, TN5250 single-ENTER, NJE OPEN-probe + signon +
the NMR reply round-trip, DRDA fingerprint + credential check + native result set (and it
flags any result column whose FD:OCA type - DECIMAL/DATE/packed - PHOSPHOR doesn't yet
confirm), and offline PassTicket generation. Read-only by default; the state-changing steps
(NJE job submission, spray) need `--i-have-authorization`.

`tools/capture.sh` grabs a scoped pcap of a failing exchange, and `tools/SMOKETEST.md` is
the runbook (what to run, expected result, what to send back). The harness itself is
validated against GIBSON's servers (DRDA fingerprint/creds/63-row result set + NJE
probe/signon all PASS; the NMR reply correctly shows UNCONF with capture guidance).
`tests/test_smoketest.py` guards it against rot (10 assertions).

Suite green across 38 files.

*Authorised, defensive / training use only.*

---

## 2026-07-14 (o) — batch mode for the smoke tests and the unit suite

Run everything at once instead of one at a time:

- Smoke tests: `python3 tools/smoketest.py --config tools/smoke.conf` runs the whole
  battery from one INI file, each service on its own host/port, with a single consolidated
  PASS/FAIL/UNCONF summary. `tools/smoke.conf.example` is a template. `--all` runs every
  suite against `--host` on default ports for a quick single-host sweep. Destructive steps
  still need `--i-have-authorization`.
- Dev unit suite: `bash run-tests.sh` runs every tests/test_*.py in one go with a summary
  (uses pytest if present, else the standalone runners; `run-tests.sh <pattern>` filters).

Batch mode validated against GIBSON's servers (one command -> 7 PASS + 1 UNCONF across NJE,
DRDA, PassTicket). `tests/test_smoketest.py` now 15 assertions (adds config/batch parsing).
Suite green across 38 files.

*Authorised, defensive / training use only.*

---

## 2026-07-15 — AT-TLS cipher profiles, two corporate skins

**TLS cipher profiles for mainframe / IBM i (`phosphor/protocols/tls.py`).** `wrap_socket`
gains `cipher_profile` ("modern" default, "compat"/"mainframe"/"ibmi", "legacy") and an
explicit `ciphers=` override, threaded through the TN3270 and TN5250 `connect()` (implicit
TLS and STARTTLS). "modern" keeps the strong secure default; "compat" lowers to
`DEFAULT:@SECLEVEL=1` with a TLS 1.0 floor so a *verified* AT-TLS session can reach a
legacy-but-cert-valid z/OS or IBM i host that the modern default refuses; "legacy" is
`ALL:@SECLEVEL=0` for untrusted test hosts. No-verify still auto-relaxes. `MAINFRAME_CIPHERS`
documents the exact z/OS/IBM i suite set. Proven: against a TLS-1.0-only cert-valid host the
modern profile refuses while mainframe connects with the cert still verified. `TLSInfo.profile`
records which was used. `tests/test_tls_ciphers.py` (6 assertions).

  Deployment note: modern OpenSSL 3.x ships without 3DES/RC4/DES in the default provider, so
  the very oldest hosts (3DES-only) also need the OpenSSL *legacy provider* enabled in the
  frozen build — a cipher string can't summon a suite the library wasn't built with.

**Two paid skins (`phosphor/app/themes.py`):** `corporate` (navy chassis, brushed-silver keys,
white-on-blue screen) and `graphite` (charcoal, warm-white legends, blue accent). Both
`paid=True`, added to `ORDER`; gated automatically (not in `FREE_SKINS`). `ALL_PAID` in
`vendor/license_issuer.py` refreshed to include tron, zx, corporate, graphite.

Suite green: 40 files.

---

## 2026-07-16 — brand skins (HVCK, Covert Access Team) + Tier-2 macro engine

**Skins (`phosphor/app/themes.py`):**
- `hvck` — HVCK magazine brand skin: heavy red chassis, white keycaps, neon-green legends
  and screen text, "HVCK" wordmark. Colour scheme + wordmark only (no logo file).
- `covertaccess` — Covert Access Team brand skin (replaces the old `corporate`): matte-black
  tactical chassis, brand-red accents, white legends, red "COVERT ACCESS TEAM" wordmark.
- `graphite` retained. `ORDER` and `ALL_PAID` (vendor/license_issuer.py) updated; `corporate`
  removed. All three are paid/gated.

**Tier-2 macro engine (`phosphor/macro/`):** scriptable TN3270/TN5250 automation.
- `MacroEngine` verbs: connect, string, move, key (ENTER/CLEAR/PF1-24/PA1-3), enter, wait,
  wait_for (polls + pumps host data), expect, snapshot, save_screen, log, disconnect. Every
  step recorded in an audit transcript.
- Text macro format (.pmac) + parser/runner (`python -m phosphor.macro <file>`); Python API
  (`from phosphor.macro import MacroEngine`); recorder (`transcript_to_script`) turns a run
  into a replayable script (Tier-1 record/replay for free).
- Examples in `examples/macros/`. `tests/test_macro.py` (16 assertions) drives a full fake
  logon through every verb, timeout, expect-failure, script runner, and recorder round-trip.

*Authorised, defensive use only.* Suite green: 41 files.

---

## 2026-07-18 — brand logos on skins, wordmark/underline cleanup, Tier-3 BOT

**Skin UI (`phosphor/app/ui.py`, `themes.py`):**
- Added a per-skin brand `logo` (new `Theme.logo` field -> `SKIN_LOGO`), pasted into the
  keypad's lower space under the PF buttons. Covert Access Team gets the cat mark
  (`logo_covertaccess.png`); HVCK gets the metal HVCK+dragon (`logo_hvck.png`), both keyed
  to transparent so they sit cleanly on the black / red keypads.
- Wordmark now **auto-fits** the sidebar width, so long brand names like
  "COVERT ACCESS TEAM" shrink to fit (14px) instead of clipping.
- Removed the accent **underline** beneath the wordmark on **all** skins.

**Tier-3 BOT (`phosphor/bot/`):** unattended, scheduled macro runs on top of Tier 2.
- `Bot` + `Job` + `RunResult`: schedule a macro once or `every` N seconds; retry with
  backoff and **reconnect-on-drop** (a fresh session per attempt); structured **JSONL run
  log** + in-memory history; `on_success` / `on_failure` hooks for alerting (email/webhook/
  Slack - you supply the fn). Jobs are a `.pmac` file path or a `callable(engine)`.
- CLI: `python -m phosphor.bot <script.pmac> [--every S] [--retries N] [--log FILE] [--runs N]`.
- Example in `examples/bot/`. `tests/test_bot.py` (13 assertions): one-shot vs scheduled,
  retry-then-success, reconnect (fresh client per attempt), failure + hooks, JSONL logging,
  and a .pmac-file job.

*Authorised, defensive use only.* Suite green: 42 files.

---

## 2026-07-18 (2) — HVCK Magazine skin tweak + bot alert transports

**HVCK skin (`themes.py`):**
- Renamed to **"HVCK Magazine"** (label + wordmark; wordmark auto-fits at 20px).
- Surround (the outer chassis / `CASE`) is now **dark grey** (46,46,48); the panels and
  keypad (`PLATE`) stay red, so the red brand panels pop against a grey machine.

**Bot alert transports (`phosphor/bot/alerts.py`):** real destinations for the Tier-3
`on_success` / `on_failure` hooks, stdlib-only (urllib, smtplib), each an injectable
`callable(RunResult)`:
- `console_alerter(prefix)` - prints a one-line summary.
- `webhook_alerter(url)` - HTTP POSTs the run JSON (+ a message field).
- `email_alerter(to, ...)` - SMTP e-mail; connection from `PHOSPHOR_SMTP_*` env by default.
- `combine(*alerters)` - fan one result out to several; `format_result()` for the summary line.
- Injectable `poster` / `smtp_factory` so they unit-test with no network. Example in
  `examples/bot/watch_ready.py`. `tests/test_bot_alerts.py` (13 assertions) covers webhook
  payload/headers/error-swallowing, SMTP starttls+login+sendmail+quit, no-host skip, combine,
  and a failing job firing the webhook end-to-end.

*Authorised, defensive use only.* Suite green: 43 files.

---

## 2026-07-18 (3) — HVCK Magazine: black key surrounds

- Added an optional per-skin `key_outline` (new `Theme.key_outline` -> `KEY_OUTLINE`), drawn
  as a thin 1px surround on the PF/AID keycaps only. It is passed from the keypad path
  (`_key3d`), so sidebar buttons are unaffected (both share `_keycap`, but only the keypad
  passes the outline).
- HVCK Magazine sets `key_outline=(0,0,0)` - a thin black surround on all PF and AID keys,
  framing the white keycaps against the red keypad. Verified: keypad keys gain the black
  border, sidebar buttons do not; no other skin changes (outline defaults to None).

Suite green: 43 files.

---

## 2026-07-18 (4) — IND$FILE ASCII fix (client did no ASCII<->EBCDIC translation)

**Bug:** an ASCII-mode upload scrambled on the host (it looked like a binary upload). The
client shipped the file's raw ASCII bytes with no translation; the host decoded them as
EBCDIC (CP037), so the stored dataset was garbage. Downloads had the mirror bug (the client
only swapped the 0x15 newline and left the record bytes in EBCDIC).

**Fix (`phosphor/protocols/indfile/dft.py`):** text mode now translates properly, matching
real c3270/x3270 and GIBSON's host contract (EBCDIC CP037 records separated by 0x15):
- `text_to_ebcdic()` / `ebcdic_to_text()` helpers; `put()` encodes local text -> CP037
  records for text mode, `get()` decodes CP037 records -> local text. Binary mode still
  ships raw bytes untouched. CRLF is normalised to the record model on upload.
- `tests/test_indfile_ascii.py` (8 assertions) reproduces the scramble and locks the fix,
  including a real DFT-framed socket round-trip against GIBSON's host and a binary
  regression check. `verify_indfile_interop.py` now also checks ASCII (stored text +
  client text), not just binary bytes.

Suite green: 44 files. (Companion GIBSON host fix in the same transfer - see CHANGELOG-GIBSON.md.)
