# PHOSPHOR — User Guide

*A mainframe terminal and security toolkit in one window: a good-looking CRT
TN3270 terminal plus click-to-run enumeration, file transfer, and reporting.
No GPU, no OpenGL, no build step. For authorised, defensive training use.*

---

## 1. What it is

PHOSPHOR connects to GIBSON (the training mainframe) or a real mainframe over
TN3270 (EBCDIC), shows the session on a cathode-ray-styled screen, and gives you
a sidebar to run the security tools, move files, tune the look, and save a
report — all without leaving the window.

The CRT effects (bloom, glass curvature, burn-in, glow-line, scanlines, flicker)
are computed on the **CPU**, so it runs on ordinary hardware — a laptop, a VM, or
a Raspberry Pi — with nothing special to install.

## 2. Install (one command)

```bash
pip install phosphor-tn3270
phosphor-app
```

That pulls the three things it needs — pygame, numpy, pillow — all as normal
Python packages. **No system libraries, no OpenGL, no `apt`, no compiler.**
pygame's window uses SDL2, which is bundled in its own package.

If your system blocks pip (e.g. Kali's "externally-managed environment"):

```bash
pip install phosphor-tn3270 --break-system-packages
# ...or use a virtual environment:
python3 -m venv ~/phosphor && ~/phosphor/bin/pip install phosphor-tn3270
~/phosphor/bin/phosphor-app
```

## 3. First run — the window

`phosphor-app` opens the client. On the left is the sidebar; the large area on
the right is the terminal. Until you connect, the terminal shows a welcome
message.

## 4. Connect (EBCDIC)

In the **CONNECT** panel:

1. Click the **Host** field and type your mainframe/GIBSON address (e.g.
   `192.168.0.195`).
2. Set the **Port** (23 for TN3270) and, if needed, the **Codepage** (default
   `cp037`, the common US EBCDIC page).
3. Click **Connect**. The status dot turns green and the logon screen appears.

## 5. Use the terminal

- Type into the command line under the screen and press **ENTER** (or the button)
  to send — e.g. `LOGON APPLID(TSO)` or `LOGON APPLID(CICS)`.
- The screen updates with the mainframe's response.
- Everything is EBCDIC on the wire; PHOSPHOR handles the translation.

## 6. Run the tools

The **TOOLS** panel is your recon console. Click any of:

- **Scan all** — a quick sweep (screen, VTAM applids, TSO users, CICS posture)
- **VTAM applids** — which applications are reachable
- **TSO users** — which userids are valid
- **CICS transactions / users / region info** — CICS enumeration and posture
- **FTP anonymous** — is anonymous FTP allowed
- **DB2 DRDA** — identify the DB2 server

Results appear in the status log and are collected for the report. Each tool runs
in the background, so the terminal stays responsive.

## 7. Upload & download files

In **TRANSFER**, click **Upload** or **Download**. A file picker opens; choose the
local file (or where to save). PHOSPHOR moves the dataset using IND$FILE over the
TSO session (or FTP). You'll be prompted for the dataset name.

## 8. Tune the look

The **DISPLAY** bar under the terminal controls the CRT:

- **Profiles:** *Authentic* (full glass), *Boardroom* (gentle, easy on the eyes),
  *Amber*, *Green*, *Off* (flat, no effects).
- **Sliders:** nudge individual effects — Bloom, Burn-in, Scanlines, Curvature,
  Glow-line, Flicker — from subtle to strong.

Turn everything down to *Off* for a plain, fast, distraction-free screen, or up to
*Authentic* for the full 1980s terminal feel. Weak hardware? Use *Boardroom* or
*Off* — with effects off, the screen redraws instantly.

## 9. Save a report

Click **Save report** in the **REPORT** panel. PHOSPHOR writes an HTML assessment
(`phosphor_report.html`) with a severity summary, the findings collected from your
scans, the evidence, and remediation guidance — ready to hand to a client.

## 10. Troubleshooting

- **"pip install" is blocked (Kali/Debian):** add `--break-system-packages`, or
  use a virtual environment (section 2).
- **No window appears / "no available video device":** you must be at an actual
  desktop, not a headless SSH session. Check with `echo $DISPLAY` — if it's empty,
  open the client from the machine's own desktop (or the VM's console window).
- **It feels slow on a Pi:** switch to the *Boardroom* or *Off* profile, or lower
  the individual effect sliders. With animated effects off, the terminal is
  instant.
- **Can't connect:** confirm the host/port, that GIBSON is running, and that a
  firewall isn't blocking TN3270 (port 23).

## Command-line tools (optional)

Everything in the window is also available headless, which is handy over SSH:

```bash
phosphor <host> --menu                     # the recon menu in the terminal
phosphor <host> --scan --report out.html   # scan and report, no window
phosphor <host> --client                   # plain interactive TN3270
```

*Authorised, defensive training use only. GIBSON contains no real data.*
