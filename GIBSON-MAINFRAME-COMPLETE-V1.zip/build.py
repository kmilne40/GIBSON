#!/usr/bin/env python3
"""Build compiled PHOSPHOR binaries with Nuitka.

Two targets:

  core   the scanner / auditor / recon-menu / reporting tool.  Pure-Python +
         stdlib only - no GPU libraries - so it compiles to a small, portable,
         single-file binary.  This is the one to deploy.

  crt    the cathode-ray TN3270 terminal.  Pulls in moderngl / pyglet / pillow /
         numpy and their native GL libraries, so the binary is larger and needs
         a working OpenGL stack on the target.  Optional.

Usage:
    pip install nuitka                       # once (needs a C compiler present)
    python build.py core                     # -> dist/phosphor
    python build.py crt                      # -> dist/phosphor-crt
    python build.py both

Cross-compiling for the Kali Pi (ARM): run this script *on* the Pi (Nuitka is
not a cross-compiler); the same command produces an aarch64 binary there.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIST = ROOT / "dist"

COMMON = [
    "--standalone",
    "--onefile",
    "--assume-yes-for-downloads",     # let Nuitka fetch ccache/depends if needed
    "--include-package-data=phosphor",  # bundle shaders / fonts / demo_screen.json
    f"--output-dir={DIST}",
    "--remove-output",
]

# the core tool never touches the GPU stack; tell Nuitka not to chase it so the
# binary stays small even if those libraries happen to be installed.
CORE = [
    "--nofollow-import-to=phosphor.crt",
    "--nofollow-import-to=moderngl",
    "--nofollow-import-to=pyglet",
    "--nofollow-import-to=numpy",
    "--nofollow-import-to=PIL",
    "--output-filename=phosphor",
    "phosphor/__main__.py",
]

# the CRT terminal needs the numeric/imaging/GL stack bundled in
CRT = [
    "--enable-plugin=numpy",
    "--include-package=phosphor.crt",
    "--include-package=moderngl",
    "--include-package=pyglet",
    "--include-package=PIL",
    "--include-package=numpy",
    "--output-filename=phosphor-crt",
    "phosphor/crt/__main__.py",
]


def _run(extra: list[str]) -> int:
    cmd = [sys.executable, "-m", "nuitka", *COMMON, *extra]
    print("+ " + " ".join(cmd))
    return subprocess.call(cmd, cwd=ROOT)


def build(target: str) -> int:
    DIST.mkdir(exist_ok=True)
    try:
        import nuitka  # noqa: F401
    except Exception:
        print("error: Nuitka is not installed.  Run:  pip install nuitka")
        return 2
    rc = 0
    if target in ("core", "both"):
        print("\n=== building core binary (scanner / auditor / menu / report) ===")
        rc |= _run(CORE)
    if target in ("crt", "both"):
        print("\n=== building CRT terminal binary ===")
        rc |= _run(CRT)
    if rc == 0:
        print(f"\nDone.  Binaries in {DIST}/")
        for p in sorted(DIST.glob("phosphor*")):
            if p.is_file() and not p.suffix:
                print(f"   {p}")
    return rc


if __name__ == "__main__":
    tgt = sys.argv[1] if len(sys.argv) > 1 else "core"
    if tgt not in ("core", "crt", "both"):
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(build(tgt))
