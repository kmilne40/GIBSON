"""Python macro example - full control, loops, conditionals.
    python examples/macros/scripted_logon.py
"""
from phosphor.macro import MacroEngine

m = MacroEngine(default_timeout=20)
m.connect("192.168.0.96", 992, tls=True, cipher_profile="mainframe")
m.wait_for("LOGON")
m.enter("LOGON APPLID(TSO)")
m.wait_for("PASSWORD")
m.enter("CHANGEME")
m.wait_for("READY")
m.snapshot("logged-in")
print(m.transcript_text())
m.disconnect()
