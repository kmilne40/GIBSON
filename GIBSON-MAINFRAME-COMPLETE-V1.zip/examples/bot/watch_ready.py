"""Tier-3 bot example: probe a host every 5 minutes, alert on failure.
    python examples/bot/watch_ready.py
Authorised testing only. Edit the host before running.
"""
from phosphor.bot import Bot, Job, webhook_alerter, email_alerter, console_alerter, combine

def probe(engine):
    engine.connect("192.168.0.96", 992, tls=True, cipher_profile="mainframe")
    engine.wait_for("READY", timeout=30)
    engine.snapshot("ready")

# fan alerts out: console now, webhook + e-mail when you fill them in.
# e-mail reads PHOSPHOR_SMTP_HOST / _PORT / _USER / _PASS / _FROM from the environment.
on_fail = combine(
    console_alerter("[PHOSPHOR]"),
    webhook_alerter("https://hooks.example.com/phosphor"),
    email_alerter("soc@example.com"),
)

bot = Bot(log_path="phosphor-bot.jsonl")
bot.add_job(Job("ready-probe", probe, every=300, max_retries=3, on_failure=on_fail))

if __name__ == "__main__":
    try:
        bot.run()            # runs forever; Ctrl-C to stop
    except KeyboardInterrupt:
        print(bot.summary())
