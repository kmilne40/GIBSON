# Building PHOSPHOR installers — Windows, macOS, Linux

This is your step-by-step guide, Kev, for turning the PHOSPHOR source into an
easy double-click installer on each platform. Everything here uses the packaging
kit already in the `packaging/` folder.

## The one rule to remember

**PyInstaller is not a cross-compiler.** You build the Windows installer *on
Windows*, the macOS installer *on a Mac*, and the Linux build *on Linux* (or on
the Pi). You cannot make a Windows `.exe` from a Mac, or a `.dmg` from Linux.
That is a PyInstaller limitation, not a PHOSPHOR one. Plan for one build per OS.

The good news: on each OS it is one or two commands.

---

## Fast path (any OS)

From the project root:

```
python packaging/build.py
```

That installs PyInstaller, builds the app into `dist/PHOSPHOR/`, and prints the
next step for your OS. If you want to do it by hand, read on.

---

## Windows → `PHOSPHOR-Setup.exe`

**You need:** Windows 10/11, Python 3.11+, and Inno Setup 6 (free) from
<https://jrsoftware.org/isdl.php>.

1. Open **Command Prompt** in the project folder and build the app:

   ```
   pip install pyinstaller pygame numpy pillow cryptography
   pyinstaller packaging\phosphor.spec
   ```

   This produces `dist\PHOSPHOR\` — a self-contained folder with `PHOSPHOR.exe`
   and everything it needs. No Python required on the user's machine.

2. Build the installer. Either double-click `packaging\windows\phosphor.iss`
   (it opens in Inno Setup — press **Build ▸ Compile**), or from the command
   line:

   ```
   "C:\Program Files (x86)\Inno Setup 6\iscc.exe" packaging\windows\phosphor.iss
   ```

3. Ship the result: **`Output\PHOSPHOR-Setup.exe`**. When a user runs it, it
   installs into *Program Files*, adds Start-Menu and desktop icons, and
   registers a clean **Uninstall** entry in Add/Remove Programs.

> **Signing (optional but recommended).** An unsigned installer shows a
> SmartScreen "unknown publisher" prompt on first run. To remove it, buy a code
> signing certificate and run `signtool sign /fd SHA256 /a` on both
> `dist\PHOSPHOR\PHOSPHOR.exe` and `Output\PHOSPHOR-Setup.exe` before you ship.

---

## macOS → `PHOSPHOR-1.0.0.dmg`

**You need:** a Mac, Python 3.11+ (python.org or Homebrew), and the Xcode command
line tools (`xcode-select --install`).

1. From the project folder, run the one script that does everything:

   ```
   bash packaging/macos/build_dmg.sh
   ```

   It builds the `.icns` icon, runs PyInstaller to produce `dist/PHOSPHOR.app`,
   ad-hoc signs it, and packages a drag-to-Applications **`dist/PHOSPHOR-1.0.0.dmg`**.

2. Ship the `.dmg`. Users open it and drag PHOSPHOR to Applications. To
   uninstall, they drag it to the Trash.

> **First-launch note.** Because the app is not notarised, the first time a user
> opens it they must **right-click ▸ Open** and confirm (a plain double-click is
> blocked by Gatekeeper). To make it launch cleanly with a normal double-click,
> sign and **notarise** it with an Apple Developer ID:
>
> ```
> codesign --deep --force --sign "Developer ID Application: Your Name" dist/PHOSPHOR.app
> xcrun notarytool submit dist/PHOSPHOR-1.0.0.dmg --apple-id you@example.com --team-id XXXX --wait
> xcrun stapler staple dist/PHOSPHOR-1.0.0.dmg
> ```

---

## Linux → menu icon *or* portable AppImage

**You need:** Python 3.9+ and the usual build basics. On the Raspberry Pi this
works as-is; the result is an `aarch64` build (build it *on* the Pi).

Build the app once:

```
pip install pyinstaller pygame numpy pillow cryptography
pyinstaller packaging/phosphor.spec
```

Then pick one of two ways to ship it:

- **Installed, with a menu icon** (per-user, into `~/.local`):

  ```
  bash packaging/linux/install.sh          # uninstall: packaging/linux/uninstall.sh
  ```

  PHOSPHOR then appears in the application menu and as the `phosphor-gui` command.

- **Portable AppImage** (one file, no install; needs `appimagetool` on PATH from
  <https://github.com/AppImage/AppImageKit/releases>):

  ```
  bash packaging/linux/build_appimage.sh   # -> dist/PHOSPHOR-1.0.0-x86_64.AppImage
  ```

  Users `chmod +x` it and double-click. Nothing else to install.

---

## What ends up in the build

The PyInstaller spec bundles the app, a fallback mono font (so text renders even
on a machine with no matching system font), the 3270/5250 bezel, the CRT assets,
and the `cryptography` backend used for skin licensing. The app icon lives in
`packaging/icons/` as `.ico` (Windows), `.icns` (macOS) and `.png` (Linux).

## Do not ship this

Never include the `vendor/` folder in a build or a release — it holds the private
licence signing key. The app only needs the public key, which is already in
`phosphor/app/license.py`. For a real release, regenerate the signing key (the
demo key has appeared in development logs).

## Quick troubleshooting

- **App takes ~30s to start after packaging** → you almost certainly built a
  *onefile* binary, which extracts itself to a temp folder on every launch. Use
  the provided spec (it builds *onedir*, which starts instantly), or on Windows
  add antivirus exclusions for the install folder.
- **"Failed to execute script"** on Windows → a data file was missed. Rebuild
  with the provided `packaging/phosphor.spec` rather than a bare `pyinstaller
  phosphor_gui.py`; the spec lists the bezel, fonts and crypto explicitly.
- **Black window / no text** → the bundled font did not ship. Confirm
  `phosphor/fonts/` is present in `dist/PHOSPHOR/_internal/phosphor/fonts/`.

## Unlock codes (for your reference)

- **All skins (master):** `TN3270Acc,ess4me!` — typed into the Enter Licence box.
- **Pen-test tools:** `TN3270tools!` — typed into the Unlock Tools box in the GUI,
  or on the command line as `phosphor <host> --scan --unlock TN3270tools!`.

Keep these out of the shipped documentation; they belong in the No Starch Press
book and your LinkedIn hand-off, so you can vet who is doing the security work.
