# GIBSON update - NJE job submission + DRDA SQL execution (validated vs real GibsonState)

Two capabilities added so GIBSON exercises the full attack surface, wired to the REAL
GibsonState APIs and verified end to end.

## 1. NJE job submission  (gibson/net/nje_protocol.py, gibson/services/nje_server.py)
After an accepted sign-on the NJE service RECEIVES and processes a submitted job:
scb_decompress() + parse_sysin_stream() recover the JCL and the run-as identity
(NJHTOUSR/NJHTOGRP). The server logs an "NJE JOB SUBMIT" security event and submits the
job to JES2 with a real runner so it EXECUTES as the run-as user:

    proc = TsoCommandProcessor(self.state, run_as)
    self.state.jes.submit(jcl, run_as, runner=proc.run,
                          sql_runner=lambda s: Db2Simulator(self.state).format_spufi(s, run_as),
                          submitter=run_as)

Verified: an ADDUSER submitted over NJE (run-as IBMUSER) actually creates the user in RACF.

## 2. DRDA immediate SQL  (gibson/net/drda.py)
The DRDA listener answers EXCSQLIMM: extract_sqlstt() pulls the statement, respond_sql()
runs it through Db2Simulator(state).run_sql(sql, userid) and returns an SQLCARD with the
SQLCODE + rows. (Note: the sim is constructed per call - GibsonState has no .db2 attribute.)
SQL errors from the sim (ValueError "SQLCODE=-nnn, ...") are mapped back into the SQLCARD.

## Verified against the real GibsonState (gibson.cli.build_state)
- NJE: spoof node HAL -> signon GIBSON (pw GIBSONPW) -> submit ADDUSER ATKR run-as IBMUSER
  -> ATKR is created in RACF (job executed, not just queued).
- DRDA: authenticate IBMUSER/SYS1 -> SELECT CURRENT SQLID FROM SYSIBM.SYSDUMMY1 -> SQLCODE 0,
  CURRENT SQLID=IBMUSER.

## Files changed (3)
- gibson/net/nje_protocol.py     (+scb_decompress, +parse_sysin_stream)
- gibson/services/nje_server.py  (receive+parse+execute job after signon)
- gibson/net/drda.py             (+extract_sqlstt, +build_sqlcard, +respond_sql; EXCSQLIMM route)

## 3. NJE node-password enforcement by security mode  (nje_protocol.py, nje_server.py)
NJE sign-on now depends on the security mode (is_secure_mode):

  VULN (default, deliberately vulnerable):
    - a passwordless node (empty node password) accepts ANY sign-on password
    - weak node passwords (GIBSONPW/HAL123/ORACPW) can be brute-forced (no lockout)

  SECURE (--secure):
    - passwordless sign-on is REJECTED (no unauthenticated NJE trust)
    - a blank sign-on password is rejected
    - per-source brute-force LOCKOUT after 3 failed node-password attempts
      (defeats nje-pass-brute); a correct password still authenticates and clears the count

This makes SECURE mode actually block the NJE spoof-and-submit attack, so instructors can
show the misconfig, the attack, the fix, and proof the attack now fails.
check_node_password(ohost, password, nodes, secure=False) gained the `secure` flag;
nje_server tracks failed attempts per source (_nje_record_fail/_nje_locked_out/_nje_reset_fails,
threshold _NJE_MAX_FAILS=3). Test: tests/test_nje_secure_signon.py (7).
