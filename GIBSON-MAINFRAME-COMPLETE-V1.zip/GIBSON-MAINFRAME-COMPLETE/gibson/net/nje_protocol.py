"""NJE (Network Job Entry) TCP handshake codec - the 33-byte OPEN/ACK/NAK record.

Matches the wire format used by Soldier of Fortran's NJElib and the nmap
``nje-node-brute`` / ``nje-pass-brute`` scripts, whose OPEN template is::

    openNJEfmt = "\\xd6\\xd7\\xc5\\xd5@@@@%s\\0\\0\\0\\0%s\\0\\0\\0\\0\\0"
                  O   P   E   N  (sp*4) RHOST  RIP=0  OHOST  OIP=0  R=0

i.e. a 33-byte record laid out as (this is the order in Table 10-2 of the
chapter; the Listing 10-6 column labels are transposed):

    TYPE(8 EBCDIC)  RHOST(8 EBCDIC)  RIP(4)  OHOST(8 EBCDIC)  OIP(4)  R(1)

OHOST is the target node being probed; RHOST is the node the caller claims to
be. The server answers with the same 33-byte shape, TYPE set to ACK or NAK and
the reason byte R set to:

    0x01  OHOST unknown / invalid          (node does not exist)
    0x04  OHOST valid but RHOST unauthorised (confirms OHOST exists)
    0x00  OHOST and RHOST both valid        (full ACK)

This R-byte side-channel is exactly what nje-node-brute reads to enumerate node
names without authentication.
"""
from __future__ import annotations

import struct
from typing import Dict, Optional, Tuple

EBCDIC = "cp037"
RECORD_LEN = 33

R_OK = 0x00
R_UNKNOWN_OHOST = 0x01
R_BAD_RHOST = 0x04


def ebcdic8(text: str) -> bytes:
    """Upper-case, 8 bytes, EBCDIC, space (0x40) padded."""
    return text.upper()[:8].ljust(8).encode(EBCDIC, errors="replace")


def from_ebcdic(raw: bytes) -> str:
    return raw.decode(EBCDIC, errors="replace").strip()


def parse_open(data: bytes) -> Optional[dict]:
    """Parse a 33-byte NJE record; return its fields or None if not a record."""
    if not data or len(data) < RECORD_LEN:
        return None
    return {
        "type": from_ebcdic(data[0:8]),
        "rhost": from_ebcdic(data[8:16]),
        "rip": data[16:20],
        "ohost": from_ebcdic(data[20:28]),
        "oip": data[28:32],
        "r": data[32],
    }


def build_record(rtype: str, *, rhost: str, rip: bytes, ohost: str,
                 oip: bytes, r: int) -> bytes:
    """Build a 33-byte NJE record."""
    return (ebcdic8(rtype) + ebcdic8(rhost) + rip[:4].ljust(4, b"\x00")
            + ebcdic8(ohost) + oip[:4].ljust(4, b"\x00") + struct.pack("B", r & 0xFF))


def respond_open(data: bytes, nodes: Dict[str, dict]) -> Optional[Tuple[bytes, dict]]:
    """Given an inbound buffer, return (response_bytes, info) or None if it is
    not an OPEN.  ``nodes`` is a mapping of known node names (e.g.
    nje.CHAPTER10_NODES).  ``info`` describes the decision for logging."""
    pkt = parse_open(data)
    if pkt is None or pkt["type"].upper() != "OPEN":
        return None
    oh = pkt["ohost"].upper()
    rh = pkt["rhost"].upper()
    known = {k.upper() for k in nodes}
    if oh not in known:
        rtype, r = "NAK", R_UNKNOWN_OHOST
    elif rh not in known:
        rtype, r = "NAK", R_BAD_RHOST
    else:
        rtype, r = "ACK", R_OK
    resp = build_record(rtype, rhost=pkt["rhost"], rip=pkt["rip"],
                        ohost=pkt["ohost"], oip=pkt["oip"], r=r)
    info = {"type": rtype, "r": r, "ohost": oh, "rhost": rh}
    return resp, info


# ---------------------------------------------------------------------------
# I-record sign-on (drives nmap nje-pass-brute).
#
# After an OPEN that returns ACK (R=0x00), the client sends SOH/ENQ; the server
# replies DLE/ACK; the client then sends an I-record carrying the node password
# (NCCILPAS/NCCINPAS).  If the password is correct the server replies with a
# 'J' sign-on reply, otherwise a 'B' close record.  nje-pass-brute reads byte 19
# (the SRCB) of the reply: 0xC2 ('B') means bad password, anything else is good.
# ---------------------------------------------------------------------------

# 18-byte SOH/ENQ the client sends and the 18-byte DLE/ACK the server returns.
SOH_ENQ = bytes.fromhex("000000120000000000000002012d00000000")
DLE_ACK = bytes.fromhex("000000120000000000000002107000000000")

SRCB_I = 0xC9   # 'I' initial sign-on
SRCB_J = 0xD1   # 'J' sign-on reply (success)
SRCB_B = 0xC2   # 'B' close / sign-on reject (bad password)

# Offset of the 8-byte EBCDIC password inside the 62-byte I-record.
_IREC_PW_OFFSET = 37


def is_soh_enq(data: bytes) -> bool:
    return bool(data) and data[:14] == SOH_ENQ[:14]


def parse_irecord_password(data: bytes) -> Optional[str]:
    """Extract the node password (NCCILPAS) from an inbound I-record."""
    if not data or len(data) < _IREC_PW_OFFSET + 8:
        return None
    # confirm this looks like an I-record (RCB 0xF0, SRCB 'I' at offset 17/18)
    if len(data) > 18 and data[18] not in (SRCB_I,):
        # tolerate slight framing differences; still try to read the password
        pass
    return from_ebcdic(data[_IREC_PW_OFFSET:_IREC_PW_OFFSET + 8])


def _calc_ttr(payload: bytes) -> bytes:
    """TTR: 0x0000 + 2-byte record length (matches NJElib readTTR)."""
    return b"\x00\x00" + struct.pack(">H", len(payload))


def _make_ttb(payload: bytes) -> bytes:
    """TTB: 8-byte header (len incl. header+EOB at bytes 2:4) + payload + 4-byte EOB."""
    return (b"\x00\x00" + struct.pack(">H", len(payload) + 8 + 4)
            + b"\x00\x00\x00\x00" + payload + b"\x00\x00\x00\x00")


def _frame_nccr(srcb: int, data: bytes, *, bcb: int = 0x80,
                fcs: bytes = b"\x8f\xcf") -> bytes:
    """Wrap an NCCR (RCB 0xF0) record in DLE STX / BCB / FCS + TTR + TTB, exactly
    the layout NJElib.processData() expects.  The SRCB lands at offset 18 (byte
    19), which is what nmap nje-pass-brute inspects, so that path still works."""
    inner = b"\x10\x02" + bytes([bcb & 0xFF]) + fcs + bytes([0xF0, srcb & 0xFF]) + data
    return _make_ttb(_calc_ttr(inner) + inner)


def build_signon_j(node_name: str, node_num: int = 1, password: str = "") -> bytes:
    """Full NCCR 'J' (response sign-on) record.

    NJElib.process_NCCR() reads a fixed field layout and indexes Data[34] and
    Data[35:39]; the old minimal reply was too short and raised before the
    command/JCL exchange.  This emits the complete 39-byte NCCI body so real
    iNJEctor.py / jcl.py parse it and continue.  NCCIEVNT is non-zero so the peer
    replies with an 'L' (concurrence) and sign-on completes in one exchange.
    """
    NCCIDL   = bytes([0x29])            # declared length (incl. RCB+SRCB) - must be >= 0x29
    NCCINODE = ebcdic8(node_name)       # 8  responding node name
    NCCIQUAL = bytes([node_num & 0xFF]) # 1  node number -> becomes peer's target_node
    NCCIEVNT = b"\x00\x00\x00\x01"      # 4  non-zero -> peer sends L, not a K reset
    NCCIREST = b"\x00\x64"              # 2  node resistance
    NCCIBUFSZ = b"\x80\x00"             # 2  buffer size (32768)
    NCCILPAS = ebcdic8(password)        # 8  last password (echo configured node pw)
    NCCINPAS = ebcdic8("")             # 8  new password (spaces)
    NCCIFLG  = b"\x00"                  # 1  0x00 = regular (not secure signon)
    NCCIFEAT = b"\x40\x17\x00\x00"      # 4  feature flags
    data = (NCCIDL + NCCINODE + NCCIQUAL + NCCIEVNT + NCCIREST + NCCIBUFSZ
            + NCCILPAS + NCCINPAS + NCCIFLG + NCCIFEAT)
    return _frame_nccr(SRCB_J, data)


def build_signon_b(node_name: str = "", node_num: int = 0) -> bytes:
    """Full NCCR 'B' (signoff / sign-on reject) record with valid framing."""
    data = (bytes([0x0F]) + ebcdic8(node_name) + bytes([node_num & 0xFF])
            + b"\x00\x00\x00\x00\x00\x00")
    return _frame_nccr(SRCB_B, data)


def signon_reply(password_ok: bool, *, node_name: str = "GIBSON",
                 node_num: int = 1, password: str = "") -> bytes:
    return (build_signon_j(node_name, node_num, password) if password_ok
            else build_signon_b(node_name, node_num))


def check_node_password(ohost: str, password: str, nodes: Dict[str, dict],
                        secure: bool = False) -> bool:
    """Validate an I-record node sign-on password.

    In VULN mode (secure=False) a node whose password is empty accepts ANY password -
    the classic unauthenticated-NJE-trust weakness that lets a spoofed node sign on.

    In SECURE mode (secure=True) that hole is closed: a node with no password set is
    rejected outright (no passwordless sign-on), and a blank supplied password is never
    accepted.  Configured node passwords are still required to match in both modes;
    secure mode additionally refuses the "no password required" shortcut."""
    node = nodes.get(ohost.upper())
    if not node:
        return False
    expected = (node.get("password") or "").upper()
    if not expected:
        # no password configured for this node
        return False if secure else True        # secure: deny; vuln: accept anything
    if secure and not password.strip():
        return False                            # secure: reject blank sign-on password
    return password.upper() == expected


# ============================================================================
#  Job submission parsing  (added: receive /*XEQ jobs, not just sign-on)
# ============================================================================
# A trusted peer that has signed on may submit a job (SYSIN stream): an NJH job
# header carrying NJHTOUSR/NJHTOGRP (the identity the job runs under) followed by the
# JCL lines.  Parsing it lets Gibson DETECT and log NJE job submission - the classic
# lateral-movement / RACF-backdoor step - and (optionally) route the JCL into JES2.

RCB_SYSIN = 0x98


def scb_decompress(data: bytes):
    """Inverse of NJE String-Control-Byte compression. Returns (plaintext, consumed)."""
    out = bytearray()
    i = 0
    while i < len(data):
        scb = data[i]; i += 1
        if scb == 0x00:                          # end of this record's data
            break
        if scb & 0xC0 == 0xC0:                    # literal bytes (0xC0-0xFF)
            n = scb & 0x3F
            out += data[i:i + n]; i += n
        elif scb & 0xE0 == 0xA0:                  # run of a repeated char (0xA0-0xBF)
            if i >= len(data):
                break
            out += bytes([data[i]]) * (scb & 0x1F); i += 1
        elif scb & 0xE0 == 0x80:                  # run of spaces (0x80-0x9F)
            out += b"\x40" * (scb & 0x1F)
        else:
            break
    return bytes(out), i


def parse_sysin_stream(wire: bytes):
    """Parse a TTB-framed SYSIN job transmission into records and pull out the JCL and
    the run-as identity.  Returns a dict: {records, jcl_lines, run_as_user, run_as_grp}."""
    result = {"records": [], "jcl_lines": [], "run_as_user": "", "run_as_grp": ""}
    if len(wire) < 12 or wire[0:2] != b"\x00\x00":
        return result
    ttb_len = (wire[2] << 8) | wire[3]
    inner = wire[8:8 + (ttb_len - 12)]
    # inner = TTR(4) DS(2) BCB(1) FCS(2) then RCB/SRCB records + EOR
    body = inner[9:]
    i = 0
    while i + 2 <= len(body):
        if body[i] == 0x00:                      # trailing EOR
            break
        rcb, srcb = body[i], body[i + 1]; i += 2
        data, consumed = scb_decompress(body[i:])
        i += consumed
        result["records"].append((rcb, srcb, data))
        if rcb == RCB_SYSIN and srcb == 0x80 and data[:1] == b"\x50":
            try:
                result["jcl_lines"].append(data[1:].decode("cp500").rstrip())
            except Exception:
                pass
        elif rcb == RCB_SYSIN and srcb == 0xC0 and len(data) >= 16:
            # NJHTOUSR / NJHTOGRP are the last 16 bytes of the NJH header
            try:
                result["run_as_user"] = data[-16:-8].decode("cp500").strip()
                result["run_as_grp"] = data[-8:].decode("cp500").strip()
            except Exception:
                pass
    return result


# ============================================================================
#  NMR (Nodal Message Record) command exchange  -  drives iNJEctor.py
# ============================================================================
# After sign-on, iNJEctor sends an operator command as an NMR (RCB 0x9A, SCB
# compressed).  The server routes the command to the JES2 handler and replies
# with one NMR *message* record per output line; NJElib.sendCommand() joins the
# NMRMSG fields with newlines.  Layout mirrors njelib.process_nmr():
#   [0]FLAG [1]LEVEL [2]TYPE [3]MLEN [4:12]TONOD [12]qual [13:21]OUT
#   [21:29]FMNOD [29]qual [30:]MSG
RCB_NMR = 0x9A


def _scb_compress(data: bytes) -> bytes:
    """Encode as NJE SCB literal runs (<=63 bytes each) terminated by 0x00."""
    out = bytearray()
    i = 0
    while i < len(data):
        chunk = data[i:i + 63]
        out.append(0xC0 | len(chunk))
        out += chunk
        i += 63
    out.append(0x00)
    return bytes(out)


def _frame_record(rcb: int, srcb: int, data: bytes, *, compress: bool = False,
                  bcb: int = 0x80, fcs: bytes = b"\x8f\xcf") -> bytes:
    payload = _scb_compress(data) if compress else data
    inner = b"\x10\x02" + bytes([bcb & 0xFF]) + fcs + bytes([rcb & 0xFF, srcb & 0xFF]) + payload
    return _make_ttb(_calc_ttr(inner) + inner)


def parse_nmr_command(wire: bytes) -> Optional[str]:
    """Extract the operator-command text from an inbound NMR command record."""
    if not wire:
        return None
    # locate RCB 0x9A followed by SRCB then an SCB literal run (0xC0-0xFF)
    idx = -1
    for o in range(len(wire) - 2):
        if wire[o] == RCB_NMR and (wire[o + 2] & 0xC0) == 0xC0:
            idx = o
            break
    if idx < 0:
        return None
    body, _ = scb_decompress(wire[idx + 2:])
    if len(body) < 4:
        return None
    nmrml = body[3]
    msg = body[30:30 + nmrml] if len(body) >= 30 else b""
    text = from_ebcdic(msg).strip()
    return text or None


def build_nmr_message(text: str, *, to_node: str, from_node: str,
                      to_num: int = 1, from_num: int = 1) -> bytes:
    """Build one TTB-framed NMR *message* record carrying ``text`` (one line)."""
    msg = ebcdic8("")[:0] + text.upper().encode(EBCDIC, errors="replace")
    msg = msg[:255]
    NMRFLAG = b"\x00"          # message (NMRFLAGC off), logical-routed
    NMRLEVEL = b"\x00"
    NMRTYPE = b"\x00"
    NMRML = bytes([len(msg)])
    NMRTONOD = ebcdic8(to_node)
    NMROUT = b"\x00" * 8
    NMRFMNOD = ebcdic8(from_node)
    packet = (NMRFLAG + NMRLEVEL + NMRTYPE + NMRML
              + NMRTONOD + bytes([to_num & 0xFF]) + NMROUT
              + NMRFMNOD + bytes([from_num & 0xFF]) + msg)
    return _frame_record(RCB_NMR, 0x00, packet, compress=True)


def build_nmr_replies(text: str, *, to_node: str, from_node: str,
                      to_num: int = 1, from_num: int = 1) -> bytes:
    """One NMR record per line of ``text`` (JES2 sends one console line each)."""
    out = b""
    for line in (text or "").split("\n"):
        out += build_nmr_message(line, to_node=to_node, from_node=from_node,
                                 to_num=to_num, from_num=from_num)
    return out


# ============================================================================
#  SYSOUT completion stream  -  lets jcl.py's sendJCL(wait_for_sysout=True) finish
# ============================================================================
# After receiving a SYSIN job, the peer waits for a SYSOUT stream whose NJH job
# header echoes the job number (NJHGJID) and name (NJHGJNAM) it submitted, then a
# SYSOUT EOF (SRCB 0x00) which njelib acknowledges and marks the job complete.
RCB_SYSOUT = 0x99


def build_sysout_completion(job_num: int, job_name: str) -> bytes:
    """Build a minimal but valid SYSOUT job-header + EOF stream for ``job``."""
    # General NJH section (offsets are relative to Data[4:], per njelib.job_headers,
    # which reads fields up to offset 212 - size the buffer to cover them all).
    section = bytearray(224)
    struct.pack_into(">H", section, 0, len(section))          # NJHGLEN
    section[2] = 0xC0                                         # NJHGTYPE = job header
    section[3] = 0x00                                         # NJHGMOD
    struct.pack_into(">h", section, 4, job_num & 0x7FFF)     # NJHGJID
    section[6:7] = "A".encode(EBCDIC)                        # NJHGJCLS
    section[7:8] = "K".encode(EBCDIC)                        # NJHGMCLS
    section[16:24] = ebcdic8("")                             # NJHGACCT
    section[24:32] = ebcdic8(job_name)                       # NJHGJNAM
    section[32:40] = ebcdic8("")                             # NJHGUSID
    njh = bytearray(4)
    struct.pack_into(">H", njh, 0, 4 + len(section))          # NJHLEN
    data = bytes(njh) + bytes(section)
    header_rec = _frame_record(RCB_SYSOUT, 0xC0, data, compress=True)
    eof_rec = _frame_record(RCB_SYSOUT, 0x00, b"\x00\x00", compress=True)
    return header_rec + eof_rec


def grant_stream(srcb: int = 0x98) -> bytes:
    """Reply 0xA0 (permission to initiate stream) to a peer's 0x90 request."""
    return _frame_record(0xA0, srcb, b"\x00\x00", compress=False)


def is_stream_request(wire: bytes) -> Optional[int]:
    """If ``wire`` is an RCB 0x90 stream-initiation request, return its SRCB.

    The RCB sits at offset 17 in a single-record TTB frame (TTB 8 + TTR 4 +
    DLE STX 2 + BCB 1 + FCS 2).  Checking that fixed position avoids mistaking a
    SYSIN (0x98) chunk that merely contains a 0x90 byte for a request."""
    if len(wire) >= 19 and wire[17] == 0x90 and wire[18] in (0x98, 0x99, 0xF8, 0xF9):
        return wire[18]
    return None
