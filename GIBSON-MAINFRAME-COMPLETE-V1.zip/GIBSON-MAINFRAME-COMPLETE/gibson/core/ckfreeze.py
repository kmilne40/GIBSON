"""CKFREEZE - the zSecure system-configuration snapshot.

In a real shop, zSecure's **CKFCOLL** program walks the running system and writes
a **CKFREEZE** data set holding the non-RACF security state: the APF list, LPA /
LNKLST, SVCs, exits, subsystems, started tasks, sensitive data sets and z/OS UNIX
settings.  CARLa then reports against CKFREEZE (`NEWLIST TYPE=APF`, `TYPE=SENSDSN`,
`TYPE=STC` ...) *combined with* the RACF database.

Gibson already has the raw material - ``state.apf_libraries``, the address-space
population, and the STARTED-class identities - so this module simply assembles it
into the record shapes CARLa consumes, which is what turns the existing "canned"
zSecure reports into a real, queryable snapshot.
"""
from __future__ import annotations

from typing import Any, Dict, List


# data sets that are security-sensitive by definition, with why
_SENSITIVE = [
    ("SYS1.PARMLIB", "PARMLIB", "System configuration - controls IPL and security"),
    ("SYS1.PROCLIB", "PROCLIB", "Started-task JCL - a write here is code execution as the STC id"),
    ("SYS1.LINKLIB", "LINKLIB", "System link library (APF)"),
    ("SYS1.LPALIB", "LPALIB", "Link pack area - resident authorized code"),
    ("SYS1.SVCLIB", "SVCLIB", "SVC routines"),
    ("SYS1.RACFDS", "RACFDB", "The RACF database - password hashes and all profiles"),
    ("SYS1.RACFDS.BACKUP", "RACFDB", "RACF database backup"),
    ("SYS1.MANA", "SMF", "SMF audit data set"),
    ("SYS1.MANB", "SMF", "SMF audit data set"),
    ("SYS1.UADS", "UADS", "TSO user attribute data set"),
]


class Ckfreeze:
    """A point-in-time snapshot of the running Gibson system."""

    def __init__(self, state: Any):
        self.state = state

    # -- system -----------------------------------------------------------
    def system(self) -> Dict[str, str]:
        cfg = getattr(self.state, "config", None)
        sysname = (getattr(getattr(self.state, "network", None), "hostname", None)
                   or "MVSC").upper()[:8]
        smfid = (getattr(cfg, "smfid", None) or "GIBS")
        return {"SYSTEM": sysname, "SMFID": smfid, "SYSPLEX": "GIBSPLEX",
                "PRODUCT": "z/OS", "RELEASE": "z/OS 3.2", "COLLECT": "CKFCOLL"}

    # -- APF list ---------------------------------------------------------
    def apf(self) -> List[Dict[str, str]]:
        libs = list(getattr(self.state, "apf_libraries", []) or [])
        rows = []
        for lib in libs:
            rows.append({
                "DSNAME": lib,
                "VOLUME": "*SMS*" if not lib.startswith("SYS1.") else "SBSYS1",
                "APF": "YES",
                "WRITABLE": "YES" if self._writable_by_nonpriv(lib) else "NO",
            })
        return rows

    def _writable_by_nonpriv(self, dsname: str) -> bool:
        """Can a non-system id UPDATE/ALTER this data set?  A writable APF library
        is the classic APF escalation finding."""
        name = dsname.upper()
        if "VULN" in name:                    # deliberate training exposure
            return True
        try:
            from gibson.apps.racf_admin import get_racf_store
            st = get_racf_store(self.state)
            prof = st.profiles.get("DATASET", {})
            # exact or high-level match
            for pname, p in prof.items():
                if name.startswith(pname.rstrip("*").rstrip(".")):
                    if str(p.get("UACC", "NONE")).upper() in ("UPDATE", "ALTER", "CONTROL"):
                        return True
                    for who, acc in (p.get("PERMITS", {}) or {}).items():
                        if who not in ("+MASTER+", "SYS1") and str(acc).upper() in ("UPDATE", "ALTER", "CONTROL"):
                            return True
        except Exception:
            pass
        return False

    # -- sensitive data sets ---------------------------------------------
    def sensitive_datasets(self) -> List[Dict[str, str]]:
        apf_names = {r["DSNAME"].upper() for r in self.apf()}
        rows = []
        seen = set()
        for name, kind, why in _SENSITIVE:
            rows.append({"DSNAME": name, "TYPE": kind, "REASON": why,
                         "APF": "YES" if name.upper() in apf_names else "NO",
                         "WRITABLE": "YES" if self._writable_by_nonpriv(name) else "NO"})
            seen.add(name.upper())
        for r in self.apf():                       # APF libs not already listed
            if r["DSNAME"].upper() not in seen:
                rows.append({"DSNAME": r["DSNAME"], "TYPE": "APFLIB",
                             "REASON": "APF-authorized load library",
                             "APF": "YES", "WRITABLE": r["WRITABLE"]})
        return rows

    # -- started tasks / address spaces ----------------------------------
    def started_tasks(self) -> List[Dict[str, str]]:
        try:
            from gibson.core.address_spaces import started_task_identities
            out = []
            for r in started_task_identities(self.state):
                out.append({"JOBNAME": r["jobname"], "PROGRAM": r["program"],
                            "OWNER": r["owner"], "ATTR": r["attrs"],
                            "RISK": "YES" if r["risk"] else "NO"})
            return out
        except Exception:
            return []

    def address_spaces(self) -> List[Dict[str, str]]:
        try:
            from gibson.core.address_spaces import system_address_spaces
            return [{"JOBNAME": s.jobname, "ASID": s.asid_hex, "PROGRAM": s.program,
                     "OWNER": s.owner, "TYPE": s.astype, "SRVCLASS": s.srvclass}
                    for s in system_address_spaces(self.state)]
        except Exception:
            return []

    def subsystems(self) -> List[Dict[str, str]]:
        return [
            {"SSNAME": "JES2", "PROGRAM": "HASPINIT", "TYPE": "PRIMARY JES"},
            {"SSNAME": "DB2A", "PROGRAM": "DSN3INI", "TYPE": "DB2 SUBSYSTEM"},
            {"SSNAME": "IRLM", "PROGRAM": "DXRRLM00", "TYPE": "DB2 LOCK MANAGER"},
            {"SSNAME": "RACF", "PROGRAM": "IRRSSM00", "TYPE": "SECURITY"},
        ]

    # -- source dispatch for CARLa NEWLIST TYPE=... ----------------------
    def rows_for(self, newlist_type: str) -> List[Dict[str, str]]:
        t = newlist_type.upper()
        return {
            "APF": self.apf,
            "SENSDSN": self.sensitive_datasets,
            "STC": self.started_tasks,
            "STARTED": self.started_tasks,
            "ADDRSPACE": self.address_spaces,
            "AS": self.address_spaces,
            "SUBSYS": self.subsystems,
        }.get(t, lambda: [])()

    # -- CKFCOLL: write the snapshot as a data set (like the real Collect) -
    def collect(self, userid: str = "IBMUSER",
                dsname: str = "SYS1.CKFREEZE") -> str:
        s = self.system()
        lines = [
            f"CKF100I CKFCOLL COLLECT STARTED FOR SYSTEM {s['SYSTEM']}",
            f"CKF110I APF LIBRARIES COLLECTED: {len(self.apf())}",
            f"CKF111I SENSITIVE DATA SETS COLLECTED: {len(self.sensitive_datasets())}",
            f"CKF112I STARTED TASKS COLLECTED: {len(self.started_tasks())}",
            f"CKF113I ADDRESS SPACES COLLECTED: {len(self.address_spaces())}",
            f"CKF114I SUBSYSTEMS COLLECTED: {len(self.subsystems())}",
            f"CKF199I CKFREEZE DATA SET {dsname} WRITTEN - COLLECT COMPLETE",
        ]
        try:
            self.state.datasets.write(userid, dsname, "\n".join(lines) + "\n")
        except Exception:
            pass
        return "\n".join(lines)


def get_ckfreeze(state: Any) -> Ckfreeze:
    return Ckfreeze(state)
