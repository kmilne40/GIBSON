from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional
import json
import re

DEFAULT_ALIASES = {
    "LU": "LISTUSER",
    "LG": "LISTGRP",
    "SD": "LISTDSD",
    "LD": "LISTDSD",
    "RL": "RLIST",
    "SE": "SETROPTS",
    "SR": "SEARCH",
    "X": "EXIT",
    "S": "SDSF",
    # Standard RACF command abbreviations. Real RACF accepts the short form of
    # every administration command, so a reader typing ALU or SETR by habit gets
    # the same result as the long form. Added as first-word aliases so no command
    # handler has to change, and they also apply inside batch IKJEFT01 SYSTSIN,
    # which is where the book's privilege-escalation deck uses ALU.
    "ALU": "ALTUSER",
    "AU": "ADDUSER",
    "DU": "DELUSER",
    "PE": "PERMIT",
    "RDEF": "RDEFINE",
    "RALT": "RALTER",
    "RDEL": "RDELETE",
    "SETR": "SETROPTS",
    "AG": "ADDGROUP",
    "ALG": "ALTGROUP",
    "DG": "DELGROUP",
    "AD": "ADDSD",
    "ALD": "ALTDSD",
    "DD": "DELDSD",
    "CO": "CONNECT",
    "RE": "REMOVE",
}

# Keyword/operand abbreviations expanded wherever they appear on the command
# line (e.g. the standard TSO DA(...) shorthand for DATASET(...)), as opposed to
# the first-word command aliases above. These are applied by expand() so no
# individual command handler (LISTDSD, DATASET, ALLOC, TRANSMIT, ...) has to be
# changed to understand the abbreviation.
DEFAULT_KEYWORD_ALIASES = {
    "DA": "DATASET",
}

@dataclass
class AliasRegistry:
    aliases: Dict[str, str] = field(default_factory=lambda: dict(DEFAULT_ALIASES))
    keyword_aliases: Dict[str, str] = field(default_factory=lambda: dict(DEFAULT_KEYWORD_ALIASES))
    path: Optional[Path] = None

    @classmethod
    def load(cls, path: Path) -> "AliasRegistry":
        reg = cls(path=path)
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                for k, v in data.items():
                    reg.aliases[k.upper()] = str(v)
            except Exception:
                pass
        return reg

    def save(self) -> None:
        if not self.path:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.aliases, indent=2, sort_keys=True), encoding="utf-8")

    def expand(self, command: str) -> str:
        raw = command.strip()
        if not raw:
            return raw
        # Operand/keyword abbreviations (e.g. DA('dsn') -> DATASET('dsn')),
        # matched only in the keyword-with-open-paren position so ordinary text
        # is left alone. Applied before the first-word command alias below.
        for kw, full in self.keyword_aliases.items():
            raw = re.sub(rf"\b{re.escape(kw)}\s*\(", f"{full}(", raw, flags=re.I)
        first, *rest = raw.split(maxsplit=1)
        alias = self.aliases.get(first.upper())
        if not alias:
            return raw
        return alias + ((" " + rest[0]) if rest else "")

    def command(self, cmd: str) -> Optional[str]:
        parts = cmd.strip().split(maxsplit=2)
        if not parts or parts[0].upper() != "ALIAS":
            return None
        if len(parts) == 1 or (len(parts) >= 2 and parts[1].upper() in ("LIST", "L")):
            lines = ["GIBSON COMMAND ALIASES", "ALIAS    EXPANDS TO", "------   ----------------------------------------"]
            for k in sorted(self.aliases):
                lines.append(f"{k:<8} {self.aliases[k]}")
            return "\n".join(lines)
        if len(parts) >= 3 and parts[1].upper() in ("DELETE", "DEL"):
            key = parts[2].strip().upper()
            if key in self.aliases:
                del self.aliases[key]
                self.save()
                return f"ALIAS {key} DELETED"
            return f"ALIAS {key} NOT FOUND"
        if len(parts) >= 3:
            self.aliases[parts[1].upper()] = parts[2].strip().strip('"')
            self.save()
            return f"ALIAS {parts[1].upper()} DEFINED"
        return "USAGE: ALIAS LIST | ALIAS name expansion | ALIAS DELETE name"
