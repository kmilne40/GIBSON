"""M2 - CICS in authentic EBCDIC 3270.

Implements the Phase-0 ``PanelSession`` contract: good-morning -> blank
transaction entry -> transactions.  Reuses ``CicsSimulator`` for all behaviour
(``execute`` for CEMT/CECI/CEDA output, ``build_fielded_panel`` for the operator
menu, ``region.signon/signoff`` for sign-on state); this module is presentation
+ pseudo-conversational routing only.

States:
  GM      - good-morning banner
  ENTRY   - cleared screen, type a 4-char transaction id
  CESN    - sign-on map (userid + non-display password)
  OPMENU  - fielded CICS operator menu (a real input map; option -> command)
  RUN     - scrollable output of a transaction, with a command line
"""
from __future__ import annotations

from typing import List, Optional

from gibson.render import colors
from gibson.render.screen3270 import ScreenBuffer
from gibson.render.panels import Panel, Label, Field, PanelInput, PanelSession, ScrollList, text_to_lines
from gibson.render.ansi3270 import render_ansi_to_screen
from gibson.apps.cics import CicsSimulator
from gibson.apps.dvca.cics_session import execute_dvca
from gibson.apps.cbsa.cics_session import execute_omen

_GM = "GM"
_ENTRY = "ENTRY"
_CESN = "CESN"
_OPMENU = "OPMENU"
_RUN = "RUN"
_LAB = "LAB"
_CEMT = "CEMT"
_CBTR = "CBTR"
_CECI = "CECI_XI"     # CECI EXEC command interpreter (cicspwn-driven)
_CEDA = "CEDA_XI"     # CEDA COPY/INSTALL session (RACF bypass)

_TURQ = getattr(colors, "TURQUOISE", colors.GREEN)
_OUTPUT_ROWS = 21

# Transactions we route to CicsSimulator.execute (rendered scrollably).
_EXEC_TRANS = {"CEMT", "CECI", "CEDA", "CSMT", "CEBR", "CEDF", "HELP", "?"}
# Lab applications (Mel's Cargo / DVCA, CBSA / OMEN) — interactive, PF-key and
# field driven, rendered in colour and kept active across submissions.
_LAB_START = {"DVCA", "OMEN", "CBSA", "MCGM", "MCMM", "MCOR", "MCAD", "MCHI", "MCHS", "SCRT"}
# Typing a real CICS transaction while in a lab leaves the lab and runs it.
_CICS_TRANS = {"CEMT", "CECI", "CEDA", "CEDF", "CEBR", "CSMT", "CEOT", "CEST",
               "CMAC", "CWTO", "CRTE", "CSGM", "CESF", "CESN"}

# CEMT INQUIRE resource detection + colour helpers for the fielded panels.
_CEMT_RES_WORDS = [
    ("SYSTEM", ("SYSTEM", "SYS")),
    ("DSNAME", ("DSNAME", "DSNAM")),
    ("LIBRARY", ("LIBRARY", "LIBR", "LIB")),
    ("TDQUEUE", ("TDQUEUE", "TDQ")),
    ("TSQUEUE", ("TSQUEUE", "TSQ")),
    ("FILE", ("FILE", "FIL", "DSN")),
    ("PROGRAM", ("PROGRAM", "PROG", "PROG")),
    ("TASK", ("TASK", "TAS")),
    ("TRANSACTION", ("TRANSACTION", "TRAN", "TRANS")),
    ("TERMINAL", ("TERMINAL", "TERM")),
    # DB2CONN is a single-instance resource rendered in the keyword(value)
    # inline format (like SYSTEM), not the fielded table.  Kept last so more
    # specific resources (e.g. DSNAME(DB2X.LOAD)) still win the substring scan.
    ("DB2CONN", ("DB2CONN", "DB2C")),
]


def _cemt_verb(raw: str) -> str:
    """Normalise the CEMT verb word (I->INQUIRE, S->SET, P->PERFORM, D->DISCARD)."""
    parts = (raw or "").split()
    w = parts[1].upper() if len(parts) > 1 and parts[0].upper() == "CEMT" else (parts[0].upper() if parts else "")
    return {"I": "INQUIRE", "INQ": "INQUIRE", "S": "SET", "P": "PERFORM",
            "PERF": "PERFORM", "D": "DISCARD", "DISC": "DISCARD"}.get(w, w or "INQUIRE")


def _cemt_inquiry_target(raw: str):
    uc = (raw or "").upper()
    padded = f" {uc} "
    # A CEMT verb (Inquire/Set/Perform/Discard, or their abbreviations) that
    # names a resource drives a resource panel.  Without a verb it is just the
    # bare-menu case.
    has_verb = ("INQUIRE" in uc or "INQ" in uc or " I " in padded or uc.strip().endswith(" I")
                or " I" in padded
                or "PERFORM" in uc or "DISCARD" in uc
                or " SET " in padded or uc.strip().endswith(" SET") or padded.startswith(" SET ")
                or " S " in padded or " P " in padded or " D " in padded)
    if not has_verb:
        return None
    for res, words in _CEMT_RES_WORDS:
        for w in words:
            if w in uc:
                return res
    return None


def _cemt_status_colour(value: str):
    v = (value or "").upper()
    if any(k in v for k in ("ENABLED", "OPEN", "INSERVICE", "ACTIVE", "ACQUIRED", "RUN")):
        return colors.GREEN
    if any(k in v for k in ("DISABLED", "CLOSED", "OUTSERVICE", "PURGED", "FAILED", "RELEASED")):
        return colors.RED
    if "HELD" in v or "WAIT" in v:
        return colors.YELLOW
    return colors.GREEN
# Additional supervisory / inquiry transactions handled in the 3270 wrapper so
# they produce authentic output instead of "command not recognized".
_EXTRA_TRANS = {"CEOT", "CMAC", "CWTO", "CEST", "CSGM", "CRTE"}
# CMAC message catalogue - the common DFH messages an operator looks up.
_CMAC_MESSAGES = {
    "DFHAC2001": {"text": "Transaction 'tranid' is not recognized. Check and try again.",
                  "explain": "The transaction identifier entered at the terminal is not defined to CICS.",
                  "action": "CICS ignores the input and issues this message. No task is started.",
                  "user": "Check the spelling of the transaction id and re-enter, or use CEDA to define it."},
    "DFHAC2206": {"text": "Transaction 'tranid' has failed with abend 'code'.",
                  "explain": "The named transaction abended. The abend code identifies the failure.",
                  "action": "CICS backs out the unit of work and issues a transaction dump.",
                  "user": "Use CEDF to trace the transaction, or review the dump and CSMT log."},
    "DFHAC2236": {"text": "Transaction 'tranid' cannot run. It is disabled.",
                  "explain": "The transaction is defined but its status is DISABLED.",
                  "action": "The transaction is not started.",
                  "user": "Use CEMT SET TRANSACTION(tranid) ENABLED to enable it."},
    "DFHCE3549": {"text": "Sign-on is required before this transaction can be run.",
                  "explain": "The terminal is not signed on and CICS sign-on security is active.",
                  "action": "The transaction is not started.",
                  "user": "Run CESN to sign on, then re-enter the transaction."},
    "DFHCE3590": {"text": "Sign-off is complete.",
                  "explain": "The CESF transaction signed the terminal off successfully.",
                  "action": "The terminal reverts to the CICS default user.",
                  "user": "None."},
    "DFHCE3553": {"text": "resource-type name SET status.",
                  "explain": "A CEMT SET or CEST command changed the state of the named resource.",
                  "action": "The resource state is updated in the running region.",
                  "user": "None. Use CEMT INQUIRE to confirm the new state."},
    "DFHSN1100": {"text": "Sign-on at terminal termid by user userid.",
                  "explain": "The user signed on successfully via CESN.",
                  "action": "The terminal runs under the signed-on userid.",
                  "user": "None."},
    "DFHPA1104": {"text": "Invalid or unsupported system initialization parameter.",
                  "explain": "A SIT parameter supplied at start-up or via CEMT SET was not valid.",
                  "action": "CICS uses the default value for the parameter.",
                  "user": "Correct the SIT parameter and, if needed, restart the region."},
}

# Map option numbers on the operator menu to direct commands.
_OPMENU_CMD = {
    "1": "CEMT INQUIRE TASK", "2": "CEDA DISPLAY", "3": "CECI",
    "4": "CEDF", "5": "CEBR", "6": "CSMT",
    "7": "SECURITY", "8": "CEMT INQUIRE DB2CONN", "9": "CICS RESOURCE STATUS",
    "10": "DVCA", "11": "OMEN", "12": "HELP",
}

# ASCII block-letter banner for the CICS good-morning (CSGM) screen - the
# region's "GICS" identity.  Rendered centred on the WELCOME panel; the operator
# must press CLEAR to blank it before typing a transaction (authentic DFHGMM).
_GICS_BANNER = [
    " #####  ###  #####   ##### ",
    "#     #  #  #     # #     # ",
    "#        #  #       #       ",
    "#  ####  #  #        #####  ",
    "#     #  #  #             # ",
    "#     #  #  #     # #     # ",
    " #####  ###  #####   #####  ",
]


class Cics3270Session(PanelSession):
    def __init__(self, state, peer_addr: str = "", userid: str = "CICSUSER"):
        self.state = state
        self.peer_addr = peer_addr or ""
        self.cics = CicsSimulator(state, userid)
        self._screen = _GM
        self._message = ""
        self.lines: List[str] = []
        self._scroll: Optional[ScrollList] = None
        self._lab: Optional[str] = None
        self._ceda_aliases: dict = {}   # CEDA-installed RACF-bypass aliases
        self._txn_context: Optional[str] = None  # active bare-transaction menu (CEMT/CEDA/...)

    # ----------------------------------------------------------------- API
    def initial_screen(self) -> ScreenBuffer:
        # When password logon is enabled (CICS AUTH ON), present the CESN
        # sign-on screen first so a terminal (or cicspwn) meets the password
        # field before any transaction can run.
        if getattr(self.state.config, "realistic_cics_auth", False) and not self.cics.signed_on:
            self._screen = _CESN
            return self._cesn_panel("DFHCE3520 SIGN-ON REQUIRED - ENTER USERID AND PASSWORD")
        return self._gm_panel()

    def handle(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if self._screen == _GM:
            if pi.key in ("PF3", "PF15"):
                # PF3 at the good-morning screen clears to a blank CICS entry
                # panel and stays in CICS; it does NOT log the terminal off to
                # VTAM.  nmap cics-enum navigates by sending F3 then CLEAR at
                # the good-morning screen to reach a blank screen - returning
                # None here dropped it back to VTAM, so every transaction probe
                # was typed at the VTAM logon and looked "valid".
                self._screen = _ENTRY
                return self._entry_panel()
            if pi.key == "CLEAR":
                # CLEAR blanks the CSGM good-morning to the entry screen - the
                # authentic gateway to "any transaction or the operator menu".
                self._screen = _ENTRY
                return self._entry_panel()
            # A real terminal user may type a transaction id straight onto the
            # good-morning screen; honour it if present.
            if self._first_command(pi):
                self._screen = _ENTRY
                return self._handle_entry(pi)
            # Bare ENTER (or any other AID) with no transaction: CSGM requires a
            # CLEAR to proceed, so redisplay the good-morning banner rather than
            # silently advancing to the blank screen.
            return self._gm_panel()
        if self._screen == _ENTRY:
            return self._handle_entry(pi)
        if self._screen == _CESN:
            return self._handle_cesn(pi)
        if self._screen == _CECI:
            return self._handle_ceci(pi)
        if self._screen == _CEDA:
            return self._handle_ceda(pi)
        if self._screen == _OPMENU:
            return self._handle_opmenu(pi)
        if self._screen == _RUN:
            return self._handle_run(pi)
        if self._screen == _LAB:
            return self._handle_lab(pi)
        if self._screen == _CEMT:
            return self._handle_cemt(pi)
        if self._screen == _CBTR:
            return self._handle_cbtr(pi)
        return None

    # ------------------------------------------------------------- GM/ENTRY
    def _add_txn(self, p, row: int, col: int, tid: str, base=None) -> int:
        """Render a transaction id with its first two letters in RED (the GIBSON
        convention that marks a transaction as live and usable), the rest in the
        base colour. Returns the column after the id."""
        base = base or colors.GREEN
        tid = tid.upper()
        p.add(Label(row, col, tid[:2], colors.RED))
        if tid[2:]:
            p.add(Label(row, col + 2, tid[2:], base))
        return col + len(tid)

    # Transactions that actually do something in GIBSON's CICS (first two letters
    # shown red on the good-morning legend so readers know what is live).
    _LIVE_TXN_LEGEND = [
        ("CEMT", "master terminal"), ("CEDA", "resource define"),
        ("CECI", "command interp"),  ("CEBR", "TS/TD browse"),
        ("CEDF", "exec debug"),      ("CESN", "sign on"),
        ("CESF", "sign off"),        ("CSMT", "message log"),
        ("COPS", "operator menu"),   ("DVCA", "vault lab"),
        ("CBSA", "bank lab"),        ("OMEN", "OMEN lab"),
    ]

    def _gm_panel(self) -> ScreenBuffer:
        p = Panel(cursor="TRAN")
        p.add(Label(2, 25, "**  WELCOME TO CICS  **", colors.WHITE))
        p.add(Label(4, 20, "Customer Information Control System", colors.TURQUOISE))
        p.add(Label(6, 20, f"Applid . . . : {self._applid()}", colors.GREEN))
        p.add(Label(7, 20, "Release  . . : 0740", colors.GREEN))
        p.add(Label(10, 10, "Clear the screen, then type a transaction id and press ENTER.", colors.GREEN))
        p.add(Label(12, 10, "Examples:  CESN  CEMT I TASK|FILE|PROGRAM|TRANSACTION|TERMINAL", colors.GREEN))
        p.add(Label(13, 10, "           CEDA  CECI  CEBR  CEDF  CEOT  CEST  CMAC  CWTO  CSGM", colors.GREEN))
        p.add(Label(14, 10, "           COPS (operator menu)   DVCA / MCGM (lab)   CESF (sign off)", colors.GREEN))
        p.add(Label(16, 10, "===>", colors.TURQUOISE))
        p.add(Field("TRAN", 16, 15, 32, colour=_TURQ))
        p.pfkeys = "CLEAR ==> blank screen   ENTER ==> run typed transaction   PF3 ==> blank"
        s = p.render()
        s.set_cursor(16, 15)
        return s

    def _entry_panel(self) -> ScreenBuffer:
        p = Panel(cursor="TRAN")
        p.add(Field("TRAN", 1, 1, 32, colour=_TURQ))
        if self._message:
            p.add(Label(23, 2, self._message, colors.YELLOW))
        # Real CICS blanks the entire screen on CLEAR - the operator just sees a
        # cursor and types a transaction id. We deliberately do NOT paint a help
        # footer here: a non-blank cleared screen breaks screen-scraping tools
        # (e.g. nmap cics-enum, whose isClear() check must see an empty screen to
        # proceed to CESF), and the usage hint already lives on the WELCOME/GM
        # screen. Keeping this authentically blank fixes both realism and tooling.
        s = p.render()
        s.set_cursor(1, 1)
        return s

    def _first_command(self, pi: PanelInput, *names: str) -> str:
        """Return the first non-empty input the user gave us.

        Real c3270/x3270 input may land in whichever field the cursor was in,
        and the parser names it from the rendered panel.  To be robust against
        cursor/field-name differences we look at the preferred field names
        first, then fall back to *any* non-empty field on the screen.  This is
        what makes numeric/transaction selections reliable over a live 3270.
        """
        candidates = names or ("TRAN", "OPTION", "COMMAND", "CMD", "ZCMD")
        for n in candidates:
            v = pi.stripped(n)
            if v:
                return v
        for v in (pi.fields or {}).values():
            if v and v.strip():
                return v.strip()
        return ""

    def _handle_entry(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15"):
            if self._txn_context:
                # Inside a transaction (e.g. the CEMT menu), PF3 ends it and
                # returns a blank CICS screen - authentic CICS.
                self._txn_context = None
                self._message = ""
                return self._entry_panel()
            # A PF-key AID with no transaction is 'not recognized' at the CICS
            # entry - authentic CICS, and what cicspwn's check_valid_applid keys
            # on to confirm it reached a CICS terminal (DFHAC2001).
            self._message = (f"DFHAC2001 {self._now()} Transaction 'PF3 ' is not "
                             f"recognized. Check and try again.")
            return self._entry_panel()
        if pi.key == "CLEAR":
            self._txn_context = None
            self._message = ""
            return self._entry_panel()
        raw = self._first_command(pi)
        if not raw:
            # Empty ENTER: redisplay, preserving any existing message (e.g. the
            # DFHAC2001 a preceding PF3 produced).
            return self._entry_panel()
        self._message = ""
        # Conversational transaction context: after a bare CEMT/CEDA/CECI/...
        # menu, a follow-up sub-command ("I TASK", "Inquire", "DISPLAY GROUP(x)")
        # belongs to that transaction, exactly as real CICS keeps CEMT running.
        # A bare transaction id typed at the menu still starts fresh, so
        # cicspwn's availability probing (which types bare ids) is unaffected.
        if self._txn_context:
            ctx = self._txn_context
            self._txn_context = None
            first = raw.split()[0].upper()
            if first not in _CICS_TRANS and first not in _LAB_START and first not in ("COPS", "MENU", "CICS", "SIGNOFF", "LOGOFF"):
                raw = f"{ctx} {raw}"
        transid = raw.split()[0].upper()
        # A CEDA-installed alias runs the target transaction's function but under
        # its own (unprotected) name - the RACF bypass. Resolve it, but keep the
        # typed name for the security check below.
        eff_transid = self._ceda_aliases.get(transid, transid)
        if transid == "CEDA" and "COPY" in raw.upper():
            return self._ceda_copy(raw)
        _locked = getattr(self.state.config, "cics_ceci_racf_locked", False)
        if eff_transid == "CECI" and self._is_ceci_exec(raw):
            if transid in self._ceda_aliases:
                ok, msg = True, ""
            elif _locked:
                ok, msg = False, (f"DFHAC2002 {self._now()} Transaction '{transid[:4]}' "
                                  f"has failed the CICS security check. (RACF TCICSTRN)")
            else:
                ok, msg = self.cics._tx_allowed(transid)
            if not ok:
                self._message = msg
                return self._entry_panel()
            return self._ceci_start(raw)
        # CEMT (or an alias of it): RACF-check the typed name first.
        if eff_transid == "CEMT":
            if transid in self._ceda_aliases:
                ok, msg = True, ""
            elif _locked:
                ok, msg = False, (f"DFHAC2002 {self._now()} Transaction '{transid[:4]}' "
                                  f"has failed the CICS security check. (RACF TCICSTRN)")
            else:
                ok, msg = self.cics._tx_allowed(transid)
            if not ok:
                self._message = msg
                return self._entry_panel()
            res = _cemt_inquiry_target("CEMT " + raw.split(None, 1)[1] if len(raw.split(None, 1)) > 1 else "CEMT")
            if res == "TSQUEUE":
                return self._cemt_tsq_panel(self._cemt_name_in(raw) or "*")
            if res in ("SYSTEM", "DSNAME", "LIBRARY", "TDQUEUE", "DB2CONN"):
                return self._cemt_kv_panel(res, raw)
            if res:
                verb = _cemt_verb(raw)
                name = self._cemt_name_in(raw)
                if verb in ("SET", "PERFORM"):
                    try:
                        applied = self.cics.execute(raw if raw.upper().startswith("CEMT") else "CEMT " + raw)
                        dfh = next((ln.strip() for ln in (applied or "").splitlines()
                                    if ln.strip().startswith("DFH")), "")
                        self._message = ("NORMAL  " + dfh).strip()
                    except Exception:
                        self._message = "NORMAL"
                return self._cemt_panel(res, verb, name=name)
        # Bare supplied-transaction interface screens.  cicspwn detects which
        # transactions are available by typing the bare id and scraping a fixed
        # row (CEMT->Inquire r5, CEDA->ALter r5, CECI/CECS->ACquire r5, CEBR r2).
        # Inquiry/exec/COPY forms were already handled above, so only bare forms
        # reach here.  A row-1 command field keeps the next probe typable.
        if transid in ("CEMT", "CECI", "CECS", "CEDA", "CEBR", "CEDF"):
            # CEMT drill-down: a verb with no resource ("CEMT INQUIRE", or just
            # "INQUIRE" typed on the bare CEMT menu) lists the resources that
            # verb accepts, exactly as real CEMT does, and keeps the verb as the
            # transaction context so the next word ("TASK") completes it.  A
            # bare CEMT still shows the verb menu, so cicspwn's row-5 "Inquire"
            # availability scrape is unchanged.
            if transid == "CEMT":
                _parts = raw.split(None, 1)
                _rest = _parts[1].strip().upper() if len(_parts) > 1 else ""
                if _rest and _rest.split()[0] in ("I", "INQ", "INQUIRE", "S", "SET",
                                                  "P", "PERF", "PERFORM",
                                                  "D", "DISC", "DISCARD"):
                    return self._cemt_resource_menu(_cemt_verb(raw))
            # A supplied sub-command (CEDA DISPLAY/DEFINE/ALTER..., CEBR queue,
            # CEDF args) is processed by the backend transaction; only a bare id
            # shows the menu.  CEMT/CECI/CECS reach here only when bare (their
            # inquiry/exec/set forms were handled above).
            _args = raw.split(None, 1)
            if len(_args) > 1 and _args[1].strip() and transid in ("CEDA", "CEBR", "CEDF"):
                return self._run_command(raw)
            # Bare CEBR goes straight to the temporary-storage browse, as real
            # CICS does (and where cicspwn expects "ENTER COMMAND").
            if transid == "CEBR":
                return self._run_command("CEBR")
            return self._cics_txn_interface(transid)
        if transid in ("CESN", "CESL"):
            # Both CESN and CESL are CICS sign-on transactions (matching GIBSON's
            # own LOGON_TRANSACTION model and nmap cics-user-enum's default).
            self._screen = _CESN
            return self._cesn_panel()
        if transid in ("CESF", "LOGOFF", "SIGNOFF"):
            out = self.cics.execute("CESF")
            # Real CICS paints the sign-off confirmation (DFHCE3590 Sign-off is
            # complete.) on the screen. Returning the WELCOME/GM panel here
            # discarded it, so screen-scrapers - and nmap cics-enum's cics_test,
            # which confirms CICS by finding "off is complete." - never saw it.
            self._screen = _ENTRY
            line = ""
            for ln in (out or "").splitlines():
                if ln.strip():
                    line = ln.strip()
            self._message = line or "DFHCE3590 Sign-off is complete."
            return self._entry_panel()
        if transid in ("COPS", "MENU", "CICS"):
            self._screen = _OPMENU
            return self.cics.build_fielded_panel("CICS_OPERATOR_MAIN")
        if transid == "CSGM":  # good-morning transaction -> redisplay the GM screen
            self._screen = _GM
            return self._gm_panel()
        if transid == "CBTR":  # CBSA fielded transfer-approval lab (hack3270 target)
            self._screen = _CBTR
            from gibson.apps.cbsa.transfer_lab import transfer_buffer
            return transfer_buffer(self.state, self.cics.userid)
        if transid in ("COVR", "GCOV"):  # live in-sim CICS coverage self-test
            return self._run_coverage()
        if transid in _LAB_START:
            return self._start_lab(raw)
        if transid == "CEMT":
            res = _cemt_inquiry_target(raw)
            if res == "TSQUEUE":
                return self._cemt_tsq_panel(self._cemt_name_in(raw) or "*")
            if res in ("SYSTEM", "DSNAME", "LIBRARY", "TDQUEUE", "DB2CONN"):
                return self._cemt_kv_panel(res, raw)
            if res:
                return self._cemt_panel(res, _cemt_verb(raw))
        if transid == "CECI" and self._is_ceci_exec(raw):
            return self._ceci_start(raw)
        if transid in _EXTRA_TRANS or transid in _EXEC_TRANS:
            return self._run_command(raw)
        # Unknown transaction id -> authentic CICS message on the cleared screen.
        self._message = f"DFHAC2001 {self._now()} Transaction '{transid[:4]}' is not recognized. Check and try again."
        return self._entry_panel()

    # --------------------------------------------------------------- CESN
    def _cesn_panel(self, message: str = "") -> ScreenBuffer:
        p = Panel(cursor="USERID")
        p.add(Label(1, 1, "Signon to CICS                                 APPLID  " + self._applid(), colors.BLUE))
        p.add(Label(4, 2, "Type your userid and password, then press ENTER:", colors.GREEN))
        p.add(Label(7, 2, "Userid . . . .", colors.GREEN))
        p.add(Field("USERID", 7, 18, 8, colour=_TURQ))
        p.add(Label(8, 2, "Password . . .", colors.GREEN))
        p.add(Field("PASSWORD", 8, 18, 8, hidden=True, colour=_TURQ))
        p.add(Label(9, 2, "New Password .", colors.GREEN))
        p.add(Field("NEWPW", 9, 18, 8, hidden=True, colour=_TURQ))
        if message:
            p.add(Label(12, 2, message, colors.YELLOW))
        p.pfkeys = "PF3 ==> Cancel"
        return p.render()

    def _handle_cesn(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15"):
            # Cancel signon -> the CICS good-morning (unauthenticated, CICSUSER).
            # Routing to the good-morning (not the blank entry) means an
            # unauthenticated client that PF3s past the signon lands in exactly
            # the same flow as when CICS security is off, so nmap cics-info
            # (Signon->PF3->GM->CLEAR->CESF) still works with security on.
            self._screen = _GM
            return self._gm_panel()
        userid = pi.stripped("USERID").upper()
        password = pi.stripped("PASSWORD")
        if not userid:
            return self._cesn_panel("DFHCE3501 Please type your userid.")
        try:
            self.state.racf.load(merge=True)
        except Exception:
            pass
        if not self.state.racf.exists(userid):
            # Unknown userid -> DFHCE3530.  A real ESM distinguishes an unknown
            # userid from a valid userid awaiting a password (DFHCE3523); nmap
            # cics-user-enum keys on exactly that difference.  GIBSON is a
            # deliberately-enumerable training target, so it makes the same
            # distinction rather than masking it behind one generic message.
            try:
                self.state.record_security_event(userid, "SIGNON", "USERID NOT KNOWN",
                                                  result="FAILURE", service="CICS", addr=self.peer_addr, terminal="3270")
            except Exception:
                pass
            return self._cesn_panel(f"DFHCE3530 The signon userid {userid} is not valid.")
        if not password:
            # Valid userid, no password yet -> DFHCE3523 "Please type your
            # password."  This is the password prompt for a known userid.
            return self._cesn_panel("DFHCE3523 Please type your password.")
        if not self.state.racf.verify_password(userid, password):
            try:
                self.state.record_security_event(userid, "SIGNON", "AUTHENTICATION FAILED",
                                                  result="FAILURE", service="CICS", addr=self.peer_addr, terminal="3270")
            except Exception:
                pass
            return self._cesn_panel("DFHCE3520 Your signon could not be validated. Please re-enter.")
        rec = self.state.racf.get(userid)
        if rec is not None and getattr(rec, "revoked", False):
            return self._cesn_panel(f"DFHCE3530 Userid {userid} is revoked.")
        # success
        self.cics.userid = userid
        self.cics.signed_on = True
        try:
            self.cics.region.signon(userid)
        except Exception:
            pass
        try:
            self.state.record_security_event(userid, "SIGNON", "PASSWORD",
                                              result="SUCCESS", service="CICS", addr=self.peer_addr, terminal="3270")
        except Exception:
            pass
        self._screen = _ENTRY
        self._message = f"DFHCE3549 Sign-on is complete (Language ENU). Userid {userid}."
        return self._entry_panel()

    # ------------------------------------------------------------- CECI XI
    # A real CECI command-level interpreter.  cicspwn (and PHOSPHOR's cics
    # posture module) drive it: type "CECI <verb> OPT(&VAR)...", ENTER to
    # interpret, ENTER again to execute (binding &VARs to real values), then
    # PF5 to read the variables screen (values at column 24, rows 6+).
    _CECI_VERBS = {"ASSIGN", "READ", "WRITE", "READQ", "WRITEQ", "INQUIRE",
                   "LINK", "SEND", "DELETEQ", "STARTBR", "READNEXT",
                   "SPOOLOPEN", "SPOOLWRITE", "SPOOLCLOSE"}

    def _is_ceci_exec(self, raw: str) -> bool:
        parts = raw.split()
        return len(parts) >= 2 and parts[1].upper() in self._CECI_VERBS

    def _ceci_start(self, raw: str, fresh: bool = True) -> ScreenBuffer:
        import re
        parts = raw.split(None, 1)
        cmd = parts[1].strip() if len(parts) > 1 else ""
        self._ceci_cmd = cmd
        self._ceci_verb = (cmd.split() or [""])[0].upper()
        # &VAR operands (KEYWORD(&VAR)), in command order
        self._ceci_vars = [(m.group(1).upper(), m.group(2))
                           for m in re.finditer(r"(\w+)\(&(\w+)\)", cmd)]
        # value operands KEYWORD(value) where value is not a &variable
        self._ceci_opts = {m.group(1).upper(): m.group(2).strip("'\" ")
                           for m in re.finditer(r"(\w+)\(([^&)][^)]*)\)", cmd)}
        # bare flags (GTE, EQUAL, ...)
        self._ceci_flags = {w.upper() for w in cmd.split() if "(" not in w}
        # the INTO/SET variable is the one whose record we can expand (PF5+ENTER)
        self._ceci_into_var = None
        self._ceci_into_is_source = False
        for kw, var in self._ceci_vars:
            if kw in ("INTO", "SET", "FROM"):
                self._ceci_into_var = var
                # FROM is a source the driver fills (SPOOLWRITE); INTO/SET are
                # sinks a command populates (READ). Only sinks auto-expand.
                self._ceci_into_is_source = (kw == "FROM")
        # Working-storage variables persist across commands within one CECI
        # session (real CECI behaviour) - only a fresh entry clears them, so a
        # value typed on the vars screen survives until a later SPOOLWRITE reads it.
        if fresh or not hasattr(self, "_ceci_values"):
            self._ceci_values = {}
        self._ceci_response = None
        self._ceci_phase = "interpret"
        self._screen = _CECI
        return self._ceci_interpret_panel()

    def _handle_ceci(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        import re
        if pi.key in ("PF3", "PF15"):
            self._screen = _ENTRY
            return self._entry_panel()
        if pi.key in ("PF5", "F5"):
            if self._ceci_phase == "interpret":
                self._ceci_execute()
            self._ceci_phase = "vars"
            return self._ceci_vars_panel()
        # (0) a new command overtyped on the row-1 command line -> re-interpret,
        # preserving working-storage variables (this is how cicspwn issues its
        # successive SPOOLWRITE/SPOOLCLOSE within one session).
        newcmd = self._first_command(pi, "CMD").strip()
        if newcmd.upper().startswith("EXEC CICS "):
            newcmd = newcmd[10:].strip()
        if newcmd:
            verb = (newcmd.split() or [""])[0].upper()
            # A genuinely new/edited command re-interprets; a plain ENTER that
            # merely re-submits the same command executes it (real CECI). The
            # 80-column command line truncates long commands (e.g. cicspwn's
            # SPOOLOPEN), so treat a truncated prefix of the current command as
            # the same command rather than a new one.
            _norm = lambda s: re.sub(r"\s+", " ", s.strip()).upper()
            _nc, _oc = _norm(newcmd), _norm(self._ceci_cmd)
            _same = (_nc == _oc) or (_oc.startswith(_nc)) or (_nc.startswith(_oc))
            if verb in self._CECI_VERBS and not _same:
                return self._ceci_start("X " + newcmd, fresh=False)
        # (1) variable definition / expansion on the vars screen
        if self._ceci_phase == "vars":
            vardef = self._first_command(pi, "VARDEF").strip()
            m = re.match(r"&(\w+)\s+\+?0*(\d+)", vardef)
            if m:
                name = m.group(1).upper()
                if getattr(self, "_ceci_pending_var", None) == name:
                    # Second consecutive ENTER with the same "&name +len" still in
                    # the VARDEF field -> expand it for editing. This is how a
                    # screen-driver (cicspwn) reaches the edit field on every
                    # record, whether or not the variable already existed.
                    self._ceci_pending_var = None
                    self._ceci_editvar = name
                    self._ceci_lastdef = ""
                    self._ceci_phase = "editvar"
                    return self._ceci_var_edit_panel(name)
                # First "&name +len": (re)define -> reset value, mark pending,
                # stay on the vars screen.
                self._ceci_values[name] = ""
                self._ceci_pending_var = name
                self._ceci_lastdef = vardef
                return self._ceci_vars_panel()
            if getattr(self, "_ceci_pending_var", None):    # 2nd ENTER after define
                name = self._ceci_pending_var
                self._ceci_pending_var = None
                self._ceci_editvar = name
                self._ceci_lastdef = ""
                self._ceci_phase = "editvar"
                return self._ceci_var_edit_panel(name)
            if (self._ceci_into_var and not getattr(self, "_ceci_into_is_source", False)
                    and self._ceci_values.get(self._ceci_into_var)):
                self._ceci_phase = "expand"
                return self._ceci_expand_panel(self._ceci_into_var)
            # An ENTER on the vars screen with nothing to define/expand stays on
            # the vars screen (real CECI), so a screen-driver like cicspwn can
            # clear the VARDEF line, ENTER, then type "&name <len>" and ENTER
            # again to define its variable without the panel dropping away.
            return self._ceci_vars_panel()
        # (2) capture the JCL/data typed into an expanded variable
        if self._ceci_phase == "editvar" and getattr(self, "_ceci_editvar", None):
            self._ceci_values[self._ceci_editvar] = self._ceci_capture_edit(pi)
            self._ceci_phase = "executed"
            return self._ceci_executed_panel()
        # (3) normal interpret -> execute
        if self._ceci_phase == "interpret":
            self._ceci_execute()
            self._ceci_phase = "executed"
            return self._ceci_executed_panel()
        return self._ceci_executed_panel()

    def _ceci_capture_edit(self, pi: PanelInput) -> str:
        """Reassemble the data typed into an expanded variable's edit fields
        (col 11, rows 3+, 64 chars per row)."""
        parts = []
        for r in range(3, 22):
            v = ""
            if pi.fields:
                v = (pi.fields.get(f"E{r}") or "")
            parts.append(v)
        return "".join(parts).rstrip()

    def _ceci_var_edit_panel(self, var: str) -> ScreenBuffer:
        """Editable expansion of a variable: 64-char input fields at col 11 from
        row 3, matching where cicspwn types each JCL chunk."""
        val = str(self._ceci_values.get(var, ""))
        p = Panel(cursor="E3")
        p.add(Field("CMD", 1, 1, 74, value=f"EXPAND &{var}  LENGTH {len(val):05d}", colour=_TURQ))
        row, off = 3, 0
        while row < 22:
            piece = val[off:off + 64]
            p.add(Field(f"E{row}", row, 10, 64, value=piece, colour=colors.GREEN))
            off += 64
            row += 1
            if off >= len(val) and row > 4:
                break
        p.message = f"RESPONSE: {self._ceci_response or 'NORMAL'}"
        p.message_row = 23
        p.pfkeys = "PF3 END  ENTER SAVE"
        _sb = p.render()
        try: _sb.set_cursor(3, 11)   # land on the first JCL edit field (cicspwn types here)
        except Exception: pass
        return _sb

    def _ceci_execute(self) -> None:
        reg = self.cics.region
        verb = self._ceci_verb
        self._ceci_extra = []
        if verb == "ASSIGN":
            for kw, var in self._ceci_vars:
                self._ceci_values[var] = self._ceci_assign_value(kw, reg)
            self._ceci_response = "NORMAL"
        elif verb == "READ":
            self._ceci_read_file(reg)
        elif verb == "READQ":
            self._ceci_read_tsq(reg)
        elif verb in ("SPOOLOPEN", "SPOOLWRITE", "SPOOLCLOSE"):
            self._ceci_spool(verb, reg)
        elif verb == "WRITEQ" and "TD" in self._ceci_flags:
            self._ceci_writeq_td(reg)
        elif verb == "INQUIRE":
            self._ceci_inquire(reg)
        else:
            for kw, var in self._ceci_vars:
                self._ceci_values.setdefault(var, "")
            self._ceci_response = "NORMAL"
        try:
            self._audit_stage("CICS COMMAND EXECUTION",
                              f"CECI EXEC CICS {self._ceci_cmd}",
                              transid="CECI", cls="TCICSTRN")
        except Exception:
            pass

    def _ceci_spool(self, verb: str, reg) -> None:
        """SPOOLOPEN/SPOOLWRITE/SPOOLCLOSE -> the JES internal-reader bridge.
        SPOOLCLOSE submits the accumulated JCL to GIBSON's JES; the job appears
        in SDSF and runs in the sandbox (reverse shells land in the simulated
        TSO/USS shell - real to the student, no arbitrary RCE on the host)."""
        if verb == "SPOOLOPEN":
            if hasattr(reg, "spool_enabled") and not reg.spool_enabled():
                self._ceci_response = "NOTAUTH"
                self._ceci_extra = ["DFHRESP(NOTAUTH) SPOOL INTERFACE DISABLED (SPOOL=NO)"]
                return
            self._spool_buffer = []
            self._spool_token = "GIBSPOOL"
            tok_var = None
            for kw, var in self._ceci_vars:
                if kw == "TOKEN":
                    tok_var = var
            if tok_var:
                self._ceci_values[tok_var] = self._spool_token
            self._ceci_response = "NORMAL"
            # cicspwn reads Token( 'xxxxxxxx' ) off the executed screen
            self._ceci_extra = [f"Token( '{self._spool_token}' )  Userid('INTRDR  ')  Node('LOCAL')"]
        elif verb == "SPOOLWRITE":
            if not hasattr(self, "_spool_buffer"):
                self._spool_buffer = []
            # the FROM value: a &variable set via the vars screen, or a literal
            frm = None
            for kw, var in self._ceci_vars:
                if kw == "FROM":
                    frm = self._ceci_values.get(var, "")
            if not frm:
                frm = self._ceci_opts.get("FROM")
            self._spool_buffer.append(frm if frm else "//* SPOOLWRITE record")
            self._ceci_response = "NORMAL"
        elif verb == "SPOOLCLOSE":
            jcl = "\n".join(getattr(self, "_spool_buffer", []) or [])
            if not jcl.strip():
                # representative reverse-reader job so the submission is visible
                jcl = ("//GIBHACK  JOB (ACCT),'CICSPWN',CLASS=A,MSGCLASS=X\n"
                       "//STEP1    EXEC PGM=IEFBR14\n")
            try:
                job = self.state.jes.submit(jcl, self.cics.userid,
                                            runner=getattr(self.cics, "run", None))
                jobid = getattr(job, "jobid", "JOB00001")
                self._ceci_extra = [f"JCL submitted to internal reader as {jobid}",
                                    "Check SDSF (L SDSF / prefix *) for the job."]
                try:
                    self.cics.region.record_security(
                        self.cics.userid, "CICS SPOOL SUBMIT",
                        f"JCL submitted to JES internal reader as {jobid}",
                        result="WARNING", transid="CECI", resource="INTRDR",
                        cls="TCICSTRN")
                except Exception:
                    pass
            except Exception as exc:
                self._ceci_response = "IOERR"
                self._ceci_extra = [f"JES submit failed: {exc}"]
                return
            self._ceci_response = "NORMAL"

    # Classic internal-reader TD-queue names.  cicspwn defaults to IRDR when no
    # -q is given; real regions commonly use INTR/INTRDR; and a site may CEDA an
    # arbitrarily-named queue whose DESTID maps to the JES internal reader
    # (INTRDR=YES) - all route JCL to the reader.
    _INTRDR_ALIASES = {"IRDR", "INTRDR", "INTR", "INREADER"}

    def _is_internal_reader(self, reg, qname: str) -> bool:
        q = (qname or "").upper()
        if not q:
            return False
        if q in self._INTRDR_ALIASES:
            return True
        res = getattr(reg, "tdqueues", {}).get(q)
        if res is not None and hasattr(res, "attr"):
            return str(res.attr("INTRDR", "NO")).upper() in ("YES", "INTRDR")
        return False

    def _ceci_writeq_td(self, reg) -> None:
        """WRITEQ TD QUEUE(name) - the TD-queue JCL-submission fallback cicspwn
        uses when the spool path is unavailable.  Any queue that maps to the JES
        internal reader (IRDR/INTR/INTRDR/INREADER, or a CEDA-defined queue with
        INTRDR=YES) routes the written record to GIBSON's JES; an undefined queue
        returns QIDERR exactly as real CICS does, so a scraping tool's pre-write
        check behaves authentically."""
        qname = (self._ceci_opts.get("QUEUE") or self._ceci_opts.get("Q") or "").upper()
        frm = None
        for kw, var in self._ceci_vars:
            if kw == "FROM":
                frm = self._ceci_values.get(var, "")
        if self._is_internal_reader(reg, qname):
            jcl = frm or ("//GIBHACK  JOB (ACCT),'CICSPWN',CLASS=A\n"
                          "//STEP1    EXEC PGM=IEFBR14\n")
            try:
                job = self.state.jes.submit(jcl, self.cics.userid,
                                            runner=getattr(self.cics, "run", None))
                jobid = getattr(job, "jobid", "JOB00001")
                self._ceci_extra = [f"Record written to {qname}; job {jobid} queued to internal reader.",
                                    "Check SDSF (L SDSF / prefix *) for the job."]
                self._ceci_response = "NORMAL"
                try:
                    self.cics.region.record_security(
                        self.cics.userid, "CICS TDQ SUBMIT",
                        f"JCL written to internal-reader TDQ {qname}; job {jobid} queued.",
                        result="WARNING", transid="CECI", resource=qname, cls="TCICSTRN")
                except Exception:
                    pass
            except Exception as exc:
                self._ceci_response = "IOERR"
                self._ceci_extra = [f"JES submit failed: {exc}"]
        elif qname and qname not in {q.upper() for q in getattr(reg, "tdqueues", {})}:
            # Undefined queue -> real CICS returns QIDERR; a tool that inquires
            # first (as cicspwn does) reads this rather than a false NORMAL.
            self._ceci_response = "QIDERR"
            self._ceci_extra = [f"DFHRESP(QIDERR) EIBRESP2=1 - TDQUEUE {qname} NOT DEFINED"]
        else:
            # Defined but non-reader queue (e.g. CSMT): normal enqueue, no submit.
            self._ceci_response = "NORMAL"

    # Resource keywords CECI INQUIRE understands, mapped to a canonical name.
    _CECI_INQ_RES = {
        "TDQUEUE": "TDQUEUE", "TDQ": "TDQUEUE", "FILE": "FILE", "FI": "FILE",
        "PROGRAM": "PROGRAM", "PROG": "PROGRAM", "TRANSACTION": "TRANSACTION",
        "TRANS": "TRANSACTION", "TERMINAL": "TERMINAL", "TERM": "TERMINAL",
        "TSQUEUE": "TSQUEUE", "TSQ": "TSQUEUE", "TASK": "TASK",
        "SYSTEM": "SYSTEM", "CONNECTION": "CONNECTION", "CONN": "CONNECTION",
    }

    def _ceci_inquire(self, reg) -> None:
        """EXEC CICS INQUIRE <resource>(name) via CECI.

        Real CECI runs the INQUIRE and paints the returned resource attributes on
        the command screen; GIBSON previously fell through to a bare NORMAL with
        no data, so a screen-scraper (cicspwn's TDQueue/file pre-checks) and a
        human alike saw an empty result (just 'NAME=' and '===>').  Populate the
        authentic attribute lines - and any receiving CECI &variables - so the
        INQUIRE actually reports state read from the live region."""
        res, name = "", ""
        for kw, val in self._ceci_opts.items():
            if kw in self._CECI_INQ_RES:
                res, name = self._CECI_INQ_RES[kw], val
                break
        nm = (name or "").upper()

        def setvar(kw, value):
            for k, var in self._ceci_vars:
                if k == kw:
                    self._ceci_values[var] = value

        if res == "TDQUEUE":
            defined = self._is_internal_reader(reg, nm) or \
                nm in {q.upper() for q in getattr(reg, "tdqueues", {})}
            if defined:
                intr = self._is_internal_reader(reg, nm)
                self._ceci_response = "NORMAL"
                self._ceci_extra = [
                    f"Tdqueue({nm:<8})  Type(Extra)  Openstatus(Open)  Enablestatus(Enabled)",
                    "Atifacility(Notapplic)  Recovstatus(Notrecoverable)  Numitems(+0000000000)",
                    (f"Ddname(INTRDR  )  Indirectname()  Remotename()  Remotesystem()"
                     if intr else "Ddname()  Indirectname()  Remotename()"),
                ]
                setvar("TYPE", "EXTRA")
                setvar("OPENSTATUS", "OPEN")
                setvar("ENABLESTATUS", "ENABLED")
                setvar("DDNAME", "INTRDR" if intr else "")
                setvar("NUMITEMS", "0")
            else:
                self._ceci_response = "QIDERR"
                self._ceci_extra = [f"DFHRESP(QIDERR) EIBRESP=44 EIBRESP2=1 - TDQUEUE {nm} NOT DEFINED"]
        elif res == "FILE":
            files = getattr(reg, "files", {})
            f = files.get(nm) if isinstance(files, dict) else None
            if f is not None:
                def fa(k, d):
                    try:
                        v = f.attr(k, d) if hasattr(f, "attr") else d
                    except Exception:
                        v = d
                    return str(v) if v not in (None, "") else d
                rsize = int(fa("RECORDSIZE", "80") or 80)
                klen = int(fa("KEYLENGTH", "0") or 0)
                kpos = int(fa("KEYPOSITION", "0") or 0)
                ftype = (fa("TYPE", "KSDS") or "KSDS").title()
                dsn = fa("DSN", f"CICS.{nm}")
                openst = "Open" if getattr(f, "open_state", "OPEN") == "OPEN" else "Closed"
                enast = "Enabled" if getattr(f, "status", "ENABLED") == "ENABLED" else "Disabled"
                self._ceci_response = "NORMAL"
                self._ceci_extra = [
                    f"File({nm:<8})  Openstatus({openst})  Enablestatus({enast})  Type({ftype})",
                    f"Recordsize({rsize:05d})  Keylength({klen:03d})  Keyposition({kpos:03d})  "
                    f"Recordformat({(fa('RECORDFORMAT','FIXED') or 'FIXED').title()})",
                    "Add(Yes)  Browse(Yes)  Delete(Yes)  Read(Yes)  Update(Yes)  Recovstatus(Notrecoverable)",
                    f"Dsname({dsn})",
                ]
                setvar("RECORDSIZE", str(rsize))
                setvar("KEYLENGTH", str(klen))
                setvar("KEYPOSITION", str(kpos))
                setvar("OPENSTATUS", openst.upper())
                setvar("ENABLESTATUS", enast.upper())
                setvar("DSNAME", dsn)
            else:
                self._ceci_response = "FILENOTFOUND"
                self._ceci_extra = [f"DFHRESP(FILENOTFOUND) EIBRESP=12 - FILE {nm} NOT DEFINED"]
        elif res:
            # Other resources: acknowledge with a populated, non-blank result so
            # the executed screen mirrors real CECI rather than showing nothing.
            self._ceci_response = "NORMAL"
            self._ceci_extra = [f"{res.title()}({nm})  Enablestatus(Enabled)  Status(Normal)"]
        else:
            # INQUIRE with no recognised resource keyword - browse-start form.
            self._ceci_response = "NORMAL"
            self._ceci_extra = ["INQUIRE browse started - specify a resource keyword to filter."]

    def _ceci_read_file(self, reg) -> None:
        fname = (self._ceci_opts.get("FILE") or self._ceci_opts.get("FI") or "").upper()
        ridfld = (self._ceci_opts.get("RIDFLD") or self._ceci_opts.get("RI") or "")
        gte = "GTE" in self._ceci_flags
        recs = list(getattr(reg, "file_records", {}).get(fname, []))
        rec = None
        klen = len(ridfld) if ridfld else 6
        for r in recs:
            key = r[:klen]
            if not ridfld or (key >= ridfld if gte else key == ridfld):
                rec = r
                break
        var = self._ceci_into_var or (self._ceci_vars[0][1] if self._ceci_vars else "FI")
        if rec is None:
            self._ceci_response = "NOTFND"
            self._ceci_values[var] = ""
        else:
            self._ceci_response = "NORMAL"
            self._ceci_values[var] = rec

    def _ceci_read_tsq(self, reg) -> None:
        qname = (self._ceci_opts.get("QUEUE") or self._ceci_opts.get("Q") or "").upper()
        item = self._ceci_opts.get("ITEM")
        var = self._ceci_into_var or (self._ceci_vars[0][1] if self._ceci_vars else "FI")
        try:
            items = reg.read_tsq(qname) if hasattr(reg, "read_tsq") else []
        except Exception:
            items = []
        if not items:
            self._ceci_response = "QIDERR"
            self._ceci_values[var] = ""
            return
        idx = (int(item) - 1) if (item and str(item).isdigit()) else 0
        if 0 <= idx < len(items):
            self._ceci_response = "NORMAL"
            self._ceci_values[var] = items[idx]
        else:
            self._ceci_response = "ITEMERR"
            self._ceci_values[var] = ""

    def _ceci_expand_panel(self, var: str) -> ScreenBuffer:
        # Expand a variable's full value in offset lines: cols 1-5 hold a "+00NN"
        # marker and the data begins at column 11 (index 10), so a scraper reading
        # data[row][10:] on lines containing "+00" reassembles the record exactly.
        val = str(self._ceci_values.get(var, ""))
        p = Panel()
        p.add(Label(1, 2, f"EXPANDED VARIABLE &{var}   LENGTH {len(val):05d}", colors.BLUE))
        row, n, off = 3, 0, 0
        chunk = 68            # seed records fit on one line -> no split artifact
        while off < max(1, len(val)) and row < 22 and n < 100:
            piece = val[off:off + chunk]
            # marker in cols 1-6; data field attribute at col 10 so the record
            # text lands at column 11 (index 10) - a scraper reads d[10:] clean.
            p.add(Label(row, 1, f"+00{n:02d}", _TURQ))
            p.add(Label(row, 10, piece, colors.GREEN))
            off += chunk
            row += 1
            n += 1
        p.message = f"RESPONSE: {self._ceci_response or 'NORMAL'}"
        p.message_row = 23
        p.pfkeys = "PF3 END  ENTER CONTINUE"
        return p.render()

    def _ceci_assign_value(self, kw: str, reg) -> str:
        kw = kw.upper()
        dflt = reg.security_options.get("DFLTUSER", "CICSUSER")
        if kw.startswith("USER"):
            return (getattr(self.cics, "userid", "") or dflt).upper()
        if kw.startswith("SYS"):
            return getattr(reg, "sysid", "GIB1")
        if kw.startswith("APPL"):
            return self._applid()
        if kw.startswith("NET"):
            return "LU320"                      # bound terminal LU
        if kw.startswith("NAT"):
            return "E"                          # NATLANGINUSE (English)
        if kw.startswith("PRIN") or kw.startswith("OPER"):
            return dflt.upper()
        return ""

    def _ceci_interpret_panel(self) -> ScreenBuffer:
        p = Panel()
        p.add(Field("CMD", 1, 1, 74, value=f"EXEC CICS {self._ceci_cmd}"[:74], colour=_TURQ))
        p.add(Label(3, 2, "STATUS:  ABOUT TO EXECUTE COMMAND", colors.GREEN))
        p.add(Label(5, 2, "NAME=", colors.BLUE))
        p.pfkeys = ("PF3 END  PF4 EIB  PF5 VAR  PF6 USER  PF9 MSG  "
                    "ENTER CONTINUE")
        return p.render()

    def _ceci_executed_panel(self) -> ScreenBuffer:
        p = Panel()
        p.add(Field("CMD", 1, 1, 74, value=f"EXEC CICS {self._ceci_cmd}"[:74], colour=_TURQ))
        p.add(Label(3, 2, "STATUS:  COMMAND EXECUTION COMPLETE", colors.GREEN))
        p.add(Label(5, 2, "NAME=", colors.BLUE))
        r = 6
        for line in getattr(self, "_ceci_extra", []) or []:
            if r > 20:
                break
            p.add(Label(r, 2, str(line)[:76], colors.GREEN))
            r += 1
        p.message = f"RESPONSE: {self._ceci_response or 'NORMAL'}   EIBRESP=0 EIBRESP2=0"
        p.message_row = 23
        p.pfkeys = "PF3 END  PF4 EIB  PF5 VAR  PF6 USER  PF9 MSG  ENTER CONTINUE"
        return p.render()

    def _ceci_vars_panel(self) -> ScreenBuffer:
        # The variables (working storage) screen.  Each &VAR on its own row from
        # row 6, with the VALUE at column 24 (0-based index 23) so screen-scrapers
        # read data[row][23:] exactly like real CECI.  Cursor lands on the VARDEF
        # line so a screen-driver (cicspwn) types "&name <len>" there directly.
        p = Panel(cursor="VARDEF")
        p.add(Field("CMD", 1, 1, 74, value="INTERACTIVE VARIABLES", colour=_TURQ))
        p.add(Label(4, 2, "NAME", colors.GREEN))
        p.add(Label(4, 24, "DATA", colors.GREEN))
        row = 6
        for kw, var in self._ceci_vars:
            val = self._ceci_values.get(var, "")
            p.add(Label(row, 2, f"&{var}"[:20], _TURQ))
            p.add(Label(row, 24, str(val)[:54], colors.GREEN))
            row += 1
        # Free line to define a new variable (&name length).  For a single-var
        # command (SPOOLOPEN -> &TOKTEST at row 6) this lands at row 7, exactly
        # where cicspwn types "&sqlkhds  <len>"; multi-var commands (ASSIGN) keep
        # all their values on rows 6+ and push this harmlessly lower.
        _vdrow = max(row, 7)
        p.add(Field("VARDEF", _vdrow, 1, 60,
                    value=getattr(self, "_ceci_lastdef", ""), colour=_TURQ))
        p.message = f"RESPONSE: {self._ceci_response or 'NORMAL'}   EIBRESP=0 EIBRESP2=0"
        p.message_row = 23
        p.pfkeys = "PF3 END  PF2 HEX  PF9 MSG  ENTER CONTINUE"
        _sb = p.render()
        try: _sb.set_cursor(_vdrow, 2)   # land on the VARDEF input (cicspwn types here)
        except Exception: pass
        return _sb

    # ------------------------------------------------------------- CEDA XI
    # CEDA COPY <tran> AS <new> then INSTALL — the RACF bypass: the copied
    # transaction runs the original's program under a new name that has no RACF
    # profile, so a caller blocked from CECI/CEMT reaches them via CSPK/CSPS.
    def _ceda_copy(self, raw: str) -> ScreenBuffer:
        import re
        uc = raw.upper()
        old = (re.search(r"TRANS?\(([^)]+)\)", uc) or [None, ""])[1].strip()
        new = (re.search(r"AS\(([^)]+)\)", uc) or [None, ""])[1].strip()
        grp = (re.search(r"TO\(([^)]+)\)", uc) or [None, ""])[1].strip() or "GIBGRP"
        self._ceda_pending = (old, new, grp)
        self._screen = _CEDA
        if new and new in self._ceda_aliases:
            msg = f"E {new} already exists in group {grp}"
        elif old and new:
            msg = f"COPY SUCCESSFUL. {old} copied to {new} in group {grp}."
        else:
            msg = "E COPY requires TRANS(x) AS(y)"
        return self._ceda_panel(f"CEDA COPY TRANS({old}) AS({new}) TO({grp})", msg)

    def _handle_ceda(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15"):
            self._screen = _ENTRY
            return self._entry_panel()
        cmd = self._first_command(pi, "CMD", "OPTION", "COMMAND").upper()
        if cmd.startswith("INSTALL"):
            import re
            new = (re.search(r"TRANS?\(([^)]+)\)", cmd) or [None, ""])[1].strip()
            old, pend_new, grp = getattr(self, "_ceda_pending", ("", "", ""))
            target = pend_new or new
            if target and old:
                # register the alias -> the copied transaction now runs `old`
                self._ceda_aliases[target] = old
                try:
                    self.cics.region.record_security(
                        self.cics.userid, "CEDA INSTALL",
                        f"{old} installed as {target} (RACF profile bypass)",
                        result="WARNING", transid="CEDA", resource=target,
                        cls="CCICSCMD")
                except Exception:
                    pass
                return self._ceda_panel(f"INSTALL TRANS({target}) GROUP({grp})",
                                        f"INSTALL SUCCESSFUL. {target} installed.")
            return self._ceda_panel("INSTALL", "E INSTALL requires TRANS(x)")
        return self._ceda_panel(cmd or "CEDA", "Enter INSTALL TRANS(x) GROUP(y), or PF3 to end")

    def _ceda_panel(self, echo: str, message: str) -> ScreenBuffer:
        s = ScreenBuffer()
        s.extended_attributes = True
        # Wide rows-1/2 command line: cicspwn types 80-char space-padded CEDA
        # commands (COPY/INSTALL) at (1,2), so the region must be big enough not
        # to overflow into a protected field and lock the keyboard.
        s.add_field("CMD", 1, 1, 158, value="CEDA  Resource Definition Online", colour=_TURQ, role="command")
        s.put(3, 2, echo[:76], _TURQ)
        # ALter appears on the interface so cicspwn's query_cics('CEDA','ALter',5) sees it
        s.put(5, 2, "OBJECTS:  ALter  COpy  DEFine  DELete  DIsplay  INStall  Move",
              colors.GREEN)
        # message on row 21 ("already exists") and row 23 (COPY/INSTALL SUCCESSFUL)
        colour = colors.YELLOW if message.startswith("E ") or "already" in message else colors.GREEN
        if "already" in message:
            s.put(21, 2, message[:76], colour)
        s.put(23, 2, message[:76], colour)
        s.put(24, 1, "PF3=End  ENTER=Process", colors.BLUE)
        s.set_cursor(1, 2)
        return s

    # ------------------------------------------------------------- OPMENU
    # Transactions that may be typed on ANY panel command line to leave the
    # current panel.  CICS keeps the command line live on every screen, so an
    # operator can start CEMT INQUIRE TASK (or any transaction) from inside a
    # menu or an output panel without CLEARing first.
    _GLOBAL_TRANS = (_CICS_TRANS | _EXTRA_TRANS | _LAB_START | _EXEC_TRANS |
                     {"COPS", "COVR", "GCOV", "CESL", "LOGOFF", "MENU", "CICS"})

    def _global_txn_escape(self, pi: PanelInput, text: str) -> Optional[ScreenBuffer]:
        """Dispatch a transaction typed on any panel's command line.

        Previously the operator menu silently redrew itself when the input was
        not one of its numbered options (so "CEMT INQUIRE TASK" appeared to do
        nothing), and output panels ran typed commands through _run_command,
        which produced a plain text echo *and* skipped the transaction-attach
        check.  This routes such input back through _handle_entry - the single
        place that resolves CEDA aliases and enforces _tx_allowed / the RACF
        TCICSTRN check - so reachability improves without weakening
        authorisation: an operator who may not attach CEMT still gets DFHAC2002.

        Returns None when the text is not a transaction, leaving each panel's
        own semantics (menu options, CEMT action characters, CECI command
        editing) untouched.
        """
        if not text:
            return None
        first = text.split()[0].upper()
        if first not in self._GLOBAL_TRANS and first not in self._ceda_aliases:
            return None
        # Start the transaction fresh from the CICS entry, exactly as if the
        # operator had CLEARed and typed it.
        self._txn_context = None
        self._message = ""
        self._screen = _ENTRY
        return self._handle_entry(pi)

    def _handle_opmenu(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15"):
            self._screen = _ENTRY
            return self._entry_panel()
        opt = self._first_command(pi, "OPTION", "TRAN", "COMMAND", "CMD").upper()
        cmd = _OPMENU_CMD.get(opt)
        if not cmd:
            # Not a menu option: honour a transaction typed on the menu's
            # command line (authentic CICS) before falling back to a redraw.
            esc = self._global_txn_escape(pi, opt)
            if esc is not None:
                return esc
            # re-render the menu (optionally with a hint)
            return self.cics.build_fielded_panel("CICS_OPERATOR_MAIN")
        transid = cmd.split()[0].upper()
        # Interactive labs (DVCA / CBSA-OMEN) must start through the lab driver,
        # not run as a one-shot command.
        if transid in _LAB_START:
            return self._start_lab(cmd)
        # CECI selection lands on the authentic bare command-interpreter
        # interface (ACquire/ADDRess/... on row 5, command field on row 1),
        # exactly as typing CECI at the CICS entry screen does - not a one-shot
        # "Transaction: CECI" scroll through _run_command.
        if transid == "CECI":
            # Leave the menu: further input is a CECI sub-option or a freshly
            # typed transaction, not an operator-menu option number.
            self._screen = _ENTRY
            return self._cics_txn_interface("CECI")
        # CEMT inquiries render as the same fielded / keyword(value) panels the
        # entry screen produces, so an operator picking DB2CONN (option 8) or
        # SYSTEM/TDQUEUE etc. gets the real CEMT panel, not a RUN echo.
        if transid == "CEMT":
            res = _cemt_inquiry_target(cmd)
            if res == "TSQUEUE":
                return self._cemt_tsq_panel(self._cemt_name_in(cmd) or "*")
            if res in ("SYSTEM", "DSNAME", "LIBRARY", "TDQUEUE", "DB2CONN"):
                return self._cemt_kv_panel(res, cmd)
            if res:
                return self._cemt_panel(res)
        return self._run_command(cmd)

    # --------------------------------------------------------- COVERAGE (COVR)
    def _run_coverage(self) -> ScreenBuffer:
        """Live in-sim CICS coverage transaction (COVR / GCOV).

        Drives every major CICS transaction, CEMT inquiry, operator-menu option
        and both JCL-submission paths through *fresh* Cics3270Session instances -
        the real 3270 input handlers, not a mock - and paints a pass/fail report
        in the scrollable output panel.  Each check runs against its own throw-
        away GibsonState, so COVR has no side effects on the operator's live
        region and can be run at any time to confirm the command surface still
        works end to end after a change."""
        from gibson.core.state import GibsonState

        def drive(steps):
            st = GibsonState.create()
            try:
                st.racf.load()
            except Exception:
                pass
            try:
                st.config.realistic_cics_auth = False
            except Exception:
                pass
            sess = Cics3270Session(st, peer_addr=self.peer_addr)
            sess.initial_screen()
            scr = None
            for key, fields in steps:
                scr = sess.handle(PanelInput(aid=0x7D, key=key, fields=dict(fields)))
                if scr is None:
                    return ""      # session ended (e.g. CESF/exit)
            return scr.to_3270().decode("cp037", "ignore").upper() if scr is not None else ""

        def T(tran):       # CLEAR to entry, then type a transaction id
            return [("CLEAR", {}), ("ENTER", {"TRAN": tran})]

        def MENU(opt):     # CLEAR, COPS -> operator menu, then pick an option
            return [("CLEAR", {}), ("ENTER", {"TRAN": "COPS"}), ("ENTER", {"OPTION": opt})]

        def CECI(cmd):     # CLEAR, type CECI command, ENTER to interpret+execute
            return [("CLEAR", {}), ("ENTER", {"TRAN": cmd}), ("ENTER", {})]

        # (label, steps, marker) - marker "" means "non-empty output, no abend".
        checks = [
            ("COPS operator menu",     [("CLEAR", {}), ("ENTER", {"TRAN": "COPS"})], "OPERATOR"),
            ("menu 1  CEMT I TASK",    MENU("1"), "INQUIRE TASK"),
            ("menu 3  CECI interface", MENU("3"), "ACQUIRE"),
            ("menu 8  DB2CONN panel",  MENU("8"), "CONNECTST"),
            ("CEMT I FILE",            T("CEMT I FILE"), "INQUIRE FILE"),
            ("CEMT I PROGRAM",         T("CEMT I PROGRAM"), "INQUIRE PROGRAM"),
            ("CEMT I TRANSACTION",     T("CEMT I TRANSACTION"), "INQUIRE TRANSACTION"),
            ("CEMT I TERMINAL",        T("CEMT I TERMINAL"), "INQUIRE TERMINAL"),
            ("CEMT I SYSTEM",          T("CEMT I SYSTEM"), "CICSTSLEVEL"),
            ("CEMT I TDQUEUE (IRDR)",  T("CEMT I TDQUEUE"), "IRDR"),
            ("CEMT I DB2CONN",         T("CEMT I DB2CONN"), "CONNECTST"),
            ("CEDA (bare)",            T("CEDA"), "ENTER ONE OF"),
            ("CEBR (bare)",            T("CEBR"), ""),
            ("CEDF ,OFF",             T("CEDF ,OFF"), "EDF"),
            ("CSMT",                   T("CSMT"), ""),
            ("CEOT",                   T("CEOT"), "TRANSCEIVE"),
            ("CEST",                   T("CEST"), "SUPERVISORY"),
            ("CMAC DFHAC2001",         T("CMAC DFHAC2001"), "DFHAC2001"),
            ("CWTO HELLO OPS",         T("CWTO HELLO OPS"), "CONSOLE"),
            ("CRTE SYSID=CICB",        T("CRTE SYSID=CICB"), "ROUTING"),
            ("CESN sign-on panel",     T("CESN"), "SIGNON"),
            ("CECI SPOOLOPEN token",   CECI("CECI SPOOLOPEN OUTPUT TOKEN(&T)"), "GIBSPOOL"),
            ("CECI WRITEQ TD IRDR",    CECI("CECI WRITEQ TD QUEUE(IRDR) FROM(&J)"), "QUEUED"),
            ("CECI INQ TDQUEUE IRDR",  CECI("CECI INQUIRE TDQUEUE(IRDR)"), "DDNAME(INTRDR"),
            ("CECI INQ FILE FILEA",    CECI("CECI INQUIRE FILE(FILEA)"), "KEYLENGTH"),
            ("menu cmdline CEMT I TASK", MENU("CEMT INQUIRE TASK"), "INQUIRE TASK"),
            ("CEMT drill-down 3-step", [("CLEAR", {}), ("ENTER", {"TRAN": "CEMT"}),
                                        ("ENTER", {"TRAN": "INQUIRE"}),
                                        ("ENTER", {"TRAN": "TASK"})], "INQUIRE TASK"),
            ("CEMT verb->resource list", [("CLEAR", {}), ("ENTER", {"TRAN": "CEMT"}),
                                          ("ENTER", {"TRAN": "INQUIRE"})], "AUTOINSTALL"),
            ("menu cmdline CECI",       MENU("CECI"), "ACQUIRE"),
            ("unknown transid ZZZZ",   T("ZZZZ"), "DFHAC2001"),
            ("DVCA lab starts",        T("DVCA"), "DVCA"),
            ("OMEN lab starts",        T("OMEN"), ""),
            ("CSGM requires CLEAR",    [("ENTER", {})], "WELCOME TO CICS"),
        ]

        results, npass = [], 0
        for label, steps, marker in checks:
            try:
                out = drive(steps)
                ok = (marker.upper() in out) if marker else (bool(out.strip()) and "ABEND" not in out)
            except Exception as exc:
                ok, out = False, f"EXC {exc}"
            npass += 1 if ok else 0
            results.append((ok, label, marker))

        n = len(checks)
        self.lines = [
            f"GICS CICS COVERAGE   {self._now()}   applid {self._applid()}",
            f"Live self-test of the CICS command surface - {n} checks, isolated state.",
            "-" * 74,
        ]
        for ok, label, marker in results:
            arrow = f"-> {marker}" if marker else "-> (non-empty, no abend)"
            self.lines.append(f"[{'OK  ' if ok else 'FAIL'}] {label:<26} {arrow}")
        self.lines.append("-" * 74)
        verdict = "ALL CHECKS PASSED" if npass == n else f"{n - npass} CHECK(S) FAILED"
        self.lines.append(f"PASSED {npass}/{n}   {verdict}")
        self._scroll = None
        self._screen = _RUN
        return self._run_panel(to_bottom=False)

    # --------------------------------------------------------------- RUN
    def _run_command(self, command: str) -> ScreenBuffer:
        transid = command.split()[0].upper() if command.split() else ""
        # A freshly-typed top-level transaction must not be trapped inside a
        # stale legacy menu sub-state (panel_state from an earlier CECI/CEMT/CEDA
        # navigation) - that produced spurious "INVALID SELECTION" for valid
        # transactions like CSMT. Numeric/keyword sub-options are left alone so
        # in-menu navigation still works.
        if transid in _EXEC_TRANS or transid in _EXTRA_TRANS:
            self.cics.panel_state = ""
        extra = self._extra_output(transid, command)
        if extra is not None:
            out = extra
        else:
            try:
                out = self.cics.execute(command)
            except Exception as exc:
                out = f"DFHAC2206 Transaction {command.split()[0][:4]} abended: {exc}"
        # Supervisory / definition transactions paint a self-contained panel;
        # real CICS does not echo a "Transaction:" header for them.
        _panel_txns = {"CEOT", "CEST", "CMAC", "CWTO", "CRTE", "CEDA", "CEBR", "CSMT", "CEDF"}
        if transid in _panel_txns:
            self.lines = []
        else:
            self.lines = [f"Transaction: {command}".rstrip(), ""]
        for line in text_to_lines(out):
            self.lines.append(line.rstrip())
        self._screen = _RUN
        return self._run_panel(to_bottom=False)

    def _extra_output(self, transid: str, command: str) -> Optional[str]:
        """Authentic responses for common supervisory/inquiry transactions."""
        termid = "S270"
        now = self._now()
        if transid == "CEOT":
            return ("CEOT                                             STATUS:  RESULTS\n"
                    f" Applid {self._applid()}    {now}                     OVERTYPE TO MODIFY\n"
                    " Tas Ter    Tertype   Service     Status\n"
                    f"     {termid:<6} 3270      INSERVICE   TRANSCEIVE  ATI  TTI  UCTRAN\n"
                    " DFHCE3120 THE COMMAND COMPLETED SUCCESSFULLY.")
        if transid == "CEST":
            uc = command.upper()
            rows = []
            try:
                for r in self.cics.terminal_resources.values():
                    rows.append(f" Ter({r.name:<4}) Net({r.attr('NETNAME',''):<8}) {r.status:<20} Ser(INSERVICE)")
            except Exception:
                rows = [f" Ter({termid:<4}) Net({termid:<8}) INSERVICE            Ser(INSERVICE)"]
            body = "\n".join(rows)
            if " SET " in f" {uc} ":
                return ("CEST  SUPERVISORY TERMINAL - SET TERMINAL         STATUS:  RESULTS\n"
                        f"{body}\n"
                        " DFHCE3553 TERMINAL SET COMPLETE.")
            return ("CEST  SUPERVISORY TERMINAL - INQUIRE TERMINAL     STATUS:  RESULTS\n"
                    f" Applid {self._applid()}    {now}                     OVERTYPE TO MODIFY\n"
                    f"{body}\n"
                    " Use CEST SET TERMINAL(x) INSERVICE|OUTSERVICE|ATI|NOATI to modify.")
        if transid == "CMAC":
            parts = command.split()
            if len(parts) > 1:
                msgid = parts[1].upper()
                e = _CMAC_MESSAGES.get(msgid)
                if e:
                    return (f"CMAC  ---  MESSAGE {msgid}\n"
                            f" {msgid} {e['text']}\n\n"
                            f" EXPLANATION:   {e['explain']}\n"
                            f" SYSTEM ACTION: {e['action']}\n"
                            f" USER RESPONSE: {e['user']}")
                return (f"CMAC  ---  MESSAGE {msgid}\n"
                        f" {msgid} is not in the local message catalogue.\n"
                        " EXPLANATION:   Refer to the CICS Messages and Codes manual.\n"
                        " SYSTEM ACTION: None.   USER RESPONSE: None.")
            return ("CMAC  ---  CICS MESSAGES AND CODES\n"
                    " Enter a message number, for example:  CMAC DFHAC2001\n"
                    " Catalogued: " + ", ".join(sorted(_CMAC_MESSAGES)))
        if transid == "CWTO":
            parts = command.split(maxsplit=1)
            if len(parts) > 1 and parts[1].strip():
                msg = parts[1].strip()[:60]
                try:
                    self.cics.region.add_log("INFO", "CWTO", self.cics.userid, f"WTO: {msg}")
                except Exception:
                    pass
                return (f" +{msg}\n"
                        " DFHWT0001I MESSAGE WRITTEN TO THE CONSOLE OPERATOR AND CSMT LOG.")
            return "CWTO  ---  Enter message text:  CWTO your-message-text"
        if transid == "CRTE":
            parts = command.split()
            sysid = parts[1].upper() if len(parts) > 1 and parts[1].upper().startswith("SYSID") else "CICR"
            return ("CRTE  ---  ROUTING TRANSACTION\n"
                    f"DFHAC1500 Routing session to system {sysid} established.\n"
                    "Enter CANCEL to end the routing session.")
        return None

    def _run_panel(self, to_bottom: bool = False) -> ScreenBuffer:
        self._scroll = ScrollList(self.lines, height=_OUTPUT_ROWS)
        if to_bottom:
            self._scroll.to_bottom()
        return self._render_run()

    def _render_run(self) -> ScreenBuffer:
        s = ScreenBuffer()
        s.extended_attributes = True
        (self._scroll or ScrollList(self.lines, height=_OUTPUT_ROWS)).render_into(
            s, 1, left=1, width=79, colour=colors.GREEN)
        pos = self._scroll.position_label if self._scroll else "Row 0 of 0"
        s.put(22, 1, pos.ljust(20), colors.BLUE)
        s.put(23, 1, "===>", colors.WHITE)
        s.add_field("CMD", 23, 6, 72, colour=_TURQ, role="command")
        s.put(24, 1, "F3=Back  F7=Up  F8=Down  CLEAR=New transaction  PA1=Attention", colors.BLUE)
        s.set_cursor(23, 6)
        return s

    # --------------------------------------------------------------- LAB
    def _start_lab(self, raw: str) -> ScreenBuffer:
        """Enter a DVCA/OMEN lab via the engine, which sets the active flag."""
        try:
            out = self.cics.execute(raw)
        except Exception as exc:
            out = f"DFHAC2206 {raw.split()[0][:4]} abended: {exc}"
        if getattr(self.cics, "dvca_active", False):
            self._lab = "DVCA"
            self._screen = _LAB
            return self._render_dvca()
        elif getattr(self.cics, "cbsa_active", False):
            self._lab = "OMEN"
        else:
            # Lab refused to start (blocked/secured) -> show the message normally.
            self.lines = [f"Transaction: {raw}".rstrip(), ""] + [l.rstrip() for l in text_to_lines(out)]
            self._screen = _RUN
            return self._run_panel(to_bottom=False)
        self._screen = _LAB
        return self._render_lab(out)

    def _dvca_screen(self) -> str:
        try:
            from gibson.apps.dvca.store import get_dvca_store
            sid = getattr(self.state, "dvca_cics_sessions", {}).get((self.cics.userid or "DVCA").upper())
            if sid:
                return (get_dvca_store(self.state).session(sid).screen or "").upper()
        except Exception:
            pass
        return ""

    def _exit_lab(self) -> Optional[ScreenBuffer]:
        self.cics.dvca_active = False
        self.cics.cbsa_active = False
        self._lab = None
        self._screen = _ENTRY
        self._message = ""
        return self._entry_panel()

    def _handle_lab(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        # The user may type into the app's own "Selection ===>" field (SELECT)
        # or the footer command line (CMD).  Honour whichever was used so menu
        # selections AND recognised commands (e.g. HACK ON) both work.
        cmd = pi.stripped("CMD") or pi.stripped("SELECT")
        uc = cmd.upper()
        first = uc.split()[0] if uc else ""
        # explicit exits
        if pi.key == "CLEAR" or first in {"CESF", "LOGOFF", "SIGNOFF", "EXIT", "CICS"}:
            if first in {"CESF", "LOGOFF", "SIGNOFF"}:
                self.cics.execute("CESF")
                self.cics.dvca_active = False
                self.cics.cbsa_active = False
                self._lab = None
                self._screen = _GM
                return self._gm_panel()
            return self._exit_lab()
        # typing a real CICS transaction leaves the lab and runs it
        if first in _CICS_TRANS:
            self.cics.dvca_active = False
            self.cics.cbsa_active = False
            self._lab = None
            self._screen = _ENTRY
            return self._handle_entry(pi)

        if self._lab == "DVCA":
            # PF3 on the top (good-morning) screen quits the lab; deeper screens
            # pass PF3 through for the app's own "back" navigation.
            if pi.key in ("PF3", "PF15") and self._dvca_screen() in ("", "MCGM"):
                return self._exit_lab()

            class _Ev:
                def __init__(self, fields, aid):
                    self.fields_by_name = fields
                    self.aid = aid
            ev = _Ev(dict(pi.fields), pi.key)
            try:
                out = execute_dvca(self.state, self.cics.userid, cmd, aid=pi.key, event=ev)
            except Exception as exc:
                return self._render_lab(f"DVCA ERROR: {exc}")
            return self._render_dvca()

        # OMEN / CBSA
        if pi.key in ("PF3", "PF15") and not uc:
            return self._exit_lab()
        try:
            out = execute_omen(self.state, self.cics.userid, cmd or pi.key)
        except Exception as exc:
            out = f"OMEN ERROR: {exc}"
        if isinstance(out, str) and out.startswith("GIBSON_CICS_ROUTE:"):
            routed = out.split(":", 1)[1]
            self.cics.cbsa_active = False
            self._lab = None
            self._screen = _RUN
            return self._run_command(routed)
        return self._render_lab(out)

    def _handle_cbtr(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        """Handle the CBSA fielded transfer-approval lab (a hack3270 target)."""
        from gibson.apps.cbsa.transfer_lab import handle_transfer
        if pi.key == "CLEAR" or pi.key in ("PF3", "PF15"):
            self._screen = _ENTRY
            self._message = ""
            return self._entry_panel()
        return handle_transfer(self.state, self.cics.userid, dict(pi.fields), aid=pi.key)

    def _render_dvca(self) -> ScreenBuffer:
        """Render the current DVCA screen as a genuine fielded 3270 panel so the
        real hack3270 proxy can reveal/unlock its BMS fields. A command line is
        kept on the bottom row for navigation and backward compatibility."""
        from gibson.apps.dvca.cics_session import dvca_buffer
        sb = dvca_buffer(self.state, self.cics.userid)
        sb.put(24, 1, "CLEAR=Exit  PF3=Back  PF5=Menu  PF7/8=Scroll   ===>", colors.BLUE)
        sb.add_field("CMD", 24, 53, 26, colour=_TURQ, role="command")
        return sb

    def _render_lab(self, ansi_text: str) -> ScreenBuffer:
        from gibson.render.ansi3270 import strip_ansi
        s = render_ansi_to_screen(ansi_text, base_colour=colors.GREEN, rows=24, cols=80, start_row=1)
        # Attach the input field to the app's own "===>" prompt so we don't
        # cover its message/PF-key legend.
        lines = strip_ansi(ansi_text).replace("\r", "").split("\n")
        prompt_row = prompt_col = None
        for i, ln in enumerate(lines[:24], start=1):
            j = ln.find("===>")
            if j != -1:
                prompt_row, prompt_col = i, j + 5  # just past "===>"
                break
        last_used = max((i for i, ln in enumerate(lines[:24], start=1) if ln.strip()), default=0)
        if prompt_row is None:
            prompt_row = min(24, max(last_used + 1, 23))
            s.put(prompt_row, 1, "===>", colors.WHITE)
            prompt_col = 6
        s.add_field("CMD", prompt_row, prompt_col, max(8, 79 - prompt_col), colour=_TURQ, role="command")
        # A one-line exit hint, only if the app left the last row free.
        if last_used < 24 and prompt_row != 24:
            hint = "CLEAR=Exit to CICS   (PF3=Quit/Back  PF5=Menu  PA3=Secret)"
            if self._lab == "OMEN":
                hint = "CLEAR=Exit to CICS   PF3=End   PF10=Instructions"
            s.put(24, 1, hint[:79], colors.BLUE)
        s.set_cursor(prompt_row, prompt_col)
        return s

    # -------------------------------------------------------------- CEMT
    def _cemt_build(self, res: str):
        """Return (title, columns, rows) for a CEMT INQUIRE resource panel.

        Each row is a dict: name (resource key), restype, and cells -> list of
        (text, colour) tuples aligned with columns.
        """
        c = self.cics
        rows = []
        if res == "FILE":
            cols = [("File", 9), ("Type", 6), ("Open", 7), ("Enable", 9), ("Rea", 4), ("Upd", 4), ("Dsname", 30)]
            for r in c.files.values():
                opn = getattr(r, "open_state", "OPEN")
                ena = "DISABLED" if "DIS" in (r.status or "").upper() else "ENABLED"
                rows.append(dict(name=r.name, restype="FILE", cells=[
                    (r.name, colors.TURQUOISE), (r.attr("TYPE", "VSAM"), colors.GREEN),
                    (opn, _cemt_status_colour(opn)), (ena, _cemt_status_colour(ena)),
                    (r.attr("READ", "YES"), colors.GREEN), (r.attr("UPDATE", "NO"), colors.GREEN),
                    (r.attr("DSN", f"GIBSON.{r.name}"), colors.WHITE)]))
            return "INQUIRE FILE", cols, rows
        if res == "PROGRAM":
            cols = [("Program", 9), ("Length", 8), ("Rescount", 9), ("Usecount", 9), ("Status", 10)]
            for r in c.programs.values():
                rows.append(dict(name=r.name, restype="PROGRAM", cells=[
                    (r.name, colors.TURQUOISE), (r.attr("LENGTH", "0000"), colors.GREEN),
                    (r.attr("RESCOUNT", "0000"), colors.GREEN), (r.attr("USECOUNT", "0000"), colors.GREEN),
                    (r.status, _cemt_status_colour(r.status))]))
            return "INQUIRE PROGRAM", cols, rows
        if res == "TASK":
            cols = [("Task", 7), ("Tran", 6), ("Facility", 9), ("Status", 9), ("Owner", 14), ("Program", 9)]
            for t in c.region.tasks.values():
                stt = t.get("STATUS", "RUNNING")
                rows.append(dict(name=str(t.get("TASK", "")), restype="TASK", cells=[
                    (str(t.get("TASK", "")), colors.TURQUOISE), (t.get("TRAN", ""), colors.GREEN),
                    (t.get("TERMID", ""), colors.GREEN), (stt, _cemt_status_colour(stt)),
                    (f"Use({(t.get('USERID','') or 'CICSUSER'):<8})", colors.GREEN), (t.get("PROGRAM", ""), colors.GREEN)]))
            if not rows:
                now = self._now()
                rows.append(dict(name="0000001", restype="TASK", cells=[
                    ("0000001", colors.TURQUOISE), ("CEMT", colors.GREEN), ("LU320", colors.GREEN),
                    ("Running", colors.GREEN), (f"Use({(self.cics.userid or 'CICSUSER'):<8})", colors.GREEN), ("DFHEMTP", colors.GREEN)]))
            # Always surface an interactive user task so operators (and screen
            # scrapers) see a non-system Use(...) entry.
            _u = (self.cics.userid or "CICSUSER")
            if not any(_u in str(r["cells"][4][0]) for r in rows):
                rows.append(dict(name="0000050", restype="TASK", cells=[
                    ("0000050", colors.TURQUOISE), ("CECI", colors.GREEN), ("LU320", colors.GREEN),
                    ("Running", colors.GREEN), (f"Use({_u:<8})", colors.GREEN), ("DFHECIP", colors.GREEN)]))
            return "INQUIRE TASK", cols, rows
        if res == "TRANSACTION":
            cols = [("Tran", 6), ("Priority", 9), ("Program", 9), ("Status", 10), ("Tcl", 6)]
            for r in c.transactions.values():
                rows.append(dict(name=r.name, restype="TRANSACTION", cells=[
                    (r.name, colors.TURQUOISE), (r.attr("PRIORITY", "001"), colors.GREEN),
                    (r.attr("PROGRAM", "DFH"), colors.GREEN), (r.status, _cemt_status_colour(r.status)),
                    (r.attr("TCLASS", "No"), colors.GREEN)]))
            return "INQUIRE TRANSACTION", cols, rows
        # TERMINAL
        cols = [("Term", 6), ("Netname", 9), ("Status", 11), ("Userid", 9), ("Service", 11)]
        for r in c.terminal_resources.values():
            svc = "INSERVICE" if "OUT" not in (r.status or "").upper() else "OUTSERVICE"
            rows.append(dict(name=r.name, restype="TERMINAL", cells=[
                (r.name, colors.TURQUOISE), (r.attr("NETNAME", ""), colors.GREEN),
                (r.status, _cemt_status_colour(r.status)), (r.attr("USERID", ""), colors.GREEN),
                (svc, _cemt_status_colour(svc))]))
        if not rows:
            rows.append(dict(name="S270", restype="TERMINAL", cells=[
                ("S270", colors.TURQUOISE), ("LU320", colors.GREEN), ("Inservice", colors.GREEN),
                (self.cics.userid, colors.GREEN), ("Inservice", colors.GREEN)]))
        return "INQUIRE TERMINAL", cols, rows

    # Legacy menu sub-state that CicsSimulator.execute() sets for a bare
    # transaction.  The 3270 interface screens below bypass execute(), so mirror
    # it here or in-menu sub-options ("1" inside CECI) lose their context and
    # come back as INVALID SELECTION.
    _LEGACY_PANEL_STATE = {"CEMT": "CEMT_MAIN", "CEDA": "CEDA_MAIN",
                           "CECI": "CECI_MAIN", "CECS": "CECI_MAIN"}

    def _cics_txn_interface(self, transid: str) -> ScreenBuffer:
        """Authentic 'bare transaction' interface screens.  Each keeps a command
        field on row 1 (so the next probe can be typed) and shows the object/verb
        list on the row cicspwn's availability detection scrapes."""
        legacy = self._LEGACY_PANEL_STATE.get(transid.upper())
        if legacy:
            self.cics.panel_state = legacy
        p = Panel(cursor="TRAN")
        p.add(Field("TRAN", 1, 1, 40, colour=_TURQ))
        if transid == "CEMT":
            p.add(Label(1, 46, "CEMT", colors.BLUE))
            p.add(Label(3, 2, "STATUS:  ENTER ONE OF THE FOLLOWING", colors.GREEN))
            p.add(Label(5, 2, "Inquire  Set  Perform  Discard", _TURQ))
        elif transid in ("CECI", "CECS"):
            p.add(Label(1, 46, transid, colors.BLUE))
            p.add(Label(3, 2, "STATUS:  ENTER ONE OF THE FOLLOWING", colors.GREEN))
            p.add(Label(5, 2, "ACquire ADDRess ALlocate ASKtime ASSign CANcel DELETEq DEQ", _TURQ))
            p.add(Label(6, 2, "DUMp ENQ ENTer EXTract FREEmain GETmain HANDle LINK READ", colors.GREEN))
        elif transid == "CEDA":
            p.add(Label(1, 46, "CEDA", colors.BLUE))
            p.add(Label(3, 2, "ENTER ONE OF THE FOLLOWING", colors.GREEN))
            p.add(Label(5, 2, "ADd  ALter  APpend  CHeck  COpy  DEFine  DELete  DIsplay  Install", _TURQ))
        elif transid == "CEBR":
            p.add(Label(1, 46, "CEBR", colors.BLUE))
            p.add(Label(2, 2, "ENTER COMMAND ===>", colors.GREEN))
            p.add(Label(4, 2, "TSQ browse.  Commands: TOP BOTom Next Previous Line Column", colors.GREEN))
        elif transid == "CEDF":
            # CEDF ,OFF -> 'EDF MODE OFF' must be readable on row 1 while the
            # command field (cols 1-40) stays typable for the next probe.
            p.add(Label(1, 44, "THIS TERMINAL: EDF MODE OFF", colors.GREEN))
        p.pfkeys = "PF3=End  ENTER=Process"
        s = p.render()
        s.set_cursor(1, 1)
        self._screen = _ENTRY
        self._txn_context = transid   # follow-up sub-commands belong to this txn
        return s

    def _cemt_resource_menu(self, verb: str = "INQUIRE") -> ScreenBuffer:
        """CEMT <verb> with no resource: list the resources the verb accepts.

        Real CEMT is a three-step drill-down - CEMT -> verb -> resource - and
        each step keeps the command line live so the operator can type the next
        word.  The verb is held as the transaction context, so typing TASK on
        this screen completes "CEMT INQUIRE TASK"."""
        v = (verb or "INQUIRE").upper()
        p = Panel(cursor="TRAN")
        p.add(Field("TRAN", 1, 1, 40, colour=_TURQ))
        p.add(Label(1, 46, f"CEMT {v[:1] + v[1:].lower()}", colors.BLUE))
        p.add(Label(3, 2, "STATUS:  ENTER ONE OF THE FOLLOWING", colors.GREEN))
        if v == "PERFORM":
            # Real CEMT PERFORM option list. Options GIBSON actually implements
            # are shown in red so the operator can see what works in the sim.
            perform_opts = [
                ("DEletshipped", False), ("DUmp", True), ("Endaffinity", False),
                ("Jvmserver", False), ("Pipeline", False), ("Reset", True),
                ("SEcurity", True), ("SHUTdown", True), ("SNap", True),
                ("SSl", False), ("STatistics", True),
            ]
            row = 5
            for name, works in perform_opts:
                # First two characters red for a LIVE (working) option; the rest
                # of the keyword, and non-working options, stay plain.
                if works and len(name) >= 2:
                    p.add(Label(row, 2, name[:2], colors.RED))
                    p.add(Label(row, 4, name[2:], _TURQ))
                else:
                    p.add(Label(row, 2, name, _TURQ))
                row += 1
            p.add(Label(row + 1, 2, f"Type an option to complete: CEMT PERFORM <option>", colors.GREEN))
            p.pfkeys = "PF3=End  ENTER=Process"
            s = p.render()
            s.set_cursor(1, 1)
            self._screen = _ENTRY
            self._txn_context = f"CEMT {v}"
            return s
        # First two characters in RED mark a resource that is LIVE (usable) in
        # GIBSON's CICS; resources it does not implement (e.g. UOW) stay plain.
        _live_res = {"CONNECTION", "DB2CONN", "DSNAME", "FILE", "LIBRARY",
                     "PROGRAM", "SYSTEM", "TASK", "TRANSACTION", "TERMINAL",
                     "TDQUEUE", "TSQUEUE"}
        _res_grid = [
            [("AUtoinstall", "AUTOINSTALL"), ("COnnection", "CONNECTION"), ("DB2conn", "DB2CONN"),
             ("DSname", "DSNAME"), ("FIle", "FILE"), ("Journal", "JOURNAL")],
            [("LIbrary", "LIBRARY"), ("NEtname", "NETNAME"), ("PROgram", "PROGRAM"),
             ("SYStem", "SYSTEM"), ("TAsk", "TASK"), ("TClass", "TCLASS")],
            [("TDqueue", "TDQUEUE"), ("TErminal", "TERMINAL"), ("TRansaction", "TRANSACTION"),
             ("TSqueue", "TSQUEUE")],
            [("UOw", "UOW"), ("Udsa", "UDSA")],
        ]
        _rr = 5
        for _cols in _res_grid:
            _cc = 2
            for _label, _key in _cols:
                if _key in _live_res:
                    p.add(Label(_rr, _cc, _label[:2], colors.RED))
                    p.add(Label(_rr, _cc + 2, _label[2:], _TURQ))
                else:
                    p.add(Label(_rr, _cc, _label, _TURQ))
                _cc += 13
            _rr += 1
        p.add(Label(10, 2, f"Type a resource name to complete: CEMT {v} <resource>", colors.GREEN))
        p.pfkeys = "PF3=End  ENTER=Process"
        s = p.render()
        s.set_cursor(1, 1)
        self._screen = _ENTRY
        # Follow-up word completes the command, e.g. TASK -> CEMT INQUIRE TASK.
        self._txn_context = f"CEMT {v}"
        return s

    def _cemt_kv_panel(self, res: str, raw: str) -> ScreenBuffer:
        """CEMT INQUIRE rendered in the classic Keyword(value) inline format that
        screen-scrapers (cicspwn's query_cics_scrap / get_users / get_hql_*) read,
        rather than the fielded table used for interactive operation."""
        self._screen = _CEMT
        self._cemt_res = res
        self._cemt_rows = []
        s = ScreenBuffer()
        s.extended_attributes = True
        s.put(1, 1, f"CEMT INQUIRE {res}", colors.WHITE)
        s.put(1, 50, "STATUS:  RESULTS", colors.TURQUOISE)
        s.put(2, 1, f"Applid {self._applid()}   {self._now()}", colors.GREEN)
        r = 4
        for line in self._cemt_kv_lines(res):
            if r > 21:
                break
            s.put(r, 2, line[:78], colors.GREEN)
            r += 1
        s.put(23, 1, "===>", colors.WHITE)
        s.add_field("CMD", 23, 6, 72, colour=_TURQ, role="command")
        s.put(24, 1, "PF3=End  PF7=Up  PF8=Down  ENTER=Reshow", colors.BLUE)
        s.set_cursor(23, 6)
        self._message = ""
        return s

    def _cemt_kv_lines(self, res: str):
        reg = self.cics.region
        dflt = reg.security_options.get("DFLTUSER", "CICSUSER")
        if res == "SYSTEM":
            ap = self._applid()
            return [
                "Cicstslevel(07300000)  Cicsrel(0730)  Cicsstatus(ACTIVE)",
                f"Oslevel(030200)  Sysid({reg.sysid})  Applid({ap})",
                f"Dfltuser({dflt})  Maxtasks( 0100)  Amxt( 0250)  Aktasks( 0001)",
                "Runaway(0005000)  Progautoinst(Autoactive)  Security(Active)",
                "Db2conn(DB2A    )  Mqconn(CSQ1    )  Cmdprotect(Yes)",
                f"Reseckey(Internal)  Xappc(No)  SYSID {reg.sysid}",
                f"Storeprotect(Active)  Ranready(Yes)  APPLID {ap}",
            ]
        if res == "DSNAME":
            out = []
            for f in reg.files.values():
                dsn = f.attr("DSN", f"GIBSON.{f.name}")
                out.append(f"Dsn({dsn})".ljust(50) + f"File({f.name})  Vsam Base")
            return out or ["DFHCE3549 NO RESOURCES MATCH"]
        if res == "LIBRARY":
            return [
                "Lib(DFHRPL)  Enablestatus(Enabled)  Critical(Critical)",
                "  Dsname01(DFH320.CICS.SDFHLOAD)",
                "Lib(GIBLIB)  Enablestatus(Enabled)  Dsname01(GIBSON.CICS.LOADLIB)",
            ]
        if res == "TASK":
            u = self.cics.userid or dflt
            out = [f"Tas(0000001) Tra(CEMT) Fac(LU320) Run Use({u:<8})",
                   f"Tas(0000002) Tra(CECI) Fac(LU321) Sus Use({dflt:<8})",
                   f"Tas(0000003) Tra(CESN) Fac(LU322) Run Use({dflt:<8})"]
            for t in (list(getattr(reg, "tasks", {}).values()) if getattr(reg, "tasks", None) else []):
                uu = (t.get("USERID") or dflt)
                out.append(f"Tas({str(t.get('TASK','0000009')):>7}) Tra({t.get('TRAN','CSSY'):<4}) "
                           f"Fac({t.get('TERMID','')}) Run Use({uu:<8})")
            return out
        if res == "TDQUEUE":
            out = []
            for q in reg.tdqueues.values():
                intrdr = q.attr("INTRDR", "NO") if hasattr(q, "attr") else "NO"
                ddn = "Ddn(INTRDR)" if str(intrdr).upper() in ("YES", "INTRDR") else ""
                out.append(f"Tdq({q.name})  Type({q.attr('TYPE','Extra') if hasattr(q,'attr') else 'Extra'})  Ope Ena {ddn}".rstrip())
            return out or ["DFHCE3549 NO RESOURCES MATCH"]
        if res == "DB2CONN":
            # Single CICS-DB2 connection.  Authid tracks the signed-on user so
            # the panel reflects who the attachment runs under; the rest mirrors
            # the CBSA sample region (DB2A / CBSAPLAN) reported by CEMT I SYSTEM.
            authid = self.cics.userid or dflt
            return [
                "Db2conn(DB2A    )  Connectst(Connected)  Connecterror()",
                "Db2id(DB2A)  Db2groupid(        )  Db2release(1210)",
                f"Plan(CBSAPLAN)  Planexitname(DSNCUEXT)  Authtype(Userid)  Authid({authid:<8})",
                "Thread(0003)  Threadlimit(0010)  Threadwait(Pool)  Tcblimit(0012)",
                "Signid(CICSUSER)  Standbymode(Reconnect)  Statsqueue(DSN2STAT)",
                "Comauthtype()  Comthreadlim(0005)  Accountrec(None)  Drollback(Yes)",
            ]
        return ["DFHCE3549 NO RESOURCES MATCH"]

    def _cemt_name_in(self, cmd: str) -> Optional[str]:
        """Extract the first parenthesised resource name (handles abbreviations
        like FI(FILEA), PROG(x), TRA(x)); returns None if absent."""
        import re as _re
        m = _re.search(r"\(([^)]+)\)", cmd or "")
        return m.group(1).strip().upper() if m else None

    def _cemt_tsq_panel(self, pattern: str = "*") -> ScreenBuffer:
        import fnmatch
        self._screen = _CEMT
        self._cemt_res = "TSQUEUE"
        self._cemt_rows = []
        self._cemt_cmdtext = "CEMT INQUIRE TSQUEUE"
        s = ScreenBuffer()
        s.extended_attributes = True
        s.add_field("TOPCMD", 1, 1, 158, value="CEMT INQUIRE TSQUEUE", colour=colors.WHITE, role="command")
        pat = (pattern or "*").upper().replace("%", "*")
        queues = [q for q in (list(getattr(self.cics.region, "tsqueues", []) or []))
                  if fnmatch.fnmatch(q.upper(), pat)]
        r = 3
        for q in queues[:8]:
            try:
                nitems = len(self.cics.region.read_tsq(q) or [])
            except Exception:
                nitems = 0
            # cicspwn reads name at [7:13], items at [29:34], length at [40:50];
            # a leading field-attribute shifts the rendered row right by one, so
            # the source positions are one to the left.
            line = list(" " * 79)
            line[0:4] = list("Tsq(")
            line[6:12] = list(q[:6].ljust(6))
            line[12] = ")"
            line[23:27] = list("Ite(")
            line[28:33] = list(str(nitems).zfill(5))
            line[33] = ")"
            line[34:38] = list("Len(")
            line[39:49] = list(str(80).zfill(10))
            line[49] = ")"
            s.put(r, 1, "".join(line), colors.GREEN); r += 1
            # cicspwn reads tran at [10:14].
            line2 = list(" " * 79)
            line2[5:9] = list("Tra(")
            line2[9:13] = list("CECI")
            line2[13] = ")"
            s.put(r, 1, "".join(line2), colors.GREEN); r += 1
        if not queues:
            s.put(3, 2, "Tsq() NOT FOUND", colors.YELLOW)
        s.put(23, 1, ("STATUS:  RESULTS   %d RESULT(S)  RESPONSE: NORMAL" % len(queues))[:79], colors.TURQUOISE)
        s.put(24, 1, "PF3=End  ENTER=Process", colors.BLUE)
        s.set_cursor(1, 2)
        return s

    def _cemt_abbrev_line(self, row: dict) -> str:
        """Render one resource in real CEMT abbreviated form (Fil(x) Ope Ena ...)."""
        rt = row.get("restype", "")
        cells = [str(c[0]).strip() for c in row.get("cells", [])]
        def g(i, d=""):
            return cells[i] if i < len(cells) else d
        if rt == "FILE":
            opn = "Ope" if "OPE" in g(2).upper() else "Clo"
            ena = "Ena" if "ENA" in g(3).upper() else "Dis"
            rea = "Rea" if g(4).upper().startswith("Y") else "Nre"
            upd = "Upd" if g(5).upper().startswith("Y") else "Nup"
            return f"Fil({g(0):<8}) {g(1)[:4]:<4} {opn} {ena} {rea} {upd} Dsn({g(6)})"
        if rt == "PROGRAM":
            st = g(4).upper()
            ena = "Ena" if "ENA" in st else ("Dis" if "DIS" in st else "Ena")
            return f"Pro({g(0):<8}) Len({g(1)}) {ena} Ced Res({g(2)}) Use({g(3)})"
        if rt == "TASK":
            return f"Tas({g(0):<7}) Tra({g(1)}) Fac({g(2)}) {g(3)} {g(4)} Pro({g(5)})"
        if rt == "TRANSACTION":
            return f"Tra({g(0)}) Pri({g(1)}) Pro({g(2)}) {g(3)} Tcl({g(4)})"
        return f"Ter({g(0)}) Net({g(1)}) {g(2)} {g(3)} {g(4)}"

    def _cemt_panel(self, res: str, verb: str = "INQUIRE", name: Optional[str] = None) -> ScreenBuffer:
        self._screen = _CEMT
        self._cemt_res = res
        title, cols, rows = self._cemt_build(res)
        if verb and verb != "INQUIRE":
            title = title.replace("INQUIRE", verb)
        if name:
            rows = [row for row in rows if str(row.get("name", "")).upper() == name.upper()]
            title = f"{title}({name.upper()})"
        self._cemt_rows = rows
        s = ScreenBuffer()
        s.extended_attributes = True
        # Rows 1-2 are one wide unprotected command line, exactly as real CEMT
        # (and like the blank entry panel that already works): a tool such as
        # cicspwn types an 80-char space-padded command at (1,2), so the region
        # must be big enough that it never overflows into a protected field and
        # locks the keyboard. It shows the command and is overtypable.
        self._cemt_cmdtext = f"CEMT {title}"
        s.add_field("TOPCMD", 1, 1, 158, value=f"CEMT {title}", colour=colors.WHITE, role="command")
        # Row 3+: one resource per line in real CEMT abbreviated form, each with
        # an unprotected action field at the front (overtype to modify). cicspwn
        # reads the first resource line at data[2] for Ope/Ena.
        r = 3
        maxr = 20
        for i, row in enumerate(rows):
            if r > maxr:
                break
            s.add_field(f"AC{i:02d}", r, 1, 3, colour=_TURQ, role="line_command")
            s.put(r, 5, self._cemt_abbrev_line(row)[:74], colors.GREEN)
            r += 1
        if not rows:
            s.put(3, 5, "DFHCE3549 NO RESOURCES MATCH", colors.YELLOW)
        # Row 22 message; row 23 the RESPONSE line cicspwn reads at data[22].
        s.put(22, 1, (self._message or f"Applid {self._applid()}  {len(rows)} result(s)  {self._now()}")[:79],
              colors.YELLOW if self._message else colors.GREEN)
        if self._message and "NORMAL" in self._message.upper():
            resp = self._message
        else:
            resp = f"{len(rows)} RESULT(S)  RESPONSE: NORMAL"
        s.put(23, 1, ("STATUS:  RESULTS   " + resp)[:79], colors.TURQUOISE)
        s.put(24, 1, "PF3=End  PF7=Up  PF8=Down  ENTER=Process  OVERTYPE TO MODIFY", colors.BLUE)
        s.set_cursor(1, 2)
        return s

    def _handle_cemt(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15") or pi.key == "CLEAR":
            self._screen = _ENTRY
            self._message = ""
            return self._entry_panel()
        # A command overtyped on the row-1 command line (real CEMT, and what
        # cicspwn does after an inquiry) is processed as a fresh CEMT command.
        top = pi.stripped("TOPCMD")
        if top and top.upper() != (getattr(self, "_cemt_cmdtext", "") or "").upper():
            first = top.split()[0].upper()
            body = top.split(None, 1)[1] if first == "CEMT" and len(top.split(None, 1)) > 1 else top
            if first in _CICS_TRANS and first != "CEMT":
                self._screen = _ENTRY
                return self._run_command(top)
            verb = _cemt_verb("CEMT " + body)
            res = _cemt_inquiry_target("CEMT " + body)
            if res == "TSQUEUE":
                return self._cemt_tsq_panel(self._cemt_name_in(body) or "*")
            if res in ("SYSTEM", "DSNAME", "LIBRARY", "TDQUEUE", "DB2CONN"):
                return self._cemt_kv_panel(res, "CEMT " + body)
            if res:
                name = self._cemt_name_in(body)
                if verb in ("SET", "PERFORM"):
                    try:
                        applied = self.cics.execute("CEMT " + body)
                        dfh = next((ln.strip() for ln in (applied or "").splitlines()
                                    if ln.strip().startswith("DFH")), "")
                        self._message = ("NORMAL  " + dfh).strip()
                    except Exception:
                        self._message = "NORMAL"
                return self._cemt_panel(res, verb, name=name)
            self._screen = _ENTRY
            return self._run_command("CEMT " + body)
        cmd = pi.stripped("CMD")
        if cmd:
            first = cmd.split()[0].upper()
            if first in _CICS_TRANS:
                self._screen = _ENTRY
                return self._handle_entry(pi)
            res = _cemt_inquiry_target(cmd)
            if res:
                return self._cemt_panel(res)
            # treat as a raw CEMT command
            self._screen = _ENTRY
            return self._run_command(cmd)
        # apply overtyped action characters
        applied = []
        rows = getattr(self, "_cemt_rows", [])
        for name, val in pi.fields.items():
            if name.startswith("AC") and val.strip():
                try:
                    idx = int(name[2:])
                except ValueError:
                    continue
                if idx < len(rows):
                    row = rows[idx]
                    act = val.strip().upper()
                    out = self.cics.execute(f"CEMT SET {row['restype']}({row['name']}) {act}")
                    applied.append(out.splitlines()[0] if out else f"{row['name']} {act}")
        if applied:
            self._message = applied[0][:78]
        else:
            self._message = ""
        return self._cemt_panel(self._cemt_res)

    def _handle_run(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15") or pi.key == "CLEAR":
            self._screen = _ENTRY
            self._message = ""
            return self._entry_panel()
        if pi.key in ("PF7", "PF8", "PF10", "PF11"):
            if self._scroll is None:
                self._scroll = ScrollList(self.lines, height=_OUTPUT_ROWS)
            self._scroll.scroll(pi.key)
            return self._render_run()
        cmd = pi.stripped("CMD")
        if cmd:
            transid = cmd.split()[0].upper()
            if transid in ("CESF", "LOGOFF"):
                self.cics.execute("CESF")
                self._screen = _GM
                return self._gm_panel()
            if transid in ("CESN", "CESL"):
                self._screen = _CESN
                return self._cesn_panel()
            # A transaction typed on an output panel's command line attaches it
            # (via the secured entry path) instead of echoing it as plain text.
            esc = self._global_txn_escape(pi, cmd)
            if esc is not None:
                return esc
            return self._run_command(cmd)
        return self._render_run()

    # --------------------------------------------------------------- utils
    def _applid(self) -> str:
        try:
            return (self.state.get_system_hostname() or "CICSGIB1")[:8].upper()
        except Exception:
            return "CICSGIB1"

    @staticmethod
    def _now() -> str:
        import datetime
        return datetime.datetime.now().strftime("%H:%M:%S")
