"""JCL model + scanner (spec J1).

Scans JCL text into a Job/Step/DD model, handling continuations, ``//*``
comments, in-stream ``DD *``/``DD DATA`` data, DD concatenation, and
parenthesis-aware parameter parsing.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class DD:
    name: str
    params: Dict[str, str] = field(default_factory=dict)
    instream: Optional[List[str]] = None
    dummy: bool = False
    concat: List["DD"] = field(default_factory=list)


@dataclass
class Step:
    name: str
    pgm: str = ""
    proc: str = ""
    params: Dict[str, str] = field(default_factory=dict)
    dds: List[DD] = field(default_factory=list)
    rc: Optional[int] = None
    abend: Optional[str] = None
    if_context: List = field(default_factory=list)   # [(cond_str, in_else), ...]


@dataclass
class Job:
    name: str
    params: Dict[str, str] = field(default_factory=dict)
    steps: List[Step] = field(default_factory=list)
    msgs: List[str] = field(default_factory=list)


def split_params(operand: str) -> Dict[str, str]:
    """Split a JCL operand field into KEY=VALUE, respecting parentheses/quotes."""
    out: Dict[str, str] = {}
    parts = _top_split(operand)
    pos = 0
    for p in parts:
        p = p.strip()
        if not p:
            continue
        if "=" in p and not p.startswith("("):
            k, v = p.split("=", 1)
            out[k.strip().upper()] = v.strip()
        else:
            out[f"_POS{pos}"] = p    # positional operand
            pos += 1
    return out


def _top_split(s: str, sep=",") -> List[str]:
    parts, depth, quote, cur = [], 0, False, []
    for c in s:
        if c == "'":
            quote = not quote
            cur.append(c)
        elif quote:
            cur.append(c)
        elif c == "(":
            depth += 1; cur.append(c)
        elif c == ")":
            depth -= 1; cur.append(c)
        elif c == sep and depth == 0:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(c)
    parts.append("".join(cur))
    return parts


@dataclass
class _Stmt:
    name: str
    op: str
    operand: str


def _logical_lines(text: str):
    """Yield (name, op, operand) after joining continuations; capture instream."""
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        if not raw.startswith("//"):
            i += 1
            continue
        if raw.startswith("//*"):     # comment
            i += 1
            continue
        # join continuations: operand ends with ',' and next line is '//' + blanks
        body = raw[2:]
        # a statement: name op operand   (name may be blank for continuation/concat)
        while body.rstrip().endswith(",") and i + 1 < len(lines) and lines[i + 1].startswith("//") \
                and not lines[i + 1].startswith("//*"):
            i += 1
            cont = lines[i][2:].strip()
            body = body.rstrip() + cont
        # parse "name op operand"
        m = re.match(r"(\S*)\s+(\S+)\s*(.*)", body)
        if not m:
            i += 1
            continue
        name, op, operand = m.group(1), m.group(2).upper(), m.group(3)
        yield i, name, op, operand
        i += 1


def scan(text: str) -> Job:
    lines = text.splitlines()
    job = Job(name="")
    cur_step: Optional[Step] = None
    last_dd: Optional[DD] = None
    stmts = list(_logical_lines(text))
    # index instream capture by line number
    idx = 0
    if_stack = []          # list of [cond_str, in_else]
    while idx < len(stmts):
        lineno, name, op, operand = stmts[idx]
        if op == "JOB":
            job.name = name
            job.params = split_params(operand)
        elif op == "IF":
            cond = operand.strip()
            if cond.upper().endswith("THEN"):
                cond = cond[:-4].strip()
            cond = cond.strip()
            if cond.startswith("(") and cond.endswith(")"):
                cond = cond[1:-1].strip()
            if_stack.append([cond, False])
        elif op == "ELSE":
            if if_stack:
                if_stack[-1][1] = True
        elif op == "ENDIF":
            if if_stack:
                if_stack.pop()
        elif op == "EXEC":
            params = split_params(operand)
            pgm = params.get("PGM", "")
            proc = params.get("PROC", "") or params.get("_POS0", "") if "PGM" not in params else ""
            cur_step = Step(name=name or f"STEP{len(job.steps)+1}", pgm=pgm, proc=proc, params=params)
            cur_step.if_context = [(c, e) for c, e in if_stack]
            job.steps.append(cur_step)
            last_dd = None
        elif op == "DD" and cur_step is not None:
            dd = _make_dd(name, operand, lineno, lines)
            if name == "" and last_dd is not None:      # concatenation
                last_dd.concat.append(dd)
            else:
                cur_step.dds.append(dd)
                last_dd = dd
        idx += 1
    return job


def _make_dd(name: str, operand: str, lineno: int, all_lines: List[str]) -> DD:
    up = operand.upper().strip()
    params = split_params(operand)
    dd = DD(name=name.upper(), params=params)
    if up.startswith("*") or up.startswith("DATA") or "_POS0" in params and params["_POS0"] in ("*", "DATA"):
        # in-stream data: capture following lines until the delimiter.  A custom
        # DLM= lets the data itself contain '/*' (REXX or C source); otherwise a
        # bare '/*' (or the next // statement) ends it.
        dlm = None
        _dm = re.search(r"\bDLM\s*=\s*'?([^,\s']{1,2})'?", operand, re.I)
        if _dm:
            dlm = _dm.group(1)
        data = []
        j = lineno + 1
        while j < len(all_lines):
            ln = all_lines[j]
            if dlm is not None:
                if ln.rstrip() == dlm:
                    break
            elif ln.rstrip() == "/*" or ln.startswith("//"):
                break
            data.append(ln)
            j += 1
        dd.instream = data
    if "DUMMY" in up.split(",") or params.get("_POS0", "").upper() == "DUMMY":
        dd.dummy = True
    return dd

from .engine import JclEngine, JobResult, run, REGISTRY  # noqa: E402
