"""REXX built-in functions (R1 starter set; R3 completes the list)."""
from __future__ import annotations

import random as _random
import time as _time
from datetime import datetime
from decimal import Decimal, InvalidOperation


def _num(s):
    return Decimal(str(s).strip() or "0")


def _int(s, default=None):
    s = str(s).strip()
    if s == "" and default is not None:
        return default
    return int(_num(s))


BUILTINS = {}


def bi(name):
    def deco(fn):
        BUILTINS[name] = fn
        return fn
    return deco


@bi("LENGTH")
def _length(a, it): return str(len(a[0]))

@bi("SUBSTR")
def _substr(a, it):
    s = a[0]; n = _int(a[1]); ln = _int(a[2], len(s) - n + 1) if len(a) > 2 and a[2] != "" else len(s) - n + 1
    pad = (a[3] if len(a) > 3 and a[3] else " ")[:1] or " "
    start = n - 1
    piece = s[start:start + ln] if start < len(s) else ""
    return (piece + pad * ln)[:ln]

@bi("LEFT")
def _left(a, it):
    ln = _int(a[1]); pad = (a[2] if len(a) > 2 and a[2] else " ")[:1]
    return (a[0] + pad * ln)[:ln]

@bi("RIGHT")
def _right(a, it):
    ln = _int(a[1]); pad = (a[2] if len(a) > 2 and a[2] else " ")[:1]
    return (pad * ln + a[0])[-ln:] if ln else ""

@bi("POS")
def _pos(a, it):
    start = _int(a[2], 1) if len(a) > 2 and a[2] else 1
    return str(a[1].find(a[0], start - 1) + 1)

@bi("LASTPOS")
def _lastpos(a, it):
    return str(a[1].rfind(a[0]) + 1)

@bi("INDEX")
def _index(a, it):
    # INDEX(haystack, needle[,start]) -> position or 0 (args reversed vs POS)
    start = _int(a[2], 1) if len(a) > 2 and a[2] else 1
    needle = a[1] if len(a) > 1 else ""
    return str(a[0].find(needle, max(0, start - 1)) + 1)

@bi("WORD")
def _word(a, it):
    w = a[0].split(); n = _int(a[1])
    return w[n - 1] if 1 <= n <= len(w) else ""

@bi("WORDS")
def _words(a, it): return str(len(a[0].split()))

@bi("SUBWORD")
def _subword(a, it):
    w = a[0].split(); n = _int(a[1]); ln = _int(a[2], len(w)) if len(a) > 2 and a[2] else len(w)
    return " ".join(w[n - 1:n - 1 + ln])

@bi("DELWORD")
def _delword(a, it):
    w = a[0].split(); n = _int(a[1]); ln = _int(a[2], len(w)) if len(a) > 2 and a[2] else len(w) - (n - 1)
    return " ".join(w[:n - 1] + w[n - 1 + ln:])

@bi("WORDPOS")
def _wordpos(a, it):
    hay = a[1].split(); needle = a[0].split()
    for i in range(len(hay) - len(needle) + 1):
        if hay[i:i + len(needle)] == needle:
            return str(i + 1)
    return "0"

@bi("STRIP")
def _strip(a, it):
    opt = (a[1][:1].upper() if len(a) > 1 and a[1] else "B")
    ch = (a[2] if len(a) > 2 and a[2] else " ")
    s = a[0]
    if opt in ("L", "B"): s = s.lstrip(ch)
    if opt in ("T", "B"): s = s.rstrip(ch)
    return s

@bi("SPACE")
def _space(a, it):
    n = _int(a[1], 1) if len(a) > 1 and a[1] != "" else 1
    pad = (a[2] if len(a) > 2 and a[2] else " ")[:1]
    words = a[0].split()
    return (pad * n).join(words)

@bi("REVERSE")
def _reverse(a, it): return a[0][::-1]

@bi("COPIES")
def _copies(a, it): return a[0] * _int(a[1])

@bi("CENTER")
def _center(a, it):
    ln = _int(a[1]); pad = (a[2] if len(a) > 2 and a[2] else " ")[:1]
    return a[0].center(ln, pad)[:ln]
BUILTINS["CENTRE"] = BUILTINS["CENTER"]

@bi("TRANSLATE")
def _translate(a, it):
    s = a[0]
    if len(a) < 2:
        return s.upper()
    to = a[1] if len(a) > 1 else ""
    fro = a[2] if len(a) > 2 else ""
    pad = (a[3] if len(a) > 3 and a[3] else " ")[:1]
    out = []
    for c in s:
        j = fro.find(c)
        if j >= 0:
            out.append(to[j] if j < len(to) else pad)
        else:
            out.append(c)
    return "".join(out)

@bi("VERIFY")
def _verify(a, it):
    ref = set(a[1]); s = a[0]
    match = len(a) > 2 and a[2][:1].upper() == "M"
    for i, c in enumerate(s):
        if (c in ref) == match:
            return str(i + 1)
    return "0"

@bi("OVERLAY")
def _overlay(a, it):
    new, s = a[0], a[1]; n = _int(a[2], 1) if len(a) > 2 and a[2] else 1
    ln = _int(a[3], len(new)) if len(a) > 3 and a[3] else len(new)
    pad = (a[4] if len(a) > 4 and a[4] else " ")[:1]
    new = (new + pad * ln)[:ln]
    s = s + " " * max(0, n - 1 - len(s))
    return s[:n - 1] + new + s[n - 1 + ln:]

@bi("INSERT")
def _insert(a, it):
    new, target = a[0], a[1]; n = _int(a[2], 0) if len(a) > 2 and a[2] else 0
    return target[:n] + new + target[n:]

@bi("DELSTR")
def _delstr(a, it):
    s = a[0]; n = _int(a[1]); ln = _int(a[2], len(s)) if len(a) > 2 and a[2] else len(s) - (n - 1)
    return s[:n - 1] + s[n - 1 + ln:]

@bi("ABBREV")
def _abbrev(a, it):
    info, short = a[0], a[1]
    ln = _int(a[2], len(short)) if len(a) > 2 and a[2] else len(short)
    return "1" if len(short) >= ln and info.startswith(short) and short != "" else ("1" if short == "" else "0")

@bi("COMPARE")
def _compare(a, it):
    s1, s2 = a[0], a[1]; pad = (a[2] if len(a) > 2 and a[2] else " ")[:1]
    m = max(len(s1), len(s2))
    s1 = s1.ljust(m, pad); s2 = s2.ljust(m, pad)
    for i in range(m):
        if s1[i] != s2[i]:
            return str(i + 1)
    return "0"

@bi("ABS")
def _abs(a, it): return str(abs(_num(a[0])))

@bi("SIGN")
def _sign(a, it):
    v = _num(a[0]); return "0" if v == 0 else ("1" if v > 0 else "-1")

@bi("MAX")
def _max(a, it): return str(max(_num(x) for x in a))

@bi("MIN")
def _min(a, it): return str(min(_num(x) for x in a))

@bi("TRUNC")
def _trunc(a, it):
    v = _num(a[0]); n = _int(a[1], 0) if len(a) > 1 and a[1] else 0
    q = Decimal(10) ** -n
    t = v.quantize(q, rounding="ROUND_DOWN")
    return str(t if n else int(t))

@bi("DATATYPE")
def _datatype(a, it):
    s = a[0].strip()
    if len(a) > 1 and a[1]:
        opt = a[1][:1].upper()
        checks = {"N": _isnum(s), "W": _iswhole(s), "A": s.isalnum(), "U": s.isupper() and s.isalpha(),
                  "L": s.islower() and s.isalpha(), "M": s.isalpha(), "D": s.isdigit(),
                  "X": _ishex(s), "B": all(c in "01" for c in s) and s != ""}
        return "1" if checks.get(opt, False) else "0"
    return "NUM" if _isnum(s) else "CHAR"

@bi("D2X")
def _d2x(a, it):
    v = int(_num(a[0])); return format(v & ((1 << 1024) - 1) if v < 0 else v, "X") if v >= 0 else format(v, "X")

@bi("X2D")
def _x2d(a, it): return str(int(a[0].strip() or "0", 16))

@bi("C2X")
def _c2x(a, it): return a[0].encode("latin-1", "replace").hex().upper()

@bi("X2C")
def _x2c(a, it): return bytes.fromhex(a[0].replace(" ", "")).decode("latin-1")

@bi("D2C")
def _d2c(a, it):
    v = int(_num(a[0])); return chr(v & 0xFF) if v >= 0 else ""

@bi("C2D")
def _c2d(a, it):
    return str(int.from_bytes(a[0].encode("latin-1", "replace"), "big")) if a[0] else "0"

@bi("FORMAT")
def _format(a, it):
    try:
        v = _num(a[0])
    except (InvalidOperation, ValueError, TypeError):
        # Control-block walkers (ENUM) hand FORMAT() raw storage bytes that are
        # not valid REXX numbers.  Rather than aborting the whole exec with a
        # Python conversion error, interpret the bytes as an unsigned big-endian
        # integer (as C2D would) so version/level fields still render.
        b = str(a[0]).encode("latin-1", "replace")
        v = Decimal(int.from_bytes(b, "big")) if b else Decimal(0)
    before = _int(a[1], None) if len(a) > 1 and a[1] else None
    after = _int(a[2], None) if len(a) > 2 and a[2] else None
    if after is not None:
        v = v.quantize(Decimal(10) ** -after)
    s = str(v)
    return s

@bi("DATE")
def _date(a, it):
    now = datetime.now()
    opt = (a[0][:1].upper() if a and a[0] else "N")
    return {"S": now.strftime("%Y%m%d"), "U": now.strftime("%m/%d/%y"),
            "E": now.strftime("%d/%m/%y"), "N": now.strftime("%d %b %Y").upper(),
            "W": now.strftime("%A"), "D": str(now.timetuple().tm_yday)}.get(opt, now.strftime("%d %b %Y").upper())

@bi("TIME")
def _time_fn(a, it):
    now = datetime.now()
    opt = (a[0][:1].upper() if a and a[0] else "N")
    return {"N": now.strftime("%H:%M:%S"), "L": now.strftime("%H:%M:%S.%f"),
            "H": str(now.hour), "M": str(now.hour * 60 + now.minute),
            "S": str(now.hour * 3600 + now.minute * 60 + now.second),
            "C": now.strftime("%I:%M%p").lower()}.get(opt, now.strftime("%H:%M:%S"))

@bi("RANDOM")
def _rand(a, it):
    if len(a) >= 2 and a[0] != "" and a[1] != "":
        return str(_random.randint(_int(a[0]), _int(a[1])))
    if len(a) >= 1 and a[0] != "":
        return str(_random.randint(0, _int(a[0])))
    return str(_random.randint(0, 999))

@bi("QUEUED")
def _queued(a, it): return str(len(it.queue))


def _isnum(s):
    try:
        Decimal(s.strip()); return s.strip() != ""
    except Exception:
        return False

def _iswhole(s):
    try:
        return _isnum(s) and Decimal(s.strip()) == int(Decimal(s.strip()))
    except Exception:
        return False

def _ishex(s):
    try:
        int(s.strip(), 16); return s.strip() != ""
    except Exception:
        return False


@bi("ARG")
def _arg_fn(a, it):
    if not a or a[0] == "":
        return str(getattr(it, "_argcount", 0))
    n = _int(a[0])
    if len(a) > 1 and a[1]:                       # ARG(n,'E'|'O') existence test
        opt = a[1][:1].upper()
        present = f"ARG{n}" in it.vars
        return "1" if (present if opt == "E" else not present) else "0"
    return it.vars.get(f"ARG{n}", "")


# --- bit operations on the byte values of two strings (RACF/ENUM flag tests) ---
def _bitop(a, op):
    s1 = a[0] if len(a) > 0 else ""
    s2 = a[1] if len(a) > 1 else ""
    pad = a[2][:1] if len(a) > 2 and a[2] else "\x00"
    n = max(len(s1), len(s2))
    s1 = s1.ljust(n, pad); s2 = s2.ljust(n, pad)
    return "".join(chr(op(ord(x), ord(y)) & 0xFF) for x, y in zip(s1, s2))

@bi("BITAND")
def _bitand(a, it): return _bitop(a, lambda x, y: x & y)

@bi("BITOR")
def _bitor(a, it): return _bitop(a, lambda x, y: x | y)

@bi("BITXOR")
def _bitxor(a, it): return _bitop(a, lambda x, y: x ^ y)


@bi("STORAGE")
def _storage(a, it):
    """TSO/E STORAGE(hexaddr[,len[,data]]) backed by the host control-block image."""
    host = getattr(it, "host", None)
    hs = getattr(host, "storage", None) if host is not None else None
    if hs is None:
        return ""
    try:
        addr = int(str(a[0]).strip(), 16)
    except Exception:
        return ""
    length = _int(a[1], 1) if len(a) > 1 and a[1] != "" else 1
    if len(a) > 2 and a[2] != "":
        data = a[2].encode("latin-1", errors="replace")[:length]
        hs.write(addr, data)
        return a[2]
    return hs.read(addr, length).decode("latin-1")


# --- TSO/E REXX external functions (SYSVAR / SYSDSN / LISTDSI) ---
def _host(it):
    return getattr(it, "host", None)

@bi("SYSCALLS")
def _syscalls(a, it):
    """z/OS UNIX REXX syscall setup: CALL SYSCALLS 'ON'|'OFF'|'SIGON'... .
    Marks the syscall environment ready so ADDRESS SYSCALL commands resolve.
    Returns 0 like the real interface."""
    op = (a[0] if a else "ON").strip().upper()
    it._syscall_ready = op not in ("OFF",)
    return "0"

@bi("USERID")
def _userid(a, it):
    """TSO/E USERID() - the userid of the caller.  ELV.APF and other tools call
    this with function syntax; fall back to the USERID variable then SYSUID."""
    host = _host(it)
    uid = (getattr(host, "sysuid", "") if host else "") or ""
    if not uid:
        uid = it.vars.get("USERID") or it.vars.get("SYSUID") or ""
    return str(uid).upper()

@bi("SYSVAR")
def _sysvar(a, it):
    key = (a[0] if a else "").upper()
    host = _host(it)
    uid = (getattr(host, "sysuid", "") if host else "") or ""
    return {
        "SYSUID": uid, "SYSPREF": uid, "SYSENV": "FORE", "SYSNODE": "GIBSON",
        "SYSLTERM": "43", "SYSWTERM": "80", "SYSCPU": "0", "SYSSRV": "0",
        "SYSHSM": "AVAILABLE", "SYSTSOE": "5660", "SYSISPF": "ACTIVE",
    }.get(key, "")

@bi("SYSDSN")
def _sysdsn(a, it):
    host = _host(it)
    dsn = (a[0] if a else "").strip().strip("'")
    try:
        if host and host.exists(dsn):
            return "OK"
    except Exception:
        pass
    return "DATASET NOT FOUND"

@bi("LISTDSI")
def _listdsi(a, it):
    host = _host(it)
    dsn = (a[0] if a else "").strip().strip("'").upper().split()[0] if a and a[0].strip() else ""
    exists = False
    try:
        exists = bool(host and host.exists(dsn))
    except Exception:
        pass
    v = getattr(it, "vars", None)
    if v is not None:
        v["SYSDSNAME"] = dsn
        v["SYSREASON"] = "0000" if exists else "0002"
        v["SYSVOLUME"] = "SYSAPF" if exists else ""
        v["SYSUNIT"] = "3390"
        v["SYSDSORG"] = "PO"
        v["SYSRECFM"] = "FB"
        v["SYSLRECL"] = "80"
        v["SYSBLKSIZE"] = "27920"
    return "0" if exists else "16"


@bi("OUTTRAP")
def _outtrap(a, it):
    """OUTTRAP('stem.') traps ADDRESS TSO output into stem.1..stem.n (stem.0=count);
    OUTTRAP('OFF') stops trapping.  Returns the previous stem name (or 'OFF')."""
    arg = (a[0] if a else "").strip()
    prev = getattr(it, "outtrap_stem", None) or "OFF"
    it.outtrap_stem = None if arg.upper() in ("OFF", "") else arg.rstrip(".").upper()
    return prev


@bi("X2B")
def _x2b(a, it):
    h = (a[0] if a else "").strip()
    try:
        return "".join(format(int(c, 16), "04b") for c in h if not c.isspace())
    except Exception:
        return ""

@bi("B2X")
def _b2x(a, it):
    b = (a[0] if a else "").replace(" ", "")
    if not b:
        return ""
    b = b.zfill(((len(b) + 3) // 4) * 4)
    return "".join(format(int(b[i:i + 4], 2), "X") for i in range(0, len(b), 4))
