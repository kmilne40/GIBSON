"""REXX interpreter (R1/early-R2): tree-walking evaluator."""
from __future__ import annotations

import re
from decimal import Decimal, getcontext, localcontext
from typing import Any, List, Optional

from . import ast as A
from .parser import parse, _StackOp
from .builtins import BUILTINS


class RexxError(Exception):
    def __init__(self, number: int, msg: str):
        super().__init__(f"REXX error {number}: {msg}")
        self.number = number


class _Exit(Exception):
    def __init__(self, value): self.value = value

class _Return(Exception):
    def __init__(self, value): self.value = value

class _Leave(Exception):
    pass

class _Iterate(Exception):
    pass


class _Signal(Exception):
    def __init__(self, label):
        self.label = label


class RexxResult:
    def __init__(self, rc, result, output):
        self.rc = rc
        self.result = result
        self.output = output


class Interpreter:
    def __init__(self, host=None, trace=False, max_clauses=1_000_000):
        self.host = host
        self.trace = trace
        self.max_clauses = max_clauses
        self.digits = 9
        self.vars = {"RC": "0", "RESULT": "", "SIGL": "0"}
        if host is not None:
            self.vars["USERID"] = host.sysuid
            self.vars["SYSUID"] = host.sysuid
        self.out: List[str] = []
        self.queue: List[str] = []
        self.top: List[Any] = []
        self.labels = {}
        self._clauses = 0
        self.address_env = "TSO"
        self.traps = {}          # condition -> label

    # ---------- public ----------
    def run(self, source: str, arg: str = "") -> RexxResult:
        prog = parse(source)
        self.top = prog.clauses
        self.labels = {c.name: i for i, c in enumerate(self.top) if isinstance(c, A.Label)}
        self.vars["ARG"] = arg
        self.vars["ARG1"] = arg
        self._arg = arg
        self._argv = [arg]
        self._argcount = 1 if arg != "" else 0
        pc = 0
        while True:
            try:
                self._exec_from(pc)
                break
            except _Exit as e:
                if e.value is not None:
                    self.vars["RC"] = e.value
                break
            except (_Leave, _Iterate):
                # LEAVE/ITERATE that reached the top with no enclosing loop: in
                # strict REXX this is a syntax error, but treat it leniently as
                # an end-of-exec so a stray one cannot crash the interpreter.
                break
            except _Signal as sig:
                if sig.label in self.labels:
                    self.vars["SIGL"] = str(self._clauses)
                    pc = self.labels[sig.label]
                else:
                    raise RexxError(16, f"label '{sig.label}' not found")
            except RexxError as e:
                if "SYNTAX" in self.traps:
                    self.vars["RC"] = str(e.number)
                    self.vars["SIGL"] = str(self._clauses)
                    lbl = self.traps["SYNTAX"]
                    if lbl in self.labels:
                        self.traps.pop("SYNTAX", None)  # avoid re-trapping loops
                        pc = self.labels[lbl]
                        continue
                raise
        return RexxResult(self.vars.get("RC", "0"), self.vars.get("RESULT", ""), self.out)

    # ---------- execution ----------
    def _exec_from(self, idx: int):
        i = idx
        while i < len(self.top):
            self.exec_clause(self.top[i])
            i += 1

    def exec_block(self, clauses: List[Any]):
        for c in clauses:
            self.exec_clause(c)

    def exec_clause(self, node):
        self._clauses += 1
        if self._clauses > self.max_clauses:
            raise RexxError(0, "clause limit exceeded")
        m = getattr(self, "_ex_" + type(node).__name__, None)
        if m is None:
            if isinstance(node, _StackOp):
                return self._ex_stack(node)
            return
        return m(node)

    def _ex_Label(self, n):  # falling into a label is a no-op
        pass

    def _ex_Nop(self, n):
        pass

    def _ex_Signal(self, n):
        raise _Signal(n.label)

    def _ex_SignalValue(self, n):
        raise _Signal(str(self.eval(n.expr)).upper())

    def _ex_SignalOn(self, n):
        if n.onoff == "ON":
            self.traps[n.cond] = n.label or n.cond
        else:
            self.traps.pop(n.cond, None)

    def _ex_Interpret(self, n):
        code = self.eval(n.expr)
        try:
            prog = parse(code)
        except Exception:
            return
        for c in prog.clauses:
            self.exec_clause(c)

    def _ex_Say(self, n):
        text = "" if n.expr is None else self.eval(n.expr)
        self.out.append(text)
        if self.host is not None:
            try:
                self.host.console(text)
            except Exception:
                pass

    def _ex_Assign(self, n):
        val = self.eval(n.expr)
        self._set_target(n.target, val)

    def _ex_Command(self, n):
        try:
            cmd = self.eval(n.expr)
        except (_Exit, _Return, _Signal, _Leave, _Iterate):
            # Control-flow exceptions must propagate; a function used as a bare
            # command clause (e.g. launch_payload(dsn)) can EXIT the whole exec.
            raise
        except Exception:
            # A bare command using non-expression syntax (EXECIO * DISKW dd (STEM s.)
            # cannot be evaluated as an expression - dispatch the raw clause text.
            raw = getattr(n, "raw", None)
            if raw is None:
                raise
            cmd = raw
        self._issue_command(self.address_env, cmd)

    def _ex_Address(self, n):
        if n.command is not None:
            self._issue_command(n.env or self.address_env, self.eval(n.command))
        elif n.env:
            self.address_env = n.env

    def _issue_command(self, env, cmd):
        if cmd.strip().upper().startswith("EXECIO"):
            self.vars["RC"] = str(self._execio(cmd))
            return
        # z/OS UNIX System Services syscall environment (CALL SYSCALLS 'ON';
        # ADDRESS SYSCALL; 'getpwent pw.').  Handle before the TSO fallback so the
        # commands don't leak to TSO as IKJ56500I NOT FOUND.
        if (env or "").upper() == "SYSCALL":
            self._syscall(cmd)
            return
        # REXX/TSO data-stack management (NEWSTACK / DELSTACK / QSTACK).  These
        # manage the data stack, not the host, so ENUM's TSTA path (NEWSTACK;
        # QUEUE 'END'; TESTAUTH; DELSTACK) must not route them to TSO.
        _verb = cmd.strip().split()[0].upper() if cmd.strip() else ""
        if _verb in ("NEWSTACK", "DELSTACK", "QSTACK"):
            if not hasattr(self, "_stack_frames"):
                self._stack_frames = []
            if _verb == "NEWSTACK":
                self._stack_frames.append(self.queue)
                self.queue = []
                self.vars["RC"] = "0"
            elif _verb == "DELSTACK":
                self.queue = self._stack_frames.pop() if self._stack_frames else []
                self.vars["RC"] = "0"
            else:  # QSTACK: number of stacks in existence (including the current)
                self.vars["RC"] = str(len(self._stack_frames) + 1)
            return
        # SUBMIT * [END(dlm)] : an in-stream job assembled onto the REXX stack.
        # ELV.APF/ELV.SVC drivers QUEUE their assemble-and-run JCL then SUBMIT * END($$);
        # drain it and route an ELV job to the Level B engine (else fall through).
        if self._maybe_submit_instream(cmd):
            return
        rc = 0
        lines = []
        if self.host is not None:
            try:
                if env == "TSO":
                    rc, lines = self.host.tso(cmd)
                    self._last_cmd_out = lines
                elif env == "ISPEXEC":
                    rc = self.host.ispexec(cmd)
                else:
                    rc, lines = self.host.tso(cmd)
            except Exception:
                rc = -3
        # OUTTRAP: route command output into a stem instead of the terminal
        stem = getattr(self, "outtrap_stem", None)
        if stem and lines:
            for i, ln in enumerate(lines, 1):
                self.vars[f"{stem}.{i}"] = ln
            self.vars[f"{stem}.0"] = str(len(lines))
        elif lines:
            # No active OUTTRAP: host-command output surfaces to the terminal/output,
            # as in real TSO/REXX (and as the legacy interpreter did).
            for ln in lines:
                self.out.append(ln)
        self.vars["RC"] = str(rc)
        if rc != 0 and "ERROR" in self.traps:
            raise _Signal(self.traps["ERROR"])
        if rc < 0 and "FAILURE" in self.traps:
            raise _Signal(self.traps["FAILURE"])

    def _syscall(self, cmd: str):
        """Minimal z/OS UNIX syscall command environment.  Implements the passwd
        enumeration used by ENUM's USSU option (setpwent/getpwent/endpwent) over
        GIBSON's RACF OMVS segments.  Sets RETVAL/ERRNO/ERRNOJR and RC like the
        real interface: RETVAL is a positive value while entries remain and 0 at
        end-of-file, which is what the caller's DO FOREVER loop tests."""
        toks = cmd.strip().split()
        if not toks:
            self.vars["RC"] = "0"; return
        verb = toks[0].lower()
        self.vars["ERRNO"] = "0"; self.vars["ERRNOJR"] = "0"

        def _pwlist():
            if getattr(self, "_pwent", None) is not None:
                return self._pwent
            entries = []
            state = getattr(self.host, "gibson_state", None) if self.host else None
            racf = getattr(state, "racf", None) if state else None
            users = getattr(racf, "users", {}) if racf else {}
            for u in users.values():
                if not getattr(u, "has_omvs", False):
                    continue
                seg = getattr(u, "omvs_segment", {}) or {}
                uid = seg.get("UID", seg.get("uid", "0"))
                gid = seg.get("GID", seg.get("gid", getattr(u, "default_group", "")))
                home = seg.get("HOME", seg.get("home")) or f"/u/{u.userid.lower()}"
                entries.append({"name": u.userid.upper(), "uid": str(uid),
                                "gid": str(gid), "dir": home})
            entries.sort(key=lambda e: (int(e["uid"]) if str(e["uid"]).lstrip("-").isdigit() else 0, e["name"]))
            self._pwent = entries
            return entries

        if verb == "setpwent":
            self._pwent_idx = 0
            self.vars["RETVAL"] = "0"; self.vars["RC"] = "0"; return
        if verb == "endpwent":
            self._pwent_idx = 0; self._pwent = None
            self.vars["RETVAL"] = "0"; self.vars["RC"] = "0"; return
        if verb == "getpwent":
            stem = (toks[1] if len(toks) > 1 else "PW.").rstrip(".").upper()
            entries = _pwlist()
            idx = getattr(self, "_pwent_idx", 0)
            if idx >= len(entries):
                self.vars["RETVAL"] = "0"     # end of file -> caller LEAVEs
                self.vars["RC"] = "0"; return
            e = entries[idx]
            self._pwent_idx = idx + 1
            self.vars[f"{stem}.PW_NAME"] = e["name"]
            self.vars[f"{stem}.PW_UID"] = e["uid"]
            self.vars[f"{stem}.PW_GID"] = e["gid"]
            self.vars[f"{stem}.PW_DIR"] = e["dir"]
            self.vars[f"{stem}.PW_SHELL"] = "/bin/sh"
            self.vars["RETVAL"] = str(idx + 1)  # positive while entries remain
            self.vars["RC"] = "0"; return
        # Unknown syscall command: succeed quietly so the exec keeps running.
        self.vars["RETVAL"] = "0"; self.vars["RC"] = "0"

    def _maybe_submit_instream(self, cmd: str) -> bool:
        """Handle `SUBMIT * [END(dlm)]`; return True if it was consumed here."""
        s = cmd.strip()
        toks = s.split()
        if len(toks) < 2 or toks[0].upper() != "SUBMIT" or toks[1] != "*":
            return False
        m = re.search(r"END\(\s*([^)]*?)\s*\)", s, re.I)
        delim = (m.group(1).strip() if m else "") or None
        # drain the queued in-stream JCL up to the end-of-data delimiter (or empty)
        jcl_lines: List[str] = []
        while self.queue:
            line = self.queue.pop(0)
            if delim is not None and line.strip() == delim:
                break
            jcl_lines.append(line)

        lines: List[str]
        host = self.host
        state = getattr(host, "gibson_state", None)
        hs = getattr(host, "storage", None)
        if state is None and hs is not None:
            state = getattr(hs, "state", None)
        userid = (getattr(host, "sysuid", None) or self.vars.get("USERID", "IBMUSER"))
        routed = None
        if state is not None and jcl_lines:
            try:
                from gibson.tools.elv_submit import route_submitted_jcl
                routed = route_submitted_jcl(state, userid, jcl_lines)
            except Exception as exc:
                # Fall back to ordinary SUBMIT handling, but do not lose the
                # reason. Swallowing this silently made assembler/storage gaps
                # look like "the exploit just did nothing", which is very hard to
                # diagnose from the terminal. Record it on the host, and surface
                # it when GIBSON_DEBUG is set.
                routed = None
                try:
                    setattr(host, "last_elv_route_error", exc)
                except Exception:
                    pass
                import os as _os
                if _os.environ.get("GIBSON_DEBUG"):
                    self.out.append(
                        f"IKJ56250I ELV ROUTING NOT APPLIED: {type(exc).__name__}: {exc}"
                    )
        if routed is not None:
            lines = routed
        else:
            lines = ["IKJ56250I IN-STREAM JOB SUBMITTED"] if jcl_lines else \
                    ["IKJ56700I MISSING DATA SET NAME"]

        self._last_cmd_out = lines
        for ln in lines:
            self.out.append(ln)
            if host is not None:
                try:
                    host.console(ln)
                except Exception:
                    pass
        stem = getattr(self, "outtrap_stem", None)
        if stem:
            for i, ln in enumerate(lines, 1):
                self.vars[f"{stem}.{i}"] = ln
            self.vars[f"{stem}.0"] = str(len(lines))
        self.vars["RC"] = "0"
        return True

    def _execio(self, cmd: str) -> int:
        """EXECIO count DISKR|DISKW ddname (STEM s. | FINIS | LIFO ...)."""
        if self.host is None:
            return 1
        body = cmd.strip()[len("EXECIO"):].strip()
        head, _, opts = body.partition("(")
        htoks = head.split()
        if len(htoks) < 3:
            return 20
        count_tok, direction, ddname = htoks[0], htoks[1].upper(), htoks[2]
        opts_up = opts.upper()
        mstem = re.search(r"STEM\s+([A-Za-z@#$][A-Za-z0-9@#$.]*)", opts, re.I)
        stem = mstem.group(1).rstrip(".").upper() if mstem else None
        lifo = "LIFO" in opts_up
        dsn = self.host.dd_to_dsn(ddname)
        if dsn is None:
            return 1
        if direction.startswith("DISKW"):
            if stem is None:
                return 20
            n = int(self._numval(self.vars.get(f"{stem}.0", "0")))
            recs = [self.vars.get(f"{stem}.{i}", "") for i in range(1, n + 1)]
            if count_tok != "*":
                recs = recs[:int(count_tok)]
            self.host.write_dataset(dsn, recs, disp="OLD")
            return 0
        if direction == "DISKR":
            try:
                recs = self.host.read_dataset(dsn)
            except Exception:
                return 1
            if count_tok != "*":
                recs = recs[:int(count_tok)]
            if stem is not None:
                for i, r in enumerate(recs, 1):
                    self.vars[f"{stem}.{i}"] = r
                self.vars[f"{stem}.0"] = str(len(recs))
            else:
                if lifo:
                    for r in reversed(recs):
                        self.queue.insert(0, r)
                else:
                    self.queue.extend(recs)
            return 0
        return 20

    def _ex_If(self, n):
        if self._truth(self.eval(n.cond)):
            if n.then is not None:
                self.exec_clause(n.then)
        elif n.els is not None:
            self.exec_clause(n.els)

    def _ex_Select(self, n):
        for cond, clause in n.whens:
            if self._truth(self.eval(cond)):
                self.exec_clause(clause)
                return
        if n.otherwise is not None:
            self.exec_block(n.otherwise)
        else:
            raise RexxError(7, "no OTHERWISE in SELECT")

    def _ex_Do(self, n):
        if n.ctrl is None:
            # A plain DO...END group is NOT a loop. Per REXX semantics, LEAVE and
            # ITERATE inside it target the nearest enclosing *loop*, so they must
            # propagate out of this group rather than be caught here. (Catching
            # _Leave here made `if cond then do; leave; end` silently fail to exit
            # the surrounding loop, which hung execs like a control-block walk.)
            self.exec_block(n.body)
            return
        try:
            if n.ctrl == "FOREVER":
                while True:
                    self._do_iter(n)
            elif n.ctrl == "TIMES":
                cnt = int(self._numval(self.eval(n.times)))
                for _ in range(cnt):
                    self._do_iter(n)
            elif n.ctrl == "WHILE":
                while self._truth(self.eval(n.cond)):
                    self._do_iter(n)
            elif n.ctrl == "UNTIL":
                while True:
                    self._do_iter(n)
                    if self._truth(self.eval(n.cond)):
                        break
            elif n.ctrl in ("CONTROLLED", "CWHILE", "CUNTIL"):
                self._do_controlled(n)
        except _Leave:
            pass

    def _do_iter(self, n):
        try:
            self.exec_block(n.body)
        except _Iterate:
            pass

    def _do_controlled(self, n):
        i = self._numval(self.eval(n.start))
        by = self._numval(self.eval(n.by)) if n.by is not None else Decimal(1)
        to = self._numval(self.eval(n.to)) if n.to is not None else None
        forn = int(self._numval(self.eval(n.forn))) if n.forn is not None else None
        count = 0
        while True:
            if to is not None:
                if by >= 0 and i > to:
                    break
                if by < 0 and i < to:
                    break
            if forn is not None and count >= forn:
                break
            self.vars[n.var] = self._fmt(i)
            if n.ctrl == "CWHILE" and not self._truth(self.eval(n.cond)):
                break
            try:
                self.exec_block(n.body)
            except _Iterate:
                pass
            if n.ctrl == "CUNTIL" and self._truth(self.eval(n.cond)):
                break
            i += by
            count += 1

    def _ex_Leave(self, n):
        raise _Leave()

    def _ex_Iterate(self, n):
        raise _Iterate()

    def _ex_Exit(self, n):
        raise _Exit(self.eval(n.expr) if n.expr is not None else None)

    def _ex_Return(self, n):
        raise _Return(self.eval(n.expr) if n.expr is not None else None)

    def _ex_Drop(self, n):
        for name in n.names:
            self.vars.pop(name, None)

    def _ex_Call(self, n):
        result = self._invoke(n.name, [self.eval(a) for a in n.args])
        self.vars["RESULT"] = result if result is not None else ""

    def _ex_stack(self, n):
        val = self.eval(n.expr) if n.expr is not None else ""
        if n.op == "PUSH":
            self.queue.insert(0, val)
        else:
            self.queue.append(val)

    def _ex_Parse(self, n):
        subs = self._split_template_commas(n.template)
        if n.source == "ARG":
            argv = list(getattr(self, "_argv", None) or [self._arg])
            for k, sub in enumerate(subs):
                self._parse_template(argv[k] if k < len(argv) else "", sub)
            return
        if n.source == "PULL":
            for sub in subs:
                line = self.queue.pop(0) if self.queue else ""
                self._parse_template(line, sub)
            return
        if n.source == "VAR":
            text = self._getvar(n.var)
        elif n.source == "VALUE":
            text = self.eval(n.value_expr)
        elif n.source == "LINEIN":
            text = ""
        else:
            text = ""
        # Non-ARG/PULL: first sub-template parses the string, any further
        # comma-separated sub-templates parse the empty string (REXX behaviour).
        for k, sub in enumerate(subs):
            self._parse_template(text if k == 0 else "", sub)

    @staticmethod
    def _split_template_commas(template):
        """Split a flat PARSE template on comma markers into sub-templates."""
        if not template:
            return [[]]
        subs, cur = [], []
        for item in template:
            if item[0] == ",":
                subs.append(cur); cur = []
            else:
                cur.append(item)
        subs.append(cur)
        return subs

    def _parse_template(self, text, template):
        """Full-ish REXX PARSE: word targets, literal delimiters, absolute/relative
        column positions, and (var) indirect literals."""
        if not template:
            return
        pos = 0
        i = 0
        n = len(template)
        while i < n:
            targets = []
            while i < n and template[i][0] in ("var", "."):
                targets.append(template[i]); i += 1
            # find the section end determined by the next pattern
            if i < n and template[i][0] in ("lit", "litvar"):
                lit = template[i][1] if template[i][0] == "lit" else self.vars.get(template[i][1], template[i][1])
                i += 1
                idx = text.find(lit, pos)
                if idx < 0:
                    section = text[pos:]; newpos = len(text)
                else:
                    section = text[pos:idx]; newpos = idx + len(lit)
                self._assign_parse(targets, section)
                pos = newpos
            elif i < n and template[i][0] == "pos":
                col = template[i][1] - 1; i += 1
                if col < 0:
                    col = 0
                section = text[pos:col] if col > pos else ""
                self._assign_parse(targets, section)
                pos = col
            elif i < n and template[i][0] == "rpos":
                col = pos + template[i][1]; i += 1
                col = max(0, col)
                section = text[pos:col] if col > pos else ""
                self._assign_parse(targets, section)
                pos = col
            else:
                self._assign_parse(targets, text[pos:])
                pos = len(text)

    def _assign_parse(self, targets, section):
        if not targets:
            return
        if len(targets) == 1:
            k, name = targets[0]
            if k == "var":
                self.vars[name] = section
            return
        parts = section.split(None, len(targets) - 1)
        for idx, (k, name) in enumerate(targets):
            val = parts[idx] if idx < len(parts) else ""
            if k == "var":
                self.vars[name] = val

    # ---------- routines ----------
    def _invoke(self, name, argvals):
        if name in self.labels and name not in ("",):
            return self._run_routine(name, argvals)
        if name in BUILTINS:
            return BUILTINS[name](argvals, self)
        raise RexxError(43, f"routine {name} not found")

    def _build_exposed_scope(self, exposed):
        """Build a called routine's variable scope from the caller's vars for the
        names in ``exposed``.  A name ending in '.' is a stem: every compound
        variable sharing that prefix is exposed (they are stored flat as
        ``STEM.TAIL``), so the routine shares the whole array with the caller."""
        scope = {}
        stems = [e for e in exposed if e.endswith(".")]
        simple = [e for e in exposed if not e.endswith(".")]
        for k in simple:
            if k in self.vars:
                scope[k] = self.vars[k]
        if stems:
            for vk, vv in self.vars.items():
                for st in stems:
                    if vk == st or vk.startswith(st):
                        scope[vk] = vv
                        break
        # Ensure the stem's default entry (if any) rides along even when empty.
        for st in stems:
            if st in self.vars and st not in scope:
                scope[st] = self.vars[st]
        return scope

    def _run_routine(self, name, argvals):
        idx = self.labels[name]
        saved_arg = self._arg
        saved_argv = getattr(self, "_argv", None)
        self._arg = argvals[0] if argvals else ""
        self._argv = list(argvals)
        saved_argcount = getattr(self, '_argcount', 0)
        self._argcount = len(argvals)
        # PROCEDURE scoping if the first following clause is a procedure marker
        new_scope = None
        start = idx + 1
        if start < len(self.top):
            nxt = self.top[start]
            if getattr(nxt, "is_procedure", False):
                exposed = list(getattr(nxt, "exposed", []))
                indirect = getattr(nxt, "exposed_indirect", [])
                # REXX indirect exposure: expose the named variable, then treat its
                # value as a subsidiary list of further variables to expose.
                for iname in indirect:
                    if iname not in exposed:
                        exposed.append(iname)
                    subsidiary = str(self.vars.get(iname, "")).split()
                    for sub in subsidiary:
                        su = sub.upper()
                        if su and su not in exposed:
                            exposed.append(su)
                new_scope = self._build_exposed_scope(exposed)
                new_scope.update({"RC": self.vars.get("RC", "0"), "RESULT": ""})
                start += 1
        saved_vars = None
        exposed_stems = tuple(e for e in exposed if e.endswith(".")) if new_scope is not None else ()
        exposed_simple = tuple(e for e in exposed if not e.endswith(".")) if new_scope is not None else ()
        if new_scope is not None:
            saved_vars = self.vars
            self.vars = new_scope
        # bind ARG.n
        for k, v in enumerate(argvals, 1):
            self.vars[f"ARG{k}"] = v
        result = None
        try:
            i = start
            while i < len(self.top):
                c = self.top[i]
                if isinstance(c, A.Label):
                    break  # fell through to next routine
                self.exec_clause(c)
                i += 1
        except _Return as r:
            result = r.value
        finally:
            if saved_vars is not None:
                # EXPOSE means the caller and callee share the variables: write the
                # callee's final values for every exposed simple var and every
                # exposed stem (all compound entries, stored flat) back to the caller.
                for k in ("RC",):
                    saved_vars[k] = self.vars.get(k, saved_vars.get(k))
                for k in exposed_simple:
                    if k in self.vars:
                        saved_vars[k] = self.vars[k]
                if exposed_stems:
                    for vk, vv in self.vars.items():
                        for st in exposed_stems:
                            if vk == st or vk.startswith(st):
                                saved_vars[vk] = vv
                                break
                self.vars = saved_vars
            self._arg = saved_arg
            self._argv = saved_argv
            self._argcount = saved_argcount
        return result

    # ---------- evaluation ----------
    def eval(self, node) -> str:
        return getattr(self, "_ev_" + type(node).__name__)(node)

    def _ev_Const(self, n): return n.value

    def _ev_Var(self, n): return self._getvar(n.name)

    def _ev_Compound(self, n):
        key = self._compound_key(n)
        return self.vars.get(key, key)

    def _ev_Concat(self, n):
        return self.eval(n.left) + (" " if n.blank else "") + self.eval(n.right)

    def _ev_Unary(self, n):
        v = self.eval(n.operand)
        if n.op in ("\\", "¬"):
            return "0" if self._truth(v) else "1"
        if n.op == "-":
            return self._fmt(-self._numval(v))
        if n.op == "+":
            return self._fmt(+self._numval(v))
        return v

    def _ev_FuncCall(self, n):
        args = [self.eval(a) for a in n.args]
        val = self._invoke(n.name, args)
        return val if val is not None else ""

    def _ev_Binary(self, n):
        op = n.op
        if op in ("&", "|", "&&"):
            l = self._truth(self.eval(n.left))
            r = self._truth(self.eval(n.right))
            if op == "&": return "1" if (l and r) else "0"
            if op == "|": return "1" if (l or r) else "0"
            return "1" if (l != r) else "0"
        left = self.eval(n.left)
        right = self.eval(n.right)
        if op in ("+", "-", "*", "/", "%", "//", "**"):
            return self._arith(op, left, right)
        # comparison
        return "1" if self._compare(op, left, right) else "0"

    def _arith(self, op, l, r):
        with localcontext() as ctx:
            ctx.prec = self.digits
            a, b = self._numval(l), self._numval(r)
            if op == "+": v = a + b
            elif op == "-": v = a - b
            elif op == "*": v = a * b
            elif op == "/": v = a / b
            elif op == "%": v = (a / b).to_integral_value(rounding="ROUND_DOWN")
            elif op == "//": v = a - b * ((a / b).to_integral_value(rounding="ROUND_DOWN"))
            elif op == "**": v = a ** int(b)
            else: v = Decimal(0)
        return self._fmt(v)

    def _compare(self, op, l, r):
        ln, rn = self._maybe_num(l), self._maybe_num(r)
        strict = op in ("==", "\\==", "¬==")
        if op in ("=", "==") :
            if ln is not None and rn is not None and not strict:
                return ln == rn
            return (l == r) if strict else (l.strip() == r.strip())
        if op in ("\\=", "/=", "><", "<>", "¬="):
            if ln is not None and rn is not None:
                return ln != rn
            return l.strip() != r.strip()
        # ordering
        if ln is not None and rn is not None:
            a, b = ln, rn
        else:
            a, b = l.strip(), r.strip()
        if op in ("<", "\\>", "¬>"): return a < b
        if op in (">", "\\<", "¬<"): return a > b
        if op == "<=": return a <= b
        if op == ">=": return a >= b
        return False

    # ---------- helpers ----------
    def _getvar(self, name):
        if name in self.vars:
            return self.vars[name]
        if "NOVALUE" in self.traps:
            raise _Signal(self.traps["NOVALUE"])
        return name

    def _set_target(self, target, val):
        if isinstance(target, A.Compound):
            self.vars[self._compound_key(target)] = val
        else:
            self.vars[target.name] = val

    def _compound_key(self, node: A.Compound):
        tails = []
        for piece in node.tails:
            if piece == "":
                tails.append("")
            elif _looks_const(piece):
                tails.append(piece.upper())
            else:
                tails.append(self.vars.get(piece.upper(), piece.upper()))
        return node.stem + "." + ".".join(tails)

    def _truth(self, v) -> bool:
        s = str(v).strip()
        if s == "1": return True
        if s == "0": return False
        raise RexxError(34, f"logical value must be 0 or 1, got '{v}'")

    def _numval(self, v) -> Decimal:
        try:
            return Decimal(str(v).strip() or "0")
        except Exception:
            raise RexxError(41, f"bad arithmetic operand '{v}'")

    def _maybe_num(self, v):
        try:
            s = str(v).strip()
            if s == "":
                return None
            return Decimal(s)
        except Exception:
            return None

    def _fmt(self, d: Decimal) -> str:
        if d == d.to_integral_value() and abs(d) < Decimal(10) ** self.digits:
            return str(int(d))
        s = str(d.normalize())
        if "E" in s:
            s = format(d, "f")
        return s


def _looks_const(piece: str) -> bool:
    p = piece.strip()
    if p == "":
        return True
    try:
        Decimal(p)
        return True
    except Exception:
        return p[:1] in "0123456789"


# ---- public engine + legacy shim ----
def _default_max_clauses() -> int:
    """Clause guard against runaway loops.  Overridable for large real execs via
    GIBSON_REXX_MAX_CLAUSES (a control-block walker with a bounded ASVT should
    never approach the default, but this keeps the guard tunable)."""
    import os
    try:
        v = int(os.environ.get("GIBSON_REXX_MAX_CLAUSES", "").strip())
        return v if v > 0 else 5_000_000
    except (ValueError, TypeError):
        return 5_000_000


class RexxEngine:
    def __init__(self, host=None, trace=False, max_clauses=None):
        self._it = Interpreter(host, trace, max_clauses or _default_max_clauses())

    def run(self, source: str, arg: str = "") -> RexxResult:
        return self._it.run(source, arg)
