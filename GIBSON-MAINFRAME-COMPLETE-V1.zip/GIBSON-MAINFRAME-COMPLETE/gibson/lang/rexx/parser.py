"""REXX parser (R1/early-R2): tokens -> clause tree."""
from __future__ import annotations

from . import ast as A
from .tokens import Token, tokenize, SYMBOL, STRING, OP, SPECIAL, EOL, EOF

_KEYWORDS = {"SAY", "IF", "THEN", "ELSE", "DO", "END", "SELECT", "WHEN", "OTHERWISE",
             "CALL", "RETURN", "EXIT", "NOP", "LEAVE", "ITERATE", "PARSE", "ADDRESS",
             "DROP", "PROCEDURE", "PULL", "PUSH", "QUEUE", "ARG", "SIGNAL", "INTERPRET",
             "NUMERIC", "TRACE"}

# comparison operators
_COMP = {"=", "==", "\\=", "/=", "><", "<>", "<", ">", "<=", ">=", "\\<", "\\>",
         "¬=", "¬<", "¬>"}


class ParseError(Exception):
    pass


class Parser:
    def __init__(self, toks: list[Token], src: str = ""):
        self.t = toks
        self.src = src
        self.i = 0
        self._stop = set()          # keywords that terminate the current expression

    def _expr_stop(self, words):
        saved = self._stop
        self._stop = words
        try:
            return self.parse_expr()
        finally:
            self._stop = saved

    # ---- token helpers ----
    def peek(self, k=0) -> Token:
        return self.t[min(self.i + k, len(self.t) - 1)]

    def next(self) -> Token:
        tok = self.t[self.i]
        if self.i < len(self.t) - 1:
            self.i += 1
        return tok

    def skip_eol(self):
        while self.peek().kind in (EOL,) or (self.peek().kind == SPECIAL and self.peek().value == ";"):
            self.next()

    def at_clause_end(self) -> bool:
        t = self.peek()
        return t.kind in (EOL, EOF) or (t.kind == SPECIAL and t.value == ";")

    def sym_is(self, *words) -> bool:
        t = self.peek()
        return t.kind == SYMBOL and t.value.upper() in words

    def eat_sym(self, word) -> bool:
        if self.sym_is(word):
            self.next(); return True
        return False

    # ---- program ----
    def parse_program(self) -> A.Program:
        clauses = []
        self.skip_eol()
        while self.peek().kind != EOF:
            c = self.parse_clause()
            if c is not None:
                clauses.append(c)
            self.skip_eol()
        return A.Program(clauses)

    # ---- clause dispatch ----
    def parse_clause(self):
        t = self.peek()
        # label:  SYMBOL ':'
        if t.kind == SYMBOL and self.peek(1).kind == SPECIAL and self.peek(1).value == ":":
            name = self.next().value.upper(); self.next()  # consume ':'
            return A.Label(name)
        # assignment:  SYMBOL '=' expr   (plain '=' only)
        if t.kind == SYMBOL and self.peek(1).kind == OP and self.peek(1).value == "=":
            target = self._compound_from_symbol(self.next().value)
            self.next()  # '='
            expr = self.parse_expr()
            return A.Assign(target, expr)
        # keyword instructions
        if t.kind == SYMBOL and t.value.upper() in _KEYWORDS:
            kw = t.value.upper()
            handler = getattr(self, f"_kw_{kw.lower()}", None)
            if handler:
                self.next()
                return handler()
        # otherwise: a command (bare expression issued to host env)
        start = self.t[self.i].pos if self.i < len(self.t) else 0
        expr = self.parse_expr()
        # Consume any remainder of the clause and capture the full raw text, so
        # commands using non-expression syntax (e.g. EXECIO * DISKW dd (STEM s.)
        # can be dispatched literally if expression evaluation fails.
        while not self.at_clause_end():
            self.next()
        raw = None
        if self.src and self.i > 0:
            last = self.t[self.i - 1]
            raw = self.src[start:last.pos + len(str(last.value))]
        return A.Command(expr, raw)

    # ---- keyword instructions ----
    def _kw_say(self):
        if self.at_clause_end():
            return A.Say(None)
        return A.Say(self.parse_expr())

    def _kw_nop(self):
        return A.Nop()

    def _kw_leave(self):
        return A.Leave()

    def _kw_iterate(self):
        return A.Iterate()

    def _kw_exit(self):
        return A.Exit(None if self.at_clause_end() else self.parse_expr())

    def _kw_return(self):
        return A.Return(None if self.at_clause_end() else self.parse_expr())

    def _kw_drop(self):
        names = []
        while self.peek().kind == SYMBOL:
            names.append(self.next().value.upper())
        return A.Drop(names)

    def _kw_call(self):
        name = self.next().value.upper()
        args = []
        while not self.at_clause_end():
            args.append(self.parse_expr())
            if self.peek().kind == SPECIAL and self.peek().value == ",":
                self.next()
            else:
                break
        return A.Call(name, args)

    def _kw_signal(self):
        if self.sym_is("ON", "OFF"):
            onoff = self.next().value.upper()
            cond = self.next().value.upper() if self.peek().kind == SYMBOL else ""
            label = None
            if self.eat_sym("NAME"):
                label = self.next().value.upper()
            return A.SignalOn(onoff, cond, label)
        if self.eat_sym("VALUE"):
            return A.SignalValue(self.parse_expr())
        target = self.next().value.upper() if self.peek().kind == SYMBOL else ""
        return A.Signal(target)

    def _kw_address(self):
        env = None
        cmd = None
        t = self.peek()
        # Environment may be a symbol (ADDRESS TSO) or a literal string
        # (ADDRESS 'TSO' 'NEWSTACK'); the remainder, if any, is one command.
        if t.kind in (SYMBOL, STRING) and not self.at_clause_end():
            env = self.next().value.upper()
        if not self.at_clause_end():
            cmd = self.parse_expr()
        return A.Address(env, cmd)

    def _kw_interpret(self):
        return A.Interpret(self.parse_expr())

    def _kw_numeric(self):
        while not self.at_clause_end():
            self.next()
        return A.Nop()

    def _kw_trace(self):
        while not self.at_clause_end():
            self.next()
        return A.Nop()

    def _kw_procedure(self):
        # PROCEDURE [EXPOSE names] - represented as Nop marker handled by interp.
        # Supports REXX indirect exposure: a name in parentheses, e.g.
        #   PROCEDURE EXPOSE (globalVars) warningDatasets
        # means "expose globalVars, then expose every variable named in its value".
        # The parenthesized names are resolved to a subsidiary list at run time.
        exposed = []          # explicit names
        exposed_indirect = [] # names whose value is a subsidiary variable list
        if self.eat_sym("EXPOSE"):
            while True:
                t = self.peek()
                if t.kind == SYMBOL:
                    exposed.append(self.next().value.upper())
                elif t.kind == SPECIAL and t.value == "(":
                    self.next()  # consume '('
                    while self.peek().kind == SYMBOL:
                        exposed_indirect.append(self.next().value.upper())
                    if self.peek().kind == SPECIAL and self.peek().value == ")":
                        self.next()  # consume ')'
                else:
                    break
        node = A.Nop()
        node.exposed = exposed  # attach for interp
        node.exposed_indirect = exposed_indirect
        node.is_procedure = True
        return node

    def _kw_pull(self):
        return A.Parse("PULL", None, None, self._template())

    def _kw_arg(self):
        return A.Parse("ARG", None, None, self._template())

    def _kw_push(self):
        return _StackOp("PUSH", None if self.at_clause_end() else self.parse_expr())

    def _kw_queue(self):
        return _StackOp("QUEUE", None if self.at_clause_end() else self.parse_expr())

    def _kw_parse(self):
        self.eat_sym("UPPER")
        self.eat_sym("CASELESS")
        if self.eat_sym("ARG"):
            return A.Parse("ARG", None, None, self._template())
        if self.eat_sym("PULL"):
            return A.Parse("PULL", None, None, self._template())
        if self.eat_sym("VAR"):
            var = self.next().value.upper()
            return A.Parse("VAR", var, None, self._template())
        if self.eat_sym("VALUE"):
            expr = self._expr_stop({'WITH'})
            self.eat_sym("WITH")
            return A.Parse("VALUE", None, expr, self._template())
        if self.eat_sym("LINEIN"):
            return A.Parse("LINEIN", None, None, self._template())
        if self.eat_sym("SOURCE"):
            return A.Parse("SOURCE", None, None, self._template())
        # unknown source: skip
        while not self.at_clause_end():
            self.next()
        return A.Nop()

    def _template(self):
        """Template items: ('var',NAME) | ('lit',str) | ('.',None) | ('pos',n) | ('rpos',n)."""
        items = []
        while not self.at_clause_end():
            t = self.peek()
            if t.kind == OP and t.value in ("+", "-"):
                self.next()
                nt = self.peek()
                if nt.kind == SYMBOL and _is_number(nt.value):
                    self.next()
                    n = int(float(nt.value))
                    items.append(("rpos", n if t.value == "+" else -n))
                continue
            if t.kind == SYMBOL:
                self.next()
                if t.value == ".":
                    items.append((".", None))
                elif _is_number(t.value):
                    items.append(("pos", int(float(t.value))))
                else:
                    items.append(("var", t.value.upper()))
            elif t.kind == STRING:
                self.next()
                items.append(("lit", t.value))
            elif t.kind == SPECIAL and t.value == "(":
                # (var) indirect literal - treat contents as a variable literal source
                self.next()
                if self.peek().kind == SYMBOL:
                    items.append(("litvar", self.next().value.upper()))
                if self.peek().kind == SPECIAL and self.peek().value == ")":
                    self.next()
            elif t.kind == SPECIAL and t.value == ",":
                # comma separates sub-templates: PARSE ARG a, b parses successive
                # arguments; PARSE PULL a, b parses successive stack lines.
                self.next()
                items.append((",", None))
            else:
                self.next()
        return items

    def _kw_if(self):
        cond = self._expr_stop({'THEN'})
        self.skip_eol()
        self.eat_sym("THEN")
        self.skip_eol()
        then = self.parse_clause_or_do()
        els = None
        save = self.i
        self.skip_eol()
        if self.eat_sym("ELSE"):
            self.skip_eol()
            els = self.parse_clause_or_do()
        else:
            self.i = save
        return A.If(cond, then, els)

    def parse_clause_or_do(self):
        if self.sym_is("DO"):
            self.next()
            return self._kw_do()
        return self.parse_clause()

    def _kw_do(self):
        ctrl = var = start = to = by = forn = cond = times = None
        if self.sym_is("FOREVER"):
            self.next(); ctrl = "FOREVER"
        elif self.peek().kind == SYMBOL and self.peek(1).kind == OP and self.peek(1).value == "=":
            var = self.next().value.upper(); self.next()  # '='
            start = self._expr_stop({'TO','BY','FOR','WHILE','UNTIL'}); ctrl = "CONTROLLED"
            while True:
                if self.eat_sym("TO"):
                    to = self._expr_stop({'TO','BY','FOR','WHILE','UNTIL'})
                elif self.eat_sym("BY"):
                    by = self._expr_stop({'TO','BY','FOR','WHILE','UNTIL'})
                elif self.eat_sym("FOR"):
                    forn = self._expr_stop({'TO','BY','FOR','WHILE','UNTIL'})
                else:
                    break
            if self.eat_sym("WHILE"):
                cond = self.parse_expr(); ctrl = "CWHILE"
            elif self.eat_sym("UNTIL"):
                cond = self.parse_expr(); ctrl = "CUNTIL"
        elif self.eat_sym("WHILE"):
            cond = self.parse_expr(); ctrl = "WHILE"
        elif self.eat_sym("UNTIL"):
            cond = self.parse_expr(); ctrl = "UNTIL"
        elif not self.at_clause_end():
            times = self._expr_stop({'WHILE','UNTIL'}); ctrl = "TIMES"
        body = self._block(("END",))
        had_end = self.eat_sym("END")
        # optional control var after END (e.g. END I) - only when END was present,
        # so an implicit close at a label boundary does not swallow the label.
        if had_end and self.peek().kind == SYMBOL and not self.at_clause_end():
            self.next()
        return A.Do(body, ctrl, var, start, to, by, forn, cond, times)

    def _kw_select(self):
        self.skip_eol()
        whens = []
        otherwise = None
        while True:
            self.skip_eol()
            if self.eat_sym("WHEN"):
                c = self._expr_stop({'THEN'})
                self.skip_eol()
                self.eat_sym("THEN")
                self.skip_eol()
                clause = self.parse_clause_or_do()
                whens.append((c, clause))
            elif self.eat_sym("OTHERWISE"):
                otherwise = self._block(("END",))
            elif self.eat_sym("END"):
                break
            elif self.peek().kind == EOF:
                break
            elif self._at_label():
                break   # label ends the SELECT (implicit END)
            else:
                self.next()
        return A.Select(whens, otherwise)

    def _at_label(self):
        """True if the next clause is a label (SYMBOL ':').  A label implicitly
        terminates any open DO/SELECT group, so a routine's label is never
        swallowed into a preceding group with a missing END (a pattern that
        occurs in real-world execs such as ELV.APF's list_apf)."""
        t = self.peek()
        return (t.kind == SYMBOL and self.peek(1).kind == SPECIAL
                and self.peek(1).value == ":")

    def _block(self, terminators):
        body = []
        while True:
            self.skip_eol()
            t = self.peek()
            if t.kind == EOF:
                break
            if t.kind == SYMBOL and t.value.upper() in terminators:
                break
            if self._at_label():
                break   # label ends the block (implicit END)
            body.append(self.parse_clause())
        return body

    # ---- expressions ----
    def parse_expr(self):
        return self._or()

    def _or(self):
        left = self._and()
        while self.peek().kind == OP and self.peek().value in ("|", "&&"):
            op = self.next().value
            left = A.Binary(op, left, self._and())
        return left

    def _and(self):
        left = self._comp()
        while self.peek().kind == OP and self.peek().value == "&":
            self.next()
            left = A.Binary("&", left, self._comp())
        return left

    def _comp(self):
        left = self._concat()
        while self.peek().kind == OP and self.peek().value in _COMP:
            op = self.next().value
            left = A.Binary(op, left, self._concat())
        return left

    def _concat(self):
        left = self._add()
        while True:
            t = self.peek()
            if t.kind == OP and t.value == "||":
                self.next()
                left = A.Concat(left, self._add(), False)
            elif self._starts_term(t):
                # abuttal: two terms adjacent -> concatenation (blank if space between)
                left = A.Concat(left, self._add(), t.had_space)
            else:
                break
        return left

    def _starts_term(self, t: Token) -> bool:
        if t.kind == SYMBOL:
            return t.value.upper() not in self._stop
        if t.kind == STRING:
            return True
        if t.kind == SPECIAL and t.value == "(":
            return True
        return False

    def _add(self):
        left = self._mul()
        while self.peek().kind == OP and self.peek().value in ("+", "-"):
            op = self.next().value
            left = A.Binary(op, left, self._mul())
        return left

    def _mul(self):
        left = self._power()
        while self.peek().kind == OP and self.peek().value in ("*", "/", "%", "//"):
            op = self.next().value
            left = A.Binary(op, left, self._power())
        return left

    def _power(self):
        left = self._unary()
        if self.peek().kind == OP and self.peek().value == "**":
            self.next()
            return A.Binary("**", left, self._power())  # right assoc
        return left

    def _unary(self):
        t = self.peek()
        if t.kind == OP and t.value in ("-", "+", "\\", "¬"):
            self.next()
            return A.Unary(t.value, self._unary())
        return self._primary()

    def _primary(self):
        t = self.peek()
        if t.kind == STRING:
            self.next()
            return A.Const(t.value)
        if t.kind == SPECIAL and t.value == "(":
            self.next()
            e = self.parse_expr()
            if self.peek().kind == SPECIAL and self.peek().value == ")":
                self.next()
            return e
        if t.kind == SYMBOL:
            # function call: name immediately followed by '(' (no space)
            nxt = self.peek(1)
            if nxt.kind == SPECIAL and nxt.value == "(" and not nxt.had_space:
                name = self.next().value.upper()
                self.next()  # '('
                args = []
                if not (self.peek().kind == SPECIAL and self.peek().value == ")"):
                    while True:
                        # allow omitted args (,,)
                        if self.peek().kind == SPECIAL and self.peek().value in ",)":
                            args.append(A.Const(""))
                        else:
                            args.append(self.parse_expr())
                        if self.peek().kind == SPECIAL and self.peek().value == ",":
                            self.next(); continue
                        break
                if self.peek().kind == SPECIAL and self.peek().value == ")":
                    self.next()
                return A.FuncCall(name, args)
            self.next()
            return self._term_from_symbol(t.value)
        # fallback empty
        self.next()
        return A.Const("")

    def _term_from_symbol(self, s: str):
        # numeric constant?
        if _is_number(s):
            return A.Const(s)
        return self._compound_from_symbol(s)

    def _compound_from_symbol(self, s: str):
        if "." in s and not s.endswith(".") is None:
            pass
        if "." in s:
            parts = s.split(".")
            stem = parts[0].upper()
            tails = parts[1:]
            return A.Compound(stem, tails)
        return A.Var(s.upper())


class _StackOp:
    def __init__(self, op, expr):
        self.op = op; self.expr = expr


def _is_number(s: str) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return False


def parse(src: str) -> A.Program:
    return Parser(tokenize(src), src).parse_program()
