"""Simulated z/OS storage + control-block image for the REXX interpreter.

Control-block-walking REXX tools (ENUM and friends) read raw storage with the TSO/E
``STORAGE()`` function and their own ``GetPtr``/``GetStorage`` wrappers, dereferencing the
CVT at absolute address x'10' and walking to the RCVT (RACF), the ASVT/ASCB chain (address
spaces), and so on.  This module lays those control blocks out at their real offsets,
populated from GIBSON state, so the walk lands on GIBSON data.

Offsets used (from the MVS Data Areas, the ones the walkers actually dereference):
    PSA  + x'10' (16)   -> CVT address           (PSACVT)
    CVT  + x'22C'(556)  -> ASVT address          (CVTASVT)
    CVT  + x'3E0'(992)  -> RCVT address          (CVTRAC)
    ASVT + x'200'(512)  -> first ASCB-pointer entry (walkers add 512 to skip the header)
    ASCB + x'24' (36)   -> ASID (halfword)        (ASCBASID)
    ASCB + x'B0' (176)  -> jobname pointer (STC)  (ASCBJBNS)
    ASCB + x'AC' (172)  -> jobname pointer (TSO)  (ASCBJBNI)
    RCVT + 0            -> 'RCVT' eyecatcher; + x'18' -> primary RACF dataset name
Authorised GIBSON training use only.
"""
from __future__ import annotations
from typing import Dict, List, Optional

PSACVT = 16
PSAAOLD = 0x224        # PSA+x'224' -> current ASCB
CVTASVT = 556
CVTRAC = 992
CVTAUTHL = 484         # CVT+x'1E4' -> APF authorization list (CVTAUTHL)
CVTSCVT = 200          # CVT+x'C8' -> SCVT (secondary CVT)
CVTECVT = 140          # CVT+x'8C' -> ECVT (extended CVT)
CVTPRODN = 0x150       # CVT product name (approx) - training value
CVTPRODI = 0x158       # CVT product id / FMID (approx) - training value
SCVTSVCT = 132         # SCVT+x'84' -> SVC table
ASVT_ENTRIES = 512     # legacy alias (kept for any external reference)
ASVTMAXU_OFF = 0x204   # ASVT+x'204' -> ASVTMAXU (number of address-space slots)
ASVTENTY_OFF = 0x210   # ASVT+x'210' -> first ASCB-pointer entry (real z/OS offset)
ASCBASID = 36
ASCBCSCB = 56          # ASCB+x'38' -> CSCB
CSCBCHTR = 28          # CSCB+x'1C' -> CHTRKID (address-space type byte)
ASCBASXB = 0x6C        # ASCB+x'6C' -> ASXB
ASCBOUCB = 144         # ASCB+x'90' -> OUCB
OUCBSUBN = 176         # OUCB+x'B0' -> subsystem name (4)  ('OMVS' for USS)
OUCBTRXN = 200         # OUCB+x'C8' -> transaction/job name (8)
OUCBUSRD = 208         # OUCB+x'D0' -> userid (8)
ASCBJBNI = 172
ASCBJBNS = 176
ASXBSENV = 0xC8        # ASXB+x'C8' -> ACEE
ACEEUSRI = 0x15        # ACEE+x'15' -> userid
ACEEFLG1 = 0x26        # ACEE+x'26' -> SPECIAL(x'80')/OPERATIONS(x'40')/AUDITOR(x'20')
RCVT_DSN = 0x18


class HostStorage:
    """A sparse, byte-addressable storage image with a bump allocator."""

    def __init__(self, base: int = 0x00010000):
        self.mem: Dict[int, int] = {}
        self._next = base

    # --- raw access ---
    def read(self, addr: int, length: int) -> bytes:
        return bytes(self.mem.get(addr + i, 0) for i in range(max(0, length)))

    def write(self, addr: int, data: bytes) -> None:
        for i, b in enumerate(data):
            self.mem[addr + i] = b & 0xFF

    def word(self, addr: int) -> int:
        return int.from_bytes(self.read(addr, 4), "big")

    def putword(self, addr: int, value: int) -> None:
        self.write(addr, (value & 0xFFFFFFFF).to_bytes(4, "big"))

    def half(self, addr: int) -> int:
        """Halfword fetch, the read counterpart of puthalf().

        The S/390 interpreter needs this for LH/AH/CH/MH against the live
        control-block image; without it those instructions raised AttributeError
        and any exploit using them was silently abandoned.
        """
        return int.from_bytes(self.read(addr, 2), "big")

    def puthalf(self, addr: int, value: int) -> None:
        self.write(addr, (value & 0xFFFF).to_bytes(2, "big"))

    def alloc(self, size: int, align: int = 8) -> int:
        addr = (self._next + align - 1) & ~(align - 1)
        self._next = addr + size
        # touch the range so reads are defined
        for i in range(size):
            self.mem.setdefault(addr + i, 0)
        return addr

    def put_ebcdic(self, addr: int, text: str, length: int) -> None:
        raw = text.upper()[:length].ljust(length).encode("latin-1", errors="replace")
        self.write(addr, raw)

    def alloc_ebcdic(self, text: str, length: int) -> int:
        a = self.alloc(length)
        self.put_ebcdic(a, text, length)
        return a


# chtrkid address-space type codes (CSCB+x'1C'), as classified by control-block
# walkers such as ENUM: TSO=x'01', started task=x'02', batch=x'03', system=x'04'.
CHT_TSO, CHT_STC, CHT_BATCH, CHT_SYSTEM = 0x01, 0x02, 0x03, 0x04


def _address_spaces(state, userid: str) -> List[tuple]:
    """(asid, jobname, chtype, is_omvs) for the address spaces GIBSON knows about.

    chtype drives the real-tool classification (started task / TSO / system /
    batch); is_omvs marks address spaces that carry an OMVS OUCB so the USS-user
    branch of a walker resolves them."""
    spaces: List[tuple] = [
        (1, "*MASTER*", CHT_SYSTEM, False), (2, "PCAUTH", CHT_SYSTEM, False),
        (3, "RASP", CHT_SYSTEM, False), (4, "TRACE", CHT_SYSTEM, False),
        (5, "DUMPSRV", CHT_SYSTEM, False), (6, "CONSOLE", CHT_SYSTEM, False),
        (7, "ALLOCAS", CHT_SYSTEM, False),
    ]
    asid = 20
    # started tasks GIBSON models (OMVS kernel address space carries an OUCB)
    for stc in ("JES2", "RACF", "VTAM", "TCPIP", "TN3270", "CICSPA01", "OMVS", "DB2MSTR"):
        spaces.append((asid, stc, CHT_STC, stc == "OMVS")); asid += 1
    # logged-on TSO users; a user with an OMVS segment also carries an OUCB
    def _has_omvs(uid):
        try:
            u = state.racf.users.get(uid.upper())
            return bool(u and getattr(u, "has_omvs", False))
        except Exception:
            return False
    try:
        for sess in getattr(state.sessions, "sessions", {}).values():
            uid = getattr(sess, "userid", "") or ""
            if uid:
                spaces.append((asid, uid, CHT_TSO, _has_omvs(uid))); asid += 1
    except Exception:
        pass
    if not any(u == userid.upper() for _, u, _, _ in spaces):
        spaces.append((asid, userid.upper(), CHT_TSO, _has_omvs(userid)))
    return spaces


def build_storage(state, userid: str = "IBMUSER") -> HostStorage:
    """Lay out PSA -> CVT -> {ASVT/ASCB chain, RCVT} from GIBSON state."""
    hs = HostStorage()
    # keep a back-reference so callers holding only the storage image (e.g. the
    # SUBMIT * hook via it.host.storage) can reach live GIBSON state/userid.
    hs.state = state
    hs.userid = userid.upper()
    spaces = _address_spaces(state, userid)

    cvt = hs.alloc(0x400)
    hs.putword(PSACVT, cvt)                       # PSA+x'10' -> CVT

    # --- ASVT + ASCB chain (real z/OS layout) ---
    #   ASVT+x'204' = ASVTMAXU (slot count); ASVT+x'210' = first ASCB-pointer.
    #   Each ASCB carries a CSCB (type byte CHTRKID) and, for USS address spaces,
    #   an OUCB, so control-block walkers classify started tasks / TSO / system /
    #   batch / OMVS users correctly and their DO 0 TO ASVTMAXU-1 loop is bounded.
    asvt = hs.alloc(ASVTENTY_OFF + len(spaces) * 4 + 16)
    hs.putword(cvt + CVTASVT, asvt)
    hs.putword(asvt + ASVTMAXU_OFF, len(spaces))   # ASVTMAXU
    caller_ascb = None
    for i, entry in enumerate(spaces):
        asid, jobname, chtype, is_omvs = entry
        ascb = hs.alloc(0x100)
        jn = hs.alloc_ebcdic(jobname, 8)
        hs.puthalf(ascb + ASCBASID, asid)
        hs.putword(ascb + ASCBJBNS, jn)           # started-task jobname pointer
        hs.putword(ascb + ASCBJBNI, jn)           # TSO/init jobname pointer
        # CSCB with the address-space type byte (CHTRKID)
        cscb = hs.alloc(0x40)
        hs.putword(ascb + ASCBCSCB, cscb)
        hs.write(cscb + CSCBCHTR, bytes([chtype & 0xFF]))
        # OUCB: subsysname 'OMVS' (+ userid) for USS spaces, blank otherwise
        oucb = hs.alloc(0x100)
        hs.putword(ascb + ASCBOUCB, oucb)
        hs.put_ebcdic(oucb + OUCBSUBN, "OMVS" if is_omvs else "    ", 4)
        hs.put_ebcdic(oucb + OUCBTRXN, jobname, 8)
        hs.put_ebcdic(oucb + OUCBUSRD, jobname if is_omvs else "        ", 8)
        hs.putword(asvt + ASVTENTY_OFF + i * 4, ascb)
        if jobname.upper() == userid.upper():
            caller_ascb = ascb

    # --- RCVT (RACF) ---
    rcvt = hs.alloc(0x100)
    hs.putword(cvt + CVTRAC, rcvt)
    hs.put_ebcdic(rcvt + 0, "RCVT", 4)
    racf_dsn = "SYS1.RACFDS"
    try:
        # prefer the live primary RACF dataset if GIBSON exposes one
        racf_dsn = getattr(state, "racf_primary_dsn", None) or racf_dsn
    except Exception:
        pass
    hs.put_ebcdic(rcvt + RCVT_DSN, racf_dsn, 44)

    # --- caller ACEE:  PSA+x'224' -> ASCB -> +x'6C' -> ASXB -> +x'C8' -> ACEE ---
    if caller_ascb is None and spaces:
        caller_ascb = hs.word(asvt + ASVTENTY_OFF)      # fall back to first
    asxb = hs.alloc(0x100)
    acee = hs.alloc(0x100)
    hs.putword(PSAAOLD, caller_ascb or 0)               # PSA+x'224' -> current ASCB
    if caller_ascb:
        hs.putword(caller_ascb + ASCBASXB, asxb)        # ASCB+x'6C' -> ASXB
    hs.putword(asxb + ASXBSENV, acee)                   # ASXB+x'C8' -> ACEE
    hs.put_ebcdic(acee + 0, "ACEE", 4)                  # eyecatcher
    # effective identity - ELV.SELF impersonation swaps the caller's ACEE for a target's
    eff_user = userid.upper()
    eff_attrs = set()
    try:
        target = getattr(state, "impersonation", {}).get(userid.upper())
    except Exception:
        target = None
    src_user = target.upper() if target else eff_user
    try:
        _su = state.racf.get(src_user)
        eff_attrs = {a.upper() for a in getattr(_su, "attributes", set())} if _su else set()
        if getattr(_su, "special", False):
            eff_attrs.add("SPECIAL")
    except Exception:
        _su = None
    if target and _su is None:                          # impersonating a started task
        eff_attrs = {"SPECIAL", "OPERATIONS"}           # trusted STC
    if target:
        eff_user = target.upper()
    hs.put_ebcdic(acee + ACEEUSRI, eff_user, 8)         # userid (possibly impersonated)
    _grp = "SYS1"
    try:
        _u = state.racf.get(eff_user)
        _grp = getattr(_u, "default_group", None) or _grp
    except Exception:
        pass
    hs.put_ebcdic(acee + 0x1D, str(_grp), 8)            # ACEEGRPN (default group)
    flg = 0
    try:
        attrs = eff_attrs
        if "SPECIAL" in attrs:
            flg |= 0x80
        if "OPERATIONS" in attrs:
            flg |= 0x40
        if "AUDITOR" in attrs:
            flg |= 0x20
    except Exception:
        pass
    hs.write(acee + ACEEFLG1, bytes([flg]))             # ACEE+x'26' SPECIAL/OPER/AUDIT

    # --- APF authorization list (dynamic format) ----------------------------
    # The pentest tools (ENUM, ELV.APF, SHOWMVS) select the APF-list format from
    # a sentinel: if CVT+x'1E4' (CVTAUTHL) holds x'7FFFF001' the list is the
    # *dynamic* CSVT/APFA linked list (ECVT+228 -> CSVT -> +12 -> APFA), otherwise
    # a *static* in-line table. The three tools disagree on the static entry
    # offsets (ENUM reads the DSN at entry+7, ELV.APF/SHOWMVS at entry+9), so no
    # single static table satisfies all of them. Their *dynamic* parsers are
    # byte-identical, so we publish the dynamic list and set the sentinel; every
    # reader then walks one correct structure.
    #   APFA:   +8 -> first entry, +12 -> last entry
    #   entry:  +4 SMS flag (x'80'), +8 -> next entry, +24 DSN[44], +68 volser[6]
    apf = getattr(state, "apf_libraries", []) or []
    apfa = hs.alloc(0x20)
    _apf_entries = []
    for dsn in apf:
        ent = hs.alloc(0x50)
        hs.write(ent + 4, bytes([0x00]))               # +4 flags: bit x'80' = SMS (off)
        hs.put_ebcdic(ent + 24, str(dsn)[:44], 44)     # +24 DSN (44, blank-padded)
        hs.put_ebcdic(ent + 68, "SYSAPF", 6)           # +68 VOLSER (used when not SMS)
        _apf_entries.append(ent)
    for i, ent in enumerate(_apf_entries):
        nxt = _apf_entries[i + 1] if i + 1 < len(_apf_entries) else ent
        hs.putword(ent + 8, nxt)                        # +8 -> next entry
    if _apf_entries:
        hs.putword(apfa + 8, _apf_entries[0])           # AFIRST
        hs.putword(apfa + 12, _apf_entries[-1])         # ALAST
    else:
        hs.putword(apfa + 8, apfa)
        hs.putword(apfa + 12, apfa)
    cvtauthl = apfa
    hs.putword(cvt + CVTAUTHL, 0x7FFFF001)             # dynamic sentinel

    # --- SCVT + SVC table (ELV.SVC):  CVT+x'C8' -> SCVT -> +x'84' -> SVC table ---
    scvt = hs.alloc(0x100)
    hs.putword(cvt + CVTSCVT, scvt)
    svct = hs.alloc(256 * 8 + 8)
    hs.putword(scvt + SCVTSVCT, svct)                   # SCVT+x'84' -> SVC table
    hs.putword(scvt + SCVTSVCT + 4, 0)                  # SCVT+x'88' -> SVC update table (none)
    magic_svc = 233
    try:
        magic_svc = int(next(iter(getattr(state, "magic_svcs", {233}))))
    except Exception:
        pass
    for n in range(256):
        ent = svct + n * 8
        if n < 200:
            hs.putword(ent, 0xF00000 + n)               # IBM SVC routine address
        elif n == magic_svc:
            hs.putword(ent, 0x00E10000 + n)             # back-door routine address
            # Attribute bytes as a real authorised user SVC would carry them:
            # x'80' type indicator, x'08' APF-authorised, x'02' non-preemptive,
            # and AR-mode in the second attribute byte. Previously only the type
            # bit was set, so enumeration showed the back door with every flag
            # column blank - i.e. indistinguishable from an unused slot.
            hs.write(ent + 4, bytes([0x80 | 0x08 | 0x02, 0x80, 0x00, 0x00]))
        else:
            hs.putword(ent, 0)                          # unassigned user SVC
    hs.scvt = scvt
    hs.svc_table = svct
    hs.magic_svc = magic_svc

    # --- TSO vector table chain:  CVT+x'9C' -> TSVT -> +x'4C' -> TPVT -> +x'14' -> CTLT
    # CVT+x'9C' was null, so enumeration of the TSO authorisation tables walked a
    # null pointer and reported TSVT/TPVT/CTLT as zeros. These are the IKJTSOxx
    # authorisation lists, a legitimate recon target: an authorised command or
    # program is a privilege-escalation candidate.
    #
    # Layout (as z/OS publishes it and enumerators read it):
    #   CTLT+4            2-byte byte-length of the descriptor area
    #   descriptors from +8, 12 bytes each:
    #     +0  4-byte pointer to the table
    #     +6  2-byte table size      +8  2-byte entry count
    #     +10 2-byte entry length
    #   each table: the 8-character CSECT name at +0, one reserved slot, then the
    #   entries at table + length*j for j = 2 .. count. The CSECT name is what
    #   identifies the list (IKJEFTE2=AUTHCMD, IKJEFTE8=AUTHPGM,
    #   IKJEFTNS=NOTBKGND, IKJEFTAP=AUTHTSF).
    tsvt = hs.alloc(0x100)
    tpvt = hs.alloc(0x200)
    ctlt = hs.alloc(0x400)
    hs.put_ebcdic(tsvt, "TSVT", 4)
    hs.put_ebcdic(tpvt, "TPVT", 4)
    hs.putword(cvt + 0x9C, tsvt)
    hs.putword(tsvt + 0x4C, tpvt)
    hs.putword(tpvt + 0x14, ctlt)
    _auth_tables = getattr(state, "tso_auth_tables", None) or [
        ("IKJEFTE2", ["TESTAUTH", "IKJEFF76", "CONSOLE", "CONSPROF", "SEND",
                      "RACONVRT", "SYNC", "IRRDPI00", "LISTD"]),
        ("IKJEFTE8", ["IEBCOPY", "IKJEFF76", "IRRDPI00"]),
        ("IKJEFTNS", ["OPER", "OPERATOR", "SUBMIT"]),
        # IDCAMS in AUTHTSF is a real, deliberately vulnerable misconfiguration:
        # it lets an unauthorised caller reach an authorised service.
        ("IKJEFTAP", ["IKJEFTSR", "IDCAMS"]),
    ]
    _ENTLEN = 8
    hs.write(ctlt + 4, (8 + 12 * len(_auth_tables)).to_bytes(2, "big"))
    for _i, (_csect, _cmds) in enumerate(_auth_tables):
        _count = len(_cmds) + 1                      # loop runs j = 2 .. count
        _tbl = hs.alloc(_ENTLEN * (_count + 2))
        hs.put_ebcdic(_tbl, _csect, _ENTLEN)         # j=0: CSECT name
        hs.put_ebcdic(_tbl + _ENTLEN, "", _ENTLEN)   # j=1: reserved
        for _k, _c in enumerate(_cmds):
            hs.put_ebcdic(_tbl + _ENTLEN * (_k + 2), str(_c)[:_ENTLEN], _ENTLEN)
        _ent = ctlt + 8 + _i * 12
        hs.putword(_ent, _tbl)                       # +0  -> table
        hs.puthalf(_ent + 6, _ENTLEN * (_count + 1))  # +6  table size
        hs.puthalf(_ent + 8, _count)                 # +8  entry count
        hs.puthalf(_ent + 10, _ENTLEN)               # +10 entry length
    hs.tsvt = tsvt
    hs.tpvt = tpvt
    hs.ctlt = ctlt

    # --- ECVT + z/OS version (ENUM VERS, real offsets):  CVT+x'8C' -> ECVT ---
    ecvt = hs.alloc(0x240)
    hs.putword(cvt + CVTECVT, ecvt)
    hs.put_ebcdic(ecvt + 0, "ECVT", 4)                  # eyecatcher
    hs.put_ebcdic(ecvt + 8, "GIBSNPLX", 8)              # ECVTSPLX (sysplex name)
    # ENUM EnumVersion reads: prodName2 @ ecvt+496 (16), ver/rel/mod @ ecvt+512/514/516 (2 each)
    hs.put_ebcdic(ecvt + 496, "z/OS", 16)
    hs.put_ebcdic(ecvt + 512, "02", 2)
    hs.put_ebcdic(ecvt + 514, "05", 2)
    hs.put_ebcdic(ecvt + 516, "00", 2)
    # CPC / LPAR identity (real ECVT fields): the hardware (CPC node) name at
    # ECVT+x'150' and the LPAR name at ECVT+x'158'. These were left as nulls, so
    # enumeration reported a blank processor name and blank LPAR id.
    _smf = (getattr(getattr(state, "config", None), "smfid", None) or "GIBS")
    hs.put_ebcdic(ecvt + 0x150, "GIBSON01", 8)          # ECVTHDNM (CPC name)
    hs.put_ebcdic(ecvt + 0x158, str(_smf)[:8], 8)       # ECVTLPNM (LPAR name)
    # ENUM reads prodName @ cvt-40 (7) and fmidNum @ cvt-32 (7) - a CVT prefix
    hs.put_ebcdic(cvt - 40, "z/OS", 7)
    hs.put_ebcdic(cvt - 32, "HBB77C0", 7)
    hs.put_ebcdic(cvt + CVTPRODN, "z/OS", 8)
    hs.put_ebcdic(cvt + CVTPRODI, "HBB77C0", 8)

    # --- SMF control area (SMCA):  CVT+x'28' (CVTSMCA) -> SMCA ---------------
    # Enumeration tools read the SMF/LPAR system id from the SMCA. CVTSMCA was
    # left null, so that pointer dereferenced to zero and the system id rendered
    # blank. Layout follows the real SMCA: 'SMCA' eyecatcher at +0 and the
    # 4-character SMF system id (SMCASID) at +x'10'.
    _smfid = (getattr(getattr(state, "config", None), "smfid", None) or "GIBS")
    smca = hs.alloc(0x100)
    hs.put_ebcdic(smca, "SMCA", 4)
    hs.put_ebcdic(smca + 0x10, str(_smfid)[:4], 4)      # SMCASID
    hs.put_ebcdic(smca + 0x14, str(_smfid)[:8], 8)      # system name
    hs.putword(cvt + 0x28, smca)                        # CVTSMCA
    hs.smca = smca
    # modern APF path (ENUM APF):  ecvt+228 -> CSVT -> +12 -> APF list (reuse CVTAUTHL)
    csvt = hs.alloc(0x20)
    hs.putword(ecvt + 228, csvt)
    hs.putword(csvt + 12, cvtauthl)
    hs.ecvt = ecvt

    # --- RACF dataset directory (ENUM SEC):  RCVT+x'E0' -> DSDT ---
    dsdt = hs.alloc(0x200)
    hs.putword(rcvt + 224, dsdt)                        # RCVT+224 -> DSDT
    hs.putword(dsdt + 4, 1)                             # number of RACF datasets
    hs.put_ebcdic(dsdt + 177, racf_dsn, 44)             # DSDT+177 primary dataset
    hs.put_ebcdic(dsdt + 353, racf_dsn + ".BACKUP", 44) # DSDT+353 backup dataset

    # --- JESCT + SSCVT chain (ENUM subsystems / CAT):  CVT+x'128' -> JESCT+24 -> SSCVT ---
    jesct = hs.alloc(0x100)
    hs.putword(cvt + 296, jesct)
    prev = 0
    for name in ("MSTR", "JES2", "OMVS"):              # subsystem chain (SSCVT+8 name, +4 next)
        ss = hs.alloc(0x40)
        hs.put_ebcdic(ss + 8, name, 4)
        hs.putword(ss + 4, prev)                        # SSCTSCTA -> previous (chain head last)
        prev = ss
    hs.putword(jesct + 24, prev)
    hs.jesct = jesct

    # --- master catalog (ENUM CAT):  ECVT+392 -> IPA, IPA+224 -> SCAT (mcat dsn @ +10) ---
    ipa = hs.alloc(0x140)
    hs.putword(ecvt + 392, ipa)
    hs.put_ebcdic(ipa + 224 + 10, "CATALOG.MASTER.GIBSON", 44)   # SUBSTR(ipaScat,11,44)

    # --- TCB / TIOT / JSCB / QMPL / QMAT for jobname + DD walk (ENUM PATH / Swareq) ---
    tcbp = hs.alloc(0x20)
    hs.putword(cvt + 0, tcbp)                           # CVT+0 -> CVTTCBP
    tcb = hs.alloc(0x100)
    hs.putword(tcbp + 4, tcb)                           # (CVTTCBP)+4 -> current TCB
    hs.putword(0x21C, tcb)                              # PSA+x'21C' (PSATOLD) -> TCB
    tiot = hs.alloc(0x200)
    hs.putword(tcb + 12, tiot)                          # TCB+12 -> TIOT
    hs.put_ebcdic(tiot + 0, userid.upper(), 8)          # TIOT+0 jobname
    jscb = hs.alloc(0x120); hs.putword(tcb + 180, jscb)  # TCB+180 -> JSCB
    qmpl = hs.alloc(0x40);  hs.putword(jscb + 244, qmpl)  # JSCB+244 -> QMPL
    hs.write(qmpl + 16, bytes([0x00]))                  # QMPL+16 status -> below-the-bar path
    qmat = hs.alloc(0x40);  hs.putword(qmpl + 24, qmat)  # QMPL+24 -> QMAT
    off = 24                                            # first TIOT DD entry at TIOT+24
    for ddn, dsn in (("SYSPROC", "SYS1.SISPEXEC"), ("SYSEXEC", "SYS1.SBPXEXEC"),
                     ("STEPLIB", "SYS1.LINKLIB")):
        blk = hs.alloc(0x100)                           # 8-aligned, so blk-16 never ends in 'F'
        hs.put_ebcdic(blk + 0, dsn, 44)
        hs.put_ebcdic(blk + 118, "SYSAPF", 6)
        token = (blk - 16) & 0xFFFFFF
        ent = 20
        hs.write(tiot + off + 0, bytes([ent]))          # entry length
        hs.put_ebcdic(tiot + off + 4, ddn, 8)           # DD name
        hs.write(tiot + off + 12, token.to_bytes(3, "big"))  # 3-byte SWA token = blk-16
        off += ent
    hs.write(tiot + off, bytes([0]))                    # terminating entry (length 0)
    hs.tiot = tiot

    hs.cvt = cvt
    hs.asvt = asvt
    hs.rcvt = rcvt
    hs.acee = acee
    hs.apf_list = cvtauthl
    hs.caller_ascb = caller_ascb
    hs.num_spaces = len(spaces)
    return hs
