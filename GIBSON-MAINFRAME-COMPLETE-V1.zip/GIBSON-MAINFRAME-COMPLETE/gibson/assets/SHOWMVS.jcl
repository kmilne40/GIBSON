//SHOWMVS  JOB (ACCT),'SHOWMVS DISPLAY',CLASS=A,MSGCLASS=A,
//             MSGLEVEL=(1,1),REGION=0M
//*********************************************************************
//* SHOWMVS - GIBSON clean-room system configuration display.         *
//* A batch job that reports the same classes of information a        *
//* SHOWMVS-style utility does, read live from the control-block       *
//* image.  Written from scratch for GIBSON; not derived from any      *
//* other SHOWMVS source.                                              *
//*                                                                   *
//*   STEP ASM  (HLASM, assemble+go): locate the CVT and ECVT in       *
//*             live storage and announce the run via WTO.             *
//*   STEP RPT  (REXX, batch):        walk the control blocks and       *
//*             print the configuration report to SYSTSPRT.            *
//*********************************************************************
//ASM      EXEC PGM=ASMACG
//SYSIN    DD   *
SHOWMVSA CSECT
*        CVT ADDRESS FROM PSA+16, THEN ECVT FROM CVT+X'8C'
         L     1,16
         L     2,140(1)
         WTO   'SHOWMVS - READING LIVE CONTROL BLOCKS (ASSEMBLE+GO)'
         WTO   'CVT AND ECVT LOCATED - HANDING OFF TO REXX REPORT'
         BR    14
         END
/*
//RPT      EXEC PGM=IRXJCL
//SYSTSPRT DD   SYSOUT=*
//SYSEXEC  DD   DATA,DLM=@@
 /* REXX - SHOWMVS report (walks the live control-block image) */
 say '1SHOWMVS - GIBSON SYSTEM CONFIGURATION DISPLAY'
 say '0-------------------------------------------------------------------'
 cvt  = GetPtr(16)
 ecvt = GetPtr(cvt+140)
 say ' '
 say ' SYSTEM'
 say '   PRODUCT . . . . :' STRIP(GetStorage(ecvt+496,16))
 say '   FMID  . . . . . :' STRIP(GetStorage(cvt-32,7))
 say '   RELEASE . . . . : z/OS' STRIP(GetStorage(ecvt+512,2))'.'STRIP(GetStorage(ecvt+514,2))'.'STRIP(GetStorage(ecvt+516,2))
 say '   SYSPLEX . . . . :' STRIP(GetStorage(ecvt+8,8))
 say '   CVT ADDRESS . . : 'D2X(cvt)
 say '   ECVT ADDRESS. . : 'D2X(ecvt)
 tcbp = GetPtr(cvt+0)
 tcb  = GetPtr(tcbp+4)
 tiot = GetPtr(tcb+12)
 say '   CURRENT JOB . . :' STRIP(GetStorage(tiot,8))
 ipa = GetPtr(ecvt+392)
 say ' '
 say ' MASTER CATALOG'
 say '   DSNAME  . . . . :' STRIP(GetStorage(ipa+234,44))
 rcvt = GetPtr(cvt+992)
 say ' '
 say ' SECURITY'
 say '   MANAGER . . . . : RACF (RCVT @ 'D2X(rcvt)')'
 say '   PRIMARY DSN . . :' STRIP(GetStorage(rcvt+24,44))
 say ' '
 say ' SUBSYSTEMS (SSCVT CHAIN)'
 jesct = GetPtr(cvt+296)
 ss    = GetPtr(jesct+24)
 nss = 0
 do while ss <> 0
   nm = STRIP(GetStorage(ss+8,4))
   if nm <> '' then do
     say '   SSNAME  . . . . :' nm
     nss = nss + 1
   end
   ss = GetPtr(ss+4)
   if nss > 32 then leave
 end
 say '   'nss 'subsystem(s) active'
 say ' '
 say ' SVC TABLE'
 scvt = GetPtr(cvt+200)
 svct = GetPtr(scvt+132)
 ibm = 0; usr = 0; auth = 0
 do n = 0 to 255
   w = C2D(GetStorage(svct + n*8, 4))
   if w = 0 then iterate
   if n < 200 then ibm = ibm + 1
   else do
     usr = usr + 1
     fb = GetStorage(svct + n*8 + 4, 1)
     if BITAND(fb,'80'x) = '80'x then do
       auth = auth + 1
       say '   USER SVC' n '- AUTHORISED/ESR FLAG SET (@'D2X(w)')'
     end
   end
 end
 say '   IBM SVCs :' ibm '  USER SVCs :' usr '  authorised user SVCs :' auth
 say ' '
 say ' AUTHORISED (APF) LIBRARIES'
 authl  = GetPtr(cvt+484)
 numapf = C2D(GetStorage(authl,2))
 off = 2
 do i = 1 to numapf
   ln  = C2D(GetStorage(authl+off,1))
   ent = GetStorage(authl+off+1,ln)
   vol = STRIP(SUBSTR(ent,1,6))
   dsn = STRIP(SUBSTR(ent,7))
   say '   'LEFT(dsn,44) vol
   off = off + 1 + ln
 end
 say '   'numapf 'authorised librar(ies)'
 say ' '
 say ' ADDRESS SPACES (ASVT)'
 asvt = GetPtr(cvt+556)
 maxu = C2D(GetStorage(asvt+516,4))
 n = 0
 line = '  '
 do i = 0 to maxu-1
   ascb = GetPtr(asvt+528+(i*4))
   if ascb = 0 then iterate
   jn = STRIP(GetStorage(GetPtr(ascb+176),8))
   if jn = '' then iterate
   n = n + 1
   line = line jn
   if n // 6 = 0 then do; say line; line = '  '; end
 end
 if STRIP(line) <> '' then say line
 say '   'maxu 'address-space slot(s),' n 'active'
 say ' '
 say ' TASK I/O TABLE (TIOT)  DD ALLOCATIONS'
 off = 24
 do forever
   el = C2D(GetStorage(tiot+off,1))
   if el = 0 then leave
   say '   DDNAME  . . . . :' STRIP(GetStorage(tiot+off+4,8))
   off = off + el
   if off > 480 then leave
 end
 say ' '
 say ' NOT MODELLED IN THIS ENVIRONMENT'
 say '   Online CPUs, real/extended storage size, IPL date/time/volser,'
 say '   virtual storage map (CSA/SQA/LPA), UCB device table, active LPA'
 say '   queue, and page data sets are not modelled by the GIBSON'
 say '   interpreter and are omitted rather than fabricated.'
 say '0-------------------------------------------------------------------'
 say ' SHOWMVS complete - all values above were read from live storage.'
 exit 0
 GetPtr: procedure
   return C2D(STORAGE(D2X(ARG(1)),4))
 GetStorage: procedure
   return STORAGE(D2X(ARG(1)),ARG(2))
@@
//
