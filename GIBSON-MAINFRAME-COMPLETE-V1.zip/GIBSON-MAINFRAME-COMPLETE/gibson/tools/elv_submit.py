"""Route an in-stream (`SUBMIT *`) ELV assemble-and-run job to the Level B engine.

The real ELV.APF / ELV.SVC drivers QUEUE a small JCL job onto the REXX stack - an
assembler step whose SYSIN is the HLASM that flips the ACEE SPECIAL bit, plus a
linkage-edit step whose SYSLMOD points at the APF library the escalation depends on
- and then issue `SUBMIT * END($$)`.  GIBSON's host SUBMIT only reads JCL from a
dataset, so an in-stream job never reached the engine.  This module parses that
queued JCL, pulls out the HLASM and the real precondition (the target APF library,
or an SVC number), and hands them to run_exploit_hlasm, which assembles+runs the
program against the live control-block image and persists the escalation only if the
precondition actually holds - exactly as the standalone ELV path already does.

Authorised GIBSON training use only.
"""
from __future__ import annotations
import re
from typing import List, Optional, Tuple

# a line is "inline data" until a JES in-stream terminator (/*) or the next JCL card
_JCL_CARD = re.compile(r"^//")
_INSTREAM_END = re.compile(r"^/\*\s*$")
_SYSIN_DD = re.compile(r"^//\S*SYSIN\s+DD\s+(\*|DATA)(?:\s|,|$)", re.I)
_SYSLMOD_DSN = re.compile(r"^//\S*SYSLMOD\s+DD\b.*?\bDSN(?:AME)?\s*=\s*([^,\s]+)", re.I)
_SVC_IN_ASM = re.compile(r"\bSVC\s+(\d{1,3})\b", re.I)
_SVC_MARKER = re.compile(r"\bNUM\s*=\s*(\d{1,3})\b", re.I)
_APF_MARKER = re.compile(r"\bAPF\s*=\s*([A-Z0-9$#@.]+)", re.I)
# Cross-memory impersonation (ELV.SELF style): the driver resolves the target
# address space itself and plants its ASID in the assembler source as a halfword
# constant, then uses AXSET/SSAR to reach it. There is no TAR= in the JCL, so the
# target has to be recovered from RMTASID and mapped back to a jobname.
_XMEM_OPS = re.compile(r"\b(SSAR|AXSET)\b", re.I)
_RMTASID = re.compile(r"^\s*RMTASID\s+DC\s+H'(\d+)'", re.I | re.M)


def _impersonation_target_asid(hlasm: str) -> Optional[str]:
    """Target ASID of a cross-memory impersonation program, if it is one."""
    if not _XMEM_OPS.search(hlasm):
        return None
    m = _RMTASID.search(hlasm)
    return m.group(1) if m else None


def _looks_elv(jcl: str) -> bool:
    up = jcl.upper()
    return "CSECT" in up and ("ACEE" in up or "MODESET" in up or "ELV" in up
                              or _SVC_IN_ASM.search(jcl) is not None
                              or "X'26'" in up or 'X"26"' in up)


def _extract_sysin_blocks(lines: List[str]) -> List[str]:
    """Return the text of each in-stream SYSIN DD * block in the JCL."""
    blocks: List[str] = []
    i, n = 0, len(lines)
    while i < n:
        if _SYSIN_DD.match(lines[i]):
            i += 1
            body: List[str] = []
            while i < n and not _INSTREAM_END.match(lines[i]) and not _JCL_CARD.match(lines[i]):
                body.append(lines[i])
                i += 1
            blocks.append("\n".join(body))
        else:
            i += 1
    return blocks


def _clean_dsn(raw: str) -> str:
    dsn = raw.strip().strip("'").upper()
    dsn = re.sub(r"\(.*?\)$", "", dsn)          # drop (MEMBER)
    return dsn


def parse_elv_job(jcl: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """(hlasm, apf_dsn, svc) from a queued ELV job, or (None, None, None) if not one."""
    lines = jcl.splitlines()
    blocks = _extract_sysin_blocks(lines)
    hlasm = next((b for b in blocks if "CSECT" in b.upper()), None)
    if hlasm is None:
        return None, None, None
    if not _looks_elv(hlasm):
        return None, None, None

    apf_dsn: Optional[str] = None
    for ln in lines:
        m = _SYSLMOD_DSN.match(ln)
        if m:
            apf_dsn = _clean_dsn(m.group(1))
            break
    if apf_dsn is None:                          # allow an explicit //* ELV APF=... marker
        m = _APF_MARKER.search(jcl)
        if m:
            apf_dsn = _clean_dsn(m.group(1))

    svc: Optional[str] = None
    m = _SVC_IN_ASM.search(hlasm) or _SVC_MARKER.search(jcl)
    if m:
        svc = m.group(1)

    return hlasm, apf_dsn, svc


def route_submitted_jcl(state, userid: str, jcl_lines: List[str]) -> Optional[List[str]]:
    """If the queued JCL is an ELV assemble-and-run job, run it and return the report.

    Returns None when the JCL is not an ELV job, so the caller can fall back to
    ordinary SUBMIT handling.
    """
    jcl = "\n".join(jcl_lines)
    hlasm, apf_dsn, svc = parse_elv_job(jcl)
    if hlasm is None:
        return None
    header = ["IKJ56250I IN-STREAM JOB SUBMITTED (ELV assemble-and-run)"]
    # A cross-memory impersonation program never sets SPECIAL in its own ACEE, so
    # judging it by that bit would always report failure. Evaluate it as an
    # impersonation against the same precondition instead.
    target_asid = _impersonation_target_asid(hlasm)
    if target_asid is not None:
        from gibson.tools.elv_engine import apply_impersonation, resolve_asid
        target = resolve_asid(state, userid, target_asid)
        report = apply_impersonation(state, userid, target, apf_dsn=apf_dsn, svc=svc)
        return header + report.splitlines()
    from gibson.tools.elv_engine import run_exploit_hlasm
    # APF target takes precedence; fall back to an SVC-driven escalation.
    kwargs = {"apf_dsn": apf_dsn} if apf_dsn else ({"svc": svc} if svc else {})
    report = run_exploit_hlasm(state, userid, hlasm, **kwargs)
    return header + report.splitlines()
