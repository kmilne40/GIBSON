"""ELV.SELF - impersonate another user/job/STC by swapping the caller's ACEE.

`LIST` lists address spaces (ASVT/ASCB walk).  `TAR=<target>` overwrites the caller's ACEE
with the target's identity/attributes, so the session runs as the target - persisted only
when the real precondition holds (a writable APF library, or a magic SVC), exactly like the
real exploit.  Authorised GIBSON training use only.
"""
from __future__ import annotations
import re

_LIST = r"""
/* ELV.SELF - list address spaces (impersonation targets) */
cvt  = GetPtr(16)
asvt = GetPtr(cvt+556)
maxu = GetPtr(asvt+516)
say '+ ELV.SELF - address spaces (impersonation targets):'
say '  ASID  JOBNAME'
do i = 0 to maxu-1
  ascb = GetPtr(asvt+528+(i*4))
  if ascb = 0 then iterate
  jbnp = GetPtr(ascb+176)
  if jbnp = 0 then iterate
  asid = c2d(storage(d2x(ascb+36),2))
  say right(asid,5)'  'strip(storage(d2x(jbnp),8))
end
say 'ELVSELF00I  Impersonate:  ex ''ELV.SELF'' ''TAR=<job> APF=<lib>''  (or SVC=233)'
exit
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
"""


def _argstr(command: str) -> str:
    parts = command.split("'")
    if len(parts) >= 3:
        return parts[1].strip()
    return command.split(None, 1)[1].strip() if " " in command else ""


def elv_self(state, userid: str, command: str) -> str:
    arg = _argstr(command)
    up = arg.strip().upper()
    if not up or up == "LIST":
        try:
            from gibson.lang.integration import run_rexx_full
            return run_rexx_full(state, userid, _LIST)
        except Exception as exc:
            return f"ELVSELF99E  {type(exc).__name__}: {exc}"
    tar = re.search(r"TAR\s*=\s*(\S+)", arg, re.I)
    apf = re.search(r"APF\s*=\s*(\S+)", arg, re.I)
    dsn = re.search(r"DSN\s*=\s*(\S+)", arg, re.I)
    svc = re.search(r"SVC\s*=\s*(\d+)", arg, re.I)
    if not tar:
        return "ELVSELF01E  specify TAR=<jobname/userid> (and APF=<lib> or SVC=nnn)."
    target = tar.group(1).upper()
    apf_dsn = (apf or dsn).group(1) if (apf or dsn) else None
    svcnum = svc.group(1) if svc else None
    from gibson.tools.elv_engine import precondition_met
    ok, reason = precondition_met(state, userid, apf_dsn=apf_dsn, svc=svcnum)
    out = [f"+ ELV.SELF - impersonating {target}",
           f"  Authorisation precheck : {'PASS' if ok else 'FAIL'}  ({reason})"]
    if not ok:
        out.append("  RESULT : ACEE not swapped (precondition failed) - you are still yourself.")
        return "\n".join(out)
    imp = getattr(state, "impersonation", None)
    if imp is None:
        imp = {}
        try:
            state.impersonation = imp
        except Exception:
            pass
    imp[userid.upper()] = target
    out.append(f"  RESULT : your ACEE now carries {target}'s identity. Confirm with the ACEE command.")
    return "\n".join(out)
