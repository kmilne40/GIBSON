"""ELV.* privilege-escalation engine (Level B).

Ties the S/390 interpreter to GIBSON's RACF model: it assembles and runs an exploit's
HLASM against the live control-block image, and if the program set the ACEE SPECIAL bit
*and* the real precondition holds (an APF library the user can write, or a magic SVC),
the escalation is persisted into RACF - so the ACEE display, RACF checks, and later logons
all reflect it.  Otherwise the ACEE patch is transient and does not stick, exactly like the
real world.  Authorised GIBSON training use only.
"""
from __future__ import annotations
from typing import List, Optional


def _has_write(state, dsn: str, userid: str) -> str:
    try:
        return state.dynamic_racf.effective_access("DATASET", dsn.upper(), userid, state.racf)
    except Exception:
        return "NONE"


def _is_apf(state, dsn: str) -> bool:
    return any(dsn.upper() == str(l).upper() for l in getattr(state, "apf_libraries", []))


def _grant_special(state, userid: str) -> None:
    u = state.racf.get(userid.upper())
    if u is None:
        return
    attrs = getattr(u, "attributes", None)
    if isinstance(attrs, list):
        if "SPECIAL" not in {a.upper() for a in attrs}:
            attrs.append("SPECIAL")
    elif isinstance(attrs, set):
        attrs.add("SPECIAL")


def run_exploit_hlasm(state, userid: str, asm: str,
                      apf_dsn: Optional[str] = None, svc: Optional[str] = None) -> str:
    """Assemble + execute an exploit's HLASM, gate on the real precondition, persist if met."""
    from gibson.lang.rexx.hoststorage import build_storage, ACEEFLG1
    from gibson.lang.asm.s390 import assemble_and_run

    hs = build_storage(state, userid)
    acee_before = bytes(hs.read(hs.acee, 48))
    before = hs.read(hs.acee + ACEEFLG1, 1)[0]
    cpu = assemble_and_run(asm, hs)
    after = hs.read(hs.acee + ACEEFLG1, 1)[0]
    acee_after = bytes(hs.read(hs.acee, 48))
    set_special = bool(after & 0x80)

    authorized, reason = False, "no APF library or SVC supplied"
    if apf_dsn:
        is_apf = _is_apf(state, apf_dsn)
        acc = _has_write(state, apf_dsn, userid) if is_apf else "NONE"
        authorized = is_apf and acc in ("UPDATE", "ALTER", "CONTROL")
        reason = f"library {apf_dsn.upper()}: APF={'YES' if is_apf else 'NO'}, your access={acc}"
    elif svc:
        magic = {str(s) for s in getattr(state, "magic_svcs", {"233"})}
        authorized = str(svc) in magic
        reason = f"SVC {svc} magic/auth = {'YES' if authorized else 'NO'}"

    out: List[str] = []
    out.append("+ ELV privilege-escalation (Level B - assembled program run against live storage)")
    out.append(f"  MODESET supervisor state : {'entered' if cpu.supervisor else 'no'}")
    out.append(f"  ACEE patch (ACEEFLG1)    : X{before:02X} -> X{after:02X}"
               f"   (program set SPECIAL: {'YES' if set_special else 'no'})")
    out.append(f"  Authorisation precheck   : {'PASS' if authorized else 'FAIL'}  ({reason})")
    if set_special and authorized:
        _grant_special(state, userid)
        out.append(f"  RESULT                   : {userid.upper()} now holds RACF SPECIAL - escalation succeeded.")
        out.append("  (Confirm with the ACEE command or LU " + userid.upper() + ".)")
    elif set_special:
        out.append("  RESULT                   : ACEE was patched in storage but the precondition")
        out.append("                             failed, so the change does NOT persist (as in reality).")
    else:
        out.append("  RESULT                   : program did not set the SPECIAL bit.")
    from gibson.tools.acee_display import _storage_dump
    out.append("")
    out.append("  --- ACEE BEFORE (flag byte ACEEFLG1 is at +000020, low nibble) ---")
    out.append(_storage_dump(hs.acee, acee_before, "ACEE"))
    out.append("  --- ACEE AFTER  (watch the byte at +000026 change) ---")
    out.append(_storage_dump(hs.acee, acee_after, "ACEE"))
    return "\n".join(out)


def call_magic_svc(state, userid: str, svc: str = "233") -> str:
    """Model ELV.SVC's 'call the magic SVC' step: if `svc` is a magic/auth SVC, its
    supervisor-state routine sets the caller's ACEE SPECIAL bit -> grant RACF SPECIAL."""
    magic = {str(s) for s in getattr(state, "magic_svcs", {"233"})}
    out = [f"+ ELV.SVC - calling SVC {svc} in the caller's address space"]
    if str(svc) not in magic:
        out.append(f"  SVC {svc} is not a magic/auth SVC - nothing happens.")
        return "\n".join(out)
    out.append("  SVC routine runs in supervisor state and patches the ACEE (SPECIAL).")
    _grant_special(state, userid)
    out.append(f"  RESULT: {userid.upper()} now holds RACF SPECIAL - confirm with the ACEE command.")
    return "\n".join(out)


def resolve_asid(state, userid: str, asid) -> str:
    """Jobname for an ASID, from the address spaces GIBSON publishes to the ASVT."""
    try:
        from gibson.lang.rexx.hoststorage import _address_spaces
        for _asid, _job, _cht, _omvs in _address_spaces(state, userid):
            if int(_asid) == int(asid):
                return str(_job).upper()
    except Exception:
        pass
    return ""


def apply_impersonation(state, userid: str, target: str, apf_dsn=None, svc=None) -> str:
    """Swap the caller's identity for `target` when the real precondition holds.

    ELV.SELF-style exploits do not flip SPECIAL in their own ACEE; they run a
    cross-memory (AXSET/SSAR) program that copies another address space's ACEE
    identity. The outcome to record is therefore an impersonation, not a SPECIAL
    bit, and it persists on the same precondition as every other ELV path: a
    writable APF library, or a magic SVC.
    """
    ok, reason = precondition_met(state, userid, apf_dsn=apf_dsn, svc=svc)
    out = [f"+ ELV cross-memory impersonation (assembled program run against live storage)",
           f"    Target address space     : {target or 'unknown'}",
           f"    Authorisation precheck   : {'PASS' if ok else 'FAIL'}  ({reason})"]
    if not ok or not target:
        out.append("    RESULT                   : ACEE not swapped - you are still yourself.")
        return "\n".join(out)
    imp = getattr(state, "impersonation", None)
    if imp is None:
        imp = {}
        try:
            state.impersonation = imp
        except Exception:
            pass
    imp[userid.upper()] = target
    out.append(f"    RESULT                   : your ACEE now carries {target}'s identity.")
    out.append("    (Confirm with the ACEE command.)")
    return "\n".join(out)


def precondition_met(state, userid: str, apf_dsn=None, svc=None):
    """(ok, reason) - the real precondition for an escalation to persist."""
    if apf_dsn:
        is_apf = _is_apf(state, apf_dsn)
        acc = _has_write(state, apf_dsn, userid) if is_apf else "NONE"
        ok = is_apf and acc in ("UPDATE", "ALTER", "CONTROL")
        return ok, f"library {apf_dsn.upper()}: APF={'YES' if is_apf else 'NO'}, your access={acc}"
    if svc:
        magic = {str(s) for s in getattr(state, "magic_svcs", {"233"})}
        return str(svc) in magic, f"SVC {svc} magic/auth = {'YES' if str(svc) in magic else 'NO'}"
    return False, "no APF library or SVC supplied"
