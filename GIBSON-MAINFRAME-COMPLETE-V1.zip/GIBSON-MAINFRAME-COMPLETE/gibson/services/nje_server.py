"""NJE (Network Job Entry) TCP listener for Gibson.

Binds the real NJE ports - 175/tcp (clear, EBCDIC) and 2252/tcp (TLS) - and
answers the 33-byte OPEN handshake with ACK/NAK exactly as a JES2 NJE/TCP server
does, so that:

  * ``nmap -p 175`` shows ``175/tcp open nje`` (nmap-services maps 175 -> nje),
  * ``nmap -sV`` confirms the NJE service, and
  * ``nmap --script nje-node-brute`` enumerates node names via the OPEN/NAK
    reason-code side-channel (0x01 unknown OHOST, 0x04 valid OHOST).

Like a real NJE server, the listener is silent on connect: it sends nothing
until it receives the client's OPEN record. Node validation reuses the
Chapter-10 node fixtures in ``gibson.core.nje``.
"""
from __future__ import annotations

import socket
import socketserver
import threading
import time

from gibson.core.issues import is_expected_disconnect
from gibson.core.nje import CHAPTER10_NODES
from gibson.core.security_mode import is_secure_mode
from gibson.net import nje_protocol


# --- SECURE-mode brute-force lockout for NJE node sign-on --------------------
# Tracks failed node-password attempts per source address.  Only consulted in
# SECURE mode; VULN mode never locks out (so the weak-password guessing lab still
# works).  In-memory and best-effort - a training control, not a hardened one.
_NJE_FAILS: dict = {}
_NJE_LOCK = threading.Lock()
_NJE_MAX_FAILS = 3

def _nje_record_fail(ip: str) -> None:
    with _NJE_LOCK:
        _NJE_FAILS[ip] = _NJE_FAILS.get(ip, 0) + 1

def _nje_reset_fails(ip: str) -> None:
    with _NJE_LOCK:
        _NJE_FAILS.pop(ip, None)

def _nje_locked_out(ip: str) -> bool:
    with _NJE_LOCK:
        return _NJE_FAILS.get(ip, 0) >= _NJE_MAX_FAILS


class NjeHandler(socketserver.BaseRequestHandler):
    state = None
    secure = False

    def handle(self) -> None:
        port = (self.state.config.nje_tls_port if self.secure
                else self.state.config.nje_port)
        try:
            self.state.note_port_touch(self.client_address[0], port, service="NJE")
        except Exception:
            pass
        try:
            self.request.settimeout(8.0)
            # Silent on connect: real NJE waits for the client OPEN record.
            data = self.request.recv(256)
            if not data:
                return
            result = nje_protocol.respond_open(data, CHAPTER10_NODES)
            if result is None:
                return  # not an OPEN; stay silent (matches real NJE)
            resp, info = result
            try:
                self.state.record_security_event(
                    self.client_address[0], "NJE OPEN",
                    f"OHOST={info['ohost']} RHOST={info['rhost']} -> "
                    f"{info['type']} R={info['r']:#04x}"
                    + ("/TLS" if self.secure else ""),
                    service="NJE",
                    result="SUCCESS" if info["type"] == "ACK" else "REJECTED",
                    addr=self.client_address[0], terminal="NJE")
            except Exception:
                pass
            self.request.sendall(resp)
            # If we accepted (ACK), the peer continues with SOH/ENQ then an
            # I-record sign-on carrying the node password.  This is what
            # nje-pass-brute exercises.
            if info["type"] != "ACK":
                try:
                    self.request.recv(64)
                except Exception:
                    pass
                return
            try:
                soh = self.request.recv(64)
            except Exception:
                return
            if not soh or not nje_protocol.is_soh_enq(soh):
                return
            self.request.sendall(nje_protocol.DLE_ACK)
            try:
                irec = self.request.recv(256)
            except Exception:
                return
            if not irec:
                return
            password = nje_protocol.parse_irecord_password(irec) or ""
            secure = is_secure_mode(self.state)
            ip = self.client_address[0]
            # SECURE mode: throttle node-password brute force (defeats nje-pass-brute).
            # VULN mode: no lockout, so guessing the weak node password still works.
            if secure and _nje_locked_out(ip):
                try:
                    self.state.record_security_event(
                        ip, "NJE SIGNON", f"OHOST={info['ohost']} LOCKED OUT "
                        f"(too many failed node-password attempts)",
                        service="NJE", result="FAILURE",
                        addr=ip, terminal="NJE")
                except Exception:
                    pass
                self.request.sendall(nje_protocol.signon_reply(False))
                return
            ok = nje_protocol.check_node_password(
                info["ohost"], password, CHAPTER10_NODES, secure=secure)
            if secure:
                if ok:
                    _nje_reset_fails(ip)
                else:
                    _nje_record_fail(ip)
            reason = "ACCEPTED" if ok else "REJECTED"
            if not ok and secure and not (CHAPTER10_NODES.get(info["ohost"].upper(), {}).get("password")):
                reason = "REJECTED (secure: node requires a password)"
            try:
                self.state.record_security_event(
                    self.client_address[0], "NJE SIGNON",
                    f"OHOST={info['ohost']} I-RECORD PASSWORD {reason}"
                    + ("  [SECURE]" if secure else ""),
                    service="NJE", result="SUCCESS" if ok else "FAILURE",
                    addr=self.client_address[0], terminal="NJE")
            except Exception:
                pass
            # Build the full NCCR 'J' sign-on reply so real NJElib parses it and
            # continues (the old minimal record raised IndexError before this point).
            node_cfg = CHAPTER10_NODES.get(info["ohost"].upper(), {})
            try:
                node_num = int(str(node_cfg.get("number", "1")))
            except Exception:
                node_num = 1
            self.request.sendall(nje_protocol.signon_reply(
                ok, node_name=info["ohost"], node_num=node_num,
                password=(node_cfg.get("password") or "")))
            if not ok:
                return
            # Sign-on accepted. The peer now sends an L (concurrence) / K (reset)
            # NCCR, then either NMR operator commands (iNJEctor.py) or a SYSIN job
            # stream (jcl.py).  Stay in a receive loop and service both so the real
            # tools complete end-to-end and JES2 state actually changes.
            client_rhost = info["rhost"]
            self.request.settimeout(6.0)
            idle_deadline = time.time() + 20.0
            while time.time() < idle_deadline:
                try:
                    chunk = self.request.recv(65535)
                except socket.timeout:
                    break
                except Exception:
                    break
                if not chunk:
                    break

                # ---- NMR operator command (iNJEctor.py) ----
                cmd = None
                try:
                    cmd = nje_protocol.parse_nmr_command(chunk)
                except Exception:
                    cmd = None
                if cmd:
                    out = None
                    try:
                        out = self.state.nje.command(cmd)
                    except Exception:
                        out = None
                    if out is None:
                        out = f"$HASP003 RC=(52)-INVALID COMMAND {cmd[:40]}"
                    try:
                        self.state.record_security_event(
                            client_rhost, "NJE NMR COMMAND",
                            f"OHOST={info['ohost']} CMD={cmd[:60]} "
                            f"from={self.client_address[0]}",
                            service="NJE", result="SUCCESS",
                            addr=self.client_address[0], terminal="NJE")
                    except Exception:
                        pass
                    try:
                        self.request.sendall(nje_protocol.build_nmr_replies(
                            out, to_node=client_rhost, from_node=info["ohost"],
                            to_num=1, from_num=node_num))
                    except Exception:
                        break
                    idle_deadline = time.time() + 20.0
                    continue

                # ---- stream-initiation request (0x90) -> grant (0xA0) ----
                try:
                    srcb = nje_protocol.is_stream_request(chunk)
                except Exception:
                    srcb = None
                if srcb is not None:
                    try:
                        self.request.sendall(nje_protocol.grant_stream(srcb))
                    except Exception:
                        break
                    idle_deadline = time.time() + 20.0
                    continue

                # ---- SYSIN job stream (jcl.py) ----
                try:
                    parsed = nje_protocol.parse_sysin_stream(chunk)
                except Exception:
                    parsed = None
                if parsed and (parsed["jcl_lines"] or parsed["run_as_user"]):
                    run_as = parsed["run_as_user"] or "?"
                    grp = parsed["run_as_grp"] or "?"
                    jcl = "\n".join(parsed["jcl_lines"])
                    jobname = ""
                    for ln in parsed["jcl_lines"]:
                        if " JOB " in ln or ln.strip().endswith("JOB"):
                            jobname = ln.split()[0].lstrip("/"); break
                    try:
                        self.state.record_security_event(
                            run_as, "NJE JOB SUBMIT",
                            f"OHOST={info['ohost']} job={jobname or '?'} "
                            f"RUN-AS={run_as}/{grp} lines={len(parsed['jcl_lines'])} "
                            f"from={self.client_address[0]}",
                            service="NJE", result="SUCCESS",
                            addr=self.client_address[0], terminal="NJE")
                    except Exception:
                        pass
                    submitted = False
                    try:
                        jes = getattr(self.state, "jes", None)
                        if jes is not None and hasattr(jes, "submit"):
                            from gibson.apps.tso import TsoCommandProcessor
                            from gibson.apps.db2_sim import Db2Simulator
                            proc = TsoCommandProcessor(self.state, run_as)
                            jes.submit(jcl, run_as, runner=proc.run,
                                       sql_runner=lambda s: Db2Simulator(self.state).format_spufi(s, run_as),
                                       submitter=run_as)
                            submitted = True
                    except Exception:
                        submitted = False
                    # Return a SYSOUT completion stream echoing the submitted job
                    # number/name so jcl.py's sendJCL(wait_for_sysout=True) finishes.
                    try:
                        import re as _re
                        m = _re.search(r"JOB(\d{4,6})", "\n".join(parsed["jcl_lines"]))
                        job_num = int(m.group(1)) if m else 1
                    except Exception:
                        job_num = 1
                    try:
                        self.request.sendall(nje_protocol.build_sysout_completion(
                            job_num, jobname or "JOB"))
                    except Exception:
                        pass
                    idle_deadline = time.time() + 20.0
                    continue
                # otherwise (L/K concurrence or unrecognised) keep listening
            return
        except Exception:
            pass


class _SecureNjeHandler(NjeHandler):
    secure = True


class ThreadedNjeServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys
        exc = sys.exc_info()[1]
        if exc is not None and is_expected_disconnect(exc):
            return
        return super().handle_error(request, client_address)


def serve_nje(state) -> ThreadedNjeServer:
    """Start the clear NJE listener on 175 and, where possible, TLS on 2252."""
    NjeHandler.state = state
    _SecureNjeHandler.state = state
    try:
        server = ThreadedNjeServer((state.config.host, state.config.nje_port), NjeHandler)
    except PermissionError:
        port = state.config.nje_port
        raise SystemExit(
            f"GIBSON: permission denied binding NJE port {port}.\n"
            f"Ports below 1024 are privileged. Grant the capability once with:\n"
            f"  sudo ./scripts/grant-port-capabilities.sh\n"
            f"(or run with sudo). The capability is not port-specific, so it covers\n"
            f"175 exactly as it covers TN3270 on 23 and FTP on 21."
        )
    threading.Thread(target=server.serve_forever, daemon=True, name="GibsonNJE").start()

    # TLS variant on 2252 - wrap accepted sockets with the shared cert context.
    tls_port = getattr(state.config, "nje_tls_port", 0)
    if tls_port:
        try:
            tls_server = ThreadedNjeServer((state.config.host, tls_port), _SecureNjeHandler)
            from gibson.net.tls import wrap_server_socket
            tls_server = wrap_server_socket(tls_server, state, "NJE/TLS")
            threading.Thread(target=tls_server.serve_forever, daemon=True,
                             name="GibsonNJE-TLS").start()
            server._tls_server = tls_server  # keep a handle alive
        except Exception:
            pass
    return server
