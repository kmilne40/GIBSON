"""Real ENUM-style REXX control-block walking works against GIBSON storage."""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from gibson.cli import build_state
from gibson.lang.integration import run_rexx_full
from gibson.lang.rexx.hoststorage import build_storage

class _A:
    def __init__(self, **k): self.__dict__.update(k)
    def __getattr__(self, k): return None

_WALK = r'''
cvt  = GetPtr(16)
asvt = GetPtr(cvt + 556)
maxu = GetPtr(asvt + 516)
do i = 0 to maxu - 1
  ascb = GetPtr(asvt + 528 + (i*4))
  if ascb = 0 then iterate
  jbnp = GetPtr(ascb + 176)
  if jbnp = 0 then iterate
  say strip(storage(d2x(jbnp),8))
end
rcvt = GetPtr(cvt + 992)
say 'DSN='strip(storage(d2x(rcvt+24),44))
exit
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
'''

def _state():
    return build_state(_A(sim_root=tempfile.mkdtemp()))

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def test_storage_image():
    hs = build_storage(_state(), "IBMUSER")
    ok("PSA+16 -> CVT", hs.word(16) == hs.cvt)
    ok("CVT+556 -> ASVT", hs.word(hs.cvt + 556) == hs.asvt)
    ok("CVT+992 -> RCVT", hs.word(hs.cvt + 992) == hs.rcvt)
    ok("RCVT eyecatcher", hs.read(hs.rcvt, 4).decode("latin-1") == "RCVT")

def test_rexx_walk():
    out = run_rexx_full(_state(), "IBMUSER", _WALK)
    ok("STORAGE() works from REXX", "DSN=" in out)
    ok("RACF dataset via RCVT walk", "SYS1.RACFDS" in out)
    ok("address spaces via ASVT/ASCB walk", "JES2" in out and "RACF" in out and "IBMUSER" in out)
    ok("started tasks enumerated", "TN3270" in out and "CICSPA01" in out)

def test_bit_builtins():
    from gibson.lang.rexx.builtins import BUILTINS
    ok("BITAND present", "BITAND" in BUILTINS)
    ok("BITAND 0F&3C=0C", ord(BUILTINS["BITAND"]([chr(0x0F), chr(0x3C)], None)) == 0x0C)


_ELV = r'''
cvt = GetPtr(16)
cvtauthl = GetPtr(cvt+484)
say 'NUMAPF='c2d(storage(d2x(cvtauthl),2))
ascb = GetPtr(548)
asxb = GetPtr(ascb+108)
acee = GetPtr(asxb+200)
say 'ACEE='storage(d2x(acee),4)
say 'USER='strip(storage(d2x(acee+21),8))
say 'FLG1='c2x(storage(d2x(acee+38),1))
exit
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
'''

def test_acee_and_apf():
    st=_state()
    out=run_rexx_full(st,"IBMUSER",_ELV)
    ok("ELV.APF APF-list walk (CVTAUTHL)", "NUMAPF=8" in out)
    ok("ELV.SELF ACEE eyecatcher via chain", "ACEE=ACEE" in out)
    ok("ACEE carries the userid", "USER=IBMUSER" in out)
    ok("ACEEFLG1 reflects RACF SPECIAL", "FLG1=80" in out)


def test_acee_dump_and_version():
    from gibson.tools.acee_display import show_acee, dump_acee
    st = _state()
    out = show_acee(st, "IBMUSER")
    ok("ACEE command includes a storage dump", "storage (as it appears in memory)" in out)
    ok("dump shows EBCDIC eyecatcher C1C3C5C5", "C1C3C5C5" in out)
    ok("dump char panel shows *ACEE*", "*ACEE" in out)
    d = dump_acee(st, "IBMUSER")
    ok("dump has classic +offset lines", "+000000" in d)
    # ECVT / z/OS version (VERS)
    from gibson.lang.integration import run_rexx_full
    vers = run_rexx_full(st, "IBMUSER", "cvt=c2d(storage(10,4));ecvt=c2d(storage(d2x(cvt+140),4));say strip(storage(d2x(ecvt),4))' 'strip(storage(d2x(ecvt+8),8))")
    ok("ECVT + sysplex readable (VERS)", "ECVT" in vers and "GIBSNPLX" in vers)


_ENUMX = r'''
cvt=GetPtr(16)
ecvt=GetPtr(cvt+140)
say 'VER='storage(d2x(ecvt+512),2)'.'storage(d2x(ecvt+514),2)'.'storage(d2x(ecvt+516),2)
say 'PROD='strip(storage(d2x(cvt-40),7))' FMID='strip(storage(d2x(cvt-32),7))
jesct=GetPtr(cvt+296)
sscvt=GetPtr(jesct+24)
subs=''
do while sscvt <> 0
  subs=subs storage(d2x(sscvt+8),4)
  sscvt=GetPtr(sscvt+4)
end
say 'SUBS='subs
dsdt=GetPtr(GetPtr(cvt+992)+224)
say 'RACF='strip(storage(d2x(dsdt+177),44))
exit
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
'''

def test_enum_vers_cat_sec():
    from gibson.lang.integration import run_rexx_full
    out = run_rexx_full(_state(), "IBMUSER", _ENUMX)
    ok("ENUM VERS reads version (ecvt+512/514/516)", "VER=03.02.00" in out)
    ok("ENUM VERS reads product + FMID (cvt-40/-32)", "PROD=Z/OS FMID=HBB77C0" in out)
    ok("ENUM subsystem chain (jesct+24 -> sscvt)", "JES2" in out and "MSTR" in out)
    ok("ENUM RACF dataset directory (rcvt+224 -> dsdt+177)", "RACF=SYS1.RACFDS" in out)


_PATH = r'''
cvt=GetPtr(16)
ecvt=GetPtr(cvt+140)
say 'MCAT='STRIP(SUBSTR(GetStorage(GetPtr(ecvt+392)+224,63),11,44))
tcb=GetPtr(GetPtr(cvt)+4)
say 'JOB='STRIP(GetStorage(GetPtr(tcb+12),8))
t=GetPtr(C2D(STORAGE('21C',4))+12)+24
elen=0;dd=''
do forever
  t=t+elen
  elen=C2D(GetStorage(t,1))
  if elen==0 then leave
  ddn=GetStorage(t+4,8)
  if ddn \== '        ' then dd=ddn
  say STRIP(dd)'='STRIP(GetStorage(Swareq(GetStorage(t+12,3)),44))
end
exit
Swareq: procedure
  if SUBSTR(X2B(C2X(GetStorage(GetPtr(GetPtr(C2D(STORAGE('21C',4))+180)+244)+16,1))),6,1)=='1' then return C2D(ARG(1))+16
  return C2D(ARG(1))+16
GetPtr: procedure
  return C2D(Storage(D2X(arg(1)),4))
GetStorage: procedure
  return Storage(D2X(arg(1)),arg(2))
'''

def test_enum_path_cat():
    from gibson.lang.integration import run_rexx_full
    out=run_rexx_full(_state(),"IBMUSER",_PATH)
    ok("ENUM CAT master catalog (ecvt+392 -> IPA)", "MCAT=CATALOG.MASTER.GIBSON" in out)
    ok("ENUM jobname (CVT->TCBP->TCB->TIOT)", "JOB=IBMUSER" in out)
    ok("ENUM PATH SYSPROC via TIOT+Swareq", "SYSPROC=SYS1.SISPEXEC" in out)
    ok("ENUM PATH SYSEXEC via TIOT+Swareq", "SYSEXEC=SYS1.SBPXEXEC" in out)

def test_x2b_b2x():
    from gibson.lang.rexx.builtins import BUILTINS
    ok("X2B present", BUILTINS["X2B"](["F1"],None)=="11110001")
    ok("B2X round-trips", BUILTINS["B2X"](["11110001"],None)=="F1")

if __name__ == "__main__":
    for fn in (test_storage_image, test_rexx_walk, test_bit_builtins, test_acee_and_apf, test_acee_dump_and_version, test_enum_vers_cat_sec, test_enum_path_cat, test_x2b_b2x):
        print("\n" + fn.__name__); fn()
    print(f"\nREXX control-block walk: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
