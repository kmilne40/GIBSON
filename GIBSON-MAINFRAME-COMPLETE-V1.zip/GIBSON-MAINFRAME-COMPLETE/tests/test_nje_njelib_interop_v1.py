"""RC-11: GIBSON NJE must interoperate with real NJElib (iNJEctor.py / jcl.py).

These lock the byte-level contract NJElib's parser depends on, verified live
against the real tools during development:
  * the NCCR 'J' sign-on record carries the full 39-byte NCCI body (the old
    minimal record raised IndexError at Data[34] before any command exchange);
  * NMR operator commands round-trip (iNJEctor -> $HASP output);
  * the SYSOUT completion header is long enough for njelib.job_headers (jcl.py).
No external dependency: we replicate the exact offsets NJElib indexes.
"""
from gibson.net import nje_protocol as P


def _nccr_data(framed: bytes) -> bytes:
    # TTB(8)+TTR(4)+DLESTX(2)+BCB(1)+FCS(2)+RCB(1)+SRCB(1) = 19, TTB EOB = last 4
    return framed[19:-4]


def test_signon_j_has_full_ncci_body():
    jrec = P.signon_reply(True, node_name="HAL", node_num=2, password="HAL123")
    # SRCB at offset 18 (nje-pass-brute) is 'J', not 'B'
    assert jrec[18] == P.SRCB_J and jrec[18] != P.SRCB_B
    data = _nccr_data(jrec)
    # njelib.process_NCCR indexes these - all must exist (no IndexError)
    assert data[0] == 0x29                 # NCCIDL >= 0x29 so features are read
    assert len(data) >= 39                 # up to NCCIFEAT[35:39]
    assert data[9] == 2                    # NCCIQUAL -> peer's target_node
    assert data[10:14] != b"\x00\x00\x00\x00"   # non-zero NCCIEVNT -> peer sends L
    _ = data[34]                           # NCCIFLG must be present
    assert len(data[35:39]) == 4           # NCCIFEAT


def test_signon_b_reject_marks_srcb_b():
    brec = P.signon_reply(False)
    assert brec[18] == P.SRCB_B


def test_nmr_command_roundtrips():
    for cmd in ["$T NJEDEF ,NODENUM=5", "$T NODE(5) ,NAME=H4CKR", "$D NODE"]:
        wire = P.build_nmr_message(cmd, to_node="HAL", from_node="GIBSON")
        assert P.parse_nmr_command(wire) == cmd.upper()


def test_nmr_reply_lines_are_separate_records():
    out = "$HASP831 NJEDEF\n$HASP831 NJEDEF OWNNAME=GIBSON"
    wire = P.build_nmr_replies(out, to_node="GIBSON", from_node="HAL")
    # two NMR records => two TTB blocks (each starts 0x00 0x00 <len>)
    assert wire.count(b"\x10\x02") == 2


def test_sysout_completion_header_is_long_enough():
    stream = P.build_sysout_completion(27127, "HCKRNJE")
    # header record + EOF record
    assert stream.count(b"\x10\x02") == 2
    # the NJH general section must cover njelib.job_headers' highest read (>=212)
    hdr_data = _nccr_data(stream[:stream.index(b"\x10\x02", 2) - 8]) if False else None
    # simpler: the compressed header record must be comfortably large
    assert len(stream) > 200


def test_is_stream_request_precise():
    req = P.grant_stream(0x98)  # a framed 0xA0; not a request
    assert P.is_stream_request(req) is None
    # a real 0x90 request has RCB 0x90 at offset 17
    reqframe = P._frame_record(0x90, 0x98, b"\x00\x00", compress=False)
    assert P.is_stream_request(reqframe) == 0x98
    # a J sign-on record is not a stream request
    assert P.is_stream_request(P.signon_reply(True)) is None
