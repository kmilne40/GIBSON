#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# run-with-web3270.sh - start/stop the web3270 add-on (standalone).
# It connects to your GIBSON at GIBSON_HOST:GIBSON_PORT (default :23), so GIBSON
# can be native or Docker, local or on your LAN - web3270 doesn't care.
#
#   ./integrations/web3270/run-with-web3270.sh up     # build + start
#   ./integrations/web3270/run-with-web3270.sh down    # stop
#   ./integrations/web3270/run-with-web3270.sh logs    # follow logs
#   ./integrations/web3270/run-with-web3270.sh ps      # status
# ---------------------------------------------------------------------------
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$HERE/../.." && pwd)"
ENV_FILE="$HERE/.env.web3270"
COMPOSE_FILE="integrations/web3270/docker-compose.web3270.yml"
ACTION="${1:-up}"; shift || true

cd "$REPO_ROOT"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "[!] .env.web3270 not found. Run ./integrations/web3270/setup-web3270.sh first."
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  DC=(docker-compose)
else
  echo "[!] Docker Compose not found. Install Docker Desktop or the compose plugin."
  exit 1
fi

# -p gives it its own project; --project-directory pins relative-path resolution
COMPOSE=("${DC[@]}" -p gibson-web3270 --project-directory "$REPO_ROOT" --env-file "$ENV_FILE" -f "$COMPOSE_FILE")

# surface the configured target
TARGET_HOST="$(grep -E '^GIBSON_HOST=' "$ENV_FILE" | cut -d= -f2-)"
TARGET_PORT="$(grep -E '^GIBSON_PORT=' "$ENV_FILE" | cut -d= -f2-)"

case "$ACTION" in
  up)
    "${COMPOSE[@]}" up -d --build "$@"
    echo
    echo "web3270 is starting."
    echo "  open client : http://<this-host>:18080"
    echo "  connects to : GIBSON at ${TARGET_HOST:-192.168.0.10}:${TARGET_PORT:-23} (VTAM/TSO, TN3270)"
    ;;
  down)  "${COMPOSE[@]}" down "$@" ;;
  logs)  "${COMPOSE[@]}" logs -f "$@" ;;
  ps)    "${COMPOSE[@]}" ps "$@" ;;
  *)     "${COMPOSE[@]}" "$ACTION" "$@" ;;
esac
