#!/usr/bin/env bash
# ===========================================================================
# web3270.sh - one-shot bootstrap + doctor for the GIBSON web3270 add-on.
#
# Does everything, in the foreground, with visible output:
#   preflight (docker/compose/git) -> fetch upstream -> detect build ->
#   write .env -> build + start -> report status + probe the UI port.
#
# Usage:
#   ./integrations/web3270/web3270.sh [up]        # default: bootstrap + start
#   ./integrations/web3270/web3270.sh doctor       # checks only, no changes
#   ./integrations/web3270/web3270.sh down          # stop + remove container
#   ./integrations/web3270/web3270.sh logs          # follow container logs
#   ./integrations/web3270/web3270.sh status        # container + port status
#   ./integrations/web3270/web3270.sh rebuild       # force a clean rebuild
#
# Options (env or flags):
#   --gibson-host H   GIBSON address the bridge dials   (default: host.docker.internal)
#   --gibson-port P   GIBSON telnet/TSO port            (default: 23)
#   --ui-port N       Browser UI port to publish        (default: 18080)
#   --api-key K       Anthropic key for Copilot         (default: none)
#   --ref REF         upstream git ref/commit to pin    (default: main)
# ===========================================================================
set -uo pipefail

# ---- locate ---------------------------------------------------------------
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$HERE/../.." && pwd)"
VENDOR="$HERE/vendor/web3270"
ENV_FILE="$HERE/.env.web3270"
COMPOSE_FILE="$HERE/docker-compose.web3270.yml"
UPSTREAM="https://github.com/wren-creator/web3270.git"

# ---- defaults / options ---------------------------------------------------
GIBSON_HOST="${GIBSON_HOST:-host.docker.internal}"
GIBSON_PORT="${GIBSON_PORT:-23}"
UI_PORT="${GIBSON_WEB3270_PORT:-18080}"
API_KEY="${ANTHROPIC_API_KEY:-}"
REF="${WEB3270_REF:-main}"
ACTION="up"

while [[ $# -gt 0 ]]; do
  case "$1" in
    up|down|logs|status|doctor|rebuild) ACTION="$1" ;;
    --gibson-host) GIBSON_HOST="$2"; shift ;;
    --gibson-port) GIBSON_PORT="$2"; shift ;;
    --ui-port)     UI_PORT="$2"; shift ;;
    --api-key)     API_KEY="$2"; shift ;;
    --ref)         REF="$2"; shift ;;
    -h|--help)     sed -n '2,30p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

# ---- pretty ---------------------------------------------------------------
if [[ -t 1 ]]; then B='\033[1;94m'; G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; D='\033[0m'
else B=''; G=''; Y=''; R=''; D=''; fi
step(){ printf "\n${B}==>${D} %s\n" "$*"; }
ok(){   printf "  ${G}[OK]${D} %s\n" "$*"; }
warn(){ printf "  ${Y}[!]${D} %s\n" "$*"; }
err(){  printf "  ${R}[X]${D} %s\n" "$*"; }

# ---- compose command ------------------------------------------------------
DC=""
detect_compose(){
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    DC="docker compose"
  elif command -v docker-compose >/dev/null 2>&1; then
    DC="docker-compose"
  else
    return 1
  fi
}
compose(){ # shellcheck disable=SC2086
  $DC -p gibson-web3270 --project-directory "$REPO_ROOT" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
}

# ---- preflight ------------------------------------------------------------
preflight(){
  step "Preflight"
  local fatal=0
  if command -v docker >/dev/null 2>&1; then
    if docker info >/dev/null 2>&1; then ok "docker present and the daemon is running"
    else err "docker is installed but the daemon isn't reachable (try: sudo systemctl start docker, or add yourself to the 'docker' group)"; fatal=1; fi
  else err "docker not found  ->  install Docker Engine / Docker Desktop"; fatal=1; fi
  if detect_compose; then ok "compose available ($DC)"; else err "docker compose not found  ->  install the compose plugin"; fatal=1; fi
  if command -v git >/dev/null 2>&1; then ok "git present ($(git --version | awk '{print $3}'))"; else err "git not found  ->  sudo apt install -y git"; fatal=1; fi
  command -v curl >/dev/null 2>&1 && ok "curl present (used for UI probe)" || warn "curl not found (UI probe will be limited)"
  return $fatal
}

# ---- fetch upstream -------------------------------------------------------
fetch_source(){
  step "Fetching upstream (wren-creator/web3270 @ $REF)"
  if [[ -d "$VENDOR/.git" ]]; then
    if git -C "$VENDOR" fetch --depth 1 origin "$REF" >/dev/null 2>&1 && git -C "$VENDOR" checkout -q FETCH_HEAD 2>/dev/null; then
      ok "updated existing checkout"
    else warn "could not update; using existing checkout"; fi
  else
    mkdir -p "$HERE/vendor"
    if git clone --depth 1 --branch "$REF" "$UPSTREAM" "$VENDOR" 2>/tmp/w3270_clone.err || git clone "$UPSTREAM" "$VENDOR" 2>>/tmp/w3270_clone.err; then
      ok "cloned into vendor/web3270"
    else
      err "clone failed. Details:"; sed 's/^/      /' /tmp/w3270_clone.err
      err "check connectivity:  git ls-remote $UPSTREAM"
      return 1
    fi
  fi
}

# ---- detect Dockerfile / build context ------------------------------------
CTX=""; DF="Dockerfile"
detect_build(){
  step "Locating the build context"
  local found
  found="$(find "$VENDOR" -maxdepth 3 -type f -name Dockerfile 2>/dev/null | head -n1)"
  if [[ -n "$found" ]]; then
    CTX="$(cd "$(dirname "$found")" && pwd)"; DF="Dockerfile"
    ok "Dockerfile: $found"
    ok "build context: $CTX"
  else
    warn "no Dockerfile in the upstream repo - generating a minimal Node.js one"
    # pick the dir that has package.json or server.js as the context
    local base
    base="$(find "$VENDOR" -maxdepth 3 -type f \( -name package.json -o -name server.js \) 2>/dev/null | head -n1)"
    if [[ -z "$base" ]]; then err "can't find package.json or server.js either - can't build. Inspect $VENDOR"; return 1; fi
    CTX="$(cd "$(dirname "$base")" && pwd)"
    DF="Dockerfile.gibson"
    cat > "$CTX/$DF" <<'DOCKER'
# Auto-generated fallback for the web3270 Node bridge
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN (npm ci || npm install) 2>/dev/null || true
EXPOSE 8080
# start: prefer an npm "start" script, else server.js, else package.json main
CMD ["sh","-c","if node -e \"process.exit(require('./package.json').scripts&&require('./package.json').scripts.start?0:1)\" 2>/dev/null; then npm start; elif [ -f server.js ]; then node server.js; else node \"$(node -e \"process.stdout.write(require('./package.json').main||'index.js')\")\"; fi"]
DOCKER
    ok "generated $CTX/$DF (context: $CTX)"
  fi
}

# ---- write .env -----------------------------------------------------------
write_env(){
  step "Writing $ENV_FILE"
  cat > "$ENV_FILE" <<ENV
# generated by web3270.sh on $(date)
WEB3270_CONTEXT=$CTX
WEB3270_DOCKERFILE=$DF
GIBSON_HOST=$GIBSON_HOST
GIBSON_PORT=$GIBSON_PORT
GIBSON_TLS=false
WEB3270_UI_PORT=$UI_PORT
DEFAULT_MODEL=3278-2
DEFAULT_CODEPAGE=37
ANTHROPIC_API_KEY=$API_KEY
ENV
  ok "target: bridge -> ${GIBSON_HOST}:${GIBSON_PORT}   UI -> :${UI_PORT}"
  [[ -n "$API_KEY" ]] && ok "Copilot: enabled" || warn "Copilot: disabled (no --api-key); terminal + macros still work"
}

# ---- reachability of GIBSON from the host ---------------------------------
check_gibson(){
  step "Checking GIBSON is listening"
  # host.docker.internal is only resolvable inside containers; test the host loopback
  local h="$GIBSON_HOST"; [[ "$h" == "host.docker.internal" ]] && h="127.0.0.1"
  if (exec 3<>"/dev/tcp/$h/$GIBSON_PORT") 2>/dev/null; then exec 3>&- 3<&-; ok "GIBSON reachable at ${h}:${GIBSON_PORT}"
  else warn "nothing answered at ${h}:${GIBSON_PORT} - is GIBSON started (./gibsonctl.sh start) and on port ${GIBSON_PORT}?"; fi
}

# ---- build + start --------------------------------------------------------
bring_up(){
  step "Building + starting web3270 (this shows build output)"
  if ! compose up -d --build; then
    err "compose up failed - see the build output above"
    err "common causes: no network during 'npm install', or a bad build context"
    return 1
  fi
  ok "container requested"
}

# ---- status / probe -------------------------------------------------------
show_status(){
  step "Container status"
  docker ps -a --filter "name=gibson-web3270" --format '  {{.Names}}  {{.Status}}  {{.Ports}}' || true
  local st; st="$(docker inspect -f '{{.State.Status}}' gibson-web3270 2>/dev/null || echo missing)"
  if [[ "$st" != "running" ]]; then
    err "container is '$st'. Last 25 log lines:"; docker logs gibson-web3270 --tail 25 2>&1 | sed 's/^/      /' || true
    return 1
  fi
  ok "container running"
}

probe_ui(){
  step "Probing the UI on :${UI_PORT}"
  if ! command -v curl >/dev/null 2>&1; then warn "curl missing; open http://<host>:${UI_PORT} in a browser to test"; return 0; fi
  local code; code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 4 "http://127.0.0.1:${UI_PORT}/" 2>/dev/null || echo 000)"
  case "$code" in
    200|301|302|304) ok "HTTP $code - a web page is served. Open: http://<your-gibson-ip>:${UI_PORT}/" ;;
    426) warn "HTTP 426 (Upgrade Required) - :${UI_PORT} is the WebSocket endpoint, not a web page." ; ui_hint ;;
    400|404) warn "HTTP $code - server is up but '/' isn't the UI." ; ui_hint ;;
    000) err "nothing answered on :${UI_PORT} - the bridge didn't bind. Check: docker logs gibson-web3270" ;;
    *) warn "HTTP $code - unexpected; check docker logs gibson-web3270" ;;
  esac
}
ui_hint(){
  local html; html="$(find "$VENDOR" -maxdepth 3 -name 'tn3270-client.html' 2>/dev/null | head -n1)"
  printf "      The browser client is a static file. Open it locally and point it at ws://<host>:%s :\n" "$UI_PORT"
  [[ -n "$html" ]] && printf "        %s\n" "$html" || printf "        (look under %s for public/tn3270-client.html)\n" "$VENDOR"
  printf "      If you'd rather it be served at http://<host>:%s, tell me and I'll add a static server.\n" "$UI_PORT"
}

# ===========================================================================
case "$ACTION" in
  down)
    detect_compose || { err "compose not found"; exit 1; }
    step "Stopping web3270"; compose down && ok "stopped" ;;
  logs)
    detect_compose || { err "compose not found"; exit 1; }
    compose logs -f ;;
  status)
    detect_compose >/dev/null 2>&1 || true; show_status; probe_ui ;;
  doctor)
    preflight || true
    [[ -d "$VENDOR" ]] && ok "upstream present at $VENDOR" || warn "upstream not fetched yet (run: $0 up)"
    [[ -f "$ENV_FILE" ]] && { ok ".env.web3270 present"; grep -E '^(WEB3270_CONTEXT|GIBSON_HOST|GIBSON_PORT|WEB3270_UI_PORT)=' "$ENV_FILE" | sed 's/^/      /'; } || warn ".env.web3270 not written yet"
    check_gibson
    docker ps -a --filter "name=gibson-web3270" --format '  {{.Names}}  {{.Status}}' 2>/dev/null | grep -q . && show_status && probe_ui || warn "no gibson-web3270 container yet" ;;
  rebuild)
    preflight || { err "fix preflight failures above"; exit 1; }
    detect_compose; compose down 2>/dev/null || true
    fetch_source && detect_build && write_env || exit 1
    step "Clean rebuild"; compose build --no-cache && compose up -d && show_status && probe_ui ;;
  up)
    preflight || { err "Fix the preflight failures above, then re-run."; exit 1; }
    fetch_source   || exit 1
    detect_build   || exit 1
    write_env
    check_gibson
    bring_up       || exit 1
    sleep 2
    show_status    || exit 1
    probe_ui
    step "Done"
    ok  "web3270 is up. From this host: http://localhost:${UI_PORT}"
    ok  "Remote:  http://<your-gibson-ip>:${UI_PORT}   (connect to GIBSON ${GIBSON_HOST}:${GIBSON_PORT})"
    printf "  ${B}manage:${D} %s {status|logs|down|rebuild}\n" "$0"
    ;;
esac
