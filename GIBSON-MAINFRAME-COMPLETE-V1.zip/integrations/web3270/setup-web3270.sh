#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# setup-web3270.sh - one-time fetch + configure of the web3270 add-on.
#
#   * clones (or updates) wren-creator/web3270 into vendor/web3270
#   * locates its Dockerfile / build context (repo root or Bridge_server/)
#   * writes .env.web3270 (from the template) with the right build paths
#
# Run once from anywhere:  ./integrations/web3270/setup-web3270.sh
# Then bring it up:        ./integrations/web3270/run-with-web3270.sh up
# ---------------------------------------------------------------------------
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$HERE/../.." && pwd)"
VENDOR="$HERE/vendor/web3270"
UPSTREAM="${WEB3270_REPO:-https://github.com/wren-creator/web3270.git}"
# Pin a commit/tag for reproducibility by exporting WEB3270_REF before running.
REF="${WEB3270_REF:-main}"

BLUE='\033[1;94m'; GREEN='\033[1;32m'; RED='\033[1;31m'; RESET='\033[0m'
step() { printf '%b==>%b %s\n' "$BLUE" "$RESET" "$*"; }
ok()   { printf '%b[OK]%b %s\n' "$GREEN" "$RESET" "$*"; }
warn() { printf '%b[!]%b %s\n' "$RED" "$RESET" "$*"; }

command -v git >/dev/null 2>&1 || { warn "git is required"; exit 1; }

# 1) fetch / update upstream ------------------------------------------------
if [[ -d "$VENDOR/.git" ]]; then
  step "Updating existing web3270 checkout"
  git -C "$VENDOR" fetch --depth 1 origin "$REF" && git -C "$VENDOR" checkout -q FETCH_HEAD || \
    git -C "$VENDOR" pull --ff-only || warn "Could not update; using existing checkout"
else
  step "Cloning $UPSTREAM (ref: $REF)"
  mkdir -p "$HERE/vendor"
  git clone --depth 1 --branch "$REF" "$UPSTREAM" "$VENDOR" 2>/dev/null || \
    git clone "$UPSTREAM" "$VENDOR"
fi
ok "Source in $VENDOR"

# 2) locate the Dockerfile / build context ----------------------------------
step "Locating Dockerfile"
DF="$(find "$VENDOR" -maxdepth 3 -type f -name Dockerfile 2>/dev/null | head -n1 || true)"
if [[ -z "$DF" ]]; then
  warn "No Dockerfile found in the upstream repo."
  warn "The bridge is a plain Node.js app; you can still run it with 'node server.js'."
  warn "See integrations/web3270/README.md (Native / non-Docker section)."
  CONTEXT_DIR="$VENDOR"
  DOCKERFILE_REL="Dockerfile"
else
  CONTEXT_DIR="$(dirname "$DF")"
  DOCKERFILE_REL="Dockerfile"
  ok "Dockerfile: $DF"
fi
# Use an ABSOLUTE build-context path. Compose resolves a *relative* build
# context against the compose file's own directory, which would double the
# path and fail the build; an absolute path is unambiguous.
CONTEXT_REL="$CONTEXT_DIR"

# 3) write .env.web3270 -----------------------------------------------------
ENV_FILE="$HERE/.env.web3270"
if [[ ! -f "$ENV_FILE" ]]; then
  step "Creating .env.web3270 from template"
  cp "$HERE/.env.web3270.example" "$ENV_FILE"
fi
# update the two build-path lines in place
sed -i.bak -E "s#^WEB3270_CONTEXT=.*#WEB3270_CONTEXT=${CONTEXT_REL}#" "$ENV_FILE"
sed -i.bak -E "s#^WEB3270_DOCKERFILE=.*#WEB3270_DOCKERFILE=${DOCKERFILE_REL}#" "$ENV_FILE"
rm -f "$ENV_FILE.bak"
ok "Wrote build context: $CONTEXT_REL ($DOCKERFILE_REL)"

cat <<DONE

${GREEN}web3270 add-on is ready.${RESET}

  1. (optional) put your Anthropic key in:  integrations/web3270/.env.web3270
                 ANTHROPIC_API_KEY=sk-ant-...
  2. bring GIBSON + web3270 up together:
                 ./integrations/web3270/run-with-web3270.sh up
  3. open the client:   http://<web3270-host>:18080
                 set GIBSON_HOST in .env.web3270, then connect to GIBSON port 23

DONE
