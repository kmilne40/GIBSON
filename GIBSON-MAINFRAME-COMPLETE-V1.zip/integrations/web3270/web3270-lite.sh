#!/usr/bin/env bash
# ===========================================================================
# web3270-lite.sh - self-contained browser 3270 for GIBSON (ttyd + c3270).
#
# Preference order (whatever is available):
#   1. Docker      -> build a tiny image once, run it (host net on Linux).
#   2. Native      -> if ttyd + c3270 are installed on the host, run directly.
#   3. Otherwise   -> print the one command needed and exit 0 (GIBSON unaffected).
#
#   ./web3270-lite.sh up | down | rebuild | logs | ps
#
# Tunables (env):
#   GIBSON_HOST (127.0.0.1)  GIBSON_PORT (23)  WEB3270_UI_PORT (18080)
#   C3270_MODEL (3279-2)     WEB3270_FORCE_NATIVE=1 to skip Docker
# ===========================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CTX="$HERE/lite"
IMAGE="${WEB3270_IMAGE:-gibson/web3270-lite:local}"
NAME="${WEB3270_NAME:-gibson-web3270}"
GIBSON_HOST="${GIBSON_HOST:-127.0.0.1}"
GIBSON_PORT="${GIBSON_PORT:-23}"
WEB_PORT="${WEB3270_UI_PORT:-18080}"
C3270_MODEL="${C3270_MODEL:-3279-2}"
PIDFILE="${WEB3270_PIDFILE:-$HERE/.web3270-native.pid}"
ACTION="${1:-up}"

have(){ command -v "$1" >/dev/null 2>&1; }
is_linux(){ [[ "$(uname -s)" == "Linux" ]]; }
docker_ok(){ have docker && docker info >/dev/null 2>&1; }

# ---- Docker backend -------------------------------------------------------
docker_build(){
  if docker image inspect "$IMAGE" >/dev/null 2>&1 && [[ "${1:-}" != "--force" ]]; then
    return 0
  fi
  echo "==> building $IMAGE (one time)"
  docker build -t "$IMAGE" "$CTX"
}

docker_run(){
  docker rm -f "$NAME" >/dev/null 2>&1 || true
  if is_linux; then
    # host network: container reaches native GIBSON on 127.0.0.1 and ttyd
    # binds :$WEB_PORT straight on the host. Simplest + most reliable on Linux.
    docker run -d --name "$NAME" --restart unless-stopped --network host \
      -e GIBSON_HOST="$GIBSON_HOST" -e GIBSON_PORT="$GIBSON_PORT" \
      -e WEB_PORT="$WEB_PORT" -e C3270_MODEL="$C3270_MODEL" "$IMAGE"
  else
    # Docker Desktop (Mac/Windows): bridge + host-gateway so a natively-running
    # GIBSON is reachable as host.docker.internal.
    local h="$GIBSON_HOST"; case "$h" in 127.0.0.1|localhost) h=host.docker.internal;; esac
    docker run -d --name "$NAME" --restart unless-stopped \
      -p "${WEB_PORT}:8080" --add-host host.docker.internal:host-gateway \
      -e GIBSON_HOST="$h" -e GIBSON_PORT="$GIBSON_PORT" \
      -e WEB_PORT=8080 -e C3270_MODEL="$C3270_MODEL" "$IMAGE"
  fi
}

# ---- Native backend (no Docker) ------------------------------------------
native_up(){
  have ttyd && have c3270 || return 1
  native_down
  nohup ttyd -W -p "$WEB_PORT" -T xterm-256color \
        c3270 -model "$C3270_MODEL" "$GIBSON_HOST" "$GIBSON_PORT" \
        >/dev/null 2>&1 &
  echo $! > "$PIDFILE"
  echo "==> web3270 (native ttyd+c3270) pid $(cat "$PIDFILE")"
}
native_down(){
  [[ -f "$PIDFILE" ]] || return 0
  kill "$(cat "$PIDFILE")" >/dev/null 2>&1 || true
  rm -f "$PIDFILE"
}

up(){
  if [[ "${WEB3270_FORCE_NATIVE:-0}" != "1" ]] && docker_ok; then
    docker_build && docker_run
  elif native_up; then
    :
  else
    echo "[!] web3270 needs either Docker, or ttyd + c3270 installed."
    echo "    Debian/Kali/Ubuntu:   sudo apt-get install -y ttyd c3270"
    echo "    (GIBSON itself is unaffected; this only skips the browser terminal.)"
    return 0
  fi
  echo "web3270 up -> http://localhost:${WEB_PORT}   (GIBSON ${GIBSON_HOST}:${GIBSON_PORT})"
}

down(){
  docker rm -f "$NAME" >/dev/null 2>&1 || true
  native_down
}

case "$ACTION" in
  up)      up ;;
  rebuild) docker_ok && docker_build --force && docker_run || up ;;
  down)    down ;;
  logs)    docker logs -f "$NAME" 2>/dev/null || { echo "native mode: no container logs"; } ;;
  ps)      docker ps --filter "name=$NAME" 2>/dev/null; [[ -f "$PIDFILE" ]] && echo "native pid $(cat "$PIDFILE")" || true ;;
  *)       echo "usage: $0 {up|down|rebuild|logs|ps}"; exit 1 ;;
esac
