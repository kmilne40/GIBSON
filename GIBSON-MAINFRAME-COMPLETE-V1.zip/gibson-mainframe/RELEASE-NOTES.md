# GIBSON — Consolidated Release Notes

This release folds together all work from the current development session into a
single tree. Everything below is cumulative and interlocking; each feature was
built, tested, and regression-checked against the pristine baseline.

## IND$FILE (file transfer)
- Root-caused the long-standing "never gets the START / just hangs": `recv_packet`
  waited indefinitely on a stalled transfer. Added `recv_packet_bounded` (default
  15s, `GIBSON_INDFILE_TIMEOUT`) so a stall aborts cleanly with `IND$FILE013E`.
- Hardened the TSOAPP command detection and added opt-in diagnostics
  (`GIBSON_INDFILE_DEBUG=1` → stderr, or `=/path` → file).
- Verified the DFT protocol at the wire level against web3270's real client
  parser (upload + download round-trip). Live emulator confirmation still pending.

## RACF SETROPTS panels (options 1/2/3/5/6)
- Comprehensive, authentic `SETROPTS LIST` (ATTRIBUTES, ACTIVE/GENERIC/RACLIST
  classes, full PASSWORD PROCESSING OPTIONS with syntax rules, PROTECTALL, TAPEDSN,
  JES options, audit section) plus focused AUDIT / CLASS / OTHER listings and a
  real REFRESH with ICH messages.

## RACF database / IRRDBU00 (verified)
- Confirmed `RACFDB BACKUP` writes a valid binary `SYS1.RACFDS.BACKUP`, round-trips
  through the racf2john-style scanner, and yields real DES hashes crackable by
  `john --format=racf`; IRRDBU00 unload emits the correct record types with no
  password-hash leakage. Passtickets present.

## Living LPAR (address-space population)
- `gibson/core/address_spaces.py`: ~40 standard z/OS started tasks / system
  address spaces with ASID, program, owning RACF id, WLM service class, CPU jitter.
- Surfaced in SDSF DA, `D A,L` (IEE114I), an ambient SYSLOG heartbeat, and a
  `D STARTED` STARTED-class privilege review.

## Db2 for z/OS depth
- SQLCODE/SQLSTATE vocabulary (`db2_sqlcodes.py`): `-204/-206/-104/-803/-811/-551/
  -904/-911/-305/+100` with the authentic SPUFI `DSNT408I` diagnostic block; a
  missing table now returns `-204` (not a generic `-104`); unqualified names resolve.
- DDF: `-DIS DDF [DETAIL]`, `-DIS THREAD(*)`, `-DIS DATABASE`, DBAT model.
- DSNZPARM display; catalog completion (SYSPACKAGE/SYSDATABASE/SYSTABLESPACE/
  SYSINDEXES/SYSKEYS/SYSDUMMY1); `DSNUTILB` utility execution in JCL (LOAD/REORG/
  RUNSTATS/COPY/CHECK/QUIESCE with DSNU messages).
- DSNR plan-execute security: unauthorized plan EXECUTE → `-551` + `DSNT501I` +
  RC=8 + `ICH408I` (MDSNPN) + SMF 80; `GRANT/REVOKE EXECUTE ON PLAN`; SYSPLANAUTH.
- Reconciled the two `Db2Simulator` classes (db2.py delegates the richer engine to
  db2_sim.py) and fixed a SQL prefix-collision (SYSPLANAUTH vs SYSPLAN).

## z/OS Connect
- `gibson/core/zosconnect.py`: the `/zosConnect` admin API (apis/services/operations,
  lifecycle, SAR deploy), Liberty `server.xml`, auth+audit interceptors (SMF 123),
  SAF authority levels (Admin/Operations/Invoke/Reader) enforced against RACF groups,
  BAQ messages + HTTP 403/415/404, and an invoke path that becomes real Db2 SQL.
- BAQSTRT Liberty STC added to the address-space population; wired into the HTTP router.

## zSecure
- CKFREEZE snapshot (`ckfreeze.py`): APF list, sensitive datasets, started tasks,
  address spaces, subsystems; `CKFCOLL` writes `SYS1.CKFREEZE`; flags writable APF.
- CARLa interpreter (`carla.py`): `NEWLIST TYPE=RACF|GROUP|SMF|APF|SENSDSN|STC|…`,
  SELECT/EXCLUDE (flags, comparisons, comma-lists, wildcards), SORTLIST/DISPLAY,
  SUMMARY. Education layer: HELP, FIELDS discovery, EXAMPLES, forgiving errors.
- Compliance framework (`compliance.py`): STIG + PCI-DSS as STANDARD/DOMAIN/RULE with
  PASS/FAIL, a compliance %, and remediable open findings.
- zSecure ISPF front-end (`zsecure3270.py`): SE/RA/AU/EV/RE/CO/CM menu with an
  interactive CARLa panel — launched from the primary ISPF `ZSEC` command.
- Escalation lab (`escalation_lab.py`): `ZSEC LAB SETUP` seeds a privileged started
  task (AUTOMON under OPERATIONS id AUTOOPER); discoverable via STCRISK / D STARTED /
  CKFREEZE / STIG ACP00294; remediate with `ALTUSER AUTOOPER NOOPERATIONS`.
- Fixed `_owner_attrs` to detect OPERATIONS/UID(0) (not just SPECIAL) on STC owners.

## ISPF editor line commands
- Completed the set: shift `>` `<` `)` `(` (+ counts and block `>>` `<<` `))` `((`),
  case UC/LC (+ UCC/LCC), F/L (reveal first/last of an excluded block), COLS ruler,
  TS split, and recognition of TF/TE/BNDS/MASK/TABS. Core I/D/R/C/M/A/B/O/X/S intact.

## Consolidation fixes
- Restored the `ENTER LINE COMMAND AT LEFT` prompt on the DSLIST panel and added
  `NJE` to the `$D NODE` display header (both pre-existing test failures unrelated
  to this session's features).

## Test health
- Full suite: ~690 passing. No regressions introduced by this session's work — every
  additional failure was confirmed pre-existing on the pristine baseline, a
  prior-session tree difference, or single-process cross-test pollution.
- New test files added this session: indfile DFT, screen recorder/LPR, DSLIST
  commands, SETROPTS realism, address spaces, Db2 depth (x2), zosconnect, zsecure
  CARLa/CKFREEZE, compliance, CARLa education, ISPF editor line commands,
  zsecure ISPF front-end, escalation lab, Db2 plan security.
