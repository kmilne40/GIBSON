# PHOSPHOR v2 — Design & Plan

*A professional, installable mainframe terminal + toolkit that looks like
cool-retro-term, needs no GPU, and installs in one command.*

---

## 1. The problem with v1

The v1 CRT terminal used moderngl + pyglet, which need **system OpenGL libraries
(`libGL.so`, `libEGL.so`) installed by hand**. On a clean/locked-down box (e.g.
Kali with a wedged package manager) that turns a "just run it" into an
afternoon of apt archaeology. The effects themselves were never the problem —
the GPU dependency was.

## 2. Research — how to get the cool-retro-term look without the pain

| Approach | Look | Install | Hardware | Verdict |
|---|---|---|---|---|
| moderngl/pyglet (v1) | great | needs system libGL/EGL by hand | GPU | ✗ the current pain |
| Electron/Tauri + WebGL | great | 100–200 MB bundle | bundles GPU stack | heavy; user rejected browser-based |
| Rust/Go + wgpu/Ebiten | great | single binary | still wants a GL/Vulkan driver | can't build/test it here; re-risks proven engine |
| **pygame (SDL2) + numpy CPU effects** | **great** | **one pip wheel, SDL2 bundled, no GL** | **CPU only** | **chosen** |

**Key finding:** the CRT effects (bloom, glass/curvature, burn-in, glow-line,
scanlines, flicker, chroma) can all be computed on the **CPU** with numpy — this
is already proven by v1's preview renderer. And **pygame's wheel bundles SDL2**,
which draws to a software surface **without any OpenGL** — so `pip install pygame`
gives a working window on any desktop with nothing to hand-install. SDL2 needs
only X11/Wayland, which every desktop already has.

## 3. Why Python (not a Rust/Go rewrite) — the honest reason

The entire protocol engine — TN3270 datastream, IND$FILE (DFT), FTP, DRDA, the 8
audit modules, reporting, the CICSpwn adapter — is **already written and verified
against GIBSON**. A Rust/Go rewrite would re-implement all of that from scratch,
re-introducing risk, and (critically) **can't be compiled or tested in the build
environment used here** (no toolchain, no network for crates/modules). Staying in
Python reuses every tested line and swaps only the ~1 frontend that caused the
trouble. If a native binary is ever wanted, the v2 renderer is pure-CPU and ports
cleanly later — but not at the cost of the proven engine now.

## 4. Architecture — one integrated client

```
┌───────────────────────────────────────────────────────────┐
│  PHOSPHOR                                          ▢ ▢ ▢    │
├──────────────┬────────────────────────────────────────────┤
│  SIDEBAR     │                                             │
│              │        ╭──────────────────────────╮         │
│  Connect     │        │  BANKSYS1 PRODUCTION LPAR │         │
│   host/port  │        │                          │         │  <- CRT terminal
│   [EBCDIC ▾] │        │   (curved glass, bloom,  │         │     (software-rendered
│   Connect    │        │    burn-in, glow-line,   │         │      CPU effects)
│              │        │    scanlines, flicker)   │         │
│  Tools       │        │                          │         │
│   ▸ scan all │        ╰──────────────────────────╯         │
│   ▸ vtam     │                                             │
│   ▸ tso users│   [ command line ______________ ] [Enter]   │
│   ▸ cics ...│                                             │
│              ├─────────────────────────────────────────────┤
│  Transfer    │  Effects:  Bloom ▁▂▃▄▅  Burn-in ▁▂▃  ...    │
│   ⭱ upload   │  Profile: [Authentic ▾]   [Off] [Boardroom] │
│   ⭳ download │                                             │
│              │                                             │
│  Report      │                                             │
│   save HTML  │                                             │
└──────────────┴─────────────────────────────────────────────┘
```

Everything the brief asked for, in one window:
- **Connect** — host, port, and an **EBCDIC** TN3270 connection to GIBSON or a
  real mainframe. Codepage selectable (cp037 and friends).
- **Tools** — the recon menu lives in the sidebar; click a scan, it runs against
  the connected host and results drop into a findings panel + the report.
- **Transfer** — upload/download via IND$FILE and FTP, with native file dialogs.
- **Effects** — live sliders for every CRT effect + the profile presets
  (Authentic / Boardroom / Amber / Green / Off), so anyone can dial the look from
  full glass to flat.
- **Report** — one click writes the HTML/Markdown assessment.

## 5. Tech stack

- **Window & input:** pygame (SDL2, bundled in the wheel — no system GL).
- **Effects:** numpy on the CPU (bloom, curvature, burn-in, glow-line, scanlines,
  flicker, chroma, vignette, noise) — reuses v1's proven effect maths, made
  real-time and frame-animated.
- **File dialogs:** tkinter.filedialog (Python stdlib) for upload/download browse.
- **Engine:** the existing, tested phosphor.* packages, unchanged.
- **Config:** the existing EffectConfig + profiles, plus a small UI-state store.

## 6. Install story (the whole point)

```bash
pip install phosphor-tn3270           # pulls pygame + numpy; NO system libraries
phosphor-app                          # launches the integrated client
```

- No `libGL`, no `apt`, no compile, no GPU.
- Runs on a Raspberry Pi, a VM, or a laptop — the effects scale with an internal
  render resolution and every effect can be turned down or off for weak hardware.
- Optional: a **PyInstaller one-file binary** (`phosphor-app` with no Python at
  all) for handing to non-technical users — pygame/numpy bundle cleanly with
  PyInstaller because there are no external native GL libs to chase.

## 7. Performance plan (honest)

CRT effects run at a fixed **internal resolution** (e.g. 900×560) and SDL scales
the window. Only burn-in, glow-line and flicker animate per frame; the text layer
re-renders only when the screen changes. Expected: 45–60 fps on a laptop, ~20–30
fps on a Pi 4 — smooth for a terminal. Heavy effects (bloom) are a single toggle,
and the internal resolution is configurable, so it degrades gracefully.

## 8. Build order

1. **Software CRT renderer** (numpy) — real-time effect pipeline, verified by
   rendering animated frames to PNG. *(starting now)*
2. **pygame shell** — window, main loop, the CRT surface, keyboard → TN3270.
3. **Sidebar UI** — connect, tools, transfer, effects, report (themed to match).
4. **Wire the engine** — connection, scans, IND$FILE/FTP transfer, reporting.
5. **Packaging** — `pip install` entry point, then optional PyInstaller binary.
6. **Documentation** — a proper user guide (install, connect, scan, transfer,
   tune the look, troubleshoot) plus a quick-start.

## 9. Documentation deliverables

- **User Guide** (install → connect → use the tools → transfer files → tune the
  CRT → troubleshoot), written for skilled and non-skilled users.
- **Quick-start card** (three commands to first screen).
- Updated component/what's-new docs.

*Authorised, defensive training use only.*
