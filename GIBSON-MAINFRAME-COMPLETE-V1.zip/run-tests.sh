#!/usr/bin/env bash
# Run PHOSPHOR's whole unit-test suite in one go, with a summary.
#   bash run-tests.sh            # run everything
#   bash run-tests.sh nje        # run only tests whose name matches "nje"
# Uses pytest if available (nicer output), else the standalone runners.
set -u
cd "$(dirname "$0")"
PAT="${1:-}"

if command -v pytest >/dev/null 2>&1; then
    echo ">> pytest"
    exec pytest -q ${PAT:+-k "$PAT"} tests/
fi

echo ">> pytest not installed; running standalone test files"
pass=0; fail=0; failed=""
for t in tests/test_*.py; do
    [ -n "$PAT" ] && case "$t" in *"$PAT"*) ;; *) continue;; esac
    if python3 "$t" >/tmp/_t.out 2>&1; then
        pass=$((pass+1)); printf '  ok   %s\n' "${t##*/}"
    else
        # test_license.py only fails for lack of pytest - flag it, don't count as real
        if [ "${t##*/}" = "test_license.py" ]; then
            printf '  skip %s (needs pytest)\n' "${t##*/}"
        else
            fail=$((fail+1)); failed="$failed ${t##*/}"
            printf '  FAIL %s\n' "${t##*/}"; tail -3 /tmp/_t.out | sed 's/^/        /'
        fi
    fi
done
echo "------------------------------------------------------"
echo "  $pass passed, $fail failed$( [ -n "$failed" ] && echo " ($failed)")"
rm -f /tmp/_t.out
exit $([ "$fail" -eq 0 ] && echo 0 || echo 1)
