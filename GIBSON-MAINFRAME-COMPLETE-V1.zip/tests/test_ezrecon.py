"""EZrecon core: key management (prompt on first run, no secrets in source),
backend reporting, validation, and clean degradation when deps are absent."""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
os.environ["XDG_CONFIG_HOME"] = tempfile.mkdtemp()   # isolate key storage
from phosphor.audit import ezrecon as ez

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def test_no_secrets_in_source():
    src = open(os.path.join(os.path.dirname(__file__), "..", "phosphor", "audit", "ezrecon.py")).read()
    # nothing that looks like a real Google/Shodan key is committed
    import re
    ok("no AIza… google key literal", "AIza" not in src)
    ok("no long hex/key literal assigned", not re.search(r'(api_key|API_KEY)\s*=\s*["\'][A-Za-z0-9]{20,}', src))

def test_validation():
    ok("domain valid", ez.is_domain("example.com"))
    ok("domain invalid", not ez.is_domain("nope nope"))
    ok("ip valid", ez.is_ip("8.8.8.8"))

def test_key_prompt_and_persist():
    ez.forget_keys("shodan")
    ok("starts without key", not ez.have_keys("shodan"))
    answers = iter(["ABC123"])
    creds = ez.ensure_keys("shodan", prompt=lambda label: next(answers))
    ok("prompt captured key", creds == {"api_key": "ABC123"})
    ok("key now present", ez.have_keys("shodan"))
    ok("stored file is chmod 600", (os.stat(ez.keys_path()).st_mode & 0o777) == 0o600)

def test_decline_and_nocallback():
    ez.forget_keys("shodan")
    ok("blank prompt aborts (None)", ez.ensure_keys("shodan", prompt=lambda l: "") is None)
    ok("still not stored", not ez.have_keys("shodan"))
    ok("no callback -> None, never blocks", ez.ensure_keys("shodan", prompt=None) is None)

def test_backend_report_and_dispatch():
    rep = ez.backend_report()
    ok("report lists subfinder", any("subfinder" in l for l in rep))
    ok("report gives install hints", any("install:" in l for l in rep))
    ok("shodan without key returns message not crash",
       ez.run("shodan_host", "8.8.8.8", prompt=None)[0].lower().startswith(("no ", "shodan")))
    ok("unknown op handled", ez.run("bogus", "")[0].startswith("unknown"))
    ok("operations catalogue present", len(ez.OPERATIONS) >= 9)

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
