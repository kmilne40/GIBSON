"""Self-contained IND$FILE DFT terminal tests (no GIBSON needed).

Builds the host WSF frames exactly as ft_dft_host does and checks the terminal
replies + reassembly.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from phosphor.protocols.indfile.dft import (IndFileTerminal, WSF_CMD, SF_INDFILE,
    RT_OPEN, ST_OPEN, RT_DATA, ST_DATA, RT_CLOSE, ST_CLOSE, RT_GETREQ, ST_GETREQ,
    REC_DATA, AID_SF)


def _host_sf(rt, st, *records):
    body = bytes([SF_INDFILE, rt, st]) + b"".join(records)
    ln = len(body) + 2
    return bytes([WSF_CMD, (ln >> 8) & 0xFF, ln & 0xFF]) + body


def _rec_data(chunk):
    total = 5 + len(chunk)
    return bytes([REC_DATA, 0x80, 0x61, (total >> 8) & 0xFF, total & 0xFF]) + chunk


def test_download_open_data_close():
    t = IndFileTerminal()
    # OPEN
    r = t.process_frame(_host_sf(RT_OPEN, ST_OPEN))
    assert r[0] == AID_SF and r[4] == 0x00 and r[5] == 0x09
    # DATA
    r = t.process_frame(_host_sf(RT_DATA, ST_DATA, _rec_data(b"HELLO WORLD")))
    assert r[4] == 0x47 and r[5] == 0x05
    # more DATA
    t.process_frame(_host_sf(RT_DATA, ST_DATA, _rec_data(b" AGAIN")))
    # CLOSE
    r = t.process_frame(_host_sf(RT_CLOSE, ST_CLOSE))
    assert r[4] == 0x41 and r[5] == 0x09
    assert bytes(t.download) == b"HELLO WORLD AGAIN" and t.done


def test_upload_getreq_eof():
    payload = b"//JOB\n//STEP EXEC PGM=IEFBR14\n"
    t = IndFileTerminal(upload_data=payload, max_chunk=8)
    t.process_frame(_host_sf(RT_OPEN, ST_OPEN))
    got = bytearray()
    while True:
        r = t.process_frame(_host_sf(RT_GETREQ, ST_GETREQ))
        assert r[4] == 0x46
        if r[5] == 0x08:            # EOF
            break
        # extract the REC_DATA payload from the reply (skip AID+len+D0+cmd+sub)
        body = r[6:]
        # find REC_DATA
        i = 0
        while i < len(body):
            if body[i] == REC_DATA:
                total = (body[i+3] << 8) | body[i+4]
                got += body[i+5:i+total]; i += total
            else:
                ln = body[i+1] or 2; i += ln
    assert bytes(got) == payload


if __name__ == "__main__":
    for fn in [test_download_open_data_close, test_upload_getreq_eof]:
        fn(); print("PASS", fn.__name__)
