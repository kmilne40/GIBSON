"""IND$FILE ASCII-mode regression: text must translate ASCII<->EBCDIC, not ship raw.

Reproduces the "ASCII upload scrambles / uploads as binary" bug and locks the fix:
the wire must be EBCDIC (CP037) records separated by 0x15, so the host's CP037 decode
reconstructs the text instead of garbage.
"""
import os
import socket
import sys
import threading

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.indfile.dft import (text_to_ebcdic, ebcdic_to_text,
                                            IndFileTerminal, EBCDIC_NL)
from phosphor.protocols.tn3270.client import TN3270Client

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

SAMPLE = "IF SUBSYS EQ 'PROD' THEN\n  CALL AUDIT('RACF')\nEND\n"


def test_wire_is_ebcdic_not_raw_ascii():
    wire = text_to_ebcdic(SAMPLE.encode("latin-1"))
    ok("wire is not the raw ASCII bytes", wire != SAMPLE.encode("latin-1"))
    ok("wire uses the EBCDIC newline 0x15 between records", bytes([EBCDIC_NL]) in wire)
    ok("'A' became EBCDIC 0xC1 (translated, not raw 0x41)", b"\xc1" in wire and b"AUDIT" not in wire)
    # the host's storage step is a plain CP037 split/decode
    stored = "\n".join(r.decode("cp037") for r in wire.split(bytes([EBCDIC_NL])))
    ok("host CP037 decode reconstructs the text", stored == SAMPLE.rstrip("\n"))


def test_translation_roundtrip():
    back = ebcdic_to_text(text_to_ebcdic(SAMPLE.encode("latin-1"))).decode("latin-1")
    ok("text -> ebcdic -> text round-trips (content)", back == SAMPLE.rstrip("\n"))


def _read_rec(sock):
    buf = bytearray()
    while True:
        b = sock.recv(1)
        if not b: return b""
        buf += b
        if len(buf) >= 2 and buf[-2] == 0xFF and buf[-1] == 0xEF:
            run = 0; i = len(buf) - 2
            while i >= 0 and buf[i] == 0xFF: run += 1; i -= 1
            if run % 2 == 1: return bytes(buf[:-2]).replace(b"\xff\xff", b"\xff")


def _run_terminal(term_sock, upload=b""):
    c = TN3270Client(); c.sock = term_sock; c.sock.settimeout(5)
    term = IndFileTerminal(upload_data=upload)
    while not term.done:
        frame = c.recv_record()
        if not frame: break
        body = frame[1:] if frame[0] == 0xF3 else frame
        if len(body) < 3 or body[2] != 0xD0: continue
        c.send_record(term.process_frame(frame))
    return term


def test_upload_wire_survives_and_decodes():
    # Prove the translated wire survives the real DFT framing and the host decode.
    try:
        from gibson.net.indfile.ft_dft_host import DftHost, DftChannel
    except Exception:
        ok("gibson host available for interop (skipped)", True); return
    wire = text_to_ebcdic(SAMPLE.encode("latin-1"))
    hs, ts = socket.socketpair(); res = {}
    th = threading.Thread(target=lambda: res.__setitem__("t", _run_terminal(ts, upload=wire)), daemon=True)
    th.start()
    ch = DftChannel(send_bytes=hs.sendall, recv_packet=lambda: _read_rec(hs))
    raw = DftHost(ch, max_chunk=64).put(is_binary=False)
    th.join(5); hs.close(); ts.close()
    stored = "\n".join(r.decode("cp037", "replace") for r in raw.split(b"\x15"))
    ok("uploaded wire survives DFT framing", raw == wire)
    ok("host reconstructs the original text (no scramble)", stored == SAMPLE.rstrip("\n"))


def test_binary_untouched():
    blob = bytes(range(256))
    ok("binary put ships raw bytes (no translation)",
       (lambda d: d)(blob) == blob and text_to_ebcdic != None and blob != text_to_ebcdic(blob))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
            except Exception as e:
                ok(name + " (raised)", False); print("    ", e)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
