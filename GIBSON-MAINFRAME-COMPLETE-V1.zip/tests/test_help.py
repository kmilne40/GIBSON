"""Context-sensitive help selection tests."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.app.help import help_for, KEYS

class S:  # minimal stand-in for AppState
    connected=False; console_open=False; console_title=""; settings_open=False
    notes_open=False; tasks_open=False; ftp_open=False; cicspwn_open=False; focus=None

_p=_f=0
def ok(n,c):
    global _p,_f
    if c: _p+=1; print("  ok  "+n)
    else: _f+=1; print(" FAIL "+n)

def test_context_titles():
    s=S(); ok("start help when idle", "getting started" in help_for(s)[0])
    s=S(); s.connected=True; s.console_open=True; s.console_title="Hydra - h:23"
    ok("hydra context", "Hydra" in help_for(s)[0])
    s.console_title="John + hash-format detector"; ok("john context", "John" in help_for(s)[0])
    s.console_title="PassTicket / credential scan"; ok("passticket context", "PassTicket" in help_for(s)[0])
    s.console_title="CICSpwn"; ok("cicspwn via console", "CICSpwn" in help_for(s)[0])
    s=S(); s.settings_open=True; ok("settings context", "Settings" in help_for(s)[0])
    s=S(); s.notes_open=True; ok("notepad context", "Notepad" in help_for(s)[0])
    s=S(); s.connected=True; s.focus="screen"; ok("screen context", "3270" in help_for(s)[0])

def test_body_and_keys():
    title, body = help_for(S())
    ok("body non-empty", len(body) > 3)
    ok("key reference appended", any("PF1-PF24" in ln for ln in body))


def test_what_it_is_and_recon():
    from phosphor.app.help import _tool_topic
    # every tool topic now opens with a "What it is" definition
    for t in ("hydra - h","john - h","cicspwn - h","api / curl - h","sql / db2 - h","passticket - h"):
        title, body = _tool_topic(t)
        ok(f"{t.split(' ')[0]} defines itself", any("What it is" in ln for ln in body))
    # recon scan titles resolve to the recon topic
    for t in ("vtam - h:23","tso - h:23","cics - h:23","scan_all - h"):
        ok(f"{t.split(' ')[0]} -> recon help", "recon" in _tool_topic(t)[0].lower())

if __name__=="__main__":
    for fn in (test_context_titles, test_body_and_keys, test_what_it_is_and_recon):
        print("\n"+fn.__name__); fn()
    print(f"\nHelp: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
