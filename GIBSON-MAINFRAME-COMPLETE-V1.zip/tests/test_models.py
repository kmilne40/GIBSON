"""3270 terminal model selection (x3270 parity).

Model 2/3/4/5 must set the right screen geometry and terminal-type string, and the
type must reach the telnet TTYPE sub-negotiation the host asks for.
"""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import client as C
from phosphor.protocols.tn3270.telnet import IAC, SB, SE, OPT_TTYPE

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

GEOM = {"2": (24, 80), "3": (32, 80), "4": (43, 80), "5": (27, 132)}


def test_geometry_per_model():
    for m, (rows, cols) in GEOM.items():
        cli = C.client_for_model(m)
        ok(f"model {m} is {rows}x{cols}",
           len(cli.screen.cells) == rows * cols and cli.screen.cols == cols)


def test_device_type_string():
    ok("model 2 -> IBM-3278-2", C.client_for_model("2").neg.device_type == "IBM-3278-2")
    ok("model 5 -> IBM-3278-5", C.client_for_model("5").neg.device_type == "IBM-3278-5")
    ok("extended flag adds -E", C.client_for_model("3", tn3270e=True).neg.device_type == "IBM-3278-3-E")


def test_ttype_subneg_reports_model():
    # the host asks TTYPE SEND; the client must answer with the model's type string
    cli = C.client_for_model("4")
    reply, _, _ = cli.neg.feed(bytes([IAC, SB, OPT_TTYPE, 0x01, IAC, SE]))
    ok("TTYPE IS carries IBM-3278-4", b"IBM-3278-4" in reply)


def test_unknown_model_defaults_to_2():
    cli = C.client_for_model("9")
    ok("unknown model falls back to 24x80 model 2",
       cli.screen.cols == 80 and cli.neg.device_type == "IBM-3278-2")


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
