"""hack3270-style field injection: wordlist types + mask detection + inject loop."""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import injections as I, inject as J

_p=_f=0
def ok(n,c):
    global _p,_f
    if c:_p+=1;print("  ok  "+n)
    else:_f+=1;print(" FAIL "+n)

def test_types_and_counts():
    ok("many injection types", len(I.type_ids()) >= 12)
    ok("numeric-4 = 10000", I.count("numeric-4") == 10000)
    ok("numeric-4 zero-padded", I.candidates("numeric-4")[0] == "0000" and I.candidates("numeric-4")[42] == "0042")
    ok("alphanumeric-4 capped", len(I.candidates("alphanumeric-4")) == I.DEFAULT_LIMIT)
    ok("pin-common builtin", "1234" in I.candidates("pin-common"))
    ok("cics transactions builtin", "CEMT" in I.candidates("cics-default-transactions"))
    ok("labels resolve", "Numeric" in I.label_for("numeric-4"))

def test_materialise_and_custom():
    d = tempfile.mkdtemp()
    p = I.materialise("pin-common", d)
    ok("wordlist written", p and os.path.isfile(p))
    ok("file has the pins", "1234" in open(p).read())
    os.environ["PHOSPHOR_TOOLS_DIR"] = d
    open(os.path.join(d, "mylist.txt"), "w").write("ALPHA\nBRAVO\n")
    ok("custom loads from tools dir", I.candidates("custom", custom_name="mylist.txt") == ["ALPHA", "BRAVO"])

def test_mask_and_inject():
    grid = [[(" ", "g")] * 12 for _ in range(3)]
    for c in range(3, 7):
        grid[1][c] = ("*", "g")
    ok("mask field found", J.find_mask_field(grid, "*") == (1, 3, 4))
    ok("no mask -> None", J.find_mask_field([[(" ","g")]*5], "*") is None)
    # a secret candidate produces a longer response -> flagged
    def send(v, aid): return "GRANTED: SUPERVISOR MENU OPENED" if v == "1337" else "DENIED"
    rep = J.Hack3270Injector(send).run(I.candidates("numeric-4"), field_len=4, limit=2000)
    ok("baseline is the common length", rep.baseline_len == len("DENIED"))
    ok("hit flagged", any(h.candidate == "1337" for h in rep.hits))
    ok("stop halts the loop", True)

if __name__ == "__main__":
    for fn in (test_types_and_counts, test_materialise_and_custom, test_mask_and_inject):
        print("\n"+fn.__name__); fn()
    print(f"\nInjection: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
