"""Editable Host/Port for API/SQL consoles: build_tool_cmd rebuilds from the fields."""
import sys, os, types
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

_p=_f=0
def ok(n,c):
    global _p,_f
    if c:_p+=1;print("  ok  "+n)
    else:_f+=1;print(" FAIL "+n)

def _fake(mode, host, port):
    st = types.SimpleNamespace(console_mode=mode, tool_host=host, tool_port=port,
                               console_cmd="", field_cursor={}, note=lambda *a, **k: None)
    return types.SimpleNamespace(state=st)

def test_build():
    from phosphor.app.__main__ import Client as App
    # API: editing host+port must rebuild the curl command for that target
    fa=_fake("api","10.9.9.9","8443"); App.build_tool_cmd(fa)
    ok("api rebuild uses new host", "10.9.9.9:8443" in fa.state.console_cmd and fa.state.console_cmd.startswith("curl"))
    # SQL: editing host+port rebuilds the ibm_db command
    fs=_fake("sql","db2.corp","5446"); App.build_tool_cmd(fs)
    import base64, re
    _m = re.search(r'b64decode\("([^"]+)"\)', fs.state.console_cmd)
    _body = base64.b64decode(_m.group(1)).decode() if _m else fs.state.console_cmd
    ok("sql rebuild uses new host", "HOSTNAME=db2.corp" in _body and "PORT=5446" in _body)
    # bad port falls back to the default, still builds
    fb=_fake("api","h","abc"); App.build_tool_cmd(fb)
    ok("bad port falls back to 443", ":443/" in fb.state.console_cmd)
    ok("cursor set to end", fs.state.field_cursor.get("console_cmd")==len(fs.state.console_cmd))

if __name__=="__main__":
    print("\ntest_build"); test_build()
    print(f"\nTool host/port: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
