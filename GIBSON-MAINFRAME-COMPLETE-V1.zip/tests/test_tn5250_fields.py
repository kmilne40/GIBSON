"""Regression: 5250 Start-of-Field parsing (output-only vs input fields).

The 5250 SF order is output-only (attribute byte only) OR input (FFW, optional
FCW pairs, attribute, 2-byte length).  Reading a FFW for output fields ate the
first characters of every label and left input fields undetectable - the reason
the PUB400 sign-on could not be driven.  Fields, protection, IC cursor and tab
must all come out right."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn5250 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def SBA(r, c): return bytes([ds.ORD_SBA, r, c])
def SF_out(attr=0x20): return bytes([ds.ORD_SF, attr])
def SF_in(ffw, attr=0x20, length=10): return bytes([ds.ORD_SF, (ffw >> 8) & 0xFF, ffw & 0xFF, attr, (length >> 8) & 0xFF, length & 0xFF])

def _signon():
    s = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x00])
    s += SBA(2, 2) + SF_out(0x20) + "Your user name:".encode("cp037")
    s += SBA(2, 20) + SF_in(0x0000, 0x20, 10) + "          ".encode("cp037")
    s += SBA(4, 2) + SF_out(0x20) + "Password:".encode("cp037")
    s += SBA(4, 20) + SF_in(0x0800, 0x27, 10)
    s += bytes([ds.ORD_IC, 2, 21])
    c = TN3270Client(); c.packets = []
    ds.parse(s, c.screen)
    return c

def test_is_attr():
    ok("0x20 is attr", ds._is_attr(0x20))
    ok("0x3F is attr", ds._is_attr(0x3F))
    ok("0x40 (space) is not attr", not ds._is_attr(0x40))
    ok("0xC1 (A) is not attr", not ds._is_attr(0xC1))

def test_output_labels_not_eaten():
    c = _signon()
    ok("username label intact", "Your user name" in c.screen.row_text(2))
    ok("password label intact", "Password" in c.screen.row_text(4))

def test_input_fields_detected():
    c = _signon()
    ed = FieldEditor(c)
    inp = ed.input_fields()
    ok("two input fields", len(inp) == 2)
    ok("both unprotected", all(not f.protected for f in inp))

def test_labels_protected():
    c = _signon()
    prot = [f for f in c.screen.fields() if f.protected]
    ok("label fields are protected", len(prot) >= 2)

def test_ic_cursor_and_tab():
    c = _signon()
    ed = FieldEditor(c)
    ok("cursor honours IC", ed.cursor == c.screen.rc(c.screen.cursor))
    inp = ed.input_fields()
    ed.cursor = (inp[0].row, inp[0].col)
    ed.tab()
    ok("tab user -> pass", ed.cursor == (inp[1].row, inp[1].col))

def test_bypass_bit_protects():
    # an input field with the BYPASS bit set must be protected
    s = bytes([ds.ESC, ds.CMD_WTD, 0, 0]) + SBA(2, 2) + SF_in(0x2000, 0x20, 5)
    c = TN3270Client(); c.packets = []
    ds.parse(s, c.screen)
    f = [x for x in c.screen.fields()]
    ok("BYPASS field is protected", f and f[0].protected)

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
