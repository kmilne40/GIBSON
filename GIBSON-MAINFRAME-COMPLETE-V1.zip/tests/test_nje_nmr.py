"""NJE NMR operator-command records.

The golden vectors were validated byte-for-byte against Soldier of Fortran's njelib
(the reference iNJEctor library, SCB compression + TTB/TTR framing). If the framing
or compression drifts these catch it. Also round-trips SCB compress/parse and checks
the NMR payload structure.
"""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import nje as N

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

# (rhost, ohost, command) -> exact on-the-wire NMR record (validated vs njelib)
GOLDEN = [
    ("FAKE", "GIBSON", "$D NODE",
     "0000003700000000000000271002808fcf9a00ca90770007c7c9c2e2d6d582c102a800c4c6c1d2c584c8015bc440d5d6c4c50000000000"),
    ("MYNODE", "POK", "$D NJEDEF",
     "0000003800000000000000281002808fcf9a00c790770009d7d6d285c102a800c6d4e8d5d6c4c582ca015bc440d5d1c5c4c5c60000000000"),
    ("A", "B", "$DU,LNES",
     "0000003000000000000000201002808fcf9a00c590770008c287c102a800c1c187c9015bc4e46bd3d5c5e20000000000"),
]


def test_golden_nmr_matches_njelib():
    for rh, oh, cmd, expect in GOLDEN:
        got = N.build_nmr(rh, oh, cmd).hex()
        ok(f"NMR '{cmd}' matches njelib", got == expect)


def test_scb_roundtrip_shapes():
    # SCB output ends with a 0x00 terminator and is never longer than input+overhead
    comp, rem = N.make_scb(b"HELLO WORLD")
    ok("SCB emits a terminator", comp.endswith(b"\x00"))
    ok("SCB consumes the buffer", rem == 0)
    # a run of spaces compresses (0x80|count)
    comp2, _ = N.make_scb(b"\x40" * 10)
    ok("space run compresses to one control byte + terminator", len(comp2) <= 3)


def test_ttb_ttr_framing():
    body = b"ABCDEF"
    ttb = N.make_ttb(body)
    ok("TTB length field = len(data)+12", ttb[2] << 8 | ttb[3] == len(body) + 12)
    ok("TTB starts 00 00", ttb[:2] == b"\x00\x00")
    ttr = N.calc_ttr(body)
    ok("TTR carries the segment length", ttr[2] << 8 | ttr[3] == len(body))


def test_nmr_carries_command_and_nodes():
    rec = N.build_nmr("FAKE", "GIBSON", "$D NODE")
    # the command text is present in EBCDIC ($=0x5B D=0xC4 space=0x40 N=0xD5 ...)
    ok("command in EBCDIC present", bytes.fromhex("5bc440d5d6c4c5") in rec)
    ok("RCB is NMR (0x9A)", N.RCB_NMR == 0x9A)
    ok("record is TTB-framed (ends 00000000)", rec.endswith(b"\x00\x00\x00\x00"))


def test_sequence_increment():
    ok("sequence stays in the 0x8x band", N.next_sequence(0x80) == 0x81)
    ok("sequence wraps low nibble", N.next_sequence(0x8F) & 0x80 == 0x80)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
