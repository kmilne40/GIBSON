"""5250 data-stream round-trip tests (no host needed)."""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from phosphor.core.screen import ScreenBuffer
from phosphor.protocols.tn5250 import datastream as ds


def _screen():
    return ScreenBuffer(24, 80)


def test_wtd_renders_text_rows():
    rows = ["  Sign On", "", "  User . . . . . :", "  Password . . . :"]
    stream = ds.build_wtd(rows, cursor_rc=(3, 20))
    sc = _screen()
    ds.parse(stream, sc)
    out = sc.to_rows()
    assert out[0].strip() == "Sign On"
    assert "User" in out[2]
    assert "Password" in out[3]


def test_clear_unit_resets_screen():
    sc = _screen()
    ds.parse(ds.build_wtd(["HELLO"]), sc)
    assert "HELLO" in sc.text()
    ds.parse(bytes([ds.ESC, ds.CMD_CLEAR_UNIT]), sc)
    assert sc.text().strip() == ""


def test_sba_positions_text():
    # place "ABC" at row 5 col 10 directly
    body = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x00, ds.ORD_SBA, 5, 10]) + ds.a2e("ABC")
    sc = _screen()
    ds.parse(body, sc)
    assert sc.row_text(5)[9:12] == "ABC"


def test_repeat_to_address_fills():
    # RA fill '*' from row1col1 to row1col10
    body = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x00, ds.ORD_SBA, 1, 1,
                  ds.ORD_RA, 1, 10]) + ds.a2e("*")
    sc = _screen()
    ds.parse(body, sc)
    assert sc.row_text(1)[:9] == "*" * 9


def test_start_of_field_protect_flag():
    # SF with FFW protect bit set -> a protected field-start cell
    ffw = 0x2000
    body = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x00, ds.ORD_SBA, 2, 1,
                  ds.ORD_SF, (ffw >> 8) & 0xFF, ffw & 0xFF])
    sc = _screen()
    ds.parse(body, sc)
    cell = sc.cells[sc.addr(2, 1)]
    assert cell.is_field_start and cell.protected


def test_ic_sets_cursor():
    body = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x00, ds.ORD_IC, 7, 15])
    sc = _screen()
    ds.parse(body, sc)
    assert sc.rc(sc.cursor) == (7, 15)


def test_build_inbound_has_cursor_and_aid():
    sc = _screen()
    sc.cursor = sc.addr(3, 20)
    frame = ds.build_inbound(sc, "ENTER", [(sc.addr(3, 20), "IBMUSER")])
    assert frame[0] == 3 and frame[1] == 20          # cursor row/col
    assert frame[2] == ds.AID["ENTER"]
    assert ds.ORD_SBA in frame                        # a typed field followed


def test_ebcdic_roundtrip():
    assert ds.e2a(ds.a2e("Q")[0]) == "Q"
    assert ds.a2e("A") == b"\xc1"                     # EBCDIC 'A'


def test_tolerant_of_garbage():
    # random non-ESC bytes must not raise and must leave a usable screen
    ds.parse(bytes(range(256)) * 3, _screen())


def test_gds_roundtrip_and_input():
    """RFC1205 GDS wrap/unwrap + field input path (the PUB400 no-input fix)."""
    from phosphor.protocols.tn5250 import datastream as ds
    from phosphor.protocols.tn5250.client import TN5250Client
    from phosphor.protocols.tn3270.fields import FieldEditor
    # A well-formed 5250 WTD: an output label ("User:") written with an
    # attribute-only SF, then an INPUT field written with a Field Format Word,
    # attribute and an explicit 2-byte length (FFW=0x4000, attr=0x20, len=7).
    raw  = bytes([0x04,0x11,0x00,0x00])
    raw += bytes([0x11,2,2,  0x1D,0x20]) + 'User:'.encode('cp037')          # SF(out) + label
    raw += bytes([0x11,2,10, 0x1D,0x40,0x00,0x20,0x00,0x07])                # SF(in) FFW attr len=7
    raw += bytes([0x13,2,11])                                               # IC at the input body
    wire = ds.gds_wrap(raw)
    assert wire[2:4]==b'\x12\xa0'
    assert ds.gds_unwrap(wire)==raw
    c=TN5250Client(); c.packets=[]
    ds.parse(ds.gds_unwrap(wire), c.screen)
    inp=[f for f in c.screen.fields() if not f.protected]
    assert inp, "5250 input field must be detected"
    ed=FieldEditor(c); f=inp[0]; ed.click(f.row,f.col)
    for ch in 'IBMUSER': ed.type_char(ch)
    ed._flush()
    out=ds.gds_wrap(ds.build_inbound(c.screen,'ENTER',c._pending))
    assert 'IBMUSER'.encode('cp037') in out


def test_5250_positioning():
    """SBA lands text at the right row/col; WEA/EA don't scatter following text."""
    from phosphor.protocols.tn5250 import datastream as ds
    from phosphor.core.screen import ScreenBuffer
    def rowtext(scr, r):
        return ''.join(c.char for c in scr.cells[(r-1)*80:(r-1)*80+80]).rstrip()
    s = ScreenBuffer(24, 80)
    ds.parse(bytes([0x04,0x11,0,0]) + bytes([0x11,5,10]) + 'HELLO'.encode('cp037'), s)
    assert rowtext(s, 5).find('HELLO') == 9, "SBA must place text at col 10"
    s2 = ScreenBuffer(24, 80)
    ds.parse(bytes([0x04,0x11,0,0]) + bytes([0x11,3,1]) + bytes([0x12,0,0x28]) + 'ABC'.encode('cp037'), s2)
    assert rowtext(s2, 3) == 'ABC', "WEA must not scatter following text"


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)
    print("all passed")
