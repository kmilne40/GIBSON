"""Tests for the hash-format detector and native RACF DES verifier."""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import hashid as H
from phosphor.toolchain import racf_des as R

_p=_f=0
def ok(n,c):
    global _p,_f
    if c: _p+=1; print("  ok  "+n)
    else: _f+=1; print(" FAIL "+n)

def test_classify():
    ok("md5crypt detected", H.classify("$1$abc$def")[0]=="md5crypt")
    ok("racf des detected", H.classify("$racf$*DUMONT*80CC5B1FCD06623B")[0]=="racf-des")
    ok("racf empty detected", H.classify("$racf$*BOB*0000000000000000")[0]=="racf-empty")
    ok("sha512crypt detected", H.classify("$6$salt$hash")[0]=="sha512crypt")
    ok("bcrypt detected", H.classify("$2b$10$abcdefg")[0]=="bcrypt")

def test_report_counts():
    text = ("A:$racf$*A*0000000000000000\nB:$racf$*B*80CC5B1FCD06623B\n"
            "C:$racf$*C*038C0B3248CD1D8E\n")
    rep = H.analyse(text)
    ok("2 crackable", rep.crackable==2)
    ok("1 empty", rep.empty==1)
    ok("suggests racf format", rep.suggested_formats()==["racf"])

def test_mixed_warning():
    rep = H.analyse("A:$1$x$y\nB:$racf$*B*80CC5B1FCD06623B\n")
    w = " ".join(rep.warnings())
    ok("mixed-format warned", "MIXED" in w)
    ok("md5-vs-racf warned", "different systems" in w)

def test_native_racf_des():
    ok("crypto available", R.crypto_available())
    h = R.racf_des_hash("KEVIN","SECRET")
    ok("deterministic 16-hex", len(h)==16)
    ok("case folded (lowercase matches)", R.verify("KEVIN","secret",h))
    ok("truncates to 8 chars", R.verify("KEVIN","PASSWORD99", R.racf_des_hash("KEVIN","PASSWORD")))
    ok("wrong password rejected", not R.verify("KEVIN","NOPE",h))
    ok("empty hash never cracks", R.crack_one("BOB","0000000000000000",["x","y"]) is None)

def test_crack_one():
    h = R.racf_des_hash("SARCHER","ARCHER1")
    ok("finds planted password", R.crack_one("SARCHER",h,["nope","archer1","x"])=="archer1")

if __name__=="__main__":
    for fn in (test_classify,test_report_counts,test_mixed_warning,test_native_racf_des,test_crack_one):
        print("\n"+fn.__name__); fn()
    print(f"\nHashID + RACF-DES: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
