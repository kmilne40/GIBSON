"""The smoke-test harness is an operational tool; this just guards it against rot -
it imports, exposes the expected checks, and its arg parser accepts the documented flags.
"""
import os, sys, importlib.util
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

spec = importlib.util.spec_from_file_location(
    "smoketest", os.path.join(os.path.dirname(__file__), "..", "tools", "smoketest.py"))
sm = importlib.util.module_from_spec(spec); spec.loader.exec_module(sm)


def test_checks_present():
    for fn in ("check_tn3270", "check_tls", "check_tn5250", "check_nje",
               "check_drda", "check_ptkt", "main"):
        ok(f"{fn} defined", hasattr(sm, fn) and callable(getattr(sm, fn)))


def test_safe_types_are_the_validated_ones():
    ok("FD:OCA safe types = CHAR/VARCHAR/SMALLINT/INTEGER",
       sm._SAFE_TYPES == {448, 452, 500, 496})


def test_ptkt_offline_runs():
    # offline PassTicket check needs no host and should PASS
    import argparse
    a = argparse.Namespace(ptkt="IBMUSER:CICSPA01:E001193519561977")
    sm._results.clear()
    sm.check_ptkt(a)
    ok("offline PassTicket check passes", sm._results == ["PASS"])


def test_ptkt_bad_format_fails_cleanly():
    import argparse
    a = argparse.Namespace(ptkt="not-a-valid-spec")
    sm._results.clear()
    sm.check_ptkt(a)
    ok("bad ptkt spec -> FAIL (no crash)", sm._results == ["FAIL"])


def test_config_batch_parsing():
    # a config file drives per-suite host/port/creds for batch mode
    import tempfile, argparse, copy
    conf = tempfile.NamedTemporaryFile("w", suffix=".conf", delete=False)
    conf.write("[default]\nhost = 10.0.0.9\ntimeout = 5\n"
               "[drda]\nport = 50000\nuser = IBMUSER\npass = SYS1\nrdb = LOC\n"
               "[nje]\nport = 175\nnodes = A,B\nsignon = A:B:pw\n")
    conf.close()
    cfg = sm._load_config(conf.name)
    ok("config sections parsed", set(cfg) == {"default", "drda", "nje"})
    base = argparse.Namespace(host=None, port=0, timeout=8.0, tls=False, starttls=False,
                              no_verify=False, model="2", user=None, pw=None, rdb=None,
                              sql=None, nje_nodes=None, nje_rhost=None, nje_signon=None,
                              nje_cmd=None, nje_submit=None, ptkt=None)
    d = sm._suite_args(base, cfg, "drda", 446)
    ok("drda suite takes its own port", d.port == 50000)
    ok("drda suite inherits default host", d.host == "10.0.0.9")
    ok("drda creds mapped (pass->pw)", d.user == "IBMUSER" and d.pw == "SYS1")
    n = sm._suite_args(base, cfg, "nje", 175)
    ok("nje nodes/signon mapped", n.nje_nodes == "A,B" and n.nje_signon == "A:B:pw")
    os.unlink(conf.name)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
