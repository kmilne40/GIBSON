"""Regression: TN5250 / IBM i (PUB400) telnet negotiation + inbound framing.

Two fixes are covered:
  * the telnet negotiator completes an IBM i handshake (NEW-ENVIRON answered with
    WONT, SGA agreed, BINARY+EOR both ways, terminal type sent);
  * the client sends the RAW cursor+AID+fields frame (IAC EOR framed) in basic
    5250 mode instead of GDS-wrapping it - wrapping in basic mode is why PUB400
    silently ignored keystrokes.  Enhanced mode still wraps.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270.telnet import (Negotiator, IAC, DO, WILL, WONT, SB, SE,
    OPT_BINARY, OPT_EOR, OPT_TTYPE, OPT_SGA, OPT_NEWENV)
from phosphor.protocols.tn5250 import datastream as ds
from phosphor.protocols.tn5250.client import TN5250Client

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def _ibm_i_handshake():
    neg = Negotiator(device_type="IBM-3179-2", allow_tn3270e=False)
    server = bytes([IAC, DO, OPT_NEWENV, IAC, DO, OPT_TTYPE,
                    IAC, WILL, OPT_EOR, IAC, DO, OPT_EOR,
                    IAC, WILL, OPT_BINARY, IAC, DO, OPT_BINARY,
                    IAC, DO, OPT_SGA, IAC, WILL, OPT_SGA])
    reply = neg.feed(server)[0]
    reply2 = neg.feed(bytes([IAC, SB, OPT_TTYPE, 0x01, IAC, SE]))[0]
    return neg, reply, reply2

def test_handshake_completes():
    neg, reply, reply2 = _ibm_i_handshake()
    ok("WONT NEW-ENVIRON", bytes([IAC, WONT, OPT_NEWENV]) in reply)
    ok("EOR agreed both ways",
       bytes([IAC, DO, OPT_EOR]) in reply and bytes([IAC, WILL, OPT_EOR]) in reply)
    ok("BINARY agreed both ways",
       bytes([IAC, DO, OPT_BINARY]) in reply and bytes([IAC, WILL, OPT_BINARY]) in reply)
    ok("SGA agreed both ways",
       bytes([IAC, WILL, OPT_SGA]) in reply and bytes([IAC, DO, OPT_SGA]) in reply)
    ok("terminal type sent", b"IBM-3179-2" in reply2)
    ok("negotiator reports ready", neg.ready())

class _Cap(TN5250Client):
    def __init__(self):
        super().__init__(); self.packets = []; self.sent = b""
    def _send(self, d): self.sent += d
    def _read_until_eor(self): pass

def test_basic_mode_frame_is_raw():
    c = _Cap(); c.move_to(2, 5); c.send_string("HELLO"); c.enhanced = False
    c._aid("ENTER")
    ok("frame ends with IAC EOR", c.sent.endswith(b"\xff\xef"))
    ok("frame is NOT GDS-wrapped in basic mode", c.sent[2:4] != ds.GDS_RECORD_TYPE)

def test_enhanced_mode_frame_is_wrapped():
    c = _Cap(); c.move_to(1, 1); c.send_string("X"); c.enhanced = True
    c._aid("ENTER")
    ok("frame IS GDS-wrapped in enhanced mode", c.sent[2:4] == ds.GDS_RECORD_TYPE)

def test_iac_byte_stuffing():
    payload = bytes([0x01, 0xFF, 0x02, 0xFF])
    stuffed = payload.replace(b"\xff", b"\xff\xff") + b"\xff\xef"
    ok("every data 0xFF doubled", stuffed[:-2].count(b"\xff") == 4)
    ok("terminator is a single IAC EOR", stuffed.endswith(b"\xff\xef"))

def test_enhanced_autodetect_from_header():
    # a record carrying the 0x12A0 GDS record type flips the client into enhanced
    c = _Cap()
    rec = ds.gds_wrap(bytes([ds.ESC, ds.CMD_CLEAR_UNIT]))
    c._buf = bytearray(rec)
    c._apply_screen()
    ok("client detects TN5250E from header", c.enhanced is True)

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
