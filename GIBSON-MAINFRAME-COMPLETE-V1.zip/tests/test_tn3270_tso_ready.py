"""Native TN3270 zPDT / TSO READY command entry.

Built from a real zPDT capture (tn3270.pcap). The TSO READY screen is a formatted
buffer whose command area is one unprotected field that runs from just after the
"READY " label all the way down the screen - a field that spans every row. The
host sets the Insert-Cursor there.

The fault this locks down: field membership used to be tested per-row
(f.row == row), so a multi-row field was only ever found on its first row. The
cursor could not be recognised inside the big command field, so it snapped back to
the first tiny field at top-left, and typing was clipped to that field's width -
the "only 6 characters / cursor stuck top-left" report. "LISTCAT" came out as a
6-char, transposed "LSITCT" landing on the READY label.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def _A(r, c):
    """1-based-free helper: enc_addr for a 0-based (row,col)."""
    return ds.enc_addr(r * 80 + c)


def _ready_screen(client):
    """Exact rec#23 from the capture:
    EW SBA(23,79) SF(0x40) SBA(0,0) SF(0xc8) SBA(0,1) 'READY ' SF(0x40) IC
       SBA(1,0) IC
    """
    s = bytes([ds.CMD_EW, 0xc1])
    s += bytes([ds.SBA]) + _A(23, 79) + bytes([ds.SF, 0x40])
    s += bytes([ds.SBA]) + _A(0, 0) + bytes([ds.SF, 0xc8])
    s += bytes([ds.SBA]) + _A(0, 1) + "READY ".encode("cp037") + bytes([ds.SF, 0x40, ds.IC])
    s += bytes([ds.SBA]) + _A(1, 0) + bytes([ds.IC])
    ds.DataStreamParser(client.screen).parse(s)


class FakeSock:
    """Minimal socket: captures everything sent, feeds a canned host reply."""
    def __init__(self, reply=b""):
        self.sent = bytearray()
        self._reply = bytearray(reply)
    def sendall(self, data): self.sent += data
    def recv(self, n):
        if not self._reply:
            return b""
        out = bytes(self._reply[:n]); del self._reply[:n]; return out
    def settimeout(self, *_): pass
    def close(self): pass


def test_ic_honoured_into_multirow_field():
    c = TN3270Client(); c.packets = []
    _ready_screen(c)
    # parser placed the host IC at (2,1) 1-based == 0-based (1,0)
    ok("host IC parsed at (2,1)", c.screen.rc(c.screen.cursor) == (2, 1))
    ed = FieldEditor(c)
    # the editor must honour that IC and sit inside the big command field, NOT snap
    # to the top-left READY label
    ok("editor cursor honours IC (not top-left)", ed.cursor == (2, 1))
    f = ed._field_at(*ed.cursor)
    ok("cursor resolves to a real input field", f is not None and not f.protected)
    ok("that field spans many rows", f is not None and f.length > 80)


def test_field_at_matches_multirow():
    c = TN3270Client(); c.packets = []
    _ready_screen(c)
    ed = FieldEditor(c)
    # the command field starts at (1,9) 1-based and must be found on later rows too
    ok("found on its start row", ed._field_at(1, 9) is not None)
    ok("found five rows down", ed._field_at(6, 40) is not None)
    ok("found near the bottom", ed._field_at(20, 10) is not None)
    # the 6-wide READY label is a separate field
    lbl = ed._field_at(1, 3)
    ok("READY label is its own 6-wide field", lbl is not None and lbl.length == 6)


def test_full_command_not_clipped():
    c = TN3270Client(); c.packets = []
    _ready_screen(c); ed = FieldEditor(c)
    for ch in "LISTCAT":
        ed.type_char(ch)
    vals = list(ed._edits.values())
    ok("LISTCAT typed in full (7 chars, no 6-char clip)", vals[0].strip() == "LISTCAT")
    # it lands in the command field body (the field starting after 'READY '),
    # keyed at (1,9) 1-based, not on the label
    ok("command lands in the command field, not the label", list(ed._edits.keys()) == [(1, 9)])

    c2 = TN3270Client(); c2.packets = []
    _ready_screen(c2); ed2 = FieldEditor(c2)
    long = "LISTCAT ENTRIES('SYS1.PARMLIB') ALL"
    for ch in long:
        ed2.type_char(ch)
    ok("long command typed in full", list(ed2._edits.values())[0].strip() == long)


def test_enter_sends_full_command_inbound():
    c = TN3270Client(); c.packets = []
    c.sock = FakeSock(reply=b"")            # enter() will try to read; empty is fine
    _ready_screen(c); ed = FieldEditor(c)
    for ch in "LISTCAT":
        ed.type_char(ch)
    ed.enter()
    sent = bytes(c.sock.sent)
    # strip telnet EOR
    body = sent.split(b"\xff\xef")[0]
    ok("inbound AID is ENTER", body[0] == 0x7d)
    ok("inbound carries LISTCAT in EBCDIC", "LISTCAT".encode("cp037") in body)
    # and it is addressed to the command field (0,8) 0-based, not the (0,1) label
    label_sba = bytes([0x11]) + _A(0, 1)
    ok("inbound is NOT addressed to the READY label", label_sba not in body)


def test_logon_userid_respects_host_cursor():
    # line-mode IKJ56700A ENTER USERID: the host sets the cursor on the line below
    # the prompt, and a real terminal types there.  The value must be complete (not
    # clipped) and the cursor must NOT jump up to the label row.
    c = TN3270Client(); c.packets = []
    s = bytes([ds.CMD_W, 0xc2]) + bytes([ds.SBA]) + _A(0, 0) + bytes([ds.SF, 0xc8])
    s += "IKJ56700A ENTER USERID -".encode("cp037") + bytes([ds.SF, 0x40])
    s += bytes([ds.SBA]) + _A(1, 0) + bytes([ds.IC])
    ds.DataStreamParser(c.screen).parse(s)
    ed = FieldEditor(c)
    start_row = ed.cursor[0]
    for ch in "IBMUSER":
        ed.type_char(ch)
    val = list(ed._edits.values())[0]
    ok("userid types in full (7 chars, not clipped)", val.strip() == "IBMUSER")
    ok("cursor did not jump up to the label row", ed.cursor[0] == start_row)


def test_cursor_stays_below_ready_when_typing():
    # the host sets the cursor on the line BELOW "READY " (its final IC).  Typing
    # must happen there, the way a real terminal does - it must NOT snap up to the
    # field start on the READY line (the reported "cursor jumps to the line above").
    c = TN3270Client(); c.packets = []
    _ready_screen(c)
    ed = FieldEditor(c)
    below_row = ed.cursor[0]
    ok("cursor starts below READY", below_row == 2)     # 1-based row 2 == 0-based (1,0)
    ed.type_char("L")
    ok("cursor stays on the line below after first keystroke", ed.cursor[0] == below_row)
    ed.type_char("G")
    ok("cursor keeps advancing on the same line", ed.cursor[0] == below_row)
    key = list(ed._edits.keys())[0]
    ok("edit belongs to the command field body, not the READY label", key == (1, 9))
    ok("typed text present and complete", ed._edits[key].strip() == "LG")


def test_manual_move_still_left_justifies():
    # if the OPERATOR arrows/clicks into a blank field (no host cursor), the first
    # keystroke should still left-justify to the field start - the snap must remain
    # for that case.
    c = TN3270Client(); c.packets = []
    _ready_screen(c)
    ed = FieldEditor(c)
    ed.move(0, 5)                       # operator nudges the cursor (clears host flag)
    ed.type_char("X")
    key = list(ed._edits.keys())[0]
    ok("manual move then type still snaps to field start", ed._edits[key].startswith("X"))


def test_protected_label_still_rejects_typing():
    # a genuinely protected label (0xe8) must not accept characters
    c = TN3270Client(); c.packets = []
    s = bytes([ds.CMD_EW, 0xc1]) + bytes([ds.SBA]) + _A(0, 0) + bytes([ds.SF, 0xe8])
    s += "PROTECTED".encode("cp037")
    s += bytes([ds.SBA]) + _A(5, 0) + bytes([ds.SF, 0x40]) + bytes([ds.IC])
    ds.DataStreamParser(c.screen).parse(s)
    ed = FieldEditor(c)
    ed.cursor = (1, 3)                       # force cursor onto the protected label
    before = dict(ed._edits)
    for ch in "XXX":
        ed.type_char(ch)
    ok("typing into a protected label is rejected", ed._edits == before)
    # the label field itself is marked protected on the screen
    lbl = [f for f in c.screen.fields() if f.row == 1][0]
    ok("protected label is marked protected", lbl.protected)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
