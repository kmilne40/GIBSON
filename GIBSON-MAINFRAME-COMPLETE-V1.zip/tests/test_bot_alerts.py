"""Alert-transport tests - injected senders, no real network or SMTP."""
import io
import json
import os
import sys
from contextlib import redirect_stdout

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.bot import Bot, Job
from phosphor.bot.alerts import (console_alerter, webhook_alerter, email_alerter,
                                 combine, format_result)

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


class _Result:
    """Stand-in for RunResult with the fields alerters read."""
    def __init__(self, ok_=False, job="probe", attempts=3, error="MacroTimeout: x", steps=5):
        self.ok = ok_; self.job = job; self.attempts = attempts
        self.error = error; self.steps = steps; self.duration = 1.23
    def to_dict(self):
        return {"job": self.job, "ok": self.ok, "attempts": self.attempts,
                "duration": self.duration, "error": self.error, "steps": self.steps}


def test_format_result():
    s = format_result(_Result(ok_=False))
    ok("format includes job, FAILED and error", "probe" in s and "FAILED" in s and "MacroTimeout" in s)


def test_console_alerter():
    buf = io.StringIO()
    with redirect_stdout(buf):
        console_alerter("[X]")(_Result(ok_=True, error=None))
    ok("console prints prefixed line", "[X]" in buf.getvalue() and "OK" in buf.getvalue())


def test_webhook_alerter():
    seen = {}
    def poster(url, body, headers):
        seen["url"] = url; seen["body"] = json.loads(body.decode()); seen["headers"] = headers
    webhook_alerter("https://hook.test/x", poster=poster)(_Result(ok_=False))
    ok("webhook posts to the url", seen.get("url") == "https://hook.test/x")
    ok("webhook body carries job + error + message",
       seen["body"]["job"] == "probe" and "MacroTimeout" in seen["body"]["error"]
       and "FAILED" in seen["body"]["message"])
    ok("webhook sets JSON content-type", seen["headers"].get("Content-Type") == "application/json")


def test_webhook_swallows_errors():
    def boom(*a): raise OSError("network down")
    buf = io.StringIO()
    with redirect_stdout(buf):
        webhook_alerter("u", poster=boom)(_Result())    # must not raise
    ok("webhook failure is caught, not raised", "webhook alert failed" in buf.getvalue())


class FakeSMTP:
    instances = []
    def __init__(self, host, port):
        self.host = host; self.port = port; self.calls = []
        FakeSMTP.instances.append(self)
    def starttls(self): self.calls.append("starttls")
    def login(self, u, p): self.calls.append(("login", u))
    def sendmail(self, frm, to, msg): self.calls.append(("sendmail", frm, tuple(to), msg))
    def quit(self): self.calls.append("quit")


def test_email_alerter():
    FakeSMTP.instances = []
    alert = email_alerter("soc@example.com", host="smtp.test", port=587,
                          user="bot@test", password="pw", sender="bot@test",
                          smtp_factory=FakeSMTP)
    alert(_Result(ok_=False))
    srv = FakeSMTP.instances[-1]
    names = [c if isinstance(c, str) else c[0] for c in srv.calls]
    ok("email connected to configured host", srv.host == "smtp.test" and srv.port == 587)
    ok("email did starttls + login + sendmail + quit",
       "starttls" in names and "login" in names and "sendmail" in names and "quit" in names)
    sm = [c for c in srv.calls if c[0] == "sendmail"][0]
    ok("email addressed to recipient", sm[2] == ("soc@example.com",))
    ok("email subject shows FAILED", b"FAILED" in sm[3])


def test_email_skips_without_host(monkeyenv=None):
    # ensure no env host leaks in
    for k in ("PHOSPHOR_SMTP_HOST",):
        os.environ.pop(k, None)
    buf = io.StringIO()
    with redirect_stdout(buf):
        email_alerter("a@b.c", host=None)(_Result(ok_=False))
    ok("email skipped cleanly when no SMTP host", "skipped" in buf.getvalue())


def test_combine_fans_out():
    hits = []
    a = lambda r: hits.append("a")
    b = lambda r: hits.append("b")
    combine(a, b)(_Result())
    ok("combine calls all alerters", hits == ["a", "b"])


def test_integration_failing_job_fires_webhook():
    fired = {}
    def poster(url, body, headers): fired["body"] = json.loads(body.decode())
    notify = webhook_alerter("https://hook.test/x", poster=poster)
    class FakeClient:
        def connect(self, *a, **k): pass
        def terminate(self): pass
        def screen_get(self): return [""]
    bot = Bot(client_factory=FakeClient)
    def always_fail(engine): raise RuntimeError("boom")
    bot.add_job(Job("j", always_fail, max_retries=1, retry_backoff=0.0, on_failure=notify))
    bot.run(max_runs=1)
    ok("failing job fired the webhook with the error",
       fired.get("body", {}).get("job") == "j" and "boom" in fired["body"].get("error", ""))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
