"""Tests for PassTicket parsing / capture scanning.

Run: python3 tests/test_passticket.py
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from phosphor.toolchain import passticket as pt

_p = _f = 0
def ok(name, cond):
    global _p, _f
    if cond: _p += 1; print("  ok  " + name)
    else: _f += 1; print(" FAIL " + name)


def test_classification():
    ok("PassTicket-shaped detected", pt.classify_credential("N4K7QP2M")[0] == "passticket")
    ok("another PassTicket", pt.classify_credential("4F9XKD1A")[0] == "passticket")
    ok("common word is password", pt.classify_credential("PASSWORD")[0] == "password")
    ok("short string is password", pt.classify_credential("SYS1")[0] == "password")
    ok("long string is phrase", pt.classify_credential("MyLongPassPhrase123")[0] == "phrase")
    ok("lowercase in-alphabet still detected", pt.looks_like_passticket("n4k7qp2m"))


def test_analyse():
    info = pt.analyse("N4K7QP2M")
    ok("kind is passticket", info.kind == "passticket")
    ok("length 8", info.length == 8)
    ok("alphabet valid", info.alphabet_valid)
    ok("counts letters+digits", info.letters == 5 and info.digits == 3 and info.distinct == 8)
    ok("carries assessment notes", any("single-use" in n.lower() for n in info.notes))


def test_scan_capture():
    def e(s): return s.encode("cp037")     # EBCDIC, as it appears on the wire
    packets = [("OUT", e("IBMUSER")), ("OUT", e("N4K7QP2M")), ("IN", e("READY TSO"))]
    fields = pt.scan_capture(packets)
    kinds = {f.text: f.kind for f in fields}
    ok("userid seen as password-shaped", kinds.get("IBMUSER") == "password")
    ok("passticket flagged in capture", kinds.get("N4K7QP2M") == "passticket")
    rep = pt.format_report(fields)
    ok("report summarises PassTicket count", "PassTicket-shaped" in rep)
    ok("empty capture handled", "no candidate" in pt.format_report(pt.scan_capture([])))


if __name__ == "__main__":
    for fn in (test_classification, test_analyse, test_scan_capture):
        print("\n" + fn.__name__); fn()
    print(f"\nPassTicket suite: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
