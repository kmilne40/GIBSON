"""Regression: apply EVERY record in a host response, not just the first.

TSO/ISPF frequently answer one Enter with several 3270 records (a message write,
then the real screen).  PHOSPHOR used to render only the first and discard the
rest, so the user was one screen behind and had to press Enter again.  feed() now
splits at EOR boundaries and the client applies each record in order."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def _rec(text):
    return bytes([ds.CMD_EW, 0xC0]) + bytes([ds.SBA]) + ds.enc_addr(0) + text.encode("cp037")

def test_feed_splits_records():
    c = TN3270Client(); c.packets = []
    chunk = _rec("A") + b"\xff\xef" + _rec("B") + b"\xff\xef"
    _reply, segs, eor = c.neg.feed(chunk)
    ok("EOR seen", eor)
    ok("two records split out (+empty tail)", len(segs) == 3)

def test_last_record_wins():
    c = TN3270Client(); c.packets = []
    chunk = _rec("NO BROADCAST MESSAGES") + b"\xff\xef" + _rec("ISPF MENU") + b"\xff\xef"
    _r, segs, _e = c.neg.feed(chunk)
    c._consume(segs)
    ok("final screen is the last record, not the first", "ISPF MENU" in c.screen.row_text(1))

def test_partial_record_across_chunks():
    c = TN3270Client(); c.packets = []
    full = _rec("ALPHA") + b"\xff\xef" + _rec("FINAL") + b"\xff\xef"
    mid = len(_rec("ALPHA")) + 2 + 6                 # cut inside the 2nd record
    c._consume(c.neg.feed(full[:mid])[1])
    c._consume(c.neg.feed(full[mid:])[1])
    ok("record split across TCP segments reconstructs", "FINAL" in c.screen.row_text(1))

def test_single_record_still_works():
    c = TN3270Client(); c.packets = []
    c._consume(c.neg.feed(_rec("ONLY") + b"\xff\xef")[1])
    ok("single record applied", "ONLY" in c.screen.row_text(1))

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
