"""zSecure ISPF front-end: SE/RA/AU/EV/RE/CO/CM navigation + interactive CARLa panel."""
import tempfile, pathlib, sys
sys.path.insert(0, "tests")
from parity_harness import make_session
from gibson.apps.zsecure3270 import Zsecure3270Session
from gibson.render.panels import PanelInput


def _z():
    st = make_session(pathlib.Path(tempfile.mkdtemp())).state
    return Zsecure3270Session(st, "IBMUSER")


def P(key="ENTER", **f):
    return PanelInput(aid=0, key=key, fields=f)


def test_main_menu_options():
    plain = _z().initial_screen().render_plain()
    for code in ("SE", "RA", "AU", "EV", "RE", "CO", "CM"):
        assert code in plain
    assert "zSecure Suite" in plain


def test_compliance_option():
    z = _z()
    plain = z.handle(P(OPTION="CM")).render_plain()
    assert "AAMV0450" in plain or "COMPLIANCE" in plain.upper()


def test_resource_submenu_writable_apf():
    z = _z()
    z.handle(P(OPTION="RE"))
    plain = z.handle(P(OPTION="3")).render_plain()      # writable APF finding
    assert "VULNLIB" in plain


def test_racf_submenu_special():
    z = _z()
    z.handle(P(OPTION="RA"))
    plain = z.handle(P(OPTION="1")).render_plain()      # SPECIAL users
    assert "IBMUSER" in plain


def test_interactive_carla_panel():
    z = _z()
    z.handle(P(OPTION="CO"))
    plain = z.handle(P(C0="NEWLIST TYPE=RACF", C1="SELECT SPECIAL",
                       C2="SORTLIST USERID(8) NAME(20)")).render_plain()
    assert "IBMUSER" in plain and "COMPLETE" in plain.upper()


def test_carla_help_and_fields_on_command_line():
    z = _z()
    z.handle(P(OPTION="CO"))
    assert "query zSecure" in z.handle(P(CMD="HELP")).render_plain()
    assert "WRITABLE" in z.handle(P(CMD="FIELDS TYPE=APF")).render_plain()


def test_navigation_and_exit():
    z = _z()
    z.handle(P(OPTION="AU"))                              # into a report
    assert z._screen == "REPORT"
    z.handle(P(key="PF3"))                                # back to menu
    assert z._screen == "MENU"
    assert z.handle(P(key="PF3")) is None                # exit to ISPF


if __name__ == "__main__":
    for n, f in sorted(globals().items()):
        if n.startswith("test_") and callable(f):
            f(); print("ok", n)
    print("ALL PASSED")
