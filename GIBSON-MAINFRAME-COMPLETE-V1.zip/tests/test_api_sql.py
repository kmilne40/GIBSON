"""API (curl) + SQL (DB2) command builders."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import api_sql as A

_p=_f=0
def ok(n,c):
    global _p,_f
    if c:_p+=1;print("  ok  "+n)
    else:_f+=1;print(" FAIL "+n)

def test_curl():
    cmd=A.curl_command("10.0.0.1",443,"/zosmf/info","GET","IBMUSER:SYS1")
    ok("https for 443", "https://10.0.0.1:443/zosmf/info" in cmd)
    ok("basic auth", "-u 'IBMUSER:SYS1'" in cmd)
    ok("zosmf csrf header", "X-CSRF-ZOSMF-HEADER" in cmd)
    ok("insecure flag", "-sk" in cmd)
    ok("http for plain port", A.curl_command("h",80,"/").startswith("curl -sk -X GET"))
    ok("endpoints listed", len(A.API_ENDPOINTS) >= 4)

def test_db2():
    cmd=A.db2_python_command("10.0.0.1",446,"DALLASC","IBMUSER","SYS1","SELECT 1 FROM SYSIBM.SYSDUMMY1")
    import base64, re
    _m = re.search(r'b64decode\("([^"]+)"\)', cmd)
    body = base64.b64decode(_m.group(1)).decode() if _m else cmd
    ok("ibm_db connect", "ibm_db.connect(" in body and "PORT=446" in body)
    ok("carries creds", "UID=IBMUSER" in body and "PWD=SYS1" in body)
    ok("runs the sql", "SYSIBM.SYSDUMMY1" in body)
    ok("clp alternative", A.db2_clp_command().startswith("db2 connect to"))
    ok("queries listed", len(A.DB2_QUERIES) >= 3)

if __name__=="__main__":
    for fn in (test_curl,test_db2):
        print("\n"+fn.__name__); fn()
    print(f"\nAPI/SQL: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
