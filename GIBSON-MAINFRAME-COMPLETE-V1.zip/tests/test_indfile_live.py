"""IND$FILE download over the live client path (scripted fake socket).

Guards the "download produces empty files" bug: a single TCP read can carry
several EOR-terminated host frames, and a frame can span two reads.  recv_record
must hand out exactly one record per call - never merging DATA frames into one
blob (which dropped every DATA after the first) and never losing a record split
across reads.
"""
import os
import socket
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.indfile.dft import (IndFileClient, WSF_CMD, SF_INDFILE,
    RT_OPEN, ST_OPEN, RT_DATA, ST_DATA, RT_CLOSE, ST_CLOSE, REC_DATA)


def _host_sf(rt, st, *records):
    body = bytes([SF_INDFILE, rt, st]) + b"".join(records)
    ln = len(body) + 2
    return bytes([WSF_CMD, (ln >> 8) & 0xFF, ln & 0xFF]) + body


def _rec_data(chunk):
    total = 5 + len(chunk)
    return bytes([REC_DATA, 0x80, 0x61, (total >> 8) & 0xFF, total & 0xFF]) + chunk


def _framed(*records):
    """telnet-frame each host structured field: IAC-escape 0xFF, add IAC EOR."""
    out = bytearray()
    for r in records:
        out += r.replace(b"\xff", b"\xff\xff") + b"\xff\xef"
    return bytes(out)


class FakeSock:
    def __init__(self, chunks):
        self.chunks = list(chunks)
        self.sent = bytearray()
        self._to = None

    def recv(self, _n):
        if self.chunks:
            return self.chunks.pop(0)
        raise socket.timeout()

    def sendall(self, b):
        self.sent += b

    def settimeout(self, t):
        self._to = t

    def gettimeout(self):
        return self._to

    def close(self):
        pass


def test_live_download_reassembles_all_records():
    open_f = _host_sf(RT_OPEN, ST_OPEN)
    data1 = _host_sf(RT_DATA, ST_DATA, _rec_data(b"HELLO WORLD"))
    data2 = _host_sf(RT_DATA, ST_DATA, _rec_data(b" AGAIN"))
    close_f = _host_sf(RT_CLOSE, ST_CLOSE)

    # read 1: OPEN alone
    # read 2: DATA1 + DATA2 back to back in ONE read (tests the queue)
    # read 3: first half of a framed CLOSE (no EOR yet)
    # read 4: the rest of CLOSE + EOR (tests the split-record carry)
    close_framed = _framed(close_f)
    split = len(close_framed) // 2
    chunks = [
        _framed(open_f),
        _framed(data1, data2),
        close_framed[:split],
        close_framed[split:],
    ]

    c = TN3270Client()
    c.sock = FakeSock(chunks)
    c.connected = True

    ift = IndFileClient(c)
    data = ift.get("USER.TEST.DATA", binary=True)

    assert data == b"HELLO WORLD AGAIN", repr(data)
    print("ok  live download reassembled:", data)


def test_live_download_single_read_all_frames():
    # Everything the host has in ONE read: OPEN + DATA + CLOSE.
    frames = _framed(
        _host_sf(RT_OPEN, ST_OPEN),
        _host_sf(RT_DATA, ST_DATA, _rec_data(b"ONELINE")),
        _host_sf(RT_CLOSE, ST_CLOSE),
    )
    c = TN3270Client()
    c.sock = FakeSock([frames])
    c.connected = True
    data = IndFileClient(c).get("X", binary=True)
    assert data == b"ONELINE", repr(data)
    print("ok  single-read download reassembled:", data)


if __name__ == "__main__":
    test_live_download_reassembles_all_records()
    test_live_download_single_read_all_frames()
    print("all passed")
