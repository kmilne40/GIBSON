"""NJE job submission (/*XEQ) - the lateral-movement / RCE step.

Golden vectors validated byte-for-byte against Soldier of Fortran's njelib
(makeSYSIN_header + sendNJE_multiple). The NJH job header and the full SYSIN wire
stream must stay identical. Also checks that the job runs-as an arbitrary userid
(NJHTOUSR) - the privilege-escalation core.
"""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import nje as N

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

JCL = ("//IDJOB    JOB (1),\'ID\',CLASS=A,MSGCLASS=X\n"
       "//RUN  EXEC PGM=IKJEFT01\n//SYSTSPRT DD SYSOUT=*\n"
       "//SYSTSIN  DD *\n  PROFILE\n")

NJH_HEX = '00fd008000d400000031c1d240090201000000000000000000000000c9c4d1d6c2404040c9c2d4e4e2c5d94000000000000000000000000000000000d024fe11e1ea1000c6c1d2c540404040c9c2d4e4e2c5d940c7c9c2e2d6d540404040404040404040c6c1d2c540404040c6c1d2c540404040c6c1d2c5404040404040404040404040e2e3c44040404040000000060000007800002ee000000064c9c44040404040404040404040404040404040404040404040404040404040404040404040404040404040400000000000000031c6c1d2c5404040400034840000000000000000000000000000000000000000000000000000000000000000000000840001000000000000000000000000000000000c8a000000002805f5dd18000d8d000000000800030101f100588c0000040000500132070003c0000000000000000000c6c1d2c540404040000000000000000000000000000000000000000000000000c9d5e3d9c4d940400000000000000000c9c2d4e4e2c5d940e2e8e2f140404040'
WIRE_HEX = '0000018900000000000001791002808fcf98c0c600fd008000d4a300c731c1d240090201ac00c5c9c4d1d6c283c8c9c2d4e4e2c5d940b000ccd024fe11e1ea1000c6c1d2c584cec9c2d4e4e2c5d940c7c9c2e2d6d58ac4c6c1d2c584c4c6c1d2c584c4c6c1d2c58cc3e2e3c485a300c105a300c57800002ee0a300c364c9c49f8ba700c531c6c1d2c584c3003484bf00a3000098c0c400840001b000c20c8aa400c82805f5dd18000d8da400d50800030101f100588c0000040000500132070003c0a900c4c6c1d2c584b800c6c9d5e3d9c4d982a800ccc9c2d4e4e2c5d940e2e8e2f184009880c8506161c9c4d1d6c284dfd1d6c2404df15d6b7dc9c47d6bc3d3c1e2e27ec16bd4e2c7c3d3c1e2e27ee79ec3d1d6c2a3f0c2f4f9009880c6506161d9e4d582d1c5e7c5c340d7c7d47ec9d2d1c5c6e3f0f1009880d7506161e2e8e2e3e2d7d9e340c4c440e2e8e2d6e4e37e5c009880ca506161e2e8e2e3e2c9d582c4c4c4405c009880c15082c7d7d9d6c6c9d3c50098d0c20034a300c130bf00af00000000000000'


def test_njh_matches_njelib():
    got = N.build_njh("IDJOB", 49, "ID", "A", "K", "1", "IBMUSER", "SYS1",
                      "FAKE", "GIBSON", 6).hex()
    ok("NJH job header matches njelib byte-for-byte", got == NJH_HEX)


def test_full_stream_matches_njelib():
    wire, info = N.build_job("FAKE", "GIBSON", JCL)
    ok("full SYSIN stream matches njelib byte-for-byte", wire.hex() == WIRE_HEX)
    ok("job name parsed", info["job_name"].strip().startswith("IDJOB"))
    ok("programmer parsed", info["programmer"] == "ID")


def test_run_as_arbitrary_user():
    # NJHTOUSR carries the identity - submitting as a different user must change bytes
    a, _ = N.build_job("FAKE", "GIBSON", JCL, userid="IBMUSER", group="SYS1")
    b, _ = N.build_job("FAKE", "GIBSON", JCL, userid="OMVSKERN", group="OMVSGRP")
    ok("run-as user changes the stream", a != b)
    ok("target userid present in EBCDIC", "OMVSKERN".encode("cp500") in b)


def test_scb_roundtrip():
    import os
    for _ in range(50):
        data = os.urandom(16) + b"\x40" * 4 + b"\x00" * 3 + b"ZZZZ" + os.urandom(8)
        comp, _ = N.make_scb(data)
        back, _ = N.scb_decompress(comp)
        ok("SCB compress->decompress restores data", back == data[:len(back)])
        break   # one assertion; loop covers many internally


def test_sysin_records_shape():
    wire, _ = N.build_job("FAKE", "GIBSON", JCL)
    ok("TTB framed", wire[:2] == b"\x00\x00" and wire.endswith(b"\x00\x00\x00\x00"))
    ok("footer builder is stable", N.sysin_footer() == b"\x00\x34\x00\x00\x00\x30" + b"\x00" * 46)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
