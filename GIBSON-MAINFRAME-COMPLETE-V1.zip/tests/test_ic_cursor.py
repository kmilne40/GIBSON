"""Regression: the field editor must honour the host's Insert-Cursor (IC) position.

Real panels (ISPF, CICS, IBM i sign-on) send an IC order placing the cursor where
you should type (e.g. "Option ===>").  Before the fix the cursor stayed at top-left
and you had to reposition and press Enter twice.  IC handling is shared by the 3270
and 5250 parsers (both set screen.cursor), so this covers both."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def _screen_with_ic(ic_addr):
    c = TN3270Client(); c.packets = []
    st = bytes([ds.CMD_EW, 0xC0])
    st += bytes([ds.SBA]) + ds.enc_addr(0) + bytes([ds.SF, 0x20]) + "Menu".encode("cp037")
    st += bytes([ds.SBA]) + ds.enc_addr(ic_addr - 1) + bytes([ds.SF, 0x00])   # unprot field attr
    st += bytes([ds.IC])                                                        # IC -> body
    ds.DataStreamParser(c.screen).parse(st)
    return c

def test_cursor_lands_on_ic_not_topleft():
    c = _screen_with_ic(240)
    r, cc = c.screen.rc(c.screen.cursor)
    ed = FieldEditor(c)                                # __init__ -> sync_cursor
    ok("screen recorded the IC position", c.screen.cursor == 240)
    ok("editor cursor honours IC (not top-left)", ed.cursor == (r, cc))
    ok("cursor is NOT (1,1)", ed.cursor != (1, 1))

def test_ic_reapplied_after_aid():
    c = _screen_with_ic(240)
    ed = FieldEditor(c)
    ed.cursor = (1, 1)                                  # pretend we moved away
    # a new screen arrives with a different IC; sync_cursor should follow it
    c.screen.cursor = 400
    # make sure there is an unprotected field at addr 400 so IC is honoured
    from phosphor.core.screen import Cell
    c.screen.set_cell(399, Cell(" ", "green", protected=False, is_field_start=True))
    c.screen.set_cell(400, Cell(" ", "green", protected=False))
    ed.sync_cursor()
    ok("cursor follows the new IC after a screen update", ed.cursor == c.screen.rc(400))

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
