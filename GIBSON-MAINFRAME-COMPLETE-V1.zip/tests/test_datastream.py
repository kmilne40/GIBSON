"""Self-contained tests (no GIBSON needed) for the PHOSPHOR TN3270 engine."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from phosphor.core.screen import ScreenBuffer
from phosphor.protocols.tn3270.datastream import (DataStreamParser, build_inbound,
    enc_addr, dec_addr, SBA, SFE, IC, CMD_EW, AID)

def test_address_roundtrip():
    for a in (0, 1, 80, 1533, 1919, 4095):
        b = enc_addr(a); assert dec_addr(b[0], b[1]) == a

def test_sfe_colour_parse():
    # EW + WCC, SBA(0), SFE colour=blue(0xF1) protected, text 'HI'
    data = bytes([CMD_EW, 0xC0, SBA]) + enc_addr(0) + \
           bytes([SFE, 0x02, 0xC0, 0x20, 0x42, 0xF1]) + "HI".encode("cp037")
    s = ScreenBuffer(); DataStreamParser(s).parse(data)
    assert s.row_text(1).startswith(" HI")           # col1 is the field attr
    coloured = [c.colour for c in s.cells if c.char in ("H", "I")]
    assert coloured == ["blue", "blue"], coloured

def test_input_field_and_frame():
    # a screen with one unprotected (input) field at addr 5
    data = bytes([CMD_EW, 0xC0, SBA]) + enc_addr(5) + \
           bytes([SFE, 0x02, 0xC0, 0x00, 0x42, 0xF4, IC])   # unprotected, green, cursor
    s = ScreenBuffer(); DataStreamParser(s).parse(data)
    ins = s.input_fields()
    assert len(ins) == 1 and ins[0].is_input
    s.cursor = 6
    frame = build_inbound(s, "ENTER", [(6, "ABC")])
    assert frame[0] == AID["ENTER"]                  # AID first
    assert frame.endswith(b"\xff\xef")               # EOR last
    assert "ABC".encode("cp037") in frame

if __name__ == "__main__":
    for fn in [test_address_roundtrip, test_sfe_colour_parse, test_input_field_and_frame]:
        fn(); print("PASS", fn.__name__)


# --- regression: real-host command codes + 14-bit addressing (the 192.168.0.248 bug) ---
def test_channel_command_code_erase_write():
    """Real z/OS VTAM can send Erase/Write as the channel code 0x05, not SNA 0xF5."""
    from phosphor.protocols.tn3270.datastream import _ERASE_WRITE_CMDS, _WRITE_CMDS, DataStreamParser
    from phosphor.core.screen import ScreenBuffer
    assert 0x05 in _ERASE_WRITE_CMDS and 0x0D in _ERASE_WRITE_CMDS and 0x01 in _WRITE_CMDS
    # exact leading bytes captured from a real host: 05 c7 11 07 7f 1d c8 11 00 00 z/OS...
    data = bytes([0x05,0xc7,0x11,0x07,0x7f,0x1d,0xc8,0x11,0x00,0x00]) + "z/OS V2R".encode("cp037")
    s = ScreenBuffer(); DataStreamParser(s).parse(data)
    assert s.row_text(1).startswith("z/OS V2R"), s.row_text(1)


def test_14bit_addressing():
    """SBA with top two bits 00 is 14-bit addressing, not 12-bit."""
    # 07 7f -> 14-bit 1919 (row 23 col 79); the old 12-bit decode gave 511 (row 6)
    assert dec_addr(0x07, 0x7f) == 1919
    assert dec_addr(0x00, 0x00) == 0
    # 12-bit codes (top bits 01/11) still decode as before
    assert dec_addr(enc_addr(80)[0], enc_addr(80)[1]) == 80
    assert dec_addr(enc_addr(1919)[0], enc_addr(1919)[1]) == 1919


def test_14bit_multiline_positions():
    from phosphor.protocols.tn3270.datastream import SBA, DataStreamParser
    from phosphor.core.screen import ScreenBuffer
    def sba14(a): return bytes([SBA, (a >> 8) & 0x3F, a & 0xFF])
    data = bytes([0x05, 0xC3])
    data += sba14(0) + "TOP".encode("cp037")
    data += sba14(23 * 80) + "BOTTOM".encode("cp037")
    s = ScreenBuffer(); DataStreamParser(s).parse(data)
    assert s.row_text(1).startswith("TOP")
    assert s.row_text(24).startswith("BOTTOM")


def test_gibson_sna_form_still_works():
    """Regression: GIBSON's SNA Erase/Write (0xF5) + 12-bit addressing unaffected."""
    from phosphor.protocols.tn3270.datastream import CMD_EW, SBA, DataStreamParser
    from phosphor.core.screen import ScreenBuffer
    data = bytes([CMD_EW, 0xC0, SBA]) + enc_addr(80) + "GIBSON".encode("cp037")
    s = ScreenBuffer(); DataStreamParser(s).parse(data)
    assert s.row_text(2).startswith("GIBSON")


# --- Phase 1: WSF (structured fields / Query Reply) + inbound 14-bit ---
def test_wsf_query_reply_and_no_screen_corruption():
    from phosphor.protocols.tn3270.datastream import DataStreamParser, AID_SF, enc_addr
    from phosphor.core.screen import ScreenBuffer
    scr = ScreenBuffer()
    DataStreamParser(scr).parse(bytes([0xF5, 0xC0, 0x11]) + enc_addr(0) + "HELLO".encode("cp037"))
    wsf = bytes([0xF3, 0x00, 0x05, 0x01, 0x00, 0x02])   # WSF + Read Partition Query
    p = DataStreamParser(scr); p.parse(wsf)
    assert p.reply is not None and p.reply[0] == AID_SF
    assert scr.row_text(1).startswith("HELLO")          # WSF must not overwrite the screen


def test_query_reply_framing_self_consistent():
    from phosphor.protocols.tn3270.datastream import build_query_reply, AID_SF, SFID_QUERY_REPLY, EOR
    qr = build_query_reply(24, 80)
    assert qr[0] == AID_SF and qr.endswith(EOR)
    body = qr[1:-2]; i = 0; fields = 0
    while i < len(body):
        ln = (body[i] << 8) | body[i + 1]
        assert body[i + 2] == SFID_QUERY_REPLY
        assert 3 <= ln and i + ln <= len(body)
        i += ln; fields += 1
    assert fields >= 4


def test_inbound_14bit_roundtrip():
    for a in (0, 80, 1919, 4096, 8000, 16383):
        b = enc_addr(a)
        assert dec_addr(b[0], b[1]) == a


def test_non_query_wsf_not_answered():
    from phosphor.protocols.tn3270.datastream import is_read_partition_query
    assert not is_read_partition_query(bytes([0x00, 0x05, 0x0F, 0x00, 0x00]))
