"""Tier-3 bot tests - scheduling, retry, reconnect, logging, hooks. No live host."""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.bot import Bot, Job, RunResult

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


class FakeClient:
    def connect(self, host, port=23, **kw): self.connected = True
    def terminate(self): self.connected = False
    def send_string(self, t): pass
    def send_enter(self): pass
    def screen_get(self): return ["READY"]
    def find(self, t): return True


def test_one_shot_runs_once():
    calls = []
    def macro(engine): calls.append(1)
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("once", macro, every=None))
    bot.run(max_runs=10)
    ok("one-shot job runs exactly once", len(calls) == 1)
    ok("history has one ok result", len(bot.history) == 1 and bot.history[0].ok)


def test_scheduled_runs_bounded():
    calls = []
    def macro(engine): calls.append(1)
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("tick", macro, every=0.01))
    bot.run(max_runs=4)
    ok("scheduled job runs max_runs times", len(calls) == 4)


def test_retry_then_success():
    state = {"n": 0}
    def flaky(engine):
        state["n"] += 1
        if state["n"] < 3:
            raise RuntimeError("connection dropped")
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("flaky", flaky, every=None, max_retries=3, retry_backoff=0.0))
    bot.run(max_runs=5)
    r = bot.history[-1]
    ok("retries until success (3 attempts)", r.ok and r.attempts == 3)


def test_reconnect_fresh_engine_each_attempt():
    seen_clients = []
    class Tracking(FakeClient):
        def connect(self, *a, **k):
            seen_clients.append(id(self)); super().connect(*a, **k)
    def macro(engine):
        engine.connect("h")           # forces a client.connect each attempt
        if len(seen_clients) < 2:
            raise RuntimeError("drop")
    bot = Bot(client_factory=Tracking)
    bot.add_job(Job("reconnect", macro, max_retries=3, retry_backoff=0.0))
    bot.run(max_runs=3)
    ok("a fresh client is connected per attempt (reconnect-on-drop)",
       len(set(seen_clients)) >= 2)


def test_failure_exhausts_and_hooks_fire():
    fails, succs = [], []
    def always_fail(engine): raise RuntimeError("nope")
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("bad", always_fail, max_retries=2, retry_backoff=0.0,
                    on_failure=lambda r: fails.append(r), on_success=lambda r: succs.append(r)))
    bot.run(max_runs=3)
    r = bot.history[-1]
    ok("failing job marked not ok after max_retries", (not r.ok) and r.attempts == 2)
    ok("on_failure hook fired once", len(fails) == 1)
    ok("on_success hook not fired", len(succs) == 0)
    ok("error recorded", r.error and "nope" in r.error)


def test_success_hook_fires():
    succs = []
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("good", lambda e: None, on_success=lambda r: succs.append(r)))
    bot.run(max_runs=1)
    ok("on_success hook fired", len(succs) == 1)


def test_jsonl_logging():
    tmp = tempfile.mkdtemp(); log = os.path.join(tmp, "bot.jsonl")
    bot = Bot(log_path=log, client_factory=FakeClient)
    bot.add_job(Job("logme", lambda e: None, every=0.01))
    bot.run(max_runs=3)
    lines = [json.loads(l) for l in open(log)]
    ok("one JSON line per run", len(lines) == 3)
    ok("log line has job/ok/attempts/duration",
       all({"job", "ok", "attempts", "duration"} <= set(d) for d in lines))


def test_pmac_file_job():
    tmp = tempfile.mkdtemp(); mac = os.path.join(tmp, "j.pmac")
    open(mac, "w").write("connect 1.2.3.4 23\nwait_for READY 1\ndisconnect\n")
    bot = Bot(client_factory=FakeClient)
    bot.add_job(Job("fromfile", mac, every=None))
    bot.run(max_runs=1)
    ok("a .pmac file job runs and succeeds", bot.history[-1].ok)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
