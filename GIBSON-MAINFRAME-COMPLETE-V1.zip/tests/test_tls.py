"""TLS tunnel for TN3270 / TN5250 (implicit / AT-TLS style) plus the no-verify
security-testing mode.

Spins a real self-signed TLS server on localhost and checks:
  * no-verify completes the handshake against the self-signed cert (testing mode)
  * verify REJECTS the self-signed cert (production safety)
  * TLSInfo is filled in (version, cipher, unverified warning)
  * port 992 implies a tunnel, and the client wires tls options through to wrap_socket
"""
import os, sys, ssl, socket, threading, tempfile, datetime
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols import tls as T

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def _self_signed():
    """Return (certfile, keyfile) for a throwaway localhost cert."""
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "phosphor-test-host")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=1))
            .sign(key, hashes.SHA256()))
    cf = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    kf = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    cf.write(cert.public_bytes(serialization.Encoding.PEM)); cf.close()
    kf.write(key.private_bytes(serialization.Encoding.PEM,
                               serialization.PrivateFormat.TraditionalOpenSSL,
                               serialization.NoEncryption())); kf.close()
    return cf.name, kf.name


class _Server:
    """Minimal TLS server: accepts one connection, echoes a byte, closes."""
    def __init__(self, certfile, keyfile):
        self.ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.ctx.load_cert_chain(certfile, keyfile)
        self.sock = socket.socket(); self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1); self.port = self.sock.getsockname()[1]
        self.handshakes = 0
        self.t = threading.Thread(target=self._serve, daemon=True); self.t.start()
    def _serve(self):
        while True:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            try:
                s = self.ctx.wrap_socket(c, server_side=True)
                self.handshakes += 1
                try: s.sendall(b"\x00")
                except OSError: pass
                s.close()
            except (ssl.SSLError, OSError):
                pass
    def close(self):
        try: self.sock.close()
        except OSError: pass


def test_no_verify_connects_through_self_signed():
    cf, kf = _self_signed()
    srv = _Server(cf, kf)
    try:
        raw = socket.create_connection(("127.0.0.1", srv.port), 5)
        info = T.TLSInfo()
        tls = T.wrap_socket(raw, "127.0.0.1", verify=False, info=info)
        ok("handshake completes against a self-signed cert (no-verify)", True)
        ok("TLSInfo marked active + unverified", info.active and not info.verified)
        ok("TLS version captured", bool(info.version))
        ok("cipher captured", bool(info.cipher))
        ok("a loud warning is set", bool(info.warning))
        tls.close()
    except Exception as e:
        ok("handshake completes against a self-signed cert (no-verify) [%r]" % e, False)
    finally:
        srv.close(); os.unlink(cf); os.unlink(kf)


def test_verify_rejects_self_signed():
    cf, kf = _self_signed()
    srv = _Server(cf, kf)
    rejected = False
    try:
        raw = socket.create_connection(("127.0.0.1", srv.port), 5)
        try:
            T.wrap_socket(raw, "127.0.0.1", verify=True)
        except ssl.SSLError:
            rejected = True
        except ssl.CertificateError:
            rejected = True
        try: raw.close()
        except OSError: pass
    finally:
        srv.close(); os.unlink(cf); os.unlink(kf)
    ok("verify mode rejects the untrusted self-signed cert", rejected)


def test_port_992_implies_tunnel():
    ok("port 992 implies an implicit TLS tunnel", T.default_secure_port(992) is True)
    ok("port 23 does not", T.default_secure_port(23) is False)


def test_client_wires_tls_options():
    # patch create_connection + wrap_socket to confirm the client tunnels on tls=True
    from phosphor.protocols.tn3270 import client as c3
    calls = {}
    class _FakeSock:
        def settimeout(self, *_): pass
        def recv(self, *_): return b""
        def sendall(self, *_): pass
        def close(self): pass
    def fake_create(addr, to): calls["addr"] = addr; return _FakeSock()
    def fake_wrap(sock, host, **kw): calls["wrap"] = (host, kw); return sock
    orig_create = c3.socket.create_connection
    orig_wrap = c3._tls.wrap_socket
    orig_neg = c3.TN3270Client._negotiate_until_ready
    c3.socket.create_connection = fake_create
    c3._tls.wrap_socket = fake_wrap
    c3.TN3270Client._negotiate_until_ready = lambda self: None
    try:
        cli = c3.TN3270Client()
        cli.connect("mvs.example.com", 992)      # port 992 -> auto TLS
        ok("port 992 auto-tunnels (wrap_socket called)", "wrap" in calls)
        calls.clear()
        cli.connect("mvs.example.com", 23, tls=True, tls_verify=False)
        ok("tls=True tunnels on any port", "wrap" in calls)
        ok("no-verify flag passed through", calls["wrap"][1].get("verify") is False)
    finally:
        c3.socket.create_connection = orig_create
        c3._tls.wrap_socket = orig_wrap
        c3.TN3270Client._negotiate_until_ready = orig_neg


def test_parse_target_prefixes():
    ok("plain host: no tls", (lambda t: not t.tls and t.verify)(T.parse_target("mvs")))
    t = T.parse_target("L:mvs"); ok("L: -> tls, verify", t.tls and t.verify and t.host == "mvs")
    t = T.parse_target("Y:mvs"); ok("Y: -> tls, no-verify", t.tls and not t.verify)
    t = T.parse_target("L:Y:mvs"); ok("L:Y: -> tls, no-verify", t.tls and not t.verify)
    t = T.parse_target("mvs=cn.ibm.com"); ok("=name -> accept_hostname", t.accept_hostname == "cn.ibm.com")


def test_cli_target_prefixes():
    from phosphor.app.__main__ import _parse_target
    ok("bare host -> port 23", _parse_target(["mvs"])[:2] == ("mvs", 23))
    ok("L: -> port 992, prefix kept", _parse_target(["L:mvs"])[:2] == ("L:mvs", 992))
    ok("tn3270s:// -> L: + 992", _parse_target(["tn3270s://mvs"])[:2] == ("L:mvs", 992))
    ok("tn5250s:// -> 5250 proto", _parse_target(["tn5250s://as400"])[2] == "5250")
    ok("explicit port survives prefix", _parse_target(["L:mvs:23"])[:2] == ("L:mvs", 23))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
