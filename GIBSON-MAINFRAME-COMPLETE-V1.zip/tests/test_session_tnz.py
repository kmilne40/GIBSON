"""tnz backend adapter: screen conversion + AID/key routing + engine factory.

These verify the adapter logic against tnz's real attribute surface (maxrow,
maxcol, scrstr, plane_fa, plane_fg, is_protected, curadd, key_*/pfN/paN/enter,
set_cursor_address) without needing a live mainframe."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

HAVE_TNZ = True
try:
    import tnz  # noqa
except Exception:
    HAVE_TNZ = False

from phosphor.session import available_engines, make_connection


class FakeTnz:
    """Minimal stand-in exposing exactly the tnz surface the adapter reads."""
    def __init__(self, rows=24, cols=80):
        self.maxrow, self.maxcol = rows, cols
        n = rows * cols
        self._text = [" "] * n
        self.plane_fa = bytearray(n)
        self.plane_fg = bytearray(n)
        self.curadd = 0
        self._protected = [True] * n
        self.calls = []
    # build a tiny login-style screen: protected label + one input field
    def put(self, addr, s, colour=4, protected=True, field_start=False):
        if field_start:
            self.plane_fa[addr] = 0x60
        for i, ch in enumerate(s):
            self._text[addr + i] = ch
            self.plane_fg[addr + i] = colour
            self._protected[addr + i] = protected
    def scrstr(self, a, b): return "".join(self._text[a:b])
    def is_protected(self, addr): return self._protected[addr]
    # key/AID surface -> record
    def set_cursor_address(self, a): self.curadd = a; self.calls.append(("cursor", a))
    def key_data(self, text, **k): self.calls.append(("key_data", text))
    def enter(self, *a, **k): self.calls.append(("enter",))
    def clear(self, *a, **k): self.calls.append(("clear",))
    def wait(self, *a, **k): pass
    def shutdown(self): self.calls.append(("shutdown",))
    def pf3(self, *a, **k): self.calls.append(("pf3",))
    def pf7(self, *a, **k): self.calls.append(("pf7",))
    def pa1(self, *a, **k): self.calls.append(("pa1",))


def test_screen_conversion():
    from phosphor.session.tnz_backend import screen_from_tnz
    ft = FakeTnz()
    ft.plane_fa[0] = 0x60                       # field attribute at addr 0 (protected label)
    ft.put(1, "LOGON", colour=6, protected=True)
    ft.plane_fa[20] = 0x40                       # field attribute at addr 20 (unprot input)
    for a in range(20, 30):
        ft._protected[a] = False
    ft.put(21, "IBMUSER", colour=4, protected=False)
    ft.curadd = 21
    sb = screen_from_tnz(ft)
    row0 = sb.row_text(1)
    ok("text extracted", "LOGON" in row0 and "IBMUSER" in row0)
    ok("field-attr cells render blank", sb.cells[0].char == " " and sb.cells[0].is_field_start)
    ok("label protected", sb.cells[1].protected)
    ok("input field unprotected", not sb.cells[21].protected)
    ok("colour mapped (yellow label)", sb.cells[1].colour == "yellow")
    inp = sb.input_fields()
    ok("input field detected", any(f.col == 22 for f in inp))     # addr20 attr -> body col22
    ok("cursor synced", sb.cursor == 21)


def test_key_and_aid_routing():
    if not HAVE_TNZ:
        ok("tnz installed for routing test (skipped)", True); return
    from phosphor.session.tnz_backend import TnzSession
    s = TnzSession()
    ft = FakeTnz(); s.t = ft                      # swap in the recorder
    s.move_to(3, 5); s.send_string("HELLO")
    ok("move_to+send_string sets cursor then types",
       ("cursor", (3 - 1) * 80 + 4) in ft.calls and ("key_data", "HELLO") in ft.calls)
    s.send_enter(); ok("enter routed", ("enter",) in ft.calls)
    s.send_pf(7); ok("pf7 routed", ("pf7",) in ft.calls)
    s.send_pa(1); ok("pa1 routed", ("pa1",) in ft.calls)
    s.send_clear(); ok("clear routed", ("clear",) in ft.calls)
    s.terminate(); ok("terminate shuts tnz down", ("shutdown",) in ft.calls)


def test_engine_factory():
    eng = available_engines()
    ok("native always available", eng.get("native") is True)
    ok("tnz discovered", eng.get("tnz") == HAVE_TNZ)
    # native 3270 + 5250 always return the clean-room clients
    c3 = make_connection("3270", "native")
    ok("native 3270 -> TN3270Client", type(c3).__name__ == "TN3270Client")
    c5 = make_connection("5250", "native")
    ok("native 5250 -> TN5250Client", type(c5).__name__ == "TN5250Client")
    if HAVE_TNZ:
        ct = make_connection("3270", "tnz")
        ok("tnz 3270 -> TnzSession", type(ct).__name__ == "TnzSession")
        # tnz has no 5250 -> falls back to native 5250
        c5t = make_connection("5250", "tnz")
        ok("tnz 5250 falls back to native", type(c5t).__name__ == "TN5250Client")


def test_duck_type_surface():
    # the tnz session must expose everything the FieldEditor / app touch
    if not HAVE_TNZ:
        ok("duck-type surface (skipped, no tnz)", True); return
    from phosphor.session.tnz_backend import TnzSession
    s = TnzSession()
    for m in ("screen", "move_to", "send_string", "send_enter", "send_pf",
              "send_pa", "send_clear", "colour_grid", "screen_get", "find",
              "get_pos", "terminate", "is_connected"):
        ok(f"has {m}", hasattr(s, m))


def test_tnz_editor_routes_typing():
    """The bug: typing did nothing on the tnz backend.  Now every keystroke goes
    straight to tnz's own input handling instead of PHOSPHOR's field model."""
    if not HAVE_TNZ:
        ok("tnz editor routing (skipped, no tnz)", True); return
    from phosphor.session.tnz_backend import TnzSession
    from phosphor.session import make_editor
    s = TnzSession(); ft = FakeTnz(); s.t = ft
    for k in ("key_tab", "key_backtab", "key_curup", "key_curdown", "key_curleft",
              "key_curright", "key_backspace", "key_home", "key_delete",
              "key_eraseeof", "key_eraseinput"):
        setattr(ft, k, (lambda name: (lambda *a, **kw: ft.calls.append((name,))))(k))
    ed = make_editor(s)
    ok("make_editor -> TnzEditor", type(ed).__name__ == "TnzEditor")
    ed.type_char("L")
    ok("type_char routes to tnz.key_data (the fix)", ("key_data", "L") in ft.calls)
    ed.tab(); ok("tab -> key_tab", ("key_tab",) in ft.calls)
    ed.tab(back=True); ok("back-tab -> key_backtab", ("key_backtab",) in ft.calls)
    ed.enter(); ok("enter -> enter", ("enter",) in ft.calls)
    ed.pf(3); ok("pf(3) -> pf3", ("pf3",) in ft.calls)
    ed.move(0, 1); ok("move right -> key_curright", ("key_curright",) in ft.calls)
    ed.backspace(); ok("backspace -> key_backspace", ("key_backspace",) in ft.calls)
    ft.curadd = 1 * 80 + 5
    ok("cursor reads tnz addr", ed.cursor == (2, 6))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
