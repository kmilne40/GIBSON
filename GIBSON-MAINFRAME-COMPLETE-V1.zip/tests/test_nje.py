"""NJE security-testing client ("iNJEctor").

Drives the client against a server that reproduces GIBSON's NJE handshake logic:
OPEN -> ACK/NAK reason codes, then SOH/ENQ -> DLE/ACK -> I-record(password) -> J/B.
Confirms node enumeration by reason code, the no-password finding, and password
accept/reject.
"""
import os, sys, socket, threading
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import nje

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

DLE_ACK = bytes.fromhex("000000120000000000000002107000000000")
# node -> (trusted_rhosts, password)   password "" == none required
NODES = {
    "GIBSON": ({"FAKE", "HAL", "MVSA"}, ""),      # trusts FAKE, no password
    "HAL":    ({"GIBSON"}, "HAL123"),             # exists, only trusts GIBSON
    "ORAC":   ({"GIBSON", "FAKE"}, "ORAC123"),    # trusts FAKE, has password
}


class _NjeServer:
    def __init__(self):
        self.sock = socket.socket(); self.sock.bind(("127.0.0.1", 0)); self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        while True:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            threading.Thread(target=self._handle, args=(c,), daemon=True).start()

    def _handle(self, c):
        try:
            c.settimeout(4)
            data = c.recv(4096)
            p = nje.parse_open(data)
            if not p:
                c.close(); return
            ohost, rhost = p["ohost"], p["rhost"]
            node = NODES.get(ohost)
            if node is None:
                c.sendall(nje.build_open("NAK", rhost=rhost, ohost=ohost, r=nje.R_UNKNOWN_OHOST)); c.close(); return
            trusted, pw = node
            if rhost not in trusted:
                c.sendall(nje.build_open("NAK", rhost=rhost, ohost=ohost, r=nje.R_BAD_RHOST)); c.close(); return
            c.sendall(nje.build_open("ACK", rhost=rhost, ohost=ohost, r=nje.R_OK))
            # expect SOH/ENQ
            enq = c.recv(4096)
            if not nje.SOH_ENQ[:14] == enq[:14]:
                c.close(); return
            c.sendall(DLE_ACK)
            irec = c.recv(4096)
            got_pw = nje.from_ebcdic(irec[37:45]) if len(irec) >= 45 else ""
            good = (not pw) or (got_pw.upper() == pw.upper())
            c.sendall(nje.signon_reply(good) if hasattr(nje, "signon_reply") else
                      _reply(good))
            c.close()
        except Exception:
            try: c.close()
            except Exception: pass


def _reply(good):
    b = bytearray(24)
    b[17] = 0xF0
    b[18] = nje.SRCB_J if good else nje.SRCB_B
    return bytes(b)


def test_open_probe_reason_codes():
    srv = _NjeServer()
    r = nje.open_probe("127.0.0.1", "GIBSON", rhost="FAKE", port=srv.port)
    ok("trusted node -> ACK (0x00)", r.reason == nje.R_OK and r.opened)
    ok("ACK yields a spoofable finding", any("spoofable" in f for f in r.findings))
    r = nje.open_probe("127.0.0.1", "HAL", rhost="FAKE", port=srv.port)
    ok("existing but untrusted rhost -> NAK 0x04", r.reason == nje.R_BAD_RHOST)
    r = nje.open_probe("127.0.0.1", "NOSUCH", rhost="FAKE", port=srv.port)
    ok("unknown node -> NAK 0x01", r.reason == nje.R_UNKNOWN_OHOST)


def test_enumerate_nodes():
    srv = _NjeServer()
    found = nje.enumerate_nodes("127.0.0.1", ["GIBSON", "HAL", "NOSUCH", "ORAC"],
                                rhost="FAKE", port=srv.port)
    existing = {r.ohost for r in found if r.reason in (nje.R_OK, nje.R_BAD_RHOST)}
    ok("enumeration finds the real nodes", {"GIBSON", "HAL", "ORAC"} <= existing)
    ok("enumeration excludes the fake node", "NOSUCH" not in existing)


def test_signon_no_password():
    srv = _NjeServer()
    r = nje.signon_test("127.0.0.1", "GIBSON", rhost="FAKE", password="", port=srv.port)
    ok("no-password node accepts empty sign-on", r.signon_ok is True)
    ok("no-password finding raised", any("NO password" in f for f in r.findings))


def test_signon_password_accept_reject():
    srv = _NjeServer()
    bad = nje.signon_test("127.0.0.1", "ORAC", rhost="FAKE", password="WRONG", port=srv.port)
    ok("wrong node password rejected", bad.signon_ok is False)
    good = nje.signon_test("127.0.0.1", "ORAC", rhost="FAKE", password="ORAC123", port=srv.port)
    ok("correct node password accepted", good.signon_ok is True)


def test_build_records_roundtrip():
    rec = nje.build_open("OPEN", rhost="ME", ohost="THEM", r=0)
    p = nje.parse_open(rec)
    ok("OPEN record round-trips", p["rhost"] == "ME" and p["ohost"] == "THEM")
    ire = nje.build_irecord("ME", "THEM", "SECRET")
    ok("I-record carries password at offset 37", nje.from_ebcdic(ire[37:45]) == "SECRET")
    ok("I-record SRCB is 'I'", ire[18] == nje.SRCB_I)


if __name__ == "__main__":
    # provide signon_reply for the server if the module doesn't expose one
    if not hasattr(nje, "signon_reply"):
        nje.signon_reply = _reply
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
