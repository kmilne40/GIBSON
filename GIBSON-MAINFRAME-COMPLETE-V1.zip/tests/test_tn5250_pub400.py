"""Regression: the decoded PUB400 QINTER sign-on (IBM-3179-2).

Built from the real tn5250.pcap sign-on stream: two labelled input fields, the
username at (5,25) length 10 and the password at (6,25) length 128, with the
attribute cell at column 24 so the field body starts at 25.  The bug this guards
against ("tab/enter sends the cursor to the start of the same text") came from
the field running to the next field-start instead of honouring the explicit SF
length, and from the protected labels being dropped from the field table.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from phosphor.protocols.tn5250 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p = _f = 0


def ok(name, cond):
    global _p, _f
    if cond:
        _p += 1
        print("  ok  " + name)
    else:
        _f += 1
        print(" FAIL " + name)


def _sba(r, c):
    return bytes([ds.ORD_SBA, r, c])


def _sf_out(attr=0x20):
    return bytes([ds.ORD_SF, attr])


def _sf_in(ffw, attr, length):
    return bytes([ds.ORD_SF, (ffw >> 8) & 0xFF, ffw & 0xFF, attr,
                  (length >> 8) & 0xFF, length & 0xFF])


def _signon():
    # ESC WTD + control chars, matching the pub400 record shape.
    s = bytes([ds.ESC, ds.CMD_WTD, 0x00, 0x18])
    s += _sba(3, 2) + _sf_out(0x20) + "User  . . . . . . . . . . . . . .".encode("cp037")
    s += _sba(5, 24) + _sf_in(0x4020, 0x24, 10)          # username, len 10
    s += _sba(4, 2) + _sf_out(0x20) + "Password  . . . . . . . . . . . .".encode("cp037")
    s += _sba(6, 24) + _sf_in(0x4000, 0x27, 128)         # password, len 128 (non-display)
    s += bytes([ds.ORD_IC, 5, 25])                       # IC lands on the username body
    c = TN3270Client()
    c.packets = []
    ds.parse(s, c.screen)
    return c


def test_two_bounded_input_fields():
    c = _signon()
    inp = c.screen.input_fields()
    ok("exactly two input fields", len(inp) == 2)
    ok("username at (5,25) len 10", (inp[0].row, inp[0].col, inp[0].length) == (5, 25, 10))
    ok("password at (6,25) len 128", (inp[1].row, inp[1].col, inp[1].length) == (6, 25, 128))
    ok("password field is non-display", inp[1].hidden)


def test_labels_present_and_protected():
    c = _signon()
    prot = [f for f in c.screen.fields() if f.protected]
    ok("two protected labels", len(prot) == 2)
    ok("username label text intact", "User" in c.screen.row_text(3))
    ok("password label text intact", "Password" in c.screen.row_text(4))


def test_ic_then_tab_then_enter():
    c = _signon()
    ed = FieldEditor(c)
    ok("IC lands on username", ed.cursor == (5, 25))
    for ch in "COACHKEV":
        ed.type_char(ch)
    ed.tab()
    ok("tab moves to password start", ed.cursor == (6, 25))
    for ch in "hunter2":
        ed.type_char(ch)
    ed._flush()
    frame = ds.build_inbound(c.screen, "ENTER", c._pending)
    ok("username sent in inbound", "COACHKEV".encode("cp037") in frame)
    ok("password sent in inbound", "hunter2".encode("cp037") in frame)


def test_tab_does_not_wrap_within_a_field():
    # The username field is 10 wide; typing 3 chars and tabbing must jump to the
    # NEXT field, never back to the start of the same one.
    c = _signon()
    ed = FieldEditor(c)
    ed.cursor = (5, 25)
    for ch in "ABC":
        ed.type_char(ch)
    ed.tab()
    ok("tab from mid-username goes to password", ed.cursor == (6, 25))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
