"""TN5250 single-Enter: apply a multi-record host reply.

Root-caused from a real pub400 capture (tn5250.pcap). Every Enter that read input
fields appeared to need pressing twice, while function keys worked on the first
press. The outbound records were byte-correct (the same field+SBA+AID format that
signs on successfully), so the fault was on the read side: an IBM i host answers an
Enter with, commonly, two records back to back - a message/acknowledgement record
and then the new screen - and the old read loop stopped at the first record and
missed the screen. Nothing changed on screen, so the operator pressed Enter again.
Function keys drew a single-record reply, so they always worked first time.

This test drives the client's real read path with a scripted host that returns the
reply as two separate reads (message, then screen). One send_enter must leave the
final screen showing, not the intermediate message.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn5250 import datastream as ds
from phosphor.protocols.tn5250.client import TN5250Client

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def _record(rows_text, cursor=(1, 1)):
    """One EOR-terminated, GDS-wrapped 5250 record painting rows_text."""
    wtd = ds.build_wtd(rows_text, cursor)
    return ds.gds_wrap(wtd).replace(b"\xff", b"\xff\xff") + b"\xff\xef"


class ScriptSock:
    """A socket whose recv() hands back a queued list of chunks in order, one per
    call, then blank (timeout)."""
    def __init__(self, chunks):
        self._chunks = list(chunks)
        self.sent = bytearray()
        self._to = 1.5
    def sendall(self, data): self.sent += data
    def recv(self, n):
        if self._chunks:
            return self._chunks.pop(0)
        import socket as _s
        raise _s.timeout()
    def gettimeout(self): return self._to
    def settimeout(self, t): self._to = t
    def close(self): pass


def _client_ready():
    c = TN5250Client()
    c.packets = []
    c.neg.local_eor = c.neg.remote_eor = True
    c.neg.local_binary = c.neg.remote_binary = True
    return c


def test_single_enter_applies_second_record():
    c = _client_ready()
    # host reply arrives as TWO separate reads: a message record, then the screen
    msg = _record(["A MESSAGE FROM THE HOST"], cursor=(1, 1))
    panel = _record(["OPTION MENU", "", "  1. Work with things",
                     "Selection or command"], cursor=(20, 7))
    c.sock = ScriptSock([msg, panel])
    c.move_to(20, 7); c.send_string("1")
    c.send_enter()                       # exactly one Enter
    text = c.screen.text()
    ok("final panel is shown after a single Enter", "OPTION MENU" in text)
    ok("Work-with line rendered", "Work with things" in text)
    ok("stale message record did not win", "A MESSAGE FROM THE HOST" not in text)


def test_single_record_reply_still_works():
    c = _client_ready()
    panel = _record(["MAIN MENU", "Selection or command"], cursor=(20, 7))
    c.sock = ScriptSock([panel])
    c.send_pf(3)                          # function key: single-record reply
    ok("single-record reply renders on the first send", "MAIN MENU" in c.screen.text())


def test_both_records_in_one_read():
    # the same two records delivered in a single TCP read must also both apply,
    # with the screen record winning
    c = _client_ready()
    msg = _record(["INTERIM MESSAGE"], cursor=(1, 1))
    panel = _record(["WORK WITH ACTIVE JOBS"], cursor=(1, 1))
    c.sock = ScriptSock([msg + panel])
    c.send_enter()
    ok("screen record wins when both arrive together",
       "WORK WITH ACTIVE JOBS" in c.screen.text())


def test_enter_clears_pending_once():
    # a resolved Enter must clear the queued field so a following bare Enter does
    # not re-transmit the same option (the duplicate '90' seen in the capture)
    c = _client_ready()
    panel = _record(["NEXT PANEL"], cursor=(20, 7))
    c.sock = ScriptSock([panel])
    c.move_to(20, 7); c.send_string("90")
    c.send_enter()
    ok("pending field cleared after a resolved Enter", c._pending == [])


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
