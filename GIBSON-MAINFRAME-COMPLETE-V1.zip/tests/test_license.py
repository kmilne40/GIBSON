"""License verification tests (self-contained: generates a keypair per run)."""
import base64
import json
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest

crypto = pytest.importorskip("cryptography")
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from phosphor.app import license as lic


def _b64u(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _mint(priv, email, skins, exp=None):
    payload = {"email": email.lower(), "skins": sorted(skins), "exp": exp}
    pb = _b64u(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    return "PHOS-" + pb + "." + _b64u(priv.sign(pb.encode()))


@pytest.fixture()
def keypair(monkeypatch):
    priv = Ed25519PrivateKey.generate()
    from cryptography.hazmat.primitives import serialization
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    monkeypatch.setattr(lic, "PUBLIC_KEY_B64", base64.b64encode(pub).decode())
    monkeypatch.setenv("XDG_CONFIG_HOME", tempfile.mkdtemp())
    return priv


def test_valid_license(keypair):
    tok = _mint(keypair, "a@b.com", ["amber", "enterprise"])
    ok, msg, payload = lic.verify_token(tok, "a@b.com")
    assert ok and set(payload["skins"]) == {"amber", "enterprise"}


def test_email_binding(keypair):
    tok = _mint(keypair, "a@b.com", ["amber"])
    ok, _m, _p = lic.verify_token(tok, "someone@else.com")
    assert not ok


def test_tamper_rejected(keypair):
    tok = _mint(keypair, "a@b.com", ["amber"])
    ok, _m, _p = lic.verify_token(tok[:-6] + "AAAAAA", "a@b.com")
    assert not ok


def test_forged_key_rejected(keypair):
    attacker = Ed25519PrivateKey.generate()
    tok = _mint(attacker, "a@b.com", ["enterprise", "darkops"])
    ok, _m, _p = lic.verify_token(tok, "a@b.com")
    assert not ok


def test_expired_rejected(keypair):
    tok = _mint(keypair, "a@b.com", ["amber"], exp=time.time() - 10)
    ok, msg, _p = lic.verify_token(tok, "a@b.com")
    assert not ok and "expired" in msg


def test_activate_and_entitlements(keypair):
    tok = _mint(keypair, "a@b.com", ["amber", "c64"])
    ok, _m, skins = lic.activate("a@b.com", tok)
    assert ok and {"amber", "c64"} <= skins
    ent = lic.entitlements()
    assert {"amber", "c64", "classic", "green", "lcars"} <= ent


def test_free_set_without_license(keypair):
    # no license file -> only free skins
    assert lic.entitlements() == set(lic.FREE_SKINS)


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
