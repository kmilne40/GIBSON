"""Boxed --client TUI: layout geometry + box dispatch (headless, no curses I/O)."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.client_panels import build_layout, GLASS_ROWS, GLASS_COLS
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor
from phosphor.client_tui import Console

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

# ---------------- layout ----------------
def test_layout_full():
    lay = build_layout(40, 130)
    ids = {b.id for b in lay.boxes}
    need = ["k_pf1", "k_pf13", "k_pf24", "k_pa1", "k_pa2", "k_pa3", "k_attn",
            "k_clear", "k_sysreq", "k_tab", "k_backtab", "k_reset", "k_newline",
            "k_enter", "b_menu", "b_settings", "b_help", "b_quit"]
    ok("kept operator keys present", all(n in ids for n in need))
    ok("24 PF cells", sum(1 for i in ids if i.startswith("k_pf")) == 24)
    ok("full chrome ok flag", lay.ok)
    # removed keys must be gone from the layout
    gone = ["k_home", "k_curselect", "k_compose", "k_insert", "k_delete",
            "k_dup", "k_fieldmark", "k_eeof", "k_einp"]
    ok("removed cluster keys absent", not any(g in ids for g in gone))

def test_glass_position_and_hit():
    lay = build_layout(40, 130)
    ok("glass top-left cell", lay.hit(lay.glass_y, lay.glass_x) == ("glass", 1, 1))
    ok("glass bottom-right cell",
       lay.hit(lay.glass_y + GLASS_ROWS - 1, lay.glass_x + GLASS_COLS - 1) == ("glass", 24, 80))
    b = lay.box("k_enter")
    ok("enter box hit-tests to itself", lay.hit(b.y, b.x) == "k_enter")

def test_nav_directions():
    lay = build_layout(40, 130)
    # single stacked right column: PA1 down -> PA2 -> Attn -> PA3 -> SysRq -> Clear
    ok("PA1 -> down = PA2", lay.neighbour("k_pa1", 1, 0) == "k_pa2")
    ok("PA2 -> down = Attn", lay.neighbour("k_pa2", 1, 0) == "k_attn")
    ok("SysRq -> down = Clear", lay.neighbour("k_sysreq", 1, 0) == "k_clear")
    ok("operator column sits right of the glass",
       lay.box("k_pa1").x >= lay.glass_x + GLASS_COLS)

def test_degrade_small():
    lay = build_layout(24, 88)
    ok("small terminal keeps glass usable", lay.glass_x >= 0 and lay.glass_y >= 0)
    ok("small terminal flags degraded", lay.ok is False and lay.reason != "")

# ---------------- box dispatch ----------------
class Rec(TN3270Client):
    """A client whose network AIDs are recorded instead of sent."""
    def __init__(self):
        super().__init__(); self.packets = []; self.sent = []
    def _aid(self, name): self.sent.append(name)
    def move_to(self, r, c): self.sent.append(("move", r, c))
    def send_string(self, t): self.sent.append(("str", t))
    def terminate(self): pass

def _console():
    c = Rec()
    stream  = bytes([ds.CMD_EW, 0xC0])
    stream += bytes([ds.SBA]) + ds.enc_addr(0)  + bytes([ds.SF, 0x00]) + "USER".encode("cp037")
    stream += bytes([ds.SBA]) + ds.enc_addr(20) + bytes([ds.SF, 0x00]) + "     ".encode("cp037")
    ds.DataStreamParser(c.screen).parse(stream)
    ed = FieldEditor(c)
    con = Console(c, ed, "host", 23, "3270")
    con.lay = build_layout(40, 130)
    return con, c, ed

def test_dispatch_pf_pa_enter_clear():
    con, c, ed = _console()
    con._apply(None, "k_pf3");   ok("PF3 sent", "PF3" in c.sent)
    con._apply(None, "k_pf13");  ok("PF13 sent", "PF13" in c.sent)
    con._apply(None, "k_pa2");   ok("PA2 sent", "PA2" in c.sent)
    con._apply(None, "k_attn");  ok("Attn -> PA1", "PA1" in c.sent)
    con._apply(None, "k_clear"); ok("Clear sent", "CLEAR" in c.sent)
    con._apply(None, "k_enter"); ok("Enter sent", "ENTER" in c.sent)

def test_dispatch_editing():
    con, c, ed = _console()
    # put cursor in the first field and type, then Home
    ed.cursor = (1, 3)
    for ch in "BOB": ed.type_char(ch)
    con._apply(None, "k_home")
    f = ed._field_at(*ed.cursor)
    ok("Home jumps to field start", ed.cursor == (f.row, f.col))
    # insert toggle
    con._apply(None, "k_insert"); ok("Insert on", con.insert is True)
    con._apply(None, "k_insert"); ok("Insert off", con.insert is False)
    # erase input clears edits
    con._apply(None, "k_einp"); ok("Erase Input clears edits", ed._edits == {})

def test_dispatch_dup_fieldmark_delete():
    con, c, ed = _console()
    f0 = ed.fields()[0]                       # first input field (starts col 2)
    ed.cursor = (f0.row, f0.col)
    for ch in "ABCD": ed.type_char(ch)
    ed.cursor = (f0.row, f0.col + 1)          # over 'B'
    con._apply(None, "k_delete")
    ok("Delete removes char under cursor", ed._edits[(f0.row, f0.col)].startswith("ACD"))
    from phosphor.client_tui import _FM
    f1 = ed.fields()[1]
    ed.cursor = (f1.row, f1.col)
    con._apply(None, "k_fieldmark")
    ok("Field Mark inserts marker", _FM in ed._edits.get((f1.row, f1.col), ""))

def test_quit_and_menu_ids():
    con, c, ed = _console()
    ok("Quit returns True", con._apply(None, "b_quit") is True)
    # cursor-select / compose / sysreq are honest no-ops with a status note
    con._apply(None, "k_curselect"); ok("Cursor Select noted", "Cursor Select" in con.msg)
    con._apply(None, "k_sysreq");    ok("SysReq noted", "SysReq" in con.msg)

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
