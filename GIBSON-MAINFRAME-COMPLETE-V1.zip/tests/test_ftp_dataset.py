"""FTP client: editable Dataset/HLQ field - list under an HLQ and download a typed dataset."""
import sys, os, types
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import phosphor.app.__main__ as M
M._run_bg = lambda fn: fn()
App = M.Client

_p=_f=0
def ok(n,c):
    global _p,_f
    if c:_p+=1;print("  ok  "+n)
    else:_f+=1;print(" FAIL "+n)

class FakeFTP:
    def __init__(self): self.got=None
    def list(self, path=""): return [f"{path}.A", f"{path}.B"] if path else ["DEF.LIST"]
    def get(self, dsn): self.got=dsn; return b"x"

def test_list_hlq():
    app=App.__new__(App); app.state=types.SimpleNamespace(ftp_dsn="SYS1",ftp_status="",ftp_list=[]); app._ftp=FakeFTP()
    app.ftp_list_hlq()
    ok("List HLQ uses the typed HLQ", app.state.ftp_list==["SYS1.A","SYS1.B"])
    ok("status names the HLQ", "SYS1" in app.state.ftp_status)

def test_download_typed():
    ftp=FakeFTP()
    app=App.__new__(App); app.state=types.SimpleNamespace(ftp_dsn="SYS1.PARMLIB",ftp_status="",field_cursor={}); app._ftp=ftp
    # stub the file dialog so no GUI is needed
    app._ftp_get = lambda dsn: ftp.get(dsn)
    app.ftp_download_dsn()
    ok("download uses the typed dataset", ftp.got=="SYS1.PARMLIB")

def test_guards():
    app=App.__new__(App); app.state=types.SimpleNamespace(ftp_dsn="",ftp_status=""); app._ftp=FakeFTP()
    app.ftp_download_dsn(); ok("empty dsn guarded", "type a dataset" in app.state.ftp_status)
    app2=App.__new__(App); app2.state=types.SimpleNamespace(ftp_dsn="SYS1",ftp_status=""); app2._ftp=None
    app2.ftp_list_hlq(); ok("not-connected guarded", "connect first" in app2.state.ftp_status)

if __name__=="__main__":
    for fn in (test_list_hlq,test_download_typed,test_guards):
        print("\n"+fn.__name__); fn()
    print(f"\nFTP dataset field: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
