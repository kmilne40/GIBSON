"""TLS cipher-profile tests: the mainframe/IBM i compat profile must reach a
legacy (TLS 1.0-only) but cert-valid host that the modern profile refuses."""
import os
import socket
import ssl
import sys
import tempfile
import threading
import time
import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols import tls as T

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def _make_cert():
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nm = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "mf")])
    cert = (x509.CertificateBuilder().subject_name(nm).issuer_name(nm)
            .public_key(key.public_key()).serial_number(1)
            .not_valid_before(datetime.datetime(2020, 1, 1))
            .not_valid_after(datetime.datetime(2035, 1, 1))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName("mf")]), False)
            .add_extension(x509.BasicConstraints(ca=True, path_length=None), True)
            .sign(key, hashes.SHA256()))
    d = tempfile.mkdtemp(); cf = d + "/c"; kf = d + "/k"
    open(cf, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(kf, "wb").write(key.private_bytes(serialization.Encoding.PEM,
                         serialization.PrivateFormat.TraditionalOpenSSL,
                         serialization.NoEncryption()))
    return cf, kf


def _tls10_server(cf, kf, port):
    sc = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    sc.load_cert_chain(cf, kf)
    try:
        sc.minimum_version = ssl.TLSVersion.TLSv1
        sc.maximum_version = ssl.TLSVersion.TLSv1      # legacy: TLS 1.0 only
    except (ValueError, OSError):
        pass
    try:
        sc.set_ciphers("AES128-SHA:@SECLEVEL=0")
    except ssl.SSLError:
        sc.set_ciphers("ALL:@SECLEVEL=0")
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port)); srv.listen(1); srv.settimeout(5)
    try:
        c, _ = srv.accept()
        try: sc.wrap_socket(c, server_side=True).close()
        except Exception: pass
    except Exception: pass
    srv.close()


def _connect(profile, port):
    threading.Thread(target=_tls10_server, args=(cf_kf[0], cf_kf[1], port), daemon=True).start()
    time.sleep(0.3)
    raw = socket.create_connection(("127.0.0.1", port), timeout=4)
    info = T.TLSInfo()
    T.wrap_socket(raw, "mf", verify=True, ca_file=cf_kf[0], cipher_profile=profile, info=info).close()
    return info


def test_profiles_defined():
    ok("MAINFRAME_CIPHERS defined", isinstance(T.MAINFRAME_CIPHERS, str) and "AES" in T.MAINFRAME_CIPHERS)
    ok("compat/mainframe/ibmi/legacy profiles exist",
       all(k in T._PROFILES for k in ("compat", "mainframe", "ibmi", "legacy", "modern")))


def test_mainframe_reaches_legacy_host():
    # modern profile must REFUSE a TLS 1.0-only host
    refused = False
    try:
        _connect("modern", 44811)
    except Exception:
        refused = True
    ok("modern profile refuses a TLS 1.0-only host", refused)

    # mainframe profile must REACH it, still verifying the certificate
    try:
        info = _connect("mainframe", 44812)
        ok("mainframe profile reaches the legacy host", info.active)
        ok("certificate still verified over the legacy profile", info.verified)
        ok("profile recorded on the connection", info.profile == "mainframe")
    except Exception as e:
        ok(f"mainframe profile reaches the legacy host (got {type(e).__name__})", False)


cf_kf = _make_cert()

if __name__ == "__main__":
    test_profiles_defined()
    test_mainframe_reaches_legacy_host()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
