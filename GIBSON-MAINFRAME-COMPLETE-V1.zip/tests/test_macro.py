"""Macro engine tests - a fake TN3270 session drives every verb, no live host."""
import os
import sys
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.macro import MacroEngine, MacroError, MacroTimeout, run_script
from phosphor.macro.recorder import transcript_to_script

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


class FakeClient:
    """A tiny scripted TN3270: LOGON -> (type applid, ENTER) -> PASSWORD ->
    (type password, ENTER) -> READY."""
    def __init__(self):
        self.state = "start"
        self.typed = []
        self.cursor = (1, 1)
        self.connected = False
        self.last_aid = None

    def connect(self, host, port=23, **kw):
        self.connected = True
        self.state = "logon"

    def terminate(self):
        self.connected = False

    def send_string(self, text):
        self.typed.append(text)

    def move_to(self, r, c):
        self.cursor = (r, c)

    def _advance(self, aid):
        self.last_aid = aid
        if aid != "ENTER":
            return
        joined = " ".join(self.typed).upper()
        if self.state == "logon" and "TSO" in joined:
            self.state = "password"; self.typed = []
        elif self.state == "password":
            self.state = "ready"; self.typed = []

    def send_enter(self): self._advance("ENTER")
    def send_clear(self): self._advance("CLEAR")
    def send_pf(self, n): self._advance(f"PF{n}")
    def send_pa(self, n): self._advance(f"PA{n}")

    def screen_get(self):
        return {
            "start": ["", ""],
            "logon": ["  TSO/E LOGON", "  ENTER LOGON APPLID"],
            "password": ["  ENTER PASSWORD -", "  PASSWORD ==>"],
            "ready": ["  IKJ56455I  LOGON IN PROGRESS", "  READY"],
        }[self.state]

    def find(self, text):
        return text.upper() in "\n".join(self.screen_get()).upper()


def test_full_logon_macro():
    fake = FakeClient()
    m = MacroEngine(client=fake, default_timeout=1.0)
    m.connect("192.168.0.96", 23)
    m.wait_for("LOGON APPLID")
    m.string("LOGON APPLID(TSO)")
    m.key("ENTER")
    m.wait_for("PASSWORD")
    m.string("hunter2")
    m.key("ENTER")
    m.wait_for("READY")
    ok("full logon reached READY", fake.state == "ready")
    m.expect("READY")
    ok("expect READY passes", True)


def test_key_mapping():
    fake = FakeClient(); fake.connect("h")
    m = MacroEngine(client=fake)
    for k, want in [("PF3", "PF3"), ("PA1", "PA1"), ("CLEAR", "CLEAR"), ("PF13", "PF13"), ("enter", "ENTER")]:
        m.key(k)
        ok(f"key {k} -> {want}", fake.last_aid == want)
    try:
        m.key("BOGUS"); ok("bad key rejected", False)
    except MacroError:
        ok("bad key rejected", True)


def test_wait_for_timeout():
    fake = FakeClient(); fake.connect("h")
    m = MacroEngine(client=fake, default_timeout=0.3)
    try:
        m.wait_for("NEVERAPPEARS", timeout=0.3)
        ok("wait_for times out", False)
    except MacroTimeout:
        ok("wait_for times out", True)


def test_expect_failure():
    fake = FakeClient(); fake.connect("h")
    m = MacroEngine(client=fake)
    try:
        m.expect("NOTHERE"); ok("expect raises when missing", False)
    except MacroError:
        ok("expect raises when missing", True)


def test_script_runner_and_save():
    fake = FakeClient()
    tmp = tempfile.mkdtemp(); out = os.path.join(tmp, "ready.txt")
    script = f"""
    # log on and capture
    connect 192.168.0.96 23
    wait_for LOGON APPLID
    string LOGON APPLID(TSO)
    key ENTER
    wait_for PASSWORD
    string hunter2
    key ENTER
    wait_for READY
    expect READY
    snapshot logged-in
    save_screen {out}
    disconnect
    """
    eng = run_script(script, client=fake, default_timeout=1.0)
    ok("script reached READY", fake.state == "ready")
    ok("save_screen wrote file", os.path.isfile(out) and "READY" in open(out).read())
    ok("snapshot captured a screen", any(e.get("screen") for e in eng.transcript))


def test_recorder_roundtrip():
    fake = FakeClient()
    m = MacroEngine(client=fake, default_timeout=1.0)
    m.connect("10.0.0.9", 992, tls=True, verify=False, cipher_profile="mainframe")
    m.wait_for("LOGON APPLID"); m.enter("LOGON APPLID(TSO)")
    script = transcript_to_script(m)
    ok("recorded connect has tls+noverify+profile",
       "connect 10.0.0.9 992 tls noverify profile=mainframe" in script)
    ok("enter expands to string + key ENTER in the recording",
       "string LOGON APPLID(TSO)" in script and "key ENTER" in script)
    # and the recorded script re-runs on a fresh fake
    fake2 = FakeClient()
    run_script(script, client=fake2, default_timeout=1.0)
    ok("recorded script replays", fake2.state in ("password", "ready"))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
