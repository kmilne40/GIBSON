"""Negotiated TELNET START-TLS (RFC 2946).

Two levels:
  * negotiator unit - DO START-TLS -> WILL, SB FOLLOWS -> SB FOLLOWS + start_tls flag.
  * full client integration - a server negotiates START-TLS in the clear, both sides
    exchange FOLLOWS, the server wraps TLS, and the client must transparently wrap and
    finish TN3270 negotiation over the encrypted channel (tls_info.active).
"""
import os, sys, ssl, socket, threading, datetime, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270.telnet import (Negotiator, IAC, DO, WILL, SB, SE,
                                              OPT_START_TLS, STARTTLS_FOLLOWS,
                                              OPT_BINARY, OPT_EOR, OPT_TTYPE)
from phosphor.protocols.tn3270.client import TN3270Client

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def test_negotiator_starttls_logic():
    n = Negotiator(want_starttls=True)
    reply, _, _ = n.feed(bytes([IAC, DO, OPT_START_TLS]))
    ok("DO START-TLS -> WILL START-TLS", reply == bytes([IAC, WILL, OPT_START_TLS]))
    reply2, _, _ = n.feed(bytes([IAC, SB, OPT_START_TLS, STARTTLS_FOLLOWS, IAC, SE]))
    ok("SB FOLLOWS -> SB FOLLOWS reply",
       reply2 == bytes([IAC, SB, OPT_START_TLS, STARTTLS_FOLLOWS, IAC, SE]))
    ok("start_tls flag raised for the caller to wrap", n.start_tls is True)


def test_negotiator_declines_when_not_wanted():
    n = Negotiator(want_starttls=False)
    reply, _, _ = n.feed(bytes([IAC, DO, OPT_START_TLS]))
    ok("declines START-TLS with WONT when not wanted", reply[-2:] == bytes([0xFC, OPT_START_TLS]))


def _self_signed():
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nm = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "mvs")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(nm).issuer_name(nm)
            .public_key(key.public_key()).serial_number(1)
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=1)).sign(key, hashes.SHA256()))
    cf = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    kf = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
    cf.write(cert.public_bytes(serialization.Encoding.PEM)); cf.close()
    kf.write(key.private_bytes(serialization.Encoding.PEM,
             serialization.PrivateFormat.TraditionalOpenSSL,
             serialization.NoEncryption())); kf.close()
    return cf.name, kf.name


class _StartTlsServer:
    """Negotiate START-TLS in the clear, wrap TLS, then finish TN3270 negotiation."""
    def __init__(self, cf, kf):
        self.cf, self.kf = cf, kf
        self.sock = socket.socket(); self.sock.bind(("127.0.0.1", 0)); self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.ok_tls = False
        threading.Thread(target=self._serve, daemon=True).start()

    def _recv_until(self, s, marker, limit=200):
        buf = b""
        while marker not in buf and len(buf) < limit:
            try:
                d = s.recv(64)
            except (ssl.SSLError, OSError):
                break
            if not d: break
            buf += d
        return buf

    def _serve(self):
        try:
            c, _ = self.sock.accept()
            c.settimeout(5)
            c.sendall(bytes([IAC, DO, OPT_START_TLS]))       # ask client to STARTTLS
            self._recv_until(c, bytes([IAC, WILL, OPT_START_TLS]))
            c.sendall(bytes([IAC, SB, OPT_START_TLS, STARTTLS_FOLLOWS, IAC, SE]))
            self._recv_until(c, bytes([IAC, SE]))
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(self.cf, self.kf)
            tls = ctx.wrap_socket(c, server_side=True)
            self.ok_tls = True
            # now the normal TN3270 negotiation, over TLS
            tls.sendall(bytes([IAC, DO, OPT_BINARY, IAC, DO, OPT_EOR, IAC, DO, OPT_TTYPE,
                               IAC, WILL, OPT_BINARY, IAC, WILL, OPT_EOR]))
            self._recv_until(tls, bytes([IAC, SE]) )          # WILLs / DOs
            tls.sendall(bytes([IAC, SB, OPT_TTYPE, 0x01, IAC, SE]))   # TTYPE SEND
            self._recv_until(tls, bytes([IAC, SE]))           # TTYPE IS
            # a minimal 3270 screen (EW + a byte) terminated by IAC EOR
            tls.sendall(bytes([0xF5, 0xC3, 0x40]) + bytes([IAC, 0xEF]))
            import time; time.sleep(0.5)
            tls.close()
        except Exception:
            pass


def test_full_client_starttls():
    cf, kf = _self_signed()
    srv = _StartTlsServer(cf, kf)
    try:
        cli = TN3270Client(); cli.packets = []
        cli.read_timeout = 2.0
        cli.connect("127.0.0.1", srv.port, tls_starttls=True, tls_verify=False)
        ok("server completed the TLS wrap", srv.ok_tls)
        ok("client negotiated STARTTLS and encrypted the session",
           cli.tls_info.active and cli.neg.starttls_done)
        ok("client recorded it as unverified (no-verify test cert)", not cli.tls_info.verified)
    except Exception as e:
        ok(f"full STARTTLS client [{e!r}]", False)
    finally:
        os.unlink(cf); os.unlink(kf)
        try: srv.sock.close()
        except OSError: pass


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
