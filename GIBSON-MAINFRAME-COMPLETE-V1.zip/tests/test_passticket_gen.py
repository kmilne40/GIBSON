"""RACF PassTicket generation.

The golden vectors below were validated byte-for-byte against GIBSON's reference
generator (gibson/assets/passticket/gen_passticket.py, itself a faithful port of the
IBM SKALGO/ALGOR algorithm) at a fixed timestamp. If the algorithm ever drifts these
will catch it.
"""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import passticket as PT

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

FIXED = 1700000000
# (userid, applid, secured-signon key hex) -> expected 8-char PassTicket at FIXED
GOLDEN = [
    ("IBMUSER", "CICSPA01", "E001193519561977", "JVZQAMLS"),
    ("ADMIN",   "IMSPROD",  "0123456789ABCDEF", "EEDP1WGK"),
    ("DADE",    "TSO",      "A1B2C3D4E5F60718", "GCGDUMHW"),
]


def test_golden_vectors_match_gibson():
    for u, a, k, expect in GOLDEN:
        got = PT.generate_passticket(u, a, k, when=FIXED)
        ok(f"{u}/{a} -> {expect}", got == expect)


def test_deterministic():
    a = PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED)
    b = PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED)
    ok("same inputs -> same ticket", a == b)


def test_time_bound():
    a = PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED)
    b = PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED + 1)
    ok("different second -> different ticket (time-bound)", a != b)


def test_shape():
    t = PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED)
    ok("8 characters", len(t) == 8)
    ok("all in the PassTicket alphabet", all(c in PT.PT_ALPHABET for c in t))
    # and the classifier recognises what the generator produced
    kind, _ = PT.classify_credential(t)
    ok("generated ticket classifies as passticket-shaped", kind in ("passticket", "password"))


def test_window():
    w = PT.passticket_window("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED, spread=2)
    ok("window returns 2*spread+1 tickets", len(w) == 5)
    ok("window centre matches point generate", dict(w)[0] ==
       PT.generate_passticket("IBMUSER", "CICSPA01", "E001193519561977", when=FIXED))


def test_bad_key_rejected():
    try:
        PT.generate_passticket("IBMUSER", "CICSPA01", "ABCD")   # too short
        ok("short key rejected", False)
    except ValueError:
        ok("short key rejected", True)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
