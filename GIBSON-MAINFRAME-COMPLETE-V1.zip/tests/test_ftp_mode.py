"""FTP transfer mode: binary (TYPE I) vs ascii (TYPE A) routing."""
import sys, os, io
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.ftp.client import MainframeFTP


class FakeInner:
    """Stand-in for ftplib.FTP that records which transfer path was used."""
    def __init__(self): self.cmds = []; self.calls = []
    def voidcmd(self, c): self.cmds.append(c); return "200 " + c
    def retrbinary(self, cmd, cb, *a, **k):
        self.calls.append(("retrbinary", cmd)); cb(b"\x00\x01\x02")
    def retrlines(self, cmd, cb, *a, **k):
        self.calls.append(("retrlines", cmd)); cb("HELLO"); cb("WORLD")
    def storbinary(self, cmd, fp, *a, **k):
        self.calls.append(("storbinary", cmd, fp.read())); return "226 ok"
    def storlines(self, cmd, fp, *a, **k):
        self.calls.append(("storlines", cmd, fp.read())); return "226 ok"


def _client(mode):
    c = MainframeFTP(mode=mode); c.ftp = FakeInner(); return c


def test_default_binary():
    c = _client("binary")
    assert c.mode == "binary"
    data = c.get("IBMUSER.LOAD")
    assert c.ftp.calls[0][0] == "retrbinary"       # raw bytes path
    assert data == b"\x00\x01\x02"


def test_ascii_get_translates_to_lines():
    c = _client("ascii")
    data = c.get("IBMUSER.TEXT")
    assert c.ftp.calls[0][0] == "retrlines"        # host does EBCDIC->ASCII
    assert data == b"HELLO\nWORLD\n"


def test_set_mode_sends_type_and_switches_path():
    c = _client("binary")
    c.set_mode("ascii")
    assert "TYPE A" in c.ftp.cmds
    c.put("IBMUSER.TEXT", b"line1\nline2\n")
    assert c.ftp.calls[-1][0] == "storlines"
    c.set_mode("binary")
    assert "TYPE I" in c.ftp.cmds
    c.put("IBMUSER.LOAD", b"\x00\xff")
    assert c.ftp.calls[-1][0] == "storbinary"


def test_per_call_override():
    c = _client("binary")
    c.get("A", mode="ascii")
    assert c.ftp.calls[-1][0] == "retrlines"        # override without changing default
    assert c.mode == "binary"


if __name__ == "__main__":
    for fn in (test_default_binary, test_ascii_get_translates_to_lines,
               test_set_mode_sends_type_and_switches_path, test_per_call_override):
        fn(); print("ok", fn.__name__)
    print("all passed")
