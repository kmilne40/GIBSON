"""Regression: real z/OS orders (EUA, GE, MF) + null handling.

These orders are emitted constantly by ISPF.  Before the fix they were treated
as ordinary bytes: the order byte and its operands rendered as box glyphs and,
worse, the buffer address never advanced, so everything after desynced and the
field map (hence TAB) broke.  Nulls also rendered as boxes instead of blanks.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.core.screen import ScreenBuffer
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

def _render(stream):
    s = ScreenBuffer(); ds.DataStreamParser(s).parse(stream); return s

def _has_boxes(text):
    return any(ord(c) < 0x20 or 0x7f <= ord(c) <= 0x9f or c == "\u25a1" for c in text)

def test_null_and_control_render_blank():
    s = bytes([ds.CMD_EW, 0xC0]) + bytes([ds.SBA]) + ds.enc_addr(0)
    s += "Settings".encode("cp037") + bytes([0, 0, 0, 0, 0]) + "Terminal".encode("cp037")
    row0 = _render(s).row_text(1)
    ok("no box/control glyphs from nulls", not _has_boxes(row0))
    ok("text around the nulls intact", "Settings" in row0 and "Terminal" in row0)

def test_eua_erases_unprotected_keeps_alignment():
    s = bytes([ds.CMD_EW, 0xC0])
    s += bytes([ds.SBA]) + ds.enc_addr(0) + bytes([ds.SF, 0x00]) + "XXXXX".encode("cp037")
    s += bytes([ds.SBA]) + ds.enc_addr(1) + bytes([ds.EUA]) + ds.enc_addr(10)
    s += bytes([ds.SBA]) + ds.enc_addr(20) + "ALIGNED".encode("cp037")
    row0 = _render(s).row_text(1)
    ok("EUA nulled the unprotected field", "X" not in row0)
    ok("text after EUA stays aligned", row0[20:27] == "ALIGNED")

def test_eua_preserves_protected():
    s = bytes([ds.CMD_EW, 0xC0])
    s += bytes([ds.SBA]) + ds.enc_addr(0) + bytes([ds.SF, 0x20]) + "KEEP".encode("cp037")
    s += bytes([ds.SBA]) + ds.enc_addr(1) + bytes([ds.EUA]) + ds.enc_addr(10)
    ok("EUA leaves protected text", "KEEP" in _render(s).row_text(1))

def test_ge_renders_glyph_and_aligns():
    s = bytes([ds.CMD_EW, 0xC0]) + bytes([ds.SBA]) + ds.enc_addr(0)
    s += bytes([ds.GE, 0xC5]) + "AB".encode("cp037")
    row0 = _render(s).row_text(1)
    ok("GE box-draw glyph rendered", row0[0] == "\u250c")
    ok("text after GE stays aligned", row0[1:3] == "AB")

def test_mf_keeps_alignment():
    s = bytes([ds.CMD_EW, 0xC0]) + bytes([ds.SBA]) + ds.enc_addr(0)
    s += bytes([ds.MF, 0x01, 0xC0, 0x20]) + "AB".encode("cp037")
    ok("text after MF stays aligned", _render(s).row_text(1)[1:3] == "AB")

def test_fields_and_tab_after_mixed_orders():
    # a screen using EUA + nulls should still expose the one input field cleanly
    c = TN3270Client(); c.packets = []
    s = bytes([ds.CMD_EW, 0xC0])
    s += bytes([ds.SBA]) + ds.enc_addr(0) + bytes([ds.SF, 0x20]) + "Option".encode("cp037")
    s += bytes([0, 0, 0]) + bytes([ds.SBA]) + ds.enc_addr(20) + bytes([ds.SF, 0x00])
    s += bytes([ds.SBA]) + ds.enc_addr(21) + bytes([ds.EUA]) + ds.enc_addr(60)
    ds.DataStreamParser(c.screen).parse(s)
    ed = FieldEditor(c)
    inp = [(f.row, f.col) for f in ed.input_fields()]
    ok("exactly one input field detected", len(inp) == 1)
    ed.cursor = inp[0]
    ed.tab()
    ok("tab on single field stays put (no desync)", ed.cursor == inp[0])

if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
