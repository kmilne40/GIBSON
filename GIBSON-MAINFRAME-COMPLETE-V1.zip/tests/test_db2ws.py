"""DB2 WebSocket client (GIBSON port 50001).

Drives PHOSPHOR's dependency-free RFC 6455 client against a real `websockets` server
(the same library GIBSON uses) that mimics GIBSON's DB2 shell: greeting, LOGIN check,
then command/response. Confirms the handshake, masked text frames, login success and
failure, a SQL round-trip, and ping/pong keepalive.
"""
import os, sys, asyncio, threading, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.db2ws import Db2WsClient, WsError

# `websockets` is only needed to run the TEST server (the db2ws client itself is
# dependency-free). If it isn't installed, skip rather than fail the suite.
try:
    import websockets  # noqa: F401
    _HAVE_WS = True
except Exception:
    _HAVE_WS = False

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


def _server_or_skip(label):
    """Start the test server, or return None (and record a skip) if it can't run."""
    if not _HAVE_WS:
        ok(f"{label} (skipped - websockets not installed)", True); return None
    srv = _Server()
    if srv.port is None:
        ok(f"{label} (skipped - test server did not start)", True); return None
    return srv


class _Server:
    """A GIBSON-shaped DB2 WebSocket server on a background asyncio loop."""
    USERS = {"IBMUSER": "SYS1"}

    def __init__(self):
        self.port = None
        self._ready = threading.Event()
        self.loop = None
        self.t = threading.Thread(target=self._run, daemon=True); self.t.start()
        self._ready.wait(5)

    def _run(self):
        import websockets
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

        async def handler(ws):
            await ws.send("Welcome to DB2/zOS simulator.\nLogin: LOGIN <username> <password>")
            authed = False
            async for msg in ws:
                cmd = msg.strip()
                if not authed:
                    p = cmd.split()
                    if len(p) == 3 and p[0].upper() == "LOGIN":
                        if self.USERS.get(p[1].upper()) == p[2]:
                            authed = True
                            await ws.send(f"Login successful. Welcome, {p[1].upper()}. Type HELP")
                        else:
                            await ws.send("Login failed: Unknown user or bad password.")
                    else:
                        await ws.send("Please login first. Format: LOGIN <username> <password>")
                    continue
                if cmd.upper().startswith("SELECT CURRENT SQLID"):
                    await ws.send("SQLID     SERVER\nIBMUSER   DALLASC\n1 row")
                elif cmd.upper() == "HELP":
                    await ws.send("Commands: SELECT ..., HELP, QUIT")
                elif cmd.upper() in ("QUIT", "EXIT"):
                    await ws.send("Goodbye"); break
                else:
                    await ws.send(f"OK: {cmd}")

        async def main():
            import websockets
            server = await websockets.serve(handler, "127.0.0.1", 0)
            self.port = server.sockets[0].getsockname()[1]
            self._ready.set()
            await asyncio.Future()

        try:
            self.loop.run_until_complete(main())
        except Exception:
            self._ready.set()


def test_connect_and_greeting():
    srv = _server_or_skip("db2ws greeting")
    if srv is None: return
    c = Db2WsClient("127.0.0.1", srv.port)
    g = c.connect()
    ok("handshake + greeting received", "DB2/zOS simulator" in g)
    c.close()


def test_login_success_and_sql():
    srv = _server_or_skip("db2ws login+sql")
    if srv is None: return
    c = Db2WsClient("127.0.0.1", srv.port)
    c.connect()
    good, reply = c.login("IBMUSER", "SYS1")
    ok("login success detected", good and "Login successful" in reply)
    ok("client records userid", c.userid == "IBMUSER")
    out = c.command("SELECT CURRENT SQLID, CURRENT SERVER FROM SYSIBM.SYSDUMMY1")
    ok("SQL round-trip returns rows", "DALLASC" in out)
    ok("HELP works", "Commands" in c.command("HELP"))
    c.close()


def test_login_failure():
    srv = _server_or_skip("db2ws login failure")
    if srv is None: return
    c = Db2WsClient("127.0.0.1", srv.port)
    c.connect()
    good, reply = c.login("IBMUSER", "wrongpw")
    ok("bad password rejected", (not good) and "failed" in reply.lower())
    c.close()


def test_larger_payload_frames():
    # exercise the 126-length extended frame path with a >125 byte message
    srv = _server_or_skip("db2ws large frames")
    if srv is None: return
    c = Db2WsClient("127.0.0.1", srv.port)
    c.connect(); c.login("IBMUSER", "SYS1")
    big = "SELECT " + "X" * 300
    out = c.command(big)
    ok("long statement echoes back in full", out.strip().endswith("X" * 300))
    c.close()


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
            except Exception as e:
                ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
