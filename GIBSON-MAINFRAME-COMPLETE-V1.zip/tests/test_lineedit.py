"""Tests for Phase 2 - the line editor and the in-client tools-directory files.

Run: python3 tests/test_lineedit.py
"""
import sys, os, tempfile
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from phosphor.app.lineedit import LineEditor

_p = _f = 0
def ok(name, cond):
    global _p, _f
    if cond: _p += 1; print("  ok  " + name)
    else: _f += 1; print(" FAIL " + name)


def test_insert_mid_string():
    e = LineEditor("nmap tso-enum 192.168.0.248")
    for _ in range(13):
        e.key(None, "left")
    e.key("X", None)
    ok("insert at cursor", "X" in e.text and e.text.endswith("192.168.0.248"))
    ok("cursor advanced", e.cursor >= 1)


def test_home_end_left_right():
    e = LineEditor("abcdef")
    e.key(None, "home"); ok("home", e.cursor == 0)
    e.key(None, "end"); ok("end", e.cursor == 6)
    e.key(None, "left"); e.key(None, "left"); ok("left twice", e.cursor == 4)
    e.key(None, "right"); ok("right", e.cursor == 5)


def test_backspace_and_delete_at_cursor():
    e = LineEditor("users.txt")
    for _ in range(4):
        e.key(None, "left")            # cursor before '.'
    e.key(None, "backspace"); ok("backspace before cursor", e.text == "user.txt")
    e.key(None, "delete"); ok("delete at cursor", e.text == "usertxt")


def test_overwrite_mode():
    e = LineEditor("abc", cursor=0, insert=False)
    e.key("X", None)
    ok("overwrite replaces", e.text == "Xbc")
    e.key(None, "insert"); e.key("Y", None)
    ok("toggle back to insert", e.text == "XYbc")


def test_word_jump():
    e = LineEditor("nmap -p 23 host"); e.key(None, "home")
    e.key(None, "right", ctrl=True)
    ok("ctrl-right jumps a word", e.cursor == 4)
    e.key(None, "backspace", ctrl=True)
    ok("ctrl-backspace deletes a word", e.text.startswith(" -p"))


def test_tools_dir_files():
    os.environ["PHOSPHOR_TOOLS_DIR"] = tempfile.mkdtemp()
    from phosphor.app import notes
    p = notes.save_tool_file("users.txt", "IBMUSER\nSYSADM\nGUEST")
    ok("save returns path", p and p.endswith("users.txt"))
    ok("load round-trips", "IBMUSER" in notes.load_tool_file("users.txt"))
    ok("appears in listing", "users.txt" in notes.list_tool_files())
    p2 = notes.save_tool_file("../../etc/evil.txt", "x")
    ok("path traversal confined", os.path.basename(p2) == "evil.txt" and "/etc/" not in p2)


if __name__ == "__main__":
    for fn in (test_insert_mid_string, test_home_end_left_right,
               test_backspace_and_delete_at_cursor, test_overwrite_mode,
               test_word_jump, test_tools_dir_files):
        print("\n" + fn.__name__); fn()
    print(f"\nPhase 2 (line editor + tools files): {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
