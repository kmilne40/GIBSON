"""Local shell console (the Shell button).

Binds the real Client._run_localshell to a light stub and checks the built-ins (cd
persists, clear, unknown dir) and that a real command runs in the tracked cwd and
streams output into the scrollback.
"""
import os, sys, types, tempfile, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# import the Client class without starting pygame
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import phosphor.app.__main__ as M

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)


class _State:
    def __init__(self):
        self.console_lines = []
        self.console_cmd = ""
        self.field_cursor = {"console_cmd": 0}
        self.focus = ""


class _Stub:
    """Minimal object carrying the real _run_localshell method."""
    def __init__(self, cwd):
        self.state = _State()
        self._shell = None
        self._shell_cwd = cwd
    def console_line(self, text):
        self.state.console_lines.append(text)


# run background work synchronously so tests are deterministic
M._run_bg = lambda fn: fn()

_run_localshell = M.Client._run_localshell


def _mk(cwd):
    s = _Stub(cwd)
    return s


def test_cd_persists():
    tmp = tempfile.mkdtemp()
    sub = os.path.join(tmp, "inner"); os.mkdir(sub)
    s = _mk(tmp)
    _run_localshell(s, "cd inner")
    ok("cd changes the tracked cwd", s._shell_cwd == sub)
    _run_localshell(s, "cd ..")
    ok("cd .. goes back up", s._shell_cwd == tmp)


def test_cd_bad_dir():
    tmp = tempfile.mkdtemp()
    s = _mk(tmp)
    _run_localshell(s, "cd /no/such/place/xyz")
    ok("cd to a missing dir is reported", any("no such directory" in l for l in s.state.console_lines))
    ok("cwd unchanged on bad cd", s._shell_cwd == tmp)


def test_clear():
    s = _mk(tempfile.mkdtemp())
    s.state.console_lines = ["a", "b", "c"]
    _run_localshell(s, "clear")
    ok("clear empties then re-prompts", len(s.state.console_lines) <= 1)


def test_command_runs_in_cwd():
    tmp = tempfile.mkdtemp()
    with open(os.path.join(tmp, "marker.txt"), "w") as f:
        f.write("x")
    s = _mk(tmp)
    _run_localshell(s, "ls")
    out = "\n".join(s.state.console_lines)
    ok("command runs and lists the cwd", "marker.txt" in out)
    ok("exit status shown", any(l.startswith("[exit ") for l in s.state.console_lines))


def test_echo_output_streams():
    s = _mk(tempfile.mkdtemp())
    _run_localshell(s, "echo hello_phosphor")
    ok("stdout captured", any("hello_phosphor" in l for l in s.state.console_lines))


def test_listen_without_crashing():
    # `listen` should try to start the reverse-shell listener; stub it so no socket binds
    s = _mk(tempfile.mkdtemp())
    called = {}
    s._start_reverse_listener = types.MethodType(
        lambda self, ep: called.setdefault("ep", ep), s)
    _run_localshell(s, "listen 127.0.0.1:5555")
    ok("listen routes to the reverse-shell listener", called.get("ep") == "127.0.0.1:5555")


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
