"""Regression: non-display (password/MFA) fields must never render in plaintext."""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.client import TN3270Client
from phosphor.protocols.tn3270.fields import FieldEditor

_p=_f=0
def ok(n,c):
    global _p,_f
    if c: _p+=1; print("  ok  "+n)
    else: _f+=1; print(" FAIL "+n)

def _screen_with_hidden():
    stream  = bytes([ds.CMD_EW, 0xC0])
    stream += bytes([ds.SBA])+ds.enc_addr(0)+bytes([ds.SF, 0x00])+"USER".encode("cp037")   # visible
    stream += bytes([ds.SBA])+ds.enc_addr(20)+bytes([ds.SF, 0x0C])+"SECRET".encode("cp037") # hidden
    c = TN3270Client(); c.packets=[]
    ds.DataStreamParser(c.screen).parse(stream)
    return FieldEditor(c)

def test_host_content_masked():
    ed=_screen_with_hidden()
    row0="".join(ch for ch,_ in ed.grid_with_edits()[0])
    ok("visible field shows", "USER" in row0)
    ok("hidden host content masked", "SECRET" not in row0)

def test_typed_password_masked():
    ed=_screen_with_hidden(); ed.cursor=(1,22)
    for ch in "MYPASS": ed.type_char(ch)
    row0="".join(ch for ch,_ in ed.grid_with_edits()[0])
    ok("typed password not rendered", "MYPASS" not in row0)

def test_visible_field_not_masked():
    ed=_screen_with_hidden(); ed.cursor=(1,6)
    for ch in "BOB": ed.type_char(ch)
    row0="".join(ch for ch,_ in ed.grid_with_edits()[0])
    ok("typing in a visible field still shows", "BOB" in row0)

if __name__=="__main__":
    for fn in (test_host_content_masked, test_typed_password_masked, test_visible_field_not_masked):
        print("\n"+fn.__name__); fn()
    print(f"\nHidden-field masking: {_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
