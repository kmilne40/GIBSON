"""Native DRDA client (DB2 for z/OS fingerprint + credential test).

Drives PHOSPHOR's DRDA client against GIBSON's *actual* DRDA server codec
(gibson/net/drda.py respond()), so the DSS/DDM framing is validated end to end:
EXCSAT->EXCSATRD fingerprint, ACCSEC, and SECCHK credential accept/reject.
"""
import os, sys, socket, threading
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from phosphor.protocols.drda import client as D

_p = _f = 0
def ok(n, c):
    global _p, _f
    if c: _p += 1; print("  ok  " + n)
    else: _f += 1; print(" FAIL " + n)

# --- load GIBSON's real DRDA server if present -------------------------------
_G = None
for cand in ("/tmp/gibson_v2", "/tmp/gibson_x"):
    if os.path.isdir(os.path.join(cand, "gibson")):
        sys.path.insert(0, cand)
        try:
            from gibson.net import drda as _G   # noqa
        except Exception:
            _G = None
        break


class _FakeRacf:
    USERS = {"IBMUSER": "SYS1", "ADMIN": "ADMINPW"}
    def verify_password(self, u, p): return self.USERS.get(u.upper()) == p
    def load(self, **k): pass


class _FakeDb2:
    def run_sql(self, sql, userid="IBMUSER"):
        if "SYSTABLES" in sql.upper():
            return [{"NAME": "EMP", "CREATOR": "DSN8"}, {"NAME": "DEPT", "CREATOR": "DSN8"}]
        if "SYSDUMMY1" in sql.upper():
            return [{"SQLID": userid, "SERVER": "GIBSONDB2"}]
        return [{"RESULT": "ok"}]


class _FakeState:
    def __init__(self): self.racf = _FakeRacf(); self.db2 = _FakeDb2(); self.current_user = "IBMUSER"
    def record_security_event(self, *a, **k): pass
    def note_port_touch(self, *a, **k): pass


class _GibsonDrdaServer:
    def __init__(self):
        self.sock = socket.socket(); self.sock.bind(("127.0.0.1", 0)); self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        self.state = _FakeState()
        threading.Thread(target=self._serve, daemon=True).start()
    def _serve(self):
        while True:
            try: c, _ = self.sock.accept()
            except OSError: return
            threading.Thread(target=self._handle, args=(c,), daemon=True).start()
    def _handle(self, c):
        try:
            c.settimeout(4)
            while True:
                data = c.recv(65535)
                if not data: break
                reply = _G.respond(data, self.state)
                if reply: c.sendall(reply)
        except Exception:
            pass
        finally:
            try: c.close()
            except Exception: pass


def _need_gibson():
    if _G is None:
        ok("GIBSON DRDA server available (skipped - source not at /tmp/gibson_x)", True)
        return False
    return True


def test_fingerprint():
    if not _need_gibson(): return
    srv = _GibsonDrdaServer()
    r = D.probe("127.0.0.1", srv.port)
    ok("server reachable + recognised as DRDA", r.reachable and r.is_drda)
    ok("fingerprint has a DB2 class name", "DB2" in (r.srvclsnm or "").upper())
    ok("fingerprint has a release level", bool(r.srvrlslv))
    ok("finding names the DB2 server", any("DB2" in f for f in r.findings))


def test_credentials_accepted():
    if not _need_gibson(): return
    srv = _GibsonDrdaServer()
    r = D.probe("127.0.0.1", srv.port, userid="IBMUSER", password="SYS1")
    ok("valid credentials accepted (SECCHKCD 0x00)", r.auth_ok is True)
    ok("accepted finding raised", any("ACCEPTED" in f for f in r.findings))


def test_credentials_rejected():
    if not _need_gibson(): return
    srv = _GibsonDrdaServer()
    r = D.probe("127.0.0.1", srv.port, userid="IBMUSER", password="WRONGPW")
    ok("bad password rejected", r.auth_ok is False)
    ok("secchkcd is the invalid-password code", r.secchkcd == 0x0F)


def test_spray():
    if not _need_gibson(): return
    srv = _GibsonDrdaServer()
    creds = [("IBMUSER", "nope"), ("ADMIN", "ADMINPW"), ("NOBODY", "x")]
    hits = D.spray("127.0.0.1", creds, port=srv.port)
    got = {h.host and r.srvnam for r in hits for h in [r]}  # noqa
    ok("spray finds exactly the valid pair", len(hits) == 1 and hits[0].auth_ok)


def test_framing_roundtrip():
    # our request encoder + reply parser agree on the wire shape
    req = D.build_secchk("IBMUSER", "SYS1", rdbnam="GIBSONDB2")
    ok("SECCHK request is a DSS (0xD0 magic)", req[2] == 0xD0)
    cp, params = D.parse_reply(D.build_excsat())   # parse a request as if a reply (shape check)
    ok("DDM codepoint parses back", cp == D.EXCSAT)


def _real_state():
    """Build a real GibsonState (respond_sql constructs Db2Simulator(state), which needs
    the real thing). Returns None if GIBSON isn't importable."""
    try:
        from gibson.cli import build_state
        class _A:
            def __getattr__(self, k): return None
        return build_state(_A())
    except Exception:
        return None


class _RealStateDrdaServer:
    def __init__(self, state):
        self.state = state
        self.sock = socket.socket(); self.sock.bind(("127.0.0.1", 0)); self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()
    def _serve(self):
        while True:
            try: c, _ = self.sock.accept()
            except OSError: return
            threading.Thread(target=self._h, args=(c,), daemon=True).start()
    def _h(self, c):
        try:
            c.settimeout(4)
            while True:
                data = c.recv(65535)
                if not data: break
                r = _G.respond(data, self.state)
                if r: c.sendall(r)
        except Exception: pass
        finally:
            try: c.close()
            except Exception: pass


def test_execute_sql_over_drda():
    if not _need_gibson(): return
    if not hasattr(_G, "respond_sql"):
        ok("GIBSON DRDA supports EXCSQLIMM (skipped - older GIBSON)", True); return
    st = _real_state()
    if st is None:
        ok("real GibsonState for SQL (skipped - build_state unavailable)", True); return
    srv = _RealStateDrdaServer(st)
    # first find a userid/password the real RACF accepts
    user, pw = "IBMUSER", "SYS1"
    code, text = D.execute_sql("127.0.0.1", srv.port, user, pw, "GIBSONDB2",
                               "SELECT CURRENT SQLID FROM SYSIBM.SYSDUMMY1")
    ok("EXCSQLIMM returns SQLCODE 0 against real DB2 sim", code == 0)
    ok("result carries the SQLID", "IBMUSER" in (text or "").upper())


def test_execute_sql_bad_creds():
    if not _need_gibson(): return
    if not hasattr(_G, "respond_sql"):
        ok("GIBSON DRDA supports EXCSQLIMM (skipped)", True); return
    st = _real_state()
    if st is None:
        ok("real GibsonState for SQL (skipped)", True); return
    srv = _RealStateDrdaServer(st)
    code, text = D.execute_sql("127.0.0.1", srv.port, "IBMUSER", "WRONGPW", "GIBSONDB2",
                               "SELECT 1 FROM SYSIBM.SYSDUMMY1")
    ok("bad credentials block SQL execution", code is None and "auth" in text.lower())


def test_interactive_session():
    if not _need_gibson(): return
    if not hasattr(_G, "respond_sql"):
        ok("DrdaSession (skipped - older GIBSON)", True); return
    st = _real_state()
    if st is None:
        ok("DrdaSession (skipped - no real state)", True); return
    srv = _RealStateDrdaServer(st)
    sess = D.DrdaSession("127.0.0.1", srv.port)
    fp = sess.open()
    ok("session opens + fingerprints", "DB2" in fp.upper())
    okl, msg = sess.login("IBMUSER", "SYS1", "GIBSONDB2")
    ok("session login works", okl)
    c1, t1 = sess.execute("SELECT CURRENT SQLID FROM SYSIBM.SYSDUMMY1")
    c2, t2 = sess.execute("SELECT CURRENT SERVER FROM SYSIBM.SYSDUMMY1")
    ok("multiple statements over one connection", c1 == 0 and c2 == 0)
    ok("SQLID reflects the logged-in user", "IBMUSER" in (t1 or "").upper())
    sess.close()


def test_command_builder_quoting():
    # the ibm_db command must survive quotes in the SQL and password (was a SyntaxError)
    import base64, re
    from phosphor.toolchain import api_sql as A
    cmd = A.db2_python_command("h", 50000, "LOC", "U", "O'BRIEN", "SELECT * FROM T WHERE X='a'")
    ok("command is single-quoted (no nested double-quote break)", cmd.startswith("python3 -c '"))
    b64 = re.search(r'b64decode\("([^"]+)"\)', cmd).group(1)
    body = base64.b64decode(b64).decode()
    ok("payload decodes and contains the SQL intact", "WHERE X='a'" in body)
    ok("password with a quote survives", "O'BRIEN" in body)


def test_native_result_set():
    if not _need_gibson(): return
    if not hasattr(_G, "respond_query"):
        ok("native DRDA result sets (skipped - GIBSON has no respond_query)", True); return
    st = _real_state()
    if st is None:
        ok("native DRDA result sets (skipped - no real state)", True); return
    srv = _RealStateDrdaServer(st)
    sess = D.DrdaSession("127.0.0.1", srv.port)
    sess.open(); sess.login("IBMUSER", "SYS1", "GIBSONDB2")
    cols, rows = sess.query("SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES")
    ok("descriptor decoded (columns present)", len(cols) >= 2)
    ok("rows retrieved over native DRDA (no driver)", len(rows) > 0)
    ok("rows are typed dicts keyed by column", "NAME" in rows[0] and "CREATOR" in rows[0])
    # single-column query
    c2, r2 = sess.query("SELECT CURRENT SQLID FROM SYSIBM.SYSDUMMY1")
    ok("single-column query works", len(r2) == 1)
    # execute() formats a SELECT as a table
    code, text = sess.execute("SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES")
    ok("execute() renders a result table", code == 0 and "row(s)" in text)
    sess.close()


def test_fdoca_decode_roundtrip():
    # decode what GIBSON's encoder produced, without a socket - proves the codec pair
    if not hasattr(_G, "build_qrydsc"):
        ok("FD:OCA codec (skipped - older GIBSON)", True); return
    cols = [("NAME", D.T_VARCHAR, 18), ("N", D.T_SMALLINT, 2), ("BIG", D.T_INTEGER, 4)]
    rows = [{"NAME": "EMP", "N": 7, "BIG": 100000}, {"NAME": "DEPT", "N": -3, "BIG": 1}]
    dsc = _G.build_qrydsc(cols)
    dta = _G.build_qrydta(cols, rows)
    # strip the 6-byte DSS + 4-byte DDM header to get the raw bodies
    dcols = D.decode_qrydsc(dsc[10:])
    drows = D.decode_qrydta(dta[10:], dcols)
    ok("descriptor round-trips (names+types)", [c[0] for c in dcols] == ["NAME", "N", "BIG"])
    ok("varchar value decodes", drows[0]["NAME"] == "EMP")
    ok("smallint (incl negative) decodes", drows[1]["N"] == -3)
    ok("integer > 32767 decodes", drows[0]["BIG"] == 100000)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try: fn()
            except Exception as e: ok(name + f" [{e!r}]", False)
    print(f"\n{_p} passed, {_f} failed")
    sys.exit(1 if _f else 0)
