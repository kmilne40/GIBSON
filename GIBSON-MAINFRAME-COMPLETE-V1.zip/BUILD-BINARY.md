# Building PHOSPHOR as a compiled binary (Nuitka)

PHOSPHOR is pure Python, but you can ship it as a **single native executable** —
no Python install, no `pip`, no dependencies on the target — using Nuitka, which
compiles the Python to C and then to a real binary.  No rewrite required.

## What you get

| Target | Command | Contents | Size |
|--------|---------|----------|------|
| **core** | `python build.py core` | scanner, auditor, recon menu, notepad, reporting, interactive client, cicspwn adapter | small (stdlib only) |
| **crt** | `python build.py crt` | the cathode-ray TN3270 terminal (moderngl/pyglet/pillow/numpy) | larger; needs OpenGL on target |

The **core** binary is the one to deploy — it's lean, portable, and covers all
the actual auditing. The **crt** terminal stays optional (it's eye-candy and
needs a GPU/GL stack), exactly as intended.

## Prerequisites

1. **Python 3.9+** and a **C compiler**:
   - Linux: `gcc` (usually already present; `sudo apt install build-essential`)
   - macOS: Xcode command-line tools (`xcode-select --install`)
   - Windows: nothing extra — Nuitka fetches a MinGW toolchain on first run
2. **Nuitka**: `pip install nuitka`
3. For the **crt** target only: `pip install "phosphor-tn3270[crt]"` (or
   `pip install moderngl pyglet pillow numpy`) so those libraries are available
   to bundle.

## Build

```bash
pip install nuitka
python build.py core      # -> dist/phosphor
python build.py crt       # -> dist/phosphor-crt   (optional)
python build.py both
```

First compile takes a few minutes (Nuitka is compiling C); subsequent builds are
faster with ccache. The result is a self-contained file in `dist/`.

Run it like the Python version:

```bash
./dist/phosphor 192.168.0.195 --scan --report assessment.html
./dist/phosphor 192.168.0.195 --menu
./dist/phosphor-crt 192.168.0.195 --profile boardroom
```

## Per-platform notes

- **Linux (x86-64):** works out of the box with `gcc`.
- **Kali Raspberry Pi (aarch64):** Nuitka is **not** a cross-compiler — run
  `python build.py core` *on the Pi* and you get an ARM64 binary. `gcc` is
  already on Kali.
- **macOS:** the binary is unsigned; on first run allow it in *System Settings →
  Privacy & Security*, or `xattr -d com.apple.quarantine ./dist/phosphor`.
- **Windows:** produces `phosphor.exe`; MinGW is fetched automatically on the
  first build (say yes to the download prompt, or it's pre-answered by
  `--assume-yes-for-downloads`).

## Driving cicspwn from the binary

The cicspwn adapter loads the real `cicspwn.py` **at runtime** from a path you
give it, so cicspwn is *not* compiled into the binary (and doesn't need to be).
Ship `cicspwn.py` alongside the binary and point the adapter at it:

```bash
./dist/phosphor-run-cicspwn ./cicspwn.py 192.168.0.195 23    # if you add this entry
# or keep using the Python: python -m phosphor.run_cicspwn ./cicspwn.py <host>
```

## How the build is configured (already handled in build.py)

- `--onefile --standalone` → one self-contained executable.
- `--include-package-data=phosphor` → bundles the shaders, fonts and
  `demo_screen.json`; PHOSPHOR loads these relative to the package (`__file__`),
  which Nuitka resolves correctly when frozen.
- core build uses `--nofollow-import-to=phosphor.crt,moderngl,pyglet,numpy,PIL`
  so the GPU stack is never pulled into the lean binary.
- crt build uses `--enable-plugin=numpy` and includes the imaging/GL packages.

## Honest note

The build tooling and packaging were prepared and verified ready — the entry
points import cleanly, the GPU dependencies are guarded so the core target builds
without them, and every data file is loaded package-relative so `--include-package-data`
bundles it. The **actual Nuitka compile has to run on your machine**, because it
needs Nuitka + a C toolchain (the environment this was assembled in has neither
networking to install Nuitka nor a way to run a multi-minute native compile). If
the first build surfaces a missing-module or data-path warning, send it over and
I'll adjust the flags — that's the normal last-mile of any Nuitka packaging.
