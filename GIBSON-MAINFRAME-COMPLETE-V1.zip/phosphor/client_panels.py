"""Boxed operator-console layout for the PHOSPHOR ``--client`` TUI.

This module owns the *geometry* only - it computes where the terminal glass and
every operator box sit for a given terminal size, provides mouse hit-testing and
2-D keyboard navigation between boxes, and carries each box's label / help / the
action id the front-end dispatches on.  It imports no curses, so it is unit
tested headless exactly like the rest of the suite.

The arrangement mirrors the physical 3270 operator keypad in the reference
screenshot, positioned to match the desktop (``--gui``) client: the operator /
PA column on the LEFT of the glass, the PF grid ACROSS THE TOP, the cursor /
edit cluster on the RIGHT, the Tab / Reset / New-Line / Enter band and the tool
MENU boxes UNDER the glass, and the ``:`` command line pinned at the very bottom
(the vi touch).  Every box is clickable and keyboard-selectable; the same menu /
tool options the GUI exposes are reachable from the MENU / SETTINGS / HELP boxes.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

GLASS_ROWS = 24
GLASS_COLS = 80


@dataclass
class Box:
    id: str                 # dispatch id, e.g. "k_pf13", "b_menu", "k_enter"
    label: str              # text drawn inside the box
    y: int                  # top row (screen coords)
    x: int                  # left col
    h: int                  # height in rows (>=3 draws a full border; 1 = grid cell)
    w: int                  # width in cols
    help: str = ""          # one-line tooltip / status hint
    accent: str = ""        # "" normal | "warn" | "accent" | "amber" | "active"

    @property
    def cx(self) -> float:
        return self.x + self.w / 2.0

    @property
    def cy(self) -> float:
        return self.y + self.h / 2.0

    def contains(self, y: int, x: int) -> bool:
        return self.y <= y < self.y + self.h and self.x <= x < self.x + self.w


@dataclass
class Layout:
    glass_y: int
    glass_x: int
    boxes: List[Box] = field(default_factory=list)
    cmd_y: int = 0
    status_y: int = 0
    ok: bool = True                 # False = terminal too small for the full chrome
    reason: str = ""
    width: int = 0
    height: int = 0
    _by_id: Dict[str, Box] = field(default_factory=dict)

    def __post_init__(self):
        self._by_id = {b.id: b for b in self.boxes}

    # ---- lookups --------------------------------------------------------
    def box(self, bid: str) -> Optional[Box]:
        return self._by_id.get(bid)

    def hit(self, y: int, x: int):
        """Mouse hit-test.  Returns a box id, or ("glass", row, col) for a click
        on the terminal glass (1-based cell), or None."""
        for b in self.boxes:
            if b.contains(y, x):
                return b.id
        gr = y - self.glass_y
        gc = x - self.glass_x
        if 0 <= gr < GLASS_ROWS and 0 <= gc < GLASS_COLS:
            return ("glass", gr + 1, gc + 1)
        return None

    # ---- keyboard navigation over the boxes -----------------------------
    def first_nav(self) -> Optional[str]:
        return self.boxes[0].id if self.boxes else None

    def neighbour(self, cur: str, dy: int, dx: int) -> Optional[str]:
        """Nearest box in the (dy,dx) direction from box ``cur`` (center-based).
        dy<0 up, dy>0 down, dx<0 left, dx>0 right."""
        c = self.box(cur)
        if not c or not self.boxes:
            return cur
        best, best_score = None, None
        for b in self.boxes:
            if b.id == cur:
                continue
            ddy, ddx = b.cy - c.cy, b.cx - c.cx
            if dy and (ddy * dy) <= 0:          # not in the vertical direction asked
                continue
            if dx and (ddx * dx) <= 0:          # not in the horizontal direction asked
                continue
            # primary distance along the axis of travel, secondary = cross drift
            primary = abs(ddy) if dy else abs(ddx)
            cross = abs(ddx) if dy else abs(ddy)
            score = primary + cross * 3          # penalise sideways drift
            if best_score is None or score < best_score:
                best, best_score = b.id, score
        return best or cur


def _keycols(labels: List[str], min_w: int = 6, pad: int = 2) -> List[int]:
    return [max(min_w, len(s) + pad) for s in labels]


def build_layout(maxy: int, maxx: int) -> Layout:
    """Lay the whole console out for a ``maxy`` x ``maxx`` terminal.

    Full chrome needs roughly 122 cols x 36 rows.  When smaller, we drop the
    outer clusters in priority order (right cluster, then left, then the PF grid)
    but always keep the glass, the operator band and the ``:`` command line so
    the terminal stays usable - ``ok``/``reason`` report any degradation.
    """
    boxes: List[Box] = []
    reason = ""

    # --- vertical budget -------------------------------------------------
    # top:    2 PF rows drawn as a 4-row boxed grid  (rows: border,13-24,1-12,border-ish)
    # glass:  24 rows
    # bottom: 3-row operator band + 1 command line + 1 status
    pf_h = 4
    band_h = 3
    have_pf = maxy >= (pf_h + GLASS_ROWS + band_h + 2)
    top = 0
    if not have_pf:
        reason = "PF grid hidden (need >=34 rows); use :pf N or F-keys"
        pf_h = 0

    glass_y_min = top + pf_h + 1
    # --- horizontal budget: a single operator column on the RIGHT of the glass -
    # (Home / Cursor-Select / Insert / Delete / Dup / Field-Mark were removed;
    #  Erase EOF / Erase Input were removed; the kept operator keys - PA1, PA2,
    #  Attn, PA3, SysRq, Clear - now stack in one column on the right.)
    col_w = 9
    right_gap = 1
    want_w = GLASS_COLS + right_gap + col_w
    have_ops = maxx >= want_w
    if not have_ops:
        col_w = 0
        reason = (reason + "; " if reason else "") + "operator column folded into MENU"

    used_w = GLASS_COLS + (right_gap + col_w if have_ops else 0)
    origin_x = max(0, (maxx - used_w) // 2)
    glass_x = origin_x
    glass_y = glass_y_min

    # ============ TOP: PF grid (13-24 over 1-12), boxed like the screenshot
    if have_pf:
        top_labels = [f"{n}" for n in range(13, 25)]
        # cells span the glass width, evenly
        cell_w = max(4, GLASS_COLS // 12)
        grid_w = cell_w * 12
        gx0 = glass_x + (GLASS_COLS - grid_w) // 2
        # legend "PF" sits to the left of each row
        for ri, base in ((0, 13), (1, 1)):
            ry = top + 1 + ri
            for i in range(12):
                n = base + i
                boxes.append(Box(
                    id=f"k_pf{n}", label=f"{n:>2}", y=ry, x=gx0 + i * cell_w,
                    h=1, w=cell_w, help=_PF_HELP.get(n, f"PF{n}"), accent="grid"))

    # ============ RIGHT: single operator column, stacked in order
    if have_ops:
        rx = glass_x + GLASS_COLS + right_gap
        column = [
            ("k_pa1", "PA1"), ("k_pa2", "PA2"), ("k_attn", "Attn"),
            ("k_pa3", "PA3"), ("k_sysreq", "SysRq"), ("k_clear", "Clear"),
        ]
        step = max(3, GLASS_ROWS // len(column))
        ry = glass_y
        for bid, lab in column:
            boxes.append(Box(bid, lab, ry, rx, 3, col_w, _KEY_HELP.get(bid, lab)))
            ry += step

    # ============ BOTTOM band: Tab | BackTab | Reset | NewLine | Enter + tools
    band_y = glass_y + GLASS_ROWS + 1
    bx = glass_x
    band = [
        ("k_tab", "Tab \u2192|", "accent"),
        ("k_backtab", "|\u2190 BTab", "accent"),
        ("k_reset", "Reset", "amber"),
        ("k_newline", "\u21b5 NewLn", "accent"),
        ("k_enter", "Enter", "active"),
    ]
    tools = [
        ("b_menu", "MENU", "amber"),
        ("b_settings", "Settings", "amber"),
        ("b_help", "Help", "amber"),
        ("b_quit", "Quit", "warn"),
    ]
    row = band + tools
    # fit the row across the glass width; wrap to a second band line if needed
    x = bx
    ry = band_y
    for bid, lab, acc in row:
        w = max(7, len(lab) + 2)
        if x + w > glass_x + GLASS_COLS + (right_gap + col_w if have_ops else 0):
            x = bx
            ry += band_h
        boxes.append(Box(bid, lab, ry, x, band_h, w, _KEY_HELP.get(bid, lab), acc))
        x += w + 1
    last_band_y = ry + band_h

    cmd_y = last_band_y
    status_y = cmd_y + 1

    lay = Layout(glass_y=glass_y, glass_x=glass_x, boxes=boxes,
                 cmd_y=cmd_y, status_y=status_y,
                 ok=(have_pf and have_ops),
                 reason=reason, width=maxx, height=maxy)
    return lay


# ---- help / tooltip text (mirrors the GUI's KEY_HELP + MENU option set) ------
_PF_HELP = {
    1: "PF1 - Help", 2: "PF2 - Split screen", 3: "PF3 - Exit / End (go back)",
    4: "PF4 - Return to primary menu", 5: "PF5 - Repeat find (RFIND)",
    6: "PF6 - Repeat change (RCHANGE)", 7: "PF7 - Scroll up / backward",
    8: "PF8 - Scroll down / forward", 9: "PF9 - Swap window", 10: "PF10 - Scroll left",
    11: "PF11 - Scroll right", 12: "PF12 - Retrieve / Cancel", 13: "PF13 - Help (alt)",
    14: "PF14 - Split (alt)", 15: "PF15 - Exit (alt)", 16: "PF16 - App-defined",
    17: "PF17 - App-defined", 18: "PF18 - App-defined", 19: "PF19 - Scroll up (alt)",
    20: "PF20 - Scroll down (alt)", 21: "PF21 - App-defined", 22: "PF22 - App-defined",
    23: "PF23 - App-defined", 24: "PF24 - App-defined / Cancel",
}

_KEY_HELP = {
    "k_pa1": "PA1 - Attention (interrupt the host)",
    "k_pa2": "PA2 - Reshow the screen",
    "k_pa3": "PA3 - Program Attention 3",
    "k_attn": "Attn - Attention (interrupt the host)",
    "k_clear": "Clear - Clear the screen",
    "k_reset": "Reset - Unlock the keyboard after inhibit",
    "k_sysreq": "SysReq - System request / attention",
    "k_eeof": "Erase EOF - Erase from cursor to end of field",
    "k_einp": "Erase Input - Clear all input fields",
    "k_tab": "Tab - Next input field",
    "k_backtab": "Back-Tab - Previous input field",
    "k_newline": "New Line - Send the screen (AID ENTER)",
    "k_enter": "Enter - Send the screen (AID ENTER)",
    "k_home": "Home - Cursor to start of first / current field",
    "k_curselect": "Cursor Select - select the field under the cursor",
    "k_compose": "Compose - dead-key compose (local)",
    "k_insert": "Insert - toggle insert / overtype mode",
    "k_delete": "Delete - delete the character under the cursor",
    "k_dup": "Dup - insert the DUP character and tab",
    "k_fieldmark": "Field Mark - insert the field-mark character",
    "b_menu": "MENU - scans, transfers, FTP, notes, report (same as the GUI)",
    "b_settings": "Settings - colour, mono, STRIP3270 inline toggles, bezel",
    "b_help": "Help - key reference for this screen",
    "b_quit": "Quit - disconnect and exit (:q)",
}
