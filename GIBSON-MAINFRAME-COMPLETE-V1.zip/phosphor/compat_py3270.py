"""A PHOSPHOR-backed drop-in `em` for CICSpwn.

CICSpwn drives a py3270 ``Emulator`` (which shells out to x3270/s3270).  This
class presents the same high-level surface CICSpwn's code calls, backed entirely
by PHOSPHOR's native TN3270 client -- no x3270, no subprocess.  Injecting an
instance as cicspwn's ``em`` lets the real tool run against any TN3270 host
(GIBSON, ZD&T, real z/OS) with none of py3270's dependencies or sleeps.
"""
from __future__ import annotations

from phosphor.protocols.tn3270.client import TN3270Client


class _Status:
    field_protection = "U"
    row_number = 24
    col_number = 80


class PhosphorEmulator:
    def __init__(self, visible=False, delay=0):
        self.client = TN3270Client()
        self.status = _Status()
        self.delay = 0

    # --- connection ------------------------------------------------------
    def connect(self, target):
        host, _, port = target.partition(":")
        self.client.connect(host, int(port) if port else 23)

    def terminate(self):
        self.client.terminate()

    def is_connected(self):
        return self.client.is_connected()

    # --- cursor / input --------------------------------------------------
    def move_to(self, ypos, xpos):
        self.client.move_to(ypos, xpos)

    def send_string(self, text):
        self.client.send_string(text)

    def safe_send(self, text):
        self.client.send_string(text)
        return True

    def safe_fieldfill(self, ypos, xpos, tosend, length):
        if ypos is not None and xpos is not None:
            self.client.move_to(ypos, xpos)
        self.client.send_string(tosend)
        return True

    def delete_field(self):
        pass

    # --- AIDs ------------------------------------------------------------
    def send_enter(self):
        self.client.send_enter()

    def send_clear(self):
        self.client.send_clear()

    def send_eraseEOF(self):
        # clear any queued input for the current field
        self.client._pending = []

    def send_pf(self, n):
        self.client.send_pf(n)

    def send_pf3(self): self.client.send_pf(3)
    def send_pf5(self): self.client.send_pf(5)
    def send_pf11(self): self.client.send_pf(11)

    # --- reading ---------------------------------------------------------
    def screen_get(self):
        return self.client.screen_get()

    def string_found(self, row, col, text):
        rows = self.client.screen_get()
        if 1 <= row <= len(rows):
            return rows[row - 1][col - 1:col - 1 + len(text)] == text
        return False

    def find_response(self, text):
        return self.client.find(text)

    def get_pos(self):
        return self.client.get_pos()

    def find_field_start_on_row(self, row):
        for f in self.client.screen.input_fields():
            if f.row == row:
                return f.col
        return 2

    def get_hostinfo(self):
        return "phosphor"
