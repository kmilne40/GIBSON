"""Minimal ANSI colour frontend.

Renders the colour ScreenBuffer to a 24x80 block of ANSI-coloured text.  This is
the lightweight 'readable' face of PHOSPHOR and a stand-in that proves the colour
model feeds a renderer -- the GLSL CRT frontend consumes the same
``screen.colour_grid()``.
"""
from __future__ import annotations

from phosphor.core.screen import ScreenBuffer

# 3270 colour name -> ANSI foreground
_ANSI = {
    "blue": "\033[38;5;39m", "red": "\033[38;5;196m", "pink": "\033[38;5;213m",
    "green": "\033[38;5;46m", "turquoise": "\033[38;5;51m",
    "yellow": "\033[38;5;226m", "white": "\033[38;5;231m",
    "neutral": "\033[38;5;250m",
}
_RESET = "\033[0m"


def render(screen: ScreenBuffer, phosphor: bool = False, cursor=None) -> str:
    """Return an ANSI string for the screen.

    ``phosphor=True`` forces monochrome green (3278 mode); otherwise the real
    3279 colours are used.  ``cursor=(row, col)`` (1-based) draws a visible
    light-blue cursor block at that cell so you can see where you are.
    """
    out = []
    for r, row in enumerate(screen.colour_grid()):
        line = []
        cur = None
        for cidx, (ch, colour, high) in enumerate(row):
            if cursor is not None and (r + 1, cidx + 1) == cursor:
                line.append(_RESET + "\033[104m\033[30m")   # light-blue bg, black fg
                line.append(ch if ch != " " else " ")
                line.append(_RESET)
                cur = None
                continue
            c = "green" if phosphor else colour
            code = _ANSI.get(c, _ANSI["green"])
            if high == "reverse":
                code += "\033[7m"
            if code != cur:
                line.append(_RESET + code); cur = code
            line.append(ch)
        out.append("".join(line) + _RESET)
    return "\n".join(out)
