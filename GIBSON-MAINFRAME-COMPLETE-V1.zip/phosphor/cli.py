"""PHOSPHOR CLI — run an audit against a TN3270 host and print/report findings."""
from __future__ import annotations
import argparse, ipaddress, json, sys
from phosphor.audit import enumerate as au


def _rfc1918(host: str) -> bool:
    try:
        return ipaddress.ip_address(host).is_private
    except ValueError:
        return True   # hostname — allow (resolve happens at connect)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="phosphor",
        description="PHOSPHOR - TN3270 mainframe audit client, terminal and toolkit.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "modes:\n"
            "  phosphor HOST[:PORT]              launch the desktop app, connected\n"
            "  phosphor HOST [PORT] --gui        same (explicit)\n"
            "  phosphor HOST [PORT] --client     full-screen curses TUI, like c3270:\n"
            "                                    type into fields, arrows/Tab, real F-keys=\n"
            "                                    PF, ':' command line for IND$FILE up/down +\n"
            "                                    FTP.  add --repl for a plain line prompt\n"
            "  phosphor HOST [PORT] --scan       run the recon audit suite (default)\n"
            "  phosphor HOST --menu              interactive recon menu\n"
        ),
    )
    p.add_argument("host"); p.add_argument("port", nargs="?", type=int, default=23)
    p.add_argument("--scan", action="store_true", help="run the recon audit suite")
    p.add_argument("--client", action="store_true",
                   help="full-screen curses TUI like c3270 (fields, F-keys, :menu for transfers/FTP)")
    p.add_argument("--menu", action="store_true", help="interactive recon menu (scans + notepad)")
    p.add_argument("--applids", help="comma list for vtam-enum")
    p.add_argument("--users", help="comma list for tso-enum")
    p.add_argument("--ftp-port", type=int, default=21, dest="ftp_port", help="FTP port for ftp-anon")
    p.add_argument("--db2-port", type=int, default=50000, dest="db2_port", help="DB2 DRDA port")
    p.add_argument("--json", action="store_true", help="emit findings as JSON")
    p.add_argument("--lab", action="store_true", help="refuse non-RFC1918 targets")
    p.add_argument("--gui", action="store_true",
                   help="launch the PHOSPHOR desktop app connected to the target (host or host:port)")
    p.add_argument("--5250", dest="tn5250", action="store_true", help="use TN5250 (IBM i)")
    p.add_argument("--engine", choices=["native", "tnz"], default="native",
                   help="TN3270 engine: 'native' (built-in) or 'tnz' (IBM tnz, "
                        "pip install tnz ebcdic) for real z/OS / zPDT")
    p.add_argument("--repl", action="store_true",
                   help="with --client, use the simple line prompt instead of the full-screen TUI")
    p.add_argument("--report", help="write an HTML or Markdown report to this path")
    p.add_argument("--unlock", metavar="CODE",
                   help="pen-test tools unlock code (needed for --scan/--menu; remembered once entered)")
    a = p.parse_args(argv)

    # `phosphor host:port` (or --gui) launches the desktop app already connected.
    if a.gui or ":" in (a.host or ""):
        from phosphor.app.__main__ import main as gui_main
        gargv = [a.host]
        if a.port and ":" not in a.host:
            gargv.append(str(a.port))
        if getattr(a, "tn5250", False):
            gargv.append("--5250")
        if a.engine and a.engine != "native":
            gargv += ["--engine", a.engine]
        return gui_main(gargv)

    if a.lab and not _rfc1918(a.host):
        print("[!] --lab set and target is not RFC1918. Refusing.", file=sys.stderr); return 2

    # the plain terminal needs no unlock code - handle it before the tools gate
    if a.client:
        proto = "5250" if getattr(a, "tn5250", False) else "3270"
        if not a.repl:
            try:
                from phosphor.client_tui import run_tui, available
                if available():
                    return run_tui(a.host, a.port, proto, a.engine)
            except Exception:
                pass
        from phosphor.client_repl import interactive
        return interactive(a.host, a.port, proto)

    # everything below runs the pen-test / audit tooling: it is gated behind the
    # one-time unlock code, exactly like the GUI's TOOLS panel.
    from phosphor.app import license as lic
    if a.unlock:
        if lic.unlock_tools(a.unlock):
            print("[+] pen-test tools unlocked (remembered on this machine)")
        else:
            print("[!] wrong unlock code", file=sys.stderr); return 3
    if not lic.tools_unlocked():
        print("[!] PHOSPHOR's scan / audit tools are locked.", file=sys.stderr)
        print("    Unlock once:  phosphor <host> --scan --unlock <CODE>", file=sys.stderr)
        print("    The code is in the No Starch Press book 'Hacking Mainframes', or PM", file=sys.stderr)
        print("    Kev on LinkedIn. The terminal (phosphor <host> --client) needs no code.", file=sys.stderr)
        return 3

    if a.menu:
        from phosphor.recon_menu import run_menu
        return run_menu(a.host or "")

    print(f"[+] PHOSPHOR audit of {a.host}:{a.port}  (authorized use only)")
    findings = []
    try:
        findings.append(au.tn3270_screen(a.host, a.port))
        ap = a.applids.split(",") if a.applids else None
        findings += au.vtam_applids(a.host, a.port, ap)
        cics_up = any("CICS" in f.title for f in findings)
        if any("TSO" in f.title for f in findings):
            findings += au.tso_users(a.host, a.port, a.users.split(",") if a.users else None)
        if cics_up:
            findings += au.cics_transactions(a.host, a.port)
            findings += au.cics_region_info(a.host, a.port)
            findings += au.cics_users(a.host, a.port)
        anon = au.ftp_anon(a.host, a.ftp_port)
        if anon:
            findings.append(anon)
        db2 = au.db2_das_info(a.host, a.db2_port)
        if db2:
            findings.append(db2)
    except Exception as e:
        print(f"[!] {type(e).__name__}: {e}", file=sys.stderr); return 1

    if a.json:
        print(json.dumps([f.as_dict() for f in findings], indent=2))
    else:
        for f in findings:
            print(f"  [{f.severity.upper():6}] {f.title} — {f.detail}")
    if a.report:
        from phosphor.report import write_report
        write_report(findings, a.report, f"{a.host}:{a.port}")
        print(f"[+] report written to {a.report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
