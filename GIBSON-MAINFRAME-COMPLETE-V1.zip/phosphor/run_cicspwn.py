"""Run the (py3-ported) CICSpwn on PHOSPHOR instead of py3270/x3270.

    python -m phosphor.run_cicspwn /path/to/cicspwn.py <host> <port> [-a APPLID]

This injects a PHOSPHOR-backed emulator as CICSpwn's `em`, so the real tool runs
with no x3270 dependency.  Demonstrated end-to-end against GIBSON.
"""
from __future__ import annotations
import sys, types, importlib.util
from phosphor.compat_py3270 import PhosphorEmulator


def _fake_py3270():
    m = types.ModuleType("py3270")
    for nm in ["CommandError", "FieldTruncateError", "TerminatedError",
               "WaitError", "KeyboardStateError"]:
        setattr(m, nm, type(nm, (Exception,), {}))
    class _E:
        def __init__(self, *a, **k): pass
    m.Emulator = m.x3270App = m.s3270App = _E
    return m


def load_cicspwn(path: str):
    sys.modules["py3270"] = _fake_py3270()
    spec = importlib.util.spec_from_file_location("cicspwn", path)
    cp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cp)
    cp.em = PhosphorEmulator()
    return cp


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) < 3:
        print(__doc__)
        print("  options: --action <id> [--applid A] [--userid U] [--password P] [--lhost H:P]")
        return 1
    path, host, port = argv[0], argv[1], argv[2]

    def opt(name, default=None):
        return argv[argv.index(name) + 1] if name in argv else default

    action = opt("--action", "info")
    applid = opt("--applid", opt("-a", "CICS"))
    userid = opt("--userid")
    password = opt("--password")
    lhost = opt("--lhost")

    from phosphor.toolchain.cicspwn import build_results, validate, describe
    err = validate(action, lhost)
    if err:
        print(err)
        return 2

    cp = load_cicspwn(path)
    results = build_results(host, port, action, applid=applid, userid=userid,
                            password=password, lhost=lhost)
    print(f"[PHOSPHOR] CICSpwn: {describe(action)}  applid={results.applid}  {host}:{port}")

    try:
        if hasattr(cp, "connect_zOS"):
            cp.connect_zOS(f"{host}:{port}")
        else:
            cp.em.connect(f"{host}:{port}")
            cp.em.move_to(24, 1); cp.em.safe_send(f"LOGON APPLID({results.applid})")
            cp.em.send_enter(); cp.em.send_clear()
        cp.main(results)
    except SystemExit:
        pass
    except Exception as e:
        print(f"[PHOSPHOR] CICSpwn error: {e}")
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
