"""PHOSPHOR tool chain: recon -> credential attack -> capture -> crack -> app testing.

A thin layer over external pentest tools (nmap, hydra, john/racf2john, hack3270) plus a
pure-Python PCAP writer. Each external tool is detected at runtime; when absent, the app
shows the exact command and an install hint instead of failing. Authorised testing /
GIBSON training only.
"""
from __future__ import annotations

import shutil
from typing import Dict

from phosphor.toolchain import pcap, crack, hydra

# The intended chain, in order.
CHAIN = [
    ("nmap", "recon / enumeration (tso-enum, cics-enum, vtam-enum)"),
    ("hydra", "credential attack (telnet / ftp / http)"),
    ("pcap", "packet capture (built-in, always available)"),
    ("racf2john", "extract RACF hashes from a GIBSON SYS1.RACFDS unload"),
    ("john", "crack the RACF hashes (--format=racf)"),
    ("hack3270", "CICS app-layer datastream manipulation (proxy)"),
    ("cicspwn", "CICS TS attack tool (info/enum/files/shells)"),
]

_INSTALL_HINT = {
    "nmap": "apt install nmap  (mainframe NSE scripts: nmap-mainframe-scripts)",
    "hydra": "apt install hydra",
    "john": "apt install john  (or build jumbo for racf-kdfaes)",
    "racf2john": "ships with John jumbo",
    "hack3270": "pip install hack3270  /  github.com/gglessner/hack3270",
    "cicspwn": "point PHOSPHOR at cicspwn.py (PHOSPHOR_CICSPWN) or drop it in the tools dir",
}


def tool_status() -> Dict[str, Dict[str, str]]:
    """{tool: {installed: bool, hint: str}} for every external tool in the chain."""
    out: Dict[str, Dict[str, str]] = {}
    for name, _desc in CHAIN:
        if name == "pcap":
            out[name] = {"installed": True, "hint": "built-in"}
        elif name == "cicspwn":
            from phosphor.toolchain import cicspwn as _cp
            out[name] = {"installed": _cp.available(), "hint": _INSTALL_HINT.get(name, "")}
        else:
            out[name] = {"installed": shutil.which(name) is not None,
                         "hint": _INSTALL_HINT.get(name, "")}
    return out
