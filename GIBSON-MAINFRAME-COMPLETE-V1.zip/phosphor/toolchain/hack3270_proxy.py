"""hack3270 integration - two ways to manipulate the CICS 3270 data stream.

gglessner/hack3270 is a TN3270 MITM proxy for CICS application pen-testing: it sits
between the client and the mainframe and lets you unprotect protected fields, reveal
hidden (password) fields, and edit the stream to test client-side controls.

PHOSPHOR offers both:

* **Managed proxy** - launch hack3270 as a local proxy on connect and route the session
  through it, so you don't start it by hand. The exact hack3270 invocation varies by
  version, so the launch command is configurable (``PHOSPHOR_HACK3270_CMD`` with
  ``{listen_host} {listen_port} {target_host} {target_port}`` placeholders).

* **Native inline** - because PHOSPHOR already parses the 3270 stream, it can apply the
  same field-attribute manipulations in-process, with no external tool. Fully offline.

Authorised testing / GIBSON training only.
"""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import time
from typing import Optional, Tuple

from phosphor.protocols.tn3270.datastream import (
    SF, SFE, SBA, SA, RA, GE, IC, PT, CMD_WSF,
    _ERASE_WRITE_CMDS, _WRITE_CMDS)

# --- basic 3270 field-attribute bits ---
ATTR_PROTECTED = 0x20
ATTR_DISPLAY_MASK = 0x0C
ATTR_HIDDEN = 0x0C          # (attr & 0x0C) == 0x0C  -> non-display


def _munge_attr(attr: int, unprotect: bool, unhide: bool) -> int:
    if unprotect:
        attr &= ~ATTR_PROTECTED
    if unhide and (attr & ATTR_DISPLAY_MASK) == ATTR_HIDDEN:
        attr &= ~ATTR_DISPLAY_MASK          # non-display -> normal display
    return attr & 0xFF


def manipulate_inbound(data: bytes, unprotect: bool = False, unhide: bool = False) -> bytes:
    """Rewrite field attributes in an inbound 3270 Write stream - the core of what
    hack3270 does - in-process. Clears the protected bit and/or reveals hidden fields.
    Returns the (possibly) modified data; structured-field writes are left untouched."""
    if not data or not (unprotect or unhide):
        return data
    out = bytearray(data)
    n = len(out)
    cmd = out[0]
    if cmd == CMD_WSF:
        return bytes(out)
    i = 2 if (cmd in _ERASE_WRITE_CMDS or cmd in _WRITE_CMDS) and n > 1 else 0
    while i < n:
        b = out[i]
        if b == SBA and i + 2 < n:
            i += 3; continue
        if b == RA and i + 3 < n:
            i += 4; continue
        if b == SA and i + 2 < n:
            i += 3; continue
        if b == GE and i + 1 < n:
            i += 2; continue
        if b in (IC, PT):
            i += 1; continue
        if b == SF and i + 1 < n:
            out[i + 1] = _munge_attr(out[i + 1], unprotect, unhide); i += 2; continue
        if b == SFE and i + 1 < n:
            pairs = out[i + 1]; j = i + 2
            for _ in range(pairs):
                if j + 1 >= n:
                    break
                if out[j] == 0xC0:                      # field-attribute pair
                    out[j + 1] = _munge_attr(out[j + 1], unprotect, unhide)
                j += 2
            i = j; continue
        i += 1
    return bytes(out)


# --------------------------------------------------------------------------- #
#  Managed hack3270 subprocess proxy
# --------------------------------------------------------------------------- #
_DEFAULT_CMD = "hack3270 --listen {listen_host}:{listen_port} --target {target_host}:{target_port}"


def hack3270_available() -> bool:
    if os.environ.get("PHOSPHOR_HACK3270_CMD"):
        return True
    return shutil.which("hack3270") is not None or shutil.which("hack3270.py") is not None


class Hack3270Proxy:
    """Launch hack3270 as a local proxy so PHOSPHOR connects through it automatically."""

    def __init__(self, target_host: str, target_port: int = 23,
                 listen_host: str = "127.0.0.1", listen_port: int = 3271):
        self.target_host, self.target_port = target_host, int(target_port)
        self.listen_host, self.listen_port = listen_host, int(listen_port)
        self.proc: Optional[subprocess.Popen] = None

    def command(self) -> list:
        import shlex
        tmpl = os.environ.get("PHOSPHOR_HACK3270_CMD") or _DEFAULT_CMD
        return shlex.split(tmpl.format(
            listen_host=self.listen_host, listen_port=self.listen_port,
            target_host=self.target_host, target_port=self.target_port))

    def available(self) -> bool:
        return hack3270_available()

    def _port_open(self) -> bool:
        try:
            with socket.create_connection((self.listen_host, self.listen_port), timeout=0.3):
                return True
        except OSError:
            return False

    def start(self, wait: float = 5.0) -> Tuple[str, int]:
        """Start the proxy and return the local endpoint to connect to. Raises if
        hack3270 isn't available or the listen port never opens."""
        if not self.available():
            raise RuntimeError("hack3270 not found (set PHOSPHOR_HACK3270_CMD or install it)")
        self.proc = subprocess.Popen(self.command(),
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.time() + wait
        while time.time() < deadline:
            if self._port_open():
                return self.listen_host, self.listen_port
            if self.proc.poll() is not None:
                raise RuntimeError("hack3270 exited before opening its listen port")
            time.sleep(0.2)
        self.stop()
        raise RuntimeError("hack3270 listen port did not open in time")

    def stop(self) -> None:
        if self.proc is not None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=2)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.proc = None
