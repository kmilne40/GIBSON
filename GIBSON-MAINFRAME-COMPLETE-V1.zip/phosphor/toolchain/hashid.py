"""Hash-format detector for PHOSPHOR's John panel.

Point it at a hash file (racf2john output, an /etc/shadow, a mixed dump) and it tells you,
per line, what each hash actually is - md5crypt, RACF DES, RACF KDFAES, an empty/zero RACF
field (PROTECTED / NOPASSWORD / phrase- or KDFAES-only account), or something else - counts
crackable vs empty, suggests the right `--format`, and warns about the classic gotchas
(mixed formats in one file; mostly-empty RACF unloads). Authorised testing / GIBSON only.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# John --format suggestions per detected kind.
JOHN_FORMAT = {
    "md5crypt": "md5crypt",
    "racf-des": "racf",
    "racf-kdfaes": "racf-kdfaes",
    "sha512crypt": "sha512crypt",
    "sha256crypt": "sha256crypt",
    "bcrypt": "bcrypt",
    "descrypt": "descrypt",
}
# kinds that have nothing to crack
_EMPTY = {"racf-empty"}

_RACF = re.compile(r"^\$racf\$\*([^*]+)\*([0-9A-Fa-f]*)$")
_RACF_KDFAES = re.compile(r"^\$racf-kdfaes\$", re.I)


def classify(hash_field: str) -> Tuple[str, str]:
    """Return (kind, detail) for a single hash field (the part after user:)."""
    h = (hash_field or "").strip()
    if not h:
        return "unknown", "empty line"
    if h.startswith("$1$"):
        return "md5crypt", "Unix MD5-crypt - NOT RACF (racf2john never emits $1$)"
    if h.startswith("$6$"):
        return "sha512crypt", "Unix SHA-512 crypt"
    if h.startswith("$5$"):
        return "sha256crypt", "Unix SHA-256 crypt"
    if re.match(r"^\$2[aby]\$", h):
        return "bcrypt", "bcrypt"
    if _RACF_KDFAES.match(h):
        return "racf-kdfaes", "RACF KDFAES (modern AES-based) - needs --format=racf-kdfaes"
    m = _RACF.match(h)
    if m:
        digest = m.group(2).upper()
        if not digest or set(digest) <= {"0"}:
            return "racf-empty", "RACF, no DES password (PROTECTED / NOPASSWORD / phrase- or KDFAES-only)"
        if len(digest) == 16:
            return "racf-des", "RACF legacy DES (8-char, uppercase, EBCDIC) - crackable with --format=racf"
        return "racf-kdfaes", f"RACF non-DES envelope ({len(digest)} hex) - likely KDFAES"
    if re.match(r"^[0-9A-Fa-f]{13}$", h):
        return "descrypt", "traditional DES crypt"
    if re.match(r"^[0-9A-Fa-f]{32}$", h):
        return "nt-or-md5", "32-hex - NTLM or raw MD5 (ambiguous)"
    return "unknown", "unrecognised format"


@dataclass
class Line:
    user: str
    kind: str
    detail: str


@dataclass
class HashReport:
    lines: List[Line] = field(default_factory=list)
    counts: Counter = field(default_factory=Counter)

    @property
    def crackable(self) -> int:
        return sum(n for k, n in self.counts.items() if k not in _EMPTY and k != "unknown")

    @property
    def empty(self) -> int:
        return sum(n for k, n in self.counts.items() if k in _EMPTY)

    def suggested_formats(self) -> List[str]:
        return sorted({JOHN_FORMAT[k] for k in self.counts if k in JOHN_FORMAT})

    def warnings(self) -> List[str]:
        w = []
        fmts = self.suggested_formats()
        if len(fmts) > 1:
            w.append(f"MIXED formats ({', '.join(fmts)}) - John loads ONE format per run; "
                     "split the file or pass --format for each.")
        if self.empty:
            w.append(f"{self.empty} RACF account(s) have no DES password (PROTECTED/NOPASSWORD/"
                     "phrase/KDFAES) - nothing for John to crack there.")
        if self.counts.get("md5crypt") and (self.counts.get("racf-des") or self.counts.get("racf-empty")):
            w.append("This dump mixes Unix md5crypt with RACF - they are different systems, "
                     "not 'both RACF DES'.")
        return w


def analyse(text: str) -> HashReport:
    rep = HashReport()
    for raw in (text or "").splitlines():
        raw = raw.strip()
        if not raw:
            continue
        user, _, hfield = raw.partition(":")
        if not hfield:
            user, hfield = "", user
        kind, detail = classify(hfield)
        rep.lines.append(Line(user or "?", kind, detail))
        rep.counts[kind] += 1
    return rep


def analyse_file(path: str) -> HashReport:
    try:
        return analyse(open(path, "r", errors="replace").read())
    except Exception:
        return HashReport()


def format_report(rep: HashReport, name: str = "") -> str:
    out = [f"hash-format scan{(' - ' + name) if name else ''}:"]
    if not rep.lines:
        return out[0] + " (no hashes found)"
    for kind, n in rep.counts.most_common():
        fmt = JOHN_FORMAT.get(kind)
        tag = f"  [--format={fmt}]" if fmt else ("  [no crackable material]" if kind in _EMPTY else "")
        out.append(f"  {n:>3}  {kind}{tag}")
    out.append(f"  -- {rep.crackable} crackable, {rep.empty} empty/PROTECTED --")
    for w in rep.warnings():
        out.append("  ! " + w)
    if rep.suggested_formats():
        out.append("  suggested: john --format=" + " / ".join(rep.suggested_formats()) + " <file>")
    return "\n".join(out)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: python3 -m phosphor.toolchain.hashid <hash-file> [more-files...]")
        raise SystemExit(2)
    for p in sys.argv[1:]:
        print(format_report(analyse_file(p), p)); print()
