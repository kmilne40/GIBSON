"""Hydra credential-attack integration for PHOSPHOR.

Builds correct ``hydra`` command lines for the services a mainframe exposes over the
network, wired to the in-client wordlists (users.txt / passwords.txt), detects whether
hydra is installed, and parses the login/password hits from its output.

Authorised testing / GIBSON training only. This module builds and (optionally) launches
hydra; it performs no attack on its own.
"""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# Services hydra natively supports that are relevant to z/OS exposure.
#   telnet - the TN3270/line-mode port (25 = solicited logon prompts)
#   ftp    - the classic JCL-submit / dataset foothold
#   http-get / http-post-form - z/OSMF, z/OS Connect, CICS web
SERVICES = ("telnet", "ftp", "http-get")


def have_hydra() -> bool:
    return shutil.which("hydra") is not None


def hydra_cmd(host: str, service: str = "telnet", port: int = 23,
              userlist: str = "users.txt", passlist: str = "passwords.txt",
              extra: Optional[List[str]] = None) -> List[str]:
    """hydra -L users.txt -P passwords.txt -s <port> -t 4 -f <host> <service>"""
    svc = service if service in SERVICES else "telnet"
    cmd = ["hydra", "-L", userlist, "-P", passlist, "-s", str(port), "-t", "4", "-f"]
    if extra:
        cmd += list(extra)
    cmd += [host, svc]
    return cmd


def hydra_cmd_string(host: str, service: str = "telnet", port: int = 23,
                     userlist: str = "users.txt", passlist: str = "passwords.txt") -> str:
    return " ".join(hydra_cmd(host, service, port, userlist, passlist))


@dataclass
class HydraHit:
    host: str
    port: str
    service: str
    login: str
    password: str


@dataclass
class HydraResult:
    hits: List[HydraHit] = field(default_factory=list)
    def as_dict(self) -> Dict[str, str]:
        return {h.login: h.password for h in self.hits}


_HIT = re.compile(
    r"\[(?P<port>\d+)\]\[(?P<svc>[\w-]+)\]\s+host:\s*(?P<host>\S+)\s+"
    r"login:\s*(?P<login>\S+)\s+password:\s*(?P<pw>\S*)", re.I)


def parse_hydra(output: str) -> HydraResult:
    """Parse hydra's ``[port][service] host: H login: L password: P`` hit lines."""
    res = HydraResult()
    for line in (output or "").splitlines():
        m = _HIT.search(line)
        if m:
            res.hits.append(HydraHit(m.group("host"), m.group("port"), m.group("svc"),
                                     m.group("login"), m.group("pw")))
    return res


# TN3270/TSO note: hydra has no native TN3270 module. For genuine 3270 logon spraying
# use the nmap tso-enum / cics-user-enum scripts PHOSPHOR already emits, or drive the
# terminal via the client. hydra here covers telnet/ftp/http, the network-exposed paths.
TN3270_NOTE = ("hydra has no native TN3270 module; use nmap tso-enum / cics-user-enum "
               "for 3270 logon spraying, and hydra for telnet/ftp/http.")
