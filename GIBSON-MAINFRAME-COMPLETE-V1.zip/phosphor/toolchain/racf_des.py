"""Native legacy RACF DES password verification for PHOSPHOR.

Ports GIBSON's training RACF DES model so PHOSPHOR can test a wordlist against
`$racf$*USER*HASH` hashes directly - no John, no external tool - which sidesteps John's
wordlist/case/EBCDIC quirks and answers "should this wordlist crack these?" instantly.

Algorithm (the historic 8-char RACF DES method):
  key  = per byte: odd_parity(((ebcdic_upper(password)[i] ^ 0x55) << 1))
  hash = DES-ECB encrypt( ebcdic_upper(userid, pad 8) ) under that key
RACF uppercases and truncates to 8 characters and works in EBCDIC (cp037) - the exact
things that trip people up when cracking. Authorised testing / GIBSON training only.
"""
from __future__ import annotations
from typing import Dict, List, Optional, Tuple

try:
    from Cryptodome.Cipher import DES  # type: ignore
except Exception:
    try:
        from Crypto.Cipher import DES  # type: ignore
    except Exception:
        DES = None  # type: ignore


def _des_encrypt(key8: bytes, block8: bytes) -> Optional[bytes]:
    if DES is not None:
        return DES.new(key8, DES.MODE_ECB).encrypt(block8)
    try:  # single DES via TripleDES with K1=K2=K3 (EDE collapses to one DES)
        try:
            from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES
        except Exception:
            from cryptography.hazmat.primitives.ciphers.algorithms import TripleDES
        from cryptography.hazmat.primitives.ciphers import Cipher, modes
        enc = Cipher(TripleDES(key8 * 3), modes.ECB()).encryptor()
        return enc.update(block8) + enc.finalize()
    except Exception:
        return None


def crypto_available() -> bool:
    return _des_encrypt(b"\0" * 8, b"\0" * 8) is not None


def _ebcdic8(value: str) -> bytes:
    return (value or "").upper()[:8].encode("cp037", errors="replace").ljust(8, b"\x40")


def _odd_parity(byte: int) -> int:
    b = byte & 0xFE
    return b | (0 if bin(b).count("1") % 2 else 1)


def _password_key(password: str) -> bytes:
    return bytes(_odd_parity(((ch ^ 0x55) << 1) & 0xFF) for ch in _ebcdic8(password))


def racf_des_hash(userid: str, password: str) -> str:
    """Byte-exact legacy RACF DES hash (hex, upper) for userid/password."""
    uid = (userid or "").upper()[:8]
    if not uid:
        raise ValueError("userid required")
    ct = _des_encrypt(_password_key(password or ""), _ebcdic8(uid))
    if ct is None:
        raise RuntimeError("no DES provider available")
    return ct.hex().upper()


def verify(userid: str, candidate: str, hash_hex: str) -> bool:
    try:
        return racf_des_hash(userid, candidate) == (hash_hex or "").upper().strip()
    except Exception:
        return False


def crack_one(userid: str, hash_hex: str, words) -> Optional[str]:
    """Return the first wordlist entry whose RACF DES hash matches, or None.
    RACF folds case + truncates to 8, so 'kevin', 'KEVIN', 'Kevin123' all normalise."""
    hx = (hash_hex or "").upper().strip()
    if not hx or set(hx) <= {"0"}:
        return None
    for w in words:
        w = w.rstrip("\r\n")
        if not w:
            continue
        if racf_des_hash(userid, w) == hx:
            return w
    return None


def crack_file(hash_path: str, wordlist_path: str):
    """Crack every $racf$*USER*HASH line in hash_path using wordlist_path (native DES)."""
    words = [w.rstrip("\r\n") for w in open(wordlist_path, "r", errors="replace")]
    results = []
    for raw in open(hash_path, "r", errors="replace"):
        raw = raw.strip()
        if "$racf$*" not in raw:
            continue
        user = raw.split(":", 1)[0]
        try:
            hx = raw.split("$racf$*", 1)[1].split("*", 1)[1].strip()
        except Exception:
            continue
        pw = crack_one(user, hx, words)
        results.append((user, hx, pw))
    return results


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("usage: python3 -m phosphor.toolchain.racf_des <racf-hash-file> <wordlist>")
        raise SystemExit(2)
    if not crypto_available():
        print("no DES provider (install pycryptodome, or the 'cryptography' library)")
        raise SystemExit(1)
    hits = 0
    for user, hx, pw in crack_file(sys.argv[1], sys.argv[2]):
        if set(hx.upper()) <= {"0"}:
            print(f"  {user:8} {hx}  (empty - no DES password)")
        elif pw is not None:
            print(f"  {user:8} {hx}  -> {pw}"); hits += 1
        else:
            print(f"  {user:8} {hx}  (not in wordlist)")
    print(f"\nnative RACF DES: cracked {hits} hash(es). RACF folds case + truncates to 8 chars.")
