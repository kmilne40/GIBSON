"""API (curl) and SQL (DB2 for z/OS) launchers for PHOSPHOR.

Modern mainframes expose a lot over the network beyond 3270:

* **REST APIs** - z/OSMF (jobs, datasets, console) on :443, z/OS Connect EE, CICS web
  services. Tested with curl (Basic auth or a bearer token).
* **DB2 for z/OS** - SQL over DRDA/DDF (commonly :446). Tested with a DB2 client: the
  `ibm_db` Python driver, the `db2` CLP, or JDBC.

Both reuse PHOSPHOR's editable console + Run: we stage a correct, ready-to-edit command
and the console executes it in your environment. Authorised testing / GIBSON only.
"""
from __future__ import annotations
import shutil
from typing import List, Tuple


# ---------------------------------------------------------------- API / curl
def curl_available() -> bool:
    return shutil.which("curl") is not None


def _scheme(port) -> str:
    return "https" if str(port) in ("443", "8443", "2443", "10443") else "http"


# common z/OS REST endpoints worth probing (label, method, path)
API_ENDPOINTS: List[Tuple[str, str, str]] = [
    ("z/OSMF info",        "GET", "/zosmf/info"),
    ("z/OSMF list jobs",   "GET", "/zosmf/restjobs/jobs"),
    ("z/OSMF datasets",    "GET", "/zosmf/restfiles/ds?dslevel=SYS1.PARMLIB"),
    ("z/OS Connect APIs",  "GET", "/zosConnect/apis"),
    ("CICS web root",      "GET", "/"),
]


def curl_command(host: str, port: int = 443, path: str = "/zosmf/info",
                 method: str = "GET", auth: str = "USER:PASS", body: str = "") -> str:
    """Build a curl command. -k allows the self-signed certs mainframes often use."""
    parts = ["curl", "-sk", "-X", method, "-u", f"'{auth}'"]
    parts += ["-H", "'Content-Type: application/json'"]
    parts += ["-H", "'X-CSRF-ZOSMF-HEADER: 1'"]           # z/OSMF requires this header
    if body:
        parts += ["-d", f"'{body}'"]
    parts.append(f"{_scheme(port)}://{host}:{port}{path}")
    return " ".join(parts)


# ---------------------------------------------------------------- SQL / DB2
def db2_available() -> bool:
    return shutil.which("db2") is not None


def ibm_db_available() -> bool:
    try:
        import ibm_db  # noqa: F401
        return True
    except Exception:
        return False


def db2_python_command(host: str, port: int = 446, location: str = "DALLASC",
                       user: str = "USER", pw: str = "PASS",
                       sql: str = "SELECT CURRENT SQLID, CURRENT SERVER FROM SYSIBM.SYSDUMMY1") -> str:
    """A one-line ibm_db snippet: connect over DRDA and run one SQL statement.

    The python is base64-encoded so the shell never has to survive the nested quotes in
    the connection string or the SQL - that nesting was closing the outer quote early and
    truncating the command (the SyntaxError: '(' was never closed)."""
    import base64
    conn = (f"DATABASE={location};HOSTNAME={host};PORT={port};PROTOCOL=TCPIP;"
            f"UID={user};PWD={pw};")
    body = (
        "import ibm_db\n"
        f"c=ibm_db.connect({conn!r},'','')\n"
        f"s=ibm_db.exec_immediate(c,{sql!r})\n"
        "r=ibm_db.fetch_assoc(s)\n"
        "print(r or 'no rows')\n"
        "ibm_db.close(c)\n"
    )
    b64 = base64.b64encode(body.encode()).decode()
    return f"python3 -c 'import base64;exec(base64.b64decode(\"{b64}\").decode())'"


def db2_clp_command(location: str = "DALLASC", user: str = "USER", pw: str = "PASS",
                    sql: str = "SELECT * FROM SYSIBM.SYSDUMMY1") -> str:
    """DB2 command-line processor alternative (needs the node/db catalogued first)."""
    return f"db2 connect to {location} user {user} using {pw} && db2 \"{sql}\""


# useful DB2-for-z/OS enumeration queries
DB2_QUERIES: List[Tuple[str, str]] = [
    ("who am I / server", "SELECT CURRENT SQLID, CURRENT SERVER FROM SYSIBM.SYSDUMMY1"),
    ("list schemas",      "SELECT DISTINCT CREATOR FROM SYSIBM.SYSTABLES"),
    ("list tables",       "SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES FETCH FIRST 50 ROWS ONLY"),
    ("my authorities",    "SELECT * FROM SYSIBM.SYSUSERAUTH WHERE GRANTEE=CURRENT SQLID"),
]
