"""John the Ripper + racf2john - scoped to GIBSON's RACF database only.

Workflow (authorised GIBSON testing only):
    1. take a RACF DB unload from GIBSON (e.g. SYS1.RACFDS pulled via FTP)
    2. racf2john <racfds>            -> a John hash file
    3. john --format=racf <hashes>  -> crack
    4. john --show   <hashes>       -> list cracked userid:password

This module builds those exact commands, detects whether the tools are installed, and
parses ``john --show`` output. It deliberately does *not* offer general cracking - only
the RACF-DB path. Nothing here cracks anything by itself; it drives the external tools.
"""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# RACF John formats: legacy DES and modern KDFAES.
RACF_FORMATS = ("racf", "racf-kdfaes")


def have(tool: str) -> bool:
    return shutil.which(tool) is not None


def tools_present() -> Dict[str, bool]:
    return {"racf2john": have("racf2john"), "john": have("john")}


def racf2john_cmd(racfds_path: str, out_path: str = "racf.hashes") -> List[str]:
    """racf2john SYS1.RACFDS > racf.hashes"""
    return ["racf2john", racfds_path]        # stdout is redirected by the caller/shell


def john_cmd(hashes_path: str, fmt: str = "racf",
             wordlist: Optional[str] = None) -> List[str]:
    if fmt not in RACF_FORMATS:
        fmt = "racf"
    cmd = ["john", f"--format={fmt}"]
    if wordlist:
        cmd.append(f"--wordlist={wordlist}")
    cmd.append(hashes_path)
    return cmd


def john_show_cmd(hashes_path: str, fmt: str = "racf") -> List[str]:
    return ["john", "--show", f"--format={fmt}", hashes_path]


def full_chain_commands(racfds_path: str, hashes_path: str = "racf.hashes",
                        fmt: str = "racf", wordlist: Optional[str] = None) -> List[str]:
    """The exact shell commands for the RACF crack chain (for display / copy)."""
    rl = " ".join(racf2john_cmd(racfds_path)) + f" > {hashes_path}"
    return [rl, " ".join(john_cmd(hashes_path, fmt, wordlist)),
            " ".join(john_show_cmd(hashes_path, fmt))]


@dataclass
class CrackResult:
    cracked: Dict[str, str] = field(default_factory=dict)   # userid -> password
    total: int = 0
    remaining: int = 0


def parse_john_show(output: str) -> CrackResult:
    """Parse ``john --show`` output. Lines are ``userid:password:...`` and a summary
    ``N password hashes cracked, M left``."""
    res = CrackResult()
    for line in (output or "").splitlines():
        line = line.rstrip()
        m = re.match(r"^([A-Za-z0-9#$@]{1,8}):([^:]*)", line)
        if m and ":" in line and "password hash" not in line.lower():
            res.cracked[m.group(1).upper()] = m.group(2)
        s = re.search(r"(\d+)\s+password hash(?:es)?\s+cracked,\s+(\d+)\s+left", line, re.I)
        if s:
            res.total = int(s.group(1)) + int(s.group(2))
            res.remaining = int(s.group(2))
    if not res.total and res.cracked:
        res.total = len(res.cracked)
    return res
