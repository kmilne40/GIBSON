"""hack3270-style field injection / brute forcing for PHOSPHOR.

Workflow mirrors hack3270's "Inject Into Fields": the tester types a run of a mask
character (default '*') into the target field, PHOSPHOR finds that run, then injects each
candidate from the chosen wordlist into it, sends the AID, and records the response. Hits
are flagged the way hack3270 does - by responses whose size differs from the common case.

The loop is decoupled from the live socket via a ``send_fn(value, aid) -> response_text``
callable so it is fully testable; the app wires ``send_fn`` to the real field-fill + send +
screen-read against the connected session. Authorised testing / GIBSON training only.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple


def find_mask_field(grid, mask_char: str = "*") -> Optional[Tuple[int, int, int]]:
    """Find the longest run of `mask_char` on the rendered grid.
    Returns (row, col, length) 0-based, or None. `grid` is rows of (char, colour) tuples."""
    best = None
    for r, row in enumerate(grid or []):
        c = 0
        n = len(row)
        while c < n:
            ch = row[c][0] if isinstance(row[c], (list, tuple)) else row[c]
            if ch == mask_char:
                start = c
                while c < n and ((row[c][0] if isinstance(row[c], (list, tuple)) else row[c]) == mask_char):
                    c += 1
                length = c - start
                if best is None or length > best[2]:
                    best = (r, start, length)
            else:
                c += 1
    return best


@dataclass
class InjectResult:
    candidate: str
    length: int
    interesting: bool = False
    snippet: str = ""


@dataclass
class InjectReport:
    results: List[InjectResult] = field(default_factory=list)
    baseline_len: int = 0
    hits: List[InjectResult] = field(default_factory=list)


def analyse(rows: List[InjectResult]) -> InjectReport:
    """Flag responses whose length differs from the most common (baseline) length."""
    rep = InjectReport(results=rows)
    if not rows:
        return rep
    lengths = Counter(r.length for r in rows)
    rep.baseline_len = lengths.most_common(1)[0][0]
    for r in rows:
        r.interesting = (r.length != rep.baseline_len)
        if r.interesting:
            rep.hits.append(r)
    return rep


class Hack3270Injector:
    def __init__(self, send_fn: Callable[[str, str], str]):
        self.send_fn = send_fn
        self.stop = False

    def run(self, candidates: List[str], field_len: Optional[int] = None,
            aid: str = "enter", limit: Optional[int] = None,
            on_result: Optional[Callable[[InjectResult], None]] = None) -> InjectReport:
        rows: List[InjectResult] = []
        for i, cand in enumerate(candidates):
            if self.stop or (limit is not None and i >= limit):
                break
            value = cand[:field_len] if field_len else cand
            try:
                resp = self.send_fn(value, aid) or ""
            except Exception as e:
                resp = f"ERROR {e}"
            r = InjectResult(candidate=cand, length=len(resp), snippet=resp[:60])
            rows.append(r)
            if on_result:
                on_result(r)
        return analyse(rows)
