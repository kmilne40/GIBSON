"""Injection wordlists for hack3270-style field brute forcing (DVCA and friends).

Mirrors hack3270's `injections/` categories: pick a TYPE (numeric-N, alpha-N,
alphanumeric-N, common PINs, CICS transactions, default passwords, dataset names,
fuzz/special chars, SQL/JCL injection, or the DVCA demo lists), and PHOSPHOR either loads
the matching file from an injections directory or generates the candidates. A custom file
from the tools directory is also supported.

Discovery order for file-backed types:
  1. $PHOSPHOR_INJECTIONS_DIR
  2. <tools dir>/injections
  3. a compact built-in fallback (so the picker always works offline)

Authorised testing / GIBSON training only.
"""
from __future__ import annotations
import os
import string
from itertools import product
from typing import List, Optional

# (id, menu label, kind, param)  - kind: numeric|alpha|alphanumeric|file|custom
INJECTION_TYPES = [
    ("numeric-4",              "Numeric 4 (PIN / supervisor)", "numeric", 4),
    ("numeric-6",              "Numeric 6",                    "numeric", 6),
    ("pin-common",             "Common PINs",                  "file", "pin-common.txt"),
    ("alpha-3",                "Alpha 3 (A-Z)",                "alpha", 3),
    ("alphanumeric-4",         "Alphanumeric 4 (A-Z0-9)",      "alphanumeric", 4),
    ("cics-default-transactions", "CICS transaction codes",    "file", "cics-default-transactions.txt"),
    ("common-userids",         "Common user IDs",              "file", "common-userids.txt"),
    ("default-passwords",      "Default passwords",            "file", "default-passwords.txt"),
    ("dataset-names",          "Dataset names",                "file", "dataset-names.txt"),
    ("special-chars",          "Special chars (fuzz)",         "file", "special-chars.txt"),
    ("db2-injections",         "DB2 SQL injection",            "file", "db2-injections.txt"),
    ("jcl-injections",         "JCL injection",                "file", "jcl-injections.txt"),
    ("dvca-demo-numeric-4",    "DVCA demo: 4-digit supervisor", "file", "dvca-demo-numeric-4.txt"),
    ("dvca-demo-transactions", "DVCA demo: transactions",      "file", "dvca-demo-transactions.txt"),
    ("custom",                 "Custom file (tools dir)",      "custom", None),
]
_BY_ID = {t[0]: t for t in INJECTION_TYPES}

# a hard cap so a huge combinatorial list can't exhaust memory / a live session
DEFAULT_LIMIT = 100000

_CHARSET = {
    "numeric": string.digits,
    "alpha": string.ascii_uppercase,
    "alphanumeric": string.ascii_uppercase + string.digits,
}

# compact built-in fallbacks (used when no injections directory is present)
_BUILTIN = {
    "pin-common.txt": ["1234", "1111", "0000", "1212", "7777", "1004", "2000", "4444",
                        "2222", "6969", "9999", "3333", "5555", "6666", "1122", "1313",
                        "8888", "4321", "2001", "1010"],
    "cics-default-transactions.txt": ["CEMT", "CECI", "CEDA", "CEDF", "CESN", "CESF", "CEBR",
                                       "CMAC", "CEST", "CETR", "CWBA", "CICS", "CESL", "CRTE"],
    "common-userids.txt": ["IBMUSER", "SYSADM", "SYSPROG", "CICSUSER", "DFHSM", "OPER", "OPERATOR",
                            "TSOUSER", "DB2ADM", "START1", "GUEST", "TEST", "DVCA"],
    "default-passwords.txt": ["PASSWORD", "PASSW0RD", "PASS", "SYS1", "IBMUSER", "TEMP", "TEMP123",
                              "CHANGEME", "LETMEIN", "SECRET", "MASTER", "ADMIN", "TEST", "DEMO"],
    "dataset-names.txt": ["SYS1.PARMLIB", "SYS1.PROCLIB", "SYS1.LINKLIB", "SYS1.RACFDS",
                          "SYS1.UADS", "SYS1.BRODCAST", "CICS.SDFHLOAD", "USER.ISPF.ISPPROF"],
    "special-chars.txt": ["'", "\"", ";", "--", "/*", "*/", "%", "_", "<", ">", "&", "|",
                          "()", "''", "1=1", "' OR '1'='1", "A" * 80, "A" * 256],
    "db2-injections.txt": ["' OR '1'='1", "' OR 1=1--", "'; DROP TABLE X--", "' UNION SELECT 1--",
                           "' OR 'A'='A", "1;SELECT * FROM SYSIBM.SYSTABLES--"],
    "jcl-injections.txt": ["//X JOB", "// EXEC PGM=IEFBR14", "//SYSIN DD *", "/*", "// EXEC PGM=IKJEFT01"],
    "dvca-demo-numeric-4.txt": [f"{i:04d}" for i in range(0, 100)],   # a short demo range
    "dvca-demo-transactions.txt": ["MCGM", "KSSF", "CESN", "CEMT", "CECI", "DVCA", "MENU"],
}


def injections_dir() -> Optional[str]:
    env = os.environ.get("PHOSPHOR_INJECTIONS_DIR")
    if env and os.path.isdir(env):
        return env
    from phosphor.app import notes as _n
    cand = os.path.join(str(_n.tools_dir()), "injections")
    return cand if os.path.isdir(cand) else None


def type_ids() -> List[str]:
    return [t[0] for t in INJECTION_TYPES]


def label_for(type_id: str) -> str:
    t = _BY_ID.get(type_id)
    return t[1] if t else type_id


def _combos(charset: str, n: int, limit: int) -> List[str]:
    out = []
    for tup in product(charset, repeat=n):
        out.append("".join(tup))
        if len(out) >= limit:
            break
    return out


def _load_file(name: str) -> Optional[List[str]]:
    d = injections_dir()
    if d:
        p = os.path.join(d, name)
        if os.path.isfile(p):
            try:
                return [w.rstrip("\r\n") for w in open(p, "r", errors="replace") if w.strip()]
            except Exception:
                pass
    return _BUILTIN.get(name)


def candidates(type_id: str, limit: int = DEFAULT_LIMIT, custom_name: str = "") -> List[str]:
    """Return the candidate list for an injection type (capped at `limit`)."""
    t = _BY_ID.get(type_id)
    if not t:
        return []
    _id, _label, kind, param = t
    if kind in ("numeric", "alpha", "alphanumeric"):
        return _combos(_CHARSET[kind], int(param), limit)
    if kind == "file":
        return (_load_file(param) or [])[:limit]
    if kind == "custom":
        from phosphor.app import notes as _n
        name = custom_name or "wordlist.txt"
        try:
            return [w.rstrip("\r\n") for w in _n.load_tool_file(name).splitlines() if w.strip()][:limit]
        except Exception:
            return []
    return []


def count(type_id: str) -> int:
    """Exact/approx candidate count (without materialising huge lists)."""
    t = _BY_ID.get(type_id)
    if not t:
        return 0
    _id, _label, kind, param = t
    if kind in ("numeric", "alpha", "alphanumeric"):
        return len(_CHARSET[kind]) ** int(param)
    if kind == "file":
        return len(_load_file(param) or [])
    return -1  # custom / unknown until loaded


def materialise(type_id: str, tools_dir: str, limit: int = DEFAULT_LIMIT, custom_name: str = "") -> Optional[str]:
    """Write the candidate list to <tools_dir>/inject-<type>.txt and return the path."""
    cands = candidates(type_id, limit=limit, custom_name=custom_name)
    if not cands:
        return None
    try:
        os.makedirs(tools_dir, exist_ok=True)
        path = os.path.join(tools_dir, f"inject-{type_id}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(cands) + "\n")
        return path
    except Exception:
        return None
