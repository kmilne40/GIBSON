"""A dependency-free PCAP writer for PHOSPHOR's TN3270 traffic.

The client already taps every inbound/outbound chunk (``_tap``). When capture is on we
frame each chunk as Ethernet/IPv4/TCP and append it to a ``.pcap`` file that Wireshark
opens and dissects as a normal TCP stream (so the TN3270 dissector applies). No scapy,
no tshark, no libpcap - just struct.

Directions: "OUT" = client -> host:port, "IN" = host:port -> client.
Authorised testing / GIBSON training only.
"""
from __future__ import annotations

import struct
import time
from pathlib import Path
from typing import Optional

LINKTYPE_ETHERNET = 1
_PCAP_MAGIC = 0xA1B2C3D4


def _ipv4(s: str) -> bytes:
    return bytes(int(p) & 0xFF for p in s.split("."))


def _checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    total = 0
    for i in range(0, len(data), 2):
        total += (data[i] << 8) | data[i + 1]
    total = (total & 0xFFFF) + (total >> 16)
    total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


class PcapWriter:
    """Write tapped bytes to a Wireshark-readable pcap as a synthetic TCP session."""

    def __init__(self, path: str, client_ip: str = "10.0.0.2", client_port: int = 49152,
                 server_ip: str = "10.0.0.1", server_port: int = 23):
        self.path = str(path)
        self.client_ip, self.client_port = client_ip, int(client_port)
        self.server_ip, self.server_port = server_ip, int(server_port)
        self.seq = {"OUT": 1, "IN": 1}          # per-direction TCP sequence numbers
        self._fh = open(self.path, "wb")
        self._fh.write(struct.pack("<IHHiIII", _PCAP_MAGIC, 2, 4, 0, 0, 65535, LINKTYPE_ETHERNET))
        self.count = 0

    # --- framing ---
    def _eth(self) -> bytes:
        return bytes.fromhex("020000000001") + bytes.fromhex("020000000002") + b"\x08\x00"

    def _ip(self, src: str, dst: str, payload_len: int) -> bytes:
        total = 20 + 20 + payload_len
        hdr = struct.pack(">BBHHHBBH4s4s", 0x45, 0, total, 0, 0x4000, 64, 6, 0,
                          _ipv4(src), _ipv4(dst))
        chk = _checksum(hdr)
        return hdr[:10] + struct.pack(">H", chk) + hdr[12:]

    def _tcp(self, sport: int, dport: int, seq: int, ack: int, payload: bytes) -> bytes:
        offset_flags = (5 << 12) | 0x018      # data offset 5 words, flags PSH+ACK
        return struct.pack(">HHIIHHHH", sport, dport, seq, ack, offset_flags, 8192, 0, 0) + payload

    def packet(self, direction: str, data: bytes, ts: Optional[float] = None) -> None:
        if not data:
            return
        d = "IN" if str(direction).upper().startswith("I") else "OUT"
        if d == "OUT":
            src_ip, dst_ip, sport, dport = self.client_ip, self.server_ip, self.client_port, self.server_port
        else:
            src_ip, dst_ip, sport, dport = self.server_ip, self.client_ip, self.server_port, self.client_port
        ack = self.seq["IN" if d == "OUT" else "OUT"]
        tcp = self._tcp(sport, dport, self.seq[d], ack, bytes(data))
        self.seq[d] += len(data)
        frame = self._eth() + self._ip(src_ip, dst_ip, len(tcp)) + tcp
        t = time.time() if ts is None else ts
        self._fh.write(struct.pack("<IIII", int(t), int((t - int(t)) * 1_000_000), len(frame), len(frame)))
        self._fh.write(frame)
        self.count += 1

    def close(self) -> None:
        try:
            self._fh.close()
        except Exception:
            pass


def default_capture_path(host: str, tools_dir: Optional[str] = None) -> str:
    base = Path(tools_dir) if tools_dir else Path.cwd()
    safe = (host or "session").replace(":", "_").replace("/", "_")
    return str(base / f"capture-{safe}-{time.strftime('%Y%m%d-%H%M%S')}.pcap")


def read_pcap(path: str, server_port: int = 23):
    """Read a pcap this writer produced (Ethernet/IPv4/TCP) and return a list of
    (direction, payload) where direction is 'IN' (from server_port) or 'OUT'.
    Tolerant: skips malformed records. Little-endian pcap only (what we write)."""
    out = []
    try:
        raw = open(path, "rb").read()
    except Exception:
        return out
    if len(raw) < 24 or struct.unpack("<I", raw[:4])[0] != _PCAP_MAGIC:
        return out
    i = 24
    while i + 16 <= len(raw):
        _ts, _us, caplen, _orig = struct.unpack("<IIII", raw[i:i + 16])
        i += 16
        frame = raw[i:i + caplen]; i += caplen
        if len(frame) < 54:
            continue
        # eth(14) + ip(20) + tcp(20); src/dst ports at tcp offset 34..38
        sport = (frame[34] << 8) | frame[35]
        payload = frame[54:]
        if not payload:
            continue
        out.append(("IN" if sport == server_port else "OUT", payload))
    return out
