"""Entry point for `python -m phosphor` and for the compiled binary."""
from phosphor.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
