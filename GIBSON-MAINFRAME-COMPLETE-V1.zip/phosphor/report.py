"""Reporting — turn audit findings into a client-ready deliverable.

Dependency-free (no jinja2): produces Markdown or a self-contained styled HTML
report from a list of Finding objects, grouped by severity, with an executive
summary, evidence, and remediation guidance.
"""
from __future__ import annotations

import datetime
import html as _html
from typing import Dict, List

SEVERITY_ORDER = ["high", "medium", "low", "info"]
SEVERITY_LABEL = {"high": "HIGH", "medium": "MEDIUM", "low": "LOW", "info": "INFO"}
SEVERITY_COLOUR = {"high": "#ff4d4d", "medium": "#ff9f40", "low": "#ffd24d", "info": "#4d9fff"}

# remediation keyed by finding-id prefix (best-effort, extend freely)
REMEDIATION = {
    "cics-ceci-unauth": "Protect CECI, CEMT, CEDA and other supplied transactions "
                        "with RACF (class TCICSTRN) and require sign-on; disable "
                        "them in production regions that do not need them.",
    "cics-tran": "Restrict access to CICS supplied transactions via RACF; only "
                 "authorised operators should reach CEMT/CECI/CEDA.",
    "vtam-applid": "Ensure each VTAM application is behind authentication and that "
                   "unused applids are not exposed to untrusted networks.",
    "tso-user": "Enforce strong passwords/passphrases and MFA for TSO; monitor for "
                "user-enumeration attempts against the logon.",
    "ftp-anon": "Disable anonymous FTP; require authenticated access and restrict "
                "the JES interface (SITE FILETYPE=JES) to authorised users.",
    "db2-das-info": "Restrict the DRDA listener to trusted networks; the server "
                    "identity/version aids targeted attacks.",
    "tn3270-screen": "Informational: the logon banner is exposed. Ensure banners do "
                     "not leak sensitive build/version detail.",
    "cics-user-enum": "No action required where enumeration is not possible; keep "
                      "sign-on responses uniform for valid and invalid users.",
}


def _remediation(fid: str) -> str:
    for pref, text in REMEDIATION.items():
        if fid.startswith(pref):
            return text
    return "Review the finding against your security baseline."


def _group(findings: List) -> Dict[str, List]:
    out = {s: [] for s in SEVERITY_ORDER}
    for f in findings:
        out.get(f.severity, out["info"]).append(f)
    return out


def _counts(findings: List) -> Dict[str, int]:
    c = {s: 0 for s in SEVERITY_ORDER}
    for f in findings:
        c[f.severity] = c.get(f.severity, 0) + 1
    return c


def _risk_line(counts: Dict[str, int]) -> str:
    if counts["high"]:
        return (f"{counts['high']} high-severity finding(s) require prompt "
                f"attention - the region is exploitable as configured.")
    if counts["medium"]:
        return f"{counts['medium']} medium-severity finding(s) should be remediated."
    return "No high or medium findings; posture appears reasonable for the tested surface."


# --- Markdown -------------------------------------------------------------
def to_markdown(findings: List, target: str, when: str = "") -> str:
    when = when or datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    counts = _counts(findings)
    groups = _group(findings)
    out = [f"# Mainframe security assessment — {target}", "",
           f"*Generated {when} by PHOSPHOR. Authorised testing only.*", "",
           "## Executive summary", "",
           f"- High: {counts['high']}  |  Medium: {counts['medium']}  |  "
           f"Low: {counts['low']}  |  Info: {counts['info']}", "",
           f"{_risk_line(counts)}", ""]
    for sev in SEVERITY_ORDER:
        items = groups[sev]
        if not items:
            continue
        out.append(f"## {SEVERITY_LABEL[sev]} findings")
        out.append("")
        for f in items:
            out.append(f"### {f.title}")
            out.append(f"- **Severity:** {SEVERITY_LABEL[sev]}  ")
            out.append(f"- **Finding id:** `{f.id}`  ")
            out.append(f"- **Detail:** {f.detail}")
            if f.evidence:
                out.append("")
                out.append("```")
                out.append(f.evidence.strip()[:1500])
                out.append("```")
            out.append(f"- **Remediation:** {_remediation(f.id)}")
            out.append("")
    return "\n".join(out)


# --- HTML -----------------------------------------------------------------
def to_html(findings: List, target: str, when: str = "") -> str:
    when = when or datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    counts = _counts(findings)
    groups = _group(findings)

    def esc(s):
        return _html.escape(str(s))

    badges = "".join(
        f'<span class="badge" style="background:{SEVERITY_COLOUR[s]}">'
        f'{SEVERITY_LABEL[s]}: {counts[s]}</span>' for s in SEVERITY_ORDER)

    cards = []
    for sev in SEVERITY_ORDER:
        for f in groups[sev]:
            ev = (f'<pre class="evidence">{esc(f.evidence.strip()[:1500])}</pre>'
                  if f.evidence else "")
            cards.append(f"""
      <div class="card">
        <div class="card-h">
          <span class="badge" style="background:{SEVERITY_COLOUR[sev]}">{SEVERITY_LABEL[sev]}</span>
          <span class="title">{esc(f.title)}</span>
          <span class="fid">{esc(f.id)}</span>
        </div>
        <p class="detail">{esc(f.detail)}</p>
        {ev}
        <p class="rem"><strong>Remediation:</strong> {esc(_remediation(f.id))}</p>
      </div>""")

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>PHOSPHOR assessment — {esc(target)}</title>
<style>
  :root {{ --bg:#0b0f0b; --panel:#101610; --fg:#c8f7d0; --dim:#7fae86; --line:#1f2a1f; }}
  * {{ box-sizing:border-box; }}
  body {{ background:var(--bg); color:var(--fg); font-family:-apple-system,Segoe UI,Roboto,sans-serif;
         margin:0; padding:0 0 60px; }}
  header {{ padding:28px 40px; border-bottom:1px solid var(--line);
            background:linear-gradient(180deg,#0f160f,#0b0f0b); }}
  h1 {{ margin:0; font-size:22px; letter-spacing:.5px; }}
  .sub {{ color:var(--dim); font-size:13px; margin-top:6px; }}
  .wrap {{ max-width:920px; margin:0 auto; padding:0 20px; }}
  .summary {{ margin:26px auto; padding:18px 20px; background:var(--panel);
              border:1px solid var(--line); border-radius:10px; }}
  .badges {{ margin:10px 0; }}
  .badge {{ display:inline-block; color:#0b0f0b; font-weight:700; font-size:12px;
            padding:3px 10px; border-radius:20px; margin-right:8px; }}
  .risk {{ color:var(--fg); margin-top:6px; }}
  h2 {{ font-size:15px; color:var(--dim); text-transform:uppercase; letter-spacing:1px;
        margin:34px 0 12px; }}
  .card {{ background:var(--panel); border:1px solid var(--line); border-left:4px solid #333;
           border-radius:8px; padding:14px 16px; margin:12px 0; }}
  .card-h {{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }}
  .title {{ font-weight:600; font-size:15px; }}
  .fid {{ color:var(--dim); font-family:monospace; font-size:12px; margin-left:auto; }}
  .detail {{ margin:8px 0; line-height:1.5; }}
  .evidence {{ background:#060906; border:1px solid var(--line); border-radius:6px;
               padding:10px; overflow:auto; color:#9fe6a8; font-size:12.5px;
               white-space:pre-wrap; max-height:260px; }}
  .rem {{ color:var(--dim); font-size:13px; margin:8px 0 2px; }}
  footer {{ color:var(--dim); font-size:12px; text-align:center; margin-top:40px; }}
</style></head><body>
  <header><div class="wrap">
    <h1>Mainframe security assessment — {esc(target)}</h1>
    <div class="sub">Generated {esc(when)} by PHOSPHOR · authorised testing only</div>
  </div></header>
  <div class="wrap">
    <div class="summary">
      <div class="badges">{badges}</div>
      <div class="risk">{esc(_risk_line(counts))}</div>
    </div>
    {''.join(cards)}
    <footer>PHOSPHOR — native TN3270 audit client. Findings reflect the tested surface only.</footer>
  </div>
</body></html>"""


def write_report(findings: List, path: str, target: str) -> str:
    fmt = "html" if path.lower().endswith((".html", ".htm")) else "md"
    text = to_html(findings, target) if fmt == "html" else to_markdown(findings, target)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path
