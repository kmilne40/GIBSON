"""PHOSPHOR audit modules — the book's enumeration techniques, clean-room, on the
native engine.  Each returns structured findings (dicts) so the reporter can
render them and so results are testable.

Read-only recon only.  Exploitation lives elsewhere behind an explicit gate.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from phosphor.protocols.tn3270.client import TN3270Client


@dataclass
class Finding:
    id: str
    severity: str            # info | low | medium | high
    title: str
    detail: str
    evidence: str = ""

    def as_dict(self) -> Dict:
        return self.__dict__.copy()


def _fresh(host: str, port: int) -> TN3270Client:
    c = TN3270Client()
    c.connect(host, port)
    return c


# --- tn3270-screen --------------------------------------------------------
def tn3270_screen(host: str, port: int = 23) -> Finding:
    """Capture the initial (VTAM/logon) screen — asset identification."""
    c = _fresh(host, port)
    try:
        rows = c.screen_get()
        text = "\n".join(rows)
        return Finding("tn3270-screen", "info", "Logon screen captured",
                       f"{sum(1 for r in rows if r.strip())} non-blank rows",
                       evidence=text)
    finally:
        c.terminate()


# --- vtam-enum ------------------------------------------------------------
DEFAULT_APPLIDS = ["TSO", "CICS", "DB2", "IMS", "ZVM", "TPF", "CICSTS", "NETVIEW"]


def vtam_applids(host: str, port: int = 23,
                 applids: Optional[List[str]] = None) -> List[Finding]:
    """Probe each applid via LOGON APPLID(x); valid ones reach an application,
    invalid ones return the VTAM 'IST097I ... NOT FOUND' rejection."""
    applids = applids or DEFAULT_APPLIDS
    out: List[Finding] = []
    for ap in applids:
        c = _fresh(host, port)
        try:
            c.move_to(24, 1)
            c.send_string(f"LOGON APPLID({ap})")
            c.send_enter()
            text = "\n".join(c.screen_get()).upper()
            not_found = "IST097I" in text or "NOT FOUND" in text
            reached = any(k in text for k in
                          ("WELCOME TO CICS", "TSO/E LOGON", "DSN ", "IMS",
                           "Z/VM", "Z/TPF")) and not not_found
            if reached:
                out.append(Finding(f"vtam-applid-{ap}", "medium",
                                   f"VTAM applid {ap} is reachable",
                                   "Application accepted a LOGON — attack surface",
                                   evidence=text[:200]))
        finally:
            c.terminate()
    return out


# --- cics-enum ------------------------------------------------------------
def cics_transactions(host: str, port: int = 23, applid: str = "CICS",
                      transactions: Optional[List[str]] = None) -> List[Finding]:
    """Reach CICS, then probe transaction ids; a recognised one shows its screen,
    an unknown one returns DFHAC2001 'not recognized'."""
    transactions = transactions or ["CEMT", "CECI", "CEDA", "CEBR", "CESN", "ZZZZ"]
    out: List[Finding] = []
    for tran in transactions:
        c = _fresh(host, port)
        try:
            c.move_to(24, 1); c.send_string(f"LOGON APPLID({applid})"); c.send_enter()
            c.send_clear()                              # blank CICS screen
            c.move_to(1, 1); c.send_string(tran); c.send_enter()
            text = "\n".join(c.screen_get())
            unknown = "DFHAC2001" in text or "not recognized" in text
            if not unknown:
                out.append(Finding(f"cics-tran-{tran}", "low",
                                   f"CICS transaction {tran} is available",
                                   "Transaction ran (not DFHAC2001)",
                                   evidence=text[:160]))
        finally:
            c.terminate()
    return out


# --- tso-enum -------------------------------------------------------------
def tso_users(host: str, port: int = 23, users: Optional[List[str]] = None,
              applid: str = "TSO") -> List[Finding]:
    """Enumerate valid TSO userids.  Valid ids reach a password prompt (or a
    RACF 'revoked' message); invalid ids return IKJ56420I 'not authorized'."""
    users = users or ["IBMUSER", "SYSADM", "TSO001", "OPER1"]
    out: List[Finding] = []
    for u in users:
        c = _fresh(host, port)
        try:
            c.move_to(24, 1); c.send_string(f"LOGON APPLID({applid})"); c.send_enter()
            flds = c.screen.input_fields()
            if flds:
                c.move_to(flds[0].row, flds[0].col)
            c.send_string(u); c.send_enter()
            text = "\n".join(c.screen_get()).upper()
            invalid = "IKJ56420I" in text or "NOT AUTHORIZED TO USE TSO" in text
            if not invalid and text.strip():
                revoked = "REVOKED" in text or "ICH70001I" in text
                out.append(Finding(
                    f"tso-user-{u}", "medium",
                    f"TSO userid {u} is valid" + (" (revoked)" if revoked else ""),
                    "RACF reports the id revoked" if revoked else "Reached the password prompt",
                    evidence=text[:160]))
        finally:
            c.terminate()
    return out


# --- cics-user-enum -------------------------------------------------------
def cics_users(host: str, port: int = 23, applid: str = "CICS",
               users: Optional[List[str]] = None) -> List[Finding]:
    """Probe CICS sign-on (CESN) for user enumeration.  If the region returns a
    different response for valid vs invalid ids, that is the vulnerability; if it
    returns the same DFHCE3520 either way, report the good posture."""
    users = users or ["CICSUSER", "SYSAD", "OPER1", "ZZINVALID"]
    responses = {}
    for u in users:
        c = _fresh(host, port)
        try:
            c.move_to(24, 1); c.send_string(f"LOGON APPLID({applid})"); c.send_enter()
            c.send_clear()
            c.move_to(1, 1); c.send_string("CESN"); c.send_enter()
            flds = c.screen.input_fields()
            if flds:
                c.move_to(flds[0].row, flds[0].col)
                c.send_string(u)
            if len(flds) > 1:
                c.move_to(flds[1].row, flds[1].col)
                c.send_string("WrongPw1")
            c.send_enter()
            text = "\n".join(c.screen_get()).upper()
            responses[u] = "DFHCE3520" in text
        finally:
            c.terminate()
    # if every response is the same, no enumeration is possible
    distinct = set(responses.values())
    if len(distinct) <= 1:
        return [Finding("cics-user-enum", "info",
                        "CICS sign-on does not leak user existence",
                        "CESN returns the same message for invalid users and wrong "
                        "passwords - user enumeration is not possible (good posture).")]
    valid = [u for u, blocked in responses.items() if not blocked]
    return [Finding(f"cics-user-{u}", "medium", f"CICS userid {u} appears valid",
                    "Sign-on response differs from invalid ids", evidence="") for u in valid]


# --- cics-info / cics-posture --------------------------------------------
def cics_region_info(host: str, port: int = 23, applid: str = "CICS") -> List[Finding]:
    """Gather CICS region identity and flag the headline posture issue: is the
    CECI command interpreter reachable with no authentication?"""
    import re
    c = _fresh(host, port)
    out: List[Finding] = []
    try:
        c.move_to(24, 1); c.send_string(f"LOGON APPLID({applid})"); c.send_enter()
        c.send_clear()
        c.move_to(1, 2); c.send_string("CECI ASSIGN USERID(&USE) SYSID(&SYS) APPLID(&APP)")
        c.send_enter(); c.send_enter(); c.send_pf(5)
        d = c.screen_get()
        userid, sysid, appl = d[5][23:].strip(), d[6][23:].strip(), d[7][23:].strip()
        c.send_pf(3)
        if userid and "DFHAC2002" not in "\n".join(d):
            out.append(Finding(
                "cics-ceci-unauth", "high",
                "CECI command interpreter reachable without authentication",
                f"EXEC CICS ASSIGN succeeded (USERID={userid}, SYSID={sysid}); "
                f"the command interpreter runs with the region's authority - a "
                f"critical exposure.",
                evidence=f"USERID={userid} SYSID={sysid} APPLID={appl}"))
        c.send_clear(); c.move_to(1, 2); c.send_string("CEMT I SYS"); c.send_enter()
        text = "\n".join(c.screen_get())
        m = re.search(r"Cicstslevel\((\d+)\)", text)
        dfl = re.search(r"Dfltuser\((\w+)\)", text)
        if m or dfl:
            out.append(Finding(
                "cics-info", "info", "CICS region information",
                f"CICS TS level {m.group(1) if m else '?'}, "
                f"default user {dfl.group(1) if dfl else '?'}",
                evidence=text[:160]))
    finally:
        c.terminate()
    return out


# --- ftp-anon -------------------------------------------------------------
def ftp_anon(host: str, port: int = 21) -> Optional[Finding]:
    """Test whether the mainframe FTP server allows anonymous login."""
    from phosphor.protocols.ftp.client import MainframeFTP
    f = MainframeFTP()
    try:
        banner = f.connect(host, port)
    except Exception:
        return None
    try:
        f.login("anonymous", "anonymous@")
        syst = f.syst()
        return Finding("ftp-anon", "medium", "Anonymous FTP login allowed",
                       "The FTP server accepted an anonymous login - files and "
                       "possibly the JES interface are reachable without credentials.",
                       evidence=(banner + " | " + syst)[:160])
    except Exception:
        return Finding("ftp-anon", "info", "Anonymous FTP not allowed",
                       "The FTP server rejected anonymous login (good posture).",
                       evidence=banner[:120])
    finally:
        f.quit()


# --- db2-das-info ---------------------------------------------------------
def db2_das_info(host: str, port: int = 50000) -> Optional[Finding]:
    """Probe DB2's DRDA listener for server identity (name, release, instance)."""
    from phosphor.protocols.drda.probe import probe
    try:
        info = probe(host, port)
    except Exception:
        return None
    if not info:
        return None
    srv = info.get("srvnam") or info.get("server") or info.get("db2_server", "?")
    rel = info.get("srvrlslv") or info.get("version") or info.get("release", "?")
    ext = info.get("extnam") or info.get("location", "")
    return Finding("db2-das-info", "info", "DB2 DRDA server identified",
                   f"Server {srv}, release {rel}" + (f", instance {ext}" if ext else ""),
                   evidence="; ".join(f"{k}={v}" for k, v in info.items())[:160])
