"""EZrecon - lightweight OSINT / recon toolkit, wired into both PHOSPHOR clients.

Clean-room re-implementation of the core operations from the ``reccy_toolkit``
(reckit.py) as a UI-agnostic module so the curses ``--client`` and the desktop
``--gui`` can both drive it.  Every operation returns plain text lines, so the
front-end only has to display them.

API keys are NEVER stored in this file.  They live in
``~/.config/phosphor/ezrecon_keys.json`` (same place as the licence) and are
prompted for on first use through a caller-supplied prompt callback, so nothing
secret is committed and the user opts in when a tool that needs a key first runs.

Backend tools (subfinder, nmap, whois, the shodan library, dnspython, ...) are
optional: each operation reports cleanly if a dependency is missing and
``backend_report()`` lists what is and isn't available plus how to get it.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

# --- optional dependencies (import lazily / tolerate absence) ---------------
try:
    import requests
except Exception:                       # pragma: no cover
    requests = None


# ============================================================================
#  key storage (no secrets in source)
# ============================================================================
def _config_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    p = Path(base) / "phosphor"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return p


def keys_path() -> Path:
    return _config_dir() / "ezrecon_keys.json"


def load_keys() -> Dict[str, Dict[str, str]]:
    p = keys_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def save_keys(keys: Dict[str, Dict[str, str]]) -> None:
    try:
        keys_path().write_text(json.dumps(keys, indent=2))
        try:
            os.chmod(keys_path(), 0o600)      # keys are secret - lock the file down
        except Exception:
            pass
    except Exception:
        pass


# Services and the fields they need.  Add here to support more key-based tools.
KEY_SERVICES = {
    "shodan": ["api_key"],
    "google": ["api_key", "cse_id"],        # Google Programmable Search (dorking)
}


def have_keys(service: str) -> bool:
    fields = KEY_SERVICES.get(service, [])
    svc = load_keys().get(service, {})
    return all(svc.get(f) for f in fields)


def ensure_keys(service: str, prompt: Optional[Callable[[str], str]] = None
                ) -> Optional[Dict[str, str]]:
    """Return the stored credentials for ``service``.  If any field is missing
    and a ``prompt(field_label) -> value`` callback is given, ask for it and save
    it.  Returns None if the user declines (blank) so the caller can abort.
    """
    fields = KEY_SERVICES.get(service, [])
    keys = load_keys()
    svc = dict(keys.get(service, {}))
    missing = [f for f in fields if not svc.get(f)]
    if missing:
        if prompt is None:
            return None
        for f in missing:
            val = (prompt(f"{service} {f}") or "").strip()
            if not val:
                return None
            svc[f] = val
        keys[service] = svc
        save_keys(keys)
    return svc


def forget_keys(service: str) -> None:
    keys = load_keys()
    if service in keys:
        del keys[service]
        save_keys(keys)


# ============================================================================
#  backend availability
# ============================================================================
def _mod(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


BACKEND_TOOLS = {
    # cli tools (external binaries)
    "subfinder": ("cli", "passive subdomain enumeration",
                  "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),
    "nmap":      ("cli", "port scanning / service detection", "apt install nmap"),
    "whois":     ("cli", "domain registration lookups", "apt install whois"),
    "amass":     ("cli", "(optional) deeper subdomain enum",
                  "go install github.com/owasp-amass/amass/v4/...@master"),
    # python libraries
    "dns":       ("py", "DNS lookups (dnspython)", "pip install dnspython"),
    "requests":  ("py", "HTTP requests", "pip install requests"),
    "bs4":       ("py", "HTML parsing for the email scraper", "pip install beautifulsoup4"),
    "shodan":    ("py", "Shodan host/search client", "pip install shodan"),
}


def backend_status() -> Dict[str, bool]:
    out = {}
    for name, (kind, _desc, _how) in BACKEND_TOOLS.items():
        out[name] = (shutil.which(name) is not None) if kind == "cli" else _mod(name)
    return out


def backend_report() -> List[str]:
    st = backend_status()
    lines = ["EZrecon backend tools", ""]
    for name, (kind, desc, how) in BACKEND_TOOLS.items():
        mark = "OK " if st[name] else "-- "
        lines.append(f"[{mark}] {name:10} ({kind})  {desc}")
        if not st[name]:
            lines.append(f"        install: {how}")
    lines.append("")
    lines.append("Keys (add on first use, stored in ~/.config/phosphor/ezrecon_keys.json):")
    for svc, fields in KEY_SERVICES.items():
        lines.append(f"  {svc:8} : {'set' if have_keys(svc) else 'not set'}  ({', '.join(fields)})")
    return lines


# ============================================================================
#  recon operations  (each returns a list of text lines)
# ============================================================================
_DOMAIN_RE = re.compile(r"^(?!-)([A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63}$")


def is_domain(s: str) -> bool:
    return bool(_DOMAIN_RE.match(s or ""))


def is_ip(s: str) -> bool:
    try:
        socket.inet_aton(s)
        return True
    except Exception:
        return False


def dns_records(domain: str, rtypes=("A", "AAAA", "MX", "NS", "TXT", "SOA")) -> List[str]:
    try:
        import dns.resolver
    except Exception:
        return ["dnspython not installed - pip install dnspython"]
    if not is_domain(domain):
        return [f"not a valid domain: {domain}"]
    out = [f"DNS records for {domain}", ""]
    for rt in rtypes:
        try:
            ans = dns.resolver.resolve(domain, rt)
            for r in ans:
                out.append(f"  {rt:5} {r.to_text()}")
        except Exception:
            out.append(f"  {rt:5} -")
    return out


def whois_lookup(domain: str) -> List[str]:
    if shutil.which("whois") is None:
        return ["whois not installed - apt install whois"]
    try:
        out = subprocess.check_output(["whois", domain], stderr=subprocess.STDOUT, timeout=25)
        text = out.decode("utf-8", "ignore")
        keep = [ln for ln in text.splitlines()
                if any(k in ln.lower() for k in
                       ("registrar", "creation", "expir", "name server",
                        "org", "registrant", "updated", "status", "dnssec"))]
        return [f"WHOIS {domain}", ""] + (keep or text.splitlines()[:40])
    except subprocess.TimeoutExpired:
        return ["whois timed out"]
    except Exception as e:
        return [f"whois error: {e}"]


def zone_transfer(domain: str) -> List[str]:
    try:
        import dns.resolver
        import dns.query
        import dns.zone
    except Exception:
        return ["dnspython not installed - pip install dnspython"]
    out = [f"AXFR zone transfer attempt for {domain}", ""]
    try:
        ns = dns.resolver.resolve(domain, "NS")
    except Exception as e:
        return out + [f"could not list name servers: {e}"]
    for rd in ns:
        nsname = rd.to_text().rstrip(".")
        try:
            ip = dns.resolver.resolve(nsname, "A")[0].to_text()
            z = dns.zone.from_xfr(dns.query.xfr(ip, domain, timeout=8))
            out.append(f"  [!] {nsname} ({ip}) ALLOWED AXFR - misconfiguration:")
            for name in list(z.nodes.keys())[:40]:
                out.append(f"        {name}.{domain}")
        except Exception:
            out.append(f"  [ok] {nsname} refused AXFR")
    return out


# a small builtin list so subdomain discovery works even without subfinder
_COMMON_SUBS = ("www", "mail", "remote", "vpn", "ftp", "webmail", "portal", "test",
                "dev", "staging", "api", "admin", "m", "blog", "shop", "app", "cloud",
                "ns1", "ns2", "smtp", "secure", "gateway", "cics", "tso", "mvs", "as400",
                "intranet", "citrix", "owa", "autodiscover", "vpn2", "git", "jenkins")


def subdomains(domain: str, prompt: Optional[Callable[[str], str]] = None) -> List[str]:
    if not is_domain(domain):
        return [f"not a valid domain: {domain}"]
    found: List[str] = []
    # 1) subfinder if present (passive, fast, thorough)
    if shutil.which("subfinder"):
        try:
            out = subprocess.check_output(["subfinder", "-silent", "-d", domain],
                                          stderr=subprocess.DEVNULL, timeout=90)
            found = [ln.strip() for ln in out.decode("utf-8", "ignore").splitlines() if ln.strip()]
        except Exception:
            found = []
    # 2) fallback: resolve a builtin wordlist
    if not found:
        try:
            import dns.resolver
            for sub in _COMMON_SUBS:
                fqdn = f"{sub}.{domain}"
                try:
                    dns.resolver.resolve(fqdn, "A")
                    found.append(fqdn)
                except Exception:
                    pass
        except Exception:
            return ["dnspython not installed and subfinder absent - "
                    "pip install dnspython or install subfinder"]
    head = [f"Subdomains of {domain}  ({'subfinder' if shutil.which('subfinder') else 'builtin wordlist'})", ""]
    return head + ([f"  {s}" for s in sorted(set(found))] or ["  (none found)"])


def dangling_dns(domain: str) -> List[str]:
    """Flag subdomains whose CNAME points at a target that no longer resolves -
    a classic subdomain-takeover indicator."""
    try:
        import dns.resolver
    except Exception:
        return ["dnspython not installed - pip install dnspython"]
    subs = [s.strip() for s in subdomains(domain) if s.strip().startswith("  ")]
    subs = [s.strip() for s in subs]
    out = [f"Dangling-DNS / takeover check for {domain}", ""]
    checked = 0
    for fqdn in subs:
        try:
            cname = dns.resolver.resolve(fqdn, "CNAME")
            target = cname[0].to_text().rstrip(".")
            checked += 1
            try:
                dns.resolver.resolve(target, "A")
                out.append(f"  [ok]  {fqdn} -> {target}")
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
                out.append(f"  [!!]  {fqdn} -> {target}  DANGLING (target does not resolve)")
        except Exception:
            pass
    if checked == 0:
        out.append("  (no CNAME records among the discovered subdomains)")
    return out


def email_scrape(url: str) -> List[str]:
    if requests is None:
        return ["requests not installed - pip install requests"]
    try:
        from bs4 import BeautifulSoup
    except Exception:
        return ["beautifulsoup4 not installed - pip install beautifulsoup4"]
    if not url.startswith("http"):
        url = "https://" + url
    try:
        r = requests.get(url, timeout=12, headers={"User-Agent": "Mozilla/5.0 EZrecon"})
        soup = BeautifulSoup(r.text, "html.parser")
        emails = set(re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", soup.get_text()))
        return [f"Emails on {url}", ""] + ([f"  {e}" for e in sorted(emails)] or ["  (none found)"])
    except Exception as e:
        return [f"fetch error: {e}"]


def port_scan(host: str, ports=(21, 22, 23, 25, 80, 443, 992, 1414, 2323, 3270, 8080, 50000),
              timeout: float = 1.0) -> List[str]:
    """Prefer nmap if present (service/version), else a plain socket banner grab."""
    if shutil.which("nmap"):
        try:
            spec = ",".join(str(p) for p in ports)
            out = subprocess.check_output(
                ["nmap", "-Pn", "-sV", "-p", spec, host],
                stderr=subprocess.STDOUT, timeout=120)
            return [f"nmap -sV {host}", ""] + out.decode("utf-8", "ignore").splitlines()
        except Exception as e:
            return [f"nmap error: {e}"]
    out = [f"Port scan (socket) {host}", ""]
    for p in ports:
        try:
            with socket.create_connection((host, p), timeout=timeout) as s:
                s.settimeout(timeout)
                try:
                    banner = s.recv(120).decode("latin-1", "ignore").strip()
                except Exception:
                    banner = ""
                out.append(f"  {p:6} open   {banner[:60]}")
        except Exception:
            pass
    if len(out) == 2:
        out.append("  (no open ports among the probed set)")
    out.append("")
    out.append("  tip: install nmap for service/version detection")
    return out


def shodan_host(ip: str, prompt: Optional[Callable[[str], str]] = None) -> List[str]:
    try:
        import shodan as _shodan
    except Exception:
        return ["shodan library not installed - pip install shodan"]
    creds = ensure_keys("shodan", prompt)
    if not creds:
        return ["no Shodan API key provided"]
    try:
        api = _shodan.Shodan(creds["api_key"])
        h = api.host(ip)
    except Exception as e:
        return [f"shodan error: {e}"]
    out = [f"Shodan host {ip}", "",
           f"  org      : {h.get('org', 'N/A')}",
           f"  os       : {h.get('os', 'N/A')}",
           f"  country  : {h.get('country_name', 'N/A')}",
           f"  hostnames: {', '.join(h.get('hostnames', [])) or 'N/A'}",
           f"  ports    : {', '.join(str(p) for p in h.get('ports', [])) or 'N/A'}",
           ""]
    for item in h.get("data", [])[:12]:
        banner = (item.get("banner") or item.get("data") or "").strip().splitlines()
        out.append(f"  port {item.get('port')}: {(banner[0] if banner else '')[:60]}")
    return out


def shodan_search(query: str, prompt: Optional[Callable[[str], str]] = None,
                  limit: int = 25) -> List[str]:
    try:
        import shodan as _shodan
    except Exception:
        return ["shodan library not installed - pip install shodan"]
    creds = ensure_keys("shodan", prompt)
    if not creds:
        return ["no Shodan API key provided"]
    try:
        api = _shodan.Shodan(creds["api_key"])
        res = api.search(query)
    except Exception as e:
        return [f"shodan error: {e}"]
    out = [f"Shodan search: {query}", f"  total: {res.get('total', 0)}", ""]
    for m in res.get("matches", [])[:limit]:
        out.append(f"  {m.get('ip_str', 'N/A'):16} {m.get('org', 'N/A')[:24]:24} "
                   f"ports={','.join(str(p) for p in m.get('ports', []))}")
    return out


# a compact catalogue the front-ends use to build the menu
OPERATIONS = [
    ("dns",       "DNS records (A/MX/NS/TXT/SOA)",     "domain"),
    ("whois",     "WHOIS registration",                "domain"),
    ("subs",      "Subdomain enumeration",             "domain"),
    ("dangling",  "Dangling-DNS / takeover check",     "domain"),
    ("zone",      "Zone-transfer (AXFR) attempt",      "domain"),
    ("email",     "Email scraper",                     "url"),
    ("ports",     "Port scan / banner grab",           "host"),
    ("shodan_host", "Shodan host lookup",              "ip"),
    ("shodan_search", "Shodan search query",           "query"),
    ("backend",   "Backend tool / key status",         None),
]


def run(op: str, target: str = "", prompt: Optional[Callable[[str], str]] = None) -> List[str]:
    """Dispatch a single operation by id.  ``prompt`` is used for API keys."""
    if op == "dns":
        return dns_records(target)
    if op == "whois":
        return whois_lookup(target)
    if op == "subs":
        return subdomains(target, prompt)
    if op == "dangling":
        return dangling_dns(target)
    if op == "zone":
        return zone_transfer(target)
    if op == "email":
        return email_scrape(target)
    if op == "ports":
        return port_scan(target)
    if op == "shodan_host":
        return shodan_host(target, prompt)
    if op == "shodan_search":
        return shodan_search(target, prompt)
    if op == "backend":
        return backend_report()
    return [f"unknown operation: {op}"]
