"""Pluggable terminal-session backends for PHOSPHOR.

The problem: a hand-rolled 3270/5250 data-stream engine is hard to get perfectly
right against every real host (zPDT, production z/OS, IBM i).  Rather than force
both protocols through one clean-room engine, this package lets PHOSPHOR select a
proven backend per protocol, behind one small surface that the rest of the app
already speaks (the same ``.screen`` / ``move_to`` / ``send_string`` /
``send_enter`` surface the FieldEditor and both clients drive).

Engines
-------
- ``native`` : the built-in clean-room engine (no dependencies) - the default.
- ``tnz``    : IBM's TN3270 engine (``pip install tnz ebcdic``), a genuine,
               actively-maintained 3270 data-stream implementation.  Best choice
               for real z/OS / zPDT where the clean-room parser struggles.

TN5250: there is no mature pure-Python engine.  The robust path is the C library
``lib5250`` (from the tn5250 project) wrapped with CFFI/ctypes, or the ``tn5250``
binary as a subprocess.  ``make_connection`` keeps the native 5250 engine as the
default and documents the native-library path in the README; a ``tn5250``
subprocess backend can be slotted in here without touching the UI.
"""
from __future__ import annotations

from typing import Dict


def available_engines() -> Dict[str, bool]:
    """Which backends can run right now (import-checked, no side effects)."""
    engines = {"native": True}
    try:
        import tnz  # noqa: F401
        engines["tnz"] = True
    except Exception:
        engines["tnz"] = False
    return engines


def make_connection(protocol: str = "3270", engine: str = "native",
                    rows: int = 24, cols: int = 80):
    """Return a connection object that duck-types the PHOSPHOR client surface.

    ``protocol`` is "3270" or "5250"; ``engine`` is "native" or "tnz".  Falls back
    to the native engine when a requested backend is unavailable, so a bad choice
    never leaves the user without a terminal.
    """
    protocol = "5250" if str(protocol) == "5250" else "3270"
    engine = (engine or "native").lower()

    if engine == "tnz" and protocol == "3270":
        try:
            from phosphor.session.tnz_backend import TnzSession
            return TnzSession(rows, cols)
        except Exception:
            pass  # tnz missing/broken -> fall through to the native engine

    if protocol == "5250":
        from phosphor.protocols.tn5250.client import TN5250Client
        return TN5250Client(rows, cols)
    from phosphor.protocols.tn3270.client import TN3270Client
    return TN3270Client()


def make_editor(conn):
    """Return the right editor for a connection.  tnz sessions get the tnz-native
    editor (tnz owns field editing); everything else gets the clean-room
    FieldEditor.  Both expose the same surface the GUI and curses client call."""
    if getattr(conn, "engine", None) == "tnz":
        try:
            from phosphor.session.tnz_backend import TnzEditor
            return TnzEditor(conn)
        except Exception:
            pass
    from phosphor.protocols.tn3270.fields import FieldEditor
    return FieldEditor(conn)
