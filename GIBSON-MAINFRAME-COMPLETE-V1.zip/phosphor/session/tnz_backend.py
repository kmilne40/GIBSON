"""IBM ``tnz``-backed TN3270 session.

``tnz`` (github.com/IBM/tnz, ``pip install tnz ebcdic``) is a genuine Python 3270
data-stream engine maintained by IBM.  This adapter drives it and rebuilds a
PHOSPHOR ``ScreenBuffer`` from tnz's screen planes after every host interaction,
so the existing renderer, FieldEditor and both clients keep working unchanged -
they only ever touch ``.screen`` / ``move_to`` / ``send_string`` /
``send_enter`` etc., which this class provides.

tnz owns the protocol (negotiation, MDT bits, field attributes, AID inbound),
which is exactly the part that must be correct against real z/OS.  PHOSPHOR keeps
its local echo (FieldEditor stages edits and flushes them on an AID via
``move_to`` + ``send_string``); on the AID we send through tnz and re-sync the
screen from tnz's authoritative model.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from phosphor.core.screen import Cell, ScreenBuffer

# tnz stores a per-cell foreground colour code in plane_fg.  Map the 3270 colour
# order to PHOSPHOR colour names; unknown -> green (the safe phosphor default).
_TNZ_COLOUR = {
    0: "green", 1: "blue", 2: "red", 3: "pink",
    4: "green", 5: "turquoise", 6: "yellow", 7: "white",
    0xF0: "neutral", 0xF1: "blue", 0xF2: "red", 0xF3: "pink",
    0xF4: "green", 0xF5: "turquoise", 0xF6: "yellow", 0xF7: "white",
}


def screen_from_tnz(t) -> ScreenBuffer:
    """Convert a tnz terminal's current screen into a PHOSPHOR ScreenBuffer."""
    rows, cols = int(t.maxrow), int(t.maxcol)
    sb = ScreenBuffer(rows, cols)
    n = rows * cols
    try:
        text = t.scrstr(0, n)
    except Exception:
        text = " " * n
    fa = getattr(t, "plane_fa", b"")
    fg = getattr(t, "plane_fg", b"")
    for addr in range(min(n, len(sb.cells))):
        is_fa = addr < len(fa) and fa[addr] != 0
        ch = text[addr] if addr < len(text) else " "
        if not ch or ch == "\x00":
            ch = " "
        colour = _TNZ_COLOUR.get(fg[addr] if addr < len(fg) else 0, "green")
        try:
            prot = bool(t.is_protected(addr))
        except Exception:
            prot = True
        sb.cells[addr] = Cell(char=(" " if is_fa else ch), colour=colour,
                              protected=prot, is_field_start=is_fa)
    sb.cursor = int(getattr(t, "curadd", 0)) % max(1, n)
    sb.keyboard_locked = False
    return sb


class TnzSession:
    """A drop-in TN3270 connection backed by IBM tnz."""

    def __init__(self, rows: int = 24, cols: int = 80) -> None:
        from tnz import tnz as tnzmod       # imported lazily so native users need no tnz
        self._mod = tnzmod
        self.t = tnzmod.Tnz()
        self.screen = ScreenBuffer(rows, cols)
        self.packets = None                 # live pcap tap not wired for this backend
        self.pcap = None
        self.connected = False
        self._pending_cursor: Optional[Tuple[int, int]] = None
        self.engine = "tnz"

    # --- connection ------------------------------------------------------
    def connect(self, host: str, port: int = 23, secure: bool = False) -> None:
        self.t.connect(host, port, secure=secure, verifycert=False)
        try:
            self.t.wait(timeout=10)
        except Exception:
            pass
        self._sync()
        self.connected = True

    def terminate(self) -> None:
        try:
            self.t.shutdown()
        except Exception:
            pass
        self.connected = False

    def is_connected(self) -> bool:
        return self.connected

    # --- screen sync -----------------------------------------------------
    def _sync(self) -> None:
        try:
            self.screen = screen_from_tnz(self.t)
        except Exception:
            pass

    # --- input staging (called by FieldEditor._flush) --------------------
    def move_to(self, row: int, col: int) -> None:
        self._pending_cursor = (row, col)

    def send_string(self, text: str) -> None:
        if self._pending_cursor is not None:
            r, c = self._pending_cursor
            try:
                self.t.set_cursor_address((r - 1) * int(self.t.maxcol) + (c - 1))
            except Exception:
                pass
        try:
            self.t.key_data(text)
        except Exception:
            pass

    safe_send = send_string

    # --- AIDs (send, then re-sync the screen from tnz truth) -------------
    def _aid(self, fn, *args) -> None:
        try:
            fn(*args)
            self.t.wait(timeout=10)
        except Exception:
            pass
        self._pending_cursor = None
        self._sync()

    def send_enter(self) -> None:
        self._aid(self.t.enter)

    def send_clear(self) -> None:
        self._aid(self.t.clear)

    def send_pf(self, n: int) -> None:
        fn = getattr(self.t, f"pf{int(n)}", None)
        if fn:
            self._aid(fn)

    def send_pa(self, n: int) -> None:
        fn = getattr(self.t, f"pa{int(n)}", None)
        if fn:
            self._aid(fn)

    def send_pf3(self) -> None:
        self.send_pf(3)

    # --- read surface the app/FieldEditor use ---------------------------
    def colour_grid(self):
        return self.screen.colour_grid()

    def screen_get(self) -> List[str]:
        return self.screen.to_rows()

    def find(self, text: str) -> bool:
        return self.screen.find(text)

    find_response = find

    def get_pos(self) -> Tuple[int, int]:
        return self.screen.rc(self.screen.cursor)


class TnzEditor:
    """A FieldEditor-compatible editor that routes all input to tnz.

    tnz owns the 3270 field model, field protection, insert mode, cursor motion
    and local echo - so instead of reconstructing that in PHOSPHOR (which is what
    made typing fail on the tnz backend), every keystroke goes straight to tnz and
    the screen is re-synced from tnz afterwards.  The surface matches the bits of
    FieldEditor that the GUI and the curses client call.
    """

    def __init__(self, conn: "TnzSession") -> None:
        self.c = conn
        self.t = conn.t
        self._edits = {}                 # kept only so callers that poke it don't crash

    # cursor as a 1-based (row, col) tuple, backed by tnz's buffer address
    @property
    def cursor(self) -> Tuple[int, int]:
        cols = int(self.t.maxcol)
        n = int(self.t.maxrow) * cols
        a = int(getattr(self.t, "curadd", 0)) % max(1, n)
        return (a // cols + 1, a % cols + 1)

    @cursor.setter
    def cursor(self, rc: Tuple[int, int]) -> None:
        r, c = rc
        try:
            self.t.set_cursor_address((r - 1) * int(self.t.maxcol) + (c - 1))
        except Exception:
            pass

    def _resync(self) -> None:
        self.c._sync()

    # --- local editing (tnz echoes into its own planes immediately) ------
    def type_char(self, ch: str) -> None:
        if ch and ch.isprintable():
            try:
                self.t.key_data(ch)
            except Exception:
                pass
            self._resync()

    def backspace(self) -> None:
        self._key("key_backspace")

    def tab(self, back: bool = False) -> None:
        self._key("key_backtab" if back else "key_tab")

    def field_up(self) -> None:
        self._key("key_curup")

    def field_down(self) -> None:
        self._key("key_curdown")

    def move(self, dr: int, dc: int) -> None:
        name = ("key_curleft" if dc < 0 else "key_curright" if dc > 0
                else "key_curup" if dr < 0 else "key_curdown")
        self._key(name)

    def home(self) -> None:
        self._key("key_home")

    def delete(self) -> None:
        self._key("key_delete")

    def erase_eof(self) -> None:
        self._key("key_eraseeof")

    def erase_input(self) -> None:
        self._key("key_eraseinput")

    def click(self, row: int, col: int) -> None:
        self.cursor = (row, col)

    def set_field(self, row: int, col: int, text: str) -> None:
        self.cursor = (row, col)
        try:
            self.t.key_data(text)
        except Exception:
            pass
        self._resync()

    def sync_cursor(self) -> None:
        self._resync()

    def _key(self, name: str) -> None:
        fn = getattr(self.t, name, None)
        if fn:
            try:
                fn()
            except Exception:
                pass
        self._resync()

    # --- AIDs ------------------------------------------------------------
    def _aid(self, fn) -> None:
        try:
            fn()
            self.t.wait(timeout=10)
        except Exception:
            pass
        self._resync()

    def enter(self) -> None:
        self._aid(self.t.enter)

    def clear(self) -> None:
        self._aid(self.t.clear)

    def pf(self, n: int) -> None:
        fn = getattr(self.t, f"pf{int(n)}", None)
        if fn:
            self._aid(fn)

    def pa(self, n: int) -> None:
        fn = getattr(self.t, f"pa{int(n)}", None)
        if fn:
            self._aid(fn)

    # --- reads the app uses ---------------------------------------------
    def grid_with_edits(self):
        return self.c.colour_grid()

    def fields(self):
        try:
            return list(self.c.screen.fields())
        except Exception:
            return []

    def input_fields(self):
        try:
            return list(self.c.screen.input_fields())
        except Exception:
            return []

    def _field_at(self, row: int, col: int):
        for f in self.fields():
            if f.row == row and f.col <= col < f.col + f.length:
                return f
        return None

    def _field_blank(self, f) -> bool:
        return True
