"""Full-screen curses TN3270 / TN5250 client - a boxed operator console.

    phosphor <host> [port] --client            # TN3270  (curses full screen)
    phosphor <host> [port] --client --5250     # TN5250 / IBM i

The terminal glass sits in the centre; the physical 3270 operator keypad is
drawn as boxes AROUND it - the PA / operator column on the left, the PF grid
across the top, the cursor / edit cluster on the right, and the
Tab / Reset / New-Line / Enter band plus the tool MENU under it.  A ':' command
line is pinned at the very bottom (the vi touch).  The arrangement mirrors the
reference 3270 keypad and the positions of the desktop (--gui) client.

Every box is usable two ways, exactly as asked:
  * click it with the mouse, or
  * press Ctrl-K to enter keypad-nav, move the highlight with the arrows, and
    press Enter to fire it (Esc / Ctrl-K returns to the glass).

Typing / editing (glass has focus by default):
  typing            goes into the field under the cursor (unprotected fields)
  Arrows            move the cursor          Tab / Shift-Tab   next / prev field
  Enter             send (AID ENTER)         Home              start of field
  Backspace / Del   erase                    Ctrl-U            erase to end of field
  Insert            toggle insert/overtype   F1..F24           PF1..PF24
  Ctrl-L  redraw    Ctrl-R reset             Esc then 1/2/3    PA1 / PA2 / PA3
  Ctrl-K            enter / leave keypad navigation (arrows + Enter on the boxes)
  :                 command line ->  :menu :upload :download :ftp :pf N :pa N
                                     :clear :mono :save FILE :help :q  (quit)

Lighter than the PHOSPHOR desktop app (no skins or packet view) - a terminal,
the full operator keypad, and transfers, for SSH / headless use.
"""
from __future__ import annotations
import sys

from phosphor.client_panels import build_layout, GLASS_ROWS, GLASS_COLS

# DUP / Field-Mark local placeholders (real 3270 order bytes 0x1C / 0x1E)
_DUP = "\u00a4"          # shown for Dup   (currency sign, stands in for the DUP glyph)
_FM = ";"               # shown for Field Mark

# 3270 colour name -> (curses colour, bold)
_COLOURS = {
    "green": ("GREEN", False), "red": ("RED", True), "blue": ("BLUE", True),
    "white": ("WHITE", True), "turquoise": ("CYAN", False), "cyan": ("CYAN", False),
    "yellow": ("YELLOW", True), "pink": ("MAGENTA", True), "magenta": ("MAGENTA", True),
    "neutral": ("WHITE", False), "default": ("GREEN", False),
}


def available() -> bool:
    try:
        import curses  # noqa
        return sys.stdout.isatty()
    except Exception:
        return False


def _connect(host, port, protocol, engine="native"):
    from phosphor.session import make_connection
    c = make_connection(protocol, engine)
    c.connect(host, port)
    return c


def run_tui(host: str, port: int = 23, protocol: str = "3270",
            engine: str = "native") -> int:
    import curses
    try:
        conn = _connect(host, port, protocol, engine)
    except Exception as e:
        print(f"[!] connect failed: {e}", file=sys.stderr)
        return 1
    from phosphor.session import make_editor
    ed = make_editor(conn)
    con = Console(conn, ed, host, port, protocol)
    try:
        curses.wrapper(con.loop)
    finally:
        try:
            conn.terminate()
        except Exception:
            pass
    print("[+] disconnected")
    return 0


# ============================================================================
#  the console
# ============================================================================
class Console:
    def __init__(self, conn, ed, host, port, protocol):
        self.c = conn
        self.ed = ed
        self.host = host
        self.port = port
        self.protocol = protocol
        self.kind = "TN5250" if protocol == "5250" else "TN3270"
        self.mono = False
        self.insert = False
        self.nav = False                 # keypad-navigation mode
        self.focus_id = None             # currently highlighted box (nav / hover)
        self.pressed = None              # box flashed as pressed this frame
        self.msg = ""                    # transient status message
        self.lay = None

    # ---- curses setup ---------------------------------------------------
    def loop(self, stdscr):
        import curses
        curses.curs_set(1)
        stdscr.keypad(True)
        try:
            curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        except Exception:
            pass
        self.pairs = _init_colours()
        while True:
            self._relayout(stdscr)
            self._draw(stdscr)
            try:
                k = stdscr.get_wch()
            except curses.error:
                continue
            except (EOFError, KeyboardInterrupt):
                break
            if k == curses.KEY_MOUSE:
                if self._on_mouse(stdscr):
                    break
                continue
            if self.nav:
                if self._nav_key(stdscr, k):
                    break
                continue
            if self._term_key(stdscr, k):
                break

    def _relayout(self, stdscr):
        maxy, maxx = stdscr.getmaxyx()
        self.lay = build_layout(maxy, maxx)
        if self.focus_id is None:
            self.focus_id = self.lay.first_nav()

    # ---- drawing --------------------------------------------------------
    def _draw(self, stdscr):
        import curses
        stdscr.erase()
        lay = self.lay
        maxy, maxx = stdscr.getmaxyx()
        # wordmark top-left, in the style of the GUI client
        try:
            stdscr.addstr(0, 0, "PHOSPHOR",
                          curses.color_pair(self.pairs.get("CYAN", 5)) | curses.A_BOLD)
        except curses.error:
            pass
        self._draw_glass(stdscr)
        # PF grid border (spans the pf cells) then every box
        self._draw_pf_border(stdscr)
        for b in lay.boxes:
            self._draw_box(stdscr, b)
        # command line + status pinned at the bottom
        cmd = f"{'-- INSERT --  ' if self.insert else ''}: (command)   press ':' to type, Ctrl-K keypad"
        try:
            stdscr.addstr(min(lay.cmd_y, maxy - 2), 0, cmd[:maxx - 1], curses.A_DIM)
        except curses.error:
            pass
        st = self.msg or self._status()
        try:
            stdscr.addstr(min(lay.status_y, maxy - 1), 0,
                          st[:maxx - 1].ljust(maxx - 1), curses.A_REVERSE)
        except curses.error:
            pass
        self.msg = ""
        # park the hardware cursor on the glass unless we're navigating boxes
        if not self.nav:
            cr, cc = self.ed.cursor
            gy = lay.glass_y + cr - 1
            gx = lay.glass_x + cc - 1
            if 0 <= gy < maxy and 0 <= gx < maxx:
                try:
                    curses.curs_set(1)
                    stdscr.move(gy, gx)
                except curses.error:
                    pass
        else:
            try:
                curses.curs_set(0)
            except curses.error:
                pass
        stdscr.refresh()

    def _status(self):
        r, c = self.ed.cursor
        nav = "  [KEYPAD NAV: arrows+Enter, Esc=glass]" if self.nav else ""
        return (f" {self.kind} {self.host}:{self.port}   r{r} c{c}   "
                f"F-keys=PF  Tab=field  Enter=send  Ctrl-K=keypad  :=cmd (:q quit){nav} ")

    def _draw_glass(self, stdscr):
        import curses
        lay = self.lay
        grid = self.ed.grid_with_edits()
        for r in range(GLASS_ROWS):
            row = grid[r] if r < len(grid) else []
            for cc in range(GLASS_COLS):
                cell = row[cc] if cc < len(row) else (" ", "green")
                ch = cell[0] or " "
                colour = "green" if self.mono else (cell[1] if len(cell) > 1 else "green")
                cname, bold = _COLOURS.get(colour, ("GREEN", False))
                attr = curses.color_pair(self.pairs.get(cname, 1))
                if bold:
                    attr |= curses.A_BOLD
                try:
                    stdscr.addstr(lay.glass_y + r, lay.glass_x + cc, ch, attr)
                except curses.error:
                    pass

    def _draw_pf_border(self, stdscr):
        import curses
        lay = self.lay
        pf = [b for b in lay.boxes if b.id.startswith("k_pf")]
        if not pf:
            return
        x0 = min(b.x for b in pf)
        x1 = max(b.x + b.w for b in pf)
        y_top = min(b.y for b in pf)
        y_bot = max(b.y for b in pf)
        dim = curses.color_pair(self.pairs.get("WHITE", 4)) | curses.A_DIM
        try:
            stdscr.addstr(y_top - 1, x0, "PF", curses.A_DIM)
            stdscr.addstr(y_bot, x0 - 3 if x0 >= 3 else x0, "PF", curses.A_DIM)
        except curses.error:
            pass
        # top / bottom rules + column separators
        for yy in (y_top - 1, y_bot + 1):
            try:
                stdscr.addstr(yy, x0, "\u2500" * (x1 - x0), dim)
            except curses.error:
                pass

    def _draw_box(self, stdscr, b):
        import curses
        lay = self.lay
        focused = (b.id == self.focus_id and (self.nav or self.pressed is None))
        pressed = (b.id == self.pressed)
        base = self._accent_attr(b.accent)
        border = base | (curses.A_BOLD | curses.A_REVERSE if focused else curses.A_DIM)
        label = base | (curses.A_BOLD if (focused or b.accent in ("active", "warn")) else 0)
        if pressed:
            border = base | curses.A_REVERSE
            label = base | curses.A_REVERSE
        if b.h == 1:
            # PF grid cell: │NN│  (separators drawn per cell)
            txt = "\u2502" + b.label.center(b.w - 1)
            try:
                stdscr.addstr(b.y, b.x, txt[:b.w], label if (focused or pressed) else base | curses.A_DIM)
                if b.x + b.w >= lay.glass_x + GLASS_COLS - b.w:  # last-ish column: close bar
                    pass
            except curses.error:
                pass
            return
        # full 3-row box
        w = b.w
        top = "\u250c" + "\u2500" * (w - 2) + "\u2510"
        mid = "\u2502" + b.label.center(w - 2)[:w - 2] + "\u2502"
        bot = "\u2514" + "\u2500" * (w - 2) + "\u2518"
        try:
            stdscr.addstr(b.y, b.x, top, border)
            stdscr.addstr(b.y + 1, b.x, mid[:1], border)
            stdscr.addstr(b.y + 1, b.x + 1, b.label.center(w - 2)[:w - 2], label)
            stdscr.addstr(b.y + 1, b.x + w - 1, "\u2502", border)
            stdscr.addstr(b.y + 2, b.x, bot, border)
        except curses.error:
            pass

    def _accent_attr(self, accent):
        import curses
        cp = self.pairs
        if accent == "warn":
            return curses.color_pair(cp.get("RED", 2)) | curses.A_BOLD
        if accent == "active":
            return curses.color_pair(cp.get("GREEN", 1)) | curses.A_BOLD
        if accent == "accent":
            return curses.color_pair(cp.get("CYAN", 5))
        if accent == "amber":
            return curses.color_pair(cp.get("YELLOW", 6))
        return curses.color_pair(cp.get("WHITE", 4))

    # ---- mouse ----------------------------------------------------------
    def _on_mouse(self, stdscr):
        import curses
        try:
            _id, mx, my, _z, bstate = curses.getmouse()
        except curses.error:
            return False
        hit = self.lay.hit(my, mx)
        if hit is None:
            return False
        if isinstance(hit, tuple) and hit[0] == "glass":
            self.ed.click(hit[1], hit[2])
            self.nav = False
            return False
        # a box was clicked
        self.focus_id = hit
        return self._fire(stdscr, hit)

    # ---- keypad navigation ---------------------------------------------
    def _nav_key(self, stdscr, k):
        import curses
        if k in ("\x0b",) or k == 11:                # Ctrl-K -> leave nav
            self.nav = False
            return False
        if k == "\x1b" or k == 27:                   # Esc -> leave nav
            self.nav = False
            return False
        if k in (curses.KEY_UP,):
            self.focus_id = self.lay.neighbour(self.focus_id, -1, 0)
        elif k in (curses.KEY_DOWN,):
            self.focus_id = self.lay.neighbour(self.focus_id, 1, 0)
        elif k in (curses.KEY_LEFT,):
            self.focus_id = self.lay.neighbour(self.focus_id, 0, -1)
        elif k in (curses.KEY_RIGHT,):
            self.focus_id = self.lay.neighbour(self.focus_id, 0, 1)
        elif k in (curses.KEY_ENTER, "\n", "\r", 10, 13, " "):
            return self._fire(stdscr, self.focus_id)
        return False

    # ---- terminal-focus keys -------------------------------------------
    def _term_key(self, stdscr, k):
        import curses
        ed = self.ed
        if isinstance(k, str):
            if k == ":":
                return _command_line(stdscr, self)
            if k == "\x0b":                          # Ctrl-K -> keypad nav
                self.nav = True
                if self.focus_id is None:
                    self.focus_id = self.lay.first_nav()
                return False
            if k in ("\n", "\r"):
                ed.enter(); return False
            if k == "\t":
                ed.tab(); return False
            if k == "\x1b[Z":
                ed.tab(back=True); return False
            if k in ("\x08", "\x7f"):
                ed.backspace(); return False
            if k == "\x0c":                          # Ctrl-L redraw
                return False
            if k == "\x15":                          # Ctrl-U erase to eof
                ed.erase_eof(); return False
            if k == "\x12":                          # Ctrl-R reset
                ed.sync_cursor(); return False
            if k == "\x1b":                          # Esc -> PA keys
                stdscr.nodelay(True)
                try:
                    n = stdscr.getch()
                finally:
                    stdscr.nodelay(False)
                if n in (ord("1"), ord("2"), ord("3")):
                    ed.pa(n - ord("0"))
                return False
            if k.isprintable():
                self._type(k)
            return False
        # integer special keys
        if k in (curses.KEY_ENTER, 10, 13):
            ed.enter()
        elif k in (9, curses.KEY_STAB):
            ed.tab()
        elif k == curses.KEY_BTAB:
            ed.tab(back=True)
        elif k == curses.KEY_BACKSPACE:
            ed.backspace()
        elif k == curses.KEY_DC:
            self._delete()
        elif k == curses.KEY_IC:
            self.insert = not self.insert
            self.msg = f"[insert {'on' if self.insert else 'off'}]"
        elif k == curses.KEY_LEFT:
            ed.move(0, -1)
        elif k == curses.KEY_RIGHT:
            ed.move(0, 1)
        elif k == curses.KEY_UP:
            ed.field_up()
        elif k == curses.KEY_DOWN:
            ed.field_down()
        elif k == curses.KEY_HOME:
            self._home()
        elif curses.KEY_F1 <= k <= curses.KEY_F1 + 23:
            ed.pf(k - curses.KEY_F1 + 1)
        return False

    # ---- local field helpers -------------------------------------------
    def _field_ctx(self):
        ed = self.ed
        r, col = ed.cursor
        f = ed._field_at(r, col)
        if not f:
            return None
        key = (f.row, f.col)
        buf = ed._edits.get(key, "")
        return f, key, buf, col - f.col

    def _type(self, ch):
        if not self.insert:
            self.ed.type_char(ch); return
        ctx = self._field_ctx()
        if not ctx:
            return
        f, key, buf, off = ctx
        buf = (buf + " " * max(0, off - len(buf)))
        buf = buf[:off] + ch + buf[off:]
        self.ed._edits[key] = buf[:f.length]
        r, col = self.ed.cursor
        if off + 1 < f.length:
            self.ed.cursor = (r, col + 1)

    def _delete(self):
        if hasattr(self.ed, "delete"):          # tnz editor deletes natively
            self.ed.delete(); return
        ctx = self._field_ctx()
        if not ctx:
            self.ed.backspace(); return
        f, key, buf, off = ctx
        if 0 <= off < len(buf):
            self.ed._edits[key] = buf[:off] + buf[off + 1:]

    def _home(self):
        if hasattr(self.ed, "home"):            # tnz editor homes natively
            self.ed.home(); return
        f = self.ed._field_at(*self.ed.cursor)
        if f:
            self.ed.cursor = (f.row, f.col)
        else:
            flds = self.ed.fields()
            if flds:
                self.ed.cursor = (flds[0].row, flds[0].col)

    def _dup(self):
        self._type(_DUP)
        self.ed.tab()
        self.msg = "[Dup]"

    def _fieldmark(self):
        self._type(_FM)
        self.msg = "[Field Mark]"

    # ---- box dispatch (mirrors the GUI keypad() + menus) ----------------
    def _fire(self, stdscr, bid):
        """Run a box's action with a brief press animation.  Returns True to quit."""
        self.pressed = bid
        self._draw(stdscr)                     # show the press
        self.pressed = None
        return self._apply(stdscr, bid)

    def _apply(self, stdscr, bid):
        """Dispatch a box id to its action (no drawing - unit testable).
        ``stdscr`` is only used by the branches that open pop-up menus."""
        ed = self.ed
        b = self.lay.box(bid) if self.lay else None
        if b and b.help:
            self.msg = b.help
        if bid.startswith("k_pf"):
            ed.pf(int(bid[4:]))
        elif bid.startswith("k_pa"):
            ed.pa(int(bid[4:]))
        elif bid in ("k_enter", "k_newline"):
            ed.enter()
        elif bid == "k_clear":
            ed.clear()
        elif bid == "k_tab":
            ed.tab()
        elif bid == "k_backtab":
            ed.tab(back=True)
        elif bid == "k_attn":
            ed.pa(1)
        elif bid == "k_reset":
            ed.sync_cursor(); self.msg = "[keyboard reset]"
        elif bid == "k_eeof":
            ed.erase_eof()
        elif bid == "k_einp":
            ed._edits.clear(); self.msg = "[erase input]"
        elif bid == "k_home":
            self._home()
        elif bid == "k_insert":
            self.insert = not self.insert
            self.msg = f"[insert {'on' if self.insert else 'off'}]"
        elif bid == "k_delete":
            self._delete()
        elif bid == "k_dup":
            self._dup()
        elif bid == "k_fieldmark":
            self._fieldmark()
        elif bid == "k_curselect":
            self.msg = "[Cursor Select - no host mapping in TN3270 basic]"
        elif bid == "k_compose":
            self.msg = "[Compose - local dead-key compose]"
        elif bid == "k_sysreq":
            self.msg = "[SysReq - attention; not wired in TN3270 basic]"
        elif bid == "b_menu":
            self.nav = False
            _transfer_menu(stdscr, self)
        elif bid == "b_settings":
            self.nav = False
            _settings_menu(stdscr, self)
        elif bid == "b_help":
            self.nav = False
            _help_popup(stdscr, self)
        elif bid == "b_quit":
            return True
        return False


def _init_colours():
    import curses
    curses.start_color()
    try:
        curses.use_default_colors()
        bg = -1
    except Exception:
        bg = curses.COLOR_BLACK
    pairs = {}
    idx = 1
    for name in ("GREEN", "RED", "BLUE", "WHITE", "CYAN", "YELLOW", "MAGENTA"):
        curses.init_pair(idx, getattr(curses, "COLOR_" + name), bg)
        pairs[name] = idx
        idx += 1
    return pairs


# ============================================================================
#  bottom ':' command line  +  pop-up menus (same options as the GUI)
# ============================================================================
def _prompt(stdscr, text):
    import curses
    maxy, maxx = stdscr.getmaxyx()
    curses.curs_set(1)
    curses.echo()
    try:
        stdscr.addstr(maxy - 1, 0, " " * (maxx - 1))
        stdscr.addstr(maxy - 1, 0, text[:maxx - 1])
        stdscr.refresh()
        s = stdscr.getstr(maxy - 1, min(len(text), maxx - 2), 200)
    finally:
        curses.noecho()
    try:
        return s.decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def _flash(stdscr, msg):
    import curses
    maxy, maxx = stdscr.getmaxyx()
    try:
        stdscr.addstr(maxy - 1, 0, msg[:maxx - 1].ljust(maxx - 1), curses.A_BOLD)
        stdscr.refresh()
        curses.napms(900)
    except curses.error:
        pass


def _command_line(stdscr, con) -> bool:
    """Handle a ':' command.  Returns True to quit."""
    conn, ed = con.c, con.ed
    cmd = _prompt(stdscr, ":").strip()
    low = cmd.lower()
    if low in ("q", "quit", "exit"):
        return True
    elif low in ("menu", "m"):
        _transfer_menu(stdscr, con)
    elif low in ("set", "settings"):
        _settings_menu(stdscr, con)
    elif low in ("help", "?"):
        _help_popup(stdscr, con)
    elif low in ("clear",):
        ed.clear()
    elif low in ("mono",):
        con.mono = not con.mono
    elif low.startswith("pf"):
        try:
            ed.pf(int(cmd[2:]))
        except Exception:
            pass
    elif low.startswith("pa"):
        try:
            ed.pa(int(cmd[2:]))
        except Exception:
            pass
    elif low.startswith("save "):
        try:
            with open(cmd[5:].strip(), "w") as f:
                f.write(_screen_text(conn.screen) + "\n")
            _flash(stdscr, f"[+] saved to {cmd[5:].strip()}")
        except Exception as e:
            _flash(stdscr, f"[!] {e}")
    elif low in ("upload", "up"):
        _do_upload(stdscr, conn)
    elif low in ("download", "down", "dl"):
        _do_download(stdscr, conn)
    elif low in ("ftp",):
        _do_ftp(stdscr, con.host)
    elif low in ("recon", "ez", "ezrecon"):
        _ezrecon_menu(stdscr, con)
    elif low in ("scan", "tools"):
        _scan_menu(stdscr, con)
    elif low in ("",):
        pass
    else:
        _flash(stdscr, "cmds: menu settings upload download ftp recon scan pf<N> pa<N> clear mono save FILE help q")
    return False


def _screen_text(screen) -> str:
    rows = [screen.cells[i:i + screen.cols] for i in range(0, len(screen.cells), screen.cols)]
    return "\n".join("".join(c.char for c in row).rstrip() for row in rows).rstrip()


def _menu(stdscr, title, items):
    """Generic centred pop-up menu.  items = [(label, callable_or_None)].
    Returns the chosen index (or None).  Arrow keys + Enter, digits, Esc."""
    import curses
    sel = 0
    while True:
        stdscr.erase()
        maxy, maxx = stdscr.getmaxyx()
        w = max(len(title) + 4, max((len(l) for l, _ in items), default=10) + 8, 40)
        h = len(items) + 4
        y0 = max(0, (maxy - h) // 2)
        x0 = max(0, (maxx - w) // 2)
        _box(stdscr, y0, x0, h, w, title)
        for i, (label, _) in enumerate(items):
            attr = curses.A_REVERSE | curses.A_BOLD if i == sel else 0
            try:
                stdscr.addstr(y0 + 2 + i, x0 + 2, f"{i + 1:>2}) {label}".ljust(w - 4)[:w - 4], attr)
            except curses.error:
                pass
        try:
            stdscr.addstr(y0 + h - 1, x0 + 2, " up/down + Enter, digit, Esc ", curses.A_DIM)
        except curses.error:
            pass
        stdscr.refresh()
        k = stdscr.getch()
        if k in (27, ord("q")):
            return None
        if k in (curses.KEY_UP,):
            sel = (sel - 1) % len(items)
        elif k in (curses.KEY_DOWN,):
            sel = (sel + 1) % len(items)
        elif k in (curses.KEY_ENTER, 10, 13):
            return sel
        elif ord("1") <= k <= ord("9"):
            i = k - ord("1")
            if i < len(items):
                return i


def _box(stdscr, y, x, h, w, title=None):
    import curses
    try:
        stdscr.addstr(y, x, "\u250c" + "\u2500" * (w - 2) + "\u2510")
        for r in range(1, h - 1):
            stdscr.addstr(y + r, x, "\u2502" + " " * (w - 2) + "\u2502")
        stdscr.addstr(y + h - 1, x, "\u2514" + "\u2500" * (w - 2) + "\u2518")
        if title:
            stdscr.addstr(y, x + 2, f" {title} ", curses.A_BOLD)
    except curses.error:
        pass


def _settings_menu(stdscr, con):
    while True:
        items = [
            (f"Monochrome (green) .......... {'ON' if con.mono else 'off'}", None),
            (f"Insert mode ................. {'ON' if con.insert else 'off'}", None),
            ("Colour: cycle green/amber/colour (glass)", None),
            ("Back", None),
        ]
        i = _menu(stdscr, "SETTINGS", items)
        if i is None or i == 3:
            return
        if i == 0:
            con.mono = not con.mono
        elif i == 1:
            con.insert = not con.insert
        elif i == 2:
            con.msg = "[colour is host-driven in --client; use --gui for skins]"
            return


def _help_popup(stdscr, con):
    import curses
    lines = [
        "PHOSPHOR --client  -  ':' command reference",
        "",
        "  Type ':' then one of these and press Enter:",
        "",
        "    :download   (or :dl / :down)   download a dataset to a local file",
        "    :upload     (or :up)           upload a local file to a dataset",
        "    :ftp                           FTP client / submit JCL",
        "    :menu                          transfers, scans, EZrecon, report",
        "    :recon      (or :ez)           EZrecon OSINT / recon toolkit",
        "    :scan                          mainframe scan / audit tools",
        "    :settings                      colour, mono, toggles",
        "    :save FILE                     write the current screen to FILE",
        "    :pf N   :pa N   :clear   :mono                 3270 keys / display",
        "    :help   (or :?)                this reference",
        "    :q      (or :quit)             disconnect and exit",
        "",
        "  Keypad: glass has focus by default - type, Tab between fields, Enter",
        "  sends.  F1..F24 = PF keys.  Esc then 1/2/3 = PA1/PA2/PA3.  The right",
        "  column (PA1 PA2 Attn PA3 SysRq Clear) and the bottom band are boxes:",
        "  click them, or press Ctrl-K then arrows + Enter.",
        "",
        "  Ctrl-U erase to end of field   Ctrl-R reset   Ctrl-L redraw",
        "",
        "  press any key",
    ]
    stdscr.erase()
    maxy, maxx = stdscr.getmaxyx()
    w = min(maxx - 2, max(len(x) for x in lines) + 4)
    h = min(maxy - 1, len(lines) + 2)
    y0 = max(0, (maxy - h) // 2)
    x0 = max(0, (maxx - w) // 2)
    _box(stdscr, y0, x0, h, w, "HELP  -  ':' commands")
    for i, ln in enumerate(lines[:h - 2]):
        try:
            stdscr.addstr(y0 + 1 + i, x0 + 2, ln[:w - 4],
                          curses.A_BOLD if i == 0 else 0)
        except curses.error:
            pass
    stdscr.refresh()
    stdscr.getch()


def _transfer_menu(stdscr, con):
    conn = con.c
    while True:
        items = [
            ("IND$FILE upload   (local -> dataset)", None),
            ("IND$FILE download (dataset -> local)", None),
            ("Transfer mode: toggle ASCII / BINARY", None),
            ("FTP client / submit JCL", None),
            ("Save screen to file", None),
            ("Scan / audit tools (VTAM, TSO, CICS, DB2, FTP anon)", None),
            ("EZrecon  (OSINT / recon toolkit)", None),
            ("Pen-test report (markdown)", None),
            ("Back", None),
        ]
        i = _menu(stdscr, "MENU  -  transfers, scans, recon, report", items)
        if i is None or i == 8:
            return
        if i == 0:
            _do_upload(stdscr, conn)
        elif i == 1:
            _do_download(stdscr, conn)
        elif i == 2:
            con.xfer_binary = not getattr(con, "xfer_binary", False)
            con.msg = f"[transfer mode: {'BINARY' if con.xfer_binary else 'ASCII'}]"
            return
        elif i == 3:
            _do_ftp(stdscr, con.host)
        elif i == 4:
            p = _prompt(stdscr, "save screen to: ")
            if p:
                try:
                    with open(p, "w") as f:
                        f.write(_screen_text(conn.screen) + "\n")
                    _flash(stdscr, f"[+] saved {p}")
                except Exception as e:
                    _flash(stdscr, f"[!] {e}")
        elif i == 5:
            _scan_menu(stdscr, con)
        elif i == 6:
            _ezrecon_menu(stdscr, con)
        elif i == 7:
            _do_report(stdscr, con)


def _scan_menu(stdscr, con):
    """The GUI's TOOLS panel - gated behind the one-time unlock code, exactly
    like the desktop app and the CLI --scan path."""
    from phosphor.app import license as lic
    if not lic.tools_unlocked():
        code = _prompt(stdscr, "pen-test tools unlock code (blank = cancel): ")
        if not code:
            _flash(stdscr, "[i] scan tools stay locked - the terminal needs no code")
            return
        if not lic.unlock_tools(code):
            _flash(stdscr, "[!] wrong unlock code")
            return
        _flash(stdscr, "[+] tools unlocked (remembered on this machine)")
    from phosphor.audit import enumerate as au
    host, port = con.host, con.port
    while True:
        items = [
            ("Scan all", None), ("VTAM applids", None), ("TSO users", None),
            ("CICS transactions", None), ("CICS users", None), ("CICS info", None),
            ("FTP anonymous", None), ("DB2 DRDA", None), ("Back", None),
        ]
        i = _menu(stdscr, "SCAN / AUDIT  (authorised targets only)", items)
        if i is None or i == 8:
            return
        try:
            out = []
            if i == 0:
                out.append(au.tn3270_screen(host, port))
                out += au.vtam_applids(host, port, None)
                out += au.tso_users(host, port, None)
                anon = au.ftp_anon(host, 21)
                if anon:
                    out.append(anon)
            elif i == 1:
                out += au.vtam_applids(host, port, None)
            elif i == 2:
                out += au.tso_users(host, port, None)
            elif i == 3:
                out += au.cics_transactions(host, port)
            elif i == 4:
                out += au.cics_users(host, port)
            elif i == 5:
                out += au.cics_region_info(host, port)
            elif i == 6:
                a = au.ftp_anon(host, 21)
                out += [a] if a else []
            elif i == 7:
                d = au.db2_das_info(host, 50000)
                out += [d] if d else []
            lines = [f"[{getattr(f,'severity','info').upper():6}] "
                     f"{getattr(f,'title','?')} - {getattr(f,'detail','')}"
                     for f in out] or ["(no findings)"]
            con._last_findings = getattr(con, "_last_findings", []) + list(out)
            _pager(stdscr, lines)
        except Exception as e:
            _flash(stdscr, f"[!] {type(e).__name__}: {e}")


def _ezrecon_menu(stdscr, con):
    """EZrecon OSINT / recon toolkit - same operations in the TUI and the GUI.
    API keys are prompted here on first use and stored under ~/.config/phosphor."""
    from phosphor.audit import ezrecon as ez
    prompt = lambda label: _prompt(stdscr, f"{label}: ")
    while True:
        items = [(desc, None) for _op, desc, _need in ez.OPERATIONS] + [("Back", None)]
        i = _menu(stdscr, "EZrecon  -  OSINT / recon (authorised targets only)", items)
        if i is None or i == len(ez.OPERATIONS):
            return
        op, desc, need = ez.OPERATIONS[i]
        target = ""
        if need == "domain":
            target = _prompt(stdscr, "domain (e.g. example.com): ")
        elif need == "url":
            target = _prompt(stdscr, "url (e.g. example.com or https://...): ")
        elif need == "host":
            target = _prompt(stdscr, "host / IP: ") or con.host
        elif need == "ip":
            target = _prompt(stdscr, "IP address: ")
        elif need == "query":
            target = _prompt(stdscr, "Shodan query (e.g. port:23 org:\"...\"): ")
        if need and not target:
            continue
        _flash(stdscr, f"[*] running {op} ...")
        try:
            lines = ez.run(op, target, prompt=prompt)
        except Exception as e:
            lines = [f"error: {type(e).__name__}: {e}"]
        # keep recon output in the session so :report / MENU report can include it
        con._recon_log = (getattr(con, "_recon_log", []) + [f"### EZrecon {op} {target}"]
                          + lines + [""])
        _pager(stdscr, lines)


def _do_report(stdscr, con):
    import time
    findings = getattr(con, "_last_findings", [])
    path = _prompt(stdscr, "report path [phosphor-report.md]: ") or "phosphor-report.md"
    try:
        md = [f"# PHOSPHOR Pen-Test Report", "",
              f"- Target: {con.host}:{con.port}",
              f"- Protocol: {con.kind}",
              f"- Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}", "",
              "## Findings", ""]
        if findings:
            for f in findings:
                md.append(f"- **[{getattr(f,'severity','info').upper()}]** "
                          f"{getattr(f,'title','?')} - {getattr(f,'detail','')}")
        else:
            md.append("_No scans run this session._")
        md.append("")
        md.append("## Current screen")
        md.append("```")
        md.append(_screen_text(con.c.screen))
        md.append("```")
        with open(path, "w") as fh:
            fh.write("\n".join(md) + "\n")
        _flash(stdscr, f"[+] report written to {path}")
    except Exception as e:
        _flash(stdscr, f"[!] {e}")


def _do_upload(stdscr, conn):
    local = _prompt(stdscr, "local file to upload: ")
    dsn = _prompt(stdscr, "target dataset: ")
    binary = _prompt(stdscr, "binary? [y/N]: ").lower().startswith("y")
    try:
        from phosphor.protocols.indfile.dft import IndFileClient
        with open(local, "rb") as f:
            data = f.read()
        ok = IndFileClient(conn).put(dsn, data, binary=binary)
        _flash(stdscr, f"{'[+] uploaded' if ok else '[!] failed'}: {dsn} ({len(data)}b)")
    except Exception as e:
        _flash(stdscr, f"[!] {type(e).__name__}: {e}")


def _do_download(stdscr, conn):
    dsn = _prompt(stdscr, "dataset to download: ")
    binary = _prompt(stdscr, "binary? [y/N]: ").lower().startswith("y")
    local = _prompt(stdscr, "save to local file: ")
    try:
        from phosphor.protocols.indfile.dft import IndFileClient
        data = IndFileClient(conn).get(dsn, binary=binary)
        if not binary:
            try:
                data = data.decode("cp037").replace("\x15", "\n").encode("utf-8")
            except Exception:
                pass
        with open(local, "wb") as f:
            f.write(data)
        _flash(stdscr, f"[+] downloaded {dsn} -> {local} ({len(data)}b)")
    except Exception as e:
        _flash(stdscr, f"[!] {type(e).__name__}: {e}")


def _do_ftp(stdscr, default_host):
    from phosphor.protocols.ftp.client import MainframeFTP
    host = _prompt(stdscr, f"FTP host [{default_host}]: ") or default_host
    port = _prompt(stdscr, "port [21]: ") or "21"
    user = _prompt(stdscr, "user [anonymous]: ") or "anonymous"
    pw = _prompt(stdscr, "password: ") or "anonymous@"
    mode = (_prompt(stdscr, "mode ascii/binary [ascii]: ") or "ascii").lower()
    f = MainframeFTP(mode=mode)
    try:
        f.connect(host, int(port))
        f.login(user, pw)
        while True:
            cmd = _prompt(stdscr, "ftp> ")
            if cmd in ("quit", "q", "bye", ""):
                break
            parts = cmd.split(None, 1)
            op = parts[0].lower()
            arg = parts[1] if len(parts) > 1 else ""
            if op in ("ls", "dir", "list"):
                _pager(stdscr, f.list(arg))
            elif op == "get":
                dsn, _, local = arg.partition(" ")
                data = f.get(dsn)
                local = local.strip() or dsn.replace(".", "_")
                with open(local, "wb") as fh:
                    fh.write(data)
                _flash(stdscr, f"[+] got {dsn} ({len(data)}b)")
            elif op == "put":
                local, _, dsn = arg.partition(" ")
                with open(local.strip(), "rb") as fh:
                    data = fh.read()
                _flash(stdscr, f.put(dsn.strip() or local.strip(), data))
    except Exception as e:
        _flash(stdscr, f"[!] FTP {type(e).__name__}: {e}")
    finally:
        try:
            f.quit()
        except Exception:
            pass


def _pager(stdscr, lines):
    import curses
    stdscr.erase()
    maxy, maxx = stdscr.getmaxyx()
    for i, ln in enumerate(lines[:maxy - 1]):
        try:
            stdscr.addstr(i, 0, str(ln)[:maxx - 1])
        except curses.error:
            pass
    try:
        stdscr.addstr(maxy - 1, 0, "[any key]", curses.A_REVERSE)
    except curses.error:
        pass
    stdscr.refresh()
    stdscr.getch()
