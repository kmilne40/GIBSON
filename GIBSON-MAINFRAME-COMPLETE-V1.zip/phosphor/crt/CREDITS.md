# phosphor-crt — credits & licensing

Clean-room implementation.  The CRT effect *techniques* (bloom, phosphor
persistence/burn-in, barrel curvature, scanlines, aperture grille, chromatic
aberration, glow-line) are standard, publicly-documented CRT-shader maths and are
reimplemented here from scratch — no GPL shader code is copied.

Inspiration & prior art gratefully acknowledged:
- **cool-retro-term** (Swordfish90) — the look this pays homage to (GPL; not copied).
- **Ayoub Elaassal** — CICSpwn.
- **Philip Young / mainframed767** — TN3270 research & tooling.
- IBM 3270 font: Ricardo Bánffy's open **3270font** (bundle separately).

Because it is clean-room, phosphor-crt may carry whatever licence you choose.
