"""phosphor-crt entry point:  python -m phosphor.crt [host] [port] [options]"""
from __future__ import annotations
import argparse
from phosphor.crt.config import EffectConfig, PROFILES


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="phosphor-crt",
                                description="A cathode-ray TN3270 terminal (native GPU window).")
    p.add_argument("host", nargs="?", help="host to connect to (omit to use --demo)")
    p.add_argument("port", nargs="?", type=int, default=23)
    p.add_argument("--demo", action="store_true", help="render the bundled colour screen offline")
    p.add_argument("--profile", choices=list(PROFILES), help="start from a named preset")
    p.add_argument("--mode", choices=["colour", "green", "amber", "white"])
    p.add_argument("--scale", type=float, default=1.0, help="window scale factor")
    p.add_argument("--preview", metavar="DIR", nargs="?", const=".",
                   help="render still CPU previews of every profile to DIR (no GPU needed) and exit")
    a = p.parse_args(argv)

    if a.preview is not None:
        import json, os
        from phosphor.crt.preview import render_preview
        from phosphor.crt import session as _sess
        grid = _sess.Session(demo=True).grid()
        os.makedirs(a.preview, exist_ok=True)
        for name, cfg in PROFILES.items():
            out = os.path.join(a.preview, f"phosphor_crt_{name}.png")
            render_preview(grid, cfg).save(out)
            print(f"wrote {out}")
        return 0

    cfg = PROFILES[a.profile].clamp() if a.profile else EffectConfig.load()
    if a.mode:
        cfg.mode = a.mode

    from phosphor.crt.session import Session
    from phosphor.crt.app import PhosphorCRT
    sess = Session(host=a.host, port=a.port, demo=a.demo or not a.host)
    PhosphorCRT(sess, cfg, scale=a.scale).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
