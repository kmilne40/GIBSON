"""Session — feeds the renderer a colour grid, from a live TN3270 connection or
the bundled demo screen, with simple local input echo at the cursor."""
from __future__ import annotations

import json
import os
from typing import List, Optional, Tuple

try:
    from phosphor.protocols.tn3270.client import TN3270Client
except Exception:
    TN3270Client = None


class Session:
    def __init__(self, host: Optional[str] = None, port: int = 23, demo: bool = False):
        self.host = host
        self.port = port
        self.demo = demo or not host
        self.client = None
        self._grid: List[List[Tuple[str, str]]] = []
        self._buf = ""                       # locally-echoed input
        self._dirty = True
        if self.demo:
            self._grid = self._load_demo()
        else:
            if TN3270Client is None:
                raise RuntimeError("engine unavailable")
            self.client = TN3270Client()
            self.client.connect(host, port)
            self._refresh()

    def _load_demo(self):
        p = os.path.join(os.path.dirname(__file__), "demo_screen.json")
        with open(p) as f:
            return json.load(f)

    def _refresh(self):
        if self.client:
            self._grid = [[(ch, col) for (ch, col, hl) in row]
                          for row in self.client.colour_grid()]
        self._buf = ""
        self._dirty = True

    # -- content ----------------------------------------------------------
    def grid(self) -> List[List[Tuple[str, str]]]:
        """Grid with the local input buffer echoed at the cursor row/col."""
        if not self._buf or not self.client:
            return self._grid
        g = [row[:] for row in self._grid]
        r, c = self.client.get_pos()
        for i, ch in enumerate(self._buf):
            cc = c - 1 + i
            if 0 <= r - 1 < len(g) and 0 <= cc < len(g[0]):
                g[r - 1][cc] = (ch, "green")
        return g

    def take_dirty(self) -> bool:
        d = self._dirty
        self._dirty = False
        return d

    # -- input ------------------------------------------------------------
    def type(self, text: str):
        self._buf += text
        self._dirty = True

    def backspace(self):
        self._buf = self._buf[:-1]
        self._dirty = True

    def enter(self):
        if self.client:
            if self._buf:
                self.client.send_string(self._buf)
            self.client.send_enter()
            self._refresh()

    def key(self, name: str):
        if not self.client:
            return
        if name == "ENTER":
            self.enter(); return
        if self._buf:
            self.client.send_string(self._buf)
        if name == "CLEAR":
            self.client.send_clear()
        elif name.startswith("PF"):
            self.client.send_pf(int(name[2:]))
        elif name.startswith("PA"):
            self.client.send_pa(int(name[2:]))
        self._refresh()

    def close(self):
        if self.client:
            self.client.terminate()
