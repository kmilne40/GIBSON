#version 330 core
in vec2 uv;
out vec4 frag;
uniform sampler2D uText;   // freshly rendered text
uniform sampler2D uPrev;   // previous accumulation
uniform float burn_in;     // 0 = no afterglow, 1 = long trails
void main() {
    vec3 cur  = texture(uText, uv).rgb;
    vec3 prev = texture(uPrev, uv).rgb;
    float decay = mix(0.0, 0.90, clamp(burn_in, 0.0, 1.0));
    frag = vec4(max(cur, prev * decay), 1.0);   // phosphor persistence
}
