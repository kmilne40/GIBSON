#version 330 core
in vec2 uv;
out vec4 frag;

uniform sampler2D uScene;   // persistence accumulation (the phosphor image)
uniform sampler2D uBloom;   // blurred bright areas
uniform vec2  uRes;
uniform float uTime;

// every effect is an adjustable intensity (0 = off) fed from EffectConfig
uniform float bloom, curvature, scanlines, aperture, rgb_shift, glow_line,
              flicker, jitter, hsync, noise, vignette, bevel, ambient,
              brightness, contrast, opacity;

float rand(vec2 c) {
    return fract(sin(dot(c, vec2(12.9898, 78.233))) * 43758.5453);
}

// barrel-distort the sampling coords to sit the image behind curved glass
vec2 curve(vec2 p) {
    p = p * 2.0 - 1.0;
    vec2 off = abs(p.yx) / vec2(6.0, 5.0);
    p = p + p * off * off * curvature * 1.3;
    return p * 0.5 + 0.5;
}

void main() {
    vec2 c = curve(uv);

    // outside the curved screen = dark glass
    if (c.x < 0.0 || c.x > 1.0 || c.y < 0.0 || c.y > 1.0) {
        frag = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // horizontal jitter + h-sync wobble
    c.x += (rand(vec2(uTime, floor(c.y * uRes.y))) - 0.5) * jitter * 0.010;
    c.x += sin(c.y * 40.0 + uTime * 6.0) * hsync * 0.004;

    // chromatic aberration: split the colour channels slightly
    float ca = rgb_shift * 0.0030;
    vec3 col;
    col.r = texture(uScene, c + vec2(ca, 0.0)).r;
    col.g = texture(uScene, c).g;
    col.b = texture(uScene, c - vec2(ca, 0.0)).b;

    // additive phosphor bloom
    col += texture(uBloom, c).rgb * bloom * 1.7;

    // scanlines
    float s = sin(c.y * uRes.y * 3.14159265);
    col *= 1.0 - scanlines * 0.6 * s * s;

    // aperture-grille (vertical triads)
    float ap = 0.5 + 0.5 * cos(c.x * uRes.x * 6.2831853);
    col *= 1.0 - aperture * 0.5 * ap;

    // slow vertical refresh sweep
    float gpos = fract(uTime * 0.08);
    float gd = 1.0 - smoothstep(0.0, 0.06, abs(c.y - gpos));
    col += gd * glow_line * 0.25;

    // brightness flicker
    col *= 1.0 - flicker * 0.10 * (rand(vec2(uTime, 0.0)) - 0.5);

    // static grain
    col += (rand(c * uRes + uTime) - 0.5) * noise * 0.15;

    // faint ambient glow
    col += ambient * 0.06;

    // vignette
    vec2 vd = c - 0.5;
    col *= clamp(1.0 - dot(vd, vd) * vignette * 1.8, 0.0, 1.0);

    // rounded bezel darkening at the very edge
    float edge = min(min(c.x, 1.0 - c.x), min(c.y, 1.0 - c.y));
    col *= smoothstep(0.0, bevel * 0.06 + 0.0015, edge);

    // levels
    col = (col - 0.5) * contrast + 0.5;
    col *= brightness;

    frag = vec4(clamp(col, 0.0, 1.0), opacity);
}
