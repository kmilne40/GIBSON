#version 330 core
in vec2 uv;
out vec4 frag;
uniform sampler2D uTex;
uniform vec2  uTexel;   // 1 / resolution
uniform vec2  uDir;     // (1,0) horizontal or (0,1) vertical
uniform float uRadius;  // extra spread
uniform float uBright;  // >0.5 = threshold to bright areas first (bloom source)
vec3 tap(vec2 p) {
    vec3 c = texture(uTex, p).rgb;
    if (uBright > 0.5) {
        float l = max(c.r, max(c.g, c.b));
        c *= smoothstep(0.40, 0.75, l);
    }
    return c;
}
void main() {
    float w[5] = float[](0.227027, 0.194595, 0.121622, 0.054054, 0.016216);
    vec3 col = tap(uv) * w[0];
    for (int i = 1; i < 5; i++) {
        vec2 off = uDir * uTexel * float(i) * (1.0 + uRadius);
        col += tap(uv + off) * w[i];
        col += tap(uv - off) * w[i];
    }
    frag = vec4(col, 1.0);
}
