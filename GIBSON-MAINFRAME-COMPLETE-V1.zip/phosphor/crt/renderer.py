"""GPU render pipeline (moderngl).

Passes per frame:
  1. persistence : blend the text texture with the decaying previous frame
  2. bloom       : threshold + separable blur of the bright areas
  3. composite   : curvature, scanlines, RGB-shift, glow-line, flicker, noise,
                   vignette, bevel, levels -> the window

Every effect intensity is a uniform pulled straight from EffectConfig, so the
look is fully adjustable at runtime (including all the way to flat/off).
"""
from __future__ import annotations

import os
from typing import Optional

import numpy as np

try:
    import moderngl
except Exception:                     # importable without a GPU present
    moderngl = None

_SHADER_DIR = os.path.join(os.path.dirname(__file__), "shaders")


def _src(name: str) -> str:
    with open(os.path.join(_SHADER_DIR, name)) as f:
        return f.read()


class CrtRenderer:
    def __init__(self, ctx, tex_size, win_size):
        if moderngl is None:
            raise RuntimeError("moderngl is required for the CRT frontend "
                               "(pip install moderngl pyglet)")
        self.ctx = ctx
        self.tw, self.th = tex_size
        self.set_window_size(win_size)

        quad = np.array([-1, -1, 1, -1, -1, 1, 1, 1], dtype="f4")
        self._vbo = ctx.buffer(quad.tobytes())

        vert = _src("quad.vert")
        self.prog_persist = ctx.program(vertex_shader=vert, fragment_shader=_src("persistence.frag"))
        self.prog_blur = ctx.program(vertex_shader=vert, fragment_shader=_src("blur.frag"))
        self.prog_comp = ctx.program(vertex_shader=vert, fragment_shader=_src("composite.frag"))
        self.vao_persist = ctx.vertex_array(self.prog_persist, [(self._vbo, "2f", "in_pos")])
        self.vao_blur = ctx.vertex_array(self.prog_blur, [(self._vbo, "2f", "in_pos")])
        self.vao_comp = ctx.vertex_array(self.prog_comp, [(self._vbo, "2f", "in_pos")])

        # text texture (updated on screen change)
        self.text_tex = ctx.texture((self.tw, self.th), 4)
        self.text_tex.repeat_x = self.text_tex.repeat_y = False
        self.text_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)

        self._make_fbos()

    # -- framebuffers -----------------------------------------------------
    def _tex(self, w, h):
        t = self.ctx.texture((w, h), 4)
        t.repeat_x = t.repeat_y = False
        t.filter = (moderngl.LINEAR, moderngl.LINEAR)
        return t

    def _make_fbos(self):
        w, h = self.tw, self.th
        self.accum = [self._tex(w, h), self._tex(w, h)]
        self.fbo_accum = [self.ctx.framebuffer([t]) for t in self.accum]
        bw, bh = w // 2, h // 2                      # bloom at half res
        self.bloom = [self._tex(bw, bh), self._tex(bw, bh)]
        self.fbo_bloom = [self.ctx.framebuffer([t]) for t in self.bloom]
        self._cur = 0
        for fbo in self.fbo_accum + self.fbo_bloom:
            fbo.use(); self.ctx.clear(0.0, 0.0, 0.0, 1.0)

    def set_window_size(self, win_size):
        self.ww, self.wh = win_size

    # -- content ----------------------------------------------------------
    def upload_text(self, rgba: bytes, w: int, h: int):
        if (w, h) != (self.tw, self.th):
            self.tw, self.th = w, h
            self.text_tex.release()
            self.text_tex = self.ctx.texture((w, h), 4)
            self.text_tex.repeat_x = self.text_tex.repeat_y = False
            self.text_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
            for t in self.accum + self.bloom:
                t.release()
            for fbo in self.fbo_accum + self.fbo_bloom:
                fbo.release()
            self._make_fbos()
        self.text_tex.write(rgba)

    # -- frame ------------------------------------------------------------
    def render(self, cfg, t: float):
        ctx = self.ctx
        prev = self.accum[self._cur]
        nxt = 1 - self._cur

        # 1) persistence
        self.fbo_accum[nxt].use()
        self.text_tex.use(0); prev.use(1)
        self.prog_persist["uText"].value = 0
        self.prog_persist["uPrev"].value = 1
        self.prog_persist["burn_in"].value = float(cfg.burn_in)
        self.vao_persist.render(moderngl.TRIANGLE_STRIP)
        scene = self.accum[nxt]
        self._cur = nxt

        # 2) bloom (bright-pass + H, then V)
        bw, bh = self.tw // 2, self.th // 2
        self.fbo_bloom[0].use()
        scene.use(0)
        self.prog_blur["uTex"].value = 0
        self.prog_blur["uTexel"].value = (1.0 / bw, 1.0 / bh)
        self.prog_blur["uDir"].value = (1.0, 0.0)
        self.prog_blur["uRadius"].value = float(cfg.bloom_radius)
        self.prog_blur["uBright"].value = 1.0
        self.vao_blur.render(moderngl.TRIANGLE_STRIP)

        self.fbo_bloom[1].use()
        self.bloom[0].use(0)
        self.prog_blur["uDir"].value = (0.0, 1.0)
        self.prog_blur["uBright"].value = 0.0
        self.vao_blur.render(moderngl.TRIANGLE_STRIP)

        # 3) composite to the window
        ctx.screen.use()
        ctx.viewport = (0, 0, self.ww, self.wh)
        scene.use(0); self.bloom[1].use(1)
        self.prog_comp["uScene"].value = 0
        self.prog_comp["uBloom"].value = 1
        self.prog_comp["uRes"].value = (float(self.tw), float(self.th))
        self.prog_comp["uTime"].value = float(t)
        for name, val in cfg.as_uniforms().items():
            try:
                self.prog_comp[name].value = float(val)
            except (KeyError, Exception):
                pass          # not every config value is a composite uniform
        self.vao_comp.render(moderngl.TRIANGLE_STRIP)
