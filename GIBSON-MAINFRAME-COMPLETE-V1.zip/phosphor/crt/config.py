"""phosphor-crt effect configuration.

Every cathode-ray effect is an independent, adjustable value so the look can be
dialled from full 1980s glass all the way down to a flat, readable screen.  This
is deliberate: heavy bloom/curvature is lovely for some and headache-inducing for
others, so nothing here is hard-coded into the shaders -- they read these values
as uniforms every frame, and the user can nudge any of them live or pick a preset.

Values are 0.0-1.0 "intensity" unless noted; 0.0 always means "effect off".
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict, fields, field
from pathlib import Path


PALETTES = {
    # name -> (foreground phosphor tint, is_colour)  ; "colour" uses real 3279
    "colour": None,               # real 3279 palette (per-cell colour)
    "green":  (0.20, 1.00, 0.35), # P1 phosphor
    "amber":  (1.00, 0.69, 0.00), # P3 phosphor
    "white":  (0.90, 0.95, 1.00),
    # --- skin screen tints (monochrome glass) --------------------------------
    "c64":    (0.62, 0.68, 1.00), # light periwinkle chars (Breadbin Blue)
    "lcars":  (1.00, 0.60, 0.20), # amber-orange console text
    "ispf":   (0.30, 1.00, 0.55), # bright 3270 green on blue field
    "cyber":  (0.35, 1.00, 0.55), # matrix green (Cyberdeck)
    "next":   (0.86, 0.90, 0.98), # near-white (NeXTSTEP mono display)
}

# real 3270/3279 base colours (used in "colour" mode), tuned as phosphor tints
COLOUR_3279 = {
    "blue":      (0.30, 0.62, 1.00),
    "red":       (1.00, 0.33, 0.33),
    "pink":      (1.00, 0.47, 1.00),
    "green":     (0.25, 1.00, 0.45),
    "turquoise": (0.25, 1.00, 1.00),
    "yellow":    (1.00, 1.00, 0.40),
    "white":     (0.95, 0.98, 1.00),
    "neutral":   (0.80, 0.82, 0.85),
}


@dataclass
class EffectConfig:
    # --- palette / mode -------------------------------------------------
    mode: str = "colour"          # colour | green | amber | white

    # --- glow / phosphor ------------------------------------------------
    bloom: float = 0.35           # bright-area glow (the signature effect)
    bloom_radius: float = 1.0     # blur spread of the bloom
    burn_in: float = 0.22         # persistence / afterglow trails
    ambient: float = 0.08         # faint ambient screen glow

    # --- raster / geometry ----------------------------------------------
    scanlines: float = 0.28       # dark horizontal scanlines
    aperture: float = 0.0         # aperture-grille (vertical triads)
    curvature: float = 0.12       # barrel screen curvature
    bevel: float = 0.40           # rounded bezel darkening at the edge
    vignette: float = 0.28        # corner darkening

    # --- motion / analogue artefacts ------------------------------------
    rgb_shift: float = 0.12       # chromatic aberration
    glow_line: float = 0.16       # slow vertical refresh sweep
    flicker: float = 0.05         # brightness flicker
    jitter: float = 0.0           # horizontal jitter
    hsync: float = 0.0            # horizontal-sync wobble
    noise: float = 0.04           # static grain

    # --- levels ---------------------------------------------------------
    brightness: float = 1.05
    contrast: float = 1.05
    opacity: float = 1.0

    # --- behaviour ------------------------------------------------------
    cursor_blink: bool = True
    fps: int = 60

    # -- helpers ---------------------------------------------------------
    def clamp(self) -> "EffectConfig":
        for f in fields(self):
            if f.type == "float":
                v = getattr(self, f.name)
                lo = 0.0
                hi = 3.0 if f.name in ("brightness", "contrast", "bloom_radius") else 1.0
                setattr(self, f.name, max(lo, min(hi, float(v))))
        return self

    def as_uniforms(self) -> dict:
        """The subset the composite shader consumes (name -> value)."""
        return {k: float(v) for k, v in asdict(self).items()
                if isinstance(v, (int, float)) and not isinstance(v, bool)}

    # -- persistence -----------------------------------------------------
    @staticmethod
    def config_path() -> Path:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
        return Path(base) / "phosphor-crt" / "profile.json"

    def save(self, path: "Path | None" = None) -> None:
        p = path or self.config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls, path: "Path | None" = None) -> "EffectConfig":
        p = path or cls.config_path()
        try:
            data = json.loads(p.read_text())
            known = {f.name for f in fields(cls)}
            return cls(**{k: v for k, v in data.items() if k in known}).clamp()
        except Exception:
            return cls()


# -- named presets, from "full glass" to "barely there" --------------------
PROFILES = {
    "authentic": EffectConfig(
        bloom=0.55, bloom_radius=1.3, burn_in=0.42, scanlines=0.42, curvature=0.22,
        bevel=0.5, vignette=0.38, rgb_shift=0.22, glow_line=0.30, flicker=0.10,
        noise=0.07, ambient=0.12, brightness=1.08, contrast=1.10),
    "amber": EffectConfig(
        mode="amber", bloom=0.5, burn_in=0.38, scanlines=0.38, curvature=0.20,
        glow_line=0.26, flicker=0.08, noise=0.06),
    "green": EffectConfig(
        mode="green", bloom=0.5, burn_in=0.40, scanlines=0.40, curvature=0.20,
        glow_line=0.28, flicker=0.09, noise=0.06),
    # gentle: keeps a hint of glass, prioritises readability (no headaches)
    "boardroom": EffectConfig(
        bloom=0.12, bloom_radius=0.9, burn_in=0.06, scanlines=0.12, curvature=0.05,
        bevel=0.25, vignette=0.15, rgb_shift=0.03, glow_line=0.0, flicker=0.0,
        noise=0.0, ambient=0.05, brightness=1.02, contrast=1.02),
    # flat: effects fully off, just crisp coloured text
    "off": EffectConfig(
        bloom=0.0, bloom_radius=1.0, burn_in=0.0, scanlines=0.0, aperture=0.0,
        curvature=0.0, bevel=0.0, vignette=0.0, rgb_shift=0.0, glow_line=0.0,
        flicker=0.0, jitter=0.0, hsync=0.0, noise=0.0, ambient=0.0,
        brightness=1.0, contrast=1.0),
}

# effects the on-screen overlay lets you nudge live (label -> attribute)
ADJUSTABLE = [
    ("Bloom", "bloom"), ("Burn-in", "burn_in"), ("Scanlines", "scanlines"),
    ("Curvature", "curvature"), ("Glow line", "glow_line"), ("Flicker", "flicker"),
    ("RGB shift", "rgb_shift"), ("Noise", "noise"), ("Vignette", "vignette"),
    ("Bevel", "bevel"), ("Brightness", "brightness"), ("Contrast", "contrast"),
]
