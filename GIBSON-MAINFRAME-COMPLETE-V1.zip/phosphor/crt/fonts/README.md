# IBM 3270 font

For the authentic look, drop the open-source **3270** font here as `3270.ttf`:

- Ricardo Bánffy's 3270font (SIL OFL): https://github.com/rbanffy/3270font
- Download `3270-Regular.ttf`, rename to `3270.ttf`, place it in this folder.

phosphor-crt picks it up automatically. Without it, it falls back to any
installed monospace (DejaVu Sans Mono, Consolas, Menlo), which still looks fine.
