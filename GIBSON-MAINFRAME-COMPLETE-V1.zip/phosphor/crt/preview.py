"""CPU preview of the CRT pipeline.

The real effects run on the GPU (renderer.py + the GLSL shaders).  This module
approximates the same pipeline in numpy/PIL so the look of a profile can be
previewed as a still image without a GPU - useful for tuning defaults and for
documentation.  It reads the same EffectConfig, so a change to a profile shows
up here the way it will on the glass.
"""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageFilter

from phosphor.crt.config import EffectConfig
from phosphor.crt import text_pass


def _to_float(img: Image.Image) -> np.ndarray:
    return np.asarray(img.convert("RGB"), dtype=np.float32) / 255.0


def _to_img(arr: np.ndarray) -> Image.Image:
    return Image.fromarray(np.clip(arr * 255.0, 0, 255).astype(np.uint8), "RGB")


def _bloom(arr: np.ndarray, amount: float, radius: float) -> np.ndarray:
    if amount <= 0:
        return arr
    lum = arr.max(axis=2, keepdims=True)
    bright = arr * np.clip((lum - 0.45) / 0.35, 0, 1)     # bright-pass
    img = _to_img(bright).filter(ImageFilter.GaussianBlur(2.5 + 4.0 * radius))
    blurred = _to_float(img)
    return 1.0 - (1.0 - arr) * (1.0 - blurred * amount * 1.7)  # screen blend


def _scanlines(arr: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return arr
    h = arr.shape[0]
    s = np.sin(np.linspace(0, np.pi * h, h)) ** 2
    mod = (1.0 - amount * 0.6 * s)[:, None, None]
    return arr * mod


def _chroma(arr: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return arr
    px = max(1, int(round(amount * 4)))
    out = arr.copy()
    out[:, :, 0] = np.roll(arr[:, :, 0], px, axis=1)     # R shifts right
    out[:, :, 2] = np.roll(arr[:, :, 2], -px, axis=1)    # B shifts left
    return out


def _curvature(arr: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return arr
    h, w, _ = arr.shape
    yy, xx = np.meshgrid(np.linspace(-1, 1, h), np.linspace(-1, 1, w), indexing="ij")
    off = (np.abs(np.stack([yy, xx])) ** 2)
    cx = xx + xx * off[0] * amount * 1.3
    cy = yy + yy * off[1] * amount * 1.3
    sx = np.clip(((cx + 1) * 0.5 * (w - 1)).astype(np.int32), 0, w - 1)
    sy = np.clip(((cy + 1) * 0.5 * (h - 1)).astype(np.int32), 0, h - 1)
    out = arr[sy, sx]
    inside = (cx >= -1) & (cx <= 1) & (cy >= -1) & (cy <= 1)
    return out * inside[:, :, None]


def _vignette(arr: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return arr
    h, w, _ = arr.shape
    yy, xx = np.meshgrid(np.linspace(-1, 1, h), np.linspace(-1, 1, w), indexing="ij")
    v = np.clip(1.0 - (xx ** 2 + yy ** 2) * amount * 0.9, 0, 1)
    return arr * v[:, :, None]


def _grain(arr: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return arr
    n = (np.random.default_rng(7).random(arr.shape[:2]) - 0.5) * amount * 0.15
    return arr + n[:, :, None]


def render_preview(grid, cfg: EffectConfig, cell=(13, 24)) -> Image.Image:
    """Approximate the CRT pipeline for a grid + config, return a PIL image."""
    raw, w, h = text_pass.render_grid(grid, cfg.mode, cell)
    arr = _to_float(Image.frombytes("RGBA", (w, h), raw))
    arr = _bloom(arr, cfg.bloom, cfg.bloom_radius)
    arr = arr + cfg.ambient * 0.06
    arr = _scanlines(arr, cfg.scanlines)
    arr = _chroma(arr, cfg.rgb_shift)
    arr = _grain(arr, cfg.noise)
    arr = _curvature(arr, cfg.curvature)
    arr = _vignette(arr, cfg.vignette)
    arr = (arr - 0.5) * cfg.contrast + 0.5
    arr = arr * cfg.brightness
    return _to_img(arr)
