"""Text pass — render the 3270 colour grid to an RGBA image.

This is the CPU side: it turns the engine's colour grid (char + 3279 colour per
cell) into the "phosphor image" the GPU shaders then bend, bloom and scan.  It
only re-runs when the screen content changes, so the shader loop stays at full
fps over a cached texture.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

from phosphor.crt.config import COLOUR_3279, PALETTES

# candidate monospace fonts, best (authentic IBM 3270) first
_FONT_CANDIDATES = [
    os.path.join(os.path.dirname(__file__), "fonts", "3270.ttf"),
    os.path.join(os.path.dirname(__file__), "fonts", "3270-Regular.ttf"),
    os.path.join(os.path.dirname(__file__), "fonts", "PhosphorMono.ttf"),   # bundled fallback
    "/usr/share/fonts/truetype/3270/3270-Regular.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
    "C:\\Windows\\Fonts\\consola.ttf",
    "/System/Library/Fonts/Menlo.ttc",
]


@lru_cache(maxsize=64)
def load_font(px: int) -> ImageFont.FreeTypeFont:
    for path in _FONT_CANDIDATES:
        try:
            if os.path.exists(path):
                return ImageFont.truetype(path, px)
        except Exception:
            continue
    try:
        return ImageFont.truetype("DejaVuSansMono.ttf", px)
    except Exception:
        return ImageFont.load_default()


def _tint(mode: str, colour: str) -> Tuple[int, int, int]:
    if mode == "colour":
        rgb = COLOUR_3279.get(colour, COLOUR_3279["green"])
    else:
        rgb = PALETTES.get(mode) or PALETTES["green"]
    return tuple(int(v * 255) for v in rgb)


@lru_cache(maxsize=128)
def _cell_font(cw: int, ch: int, fill: int = 100):
    """Pick the largest font whose glyph advance fits `fill`% of the cell WIDTH
    and whose height fits the cell HEIGHT, then return (font, x_off, y_off) to
    centre it.  Sizing by width is the fix for the 'bunched / overlapping' glyphs;
    `fill` (55-100) lets the user scale the text within the fixed cell (A- / A+)."""
    lo, hi, best = 5, max(6, ch + 6), 6
    wtarget = max(3, int(cw * fill / 100) - 1)      # leave 1px so glyphs never touch
    htarget = max(6, int(ch * fill / 100))
    while lo <= hi:
        mid = (lo + hi) // 2
        f = load_font(mid)
        adv = f.getlength("M")               # monospace: every glyph has this advance
        asc, desc = f.getmetrics()
        if adv <= wtarget and (asc + desc) <= htarget:
            best = mid; lo = mid + 1
        else:
            hi = mid - 1
    f = load_font(best)
    adv = f.getlength("0")
    asc, desc = f.getmetrics()
    x_off = max(0, int((cw - adv) // 2))
    y_off = max(0, int((ch - (asc + desc)) // 2))
    return f, x_off, y_off


@lru_cache(maxsize=8192)
def _glyph_tile(char: str, rgb: Tuple[int, int, int], cw: int, ch: int, fill: int = 100) -> "Image.Image":
    """A single character rasterised once into a cw x ch RGBA tile, cached.

    The glyph is sized to fit the cell and centred, so a full row of text is
    crisp and evenly spaced with no overlap between neighbouring cells.
    """
    tile = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    font, xo, yo = _cell_font(cw, ch, fill)
    ImageDraw.Draw(tile).text((xo, yo), char, font=font, fill=rgb + (255,))
    return tile


def render_grid(grid: List[List[Tuple[str, str]]], mode: str = "colour",
                cell: Tuple[int, int] = (13, 24),
                font: Optional[ImageFont.FreeTypeFont] = None,
                overlay: Optional[List[str]] = None,
                bg: Tuple[int, int, int] = (0, 0, 0),
                palette: Optional[dict] = None,
                out_size: Optional[Tuple[int, int]] = None,
                fill: int = 100) -> Tuple[bytes, int, int]:
    """Return (rgba_bytes, width, height) for the grid, with an optional HUD
    overlay (effect readout) drawn at the bottom-left in a dim phosphor box.
    `bg` is the glass field colour (black for a normal CRT, a tint for skins).
    `palette` optionally overrides the per-cell text colour: a dict of 3270
    colour-name -> (r,g,b), used e.g. for the pink skin (pink text, red highlights).
    `out_size` renders directly onto a canvas of exactly (w,h) with integer cell
    sizes, so the CRT pass never has to fractionally rescale -> crispest text."""
    rows = len(grid)
    cols = len(grid[0]) if rows else 80
    if out_size is not None:
        ow, oh = out_size
        cw = max(4, ow // cols)
        ch = max(6, oh // rows)
        img_w, img_h = ow, oh
        # centre the cell block within the exact canvas
        offx = (ow - cw * cols) // 2
        offy = (oh - ch * rows) // 2
    else:
        cw, ch = cell
        img_w, img_h = cols * cw, rows * ch
        offx = offy = 0
    img = Image.new("RGBA", (img_w, img_h), tuple(bg) + (255,))

    def tint(colour):
        if palette is not None:
            return palette.get(colour, palette.get("default", (255, 255, 255)))
        return _tint(mode, colour)

    if font is None:
        # fast path: paste cached per-glyph tiles (no per-cell rasterising)
        for r, row in enumerate(grid):
            base_y = offy + r * ch
            for cx, spec in enumerate(row):
                char = spec[0]
                if not char or char == " ":
                    continue
                colour = spec[1] if len(spec) > 1 else "green"
                tile = _glyph_tile(char, tint(colour), cw, ch, fill)
                img.paste(tile, (offx + cx * cw, base_y), tile)
    else:
        draw = ImageDraw.Draw(img)
        for r, row in enumerate(grid):
            for cx, spec in enumerate(row):
                char = spec[0]
                if not char or char == " ":
                    continue
                colour = spec[1] if len(spec) > 1 else "green"
                draw.text((offx + cx * cw + 1, offy + r * ch), char, font=font, fill=tint(colour) + (255,))
    if overlay:
        _draw_overlay(img, overlay, cell, mode)
    return img.tobytes(), img.width, img.height


def _draw_overlay(img: "Image.Image", lines: List[str], cell, mode: str) -> None:
    cw, ch = cell
    fnt = load_font(int(ch * 0.82))
    pad = 8
    w = max((fnt.getlength(s) for s in lines), default=0) + pad * 2
    h = len(lines) * ch + pad
    x0 = pad
    y0 = img.height - h - pad
    box = Image.new("RGBA", (int(w), int(h)), (0, 0, 0, 190))
    img.alpha_composite(box, (int(x0), int(y0)))
    d = ImageDraw.Draw(img)
    fg = _tint("amber" if mode == "colour" else mode, "yellow")
    for i, s in enumerate(lines):
        d.text((x0 + pad, y0 + pad // 2 + i * ch), s, font=fnt, fill=fg + (255,))


def render_grid_image(grid, mode: str = "colour", cell=(13, 24), bg=(0, 0, 0), palette=None, out_size=None, fill=100) -> Image.Image:
    """Same as render_grid but returns the PIL image (for previews / PNG export)."""
    raw, w, h = render_grid(grid, mode, cell, bg=bg, palette=palette, out_size=out_size, fill=fill)
    return Image.frombytes("RGBA", (w, h), raw)
