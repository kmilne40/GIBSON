"""phosphor-crt application window (pyglet + moderngl).

Opens a GPU window that renders the live 3270 session through the CRT pipeline.
3270 keys drive the session; Ctrl-modified keys tune the effects live so nobody
is stuck with more bloom/curvature than they want.
"""
from __future__ import annotations

import time
from typing import Optional

try:
    import pyglet
    import moderngl
except Exception:
    pyglet = None
    moderngl = None

from phosphor.crt.config import EffectConfig, PROFILES, ADJUSTABLE
from phosphor.crt.renderer import CrtRenderer
from phosphor.crt.session import Session
from phosphor.crt import text_pass


# PF key mapping: F1..F12 -> PF1..PF12, Shift+F1..F12 -> PF13..PF24
def _pf_name(symbol, shift):
    import pyglet.window.key as k
    fkeys = {getattr(k, f"F{i}"): i for i in range(1, 13)}
    if symbol in fkeys:
        n = fkeys[symbol] + (12 if shift else 0)
        return f"PF{n}"
    return None


class PhosphorCRT:
    def __init__(self, session: Session, cfg: EffectConfig,
                 cell=(13, 24), scale: float = 1.0):
        if pyglet is None:
            raise RuntimeError("pyglet + moderngl are required "
                               "(pip install pyglet moderngl pillow numpy)")
        self.session = session
        self.cfg = cfg
        self.cell = cell
        self._sel = 0                      # selected adjustable effect index
        self._hud_until = 0.0
        self._hud_lines: list = []
        self._font = text_pass.load_font(int(cell[1] * 0.92))

        grid = session.grid()
        cols = len(grid[0]) if grid else 80
        rows = len(grid) if grid else 24
        self.tw, self.th = cols * cell[0], rows * cell[1]
        ww, wh = int(self.tw * scale), int(self.th * scale)

        self.window = pyglet.window.Window(width=ww, height=wh,
                                           caption="phosphor-crt", resizable=True)
        self.ctx = moderngl.create_context()
        self.renderer = CrtRenderer(self.ctx, (self.tw, self.th), (ww, wh))
        self._push_text(force=True)
        self._t0 = time.time()

        self.window.push_handlers(
            on_draw=self.on_draw,
            on_key_press=self.on_key_press,
            on_text=self.on_text,
            on_resize=self.on_resize,
        )
        pyglet.clock.schedule_interval(self._tick, 1.0 / max(1, self.cfg.fps))

    # -- rendering --------------------------------------------------------
    def _hud_active(self) -> bool:
        return time.time() < self._hud_until

    def _push_text(self, force=False):
        hud = self._hud_lines if self._hud_active() else None
        if force or self.session.take_dirty() or hud is not None or self._hud_dirty():
            rgba, w, h = text_pass.render_grid(self.session.grid(), self.cfg.mode,
                                               self.cell, self._font, overlay=hud)
            self.renderer.upload_text(rgba, w, h)

    def _hud_dirty(self) -> bool:
        # true for one push just after the HUD expires, so it clears cleanly
        was, self._hud_was = getattr(self, "_hud_was", False), self._hud_active()
        return was and not self._hud_was

    def _show_hud(self):
        bar_n = 10
        lines = [f"PROFILE: {getattr(self,'_prof_name','custom')}    MODE: {self.cfg.mode}"]
        for i, (label, attr) in enumerate(ADJUSTABLE):
            v = getattr(self.cfg, attr)
            filled = int(round(min(1.0, v) * bar_n))
            bar = "#" * filled + "-" * (bar_n - filled)
            marker = ">" if i == self._sel else " "
            lines.append(f"{marker} {label:<10} [{bar}] {v:0.2f}")
        self._hud_lines = lines
        self._hud_until = time.time() + 3.0
        self.session._dirty = True

    def _tick(self, dt):
        self._push_text()

    def on_draw(self):
        self.renderer.render(self.cfg, time.time() - self._t0)

    def on_resize(self, w, h):
        self.renderer.set_window_size((w, h))

    # -- input ------------------------------------------------------------
    def on_text(self, text):
        for ch in text:
            if ch.isprintable():
                self.session.type(ch)

    def on_key_press(self, symbol, modifiers):
        import pyglet.window.key as k
        ctrl = modifiers & k.MOD_CTRL
        shift = modifiers & k.MOD_SHIFT

        if ctrl:
            return self._effect_key(symbol, k)

        if symbol == k.ENTER:
            self.session.key("ENTER")
        elif symbol == k.BACKSPACE:
            self.session.backspace()
        elif symbol in (k.ESCAPE,):
            self.session.key("CLEAR")
        else:
            pf = _pf_name(symbol, shift)
            if pf:
                self.session.key(pf)
        self._push_text()

    def _effect_key(self, symbol, k):
        """Ctrl-based effect controls (never collide with 3270 keys)."""
        adj = ADJUSTABLE[self._sel][1]
        step = 0.05
        if symbol == k.BRACKETRIGHT:                  # Ctrl+]  next effect
            self._sel = (self._sel + 1) % len(ADJUSTABLE)
        elif symbol == k.BRACKETLEFT:                 # Ctrl+[  prev effect
            self._sel = (self._sel - 1) % len(ADJUSTABLE)
        elif symbol in (k.EQUAL, k.PLUS, k.NUM_ADD):  # Ctrl+=  more
            setattr(self.cfg, adj, min(3.0, getattr(self.cfg, adj) + step))
        elif symbol in (k.MINUS, k.NUM_SUBTRACT):     # Ctrl+-  less
            setattr(self.cfg, adj, max(0.0, getattr(self.cfg, adj) - step))
        elif symbol == k.P:                           # Ctrl+P  cycle profiles
            names = list(PROFILES)
            cur = getattr(self, "_prof", -1)
            self._prof = (cur + 1) % len(names)
            self._prof_name = names[self._prof]
            self.cfg = PROFILES[self._prof_name].clamp()
            self.session._dirty = True
        elif symbol == k.M:                           # Ctrl+M  cycle palette
            modes = ["colour", "green", "amber", "white"]
            self.cfg.mode = modes[(modes.index(self.cfg.mode) + 1) % len(modes)]
            self.session._dirty = True
        elif symbol == k.S:                           # Ctrl+S  save profile
            self.cfg.save()
        self._show_hud()
        self._push_text()

    def run(self):
        try:
            pyglet.app.run()
        finally:
            self.session.close()
