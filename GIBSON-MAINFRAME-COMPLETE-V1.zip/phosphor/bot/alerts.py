"""Alert transports for the BOT layer (Tier 3).

Each function returns a ``callable(RunResult)`` you drop straight into a Job's
``on_failure`` / ``on_success`` hook, so unattended runs can actually page you:

    from phosphor.bot import Bot, Job
    from phosphor.bot.alerts import email_alerter, webhook_alerter, console_alerter

    notify = webhook_alerter("https://hooks.example.com/phosphor")
    bot.add_job(Job("audit", "audit.pmac", every=3600, on_failure=notify))

    # or e-mail via SMTP (host/user/pass from PHOSPHOR_SMTP_* env by default):
    bot.add_job(Job("probe", probe, every=300,
                    on_failure=email_alerter("soc@example.com")))

The transports use only the standard library (urllib, smtplib) - no extra deps. Both
take an injectable sender so they can be unit-tested without real network / SMTP.
"""
from __future__ import annotations

import json
import os
import ssl
import urllib.request
from typing import Callable, Optional


def format_result(result) -> str:
    """One-line human summary of a run."""
    tag = "OK" if result.ok else "FAILED"
    msg = f"PHOSPHOR bot: job {result.job!r} {tag} after {result.attempts} attempt(s), " \
          f"{result.duration:.2f}s, {result.steps} step(s)"
    if result.error:
        msg += f" - {result.error}"
    return msg


# -- console -----------------------------------------------------------------
def console_alerter(prefix: str = "[PHOSPHOR]") -> Callable[[object], None]:
    def _alert(result):
        print(f"{prefix} {format_result(result)}")
    return _alert


# -- webhook (HTTP POST of the run JSON) -------------------------------------
def webhook_alerter(url: str, *, timeout: float = 10.0,
                    poster: Optional[Callable[[str, bytes, dict], None]] = None
                    ) -> Callable[[object], None]:
    """POST the run result as JSON to `url`. `poster(url, body, headers)` is
    injectable for tests; the default uses urllib."""
    def _default_poster(u, body, headers):
        req = urllib.request.Request(u, data=body, headers=headers, method="POST")
        ctx = ssl.create_default_context()
        urllib.request.urlopen(req, timeout=timeout, context=ctx).close()

    send = poster or _default_poster

    def _alert(result):
        payload = dict(result.to_dict())
        payload["message"] = format_result(result)
        body = json.dumps(payload).encode("utf-8")
        try:
            send(url, body, {"Content-Type": "application/json"})
        except Exception as e:
            print(f"[PHOSPHOR] webhook alert failed: {e}")
    return _alert


# -- e-mail (SMTP) -----------------------------------------------------------
def email_alerter(to: str, *, subject_prefix: str = "PHOSPHOR bot",
                  host: Optional[str] = None, port: Optional[int] = None,
                  user: Optional[str] = None, password: Optional[str] = None,
                  sender: Optional[str] = None, use_tls: bool = True,
                  smtp_factory: Optional[Callable[..., object]] = None
                  ) -> Callable[[object], None]:
    """E-mail the run result. Connection details default to PHOSPHOR_SMTP_* env vars:
    PHOSPHOR_SMTP_HOST / _PORT / _USER / _PASS / _FROM. `smtp_factory(host, port)` is
    injectable for tests (defaults to smtplib.SMTP)."""
    host = host or os.environ.get("PHOSPHOR_SMTP_HOST")
    port = int(port or os.environ.get("PHOSPHOR_SMTP_PORT", 587))
    user = user or os.environ.get("PHOSPHOR_SMTP_USER")
    password = password or os.environ.get("PHOSPHOR_SMTP_PASS")
    sender = sender or os.environ.get("PHOSPHOR_SMTP_FROM") or user or "phosphor-bot@localhost"

    def _alert(result):
        subject = f"{subject_prefix}: {result.job} " + ("OK" if result.ok else "FAILED")
        body = format_result(result) + "\n\n" + json.dumps(result.to_dict(), indent=2)
        msg = (f"From: {sender}\r\nTo: {to}\r\nSubject: {subject}\r\n"
               f"Content-Type: text/plain; charset=utf-8\r\n\r\n{body}")
        if not host:
            print(f"[PHOSPHOR] e-mail alert skipped (no SMTP host): {subject}")
            return
        try:
            factory = smtp_factory or _default_smtp
            srv = factory(host, port)
            try:
                if use_tls and hasattr(srv, "starttls"):
                    srv.starttls()
                if user:
                    srv.login(user, password or "")
                srv.sendmail(sender, [to], msg.encode("utf-8"))
            finally:
                try:
                    srv.quit()
                except Exception:
                    pass
        except Exception as e:
            print(f"[PHOSPHOR] e-mail alert failed: {e}")
    return _alert


def _default_smtp(host, port):
    import smtplib
    return smtplib.SMTP(host, port, timeout=15)


def combine(*alerters: Callable[[object], None]) -> Callable[[object], None]:
    """Fan a result out to several alerters."""
    def _alert(result):
        for a in alerters:
            try:
                a(result)
            except Exception:
                pass
    return _alert
