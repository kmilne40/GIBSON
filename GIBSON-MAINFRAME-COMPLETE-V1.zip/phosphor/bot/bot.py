"""PHOSPHOR BOT layer (Tier 3) - run macros unattended.

Builds on the Tier-2 macro engine to add the things automation needs:

  * scheduling (run a macro once, or every N seconds),
  * retry with backoff and reconnect-on-drop (a fresh session per attempt),
  * structured run logging (one JSON line per run) and an in-memory history,
  * success / failure hooks for alerting (email, webhook, Slack - you supply the fn).

A "job" is a name + a macro (a .pmac file path or a ``callable(engine)``) + a schedule.

    from phosphor.bot import Bot, Job

    def probe(engine):
        engine.connect("10.0.0.9", 992, tls=True, cipher_profile="mainframe")
        engine.wait_for("READY", timeout=30)
        engine.snapshot("ready")

    bot = Bot(log_path="bot.jsonl")
    bot.add_job(Job("hourly-audit", "audit.pmac", every=3600, max_retries=3))
    bot.add_job(Job("probe", probe, every=60, on_failure=lambda r: alert(r)))
    bot.run()          # runs forever; pass max_runs=N to bound it

Authorised, defensive use only: a bot can drive live mainframe sessions unattended.
Only point it at systems you own or are explicitly authorised to test, and keep the
run log for your audit trail.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Union

from phosphor.macro.engine import MacroEngine
from phosphor.macro.script import run_file

MacroSpec = Union[str, Callable[[MacroEngine], None]]


@dataclass
class Job:
    name: str
    macro: MacroSpec                       # a .pmac file path, or callable(engine)
    every: Optional[float] = None          # seconds between runs; None = run once
    max_retries: int = 1                   # attempts per run (>=1)
    retry_backoff: float = 2.0             # seconds * attempt between retries
    on_success: Optional[Callable[["RunResult"], None]] = None
    on_failure: Optional[Callable[["RunResult"], None]] = None
    _next: Optional[float] = field(default=None, repr=False)


@dataclass
class RunResult:
    job: str
    ok: bool
    attempts: int
    started: float
    ended: float
    error: Optional[str] = None
    steps: int = 0

    @property
    def duration(self) -> float:
        return self.ended - self.started

    def to_dict(self) -> dict:
        return {"job": self.job, "ok": self.ok, "attempts": self.attempts,
                "started": self.started, "ended": self.ended,
                "duration": round(self.duration, 3), "error": self.error,
                "steps": self.steps}


class Bot:
    """Runs jobs on a schedule with retry, reconnect, logging and alert hooks."""

    def __init__(self, log_path: Optional[str] = None,
                 client_factory: Optional[Callable[[], object]] = None):
        self.jobs: List[Job] = []
        self.log_path = log_path
        self.client_factory = client_factory      # inject a client (tests); None = real
        self.history: List[RunResult] = []

    def add_job(self, job: Job) -> "Bot":
        if job.max_retries < 1:
            job.max_retries = 1
        self.jobs.append(job)
        return self

    # -- logging -----------------------------------------------------------
    def _log(self, result: RunResult) -> None:
        self.history.append(result)
        if self.log_path:
            try:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(result.to_dict()) + "\n")
            except Exception:
                pass

    # -- one job, with retry + reconnect -----------------------------------
    def run_job(self, job: Job) -> RunResult:
        started = time.time()
        last_err = None
        attempts = 0
        steps = 0
        for attempt in range(1, job.max_retries + 1):
            attempts = attempt
            client = self.client_factory() if self.client_factory else None
            engine = MacroEngine(client=client)
            try:
                if callable(job.macro):
                    job.macro(engine)
                else:
                    run_file(job.macro, engine=engine)
                steps = len(engine.transcript)
                _safe_disconnect(engine)
                result = RunResult(job.name, True, attempt, started, time.time(), steps=steps)
                self._log(result)
                if job.on_success:
                    _safe_call(job.on_success, result)
                return result
            except Exception as e:                       # any failure -> retry w/ fresh session
                last_err = f"{type(e).__name__}: {e}"
                steps = len(engine.transcript)
                _safe_disconnect(engine)
                if attempt < job.max_retries:
                    time.sleep(job.retry_backoff * attempt)   # reconnect-on-drop: next loop reconnects
                    continue
        result = RunResult(job.name, False, attempts, started, time.time(),
                           error=last_err, steps=steps)
        self._log(result)
        if job.on_failure:
            _safe_call(job.on_failure, result)
        return result

    # -- scheduler ---------------------------------------------------------
    def run(self, max_runs: Optional[int] = None, tick: float = 0.1) -> List[RunResult]:
        """Run the schedule. Blocks. `max_runs` bounds total runs (for tests / batch)."""
        now = time.time()
        for j in self.jobs:
            j._next = now
        runs = 0
        while True:
            if max_runs is not None and runs >= max_runs:
                break
            if all(j._next is None for j in self.jobs):
                break                                    # all one-shots finished
            due = sorted((j for j in self.jobs if j._next is not None and j._next <= time.time()),
                         key=lambda j: j._next)
            if not due:
                time.sleep(tick)
                continue
            for job in due:
                self.run_job(job)
                runs += 1
                job._next = (time.time() + job.every) if job.every else None
                if max_runs is not None and runs >= max_runs:
                    break
        return self.history

    # -- reporting ---------------------------------------------------------
    def summary(self) -> str:
        ok = sum(1 for r in self.history if r.ok)
        fail = len(self.history) - ok
        lines = [f"BOT summary: {len(self.history)} runs, {ok} ok, {fail} failed"]
        for r in self.history[-10:]:
            tag = "ok " if r.ok else "FAIL"
            lines.append(f"  {tag} {r.job:<18} {r.attempts} attempt(s) {r.duration:.2f}s "
                         + (r.error or ""))
        return "\n".join(lines)


def _safe_disconnect(engine) -> None:
    try:
        engine.disconnect()
    except Exception:
        pass


def _safe_call(fn, arg) -> None:
    try:
        fn(arg)
    except Exception:
        pass
