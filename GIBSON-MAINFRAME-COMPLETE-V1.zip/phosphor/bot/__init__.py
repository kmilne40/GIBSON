"""PHOSPHOR BOT layer (Tier 3) - unattended, scheduled macro runs with alerting."""
from phosphor.bot.bot import Bot, Job, RunResult
from phosphor.bot.alerts import (console_alerter, webhook_alerter, email_alerter,
                                 combine, format_result)

__all__ = ["Bot", "Job", "RunResult", "console_alerter", "webhook_alerter",
           "email_alerter", "combine", "format_result"]
