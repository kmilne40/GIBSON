"""Run one macro unattended on a schedule:

    python -m phosphor.bot <script.pmac> [--every SECONDS] [--retries N] [--log FILE] [--runs N]

Runs forever by default; --runs bounds the number of runs (batch / testing).
"""
import argparse
import sys
from phosphor.bot.bot import Bot, Job


def main(argv=None):
    ap = argparse.ArgumentParser(prog="phosphor.bot")
    ap.add_argument("macro", help="path to a .pmac macro")
    ap.add_argument("--every", type=float, default=None, help="seconds between runs (default: once)")
    ap.add_argument("--retries", type=int, default=3, help="attempts per run")
    ap.add_argument("--backoff", type=float, default=2.0, help="retry backoff seconds * attempt")
    ap.add_argument("--log", default=None, help="JSONL run log path")
    ap.add_argument("--runs", type=int, default=None, help="max total runs (default: unlimited)")
    ap.add_argument("--name", default="job", help="job name for the log")
    args = ap.parse_args(argv)

    bot = Bot(log_path=args.log)
    bot.add_job(Job(args.name, args.macro, every=args.every,
                    max_retries=args.retries, retry_backoff=args.backoff))
    try:
        bot.run(max_runs=args.runs)
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
    print(bot.summary())
    return 0 if all(r.ok for r in bot.history) else 1


if __name__ == "__main__":
    raise SystemExit(main())
