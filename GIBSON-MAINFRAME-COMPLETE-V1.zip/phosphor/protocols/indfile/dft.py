"""IND$FILE DFT-mode (structured-field 0xD0) — terminal (client) side.

The host drives the exchange (OPEN -> DATA.../GET-REQ... -> CLOSE) over Write
Structured Field frames; the terminal answers each with an AID-0x88 SF reply.
This is the mirror of GIBSON's ft_dft_host.py, so a PHOSPHOR terminal transfers
files with GIBSON, real z/OS (ZD&T), c3270/x3270 and web3270.

Clean-room, from the public IBM 3270 file-transfer / IND$FILE definition.
"""
from __future__ import annotations
from typing import List, Tuple

SF_INDFILE = 0xD0
AID_SF     = 0x88
WSF_CMD    = 0xF3
RT_OPEN,   ST_OPEN   = 0x00, 0x12
RT_DATA,   ST_DATA   = 0x47, 0x04
RT_GETREQ, ST_GETREQ = 0x46, 0x11
RT_CLOSE,  ST_CLOSE  = 0x41, 0x12
REC_CONTENTS   = 0x03
REC_RECORDSIZE = 0x08
REC_RECORDNUM  = 0x63
REC_DATA       = 0xC0
EBCDIC_NL = 0x15
EBCDIC = "cp037"          # host code page for text-mode translation
LOCAL = "latin-1"        # local code page (ASCII-safe, 1:1 over 0-255)


def text_to_ebcdic(data: bytes) -> bytes:
    """Local ASCII text -> EBCDIC (CP037) records separated by the EBCDIC newline 0x15.
    This is the on-the-wire format the host expects for a text-mode PUT."""
    text = data.decode(LOCAL, "replace").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()                      # drop the trailing empty record
    return bytes([EBCDIC_NL]).join(l.encode(EBCDIC, "replace") for l in lines)


def ebcdic_to_text(data: bytes) -> bytes:
    """EBCDIC (CP037) records separated by 0x15 -> local ASCII text with \\n newlines.
    The mirror of text_to_ebcdic, used for a text-mode GET."""
    records = data.split(bytes([EBCDIC_NL]))
    text = "\n".join(r.decode(EBCDIC, "replace") for r in records)
    return text.encode(LOCAL, "replace")


class DftError(Exception):
    pass


# --- reply frame builders (terminal -> host) ------------------------------
def _reply_sf(cmd: int, sub: int, *records: bytes) -> bytes:
    body = bytes([SF_INDFILE, cmd, sub]) + b"".join(records)
    ln = len(body) + 2
    return bytes([AID_SF, (ln >> 8) & 0xFF, ln & 0xFF]) + body


def _rec_recordnum(n: int) -> bytes:
    return bytes([REC_RECORDNUM, 6, 0, 0, (n >> 8) & 0xFF, n & 0xFF])


def _rec_data(chunk: bytes) -> bytes:
    total = 5 + len(chunk)
    return bytes([REC_DATA, 0x80, 0x61, (total >> 8) & 0xFF, total & 0xFF]) + chunk


# --- host frame parsing ---------------------------------------------------
def parse_host_sf(frame: bytes) -> Tuple[int, int, bytes]:
    p = frame
    if p and p[0] == WSF_CMD:
        p = p[1:]
    if len(p) < 5:
        raise DftError("short host structured field")
    ln = (p[0] << 8) | p[1]
    if p[2] != SF_INDFILE:
        raise DftError(f"host SF id 0x{p[2]:02x} (want 0xD0)")
    return p[3], p[4], p[5:ln]


def parse_records(buf: bytes) -> List[dict]:
    out: List[dict] = []
    p, n = 0, len(buf)
    while p < n:
        tag = buf[p]
        if tag == REC_DATA:
            if p + 5 > n:
                break
            total = (buf[p + 3] << 8) | buf[p + 4]
            if total < 5 or p + total > n:
                break
            out.append({"tag": tag, "data": buf[p + 5:p + total]})
            p += total
        else:
            if p + 1 >= n:
                break
            ln = buf[p + 1] or 2
            if p + ln > n:
                break
            out.append({"tag": tag, "data": buf[p + 2:p + ln]})
            p += ln
    return out


class IndFileTerminal:
    """Reactive terminal side.  Feed it each host frame via process_frame; it
    returns the SF reply and accumulates a download / serves an upload."""

    def __init__(self, upload_data: bytes = b"", max_chunk: int = 2048):
        self.upload = upload_data
        self._up_off = 0
        self.download = bytearray()
        self.max_chunk = max_chunk
        self._recnum = 0
        self.done = False

    def process_frame(self, frame: bytes) -> bytes:
        rt, st, records = parse_host_sf(frame)
        if rt == RT_OPEN:
            return _reply_sf(0x00, 0x09)                       # OPEN ack
        if rt == RT_DATA:
            for rec in parse_records(records):
                if rec["tag"] == REC_DATA:
                    self.download += rec["data"]
            self._recnum += 1
            return _reply_sf(0x47, 0x05, _rec_recordnum(self._recnum))
        if rt == RT_GETREQ:
            if self._up_off >= len(self.upload):
                return _reply_sf(0x46, 0x08)                   # EOF
            chunk = self.upload[self._up_off:self._up_off + self.max_chunk]
            self._up_off += len(chunk)
            self._recnum += 1
            return _reply_sf(0x46, 0x05, _rec_recordnum(self._recnum), _rec_data(chunk))
        if rt == RT_CLOSE:
            self.done = True
            return _reply_sf(0x41, 0x09)                       # CLOSE ack
        raise DftError(f"unexpected host request-type 0x{rt:02x}")


class IndFileClient:
    """Drives an IND$FILE DFT transfer over a live TN3270Client.  The command is
    typed at the current command line (a TSO READY prompt or a CICS transaction),
    then the host's structured-field exchange is answered frame by frame."""

    def __init__(self, client):
        self.c = client

    def _run(self, command: str, term: "IndFileTerminal") -> None:
        self.c.send_aid_raw("ENTER", command)     # type IND$FILE ... + ENTER
        guard = 0
        while not term.done and guard < 100000:
            guard += 1
            wsf = self.c.recv_record()
            if not wsf:
                break
            # Only genuine IND$FILE structured fields (SF id 0xD0) drive the
            # transfer.  Skip anything else the host interleaves - a screen write,
            # a Read-Partition Query, a message line - instead of feeding it to
            # process_frame (which would raise on a non-0xD0 frame and abort the
            # download half-finished).
            body = wsf[1:] if wsf[0] == WSF_CMD else wsf
            if len(body) < 3 or body[2] != SF_INDFILE:
                continue
            self.c.send_record(term.process_frame(wsf))

    def get(self, dsn: str, binary: bool = False) -> bytes:
        term = IndFileTerminal()
        mode = " BINARY" if binary else " ASCII"
        self._run(f"IND$FILE GET {dsn}{mode}", term)
        data = bytes(term.download)
        if binary:
            return data
        # Text mode: the host sends EBCDIC (CP037) records separated by the EBCDIC
        # newline 0x15. Translate back to local text. (Just swapping 0x15 for \n and
        # leaving the record bytes as EBCDIC is what scrambled downloads.)
        return ebcdic_to_text(data)

    def put(self, dsn: str, data: bytes, binary: bool = False) -> bool:
        # Text mode: translate local ASCII -> EBCDIC (CP037) records before sending -
        # the format the host expects. Without this the host stored our raw ASCII bytes
        # decoded as EBCDIC (i.e. scrambled), which looked like a binary upload.
        wire = data if binary else text_to_ebcdic(data)
        term = IndFileTerminal(upload_data=wire)
        mode = " BINARY" if binary else " ASCII"
        self._run(f"IND$FILE PUT {dsn}{mode}", term)
        return term.done
