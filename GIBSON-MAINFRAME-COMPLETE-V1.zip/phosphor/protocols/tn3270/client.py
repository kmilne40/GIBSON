"""PHOSPHOR TN3270 client.

Native socket + negotiation + screen model.  Presents a py3270-``Emulator``-style
API so it can later drop into tools (e.g. a ported CICSpwn) unchanged, while also
exposing the colour screen model the CRT frontend renders.
"""
from __future__ import annotations

import socket
from typing import List, Optional, Tuple

from phosphor.core.screen import ScreenBuffer
from phosphor.protocols.tn3270 import datastream as ds
from phosphor.protocols.tn3270.telnet import Negotiator, IAC
from phosphor.protocols import tls as _tls

EOR = ds.EOR


# 3270 terminal models (x3270 parity): model -> (device type, rows, cols).
# Model 2 = 24x80, 3 = 32x80, 4 = 43x80, 5 = 27x132.  The -E device types advertise
# extended attributes (colour / extended highlighting).
MODELS = {
    "2":  ("IBM-3278-2",   24, 80),
    "3":  ("IBM-3278-3",   32, 80),
    "4":  ("IBM-3278-4",   43, 80),
    "5":  ("IBM-3278-5",   27, 132),
    "2E": ("IBM-3278-2-E", 24, 80),
    "3E": ("IBM-3278-3-E", 32, 80),
    "4E": ("IBM-3278-4-E", 43, 80),
    "5E": ("IBM-3278-5-E", 27, 132),
}


def client_for_model(model: str = "2", *, tn3270e: bool = False, **kw):
    """Build a TN3270Client for a terminal model ('2'..'5', optional 'E' for extended)."""
    dev, rows, cols = MODELS.get(str(model).upper(), MODELS["2"])
    if tn3270e and not dev.endswith("-E"):
        dev += "-E"
    return TN3270Client(rows=rows, cols=cols, device_type=dev, tn3270e=tn3270e, **kw)


class TN3270Client:
    def __init__(self, rows: int = 24, cols: int = 80,
                 device_type: str = "IBM-3278-2", tn3270e: bool = False,
                 connect_timeout: float = 10.0, read_timeout: float = 1.5) -> None:
        self.screen = ScreenBuffer(rows, cols)
        self.neg = Negotiator(device_type=device_type, allow_tn3270e=tn3270e)
        self.sock: Optional[socket.socket] = None
        self._buf = bytearray()
        self._rec_queue: List[bytes] = []              # complete records awaiting recv_record()
        self._rec_partial = bytearray()                # carry for a record split across reads
        self._pending: List[Tuple[int, str]] = []      # (addr, text) typed
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.connected = False
        self.tls_info = _tls.TLSInfo()

    # --- connection ------------------------------------------------------
    def connect(self, host: str, port: int = 23, *,
                tls: bool = False, tls_verify: bool = True,
                tls_starttls: bool = False,
                tls_accept_hostname: Optional[str] = None,
                ca_file: Optional[str] = None,
                client_cert: Optional[str] = None,
                client_key: Optional[str] = None,
                cipher_profile: str = "modern") -> None:
        raw = socket.create_connection((host, port), self.connect_timeout)
        self._tls_opts = dict(host=host, verify=tls_verify,
                              accept_hostname=tls_accept_hostname, ca_file=ca_file,
                              client_cert=client_cert, client_key=client_key,
                              cipher_profile=cipher_profile)
        # implicit TLS tunnel: explicit request, or the secure telnet port 992 (as x3270)
        if tls or _tls.default_secure_port(port):
            self.tls_info = _tls.TLSInfo()
            raw = _tls.wrap_socket(raw, host, verify=tls_verify,
                                   accept_hostname=tls_accept_hostname, ca_file=ca_file,
                                   client_cert=client_cert, client_key=client_key,
                                   cipher_profile=cipher_profile,
                                   info=self.tls_info)
        elif tls_starttls:
            self.neg.want_starttls = True          # negotiated STARTTLS (RFC 2946)
        self.sock = raw
        self.sock.settimeout(self.read_timeout)
        self.connected = True
        self._negotiate_until_ready()

    def _do_starttls(self) -> None:
        """Wrap the live socket in TLS mid-stream after the TELNET START-TLS FOLLOWS
        exchange, then keep negotiating over the encrypted channel."""
        opts = getattr(self, "_tls_opts", None)
        if not opts or self.sock is None:
            return
        self.tls_info = _tls.TLSInfo()
        self.sock = _tls.wrap_socket(self.sock, opts["host"], verify=opts["verify"],
                                     accept_hostname=opts["accept_hostname"],
                                     ca_file=opts["ca_file"], client_cert=opts["client_cert"],
                                     client_key=opts["client_key"],
                                     cipher_profile=opts.get("cipher_profile", "modern"),
                                     info=self.tls_info)
        self.sock.settimeout(self.read_timeout)
        self.neg.start_tls = False
        self.neg.starttls_done = True

    def terminate(self) -> None:
        try:
            if self.sock:
                self.sock.close()
        finally:
            self.sock = None
            self.connected = False

    def is_connected(self) -> bool:
        return self.connected

    # --- low-level io ----------------------------------------------------
    def _recv(self) -> bytes:
        assert self.sock is not None
        try:
            data = self.sock.recv(65535)
        except socket.timeout:
            return b""
        self._tap("<", data)
        return data

    def _send(self, data: bytes) -> None:
        assert self.sock is not None
        self.sock.sendall(data)
        self._tap(">", data)

    def _tap(self, direction: str, data: bytes) -> None:
        """Record recent bytes for the packet monitor, if enabled by the app."""
        buf = getattr(self, "packets", None)
        if buf is not None and data:
            buf.append((direction, bytes(data)))
            if len(buf) > 40:
                del buf[:len(buf) - 40]
        pcap = getattr(self, "pcap", None)          # live PCAP capture (toggleable)
        if pcap is not None and data:
            try:
                pcap.packet(direction, bytes(data))
            except Exception:
                pass

    def _negotiate_until_ready(self) -> None:
        """Pump negotiation until BINARY+EOR+TTYPE are agreed and the first
        real screen record arrives (a WSF Query reply doesn't count)."""
        empties = 0
        while empties < 15:
            chunk = self._recv()
            if not chunk:
                empties += 1
                continue
            empties = 0
            reply, segs, eor = self.neg.feed(chunk)
            if reply:
                self._send(reply)
            if getattr(self.neg, "start_tls", False) and not self.neg.starttls_done:
                self._do_starttls()
            got_screen = self._consume(segs)
            if self.neg.ready() and got_screen:
                self._drain_fast()
                break

    @staticmethod
    def _telnet_eor(chunk: bytes) -> bool:
        return chunk.endswith(b"\xff\xef")

    # --- screen sync -----------------------------------------------------
    def _apply_record(self, rec: bytes) -> bool:
        """Apply one complete 3270 record (one host Write).  Returns True if it
        updated the screen, False if it was only a WSF Query reply (which the host
        answers and then sends the real screen separately - so the caller keeps
        reading rather than treating the query as the response)."""
        if not rec:
            return False
        manip = getattr(self, "manip", None)
        if manip and (manip.get("unprotect") or manip.get("unhide")):
            from phosphor.toolchain.hack3270_proxy import manipulate_inbound
            rec = manipulate_inbound(rec, manip.get("unprotect", False),
                                     manip.get("unhide", False))
        p = ds.DataStreamParser(self.screen)
        p.parse(rec)
        if getattr(p, "reply", None):
            self._send(p.reply)                   # answer WSF Read Partition Query
            return False
        self.screen.keyboard_locked = False
        self._pending = []
        return True

    def _consume(self, segments) -> bool:
        """Fold feed() segments through the carried partial in self._buf, applying
        every complete (EOR-terminated) record.  Returns True if a record updated
        the screen (not just a query reply)."""
        updated = False
        if len(segments) <= 1:
            self._buf += segments[0] if segments else b""   # still partial, no EOR yet
            return False
        updated |= self._apply_record(bytes(self._buf) + segments[0])   # completes the carry
        for s in segments[1:-1]:
            updated |= self._apply_record(s)
        self._buf = bytearray(segments[-1])                 # trailing partial carries over
        return updated

    def _drain_fast(self) -> None:
        """After the response arrives, briefly poll for any further records the
        host queued for it (TSO/ISPF sometimes send a message then the screen),
        then return.  Uses a short timeout so there is no per-Enter lag."""
        if self.sock is None:
            return
        old = self.sock.gettimeout()
        self.sock.settimeout(0.08)
        try:
            for _ in range(4):
                try:
                    chunk = self.sock.recv(65535)
                except (socket.timeout, OSError):
                    break
                if not chunk:
                    break
                self._tap("<", chunk)
                reply, segs, eor = self.neg.feed(chunk)
                if reply:
                    self._send(reply)
                self._consume(segs)
        finally:
            try:
                self.sock.settimeout(old)
            except OSError:
                pass

    def _read_until_eor(self) -> None:
        """Read the host's response to an AID and apply every record it contains.
        Returns as soon as a screen record arrives (plus a short straggler drain),
        so there is no delay after Enter."""
        empties = 0
        while empties < 6:
            chunk = self._recv()
            if not chunk:
                empties += 1
                continue
            empties = 0
            reply, segs, eor = self.neg.feed(chunk)
            if reply:
                self._send(reply)
            if self._consume(segs):
                self._drain_fast()
                return

    # --- py3270-style API ------------------------------------------------
    def move_to(self, row: int, col: int) -> None:
        self.screen.cursor = self.screen.addr(row, col)

    def send_string(self, text: str) -> None:
        """Queue text at the current cursor (as a modified field)."""
        self._pending.append((self.screen.cursor, text))
        self.screen.cursor = (self.screen.cursor + len(text)) % len(self.screen.cells)

    safe_send = send_string

    def _aid(self, name: str) -> None:
        frame = ds.build_inbound(self.screen, name, self._pending)
        self._send(frame)
        self._read_until_eor()

    def send_enter(self) -> None: self._aid("ENTER")
    def send_clear(self) -> None: self._aid("CLEAR")
    def send_pf(self, n: int) -> None: self._aid(f"PF{n}")
    def send_pa(self, n: int) -> None: self._aid(f"PA{n}")
    def send_pf3(self) -> None: self._aid("PF3")
    def send_pf5(self) -> None: self._aid("PF5")
    def send_pf11(self) -> None: self._aid("PF11")

    def screen_get(self) -> List[str]:
        return self.screen.to_rows()

    def find(self, text: str) -> bool:
        return self.screen.find(text)

    find_response = find

    def get_pos(self) -> Tuple[int, int]:
        return self.screen.rc(self.screen.cursor)

    # colour access for the CRT frontend
    def colour_grid(self):
        return self.screen.colour_grid()

    # --- raw record I/O (for IND$FILE structured-field exchange) ----------
    def send_record(self, data: bytes) -> None:
        """Send raw bytes as one 3270 record: IAC-escaped, IAC EOR terminated."""
        body = bytes(data).replace(b"\xff", b"\xff\xff")
        self._send(body + b"\xff\xef")

    def recv_record(self) -> bytes:
        """Read and return exactly ONE inbound record (telnet framing removed).

        IND$FILE is a strict request/reply exchange: every host structured-field
        frame must be answered on its own.  A single TCP read can carry several
        EOR-terminated records (the host commonly sends them back to back), so any
        records beyond the first are queued and handed out by later calls rather
        than being concatenated into one blob (which silently dropped every DATA
        frame after the first and produced empty downloads).  Returns b"" if the
        host goes quiet with no complete record available."""
        if self._rec_queue:
            return self._rec_queue.pop(0)
        empties = 0
        while empties < 20:
            chunk = self._recv()
            if not chunk:
                empties += 1
                continue
            empties = 0
            reply, segs, eor = self.neg.feed(chunk)
            if reply:
                self._send(reply)
            # segs = [bytes-before-first-EOR, complete1, ..., trailing-partial].
            # The first segment completes any partial carried from a prior read.
            self._rec_partial += segs[0]
            if len(segs) > 1:
                complete = [bytes(self._rec_partial)] + [bytes(s) for s in segs[1:-1]]
                self._rec_partial = bytearray(segs[-1])
                self._rec_queue.extend(complete[1:])
                return complete[0]
        return b""

    def send_aid_raw(self, aid: str, text: str) -> None:
        """Type text at the cursor and press an AID, sending the frame without
        waiting for / parsing a screen (the host may answer with WSF instead)."""
        frame = ds.build_inbound(self.screen, aid, [(self.screen.cursor, text)])
        self._send(frame)
