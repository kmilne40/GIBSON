"""Telnet option negotiation for TN3270 (classic and TN3270E).

Drives the same handshake proven against GIBSON: reject or accept TN3270E, agree
BINARY + END-OF-RECORD both ways, answer the terminal-type sub-negotiation with a
3270 device type.  Clean-room.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple

IAC, DONT, DO, WONT, WILL, SB, SE = 0xFF, 0xFE, 0xFD, 0xFC, 0xFB, 0xFA, 0xF0
OPT_BINARY, OPT_EOR, OPT_TTYPE, OPT_TN3270E = 0x00, 0x19, 0x18, 0x28
OPT_START_TLS = 0x2E                        # RFC 2946 TELNET START-TLS
STARTTLS_FOLLOWS = 0x01
OPT_SGA, OPT_NEWENV = 0x03, 0x27          # Suppress Go-Ahead, NEW-ENVIRON (IBM i)
TTYPE_SEND, TTYPE_IS = 0x01, 0x00


@dataclass
class Negotiator:
    device_type: str = "IBM-3278-2"
    allow_tn3270e: bool = False           # cics-enum-style tools force classic
    # negotiated state
    local_binary: bool = False
    remote_binary: bool = False
    local_eor: bool = False
    remote_eor: bool = False
    ttype_sent: bool = False
    tn3270e: bool = False
    local_sga: bool = False
    remote_sga: bool = False
    # negotiated TELNET START-TLS (RFC 2946): the host offers DO START-TLS; if the
    # client wants STARTTLS it answers WILL, exchanges SB FOLLOWS, then wraps in TLS.
    want_starttls: bool = False           # client is willing to negotiate STARTTLS
    start_tls: bool = False               # set True when the caller must wrap TLS now
    starttls_done: bool = False

    def ready(self) -> bool:
        return (self.local_binary and self.remote_binary
                and self.local_eor and self.remote_eor and self.ttype_sent)

    def feed(self, data: bytes):
        """Process inbound bytes.  Returns (reply, segments, eor_seen).

        Telnet commands are consumed; IAC EOR (0xFF 0xEF) marks the end of a 3270
        record.  ``segments`` is the 3270 data split at every EOR boundary - a new
        segment starts after each EOR - so a chunk carrying several host writes
        (which TSO/ISPF do constantly) comes back as several records rather than
        one concatenated blob.  The caller joins segments[0] onto any carried
        partial and treats the boundary after it as record-complete.
        """
        reply = bytearray()
        segments = [bytearray()]
        eor = False
        i, n = 0, len(data)
        while i < n:
            b = data[i]
            if b != IAC:
                segments[-1].append(b); i += 1; continue
            if i + 1 >= n:
                break
            cmd = data[i + 1]
            if cmd == IAC:                        # escaped 0xFF in data
                segments[-1].append(IAC); i += 2; continue
            if cmd == 0xEF:                        # IAC EOR - record boundary
                eor = True; segments.append(bytearray()); i += 2; continue
            if cmd in (DO, DONT, WILL, WONT) and i + 2 < n:
                opt = data[i + 2]
                reply += self._negotiate(cmd, opt); i += 3; continue
            if cmd == SB:                          # sub-negotiation until IAC SE
                j = i + 2
                sub = bytearray()
                while j + 1 < n and not (data[j] == IAC and data[j + 1] == SE):
                    sub.append(data[j]); j += 1
                reply += self._subneg(bytes(sub)); i = j + 2; continue
            i += 2                                 # unknown 2-byte command
        return bytes(reply), [bytes(s) for s in segments], eor

    def _negotiate(self, cmd: int, opt: int) -> bytes:
        r = bytearray()
        if cmd == DO:
            if opt == OPT_TN3270E and not self.allow_tn3270e:
                r += bytes([IAC, WONT, OPT_TN3270E])
            elif opt == OPT_START_TLS:
                if self.want_starttls and not self.starttls_done:
                    r += bytes([IAC, WILL, OPT_START_TLS])
                else:
                    r += bytes([IAC, WONT, OPT_START_TLS])
            elif opt in (OPT_BINARY, OPT_EOR, OPT_TTYPE, OPT_SGA):
                r += bytes([IAC, WILL, opt])
                if opt == OPT_BINARY:
                    self.local_binary = True
                elif opt == OPT_EOR:
                    self.local_eor = True
                elif opt == OPT_SGA:
                    self.local_sga = True
            else:
                # e.g. NEW-ENVIRON: a plain WONT is a valid answer (the IBM i host
                # then auto-creates the virtual device) - RFC 4777 s.3.
                r += bytes([IAC, WONT, opt])
        elif cmd == WILL:
            if opt in (OPT_BINARY, OPT_EOR, OPT_SGA):
                r += bytes([IAC, DO, opt])
                if opt == OPT_BINARY:
                    self.remote_binary = True
                elif opt == OPT_EOR:
                    self.remote_eor = True
                elif opt == OPT_SGA:
                    self.remote_sga = True
            elif opt == OPT_TN3270E and self.allow_tn3270e:
                r += bytes([IAC, DO, OPT_TN3270E]); self.tn3270e = True
            else:
                r += bytes([IAC, DONT, opt])
        # DONT/WONT -> accept silently
        return bytes(r)

    def _subneg(self, sub: bytes) -> bytes:
        if len(sub) >= 2 and sub[0] == OPT_TTYPE and sub[1] == TTYPE_SEND:
            self.ttype_sent = True
            return bytes([IAC, SB, OPT_TTYPE, TTYPE_IS]) + \
                self.device_type.encode("ascii") + bytes([IAC, SE])
        # SB START-TLS FOLLOWS: answer with our own FOLLOWS, then the caller wraps TLS
        if len(sub) >= 2 and sub[0] == OPT_START_TLS and sub[1] == STARTTLS_FOLLOWS:
            if self.want_starttls and not self.starttls_done:
                self.start_tls = True          # caller must wrap the socket in TLS now
                return bytes([IAC, SB, OPT_START_TLS, STARTTLS_FOLLOWS, IAC, SE])
        return b""
