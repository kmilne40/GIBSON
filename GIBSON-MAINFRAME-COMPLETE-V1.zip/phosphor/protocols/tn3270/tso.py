"""TSO/E LOGON panel navigation.

GIBSON (like real z/OS over TN3270) presents the full-screen TSO/E LOGON panel,
not a line-mode ``IKJ56700A ENTER USERID`` prompt.  This helper fills the panel's
USERID and PASSWORD fields and drives it to a live READY prompt, which is the
precondition for running IND$FILE (or any TSO command) over the session.
"""
from __future__ import annotations

from typing import Optional


def _screen_text(client) -> str:
    try:
        return "\n".join(client.screen_get()).upper()
    except Exception:
        return ""


def at_ready(client) -> bool:
    return "READY" in _screen_text(client)


def tso_login(client, userid: str, password: str, applid: str = "TSO",
              procedure: Optional[str] = None) -> bool:
    """Log a connected TN3270 client into TSO via the LOGON panel.

    Returns True on reaching READY.  Raises nothing - returns False on any
    non-READY outcome (invalid user, wrong password, revoked, MFA required).
    """
    # request the TSO applid from the VTAM screen
    client.move_to(24, 1)
    client.send_string(f"LOGON APPLID({applid})")
    client.send_enter()

    # we should now be on the TSO/E LOGON panel; fill USERID and PASSWORD by
    # locating the panel's input fields (USERID on the userid row, PASSWORD on
    # the password row - not the NEW PASSWORD field further right).
    fields = []
    try:
        fields = client.screen.input_fields()
    except Exception:
        pass

    userid_field = password_field = None
    for f in fields:
        # the login panel places USERID above PASSWORD; the left-most field on
        # each of the first two input rows is the one we want.
        if userid_field is None:
            userid_field = f
            continue
        if password_field is None and f.row > userid_field.row and f.col < 40:
            password_field = f
            break

    if userid_field is not None:
        client.move_to(userid_field.row, userid_field.col)
        client.send_string(userid)
    if password_field is not None:
        client.move_to(password_field.row, password_field.col)
        client.send_string(password)
    else:
        # fall back to the well-known LOGON-panel coordinates
        client.move_to(5, 17); client.send_string(userid)
        client.move_to(7, 17); client.send_string(password)

    client.send_enter()

    # some hosts show "userid LOGON IN PROGRESS" then the READY prompt in the
    # same screen; a spare ENTER clears any *** more *** pause without harm.
    if not at_ready(client):
        try:
            client.send_enter()
        except Exception:
            pass
    return at_ready(client)
