"""3270 data-stream parse (inbound) and build (outbound).

Clean-room implementation from the public 3270 data-stream definition
(GA23-0059).  Handles the orders GIBSON and real z/OS emit: SBA, SF, SFE
(with extended colour/highlight), IC, RA, plus Erase/Write + WCC framing, and
builds inbound frames (AID + SBA + modified fields) for Enter/PF/PA keys.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from phosphor.core.screen import (Cell, ScreenBuffer, COLOURS, HIGHLIGHTS,
                                  DEFAULT_COLOUR)

# --- orders ---------------------------------------------------------------
SF, SFE, SBA, SA, MF, IC, PT, RA, EUA, GE = (
    0x1D, 0x29, 0x11, 0x28, 0x2C, 0x13, 0x05, 0x3C, 0x12, 0x08)
# --- write commands -------------------------------------------------------
CMD_W, CMD_EW, CMD_EWA, CMD_WSF = 0xF1, 0xF5, 0x7E, 0xF3
# Channel-command form of the same commands. Some real z/OS VTAM hosts send these over
# TN3270 (e.g. Erase/Write as 0x05 instead of 0xF5); GIBSON sends the SNA form above.
CMD_W_LOCAL, CMD_EW_LOCAL, CMD_EWA_LOCAL = 0x01, 0x05, 0x0D
_ERASE_WRITE_CMDS = frozenset({CMD_EW, CMD_EWA, CMD_EW_LOCAL, CMD_EWA_LOCAL})
_WRITE_CMDS = frozenset({CMD_W, CMD_W_LOCAL})
# --- AIDs -----------------------------------------------------------------
AID = {
    "ENTER": 0x7D, "CLEAR": 0x6D, "PA1": 0x6C, "PA2": 0x6E, "PA3": 0x6B,
    "PF1": 0xF1, "PF2": 0xF2, "PF3": 0xF3, "PF4": 0xF4, "PF5": 0xF5,
    "PF6": 0xF6, "PF7": 0xF7, "PF8": 0xF8, "PF9": 0xF9, "PF10": 0x7A,
    "PF11": 0x7B, "PF12": 0x7C, "PF13": 0xC1, "PF14": 0xC2, "PF15": 0xC3,
    "PF16": 0xC4, "PF17": 0xC5, "PF18": 0xC6, "PF19": 0xC7, "PF20": 0xC8,
    "PF21": 0xC9, "PF22": 0x4A, "PF23": 0x4B, "PF24": 0x4C,
}
EOR = b"\xff\xef"

# 6-bit buffer-address code table (12-bit addressing, standard 3270).
CODE_TABLE = [
    0x40, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
    0xC8, 0xC9, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
    0x50, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
    0xD8, 0xD9, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
    0x60, 0x61, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
    0xE8, 0xE9, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
    0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
    0xF8, 0xF9, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
]
REV_CODE = {b: i for i, b in enumerate(CODE_TABLE)}


def enc_addr(a: int) -> bytes:
    a = max(0, int(a))
    if a > 0x0FFF:                                 # 14-bit addressing (alternate models)
        return bytes(((a >> 8) & 0x3F, a & 0xFF))
    return bytes((CODE_TABLE[(a >> 6) & 0x3F], CODE_TABLE[a & 0x3F]))


def dec_addr(b1: int, b2: int) -> int:
    # The top two bits of the first byte select the buffer-addressing mode (3270 spec):
    #   00 -> 14-bit binary addressing;  01 or 11 -> 12-bit (6-bit code) addressing.
    # GIBSON emits 12-bit; real z/OS VTAM often emits 14-bit - both must decode.
    if (b1 & 0xC0) == 0x00:
        return ((b1 & 0x3F) << 8) | (b2 & 0xFF)       # 14-bit
    return ((b1 & 0x3F) << 6) | (b2 & 0x3F)           # 12-bit


def _ebcdic(byte: int) -> str:
    # EBCDIC null (0x00) and any byte that decodes to a C0/C1 control character
    # must render as a blank - a real 3270 displays nulls and orders as spaces,
    # never as a box/replacement glyph.  This is what removes the stray "boxes"
    # that appeared between ISPF fields on real z/OS.
    if byte == 0x00:
        return " "
    try:
        ch = bytes([byte]).decode("cp037")
    except Exception:
        return " "
    o = ord(ch)
    if o < 0x20 or 0x7F <= o <= 0x9F:
        return " "
    return ch


# Graphic Escape (GE, 0x08): the following byte is a character from the alternate
# (line-drawing / APL) set.  ISPF and CICS panels draw box borders this way.  Map
# the common line-draw code points to Unicode box-drawing; fall back to a blank so
# an unknown graphic never corrupts alignment or shows a replacement glyph.
_GE_MAP = {
    0xC5: "\u250c", 0xD5: "\u2510", 0xC4: "\u2514", 0xD4: "\u2518",  # corners
    0xC6: "\u251c", 0xD6: "\u2524", 0xC7: "\u252c", 0xD7: "\u2534",  # tees
    0xC8: "\u253c",                                                  # cross
    0xA2: "\u2500", 0x85: "\u2500", 0x62: "\u2500",                  # horizontals
    0x84: "\u2502", 0x86: "\u2502",                                  # verticals
    0x4A: "\u00a2", 0x5F: "\u00ac",                                  # cent / not
}


def _ge_char(byte: int) -> str:
    if byte in _GE_MAP:
        return _GE_MAP[byte]
    return _ebcdic(byte)


def _attr_from_byte(attr: int) -> Dict[str, bool]:
    return {
        "protected": bool(attr & 0x20),
        "intensified": (attr & 0x0C) == 0x08,
        "hidden": (attr & 0x0C) == 0x0C,
    }


# --- Write Structured Field (WSF) -----------------------------------------
SFID_READ_PARTITION, SFID_QUERY_REPLY = 0x01, 0x81
AID_SF = 0x88          # inbound AID that carries Query Reply structured fields


def parse_structured_fields(body: bytes):
    """Split a WSF body into (sfid, sfdata) tuples. Each field is
    [len_hi][len_lo][sfid][data...] where len covers the whole field."""
    out = []
    i, n = 0, len(body)
    while i + 3 <= n:
        ln = (body[i] << 8) | body[i + 1]
        if ln == 0:                     # 0 -> field runs to end of record
            ln = n - i
        if ln < 3 or i + ln > n:
            break
        out.append((body[i + 2], body[i + 3:i + ln]))
        i += ln
    return out


def is_read_partition_query(body: bytes) -> bool:
    """True if a WSF body asks the terminal to describe itself (Read Partition
    Query / QueryList)."""
    for sfid, data in parse_structured_fields(body):
        if sfid == SFID_READ_PARTITION and len(data) >= 2 and data[1] in (0x02, 0x03):
            return True
    return False


def build_query_reply(rows: int = 24, cols: int = 80,
                      alt_rows: int = 24, alt_cols: int = 80) -> bytes:
    """Build the inbound Query Reply answering a Read Partition Query:
    AID(0x88) + a set of Query Reply structured fields + EOR. Values describe a
    3278/3279 model-2-class device; framing is self-consistent (see tests)."""
    def qr(qcode: int, payload: bytes) -> bytes:
        field = bytes([SFID_QUERY_REPLY, qcode]) + payload
        ln = len(field) + 2
        return bytes([(ln >> 8) & 0xFF, ln & 0xFF]) + field

    buf = rows * cols
    out = bytearray([AID_SF])
    # Summary: the QCODEs we answer
    out += qr(0x80, bytes([0x80, 0x81, 0x86, 0x87, 0x88, 0xA6]))
    # Usable Area: flags, width, height, units, Xr(4), Yr(4), AW, AH, buffer size
    out += qr(0x81, bytes([0x01, 0x00,
                           (cols >> 8) & 0xFF, cols & 0xFF,
                           (rows >> 8) & 0xFF, rows & 0xFF,
                           0x01,
                           0x00, 0x00, 0x00, 0x00,
                           0x00, 0x00, 0x00, 0x00,
                           0x09, 0x0C,
                           (buf >> 8) & 0xFF, buf & 0xFF]))
    # Color: base + 8 colours (neutral/blue/red/pink/green/turq/yellow/white)
    out += qr(0x86, bytes([0x00, 0x08,
                           0x00, 0xF4, 0xF1, 0xF1, 0xF2, 0xF2, 0xF3, 0xF3,
                           0xF4, 0xF4, 0xF5, 0xF5, 0xF6, 0xF6, 0xF7, 0xF7]))
    # Highlighting: 5 pairs (default, blink, reverse, underscore, intensify)
    out += qr(0x87, bytes([0x05, 0x00, 0xF0, 0xF1, 0xF1, 0xF2, 0xF2,
                           0xF4, 0xF4, 0xF8, 0xF8]))
    # Reply Modes: field, extended field, character
    out += qr(0x88, bytes([0x00, 0x01, 0x02]))
    # Implicit Partition: default + alternate screen sizes (self-defining param)
    out += qr(0xA6, bytes([0x00, 0x00,
                           0x0B, 0x01, 0x00,
                           (cols >> 8) & 0xFF, cols & 0xFF,
                           (rows >> 8) & 0xFF, rows & 0xFF,
                           (alt_cols >> 8) & 0xFF, alt_cols & 0xFF,
                           (alt_rows >> 8) & 0xFF, alt_rows & 0xFF]))
    return bytes(out) + EOR


class DataStreamParser:
    """Applies an inbound 3270 write to a ScreenBuffer (colour included)."""

    def __init__(self, screen: ScreenBuffer) -> None:
        self.s = screen
        self.reply: Optional[bytes] = None      # inbound frame to send back (Query Reply)

    def parse(self, data: bytes) -> None:
        if not data:
            return
        i = 0
        cmd = data[0]
        if cmd == CMD_WSF:                         # Write Structured Field
            body = data[1:]
            if is_read_partition_query(body):
                self.reply = build_query_reply(self.s.rows, self.s.cols)
            return                                 # SFs are not screen text
        if cmd in _ERASE_WRITE_CMDS:
            self.s.clear()
            i = 2 if len(data) > 1 else 1          # skip command + WCC
        elif cmd in _WRITE_CMDS:
            i = 2 if len(data) > 1 else 1
        # else: no recognised command byte -> treat whole thing as orders/text

        addr = 0
        cur_colour = DEFAULT_COLOUR
        cur_high = "normal"
        self._run_protected = False       # unformatted area is unprotected until an SF
        n = len(data)
        while i < n:
            b = data[i]
            if b == SBA and i + 2 < n:
                addr = dec_addr(data[i + 1], data[i + 2]); i += 3; continue
            if b == IC:
                self.s.cursor = addr; i += 1; continue
            if b == SF and i + 1 < n:
                self._field(addr, data[i + 1], DEFAULT_COLOUR, "normal")
                addr = (addr + 1) % len(self.s.cells); i += 2; continue
            if b == SFE and i + 1 < n:
                pairs = data[i + 1]; j = i + 2
                fattr, col, high = 0x20, DEFAULT_COLOUR, "normal"
                for _ in range(pairs):
                    if j + 1 >= n:
                        break
                    t, v = data[j], data[j + 1]
                    if t == 0xC0:
                        fattr = v
                    elif t == 0x42:
                        col = COLOURS.get(v, DEFAULT_COLOUR)
                    elif t == 0x41:
                        high = HIGHLIGHTS.get(v, "normal")
                    j += 2
                self._field(addr, fattr, col, high)
                addr = (addr + 1) % len(self.s.cells); i = j; continue
            if b == RA and i + 3 < n:
                stop = dec_addr(data[i + 1], data[i + 2]); ch = _ebcdic(data[i + 3])
                while addr != stop:
                    self._put(addr, ch, cur_colour, cur_high)
                    addr = (addr + 1) % len(self.s.cells)
                i += 4; continue
            if b == SA and i + 2 < n:               # set-attribute (running)
                t, v = data[i + 1], data[i + 2]
                if t == 0x42:
                    cur_colour = COLOURS.get(v, DEFAULT_COLOUR)
                elif t == 0x41:
                    cur_high = HIGHLIGHTS.get(v, "normal")
                i += 3; continue
            if b == EUA and i + 2 < n:               # Erase Unprotected to Address
                # Null every UNPROTECTED cell from the current address up to (but
                # not including) the stop address; protected cells and field
                # attributes are left intact.  Real ISPF uses this constantly -
                # not handling it desynced the whole buffer and broke tabbing.
                stop = dec_addr(data[i + 1], data[i + 2])
                guard = 0
                while addr != stop and guard <= len(self.s.cells):
                    cell = self.s.cells[addr]
                    if not cell.is_field_start and not cell.protected:
                        self.s.set_cell(addr, Cell(char=" ", colour=cell.colour,
                                                   protected=False))
                    addr = (addr + 1) % len(self.s.cells); guard += 1
                i += 3; continue
            if b == GE and i + 1 < n:                # Graphic Escape: next byte = alt set
                self._put(addr, _ge_char(data[i + 1]), cur_colour, cur_high)
                addr = (addr + 1) % len(self.s.cells); i += 2; continue
            if b == MF and i + 1 < n:                # Modify Field: count + type/value pairs
                pairs = data[i + 1]; j = i + 2
                for _ in range(pairs):
                    if j + 1 >= n:
                        break
                    j += 2
                # MF acts on the field attribute already at this position; it keeps
                # its buffer cell, so advance one position like SF/SFE.
                addr = (addr + 1) % len(self.s.cells); i = j; continue
            if b in (0xFF,):                        # stray IAC / EOR fragment
                i += 1; continue
            if b == PT:                             # Program Tab - advance, emit no glyph
                addr = (addr + 1) % len(self.s.cells); i += 1; continue
            # ordinary character
            self._put(addr, _ebcdic(b), cur_colour, cur_high)
            addr = (addr + 1) % len(self.s.cells); i += 1

    def _field(self, addr: int, attr: int, colour: str, high: str) -> None:
        bits = _attr_from_byte(attr)
        self.s.set_cell(addr, Cell(char=" ", colour=colour, highlight=high,
                                   protected=bits["protected"],
                                   intensified=bits["intensified"],
                                   hidden=bits["hidden"], is_field_start=True))
        # inherit the field's colour + protection for the characters that follow
        self._run_colour = colour
        self._run_protected = bits["protected"]

    def _put(self, addr: int, ch: str, colour: str, high: str) -> None:
        # a character takes the colour of its field unless a running SA overrode it
        fld_colour = getattr(self, "_run_colour", colour)
        self.s.set_cell(addr, Cell(char=ch, colour=colour if colour != DEFAULT_COLOUR else fld_colour,
                                   highlight=high,
                                   protected=getattr(self, "_run_protected", True)))


def build_inbound(screen: ScreenBuffer, aid: str,
                  typed: Optional[List[Tuple[int, str]]] = None) -> bytes:
    """Build an inbound frame: AID + cursor SBA + modified fields + EOR.

    ``typed`` is an optional list of (linear_addr, text) the client has entered;
    each becomes an SBA + EBCDIC data run, mirroring what a real terminal sends
    for modified fields.
    """
    aid_byte = AID.get(aid.upper(), AID["ENTER"])
    out = bytearray([aid_byte])
    if aid.upper() in ("PA1", "PA2", "PA3", "CLEAR"):
        return bytes(out) + EOR            # short-read AIDs carry no fields
    # cursor address: 2 raw bytes immediately after the AID (no SBA order)
    out += enc_addr(screen.cursor)
    for addr, text in (typed or []):
        out += bytes([SBA]) + enc_addr(addr)
        out += text.encode("cp037", "replace")
    return bytes(out) + EOR
