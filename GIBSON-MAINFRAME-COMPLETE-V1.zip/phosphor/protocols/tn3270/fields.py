"""3270 field-level input.

Real 3270 terminals let you type into the *fields on the screen* (Userid,
Password, ...), tab between them, and send them all on ENTER.  This editor adds
exactly that on top of the TN3270 client: it tracks a cursor, echoes typed text
into the right field locally, and flushes every edited field to the host on
ENTER.  It is frontend-agnostic - the desktop UI and any future UI drive the same
object - so the terminal behaves like a real 3270, not just a command line.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from phosphor.core.screen import Field


class FieldEditor:
    def __init__(self, client):
        self.c = client
        self.cursor: Tuple[int, int] = (1, 1)          # (row, col), 1-based
        self._edits: Dict[Tuple[int, int], str] = {}    # (frow, fcol) -> typed text
        # True while the cursor sits where the host's Insert-Cursor put it and the
        # operator has not moved it.  A host-placed cursor is authoritative: typing
        # happens there, exactly as on a real 3270.  Only when the operator arrows,
        # clicks or tabs into a blank field do we left-justify to the field start.
        self._cursor_host_set = False
        self.sync_cursor()

    # ---- unformatted screens -------------------------------------------
    def _is_unformatted(self) -> bool:
        """A 3270 buffer with no field-attribute characters at all is
        *unformatted*: the whole buffer is a single unprotected area and the
        operator types from the cursor.  Native TSO line mode (the READY prompt,
        ``IKJ56700A ENTER USERID``) works exactly this way - not handling it left
        the command line untypable (or clipped), which is why TSO commands could
        not be entered."""
        try:
            return not self.c.screen.fields()
        except Exception:
            return False

    def _synth_field(self) -> Optional[Field]:
        """The synthetic input field for an unformatted screen: it starts at the
        host Insert-Cursor position (where TSO wants the command typed) and runs
        to the end of the buffer, so a full command line is enterable."""
        try:
            sb = self.c.screen
            ic = getattr(sb, "cursor", 0) or 0
            r, c = sb.rc(ic)
            length = len(sb.cells) - ic
            return Field(row=r, col=c, length=max(1, length), protected=False,
                         colour="green", highlight="normal", intensified=False,
                         hidden=False)
        except Exception:
            return None

    def _linear_span(self, f) -> Tuple[int, int]:
        start = self.c.screen.addr(f.row, f.col)
        return start, start + max(0, f.length)

    # ---- field lookup ---------------------------------------------------
    def fields(self) -> List:
        try:
            flds = list(self.c.screen.input_fields())   # already input-only
        except Exception:
            flds = []
        if not flds and self._is_unformatted():
            sf = self._synth_field()
            return [sf] if sf else []
        return flds

    def _field_at(self, row: int, col: int):
        # A 3270 field runs from its attribute cell to the next one and routinely
        # spans several rows (the whole TSO command area is one field). Match every
        # field by its linear buffer span, not by row, or the cursor can never be
        # recognised as being inside a multi-row input field - which left it snapping
        # back to the first tiny field at top-left and clipping commands to that
        # field's width (the "6 characters / cursor stuck top-left" fault).
        if self._is_unformatted():
            sf = self._synth_field()
            if sf:
                start, end = self._linear_span(sf)
                here = self.c.screen.addr(row, col)
                if start <= here < end:
                    return sf
            return None
        sb = self.c.screen
        n = len(sb.cells)
        here = sb.addr(row, col)
        for f in self.fields():
            start = sb.addr(f.row, f.col)
            length = max(0, f.length)
            if length == 0:
                continue
            if start + length <= n:                 # no wrap
                if start <= here < start + length:
                    return f
            else:                                   # field wraps past the buffer end
                if here >= start or here < (start + length) % n:
                    return f
        return None

    def sync_cursor(self):
        flds = self.fields()
        # honour the host's Insert-Cursor (IC) position first.  Real panels put the
        # cursor exactly where you should type - "Option ===>", after "READY", the
        # sign-on field - and this must win even on an UNFORMATTED screen (TSO line
        # mode has no fields, so the old code left the cursor stuck at top-left).
        ic = getattr(self.c.screen, "cursor", 0)
        if ic:
            r, c = self.c.screen.rc(ic)
            f = self._field_at(r, c)
            if (f and not f.protected) or not flds:
                self.cursor = (r, c)
                self._cursor_host_set = True
                return
        self._cursor_host_set = False
        if not flds:
            return
        # else keep the cursor if it's already inside an input field - otherwise
        # snap to the first input field on the screen.
        if self._field_at(*self.cursor):
            return
        first = sorted(flds, key=lambda f: (f.row, f.col))[0]
        self.cursor = (first.row, first.col)

    def set_field(self, row: int, col: int, text: str):
        """Replace a field's content outright (used by the injector). Clears any
        residual/mask characters by writing the whole field width."""
        f = self._field_at(row, col)
        if f:
            self._edits[(f.row, f.col)] = text[:f.length]
            self.cursor = (f.row, min(col + len(text), f.col + f.length))
        else:
            self._edits[(row, col)] = text
            self.cursor = (row, col + len(text))

    # ---- navigation -----------------------------------------------------
    def _field_blank(self, f) -> bool:
        """True if the field currently holds nothing on screen (so fresh typing
        should left-justify from the field start)."""
        if self._edits.get((f.row, f.col)):
            return False
        try:
            addr = self.c.screen.addr(f.row, f.col)
            for i in range(min(f.length, 80)):
                ch = self.c.screen.cells[addr + i].char
                if ch and ch not in (" ", "\x00", "\x1d"):
                    return False
        except Exception:
            pass
        return True

    def field_down(self):
        """Move to the next input field below the cursor (arrow Down), at its start."""
        order = sorted(self.fields(), key=lambda f: (f.row, f.col))
        if not order:
            return
        r, c = self.cursor
        below = [f for f in order if f.row > r]
        target = below[0] if below else order[0]           # wrap to top
        self.cursor = (target.row, target.col)
        self._cursor_host_set = False

    def field_up(self):
        """Move to the previous input field above the cursor (arrow Up), at its start."""
        order = sorted(self.fields(), key=lambda f: (f.row, f.col))
        if not order:
            return
        r, c = self.cursor
        above = [f for f in order if f.row < r]
        target = above[-1] if above else order[-1]          # wrap to bottom
        self.cursor = (target.row, target.col)
        self._cursor_host_set = False

    def move(self, drow: int, dcol: int, rows: int = 24, cols: int = 80):
        """Free cursor movement (arrow keys), wrapping at screen edges."""
        r, c = self.cursor
        c += dcol
        r += drow
        if c < 1:
            c = cols; r -= 1
        elif c > cols:
            c = 1; r += 1
        r = max(1, min(rows, r))
        self.cursor = (r, c)
        self._cursor_host_set = False

    def click(self, row: int, col: int):
        """Place the cursor; if the click is inside a writable field, snap to it."""
        f = self._field_at(row, col)
        self.cursor = (f.row, col) if f else (row, col)
        self._cursor_host_set = False

    def tab(self, back: bool = False):
        """Move to the next (or previous) *input* field, landing on its first
        writable position.  Tabs cycle only through unprotected fields, the way a
        real 3270 does - protected labels are skipped.  Back-tab from the middle
        of a field goes to that field's start first, then to the previous field.
        """
        order = sorted(self.input_fields(), key=lambda f: (f.row, f.col))
        if not order:
            return
        cur = self.cursor
        if back:
            # if the cursor is inside a field but past its start, go to the start
            here = self._field_at(*cur)
            if here and here.is_input and cur != (here.row, here.col):
                self.cursor = (here.row, here.col)
                self._cursor_host_set = False
                return
            prev = [f for f in order if (f.row, f.col) < cur]
            target = prev[-1] if prev else order[-1]        # wrap to last
        else:
            nxt = [f for f in order if (f.row, f.col) > cur]
            target = nxt[0] if nxt else order[0]            # wrap to first
        self.cursor = (target.row, target.col)
        self._cursor_host_set = False

    def input_fields(self):
        # self.fields() already resolves to the screen's input fields, or the
        # single synthetic field on an unformatted screen.
        return [f for f in self.fields() if not getattr(f, "protected", False)]

    # ---- editing --------------------------------------------------------
    def type_char(self, ch: str):
        if not ch or not ch.isprintable():
            return
        r, col = self.cursor
        f = self._field_at(r, col)
        if not f:                              # not in a field -> ignore
            return
        key = (f.row, f.col)
        buf = self._edits.get(key, "")
        sb = self.c.screen
        fstart = sb.addr(f.row, f.col)
        here = sb.addr(r, col)
        offset = here - fstart                 # linear, so multi-row fields work
        # if this is the first keystroke into an empty field but the cursor sits
        # past the field start (you arrowed/clicked into the middle), snap to the
        # start so the value is left-justified - otherwise a password/userid gets
        # sent with leading blanks and the host rejects it.  A cursor the HOST
        # placed with Insert-Cursor is authoritative and must NOT be snapped: on the
        # TSO READY screen the host sets the cursor on the line below "READY " and a
        # real terminal types there, so snapping up to the field start (the READY
        # line) made the cursor jump up a line on the first keystroke.
        if (not buf and offset > 0 and self._field_blank(f)
                and not self._cursor_host_set):
            r, col = f.row, f.col
            here = fstart; offset = 0
            self.cursor = (r, col)
        self._cursor_host_set = False           # the operator is driving now
        buf = (buf + " " * max(0, offset - len(buf)))[:offset] + ch + buf[offset + 1:]
        self._edits[key] = buf[:f.length]
        if offset + 1 < f.length:
            self.cursor = sb.rc(here + 1)      # advances across the row edge too

    def backspace(self):
        r, col = self.cursor
        f = self._field_at(r, col)
        if not f:
            return
        sb = self.c.screen
        fstart = sb.addr(f.row, f.col)
        here = sb.addr(r, col)
        if here <= fstart:                     # at the field start -> nothing to erase
            return
        key = (f.row, f.col)
        buf = self._edits.get(key, "")
        offset = here - fstart - 1
        if 0 <= offset < len(buf):
            buf = buf[:offset] + buf[offset + 1:]
            self._edits[key] = buf
        self.cursor = sb.rc(here - 1)

    # ---- AID keys -------------------------------------------------------
    def _flush(self):
        for (frow, fcol), text in self._edits.items():
            try:
                self.c.move_to(frow, fcol)
                self.c.send_string(text)
            except Exception:
                pass
        self._edits.clear()

    def enter(self):
        self._flush()
        self.c.send_enter()
        self.sync_cursor()

    def pf(self, n: int):
        self._flush()
        self.c.send_pf(n)
        self.sync_cursor()

    def pa(self, n: int):
        self.c.send_pa(n)
        self.sync_cursor()

    def clear(self):
        self._edits.clear()
        self.c.send_clear()
        self.sync_cursor()

    def erase_eof(self):
        r, col = self.cursor
        f = self._field_at(r, col)
        if f:
            self._edits[(f.row, f.col)] = self._edits.get((f.row, f.col), "")[:col - f.col]

    # ---- rendering ------------------------------------------------------
    def grid_with_edits(self):
        """Colour grid with locally-typed text and a cursor marker overlaid.

        Non-display (hidden) fields - RACF password prompts, MFA token fields - are
        masked so the characters never render on screen (matching a real 3270). If the
        hack3270 'reveal hidden' option is on, the datastream's non-display bit was
        already cleared upstream, so those fields simply aren't hidden here."""
        grid = [[(c, col) for (c, col, _hl) in row] for row in self.c.colour_grid()]
        rows = len(grid)
        cols = len(grid[0]) if rows else 0
        sb = self.c.screen
        n = len(sb.cells) or 1
        # cells covered by a hidden field (whole span, not just the attribute cell)
        hidden = set()
        try:
            for f in sb.fields():
                if not f.hidden:
                    continue
                start = sb.addr(f.row, f.col)
                for k in range(max(0, f.length)):
                    a = (start + k) % n
                    hidden.add((a // cols, a % cols))
        except Exception:
            hidden = set()
        # overlay locally-typed text.  Walk each edit by its real buffer address so
        # a value that runs across the row edge (a command typed on the line below
        # "READY ", where the field starts on the line above) renders on the right
        # line instead of being clipped at column 80.
        for (frow, fcol), text in self._edits.items():
            start = sb.addr(frow, fcol)
            for i, ch in enumerate(text):
                a = (start + i) % n
                rr, cc = a // cols, a % cols
                if 0 <= rr < rows and 0 <= cc < cols:
                    grid[rr][cc] = (ch, "turquoise")
        # mask hidden fields last (covers both host content and anything just typed)
        for (rr, cc) in hidden:
            if 0 <= rr < rows and 0 <= cc < cols:
                _ch, colr = grid[rr][cc]
                if _ch and _ch != " ":
                    grid[rr][cc] = (" ", colr)
        # (the cursor is drawn as a blinking light-blue overlay on the glass, so it
        # is not baked into the grid here - that lets it blink without re-rasterising)
        return grid
