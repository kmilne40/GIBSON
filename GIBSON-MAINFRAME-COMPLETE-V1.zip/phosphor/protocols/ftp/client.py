"""Mainframe FTP client.

Wraps ftplib with the z/OS-specific surface a pentest/audit needs: banner
capture, SITE commands (RECFM/LRECL/FILETYPE), MVS dataset vs USS path handling,
and the JES interface (SITE FILETYPE=JES to submit JCL and read job output).
"""
from __future__ import annotations
import ftplib
import io
from typing import List, Optional


class MainframeFTP:
    def __init__(self, timeout: float = 10.0, mode: str = "binary"):
        self.ftp = ftplib.FTP()
        self.timeout = timeout
        self.banner = ""
        self.mode = mode if mode in ("binary", "ascii") else "binary"

    def set_mode(self, mode: str) -> str:
        """Select the FTP transfer type.

        binary (TYPE I) -> raw bytes, exactly as stored (load modules, ZIPs,
                           EBCDIC you want to keep as-is).
        ascii  (TYPE A) -> the host translates EBCDIC<->ASCII, so text datasets
                           come back readable and uploads are converted for you.
        """
        self.mode = "ascii" if mode == "ascii" else "binary"
        try:
            self.ftp.voidcmd("TYPE A" if self.mode == "ascii" else "TYPE I")
        except Exception:
            pass
        return self.mode

    def connect(self, host: str, port: int = 21) -> str:
        self.banner = self.ftp.connect(host, port, self.timeout) or ""
        return self.banner

    def login(self, user: str = "anonymous", password: str = "anonymous@") -> str:
        return self.ftp.login(user, password)

    def site(self, option: str) -> str:
        return self.ftp.sendcmd("SITE " + option)

    def syst(self) -> str:
        try:
            return self.ftp.sendcmd("SYST")
        except Exception as e:
            return str(e)

    def list(self, path: str = "") -> List[str]:
        out: List[str] = []
        self.ftp.retrlines("LIST " + path if path else "LIST", out.append)
        return out

    def get(self, dsn: str, mode: Optional[str] = None) -> bytes:
        m = mode or self.mode
        if m == "ascii":
            # TYPE A: the host translates EBCDIC->ASCII and delivers text lines.
            lines: List[str] = []
            self.ftp.retrlines(f"RETR {dsn}", lines.append)
            return ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8", "replace")
        buf: List[bytes] = []
        self.ftp.retrbinary(f"RETR {dsn}", buf.append)   # TYPE I: raw bytes
        return b"".join(buf)

    def put(self, dsn: str, data: bytes, mode: Optional[str] = None) -> str:
        m = mode or self.mode
        if m == "ascii":
            return self.ftp.storlines(f"STOR {dsn}", io.BytesIO(data))   # TYPE A
        return self.ftp.storbinary(f"STOR {dsn}", io.BytesIO(data))      # TYPE I

    def submit_jcl(self, jcl: bytes, name: str = "JOB") -> str:
        """SITE FILETYPE=JES then STOR the JCL - submits a job to the internal
        reader.  A legitimate finding (and RCE vector) when reachable."""
        self.site("FILETYPE=JES")
        try:
            return self.ftp.storbinary(f"STOR {name}", io.BytesIO(jcl))
        finally:
            try:
                self.site("FILETYPE=SEQ")
            except Exception:
                pass

    def quit(self) -> None:
        try:
            self.ftp.quit()
        except Exception:
            try:
                self.ftp.close()
            except Exception:
                pass
