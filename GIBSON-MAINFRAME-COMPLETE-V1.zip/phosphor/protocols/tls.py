"""TLS for TN3270 / TN5250 sessions.

This is the client side of an *implicit* TLS tunnel: as soon as the TCP session is
up, the socket is wrapped in TLS and the whole session runs encrypted.  That is what
x3270 calls the ``L:`` prefix, and it is exactly what a z/OS **AT-TLS** policy looks
like from the client - the mainframe's TCP/IP stack does TLS transparently on a
policy-defined port, so the emulator just has to speak TLS on connect.  The secure
TELNET port 992 (telnets) is treated the same way.

For security testing, verification can be turned off (x3270's ``Y:`` prefix /
``-noverifycert``): PHOSPHOR will then complete the handshake against a self-signed,
expired, wrong-name or otherwise untrusted certificate so you can reach and audit a
host whose certificate you would not, and should not, trust in production.  This mode
is loud on purpose - callers surface a warning - and must never be a silent default.
"""
from __future__ import annotations

import socket
import ssl
from typing import Optional


# ---------------------------------------------------------------------------
# Cipher suites that z/OS System SSL (which AT-TLS uses) and IBM i System SSL
# actually negotiate, expressed as OpenSSL cipher names, strongest first. TLS 1.3
# suites (TLS_AES_256_GCM_SHA384, TLS_AES_128_GCM_SHA256, TLS_CHACHA20_POLY1305_
# SHA256) are always offered by OpenSSL and are not controlled by set_ciphers(),
# so they are not listed here - they cover z/OS 2.4+/2.5 and IBM i 7.4+/7.5.
#
# "MAINFRAME" is the broad compatibility set: it keeps the modern ECDHE/AES-GCM
# suites but ALSO re-enables the RSA-kx AES-CBC and 3DES suites that older z/OS
# and IBM i LPARs still present, at SECLEVEL=1 so they are permitted. This lets a
# fully *verified* TLS session reach a legacy-but-cert-valid host that modern
# OpenSSL defaults (SECLEVEL 2, GCM/ECDHE only) would refuse with "no shared
# cipher".
# ---------------------------------------------------------------------------
MAINFRAME_CIPHERS = ":".join([
    # ECDHE + AES-GCM  (z/OS 2.3+/2.4+, IBM i 7.4+; the preferred modern suites)
    "ECDHE-ECDSA-AES256-GCM-SHA384", "ECDHE-RSA-AES256-GCM-SHA384",
    "ECDHE-ECDSA-AES128-GCM-SHA256", "ECDHE-RSA-AES128-GCM-SHA256",
    # ECDHE + AES-CBC
    "ECDHE-ECDSA-AES256-SHA384", "ECDHE-RSA-AES256-SHA384",
    "ECDHE-ECDSA-AES128-SHA256", "ECDHE-RSA-AES128-SHA256",
    "ECDHE-ECDSA-AES256-SHA", "ECDHE-RSA-AES256-SHA",
    "ECDHE-ECDSA-AES128-SHA", "ECDHE-RSA-AES128-SHA",
    # RSA key-exchange + AES-GCM / AES-CBC  (very common on z/OS and IBM i)
    "AES256-GCM-SHA384", "AES128-GCM-SHA256",
    "AES256-SHA256", "AES128-SHA256",
    "AES256-SHA", "AES128-SHA",
    # 3DES - legacy z/OS / IBM i systems that predate AES policy
    "DES-CBC3-SHA",
]) + ":@SECLEVEL=1"

# Everything OpenSSL can still do, including RC4/DES/export-grade, for reaching
# deliberately weak or misconfigured *test* targets. Never used with verification.
LEGACY_CIPHERS = "ALL:@SECLEVEL=0"

# Strong, modern-only (the secure default): ECDHE/AES-GCM at the library's normal
# SECLEVEL. Passing None leaves OpenSSL's default list untouched.
MODERN_CIPHERS = None

_PROFILES = {
    # secure default: leave OpenSSL's modern list + normal security level untouched
    "modern": None,
    # broadest reach for a *verified* session to an older z/OS / IBM i host: keep the
    # full default suite list but drop the security level to 1 (permits SHA-1 MAC and
    # 3DES where the library provides it) - the version floor is lowered to TLS 1.0
    # separately below. This reaches legacy-but-cert-valid hosts that the modern
    # default (SECLEVEL 2, TLS 1.2 floor) refuses.
    "compat": "DEFAULT:@SECLEVEL=1",
    "mainframe": "DEFAULT:@SECLEVEL=1",
    "ibmi": "DEFAULT:@SECLEVEL=1",
    # everything the library can still do, incl. export/RC4/DES: untrusted test hosts
    "legacy": "ALL:@SECLEVEL=0",
}


class TLSInfo:
    """What actually happened on the wire, for the status line / OIA."""
    def __init__(self) -> None:
        self.active = False
        self.verified = False
        self.version: Optional[str] = None
        self.cipher: Optional[str] = None
        self.peer_cn: Optional[str] = None
        self.peer_subject: Optional[str] = None
        self.warning: Optional[str] = None
        self.profile: Optional[str] = None

    def summary(self) -> str:
        if not self.active:
            return "no TLS"
        v = self.version or "TLS"
        tag = "verified" if self.verified else "UNVERIFIED"
        return f"{v} {tag}" + (f" ({self.cipher})" if self.cipher else "")


def _peer_cn(cert: Optional[dict]) -> Optional[str]:
    if not cert:
        return None
    for rdn in cert.get("subject", ()):        # tuple of ((k, v), ...)
        for k, v in rdn:
            if k == "commonName":
                return v
    return None


def wrap_socket(sock: socket.socket, host: str, *,
                verify: bool = True,
                accept_hostname: Optional[str] = None,
                ca_file: Optional[str] = None,
                client_cert: Optional[str] = None,
                client_key: Optional[str] = None,
                legacy: bool = False,
                cipher_profile: str = "modern",
                ciphers: Optional[str] = None,
                info: Optional[TLSInfo] = None) -> ssl.SSLSocket:
    """Wrap a connected TCP socket in a TLS tunnel and return the TLS socket.

    verify           - validate the host certificate + name (production default).
    accept_hostname  - name to match the certificate against / send as SNI instead of
                       `host` (x3270's =name suffix / acceptHostname resource).
    ca_file          - extra CA bundle to trust when verifying.
    client_cert/key  - client certificate + private key for mutual TLS.
    legacy           - relax the minimum TLS version and cipher security level so old
                       mainframe stacks (TLS 1.0, legacy ciphers) can still be reached.
                       Forced on when verify is False, since testing targets are often
                       exactly the old / misconfigured hosts you cannot validate.
    """
    info = info or TLSInfo()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)

    if verify:
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
        ctx.load_default_certs()
        if ca_file:
            ctx.load_verify_locations(cafile=ca_file)
        server_hostname = accept_hostname or host
    else:
        # security-testing mode: complete the handshake regardless of the certificate
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        legacy = True
        # SNI is still useful (some hosts serve different certs by name); harmless with
        # no verification, and skipped automatically for bare IP addresses.
        server_hostname = accept_hostname or host

    # --- cipher suite / protocol version selection ------------------------
    # Pick the effective cipher set. An explicit `ciphers` string wins; otherwise
    # a named profile ("modern" default, "compat"/"mainframe"/"ibmi", "legacy").
    # No-verify testing still relaxes to the widest set unless told otherwise, and
    # `legacy=True` remains a shortcut for the legacy profile.
    effective = cipher_profile or "modern"
    if legacy:
        effective = "legacy"
    if not verify and effective == "modern":
        # reaching an untrusted host usually means an old/misconfigured stack
        effective = "legacy"

    cipher_str = ciphers if ciphers is not None else _PROFILES.get(effective, MODERN_CIPHERS)

    # compat and legacy profiles must be able to reach TLS 1.0/1.1 hosts
    if effective in ("compat", "mainframe", "ibmi", "legacy") or ciphers is not None:
        try:
            ctx.minimum_version = ssl.TLSVersion.TLSv1
        except (ValueError, OSError):
            pass

    if cipher_str is not None:
        # try the requested list, then progressively safer fallbacks so a build
        # against an OpenSSL that lacks a given suite still comes up.
        for attempt in (cipher_str, "DEFAULT:@SECLEVEL=1", "DEFAULT"):
            try:
                ctx.set_ciphers(attempt)
                break
            except ssl.SSLError:
                continue

    if client_cert:
        ctx.load_cert_chain(certfile=client_cert, keyfile=client_key)

    # In verify mode always pass the name/address so Python can validate it (it matches
    # IP SANs for bare addresses).  In no-verify mode SNI is only useful for real
    # hostnames, so suppress it for a bare IP to keep the handshake happy.
    sni = server_hostname
    if not verify and sni and _looks_like_ip(sni):
        sni = None

    tls = ctx.wrap_socket(sock, server_hostname=sni)

    info.active = True
    info.verified = bool(verify)
    info.profile = effective
    try:
        info.version = tls.version()
        ci = tls.cipher()
        info.cipher = ci[0] if ci else None
        cert = tls.getpeercert()
        info.peer_cn = _peer_cn(cert)
    except Exception:
        pass
    if not verify:
        info.warning = ("certificate NOT verified - testing mode; do not trust this "
                        "session for anything but authorised audit")
    return tls


def _looks_like_ip(name: str) -> bool:
    try:
        socket.inet_pton(socket.AF_INET, name); return True
    except OSError:
        pass
    try:
        socket.inet_pton(socket.AF_INET6, name.strip("[]")); return True
    except OSError:
        return False


def default_secure_port(port: int) -> bool:
    """Port 992 (telnets) implies an implicit TLS tunnel, matching x3270."""
    return port == 992


class Target:
    """A parsed connection target with its TLS options."""
    def __init__(self, host: str, tls: bool = False, verify: bool = True,
                 accept_hostname: Optional[str] = None) -> None:
        self.host = host
        self.tls = tls
        self.verify = verify
        self.accept_hostname = accept_hostname


def parse_target(host: str) -> Target:
    """Read x3270-style prefixes off a host string so TLS can be driven straight from
    the host box:

        L:host          TLS tunnel (implicit / AT-TLS)
        Y:host          skip certificate verification (implies TLS; testing only)
        L:Y:host        TLS tunnel, no verification
        host=certname   match / send `certname` instead of `host` for the certificate

    Order and case of the L:/Y: letters do not matter.  Anything else is left alone.
    """
    tls = verify = None
    h = host.strip()
    # peel leading single-letter prefixes "X:"
    while len(h) > 2 and h[1] == ":" and h[0].isalpha():
        p = h[0].upper()
        if p == "L":
            tls = True
        elif p == "Y":
            verify = False; tls = True
        elif p == "A":
            pass                       # NVT / plain, no TLS implication here
        else:
            break                      # unknown prefix - stop, leave it on the host
        h = h[2:].strip()
    accept = None
    if "=" in h and not h.count(":") > 1:      # host=certname  (skip for IPv6 [..])
        h, accept = h.split("=", 1)
    return Target(h.strip(),
                  tls=bool(tls),
                  verify=True if verify is None else verify,
                  accept_hostname=accept or None)
