"""DRDA EXCSAT probe for DB2 (db2-das-info).

Sends a minimal EXCSAT (Exchange Server Attributes) request and parses the
server's EXCSATRD reply for the server name, release level and external name -
i.e. the DB2 instance identity - over the standard DRDA framing:

    DSS header (6):  length(2) 0xD0 format(1) correlation-id(2)
    DDM object:      length(2) codepoint(2) data...

String parameters are EBCDIC (cp037).  Clean-room, from the public DRDA spec.
"""
from __future__ import annotations
import socket
import struct
from typing import Dict, Optional

MAGIC = 0xD0
EXCSAT   = 0x1041
EXCSATRD = 0x1443
EXTNAM   = 0x115E
SRVCLSNM = 0x1147
SRVNAM   = 0x116D
SRVRLSLV = 0x115A
PRDID    = 0x112E
MGRLVLLS = 0x1404


def _param(cp: int, data: bytes) -> bytes:
    return struct.pack(">HH", len(data) + 4, cp) + data


def build_excsat(extnam: str = "PHOSPHOR") -> bytes:
    body = _param(EXTNAM, extnam.encode("cp037"))
    ddm = struct.pack(">HH", len(body) + 4, EXCSAT) + body
    return struct.pack(">HBBH", len(ddm) + 6, MAGIC, 0x01, 1) + ddm      # request DSS


def parse_excsatrd(data: bytes) -> Dict[str, str]:
    """Extract EBCDIC string parameters from an EXCSATRD reply."""
    out: Dict[str, str] = {}
    if len(data) < 10 or data[2] != MAGIC:
        return out
    try:
        dss_len = struct.unpack(">H", data[0:2])[0]
        ddm = data[6:dss_len or len(data)]
        ddm_len = struct.unpack(">H", ddm[0:2])[0]
        cp = struct.unpack(">H", ddm[2:4])[0]
        if cp != EXCSATRD:
            return out
        off = 4
        names = {SRVNAM: "srvnam", SRVRLSLV: "srvrlslv", EXTNAM: "extnam",
                 SRVCLSNM: "srvclsnm", PRDID: "prdid"}
        while off + 4 <= ddm_len:
            plen = struct.unpack(">H", ddm[off:off + 2])[0]
            pcp = struct.unpack(">H", ddm[off + 2:off + 4])[0]
            if plen < 4:
                break
            if pcp in names:
                raw = ddm[off + 4:off + plen]
                try:
                    out[names[pcp]] = raw.decode("cp037").strip()
                except Exception:
                    out[names[pcp]] = raw.hex()
            off += plen
    except Exception:
        pass
    return out


def probe(host: str, port: int = 50000, timeout: float = 6.0) -> Dict[str, str]:
    """Return the DB2 server attributes (or a text DAS-info fallback)."""
    with socket.create_connection((host, port), timeout) as s:
        s.settimeout(timeout)
        s.sendall(build_excsat())
        data = s.recv(4096)
    if data[:1] and data[2:3] == bytes([MAGIC]):
        info = parse_excsatrd(data)
        if info:
            return info
    # text DAS-info fallback (some servers answer with a plain profile)
    try:
        text = data.decode("utf-8", "ignore")
        d = {}
        for line in text.replace("\r", "\n").split("\n"):
            if "=" in line:
                k, _, v = line.partition("=")
                d[k.strip().lower()] = v.strip()
        return d
    except Exception:
        return {}
