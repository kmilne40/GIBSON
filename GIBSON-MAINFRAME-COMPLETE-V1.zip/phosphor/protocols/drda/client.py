"""Native DRDA client for DB2 for z/OS (DDF, usually port 446).

Extends the minimal EXCSAT probe in this package with the full connect handshake:

    EXCSAT  -> EXCSATRD   exchange server attributes  (fingerprint)
    ACCSEC  -> ACCSECRD   negotiate the security mechanism (user id + password)
    SECCHK  -> SECCHKRM   check credentials  (SECCHKCD 0x00 = accepted)
    ACCRDB  -> ACCRDBRM   open the database (RDB / location)   [optional]

Two security-testing capabilities, no driver required:
  * fingerprint  - product id / location / class / release from EXCSATRD.
  * credential test / spray - SECCHK returns a security-check code, so DB2 DDF
    credentials can be validated over the wire.

Statement execution is also supported without a driver: EXCSQLIMM for non-queries
(SQLCODE via SQLCARD), and OPNQRY -> QRYDSC + QRYDTA for SELECTs, with an FD:OCA decoder
for the common column types (CHAR/VARCHAR/SMALLINT/INTEGER).  This is validated end to
end against GIBSON's DRDA listener; on a real z/OS DB2 the FD:OCA wire detail (DECIMAL,
DATE/TIME, mixed CCSID, packed types) can differ, so confirm on the metal or keep the
ibm_db driver path (api_sql.py) for guaranteed real-host result sets.
"""
from __future__ import annotations

import socket
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

EXCSAT = 0x1041
ACCSEC = 0x106D
SECCHK = 0x106E
ACCRDB = 0x2001
PRDID = 0x112E
SRVCLSNM = 0x1147
SVRCOD = 0x1149
SRVRLSLV = 0x115A
EXTNAM = 0x115E
SRVNAM = 0x116D
USRID = 0x11A0
PASSWORD = 0x11A1
SECMEC = 0x11A2
SECCHKCD = 0x11A4
SECCHKRM = 0x1219
MGRLVLLS = 0x1404
EXCSATRD = 0x1443
ACCSECRD = 0x14AC
RDBNAM = 0x2110
ACCRDBRM = 0x2201
RDBNFNRM = 0x2211
EXCSQLIMM = 0x200A          # execute immediate SQL
SQLSTT = 0x2414             # SQL statement object
SQLCARD = 0x2408            # SQL communications-area reply
SQLCARDDATA = 0x2411        # (GIBSON) SQLCA blob: int32 sqlcode + EBCDIC text
PKGNAMCSN = 0x2113
# query result sets (OPNQRY -> QRYDSC + QRYDTA)
OPNQRY = 0x200C
PRPSQLSTT = 0x200D
CLSQRY = 0x2005
QRYDSC = 0x241A
QRYDTA = 0x241B
OPNQRYRM = 0x2205
ENDQRYRM = 0x220B
_OBJDSS = 0x03
T_VARCHAR, T_CHAR, T_SMALLINT, T_INTEGER = 448, 452, 500, 496

SECMEC_USRIDPWD = 0x0003
SECCHKCD_OK = 0x00

_MAGIC = 0xD0
_RQSDSS = 0x01
_CLIENT_MGRLVLLS = bytes.fromhex("1403000724070008240f000814400008147400081c0008146c0008")

SECCHKCD_TEXT = {
    0x00: "accepted (credentials valid)",
    0x01: "SECMEC not supported",
    0x0E: "password expired",
    0x0F: "password invalid",
    0x10: "userid invalid / not found",
    0x12: "userid revoked",
    0x13: "new password invalid",
}


def _ebcdic(text: str) -> bytes:
    return text.encode("cp037")


def _from_ebcdic(raw: bytes) -> str:
    try:
        return raw.decode("cp037").strip()
    except Exception:
        return ""


def _param(codepoint: int, data: bytes) -> bytes:
    return struct.pack(">HH", len(data) + 4, codepoint) + data


def _rqsdss(ddm: bytes, corr: int = 1) -> bytes:
    return struct.pack(">HBBH", len(ddm) + 6, _MAGIC, _RQSDSS, corr) + ddm


def _ddm(codepoint: int, params: bytes) -> bytes:
    return struct.pack(">HH", len(params) + 4, codepoint) + params


def build_excsat(extnam: str = "PHOSPHOR", corr: int = 1) -> bytes:
    p = _param(EXTNAM, _ebcdic(extnam)) + _param(MGRLVLLS, _CLIENT_MGRLVLLS)
    return _rqsdss(_ddm(EXCSAT, p), corr)


def build_accsec(rdbnam: str = "", corr: int = 1) -> bytes:
    p = _param(SECMEC, struct.pack(">H", SECMEC_USRIDPWD))
    if rdbnam:
        p += _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))
    return _rqsdss(_ddm(ACCSEC, p), corr)


def build_secchk(userid: str, password: str, rdbnam: str = "", corr: int = 1) -> bytes:
    p = _param(SECMEC, struct.pack(">H", SECMEC_USRIDPWD))
    if rdbnam:
        p += _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))
    p += _param(USRID, _ebcdic(userid)) + _param(PASSWORD, _ebcdic(password))
    return _rqsdss(_ddm(SECCHK, p), corr)


def build_accrdb(rdbnam: str, corr: int = 1) -> bytes:
    return _rqsdss(_ddm(ACCRDB, _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))), corr)


def parse_reply(data: bytes) -> Tuple[Optional[int], Dict[int, bytes]]:
    if not data or len(data) < 10 or data[2] != _MAGIC:
        return None, {}
    dss_len = struct.unpack(">H", data[0:2])[0]
    ddm = data[6:dss_len]
    if len(ddm) < 4:
        return None, {}
    ddm_len = struct.unpack(">H", ddm[0:2])[0]
    codepoint = struct.unpack(">H", ddm[2:4])[0]
    params: Dict[int, bytes] = {}
    off = 4
    while off + 4 <= min(ddm_len, len(ddm)):
        plen = struct.unpack(">H", ddm[off:off + 2])[0]
        pcp = struct.unpack(">H", ddm[off + 2:off + 4])[0]
        if plen < 4:
            break
        params[pcp] = ddm[off + 4:off + plen]
        off += plen
    return codepoint, params


@dataclass
class DrdaResult:
    host: str
    port: int
    reachable: bool = False
    is_drda: bool = False
    extnam: str = ""
    srvclsnm: str = ""
    srvnam: str = ""
    srvrlslv: str = ""
    prdid: str = ""
    auth_attempted: bool = False
    secchkcd: Optional[int] = None
    rdb_opened: Optional[bool] = None
    error: Optional[str] = None
    findings: List[str] = field(default_factory=list)

    @property
    def auth_ok(self) -> Optional[bool]:
        if self.secchkcd is None:
            return None
        return self.secchkcd == SECCHKCD_OK

    def secchk_text(self) -> str:
        return SECCHKCD_TEXT.get(self.secchkcd, f"code 0x{(self.secchkcd or 0):02X}")


class DrdaClient:
    def __init__(self, host: str, port: int = 446, *, tls: bool = False,
                 timeout: float = 10.0) -> None:
        self.host = host
        self.port = port
        self.tls = tls
        self.timeout = timeout
        self.sock: Optional[socket.socket] = None

    def connect(self) -> None:
        s = socket.create_connection((self.host, self.port), self.timeout)
        if self.tls:
            from phosphor.protocols import tls as _tls
            s = _tls.wrap_socket(s, self.host, verify=False)
        s.settimeout(self.timeout)
        self.sock = s

    def close(self) -> None:
        try:
            if self.sock:
                self.sock.close()
        finally:
            self.sock = None

    def _recvn(self, n: int) -> bytes:
        buf = b""
        while len(buf) < n:
            try:
                chunk = self.sock.recv(n - len(buf))
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk
        return buf

    def exchange(self, req: bytes) -> Tuple[Optional[int], Dict[int, bytes]]:
        assert self.sock is not None
        self.sock.sendall(req)
        head = self._recvn(6)
        if len(head) < 6:
            return None, {}
        dss_len = struct.unpack(">H", head[0:2])[0]
        body = self._recvn(dss_len - 6) if dss_len > 6 else b""
        return parse_reply(head + body)

    def recv_dss_raw(self) -> Tuple[Optional[int], bytes]:
        """Read one DSS and return (ddm_codepoint, raw_ddm_body). For QRYDSC/QRYDTA
        whose bodies are FD:OCA, not parameter lists."""
        head = self._recvn(6)
        if len(head) < 6:
            return None, b""
        dss_len = struct.unpack(">H", head[0:2])[0]
        body = self._recvn(dss_len - 6) if dss_len > 6 else b""
        ddm = (head + body)[6:]
        if len(ddm) < 4:
            return None, b""
        cp = struct.unpack(">H", ddm[2:4])[0]
        return cp, ddm[4:]

    def send(self, data: bytes) -> None:
        assert self.sock is not None
        self.sock.sendall(data)


def build_opnqry(rdbnam: str, corr: int = 1) -> bytes:
    return _rqsdss(_ddm(OPNQRY, _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))), corr)


def build_prpsqlstt(rdbnam: str, corr: int = 1) -> bytes:
    return _rqsdss(_ddm(PRPSQLSTT, _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))), corr)


def build_clsqry(rdbnam: str, corr: int = 1) -> bytes:
    return _rqsdss(_ddm(CLSQRY, _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))), corr)


def decode_qrydsc(body: bytes):
    """FD:OCA-style column descriptor -> list of (name, type_code, maxlen)."""
    if len(body) < 2:
        return []
    ncols = struct.unpack(">H", body[0:2])[0]
    off, cols = 2, []
    for _ in range(ncols):
        if off + 6 > len(body):
            break
        tcode, maxlen = struct.unpack(">HH", body[off:off + 4]); off += 4
        off += 1                                   # nullable flag
        namelen = body[off]; off += 1
        name = body[off:off + namelen].decode("cp037", "replace"); off += namelen
        cols.append((name.strip(), tcode, maxlen))
    return cols


def decode_qrydta(body: bytes, columns):
    """Decode the row stream against the column descriptor."""
    rows, off = [], 0
    while off < len(body):
        marker = body[off]; off += 1
        if marker == 0xFF:                          # end of rows
            break
        row = {}
        for name, tcode, maxlen in columns:
            if off >= len(body):
                break
            nullind = body[off]; off += 1
            if nullind == 0xFF:
                row[name] = None; continue
            if tcode in (T_VARCHAR, T_CHAR):
                ln = struct.unpack(">H", body[off:off + 2])[0]; off += 2
                row[name] = body[off:off + ln].decode("cp037", "replace"); off += ln
            elif tcode == T_SMALLINT:
                row[name] = struct.unpack(">h", body[off:off + 2])[0]; off += 2
            elif tcode == T_INTEGER:
                row[name] = struct.unpack(">i", body[off:off + 4])[0]; off += 4
            else:
                ln = struct.unpack(">H", body[off:off + 2])[0]; off += 2
                row[name] = body[off:off + ln].decode("cp037", "replace"); off += ln
        rows.append(row)
    return rows


def _query(cli: "DrdaClient", rdbnam: str, sql: str):
    """Run a SELECT via OPNQRY and return (columns, rows). columns is [(name,type,len)]."""
    cli.send(build_prpsqlstt(rdbnam) + build_sqlstt(sql))
    cli.recv_dss_raw()                              # prepare ack (SQLCARD)
    cli.send(build_opnqry(rdbnam) + build_sqlstt(sql))
    columns, rows = [], []
    for _ in range(10000):                          # safety bound
        cp, raw = cli.recv_dss_raw()
        if cp is None:
            break
        if cp == QRYDSC:
            columns = decode_qrydsc(raw)
        elif cp == QRYDTA:
            rows += decode_qrydta(raw, columns)
        elif cp == ENDQRYRM:
            cli.recv_dss_raw()                      # trailing SQLCARD
            break
        elif cp == SQLCARD:
            break
        # OPNQRYRM and others: keep reading
    cli.send(build_clsqry(rdbnam)); cli.recv_dss_raw()
    return columns, rows


def probe(host: str, port: int = 446, *, userid: str = "", password: str = "",
          rdbnam: str = "", tls: bool = False, timeout: float = 10.0) -> DrdaResult:
    """Fingerprint a DB2 DRDA server and, if credentials are supplied, test them."""
    res = DrdaResult(host, port)
    cli = DrdaClient(host, port, tls=tls, timeout=timeout)
    try:
        cli.connect()
        res.reachable = True
        cp, params = cli.exchange(build_excsat())
        if cp != EXCSATRD:
            res.error = f"no EXCSATRD (got codepoint {cp})"
            cli.close(); return res
        res.is_drda = True
        res.extnam = _from_ebcdic(params.get(EXTNAM, b""))
        res.srvclsnm = _from_ebcdic(params.get(SRVCLSNM, b""))
        res.srvnam = _from_ebcdic(params.get(SRVNAM, b""))
        res.srvrlslv = _from_ebcdic(params.get(SRVRLSLV, b""))
        res.findings.append(f"DB2 DRDA server: {res.srvclsnm or '?'} "
                            f"{res.srvrlslv or ''} location={res.srvnam or '?'}")

        cli.exchange(build_accsec(rdbnam))            # ACCSECRD

        if userid:
            res.auth_attempted = True
            cp, params = cli.exchange(build_secchk(userid, password, rdbnam))
            if cp == SECCHKRM:
                cd = params.get(SECCHKCD)
                res.secchkcd = cd[0] if cd else None
                if res.auth_ok:
                    res.findings.append(f"credentials ACCEPTED for {userid} - valid DB2 login")
                    if rdbnam:
                        cp2, _ = cli.exchange(build_accrdb(rdbnam))
                        res.rdb_opened = (cp2 == ACCRDBRM)
                        res.findings.append(
                            f"RDB {rdbnam}: {'opened' if res.rdb_opened else 'not found / denied'}")
                else:
                    res.findings.append(f"credentials rejected for {userid}: {res.secchk_text()}")
            else:
                res.error = f"unexpected SECCHK reply codepoint {cp}"
        cli.close()
    except Exception as e:
        res.error = str(e)
        cli.close()
    return res


def spray(host: str, creds: List[Tuple[str, str]], port: int = 446,
          rdbnam: str = "", tls: bool = False) -> List[DrdaResult]:
    """Test a list of (userid, password) pairs against DB2 DDF. Returns the hits."""
    hits = []
    for u, p in creds:
        r = probe(host, port, userid=u, password=p, rdbnam=rdbnam, tls=tls)
        if r.auth_ok:
            hits.append(r)
    return hits


class DrdaSession:
    """A live DRDA connection you log in to once and then run many statements over -
    so the SQL console can be a real client connection area (connect, login, run SQL)."""

    def __init__(self, host: str, port: int = 446, *, tls: bool = False,
                 timeout: float = 10.0) -> None:
        self.cli = DrdaClient(host, port, tls=tls, timeout=timeout)
        self.host, self.port = host, port
        self.rdbnam = ""
        self.userid = ""
        self.authed = False
        self.server = ""
        self.release = ""
        self.location = ""

    def open(self):
        """TCP connect + EXCSAT; returns a one-line server fingerprint."""
        self.cli.connect()
        cp, params = self.cli.exchange(build_excsat())
        if cp != EXCSATRD:
            self.cli.close()
            raise RuntimeError(f"not a DRDA server (codepoint {cp})")
        self.server = _from_ebcdic(params.get(SRVCLSNM, b""))
        self.release = _from_ebcdic(params.get(SRVRLSLV, b""))
        self.location = _from_ebcdic(params.get(SRVNAM, b""))
        return f"{self.server} {self.release}  location={self.location or '?'}"

    def login(self, userid: str, password: str, rdbnam: str = ""):
        """SECCHK the credentials and open the RDB. Returns (ok, message)."""
        self.rdbnam = rdbnam or self.location or "DB2"
        self.userid = userid
        self.cli.exchange(build_accsec(self.rdbnam))
        cp, params = self.cli.exchange(build_secchk(userid, password, self.rdbnam))
        cd = params.get(SECCHKCD)
        code = cd[0] if cd else None
        self.authed = (cp == SECCHKRM and code == SECCHKCD_OK)
        if self.authed and self.rdbnam:
            self.cli.exchange(build_accrdb(self.rdbnam))
        msg = "login successful" if self.authed else \
            f"login failed: {SECCHKCD_TEXT.get(code, f'code 0x{(code or 0):02X}')}"
        return self.authed, msg

    def query(self, sql: str):
        """Run a SELECT and return (columns, rows) with typed values."""
        if not self.authed:
            return [], []
        return _query(self.cli, self.rdbnam, sql)

    def execute(self, sql: str):
        """Run one statement over the open session. SELECTs come back as a formatted
        result set (via OPNQRY/QRYDSC/QRYDTA); other statements return (sqlcode, text)."""
        if not self.authed:
            return None, "not logged in"
        if sql.strip().upper().startswith(("SELECT", "WITH", "VALUES")):
            cols, rows = self.query(sql)
            if not rows:
                return 100, "0 rows"
            return 0, format_result_table(cols, rows)
        cp, params = self.cli.exchange(build_excsqlimm(self.rdbnam) + build_sqlstt(sql))
        blob = params.get(SQLCARDDATA)
        if cp == SQLCARD and blob and len(blob) >= 4:
            return struct.unpack(">i", blob[:4])[0], _from_ebcdic(blob[4:])
        return None, f"unexpected reply codepoint {cp}"

    def close(self):
        self.cli.close()
        self.authed = False


def format_result_table(columns, rows) -> str:
    """Render (columns, rows) as an aligned text table for the console."""
    names = [c[0] for c in columns] or (list(rows[0].keys()) if rows else [])
    widths = {n: len(str(n)) for n in names}
    for r in rows:
        for n in names:
            widths[n] = max(widths[n], len(str(r.get(n, ""))))
    head = "  ".join(str(n).ljust(widths[n]) for n in names)
    sep = "  ".join("-" * widths[n] for n in names)
    body = [head, sep]
    for r in rows:
        body.append("  ".join(str(r.get(n, "")).ljust(widths[n]) for n in names))
    body.append(f"{len(rows)} row(s)")
    return "\n".join(body)


# ---- immediate SQL execution (EXCSQLIMM) -----------------------------------
_OBJDSS = 0x03


def build_excsqlimm(rdbnam: str, corr: int = 1) -> bytes:
    p = _param(RDBNAM, _ebcdic(rdbnam.ljust(18)))
    return _rqsdss(_ddm(EXCSQLIMM, p), corr)


def build_sqlstt(sql: str, corr: int = 1) -> bytes:
    """The SQL statement as an OBJDSS carrying an SQLSTT object."""
    body = _ebcdic(sql)
    ddm = struct.pack(">HH", len(body) + 4, SQLSTT) + body
    return struct.pack(">HBBH", len(ddm) + 6, _MAGIC, _OBJDSS, corr) + ddm


def execute_sql(host: str, port: int, userid: str, password: str, rdbnam: str,
                sql: str, *, tls: bool = False, timeout: float = 10.0):
    """Authenticate, open the RDB, and run one immediate SQL statement over DRDA.
    Returns (sqlcode, text). sqlcode 0 = OK, negative = error. Interoperates with
    GIBSON's DRDA listener; real DB2 result sets still need the ibm_db driver."""
    cli = DrdaClient(host, port, tls=tls, timeout=timeout)
    cli.connect()
    cp, _ = cli.exchange(build_excsat())
    if cp != EXCSATRD:
        cli.close(); return None, "not a DRDA server"
    cli.exchange(build_accsec(rdbnam))
    cp, params = cli.exchange(build_secchk(userid, password, rdbnam))
    cd = params.get(SECCHKCD)
    if cp != SECCHKRM or not cd or cd[0] != SECCHKCD_OK:
        cli.close(); return None, "authentication failed"
    cli.exchange(build_accrdb(rdbnam))
    cp, params = cli.exchange(build_excsqlimm(rdbnam) + build_sqlstt(sql))
    cli.close()
    blob = params.get(SQLCARDDATA)
    if cp == SQLCARD and blob and len(blob) >= 4:
        sqlcode = struct.unpack(">i", blob[:4])[0]
        text = _from_ebcdic(blob[4:])
        return sqlcode, text
    return None, f"unexpected reply codepoint {cp}"
