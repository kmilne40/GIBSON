"""5250 data-stream parse (inbound) and build (outbound) - first cut.

Clean-room implementation from the public 5250 data-stream architecture, mirroring
the approach of the sibling tn3270/datastream.py.  This covers the common path that
renders an IBM i sign-on / menu panel: the Write-To-Display (WTD) command with its
control characters, and the orders SBA, RA, SF (start of field w/ format word) and
IC, with EBCDIC text placement.  A matching builder lets us round-trip test the
parser without a live host.

Not yet covered (needs iteration against a real host such as pub400.com):
structured-field / Query, TN5250E GDS wrapping, WEA/extended attributes, and the
full outbound field-read format.  The outbound builder here is a minimal AID frame.
"""
from __future__ import annotations

import codecs
from typing import List, Optional, Tuple

from phosphor.core.screen import Cell, Field, ScreenBuffer, DEFAULT_COLOUR

ESC = 0x04                       # every 5250 command is introduced by ESC

# --- commands (host -> display) ------------------------------------------
CMD_WTD = 0x11                   # Write To Display
CMD_CLEAR_UNIT = 0x40            # Clear Unit (erase, reset to 24x80)
CMD_CLEAR_UNIT_ALT = 0x20        # Clear Format Table
CMD_WEA = 0x12                   # Write Error Code (rendered on status line)
CMD_READ_MDT = 0x52             # Read Modified (host asks for input)
CMD_READ_IMMED = 0x72

# --- orders (inside a WTD) -----------------------------------------------
ORD_SBA = 0x11                   # Set Buffer Address: row, col (1-based)
ORD_RA = 0x02                    # Repeat to Address: row, col, char
ORD_SF = 0x1D                    # Start of Field: FFW(2) [+ FCW pairs] then attr
ORD_IC = 0x13                    # Insert Cursor: row, col
ORD_SOH = 0x01                   # Start of Header: len, then flags/AID mask
ORD_EA = 0x03                    # Erase to Address: row, col (fill blanks to there)
ORD_WEA = 0x12                   # Write Extended Attribute: type, value
ORD_WDSF = 0x15                  # Write to Display Structured Field: len(2), data
ORD_MC = 0x14                    # Move Cursor (no operands in WTD)
ORD_TD = 0x10                    # Transparent Data: len then raw bytes

# --- AIDs (5250) ----------------------------------------------------------
AID = {
    "ENTER": 0xF1, "CLEAR": 0xBD, "HELP": 0xF3, "PRINT": 0xF6,
    "PF1": 0x31, "PF2": 0x32, "PF3": 0x33, "PF4": 0x34, "PF5": 0x35,
    "PF6": 0x36, "PF7": 0x37, "PF8": 0x38, "PF9": 0x39, "PF10": 0x3A,
    "PF11": 0x3B, "PF12": 0x3C, "PF13": 0xB1, "PF14": 0xB2, "PF15": 0xB3,
    "PF16": 0xB4, "PF17": 0xB5, "PF18": 0xB6, "PF19": 0xB7, "PF20": 0xB8,
    "PF21": 0xB9, "PF22": 0xBA, "PF23": 0xBB, "PF24": 0xBC,
    "PA1": 0x6C, "PA2": 0x6E, "PA3": 0x6B,
}

_EBCDIC = "cp037"


def _is_attr(b: int) -> bool:
    """A 5250 field-attribute byte has its top three bits = 001 (0x20-0x3F)."""
    return (b & 0xE0) == 0x20


# 5250 field-attribute byte -> PHOSPHOR colour name (the 3270-style palette).
_ATTR_COLOUR = {
    0x20: "green", 0x22: "white", 0x24: "green", 0x26: "white", 0x27: "green",
    0x28: "red", 0x2A: "red", 0x2C: "red", 0x2E: "red",
    0x30: "turquoise", 0x32: "yellow", 0x34: "turquoise", 0x36: "yellow",
    0x38: "pink", 0x3A: "blue", 0x3C: "pink", 0x3E: "blue",
}


def _colour_from_attr(attr: int) -> str:
    return _ATTR_COLOUR.get(attr & 0x3E, DEFAULT_COLOUR)

# RFC 1205 wraps every 5250 record in a GDS header (Logical Record Length,
# Record Type 0x12A0, then a variable header carrying flags + an opcode).  The
# host sends it and expects it back; without it, an IBM i host silently ignores
# the client's field data (which is why input "did nothing" against PUB400).
GDS_RECORD_TYPE = b"\x12\xa0"
GDS_OPCODE_NOOP = 0x00
GDS_OPCODE_PUTGET = 0x03
GDS_FLAG_ATN = 0x0800          # bit 1 = 5250 ATTN key pressed


def gds_unwrap(data: bytes) -> bytes:
    """Strip a leading RFC 1205 GDS header, returning the raw 5250 command stream."""
    if len(data) >= 10 and data[2:4] == GDS_RECORD_TYPE:
        hdr = 6 + data[6]      # fixed 6 octets + variable header length (usually 4)
        return data[hdr:]
    return data


def gds_wrap(payload: bytes, opcode: int = GDS_OPCODE_PUTGET, flags: int = 0x0000) -> bytes:
    """Wrap outbound 5250 data in the RFC 1205 GDS header."""
    var = bytes([0x04, (flags >> 8) & 0xFF, flags & 0xFF, opcode & 0xFF])
    rec = GDS_RECORD_TYPE + b"\x00\x00" + var + payload
    lrl = len(rec) + 2                          # LRL counts itself + the rest of the record
    return bytes([(lrl >> 8) & 0xFF, lrl & 0xFF]) + rec



def e2a(b: int) -> str:
    """One EBCDIC byte -> unicode char (spaces/nulls -> ' ')."""
    if b in (0x00, 0x40):
        return " "
    try:
        return codecs.decode(bytes([b]), _EBCDIC)
    except Exception:
        return " "


def a2e(s: str) -> bytes:
    try:
        return codecs.encode(s, _EBCDIC)
    except Exception:
        return b"\x40" * len(s)


# =========================================================================
# Inbound: parse host data stream into a ScreenBuffer
# =========================================================================
def parse(data: bytes, screen: ScreenBuffer) -> ScreenBuffer:
    """Apply a 5250 host data stream to `screen`.  Tolerant: unknown orders and
    commands are skipped rather than raising, so a partial/oddly-framed record
    still renders what it can."""
    i, n = 0, len(data)
    cols = screen.cols
    pos = 0                                   # linear buffer address
    _fields = []                              # explicit input-field table (5250)
    while i < n:
        if data[i] != ESC:
            i += 1
            continue
        if i + 1 >= n:
            break
        cmd = data[i + 1]
        i += 2
        if cmd in (CMD_CLEAR_UNIT, CMD_CLEAR_UNIT_ALT):
            screen.clear(); pos = 0; _fields = []
            screen.field_table = None
            continue
        if cmd != CMD_WTD:
            # commands we don't render (reads, WEA, etc.) - stop consuming here;
            # the caller decides what to do with a read request.
            continue
        # WTD: two control-character bytes, then orders/data until the next ESC
        if i + 1 < n:
            i += 2                            # CC1, CC2 (lock keyboard / reset etc.)
        while i < n and data[i] != ESC:
            b = data[i]
            if b == ORD_SBA and i + 2 < n:
                row, col = data[i + 1], data[i + 2]
                pos = _rc_to_addr(row, col, cols); i += 3
            elif b == ORD_IC and i + 2 < n:
                row, col = data[i + 1], data[i + 2]
                screen.cursor = _rc_to_addr(row, col, cols); i += 3
            elif b == ORD_RA and i + 3 < n:
                row, col = data[i + 1], data[i + 2]
                end = _rc_to_addr(row, col, cols)
                ch = e2a(data[i + 3]); i += 4
                while pos <= end and pos < len(screen.cells):
                    screen.set_cell(pos, Cell(ch, DEFAULT_COLOUR)); pos += 1
            elif b == ORD_SF:
                # Start of Field.  Peek the next byte: if it is already an
                # attribute byte, this is an OUTPUT-ONLY field (no FFW, no length,
                # always protected); otherwise it is an INPUT field with a Field
                # Format Word, optional Field Control Word pairs, an attribute
                # byte, then a 2-byte length.  Getting this wrong (reading a FFW
                # for output fields) ate the first characters of every label and
                # left input fields undetectable - the PUB400 sign-on failure.
                j = i + 1
                ffw = 0
                has_ffw = False
                if j < n and not _is_attr(data[j]):
                    has_ffw = True
                    ffw = (data[j] << 8) | data[j + 1]
                    j += 2
                    while j < n and not _is_attr(data[j]):
                        j += 2                      # skip FCW pair
                attr = data[j] if j < n else 0x20
                j += 1
                length = 0
                if has_ffw and j + 1 < n:
                    length = (data[j] << 8) | data[j + 1]      # field length (input only)
                    j += 2
                protected = (not has_ffw) or bool(ffw & 0x2000)
                hidden = (ffw & 0x0C00) == 0x0C00 or (attr & 0x2F) == 0x27
                colour = _colour_from_attr(attr)
                cell = Cell(" ", colour)
                cell.protected = protected
                cell.hidden = hidden
                cell.is_field_start = True
                if pos < len(screen.cells):
                    screen.set_cell(pos, cell)
                    # Record EVERY field (protected label AND input) in the explicit
                    # table.  5250 later writes can clobber the attribute cell, so the
                    # 3270-style "run to next attribute" inference is unreliable here -
                    # the table is authoritative.  Input fields carry the explicit SF
                    # length; output/label fields get their length computed post-parse
                    # as the distance to the next field-start, so the label text (and
                    # hidden-masking, and tab targets) all come out right.
                    body = pos + 1
                    _fields.append({
                        "addr": body % len(screen.cells),
                        "length": max(0, length) if has_ffw else None,
                        "protected": protected, "colour": colour,
                        "highlight": "normal", "intensified": False,
                        "hidden": hidden,
                    })
                    pos += 1
                i = j; continue
            elif b == ORD_EA and i + 2 < n:
                # Erase to Address: blank from the current position to (row,col)
                row, col = data[i + 1], data[i + 2]
                end = _rc_to_addr(row, col, cols); i += 3
                while pos < end and pos < len(screen.cells):
                    screen.set_cell(pos, Cell(" ", DEFAULT_COLOUR)); pos += 1
            elif b == ORD_WEA and i + 2 < n:
                # Write Extended Attribute (type, value) - consumed, no cell used,
                # so following text stays aligned instead of scattering.
                i += 3
            elif b == ORD_WDSF and i + 2 < n:
                ln = (data[i + 1] << 8) | data[i + 2]      # length includes itself
                i += 1 + max(2, ln)                        # skip the structured field
            elif b == ORD_MC:
                i += 1                                     # move cursor, no operands here
            elif b == ORD_TD and i + 2 < n:
                ln = (data[i + 1] << 8) | data[i + 2]; i += 3 + ln     # skip transparent block
            elif b == ORD_SOH and i + 1 < n:
                ln = data[i + 1]; i += 2 + ln                          # skip header
            elif 0x20 <= b <= 0x3F:
                # bare 5250 field-attribute byte: display position, renders BLANK
                # (this is what was showing up as stray corner/¬ glyphs on PUB400)
                if pos < len(screen.cells):
                    screen.set_cell(pos, Cell(" ", DEFAULT_COLOUR)); pos += 1
                i += 1
            else:
                # EBCDIC controls (< 0x40) render blank; 0x40+ decode to text
                ch = " " if b < 0x40 else e2a(b)
                if pos < len(screen.cells):
                    screen.set_cell(pos, Cell(ch, DEFAULT_COLOUR)); pos += 1
                i += 1
    # 5250 fields carry explicit lengths and later writes can clobber the
    # attribute cells, so hand the FieldEditor the exact field list we parsed.
    # Output/label fields have no explicit length: fill it as the distance from
    # the field body to the next field-start (buffer order), or to the end of the
    # buffer for the last field - the classic 3270 field extent, applied only to
    # the protected labels so input fields keep their exact host-given length.
    if _fields:
        ordered = sorted(_fields, key=lambda f: f["addr"])
        total = len(screen.cells)
        starts = [f["addr"] for f in ordered]
        table = []
        for idx, f in enumerate(ordered):
            length = f["length"]
            if length is None:
                nxt = starts[idx + 1] - 1 if idx + 1 < len(starts) else total
                length = max(0, nxt - f["addr"])
            r, c = screen.rc(f["addr"])
            table.append(Field(row=r, col=c, length=length,
                               protected=f["protected"], colour=f["colour"],
                               highlight=f["highlight"], intensified=f["intensified"],
                               hidden=f["hidden"]))
        screen.field_table = table
    return screen


def _rc_to_addr(row: int, col: int, cols: int) -> int:
    row = max(1, row); col = max(1, col)
    return (row - 1) * cols + (col - 1)


# =========================================================================
# Outbound: build a minimal inbound frame (client -> host)
# =========================================================================
def build_inbound(screen: ScreenBuffer, aid: str,
                  pending: Optional[List[Tuple[int, str]]] = None) -> bytes:
    """A first-cut 5250 read response: cursor row/col, the AID, then each typed
    field as SBA + EBCDIC text.  Real hosts expect the fields the Read specified;
    this is enough to drive a sign-on and is the piece to refine against a host."""
    cols = screen.cols
    r, c = screen.rc(screen.cursor)
    out = bytearray([r & 0xFF, c & 0xFF, AID.get(aid, AID["ENTER"])])
    for addr, text in (pending or []):
        rr = (addr // cols) + 1
        cc = (addr % cols) + 1
        out += bytes([ORD_SBA, rr & 0xFF, cc & 0xFF]) + a2e(text)
    return bytes(out)


# =========================================================================
# Builder used by the tests (and handy for demos): encode a text screen as a WTD
# =========================================================================
def build_wtd(rows_text: List[str], cursor_rc: Tuple[int, int] = (1, 1)) -> bytes:
    """Encode plain rows of text into a Clear-Unit + Write-To-Display stream."""
    out = bytearray([ESC, CMD_CLEAR_UNIT, ESC, CMD_WTD, 0x00, 0x00])
    for r, line in enumerate(rows_text, start=1):
        line = line.rstrip()
        if not line:
            continue
        out += bytes([ORD_SBA, r, 1]) + a2e(line)
    cr, cc = cursor_rc
    out += bytes([ORD_IC, cr, cc])
    return bytes(out)
