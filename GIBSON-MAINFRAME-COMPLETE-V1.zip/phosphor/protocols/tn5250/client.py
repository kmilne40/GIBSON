"""TN5250 client - a Session over telnet to an IBM i (AS/400) host.

Mirrors TN3270Client's surface so the app drives either identically.  Uses the
shared telnet Negotiator with the 5250 device type (RFC 1205 basic mode), and the
clean-room 5250 data-stream parser in datastream.py.  First cut: renders host
panels and can send an AID; TN5250E (GDS-wrapped) mode and the full field-read
format are the pieces to refine against a live host such as pub400.com.
"""
from __future__ import annotations

import socket
from typing import List, Optional, Tuple

from phosphor.core.screen import ScreenBuffer
from phosphor.protocols.tn3270.telnet import Negotiator
from phosphor.protocols.tn5250 import datastream as ds
from phosphor.protocols import tls as _tls


class TN5250Client:
    def __init__(self, rows: int = 24, cols: int = 80,
                 device_type: str = "IBM-3179-2",
                 connect_timeout: float = 10.0, read_timeout: float = 1.5) -> None:
        self.screen = ScreenBuffer(rows, cols)
        self.neg = Negotiator(device_type=device_type, allow_tn3270e=False)
        self.sock: Optional[socket.socket] = None
        self._buf = bytearray()
        self._pending: List[Tuple[int, str]] = []
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.connected = False
        self.enhanced = False           # set True if the host uses TN5250E records
        self.tls_info = _tls.TLSInfo()

    # --- connection ------------------------------------------------------
    def connect(self, host: str, port: int = 23, *,
                tls: bool = False, tls_verify: bool = True,
                tls_accept_hostname: Optional[str] = None,
                ca_file: Optional[str] = None,
                client_cert: Optional[str] = None,
                client_key: Optional[str] = None,
                cipher_profile: str = "modern") -> None:
        raw = socket.create_connection((host, port), self.connect_timeout)
        if tls or _tls.default_secure_port(port):
            self.tls_info = _tls.TLSInfo()
            raw = _tls.wrap_socket(raw, host, verify=tls_verify,
                                   accept_hostname=tls_accept_hostname, ca_file=ca_file,
                                   client_cert=client_cert, client_key=client_key,
                                   cipher_profile=cipher_profile,
                                   info=self.tls_info)
        self.sock = raw
        self.sock.settimeout(self.read_timeout)
        self.connected = True
        self._negotiate_until_ready()

    def terminate(self) -> None:
        try:
            if self.sock:
                self.sock.close()
        finally:
            self.sock = None
            self.connected = False

    def is_connected(self) -> bool:
        return self.connected

    # --- low-level io (same tap/packet contract as TN3270Client) ---------
    def _recv(self) -> bytes:
        assert self.sock is not None
        try:
            data = self.sock.recv(65535)
        except socket.timeout:
            return b""
        self._tap("<", data)
        return data

    def _send(self, data: bytes) -> None:
        assert self.sock is not None
        self.sock.sendall(data)
        self._tap(">", data)

    def _tap(self, direction: str, data: bytes) -> None:
        buf = getattr(self, "packets", None)
        if buf is not None and data:
            buf.append((direction, bytes(data)))
            if len(buf) > 40:
                del buf[:-40]

    # --- negotiation + screen sync --------------------------------------
    def _negotiate_until_ready(self) -> None:
        empties = 0
        while empties < 15:
            chunk = self._recv()
            if not chunk:
                empties += 1
                if self.neg.ready() and self._consume([b"", b""]):
                    break
                continue
            empties = 0
            reply, segs, eor = self.neg.feed(chunk)
            if reply:
                self._send(reply)
            got = self._consume(segs)
            if self.neg.ready() and got:
                self._drain_fast(); break

    def _apply_record(self, rec: bytes) -> bool:
        """Apply ONE complete 5250 record (one EOR-terminated GDS record).

        An IBM i host answers an Enter that reads input fields with, commonly,
        *two* records back to back - a message/acknowledgement record and then the
        new screen.  The old read loop stopped at the first record and stitched the
        rest into one blob, so the screen record was missed and nothing appeared to
        change: the operator pressed Enter again and only then saw the panel move.
        That is the "needs two Enters" fault.  Function keys drew a single-record
        reply, so they always worked on the first press.  Applying each record on
        its own, and draining stragglers, fixes it without touching the (correct)
        outbound side."""
        if not rec:
            return False
        if len(rec) >= 4 and rec[2:4] == ds.GDS_RECORD_TYPE:
            self.enhanced = True                # host is using TN5250E enhanced mode
        data = ds.gds_unwrap(rec)               # strip this record's header if present
        if not data:
            return False
        ds.parse(data, self.screen)
        self.screen.keyboard_locked = False
        self._pending = []
        return True

    def _apply_screen(self) -> bool:
        """Back-compat entry point: apply whatever complete record is buffered."""
        rec = bytes(self._buf)
        self._buf = bytearray()
        return self._apply_record(rec)

    def _consume(self, segments) -> bool:
        """Fold feed() segments through the carried partial in self._buf, applying
        every complete (EOR-terminated) record.  Returns True if a record updated
        the screen."""
        updated = False
        if len(segments) <= 1:
            self._buf += segments[0] if segments else b""   # still partial, no EOR yet
            return False
        updated |= self._apply_record(bytes(self._buf) + segments[0])   # completes the carry
        for s in segments[1:-1]:
            updated |= self._apply_record(s)
        self._buf = bytearray(segments[-1])                 # trailing partial carries over
        return updated

    def _drain_fast(self) -> None:
        """After the response arrives, briefly poll for any further records the host
        queued for it (the message-then-screen pair above), then return.  Short
        timeout so there is no per-Enter lag."""
        if self.sock is None:
            return
        old = self.sock.gettimeout()
        try:
            self.sock.settimeout(0.08)
        except OSError:
            return
        try:
            for _ in range(4):
                try:
                    chunk = self.sock.recv(65535)
                except (socket.timeout, OSError):
                    break
                if not chunk:
                    break
                self._tap("<", chunk)
                reply, segs, eor = self.neg.feed(chunk)
                if reply:
                    self._send(reply)
                self._consume(segs)
        finally:
            try:
                self.sock.settimeout(old)
            except OSError:
                pass

    def _read_until_eor(self) -> None:
        """Read the host's reply to an AID and apply every record it contains, then
        drain any straggler records, so a single Enter shows the resulting panel."""
        empties = 0
        while empties < 8:
            chunk = self._recv()
            if not chunk:
                empties += 1
                continue
            empties = 0
            reply, segs, eor = self.neg.feed(chunk)
            if reply:
                self._send(reply)
            if self._consume(segs):
                self._drain_fast()
                return

    # --- app-facing API (matches TN3270Client) --------------------------
    def move_to(self, row: int, col: int) -> None:
        self.screen.cursor = self.screen.addr(row, col)

    def send_string(self, text: str) -> None:
        self._pending.append((self.screen.cursor, text))
        self.screen.cursor = (self.screen.cursor + len(text)) % len(self.screen.cells)

    safe_send = send_string

    def _aid(self, name: str) -> None:
        payload = ds.build_inbound(self.screen, name, self._pending)
        # In basic 5250 mode (RFC 1205) the inbound record is the RAW cursor+AID+
        # fields stream framed by IAC EOR - NOT GDS-wrapped.  Only wrap when the
        # host actually put us in TN5250E enhanced mode.  Wrapping in basic mode
        # is exactly why keystrokes were silently ignored by PUB400.
        if getattr(self, "enhanced", False):
            flags = ds.GDS_FLAG_ATN if name in ("PA1", "PA2", "PA3", "ATTN") else 0x0000
            payload = ds.gds_wrap(payload, opcode=ds.GDS_OPCODE_PUTGET, flags=flags)
        # BINARY mode: any 0xFF in the data must be doubled so it is not read as IAC.
        self._send(payload.replace(b"\xff", b"\xff\xff") + b"\xff\xef")
        self._pending = []
        self._read_until_eor()

    def send_enter(self) -> None: self._aid("ENTER")
    def send_clear(self) -> None: self._aid("CLEAR")
    def send_pf(self, n: int) -> None: self._aid(f"PF{n}")
    def send_pa(self, n: int) -> None: self._aid(f"PA{n}")
    def send_pf3(self) -> None: self._aid("PF3")

    def screen_get(self) -> List[str]:
        return self.screen.to_rows()

    def find(self, text: str) -> bool:
        return self.screen.find(text)

    find_response = find

    def get_pos(self) -> Tuple[int, int]:
        return self.screen.rc(self.screen.cursor)

    def colour_grid(self):
        return self.screen.colour_grid()
