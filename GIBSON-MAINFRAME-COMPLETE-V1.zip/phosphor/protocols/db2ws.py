"""DB2 clients for PHOSPHOR.

Two very different things wear the name "DB2" on a mainframe, and PHOSPHOR speaks to
both:

* **GIBSON DB2 (WebSocket shell)** - the training simulator exposes a plain-text command
  shell over a WebSocket on port 50001: connect, ``LOGIN <user> <pass>`` (checked against
  GIBSON's RACF), then type SQL/operator commands and read the reply.  That is what the
  ``Db2WsClient`` below drives, and it matches the db2-connect.py reference client.

* **Real DB2 for z/OS (DRDA/DDF)** - the production protocol on port 446 is DRDA over DDM,
  a binary protocol.  A native client is a separate, larger piece of work; see
  ``drda_setup_notes()`` for how to reach it and what a native client needs.  Until then
  PHOSPHOR drives the ``ibm_db`` driver / ``db2`` CLP for real hosts (api_sql.py).

This module has no third-party dependency: the WebSocket client is a small RFC 6455
implementation over a raw socket, so it works inside PHOSPHOR's synchronous console with
nothing extra to install and nothing extra to bundle.
"""
from __future__ import annotations

import base64
import hashlib
import os
import socket
import ssl as _ssl
import struct
from typing import List, Optional, Tuple

_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"     # RFC 6455 accept-key GUID


class WsError(Exception):
    pass


class _WebSocket:
    """Minimal synchronous RFC 6455 client: HTTP upgrade + masked text frames."""

    def __init__(self, sock: socket.socket) -> None:
        self.sock = sock
        self._buf = b""

    # -- handshake --------------------------------------------------------
    @classmethod
    def connect(cls, host: str, port: int, *, path: str = "/",
                tls: bool = False, timeout: float = 15.0) -> "_WebSocket":
        raw = socket.create_connection((host, port), timeout)
        if tls:
            ctx = _ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = _ssl.CERT_NONE
            raw = ctx.wrap_socket(raw, server_hostname=None)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        raw.sendall(req.encode("ascii"))
        ws = cls(raw)
        headers = ws._read_http_headers()
        if "101" not in headers.split("\r\n", 1)[0]:
            raw.close()
            raise WsError("server did not accept the WebSocket upgrade: "
                          + headers.split('\r\n', 1)[0])
        expect = base64.b64encode(hashlib.sha1((key + _GUID).encode()).digest()).decode()
        if expect.lower() not in headers.lower():
            raw.close()
            raise WsError("bad Sec-WebSocket-Accept from server")
        raw.settimeout(timeout)
        return ws

    def _read_http_headers(self) -> str:
        while b"\r\n\r\n" not in self._buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise WsError("connection closed during handshake")
            self._buf += chunk
        head, _, rest = self._buf.partition(b"\r\n\r\n")
        self._buf = rest
        return head.decode("latin-1")

    # -- frames -----------------------------------------------------------
    def send_text(self, text: str) -> None:
        payload = text.encode("utf-8")
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        n = len(payload)
        frame = bytearray([0x81])                       # FIN + text opcode
        if n < 126:
            frame.append(0x80 | n)
        elif n < 65536:
            frame.append(0x80 | 126); frame += struct.pack(">H", n)
        else:
            frame.append(0x80 | 127); frame += struct.pack(">Q", n)
        frame += mask + masked
        self.sock.sendall(frame)

    def _read(self, n: int) -> bytes:
        while len(self._buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise WsError("connection closed")
            self._buf += chunk
        out, self._buf = self._buf[:n], self._buf[n:]
        return out

    def recv_text(self) -> str:
        """Return the next full text message, transparently answering pings and
        stitching continuation frames."""
        data = bytearray()
        while True:
            b0, b1 = self._read(2)
            fin = b0 & 0x80
            opcode = b0 & 0x0F
            masked = b1 & 0x80
            length = b1 & 0x7F
            if length == 126:
                length = struct.unpack(">H", self._read(2))[0]
            elif length == 127:
                length = struct.unpack(">Q", self._read(8))[0]
            mask = self._read(4) if masked else b""
            payload = self._read(length)
            if masked:
                payload = bytes(c ^ mask[i % 4] for i, c in enumerate(payload))
            if opcode == 0x9:                           # ping -> pong
                self._send_control(0xA, payload); continue
            if opcode == 0xA:                            # pong
                continue
            if opcode == 0x8:                            # close
                try: self._send_control(0x8, payload[:2])
                except Exception: pass
                raise WsError("server closed the connection")
            data += payload
            if fin:
                return data.decode("utf-8", errors="replace")

    def _send_control(self, opcode: int, payload: bytes = b"") -> None:
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        frame = bytes([0x80 | opcode, 0x80 | len(payload)]) + mask + masked
        self.sock.sendall(frame)

    def close(self) -> None:
        try:
            self._send_control(0x8)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


class Db2WsClient:
    """GIBSON DB2 WebSocket shell client (the db2-connect.py protocol).

    greeting  <- "Welcome to DB2/zOS simulator.\\nLogin: LOGIN <username> <password>"
    LOGIN u p ->
    reply     <- "Login successful. Welcome, U. Type HELP"  (or a failure line)
    <sql>     -> ; reply <- command output
    """

    def __init__(self, host: str, port: int = 50001, *, tls: bool = False,
                 timeout: float = 15.0) -> None:
        self.host = host
        self.port = port
        self.tls = tls
        self.timeout = timeout
        self.ws: Optional[_WebSocket] = None
        self.greeting = ""
        self.userid: Optional[str] = None

    def connect(self) -> str:
        scheme = "wss" if self.tls else "ws"
        self.ws = _WebSocket.connect(self.host, self.port, tls=self.tls,
                                     timeout=self.timeout)
        self.greeting = self.ws.recv_text()
        return self.greeting

    def login(self, user: str, password: str) -> Tuple[bool, str]:
        if not self.ws:
            raise WsError("not connected")
        self.ws.send_text(f"LOGIN {user} {password}")
        reply = self.ws.recv_text()
        ok = "login successful" in reply.lower()
        if ok:
            self.userid = user
        return ok, reply

    def command(self, sql: str) -> str:
        if not self.ws:
            raise WsError("not connected")
        self.ws.send_text(sql)
        return self.ws.recv_text()

    def close(self) -> None:
        if self.ws:
            self.ws.close()
            self.ws = None


# quick DB2-for-z/OS enumeration statements the GIBSON shell understands
GIBSON_DB2_QUERIES: List[Tuple[str, str]] = [
    ("who am I",        "SELECT CURRENT SQLID, CURRENT SERVER FROM SYSIBM.SYSDUMMY1"),
    ("list tables",     "SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES"),
    ("list users",      "SELECT GRANTEE FROM SYSIBM.SYSUSERAUTH"),
    ("help",            "HELP"),
]


def drda_setup_notes() -> str:
    """How to reach *real* DB2 for z/OS, and what a native client needs. Shown in the
    SQL console when the user picks the DRDA/real-host path."""
    return (
        "Real DB2 for z/OS speaks DRDA over DDM (binary), normally on the DDF port 446.\n"
        "GIBSON also exposes a DRDA/DB2DAS listener on 50000 for practice.\n"
        "\n"
        "To reach it you need, in order:\n"
        "  1. DDF started on the LPAR and a TCP/IP LISTENER (DSNJU / BSDS) on 446.\n"
        "  2. A location name (SELECT CURRENT SERVER) and a RACF userid with CONNECT.\n"
        "  3. On zPDT: DB2 must be up (‑DIS DDF should show STARTED) and the port opened.\n"
        "\n"
        "PHOSPHOR client options:\n"
        "  - ibm_db driver (pip install ibm_db) or the db2 CLP - PHOSPHOR builds the\n"
        "    exact connect+SQL command for you (see the SQL console).\n"
        "  - a native DRDA client (EXCSAT/ACCSEC/SECCHK/ACCRDB + EXCSQLIMM) is on the\n"
        "    roadmap; GIBSON's gibson/net/drda.py is the reference for the handshake.\n"
    )
