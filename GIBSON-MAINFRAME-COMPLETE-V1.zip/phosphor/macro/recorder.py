"""Turn a recorded session into a replayable macro.

Tier 1 (record & replay) falls out of Tier 2 for free: drive a session with the engine
(or attach the recorder as the engine's on_step during an interactive session), then
export the transcript as a .pmac script you can replay later.

    eng = MacroEngine()
    ... drive the session ...
    open("logon.pmac", "w").write(transcript_to_script(eng))
"""
from __future__ import annotations

from phosphor.macro.engine import MacroEngine

# verbs that map straight back to a macro line as "verb detail"
_PASSTHROUGH = {"connect", "disconnect", "string", "move", "key", "enter",
                "wait", "wait_for", "expect", "snapshot", "save_screen", "log"}


def transcript_to_script(engine: MacroEngine) -> str:
    """Render an engine's transcript as a runnable .pmac script."""
    lines = ["# recorded by PHOSPHOR macro recorder"]
    for e in engine.transcript:
        verb = e["verb"]
        detail = e.get("arg", e.get("detail", ""))
        if verb not in _PASSTHROUGH:
            continue
        if verb == "connect":
            # detail looks like "host:port tls=.. verify=.. profile=.."; rebuild flags
            lines.append(_connect_line(detail))
        elif detail:
            lines.append(f"{verb} {detail}")
        else:
            lines.append(verb)
    return "\n".join(lines) + "\n"


def _connect_line(detail: str) -> str:
    # detail: "HOST:PORT tls=True verify=False profile=mainframe"
    try:
        hostport, *kvs = detail.split()
        host, _, port = hostport.partition(":")
        opts = dict(kv.split("=", 1) for kv in kvs if "=" in kv)
        parts = ["connect", host]
        if port and port != "23":
            parts.append(port)
        if opts.get("tls") == "True":
            parts.append("tls")
        if opts.get("verify") == "False":
            parts.append("noverify")
        prof = opts.get("profile", "modern")
        if prof and prof != "modern":
            parts.append(f"profile={prof}")
        return " ".join(parts)
    except Exception:
        return f"# (could not rebuild connect from: {detail})"
