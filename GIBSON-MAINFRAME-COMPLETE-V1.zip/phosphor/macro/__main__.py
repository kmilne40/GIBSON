"""Run a PHOSPHOR text macro:  python -m phosphor.macro <script.pmac> [--quiet]"""
import sys
from phosphor.macro.script import run_file
from phosphor.macro.engine import MacroError


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        print("usage: python -m phosphor.macro <script.pmac> [--quiet]")
        return 0
    path = argv[0]
    quiet = "--quiet" in argv
    def on_step(verb, detail):
        if not quiet:
            print(f"  {verb:<11} {detail}")
    try:
        eng = run_file(path, on_step=on_step)
    except MacroError as e:
        print(f"macro failed: {e}", file=sys.stderr)
        return 1
    finally:
        try:
            eng.disconnect()  # type: ignore
        except Exception:
            pass
    print("\n--- transcript ---")
    print(eng.transcript_text())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
