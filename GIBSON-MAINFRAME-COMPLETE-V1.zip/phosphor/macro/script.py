"""Run a PHOSPHOR text macro (.pmac).

Format - one verb per line, ``#`` starts a comment. Free-text verbs (string, expect,
log, enter) take the rest of the line verbatim (spaces preserved, no quoting needed):

    # log on to TSO and capture the READY screen
    connect 192.168.0.96 23 tls profile=mainframe
    wait_for LOGON 15
    string LOGON APPLID(TSO)
    key ENTER
    wait_for PASSWORD
    string hunter2
    key ENTER
    wait_for READY 20
    snapshot logged-in
    save_screen tso-ready.txt
    disconnect

connect flags: ``tls``, ``noverify``, ``5250``, ``profile=modern|mainframe|legacy``.
"""
from __future__ import annotations

from typing import Optional

from phosphor.macro.engine import MacroEngine, MacroError

FREE_TEXT = {"string", "expect", "log", "enter", "snapshot", "save_screen"}


def _parse_connect(engine: MacroEngine, args: str):
    toks = args.split()
    if not toks:
        raise MacroError("connect: needs a host")
    host = toks[0]
    port = 23
    tls = verify = five = False
    verify = True
    profile = "modern"
    for tok in toks[1:]:
        t = tok.lower()
        if t.isdigit():
            port = int(t)
        elif t == "tls":
            tls = True
        elif t in ("noverify", "no-verify"):
            verify = False; tls = True
        elif t in ("5250", "tn5250"):
            five = True
        elif t.startswith("profile="):
            profile = t.split("=", 1)[1]
        else:
            raise MacroError(f"connect: unknown option {tok!r}")
    if not tls and port == 992:
        tls = True
    engine.connect(host, port, tls=tls, verify=verify, cipher_profile=profile, tls_5250=five)


def run_script(text: str, engine: Optional[MacroEngine] = None, **engine_kwargs) -> MacroEngine:
    """Execute a macro from a string. Returns the engine (with its transcript)."""
    eng = engine or MacroEngine(**engine_kwargs)
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        verb = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        try:
            if verb == "connect":
                _parse_connect(eng, arg)
            elif verb == "disconnect":
                eng.disconnect()
            elif verb == "string":
                eng.string(arg)
            elif verb == "move":
                r, c = arg.split()
                eng.move(int(r), int(c))
            elif verb == "key":
                eng.key(arg.strip())
            elif verb == "enter":
                eng.enter(arg if arg else None)
            elif verb == "wait":
                eng.wait(float(arg))
            elif verb == "wait_for":
                toks = arg.rsplit(None, 1)
                if len(toks) == 2 and _is_number(toks[1]):
                    eng.wait_for(toks[0], timeout=float(toks[1]))
                else:
                    eng.wait_for(arg)
            elif verb == "expect":
                eng.expect(arg)
            elif verb == "snapshot":
                eng.snapshot(arg)
            elif verb == "save_screen":
                eng.save_screen(arg.strip())
            elif verb == "log":
                eng.log(arg)
            else:
                raise MacroError(f"unknown verb {verb!r}")
        except MacroError:
            raise
        except Exception as e:
            raise MacroError(f"line {lineno}: {verb}: {e}") from e
    return eng


def _is_number(s: str) -> bool:
    try:
        float(s); return True
    except ValueError:
        return False


def run_file(path: str, **engine_kwargs) -> MacroEngine:
    with open(path, "r", encoding="utf-8") as f:
        return run_script(f.read(), **engine_kwargs)
