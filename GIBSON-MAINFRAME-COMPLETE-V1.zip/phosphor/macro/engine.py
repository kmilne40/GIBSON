"""PHOSPHOR macro engine (Tier 2).

Drives a TN3270 session with a small, readable verb set - the same idea as x3270's
scripting, but built on PHOSPHOR's own client. Use it three ways:

  * a text macro file (``python -m phosphor.macro logon.pmac``),
  * a Python script (``from phosphor.macro import MacroEngine``),
  * or record a session and replay it (see recorder.py).

Every step is recorded in a transcript for logging / audit, which matters for an
authorised-testing tool: you get a written record of exactly what the macro did.

Authorised use only: a macro can log in and drive a live mainframe session. Only run
macros against systems you own or are explicitly authorised to test.
"""
from __future__ import annotations

import time
from typing import Callable, List, Optional


class MacroError(Exception):
    pass


class MacroTimeout(MacroError):
    pass


# AID names the engine understands, mapped to client calls.
def _send_key(client, name: str) -> None:
    n = name.strip().upper()
    if n == "ENTER":
        client.send_enter()
    elif n == "CLEAR":
        client.send_clear()
    elif n.startswith("PF"):
        client.send_pf(int(n[2:]))
    elif n.startswith("PA"):
        client.send_pa(int(n[2:]))
    else:
        raise MacroError(f"unknown key {name!r} (use ENTER, CLEAR, PF1-24, PA1-3)")


class MacroEngine:
    """A scriptable driver over a TN3270 client.

    Pass an existing client (any object exposing send_string / send_enter / send_pf /
    send_pa / send_clear / screen_get / find / terminate), or call connect() to open a
    real one. `on_step` is an optional callback(step, detail) for live progress / a
    recorder.
    """

    def __init__(self, client=None, *, on_step: Optional[Callable[[str, str], None]] = None,
                 default_timeout: float = 15.0):
        self.client = client
        self.default_timeout = default_timeout
        self.transcript: List[dict] = []
        self._on_step = on_step

    # -- bookkeeping -------------------------------------------------------
    def _step(self, verb: str, detail: str = "", arg: Optional[str] = None) -> None:
        # `detail` is human/outcome text; `arg` is the replayable macro argument
        # (defaults to detail). The recorder replays from `arg`.
        self.transcript.append({"t": time.time(), "verb": verb, "detail": detail,
                                "arg": detail if arg is None else arg})
        if self._on_step:
            try:
                self._on_step(verb, detail)
            except Exception:
                pass

    def _need_client(self):
        if self.client is None:
            raise MacroError("not connected - call connect() first")
        return self.client

    # -- connection --------------------------------------------------------
    def connect(self, host: str, port: int = 23, *, tls: bool = False, verify: bool = True,
                cipher_profile: str = "modern", tls_5250: bool = False, timeout: float = 20.0):
        """Open a real TN3270 (or TN5250) session."""
        if self.client is None:
            if tls_5250:
                from phosphor.protocols.tn5250.client import TN5250Client as _C
            else:
                from phosphor.protocols.tn3270.client import TN3270Client as _C
            self.client = _C()
        self.client.connect(host, port, tls=tls, tls_verify=verify,
                            cipher_profile=cipher_profile)
        self._step("connect", f"{host}:{port} tls={tls} verify={verify} profile={cipher_profile}")
        return self

    def disconnect(self):
        c = self.client
        if c is not None:
            try:
                c.terminate()
            except Exception:
                pass
        self._step("disconnect")

    # -- pumping host data (for wait_for) ----------------------------------
    def _pump(self) -> None:
        """Best-effort: read any pending host update into the screen buffer."""
        c = self.client
        fn = getattr(c, "_read_until_eor", None)
        if fn is None:
            return
        sock = getattr(c, "sock", None)
        old = None
        try:
            if sock is not None:
                old = sock.gettimeout()
                sock.settimeout(0.3)
            fn()
        except Exception:
            pass
        finally:
            if sock is not None and old is not None:
                try:
                    sock.settimeout(old)
                except Exception:
                    pass

    # -- input verbs -------------------------------------------------------
    def string(self, text: str):
        """Type text at the current cursor position."""
        self._need_client().send_string(text)
        self._step("string", text)
        return self

    def move(self, row: int, col: int):
        """Position the cursor (1-based row/col)."""
        self._need_client().move_to(row, col)
        self._step("move", f"{row},{col}", arg=f"{row} {col}")
        return self

    def key(self, name: str):
        """Send an AID key: ENTER, CLEAR, PF1-24, PA1-3."""
        _send_key(self._need_client(), name)
        self._step("key", name)
        return self

    def enter(self, text: Optional[str] = None):
        """Convenience: optionally type text, then press ENTER."""
        if text is not None:
            self.string(text)
        return self.key("ENTER")

    # -- screen / synchronisation -----------------------------------------
    def screen(self) -> List[str]:
        return self._need_client().screen_get()

    def wait(self, seconds: float):
        """Sleep for a fixed time."""
        time.sleep(seconds)
        self._step("wait", f"{seconds}s")
        return self

    def wait_for(self, text: str, timeout: Optional[float] = None, *, ignore_case: bool = True):
        """Block until `text` appears on the screen, or raise MacroTimeout."""
        c = self._need_client()
        limit = self.default_timeout if timeout is None else timeout
        deadline = time.time() + limit
        needle = text.upper() if ignore_case else text
        while True:
            joined = "\n".join(c.screen_get())
            hay = joined.upper() if ignore_case else joined
            if needle in hay:
                self._step("wait_for", f"{text!r} found", arg=text)
                return self
            if time.time() >= deadline:
                self._step("wait_for", f"{text!r} TIMEOUT after {limit}s", arg=text)
                raise MacroTimeout(f"timed out after {limit}s waiting for {text!r}")
            self._pump()
            time.sleep(0.15)

    def expect(self, text: str, *, ignore_case: bool = True):
        """Assert text is on the current screen right now (no waiting)."""
        joined = "\n".join(self._need_client().screen_get())
        hay = joined.upper() if ignore_case else joined
        needle = text.upper() if ignore_case else text
        if needle not in hay:
            self._step("expect", f"{text!r} NOT FOUND")
            raise MacroError(f"expected {text!r} on screen, not found")
        self._step("expect", f"{text!r} ok")
        return self

    # -- capture -----------------------------------------------------------
    def snapshot(self, label: str = ""):
        """Record the current screen into the transcript."""
        rows = self._need_client().screen_get()
        self.transcript.append({"t": time.time(), "verb": "snapshot",
                                "detail": label, "screen": list(rows)})
        if self._on_step:
            try:
                self._on_step("snapshot", label)
            except Exception:
                pass
        return self

    def save_screen(self, path: str):
        """Write the current screen text to a file."""
        rows = self._need_client().screen_get()
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(rows) + "\n")
        self._step("save_screen", path)
        return self

    def log(self, message: str):
        self._step("log", message)
        return self

    # -- transcript --------------------------------------------------------
    def transcript_text(self) -> str:
        out = []
        for e in self.transcript:
            line = f"{e['verb']:<11} {e.get('detail','')}"
            out.append(line.rstrip())
            if e.get("screen") is not None:
                out.append("    +-- screen " + "-" * 50)
                for r in e["screen"]:
                    out.append("    | " + r)
                out.append("    +" + "-" * 60)
        return "\n".join(out)
