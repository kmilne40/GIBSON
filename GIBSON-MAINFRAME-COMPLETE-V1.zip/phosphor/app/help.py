"""Context-sensitive help for PHOSPHOR.

`help_for(state)` inspects what the user is currently doing - which panel/popup is open,
what field has focus, whether a session is connected - and returns a focused, accurate
help topic (title + body lines) for exactly that context, plus a compact key reference.
The goal is that pressing ? or F1 answers "what do I do *here*", not a generic manual.
"""
from __future__ import annotations
from typing import List, Tuple

# Global key reference appended to every topic.
KEYS = [
    "Keys:  PF1-PF24 keypad (or F1-F12)  ·  Enter / Tab / Esc drive the 3270 screen",
    "       Line edit: <- -> Home End, Ins toggles overwrite, Ctrl+<-/-> by word",
    "       ? (when not typing) or the Help button = this help  ·  Esc closes popups",
]


def _tool_topic(title_lc: str) -> Tuple[str, List[str]]:
    if "hydra" in title_lc:
        return ("Help - Hydra credential attack", [
            "What it is: Hydra is a fast ONLINE password-guessing tool - it tries many",
            "login/password pairs against a live network service until one works.",
            "",
            "Sprays login/password pairs against a network service (telnet / ftp / http).",
            "",
            "The command is prefilled from your Host/Port and the wordlists in your tools",
            "dir (users.txt, passwords.txt). Edit it if needed, then press Run now / Run.",
            "Output streams below; a hit shows as 'login: X password: Y'.",
            "",
            "Notes: hydra has no native TN3270 module - use the nmap tso-enum / cics-user-enum",
            "scans for 3270 logon spraying. hydra must be installed on this machine.",
        ])
    if "john" in title_lc:
        return ("Help - John + hash-format detector", [
            "What it is: John the Ripper is an OFFLINE password cracker - it takes captured",
            "password HASHES and tries candidates until the hash matches (no target contact).",
            "",
            "First it identifies what's in your hash file (md5crypt / RACF DES / KDFAES /",
            "empty-PROTECTED) and suggests the --format. Then it stages the RACF crack chain.",
            "",
            "Run now cracks RACF DES *natively* (no external John) using your passwords.txt -",
            "it folds case and truncates to 8 chars exactly like RACF, so a lowercase list is",
            "fine. Use this if John 'runs forever': that means John fell through to incremental",
            "brute force because the wordlist pass didn't fire (pass --wordlist and --format).",
            "",
            "Empty 0000... hashes are PROTECTED / NOPASSWORD accounts - nothing to crack.",
        ])
    if "passticket" in title_lc:
        return ("Help - PassTicket / credential scan", [
            "What it is: a PassTicket is a one-time, time-bound RACF credential used instead",
            "of a password. This scan spots them (and passwords) in captured logon traffic.",
            "",
            "Scans captured logon traffic (the live tap, or a saved .pcap in your tools dir)",
            "and classifies each credential it finds: passticket / password / phrase.",
            "",
            "A PassTicket is an 8-char, single-use, time-bound RACF credential. Spotting one in",
            "a capture tells you the app uses PassTickets rather than static passwords - and if",
            "a replayed PassTicket is still accepted, that's a finding.",
            "",
            "Tip: turn on Capture PCAP, log in, then run this to scan the saved capture.",
        ])
    if "cicspwn" in title_lc:
        return ("Help - CICSpwn", [
            "What it is: CICSpwn is a CICS Transaction Server attack tool - it enumerates and",
            "abuses CICS resources (transactions, files, TS queues, JCL submit) over 3270.",
            "",
            "Drives CICSpwn through PHOSPHOR's emulator (no x3270 needed). Pick a mode via",
            "--action: info / all / userids / trans / files / tsqueues / bypass, or a shell",
            "(dummy / reverse_tso / reverse_unix / direct_unix / ftp).",
            "",
            "Reverse shells need --lhost H:P - catch them with the Shell listener button.",
            "Targeted ops (--get-file FILE) are added by editing the staged command.",
            "Point PHOSPHOR at your tool with PHOSPHOR_CICSPWN=... or drop cicspwn.py in tools.",
        ])
    if "api" in title_lc or "curl" in title_lc:
        return ("Help - API / curl", [
            "What it is: curl is a command-line HTTP client. Here it probes the mainframe's",
            "REST endpoints (z/OSMF, z/OS Connect, CICS web services).",
            "",
            "Probe the host's REST APIs: z/OSMF (:443 - jobs, datasets, console), z/OS Connect",
            "EE, and CICS web services. The staged curl uses Basic auth (-u USER:PASS), -k for",
            "the self-signed certs mainframes use, and the X-CSRF-ZOSMF-HEADER z/OSMF needs.",
            "",
            "Edit the path/method/creds and Run. The listed endpoints are good first probes;",
            "watch for anonymous info leaks, weak auth, and verbose errors.",
        ])
    if "sql" in title_lc or "db2" in title_lc:
        return ("Help - SQL / DB2", [
            "What it is: DB2 for z/OS is IBM's mainframe database; it speaks SQL over DRDA",
            "(DDF, usually port 446). This console connects and runs SQL against it.",
            "",
            "Talk to DB2 for z/OS over DRDA (DDF, usually :446). The staged command uses the",
            "ibm_db Python driver to connect and run one statement; a db2 CLP line is also shown.",
            "",
            "Edit LOCATION / UID / PWD / the SQL and Run. The sample queries enumerate your",
            "SQLID, schemas, tables and authorities - useful for privilege review and for",
            "confirming SQL-injection reach from a CICS/web front end.",
        ])
    if any(k in title_lc for k in ("nmap","scan","recon","vtam","tso","cics","ftp","db2","applid","enum")):
        return ("Help - recon / nmap", [
            "What it is: nmap is the network scanner; with the mainframe NSE scripts it",
            "enumerates TSO/CICS/VTAM/DB2. These buttons run those scans against your host.",
            "",
            "Runs the mainframe NSE scans (tso-enum, cics-enum, vtam-enum, ...) against your",
            "Host/Port. Edit the command and Run; results stream below and feed the report.",
            "userdb/passdb point at the wordlists in your tools dir.",
        ])
    if "shell" in title_lc:
        return ("Help - Shell listener", [
            "Opens a local listener to catch a reverse shell (e.g. from a CICSpwn submit).",
            "Once a shell connects, type commands here and they're sent to the target.",
        ])
    return ("Help - tool console", [
        "Edit the command and press Run now / Run. Output streams below.",
        "The command line is fully editable (arrows, Home/End, insert/overwrite).",
    ])


def help_for(state) -> Tuple[str, List[str]]:
    """Return (title, body_lines) for the current context."""
    s = state
    # 1) an open tool console is the most specific context
    if getattr(s, "console_open", False):
        title, body = _tool_topic((getattr(s, "console_title", "") or "").lower())
        return title, body + [""] + KEYS
    if getattr(s, "cicspwn_open", False):
        return _tool_topic("cicspwn")[0], _tool_topic("cicspwn")[1] + [""] + KEYS
    if getattr(s, "hack3270_open", False):
        return ("Help - STRIP3270", [
            "Manipulate the CICS 3270 data stream to test client-side controls.",
            "",
            "Auto-proxy on connect - route the session through hack3270 as a MITM proxy",
            "  (needs the hack3270 binary; set PHOSPHOR_HACK3270_CMD for the launch line).",
            "Unprotect fields (inline) - clear the protected bit so 'read-only' fields accept",
            "  input, in-process (no binary needed).",
            "Reveal hidden fields (inline) - unmask non-display fields such as password/MFA",
            "  inputs, in-process. (With this OFF, PHOSPHOR masks those fields for you.)",
            "",
            "Inline toggles apply live; auto-proxy takes effect on the next Connect.",
        ] + [""] + KEYS)
    if getattr(s, "settings_open", False):
        return ("Help - Settings", [
            "Screen colour / font / codepage for the terminal.",
            "",
            "STRIP3270 (CICS app testing):",
            "  Auto-proxy on connect - launch hack3270 as a MITM proxy automatically.",
            "  Unprotect fields (inline) - clear the protected bit so 'read-only' fields accept",
            "  input, in-process (no external proxy).",
            "  Reveal hidden fields (inline) - unmask non-display fields (e.g. password inputs).",
            "  These test client-side field controls; toggles apply to the live session.",
        ] + [""] + KEYS)
    if getattr(s, "notes_open", False):
        return ("Help - Notepad / wordlists", [
            "Free-text notes auto-save. To build a wordlist for scans/cracking, type a filename",
            "(e.g. users.txt) and press 'Save to tools' - scans and John then pick it up.",
            "Click a file under 'tools:' to load and edit it. One entry per line.",
        ] + [""] + KEYS)
    if getattr(s, "tasks_open", False):
        return ("Help - Tasks", [
            "A simple engagement checklist. Type a task and Add; click a task to toggle done.",
        ] + [""] + KEYS)
    if getattr(s, "ftp_open", False):
        return ("Help - FTP / JCL submit", [
            "Connect to the host's FTP service to browse datasets or submit JCL (the classic",
            "z/OS foothold). Fill host / user / pass and connect; anonymous is worth trying.",
        ] + [""] + KEYS)
    # 2) focus-specific help on the main screen
    focus = getattr(s, "focus", None)
    if focus == "screen" and getattr(s, "connected", False):
        return ("Help - the 3270 screen", [
            "You're typing on the live mainframe screen. Type into unprotected fields; Tab jumps",
            "field to field; Enter sends the screen (AID); Esc clears; PF1-PF24 send function",
            "keys. Watch the packet monitor below to see the EBCDIC/ASCII datastream.",
        ] + [""] + KEYS)
    if focus in ("cmd", "console_cmd"):
        return ("Help - command line", [
            "Type a command and Enter/Run. Full line editing: arrows, Home/End, Insert toggles",
            "overwrite, Ctrl+arrows move by word. This is where staged tool commands land.",
        ] + [""] + KEYS)
    # 3) connection state
    if not getattr(s, "connected", False):
        return ("Help - getting started", [
            "1. Enter a Host and Port (TN3270 is usually 23) and press Connect.",
            "2. Pick a codepage (cp037 EBCDIC is the common default).",
            "3. Once connected, type on the screen; use the keypad for PF keys.",
            "",
            "TOOLS (left): recon scans, and credential/crack/shell -",
            "  Hydra, John (+ hash detector), PassTicket scan, CICSpwn, Shell listener.",
            "The dots show which external tools are installed (green) vs missing (red).",
            "Capture PCAP records the session for later PassTicket/credential analysis.",
        ] + [""] + KEYS)
    return ("Help - PHOSPHOR", [
        "Connected. Type on the screen, drive it with Enter/Tab/PF keys, and watch the packet",
        "monitor. Use the TOOLS panel for recon and credential/crack work, and Capture PCAP to",
        "record traffic. Press ? on any panel for help specific to it.",
    ] + [""] + KEYS)
