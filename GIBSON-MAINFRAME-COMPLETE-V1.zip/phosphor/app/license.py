"""Offline license verification for Phosphor Skins.

Design (see also vendor/license_issuer.py):

  * The vendor holds an Ed25519 *private* key (never shipped).  This client ships
    only the matching *public* key below, so reverse-engineering the app cannot
    forge a license - you'd need the private key to sign one, and that never
    leaves the vendor's offline signing machine.  This is stronger than
    obfuscation/encryption: the signature is tamper-proof maths, not a hidden
    secret that can be extracted from the binary.
  * A license is a signed token that embeds the buyer's email, the skins they
    bought, and an expiry.  The token is emailed to the buyer at purchase time
    (delivery to their inbox is what ties the license to that email address).
  * To activate, the user enters their email + pastes the token.  We verify the
    Ed25519 signature with the public key, check the embedded email matches, and
    check expiry.  Valid -> the listed skins unlock.  The activation is cached in
    ~/.config/phosphor/license.json and re-verified every launch.

Requires the `cryptography` package for verification.  If it isn't installed the
app still runs - only the free skins are available - and the popup says so.
"""
from __future__ import annotations

import base64
import json
import os
import time
from pathlib import Path
from typing import Optional, Tuple

# Vendor's Ed25519 public key (raw, base64).  Safe to ship - it can only *verify*.
PUBLIC_KEY_B64 = "tyjF4QRCVRex3oryhUQpD+9YQCsY+qHwQM4Swiv0kVU="

# Master unlock code (a shared password you can hand to friends).  Only the scrypt
# HASH of the password lives here - never the password itself - so nobody can read
# the code out of the source or the binary.  Entering the right password re-derives
# this same hash and unlocks every skin.
MASTER_SALT_B64 = "J58OrhWfuLfyg0LMAg/aSQ=="
MASTER_KEY_B64 = "w445agARpNpDiU++938BBAnz2dTJZUVLdRpwuGP4mf8="
# Tools unlock code (gates the pen-test tools).  Same scheme: only the scrypt hash
# is stored, never the password.  Default password: "TN3270tools!".
TOOLS_SALT_B64 = "DWctEZi9RddPrkTt0uidgA=="
TOOLS_KEY_B64 = "c+ULwy71JI0Zg6BTYpy+uXDWuHDdrJ920aKwO7c8vYY="
_SCRYPT = dict(n=2 ** 14, r=8, p=1, dklen=32, maxmem=64 * 1024 * 1024)

FREE_SKINS = {"classic", "green", "lcars", "pink", "bbc", "z17"}


def _scrypt_match(password: str, salt_b64: str, key_b64: str) -> bool:
    import hashlib
    import hmac
    if not password:
        return False
    try:
        key = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt_b64), **_SCRYPT)
        return hmac.compare_digest(key, base64.b64decode(key_b64))
    except Exception:
        return False


def check_tools(password: str) -> bool:
    """True if `password` matches the pen-test tools unlock code."""
    return _scrypt_match(password, TOOLS_SALT_B64, TOOLS_KEY_B64)


def tools_unlocked() -> bool:
    """Whether the tools are unlocked (a saved, re-verified unlock code)."""
    try:
        data = json.loads(_license_path().read_text())
        return _scrypt_match(data.get("tools", ""), TOOLS_SALT_B64, TOOLS_KEY_B64)
    except Exception:
        return False


def unlock_tools(password: str) -> bool:
    """Verify + persist the tools unlock code."""
    if not check_tools(password):
        return False
    try:
        data = {}
        try:
            data = json.loads(_license_path().read_text())
        except Exception:
            pass
        data["tools"] = password
        _license_path().write_text(json.dumps(data, indent=2))
    except Exception:
        pass
    return True


def check_master(password: str) -> bool:
    """True if `password` matches the master unlock code (constant-time)."""
    import hashlib
    import hmac
    if not password:
        return False
    try:
        key = hashlib.scrypt(password.encode(), salt=base64.b64decode(MASTER_SALT_B64), **_SCRYPT)
        return hmac.compare_digest(key, base64.b64decode(MASTER_KEY_B64))
    except Exception:
        return False


def _all_skins() -> set:
    from phosphor.app.themes import THEMES
    return set(THEMES.keys())


def _dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    p = Path(base) / "phosphor"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _license_path() -> Path:
    return _dir() / "license.json"


def crypto_available() -> bool:
    try:
        import cryptography  # noqa: F401
        return True
    except Exception:
        return False


def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def verify_token(token: str, email: str) -> Tuple[bool, str, Optional[dict]]:
    """Verify a license token for `email`.  Returns (ok, message, payload)."""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
    except Exception:
        return False, "install the 'cryptography' package to activate a license", None

    token = (token or "").strip().replace("\n", "").replace(" ", "")
    if token.lower().startswith("phos-"):
        token = token[5:]
    if "." not in token:
        return False, "not a valid license token", None
    payload_b64, sig_b64 = token.split(".", 1)
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
        pub.verify(_b64u_decode(sig_b64), payload_b64.encode())     # signs the b64 payload string
    except InvalidSignature:
        return False, "license signature invalid (not issued by us)", None
    except Exception as e:
        return False, f"verification error: {e}", None

    try:
        payload = json.loads(_b64u_decode(payload_b64))
    except Exception:
        return False, "license payload unreadable", None

    if (payload.get("email", "").strip().lower() != (email or "").strip().lower()):
        return False, "this license is registered to a different email", None
    exp = payload.get("exp")
    if exp and time.time() > float(exp):
        return False, "license has expired", None
    return True, "license valid", payload


def activate(email: str, token: str) -> Tuple[bool, str, set]:
    """Verify + persist a license.  Accepts either a signed licence token or the
    master unlock code.  Returns (ok, message, unlocked_skins)."""
    token = (token or "").strip()
    # master unlock code path (a shared password) - unlocks everything
    if check_master(token):
        try:
            data = {}
            try:
                data = json.loads(_license_path().read_text())
            except Exception:
                pass
            data["unlock"] = token
            if email.strip():
                data.setdefault("email", email.strip())
            _license_path().write_text(json.dumps(data, indent=2))
        except Exception:
            pass
        return True, "activated: master unlock - all skins", set(FREE_SKINS) | _all_skins()
    # signed licence path
    ok, msg, payload = verify_token(token, email)
    if not ok:
        return False, msg, set(FREE_SKINS)
    _license_path().write_text(json.dumps({"email": email.strip(), "token": token}, indent=2))
    skins = set(FREE_SKINS) | set(payload.get("skins", []))
    return True, "activated: " + ", ".join(sorted(set(payload.get("skins", [])))), skins


def deactivate() -> None:
    try:
        _license_path().unlink()
    except Exception:
        pass


def entitlements() -> set:
    """Skins the user may use: the free set plus anything a valid saved license
    grants, plus everything if the saved master unlock code re-verifies.  The
    signature and the master password are BOTH re-checked here every call, so a
    hand-edited license.json grants nothing without the real secret."""
    unlocked = set(FREE_SKINS)
    try:
        data = json.loads(_license_path().read_text())
        if check_master(data.get("unlock", "")):        # master password path
            unlocked |= _all_skins()
        ok, _msg, payload = verify_token(data.get("token", ""), data.get("email", ""))
        if ok and payload:                              # signed-licence path
            unlocked |= set(payload.get("skins", []))
    except Exception:
        pass
    if os.environ.get("PHOSPHOR_UNLOCK_ALL") == "1":
        unlocked |= _all_skins()
    return unlocked


def saved_email() -> str:
    try:
        return json.loads(_license_path().read_text()).get("email", "")
    except Exception:
        return ""
