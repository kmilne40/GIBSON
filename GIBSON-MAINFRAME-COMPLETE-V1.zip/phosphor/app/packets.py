"""Format captured TN3270 bytes for the live packet monitor."""
from __future__ import annotations

from typing import List, Tuple


def _ebcdic(data: bytes) -> str:
    try:
        s = data.decode("cp037")
    except Exception:
        s = ""
    return "".join(c if 32 <= ord(c) < 127 else "." for c in s)


def _ascii(data: bytes) -> str:
    return "".join(chr(b) if 32 <= b < 127 else "." for b in data)


def format_packets(packets: List[Tuple[str, bytes]], width: int = 20,
                   max_lines: int = 6) -> List[Tuple[str, str]]:
    """Return [(direction, text)] for the most recent packets."""
    out = []
    for direction, data in packets[-max_lines:]:
        chunk = data[:width]
        arrow = "OUT \u25b6" if direction == ">" else "IN  \u25c0"
        hexs = chunk.hex(" ")
        line = f"{arrow} {len(data):>4}b  {hexs:<{width*3}}  E|{_ebcdic(chunk):<{width}}  A|{_ascii(chunk)}"
        out.append((direction, line))
    return out
