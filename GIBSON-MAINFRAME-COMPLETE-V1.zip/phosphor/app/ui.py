"""Integrated app UI - composed as one image with hit-testing (pygame-free)."""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from typing import Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from phosphor.crt import text_pass
from phosphor.crt.config import EffectConfig
from phosphor.app.crt_render import SoftCRT

BG, PANEL, PANEL_HI = (8, 12, 10), (14, 22, 16), (22, 34, 24)
LINE, FG, DIM = (34, 54, 38), (150, 230, 165), (95, 145, 105)
ACCENT, AMBER, WARN = (60, 230, 120), (255, 176, 0), (255, 90, 90)
CONSOLE_TEXT = (140, 225, 255)   # bright cyan - high-contrast, distinct from the green screen
SEVCOL = {"high": (255, 90, 90), "medium": (255, 176, 0), "low": (240, 215, 90), "info": (110, 180, 255)}

# --- IBM Model M palette (the beige workstation the dark 3270 monitor sits in) --
# Warm-neutral greige case, two-tone sculpted keycaps, dark charcoal legends.
CASE      = (201, 197, 188)      # main case / desk background
CASE_HI   = (223, 220, 212)      # top highlight / raised edge
CASE_LO   = (150, 147, 139)      # shadow / recess
PLATE     = (210, 207, 199)      # raised section plate
KEY_FACE  = (198, 195, 187)      # keycap face (pearl grey)
KEY_HI    = (226, 223, 216)      # keycap top bevel highlight
KEY_LO    = (150, 148, 141)      # keycap bottom/right shadow
KEY_DARK  = (128, 126, 120)      # darker/modifier keycap face
LEGEND    = (52, 50, 46)         # dark charcoal legend text
LEGEND_DIM = (104, 101, 95)      # secondary legend text
NAMEPLATE = (182, 179, 171)      # recessed input nameplate
IBM_BLUE  = (36, 74, 140)        # active / selected accent
IBM_RED   = (170, 44, 46)        # power / warn / logo
SCREEN_BG = (10, 14, 11)         # dark inset readouts (OUTPUT / PACKETS)
SCREEN_FIELD = (0, 0, 0)         # terminal glass background (themeable)
SCREEN_PALETTE = None            # optional per-skin text palette (colour_name -> rgb)
KEY_PF = None                    # optional PF/keypad keycap colour (e.g. BBC red)
KEY_OUTLINE = None               # optional thin surround on PF/AID keycaps (e.g. HVCK black)
KEY_PF_FG = None                 # optional PF/keypad legend colour (e.g. BBC black)
HEADER_FG = None                 # wordmark colour override
WORDMARK = None                  # wordmark text override (defaults to "PHOSPHOR")
SKIN_LOGO = None                 # optional brand logo asset (filename in app/assets)
FIELD_FG = None                  # input-field text colour override
_CURRENT_THEME = "classic"

WIN_W, WIN_H = 1500, 900
BUILD = "build 9 (2026-07-07)"
SIDEBAR_W = 212                  # single-column beige panel
KEYPAD_W = 150                   # tighter keypad
KP_X = WIN_W - KEYPAD_W - 8
TERM_X = SIDEBAR_W + 12
TERM_W = KP_X - 12 - TERM_X
TERM_Y = 12
TERM_H = 742

CODEPAGES = ["cp037 (EBCDIC)", "cp500 (EBCDIC)", "cp1140 (EBCDIC)", "cp285 (EBCDIC)"]
FONTS = ["3270", "DejaVu Mono", "Liberation Mono"]

# --- IBM 3270 bezel -----------------------------------------------------------
# The photoreal bezel is drawn around the live screen; the terminal text renders
# into the recessed glass.  These fractions are the glass rectangle measured from
# the source image, so they hold whatever size the bezel is scaled to.
_BEZEL_PATH = __import__("os").path.join(__import__("os").path.dirname(__file__),
                                         "assets", "ntl3270_bezel.png")
_BEZEL_ASPECT = 1619 / 1080
_GLASS_FRAC = (0.0700, 0.1110, 0.8190, 0.8660)   # (left, top, right, bottom)
_POWER_FRAC = (0.9150, 0.5500, 0.9530, 0.5980)   # dark square below 3270/5250 = quit

# The live glass rectangle in window pixels, updated every frame so click->cell
# mapping and the "screen" hit-box track the bezel (or the plain viewport).
GLASS_RECT = (TERM_X, TERM_Y, TERM_W, TERM_H)


@lru_cache(maxsize=8)
def _bezel_image(w, h):
    """Bezel scaled to (w,h), cached so we don't rescale a big PNG every frame."""
    try:
        return Image.open(_BEZEL_PATH).convert("RGBA").resize((w, h), Image.LANCZOS)
    except Exception:
        return None


@lru_cache(maxsize=1)
def _engines_available():
    try:
        from phosphor.session import available_engines
        return available_engines()
    except Exception:
        return {"native": True, "tnz": False}


def flat_cfg(mode: str) -> EffectConfig:
    return EffectConfig(mode=mode, bloom=0, bloom_radius=0, burn_in=0, ambient=0,
                        scanlines=0, aperture=0, curvature=0, bevel=0, vignette=0,
                        rgb_shift=0, glow_line=0, flicker=0, jitter=0, hsync=0,
                        noise=0, brightness=1.0, contrast=1.0)


@lru_cache(maxsize=128)
def _font(sz, mono=False):
    if mono:
        return text_pass.load_font(sz)
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(p, sz)
        except Exception:
            pass
    return ImageFont.load_default()


@dataclass
class AppState:
    host: str = ""
    port: str = "23"
    codepage: str = "cp037 (EBCDIC)"
    protocol: str = "3270"          # "3270" (TN3270) or "5250" (TN5250 / IBM i)
    engine: str = "native"          # "native" (built-in) or "tnz" (IBM tnz, 3270 only)
    colour: str = "green"
    font_px: int = 20
    connected: bool = False
    status: str = "not connected"
    _grid: Optional[list] = None
    grid_gen: int = 0               # bumped on every grid change (cheap change-detect)
    findings: int = 0
    results: List = field(default_factory=list)
    favourites: List[Dict] = field(default_factory=list)
    log: List[str] = field(default_factory=list)
    focus: Optional[str] = None
    cmdline: str = ""
    settings_open: bool = False
    console_open: bool = False
    console_lines: List[str] = field(default_factory=list)
    console_title: str = "OUTPUT"
    console_mode: str = ""          # "api" / "sql" -> show editable Host/Port fields
    tool_host: str = ""
    tool_port: str = ""
    console_scroll: int = 0         # lines scrolled up from the bottom (F7/F8 / wheel)
    help_scroll: int = 0            # scroll offset for the Help popup
    themes_scroll: int = 0          # scroll offset (rows) for the Skins picker
    notes_scroll: int = 0           # scroll offset for the Notes popup
    cursor_blink: bool = True        # blink the terminal cursor so its position is visible
    crosshair: bool = False          # full row/column crosshair through the cursor
    monocase: bool = False
    typeahead: bool = True
    cursor_rc: tuple = (1, 1)        # (row, col) 1-based of the terminal cursor
    console_cmd: str = ""
    trace_on: bool = False
    capture_on: bool = False        # PCAP capture toggle
    capture_path: str = ""
    h3_proxy: bool = False          # auto-launch hack3270 as a proxy on connect
    h3_unprotect: bool = False      # native: clear the protected bit on fields
    h3_unhide: bool = False         # native: reveal hidden (password) fields
    tls: bool = False               # implicit TLS tunnel (AT-TLS / telnets)
    tls_verify: bool = True         # verify the host certificate (off = testing only)
    tls_starttls: bool = False      # negotiated TELNET START-TLS (RFC 2946) upgrade
    tls_accept_hostname: str = ""   # name to match the cert against (x3270 =name)
    term_model: str = "2"           # 3270 model 2/3/4/5 (24x80 / 32x80 / 43x80 / 27x132)
    packets: list = field(default_factory=list)
    about_open: bool = False
    help_open: bool = False
    confirm_open: bool = False
    confirm_text: str = ""
    about_text: str = ""
    notes_open: bool = False
    notes_text: str = ""
    notes_name: str = ""           # filename to save into the tools directory
    tools_files: list = field(default_factory=list)   # .txt files in the tools dir
    tasks_open: bool = False
    tasks: list = field(default_factory=list)
    task_input: str = ""
    field_cursor: dict = field(default_factory=dict)   # per-field caret position
    insert_mode: bool = True                            # insert vs overwrite
    ctrl_down: bool = False
    shift_down: bool = False
    quit: bool = False              # set by the shutdown button
    tool_status: dict = field(default_factory=dict)   # {tool: {installed, hint}}
    cicspwn_open: bool = False
    hack3270_open: bool = False
    h3_inject_idx: int = 0          # index into injection types
    h3_mask: str = "*"              # mask char marking the target field
    cicspwn_action: str = "info"
    shell_on: bool = False          # reverse-shell listener active
    ftp_open: bool = False
    ftp_host: str = ""
    ftp_user: str = "IBMUSER"
    ftp_pass: str = ""
    ftp_list: list = field(default_factory=list)
    ftp_dsn: str = ""              # editable dataset / HLQ to list or download
    ftp_status: str = "not connected"
    ftp_focus: str = ""
    ftp_mode: str = "binary"        # FTP transfer type: "binary" (TYPE I) or "ascii" (TYPE A)
    xfer_mode: str = "ascii"        # IND$FILE (Upload/Download) type: "ascii" or "binary"
    bezel: bool = True             # draw the IBM 3270 bezel around the screen
    theme: str = "classic"         # active Phosphor Skin
    themes_open: bool = False       # theme picker popup
    focus_mode: bool = False        # detached full-screen terminal (no chrome)
    license_open: bool = False       # activation popup
    license_email: str = ""
    license_token: str = ""
    license_status: str = ""
    tools_unlocked: bool = False     # pen-test tools gated behind the unlock code
    tools_popup: bool = False
    tools_pw: str = ""
    tools_status: str = ""
    unlocked: set = field(default_factory=lambda: {"classic", "green", "lcars", "pink", "bbc", "z17"})

    @property
    def cfg(self):
        return flat_cfg(self.colour)

    @property
    def grid(self):
        return self._grid

    @grid.setter
    def grid(self, value):
        # Any screen change bumps a counter, so the render loop can detect a
        # change in O(1) instead of hashing all 1920 cells every iteration.
        self._grid = value
        self.grid_gen += 1

    def note(self, msg: str):
        self.log.append(msg); self.log = self.log[-3:]


TOOLS = [("scan_all", "Scan all"), ("vtam", "VTAM applids"), ("tso", "TSO users"),
         ("cics", "CICS trans"), ("cics_users", "CICS users"), ("cics_info", "CICS info"),
         ("ftp", "FTP anon"), ("db2", "DB2 DRDA")]

KEYPAD = [
    (50, [("pf1", "PF1"), ("pf2", "PF2"), ("pf3", "PF3")]),
    (50, [("pf4", "PF4"), ("pf5", "PF5"), ("pf6", "PF6")]),
    (50, [("pf7", "PF7"), ("pf8", "PF8"), ("pf9", "PF9")]),
    (50, [("pf10", "PF10"), ("pf11", "PF11"), ("pf12", "PF12")]),
    (50, [("pf13", "PF13"), ("pf14", "PF14"), ("pf15", "PF15")]),
    (50, [("pf16", "PF16"), ("pf17", "PF17"), ("pf18", "PF18")]),
    (50, [("pf19", "PF19"), ("pf20", "PF20"), ("pf21", "PF21")]),
    (50, [("pf22", "PF22"), ("pf23", "PF23"), ("pf24", "PF24")]),
    (34, [("pa1", "PA1"), ("pa2", "PA2"), ("pa3", "PA3")]),
    (34, [("enter", "Enter"), ("clear", "Clear")]),
    (34, [("reset", "Reset"), ("attn", "Attn")]),
    (34, [("eeof", "Erase EOF"), ("einp", "Erase Inp")]),
    (34, [("tab", "Tab"), ("newline", "New Line")]),
    (34, [("up", "\u2191")]),
    (34, [("left", "\u2190"), ("down", "\u2193"), ("right", "\u2192")]),
]

KEY_HELP = {
    "k_pf1": "PF1 - Help", "k_pf2": "PF2 - Split screen",
    "k_pf3": "PF3 - Exit / End  (go back, saving)", "k_pf4": "PF4 - Return to primary menu",
    "k_pf5": "PF5 - Repeat find (RFIND)", "k_pf6": "PF6 - Repeat change (RCHANGE)",
    "k_pf7": "PF7 - Scroll up / backward", "k_pf8": "PF8 - Scroll down / forward",
    "k_pf9": "PF9 - Swap window", "k_pf10": "PF10 - Scroll left",
    "k_pf11": "PF11 - Scroll right", "k_pf12": "PF12 - Retrieve / Cancel",
    "k_pf13": "PF13 - Help (alternate)", "k_pf14": "PF14 - Split (alternate)",
    "k_pf15": "PF15 - Exit (alternate)",
    "k_pf16": "PF16 - Application-defined", "k_pf17": "PF17 - Application-defined",
    "k_pf18": "PF18 - Application-defined", "k_pf19": "PF19 - Scroll up (alt)",
    "k_pf20": "PF20 - Scroll down (alt)", "k_pf21": "PF21 - Application-defined",
    "k_pf22": "PF22 - Application-defined", "k_pf23": "PF23 - Application-defined",
    "k_pf24": "PF24 - Application-defined / Cancel",
    "k_pa1": "PA1 - Attention (interrupt the host)", "k_pa2": "PA2 - Reshow the screen",
    "k_pa3": "PA3 - Program Attention 3",
    "k_enter": "Enter - Send the screen to the host",
    "k_clear": "Clear - Clear the screen", "k_reset": "Reset - Unlock the keyboard after inhibit",
    "k_eeof": "Erase EOF - Erase from cursor to end of field",
    "k_einp": "Erase Input - Clear all input fields",
    "k_attn": "Attn - Attention (interrupt the host)",
    "k_tab": "Tab - Jump to the next input field",
    "k_up": "Up - Move cursor up", "k_down": "Down - Move cursor down",
    "k_left": "Left - Move cursor left", "k_right": "Right - Move cursor right",
    "k_newline": "Newline - New line",
    "b_power": "POWER - shut down PHOSPHOR",
}


_PRESSED = None    # wid currently held down (for the pressed look)
_HOVER = None      # wid currently hovered (for the hover look)


def _key3d(d, hm, wid, box, label, accent=False):
    """A sculpted Model M keycap for the PF keypad."""
    pressed = (wid == _PRESSED)
    hovered = (wid == _HOVER) and not pressed
    if accent:
        face, hi, lo, txt = (176, 190, 214), (214, 224, 240), (96, 116, 150), IBM_BLUE
    elif KEY_PF is not None:
        r0, g0, b0 = KEY_PF
        face = KEY_PF
        hi = (min(255, r0 + 40), min(255, g0 + 40), min(255, b0 + 40))
        lo = (max(0, r0 - 60), max(0, g0 - 60), max(0, b0 - 60))
        lum = 0.299 * r0 + 0.587 * g0 + 0.114 * b0
        txt = KEY_PF_FG if KEY_PF_FG is not None else ((20, 16, 12) if lum > 150 else (250, 245, 240))
    else:
        face, hi, lo, txt = KEY_FACE, KEY_HI, KEY_LO, LEGEND
    _keycap(d, box, face, hi, lo, r=6, pressed=pressed, hovered=hovered, outline=KEY_OUTLINE)
    x0, y0, x1, y1 = box
    f = _font(11)
    tw = d.textlength(label, font=f)
    d.text((x0 + (x1 - x0 - tw) / 2, y0 + (y1 - y0 - 13) / 2 - 1 + (1 if pressed else 0)),
           label, font=f, fill=txt)
    hm.add(wid, box)


def _tooltip(d, text, near):
    f = _font(12)
    tw = d.textlength(text, font=f)
    w, h = tw + 20, 26
    x1 = near[0] - 8
    x0 = max(4, x1 - w)
    y0 = min(near[1], WIN_H - h - 4)
    d.rounded_rectangle((x0, y0, x0 + w, y0 + h), radius=5, fill=(18, 26, 20), outline=ACCENT, width=1)
    d.text((x0 + 10, y0 + 6), text, font=f, fill=FG)


class Hitmap:
    def __init__(self):
        self.rects: List[Tuple[str, Tuple[int, int, int, int]]] = []

    def add(self, wid, box):
        self.rects.append((wid, box))

    def hit(self, x, y):
        for wid, (x0, y0, x1, y1) in reversed(self.rects):
            if x0 <= x <= x1 and y0 <= y <= y1:
                return wid
        return None


def _panel(d, box, title=None, screen=False):
    """A raised beige case plate (Model M).  screen=True draws a dark inset
    readout window (for OUTPUT / PACKETS) so their coloured text stays legible."""
    x0, y0, x1, y1 = box
    if screen:
        d.rounded_rectangle(box, radius=8, fill=CASE_LO, outline=CASE_HI, width=1)
        d.rounded_rectangle((x0 + 2, y0 + 2, x1 - 2, y1 - 2), radius=7, fill=SCREEN_BG,
                            outline=(30, 46, 34), width=1)
        if title:
            d.text((x0 + 12, y0 + 8), title, font=_font(11), fill=DIM)
        return
    # raised plate: soft bottom/right shadow, top/left highlight, charcoal title
    d.rounded_rectangle((x0 + 1, y0 + 2, x1 + 1, y1 + 2), radius=8, fill=CASE_LO)   # drop shadow
    d.rounded_rectangle(box, radius=8, fill=PLATE, outline=CASE_LO, width=1)
    d.line((x0 + 8, y0 + 1, x1 - 8, y0 + 1), fill=CASE_HI)
    if title:
        d.text((x0 + 12, y0 + 8), title, font=_font(11), fill=LEGEND_DIM)


def _btn_scheme(active, colour):
    """(face, hi, lo, text) for a sculpted Model M keycap by variant."""
    if active:
        return (176, 190, 214), (214, 224, 240), (96, 116, 150), IBM_BLUE
    if colour == WARN:
        return (196, 168, 164), (226, 206, 202), (150, 118, 114), IBM_RED
    if colour == AMBER:
        return (206, 198, 176), (230, 224, 206), (156, 146, 120), (120, 92, 24)
    if colour == ACCENT:
        return (186, 200, 190), (220, 230, 222), (140, 156, 144), (30, 96, 60)
    if colour == IBM_RED:
        return (196, 168, 164), (226, 206, 202), (150, 118, 114), IBM_RED
    return (KEY_FACE, KEY_HI, KEY_LO, LEGEND)


def _keycap(d, box, face, hi, lo, r=5, pressed=False, hovered=False, outline=None):
    """Paint a sculpted keycap: dished face with a top-light bevel and a
    bottom/right shadow, the way an injection-moulded Model M cap catches light."""
    x0, y0, x1, y1 = box
    if hovered and not pressed:
        face = tuple(min(255, int(c * 1.05) + 4) for c in face)
    if pressed:
        face = tuple(int(c * 0.90) for c in face)
        lo, hi = hi, lo
    # seat shadow under the cap
    d.rounded_rectangle((x0, y0 + 2, x1, y1 + 2), radius=r, fill=lo)
    # cap body
    d.rounded_rectangle((x0, y0, x1, y1 - 1), radius=r, fill=face, outline=lo, width=1)
    # top bevel highlight + left edge
    d.line((x0 + r, y0 + 1, x1 - r, y0 + 1), fill=hi)
    d.line((x0 + 1, y0 + r, x0 + 1, y1 - r - 1), fill=hi)
    if outline is not None:                        # thin surround (e.g. HVCK black keys)
        d.rounded_rectangle((x0, y0, x1, y1 - 1), radius=r, outline=outline, width=1)


def _button(d, hm, wid, box, label, active=False, colour=None, small=False):
    x0, y0, x1, y1 = box
    face, hi, lo, txt = _btn_scheme(active, colour)
    pressed = (wid == _PRESSED)
    hovered = (wid == _HOVER) and not pressed
    _keycap(d, box, face, hi, lo, r=5, pressed=pressed, hovered=hovered)
    f = _font(11 if small else 12)
    tw = d.textlength(label, font=f)
    ty = y0 + (y1 - y0 - (12 if small else 13)) / 2 - 1 + (1 if pressed else 0)
    d.text((x0 + (x1 - x0 - tw) / 2, ty), label, font=f, fill=txt)
    hm.add(wid, box)


def _text_caret(d, xy, text, cursor, font, fill, prefix="", h=15):
    """Draw mono text with a caret bar at the cursor position (None = no caret)."""
    d.text(xy, prefix + text, font=font, fill=fill)
    if cursor is not None:
        cx = xy[0] + d.textlength(prefix + text[:cursor], font=font)
        d.rectangle([cx, xy[1] - 1, cx + 1, xy[1] + h], fill=fill)


def _field(d, hm, wid, box, value, label, focus=False, cursor=None):
    x0, y0, x1, y1 = box
    d.text((x0, y0 - 14), label, font=_font(10), fill=LEGEND_DIM)
    d.rounded_rectangle(box, radius=4, fill=NAMEPLATE,
                        outline=(IBM_BLUE if focus else CASE_LO), width=(2 if focus else 1))
    d.line((x0 + 4, y0 + 1, x1 - 4, y0 + 1), fill=CASE_LO)   # top inner shadow (recessed)
    d.text((x0 + 8, y0 + 6), value + ("_" if (focus and cursor is None) else ""),
           font=_font(13, mono=True), fill=FIELD_FG or LEGEND)
    if focus and cursor is not None:
        _text_caret(d, (x0 + 8, y0 + 6), value, cursor, _font(13, mono=True), FIELD_FG or LEGEND)
    hm.add(wid, box)


def _zx_rainbow(d, x0, y0, bar_w=7, height=16, slant=6):
    """The well-known Sinclair ZX Spectrum rainbow flash: four slanted bars in
    red / yellow / green / cyan (Spectrum colours 2,6,4,5).  Small and tucked into
    a corner so it reads as a badge on the machine, not chrome over the screen."""
    bars = [(213, 0, 0), (255, 204, 0), (0, 200, 0), (0, 200, 200)]
    x = x0
    for col in bars:
        d.polygon([(x + slant, y0), (x + slant + bar_w, y0),
                   (x + bar_w, y0 + height), (x, y0 + height)], fill=col)
        x += bar_w
    return x + slant


def _vertali_logo(d, x, y, h):
    """The Vertali mark drawn from the real logo SVG path (an open lime hexagon -
    the 'C').  Path + colour taken verbatim from vertali_logo.svg, scaled to height
    h.  Drawn from primitives so no logo file has to ship."""
    lime = (138, 205, 0)                                  # #8ACD00, from the SVG
    pts = [(405, 154), (274, 82), (127, 154), (127, 323), (274, 407), (403, 339)]
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    bw, bh = max(xs) - min(xs), max(ys) - min(ys)
    s = h / bh
    sp = [(x + (px - min(xs)) * s, y + (py - min(ys)) * s) for px, py in pts]
    w = max(2, round(34 * s))                             # SVG stroke-width 34
    try:
        d.line(sp, fill=lime, width=w, joint="curve")
    except TypeError:                                     # very old Pillow: no joint kwarg
        d.line(sp, fill=lime, width=w)
    r = w / 2                                             # round the mitre joints
    for px, py in sp:
        d.ellipse((px - r, py - r, px + r, py + r), fill=lime)


@lru_cache(maxsize=16)
def _skin_logo_image(name, box_w, box_h):
    """Brand logo scaled to fit (box_w, box_h) preserving aspect ratio, cached."""
    if not name:
        return None
    path = __import__("os").path.join(__import__("os").path.dirname(__file__), "assets", name)
    try:
        im = Image.open(path).convert("RGBA")
    except Exception:
        return None
    scale = min(box_w / im.width, box_h / im.height)
    w, h = max(1, int(im.width * scale)), max(1, int(im.height * scale))
    return im.resize((w, h), Image.LANCZOS)


def _paste_skin_logo(img):
    """Paste the current skin's brand logo into the keypad's lower space, under the
    PF buttons and above the Help/Quit row (nothing for skins without a logo)."""
    if not SKIN_LOGO:
        return
    bx0, by0 = KP_X + 14, WIN_H - 156
    bx1, by1 = WIN_W - 14, WIN_H - 82
    logo = _skin_logo_image(SKIN_LOGO, bx1 - bx0, by1 - by0)
    if logo is None:
        return
    x = bx0 + (bx1 - bx0 - logo.width) // 2
    y = by0 + (by1 - by0 - logo.height) // 2
    img.paste(logo, (x, y), logo)


def _keypad(d, hm):
    # beige keypad chassis to match the Model M case
    d.rounded_rectangle((KP_X, TERM_Y, WIN_W - 8, WIN_H - 12), radius=10, fill=PLATE, outline=CASE_LO, width=1)
    d.line((KP_X + 8, TERM_Y + 1, WIN_W - 16, TERM_Y + 1), fill=CASE_HI)
    d.text((KP_X + 14, TERM_Y + 8), "KEYPAD", font=_font(11), fill=LEGEND_DIM)
    if _CURRENT_THEME == "zx":
        # ZX Spectrum rainbow flash, right-aligned in the keypad header - a small
        # badge on the machine, well clear of the screen and the keys.
        _zx_rainbow(d, WIN_W - 16 - (7 * 4 + 6), TERM_Y + 6, bar_w=7, height=15, slant=5)
    inner_l = KP_X + 12
    inner_r = WIN_W - 16
    y = TERM_Y + 28
    gap = 5
    for height, row in KEYPAD:
        n = len(row)
        total = inner_r - inner_l
        bw = (total - gap * (n - 1)) / n
        # centre rows that don't fill all three columns (e.g. the lone Up arrow)
        x = inner_l + (total - (bw * n + gap * (n - 1))) / 2 if n < 3 else inner_l
        if n == 1:                         # single key: keep it one-column wide, centred
            bw = (total - gap * 2) / 3
            x = inner_l + bw + gap
        for wid, label in row:
            _key3d(d, hm, f"k_{wid}", (x, y, x + bw, y + height), label,
                   accent=wid in ("enter", "newline"))
            x += bw + gap
        y += height + 4


def _cell_for(font_px):
    return (max(7, int(font_px * 0.55)), font_px)


def _grid_signature(grid):
    """Cheap fingerprint of the visible grid (chars + colours) to detect change."""
    if not grid:
        return 0
    return hash(tuple((c[0], c[1] if len(c) > 1 else "") for row in grid for c in row))


def _draw_terminal_bezel(img, d, hm, state):
    """Static half of the terminal: the IBM bezel (or plain viewport border) and
    the screen / POWER hitboxes.  Cached with the chrome; sets GLASS_RECT."""
    global GLASS_RECT
    bez = _bezel_image(TERM_W, min(TERM_H, int(TERM_W / _BEZEL_ASPECT))) if state.bezel else None
    if bez is not None:
        bw, bh = bez.size
        img.paste(bez, (TERM_X, TERM_Y), bez)
        l, tp, r, b = _GLASS_FRAC
        gx = TERM_X + int(l * bw); gy = TERM_Y + int(tp * bh)
        gw = int((r - l) * bw);    gh = int((b - tp) * bh)
        pl, ptp, pr, pb = _POWER_FRAC           # POWER button = quit
        hm.add("b_power", (TERM_X + int(pl * bw), TERM_Y + int(ptp * bh),
                           TERM_X + int(pr * bw), TERM_Y + int(pb * bh)))
    else:
        gx, gy, gw, gh = TERM_X, TERM_Y, TERM_W, TERM_H
        d.rectangle((gx, gy, gx + gw, gy + gh), outline=LINE, width=1)
    GLASS_RECT = (gx, gy, gw, gh)
    hm.add("screen", (gx, gy, gx + gw, gy + gh))
    return gx, gy, gw, gh


def render_terminal_only(state, crt, t):
    """Compose just the bezel + live glass into a standalone image (no chrome),
    for the detached full-screen 'focus' mode.  Returns (image, glass_rect)."""
    bez = _bezel_image(TERM_W, min(TERM_H, int(TERM_W / _BEZEL_ASPECT))) if state.bezel else None
    if bez is not None:
        bw, bh = bez.size
        img = Image.new("RGB", (bw, bh), (0, 0, 0))
        img.paste(bez, (0, 0), bez)
        l, tp, r, b = _GLASS_FRAC
        gx, gy = int(l * bw), int(tp * bh)
        gw, gh = int((r - l) * bw), int((b - tp) * bh)
    else:
        gw, gh = TERM_W, TERM_H
        img = Image.new("RGB", (gw, gh), SCREEN_FIELD)
        gx = gy = 0
    cols = len(state.grid[0]) if state.grid and state.grid[0] else 80
    rows = len(state.grid) if state.grid else 24
    cw = max(int(state.font_px * 0.55), gw // cols + 2)
    chh = max(state.font_px, gh // rows + 2)
    sig = (state.grid_gen, state.cfg.mode, state.colour, gw, gh, cw, chh, state.font_px, bool(state.grid))
    if getattr(crt, "_app_sig", None) != sig:
        if state.grid:
            text_img = text_pass.render_grid_image(state.grid, mode=state.cfg.mode, cell=(cw, chh), bg=SCREEN_FIELD, palette=(SCREEN_PALETTE if state.colour == "colour" else None), out_size=(gw, gh), fill=max(82, min(100, int(82 + (max(8, min(24, state.font_px)) - 8) / 16 * 18))))
        else:
            text_img = Image.new("RGB", (gw, gh), SCREEN_FIELD)
            tint = {"green": (60, 190, 90), "amber": (255, 176, 0)}.get(state.colour, (120, 210, 140))
            ImageDraw.Draw(text_img).text((40, gh // 2 - 12), "  PHOSPHOR - connect to a host to begin",
                                          font=text_pass.load_font(22), fill=tint)
        if (crt.w, crt.h) != (gw, gh):
            crt.w, crt.h = gw, gh
            crt._geom.clear(); crt._glow_y = np.linspace(0, 1, gh)
        crt.cfg = state.cfg; crt._static = None
        crt.prepare(text_img)
        crt._app_sig = sig
    crt_img = Image.fromarray(crt.render(t)).convert("RGB")
    img.paste(crt_img, (gx, gy), _glass_mask(gw, gh, max(6, int(min(gw, gh) * 0.055))))
    if state.connected:
        _draw_cursor(ImageDraw.Draw(img), state, gx, gy, gw, gh, t)
    return img, (gx, gy, gw, gh)


@lru_cache(maxsize=8)
def _glass_mask(gw, gh, r):
    """Rounded-rectangle alpha mask so the pasted CRT screen follows the curved
    bezel instead of showing as a hard square."""
    m = Image.new("L", (gw, gh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, gw - 1, gh - 1), radius=r, fill=255)
    return m


CURSOR_BLUE = (120, 200, 255)          # light-blue terminal cursor (always this colour)


def _draw_cursor(d, state, gx, gy, gw, gh, t):
    """Blinking light-blue cursor (and optional crosshair) drawn on the composited
    glass, so it animates without re-rasterising the screen."""
    if not state.grid:
        return
    cols = len(state.grid[0]) if state.grid[0] else 80
    rows = len(state.grid)
    cw = max(4, gw // cols)
    chh = max(6, gh // rows)
    offx = (gw - cw * cols) // 2
    offy = (gh - chh * rows) // 2
    row, col = getattr(state, "cursor_rc", (1, 1))
    col = min(max(1, col), cols)
    row = min(max(1, row), rows)
    cx = gx + offx + (col - 1) * cw
    cy = gy + offy + (row - 1) * chh
    if getattr(state, "crosshair", False):
        faint = (46, 92, 132)
        d.line((gx, cy + chh // 2, gx + gw, cy + chh // 2), fill=faint, width=1)
        d.line((cx + cw // 2, gy, cx + cw // 2, gy + gh), fill=faint, width=1)
    # solid, always-visible light-blue cursor (drawn each frame; moves as you type).
    d.rectangle((cx, cy, cx + cw - 1, cy + chh - 1), outline=CURSOR_BLUE, width=1)
    d.rectangle((cx, cy + chh - 3, cx + cw - 1, cy + chh - 1), fill=CURSOR_BLUE)


def _blit_terminal_glass(img, state, crt, t):
    """Dynamic half of the terminal: the live 3270 screen rasterised + CRT pass,
    pasted into the glass.  The raster/CRT are cached on `crt` (keyed on grid_gen)
    so this is cheap unless the screen content actually changed."""
    gx, gy, gw, gh = GLASS_RECT
    cols = len(state.grid[0]) if state.grid and state.grid[0] else 80
    rows = len(state.grid) if state.grid else 24
    cw = max(int(state.font_px * 0.55), gw // cols + 2)
    chh = max(state.font_px, gh // rows + 2)

    sig = (state.grid_gen, state.cfg.mode, state.colour, gw, gh, cw, chh, state.font_px, bool(state.grid))
    if getattr(crt, "_app_sig", None) != sig:
        if state.grid:
            text_img = text_pass.render_grid_image(state.grid, mode=state.cfg.mode, cell=(cw, chh), bg=SCREEN_FIELD, palette=(SCREEN_PALETTE if state.colour == "colour" else None), out_size=(gw, gh), fill=max(82, min(100, int(82 + (max(8, min(24, state.font_px)) - 8) / 16 * 18))))
        else:
            text_img = Image.new("RGB", (gw, gh), SCREEN_FIELD)
            tint = {"green": (60, 190, 90), "amber": (255, 176, 0)}.get(state.colour, (120, 210, 140))
            ImageDraw.Draw(text_img).text((40, gh // 2 - 12), "  PHOSPHOR - connect to a host to begin",
                                          font=text_pass.load_font(22), fill=tint)
        if (crt.w, crt.h) != (gw, gh):
            crt.w, crt.h = gw, gh
            crt._geom.clear(); crt._glow_y = np.linspace(0, 1, gh)
        crt.cfg = state.cfg; crt._static = None
        crt.prepare(text_img)
        crt._app_sig = sig
    crt_img = Image.fromarray(crt.render(t)).convert("RGB")
    img.paste(crt_img, (gx, gy), _glass_mask(gw, gh, max(6, int(min(gw, gh) * 0.055))))
    if state.connected:
        _draw_cursor(ImageDraw.Draw(img), state, gx, gy, gw, gh, t)


def _compose_chrome(state: AppState, hover: str = None, pressed: str = None):
    """Draw everything that is static between frames: sidebar, keypad, bottom bar,
    panels, the terminal BEZEL, the (empty) command-line box, popups.  The live
    terminal glass and the command-line text are drawn on top afterwards, so this
    expensive pass (~100 text labels + ~80 keycaps) is cached and reused."""
    global _PRESSED
    _PRESSED = pressed
    global _HOVER
    _HOVER = hover
    img = Image.new("RGB", (WIN_W, WIN_H), CASE)
    d = ImageDraw.Draw(img)
    hm = Hitmap()

    # header - the wordmark (and, on the Vertali skin, its hexagon mark)
    if _CURRENT_THEME == "vertali":
        # hexagon mark with the wordmark's first letter sitting INSIDE it, and the
        # rest of the word flowing out the open right side - as in the real logo.
        # No underline (the Vertali logo has none).
        _vertali_logo(d, 12, 4, 34)
        d.text((20, 10), WORDMARK or "vertali", font=_font(22), fill=HEADER_FG or LEGEND)
    else:
        # auto-fit the wordmark so long brand names (e.g. "COVERT ACCESS TEAM")
        # fit the sidebar width; no underline (removed on all skins).
        wm = WORDMARK or "PHOSPHOR"
        maxw = SIDEBAR_W - 28
        fs = 22
        f = _font(fs)
        while fs > 10 and d.textlength(wm, font=f) > maxw:
            fs -= 1
            f = _font(fs)
        d.text((16, 10 + (22 - fs) // 2), wm, font=f, fill=HEADER_FG or LEGEND)

    SX0, SX1 = 8, SIDEBAR_W - 6
    bx0, bx1 = SX0 + 12, SX1 - 12          # single-column button span
    colw = (bx1 - bx0 - 8) // 2            # for the tight 2-col sub-grids

    # CONNECT
    _panel(d, (SX0, 46, SX1, 176), "CONNECT")
    _field(d, hm, "f_host", (bx0, 80, bx1, 104), state.host or "", "Host", state.focus == "f_host", state.field_cursor.get("host"))
    _field(d, hm, "f_port", (bx0, 126, bx0 + 64, 150), state.port, "Port", state.focus == "f_port", state.field_cursor.get("port"))
    _button(d, hm, "b_protocol", (bx0 + 72, 126, bx1, 150),
            "TN5250" if state.protocol == "5250" else "TN3270", small=True,
            colour=(ACCENT if state.protocol == "5250" else AMBER))
    _button(d, hm, "b_connect", (bx0, 152, bx1, 174),
            "Disconnect" if state.connected else "Connect", active=state.connected)

    # FAVOURITES
    fav_h = 54 + min(4, len(state.favourites)) * 22
    _panel(d, (SX0, 184, SX1, 184 + fav_h), "FAVOURITES")
    _button(d, hm, "b_fav_save", (bx0, 206, bx1, 226), "\u2605 Save current", small=True)
    fy = 232
    for fav in state.favourites[:4]:
        _button(d, hm, f"fav_{fav['name']}", (bx0, fy, bx1 - 20, fy + 20),
                f"{fav['name']}  {fav['host']}:{fav['port']}", small=True)
        _button(d, hm, f"favx_{fav['name']}", (bx1 - 18, fy, bx1, fy + 20), "\u00d7", small=True, colour=WARN)
        fy += 22
    ty0 = 184 + fav_h + 8

    # TOOLS - primary scans single-column, secondary tools tight 2-col ("1.5")
    cred = [("a_hydra", "Hydra", AMBER), ("a_passticket", "PassTicket", AMBER),
            ("a_hack3270", ("\u25cf STRIP3270" if (state.h3_proxy or state.h3_unprotect or state.h3_unhide) else "STRIP3270"),
             WARN if state.h3_proxy else AMBER),
            ("a_shell", ("\u25cf Shell live" if state.shell_on else "Shell"),
             WARN if state.shell_on else ACCENT),
            ("a_api", "API (curl)", ACCENT), ("a_sql", "SQL (DB2)", ACCENT),
            ("a_ezrecon", "EZrecon", ACCENT), ("a_injector", "iNJEctor", ACCENT)]
    cred_rows = (len(cred) + 1) // 2
    tools_h = 26 + len(TOOLS) * 25 + 16 + cred_rows * 25 + 26
    _panel(d, (SX0, ty0, SX1, ty0 + tools_h), "TOOLS")
    if not getattr(state, "tools_unlocked", False):
        # pen-test tools gated behind the one-time unlock code
        d.text((bx0, ty0 + 30), "\U0001f512 Pen-test tools locked", font=_font(12), fill=WARN)
        d.text((bx0, ty0 + 50), "Enter the unlock code to enable", font=_font(10), fill=LEGEND_DIM)
        _button(d, hm, "tools_unlock", (bx0, ty0 + 74, bx1, ty0 + 100), "Unlock tools", colour=ACCENT)
    else:
        ry = ty0 + 26
        for wid, label in TOOLS:
            _button(d, hm, f"t_{wid}", (bx0, ry, bx1, ry + 23), label, small=True)
            ry += 25
        d.text((bx0, ry + 2), "credential / crack / app", font=_font(10), fill=LEGEND_DIM)
        ry += 16
        for i, (wid, label, col) in enumerate(cred):
            cx = bx0 + (i % 2) * (colw + 8); cy2 = ry + (i // 2) * 25
            _button(d, hm, wid, (cx, cy2, cx + colw, cy2 + 23), label, small=True, colour=col)
        ry += cred_rows * 25 + 4
    # tool status strip (installed = blue dot)
    st = state.tool_status or {}
    if getattr(state, "tools_unlocked", False):
        _rows = [(("nmap", "nmap"), ("hydra", "hydra")),
                 (("hack3270", "h3270"), ("pcap", "pcap"))]
        for ri, row in enumerate(_rows):
            sx = bx0; ry2 = ry + ri * 12
            for name, lbl in row:
                info = st.get(name, {"installed": name == "pcap"})
                d.ellipse((sx, ry2 + 2, sx + 7, ry2 + 9), fill=IBM_BLUE if info.get("installed") else IBM_RED)
                d.text((sx + 10, ry2), lbl, font=_font(9), fill=LEGEND_DIM)
                sx += 10 + int(d.textlength(lbl, font=_font(9))) + 10
    tr0 = ty0 + tools_h + 8

    # TRANSFER + REPORT
    _panel(d, (SX0, tr0, SX1, tr0 + 106), "TRANSFER")
    _button(d, hm, "b_upload", (bx0, tr0 + 24, bx0 + colw, tr0 + 46), "\u2b06 Upload", small=True)
    _button(d, hm, "b_download", (bx0 + colw + 8, tr0 + 24, bx1, tr0 + 46), "\u2b07 Download", small=True)
    _button(d, hm, "b_xfer_mode", (bx0, tr0 + 50, bx1, tr0 + 72),
            "Type: BINARY" if state.xfer_mode == "binary" else "Type: ASCII", small=True,
            colour=(ACCENT if state.xfer_mode == "binary" else AMBER))
    _button(d, hm, "b_ftp", (bx0, tr0 + 76, bx1, tr0 + 98), "FTP client / Submit JCL", small=True, colour=AMBER)
    _button(d, hm, "b_grab", (bx0, tr0 + 114, bx0 + colw, tr0 + 136),
            "\u2317 Grab", colour=ACCENT, small=True)
    _button(d, hm, "b_report", (bx0 + colw + 8, tr0 + 114, bx1, tr0 + 136),
            "\u25a4 Report", colour=AMBER, small=True)

    # OUTPUT - findings readout (the redundant "connected to" line is gone; the
    # live status already shows on the command bar / packet header)
    out0 = tr0 + 146
    _panel(d, (SX0, out0, SX1, WIN_H - 44), "OUTPUT", screen=True)
    if state.results:
        d.text((SX1 - 78, out0 + 6), "\u2317 click", font=_font(9), fill=(90, 130, 110))
        ry = out0 + 26
        recent = state.results[-16:]
        base = len(state.results) - len(recent)
        for i, fnd in enumerate(recent):
            sev = getattr(fnd, "severity", "info")
            d.text((SX0 + 12, ry), "\u25cf", font=_font(10), fill=SEVCOL.get(sev, DIM))
            d.text((SX0 + 26, ry), getattr(fnd, "title", str(fnd))[:34], font=_font(10), fill=(180, 210, 188))
            hm.add(f"finding_{base + i}", (SX0 + 6, ry - 1, SX1 - 6, ry + 13))
            ry += 15
            if ry > WIN_H - 56:
                break
    else:
        d.text((SX0 + 12, out0 + 28), "findings appear here", font=_font(10), fill=DIM)
        d.text((SX0 + 12, out0 + 44), "run a scan to populate", font=_font(10), fill=(70, 100, 78))

    # offensivesec.org link (bottom-left, clickable)
    link = "offensivesec.org"
    lf = _font(13)
    d.text((16, WIN_H - 30), "\u00bb " + link, font=lf, fill=IBM_BLUE)
    lw = d.textlength("\u00bb " + link, font=lf)
    d.line((16, WIN_H - 14, 16 + lw, WIN_H - 14), fill=IBM_BLUE)
    hm.add("link_offsec", (14, WIN_H - 32, 16 + lw + 6, WIN_H - 12))

    # TERMINAL - static IBM 3270 bezel + hitboxes.  The live glass is overlaid later.
    _draw_terminal_bezel(img, d, hm, state)

    # command line - the (empty) dark input box + ENTER; the text is overlaid later
    cy = TERM_Y + TERM_H + 8
    d.rounded_rectangle((TERM_X, cy, TERM_X + TERM_W - 96, cy + 30), radius=5, fill=SCREEN_BG,
                        outline=(IBM_BLUE if state.focus == "cmd" else CASE_LO), width=(2 if state.focus == "cmd" else 1))
    hm.add("cmd", (TERM_X, cy, TERM_X + TERM_W - 96, cy + 30))
    _button(d, hm, "b_enter", (TERM_X + TERM_W - 88, cy, TERM_X + TERM_W, cy + 30), "ENTER", colour=ACCENT)

    # bottom bar - a single row (skins / bezel / about now live in Settings)
    by = cy + 40
    d.text((TERM_X, by + 6), "COLOUR", font=_font(10), fill=LEGEND_DIM)
    _button(d, hm, "c_colour", (TERM_X + 54, by, TERM_X + 110, by + 26), "Colour", active=state.colour == "colour", small=True)
    _button(d, hm, "c_green", (TERM_X + 114, by, TERM_X + 170, by + 26), "Green", active=state.colour == "green", small=True)
    _button(d, hm, "c_amber", (TERM_X + 174, by, TERM_X + 230, by + 26), "Amber", active=state.colour == "amber", small=True)
    d.text((TERM_X + 242, by + 6), "FONT", font=_font(10), fill=LEGEND_DIM)
    _button(d, hm, "font_dec", (TERM_X + 280, by, TERM_X + 306, by + 26), "A-", small=True)
    d.text((TERM_X + 312, by + 6), f"{state.font_px}px", font=_font(11), fill=LEGEND)
    _button(d, hm, "font_inc", (TERM_X + 352, by, TERM_X + 378, by + 26), "A+", small=True)
    _button(d, hm, "b_settings", (TERM_X + 388, by, TERM_X + 470, by + 26), "\u2699 Settings", small=True, colour=AMBER, active=True)
    _button(d, hm, "b_trace", (TERM_X + 478, by, TERM_X + 536, by + 26),
            "Trace \u25cf" if state.trace_on else "Trace", small=True, colour=(WARN if state.trace_on else None))
    _button(d, hm, "b_copy", (TERM_X + 544, by, TERM_X + 596, by + 26), "Copy", small=True)
    _button(d, hm, "b_paste", (TERM_X + 604, by, TERM_X + 656, by + 26), "Paste", small=True)
    _button(d, hm, "b_notes", (TERM_X + 664, by, TERM_X + 722, by + 26), "Notes", small=True, colour=AMBER)
    _button(d, hm, "b_tasks", (TERM_X + 730, by, TERM_X + 788, by + 26), "Tasks", small=True, colour=AMBER)
    _button(d, hm, "b_focus", (TERM_X + 796, by, TERM_X + 868, by + 26), "\u26f6 Focus", small=True, colour=ACCENT)

    # PACKET MONITOR - dark inset readout under the terminal (click to expand)
    py = by + 32
    _panel(d, (TERM_X, py, KP_X - 12, WIN_H - 12),
           "PACKETS  (EBCDIC / ASCII)   " + ("live" if state.connected else "idle") + "   \u2317 click to expand", screen=True)
    hm.add("packets", (TERM_X, py, KP_X - 160, WIN_H - 12))     # focusable: opens the full log
    _button(d, hm, "b_pcap", (KP_X - 140, py + 6, KP_X - 24, py + 30),
            ("\u25cf REC PCAP" if state.capture_on else "Capture PCAP"), small=True,
            colour=(WARN if state.capture_on else ACCENT))
    from phosphor.app.packets import format_packets
    ly = py + 24
    for direction, line in format_packets(state.packets, width=18, max_lines=int((WIN_H - 12 - ly) / 16)):
        col = ACCENT if direction == ">" else (110, 180, 255)
        d.text((TERM_X + 12, ly), line, font=_font(11, mono=True), fill=col)
        ly += 16

    _keypad(d, hm)
    _paste_skin_logo(img)

    # help + shutdown, at the bottom of the keypad panel (out of the way)
    _button(d, hm, "b_help", (KP_X + 12, WIN_H - 74, WIN_W - 12, WIN_H - 52), "? Help", small=True, colour=AMBER)
    _button(d, hm, "b_quit", (KP_X + 12, WIN_H - 46, WIN_W - 12, WIN_H - 24), "\u23fb Quit", small=True, colour=WARN)
    return img, hm


def _has_overlay(state, hover):
    return (state.settings_open or state.console_open or state.about_open
            or state.notes_open or state.tasks_open or state.ftp_open or state.help_open
            or state.hack3270_open or state.confirm_open or state.themes_open
            or state.license_open or state.tools_popup
            or bool(hover and hover in KEY_HELP))


def _draw_overlays(d, hm, state, hover):
    """Modal popups + tooltips, drawn AFTER the terminal glass so they always sit
    on top of the green screen instead of being painted over by it."""
    if (state.settings_open or state.console_open or state.about_open
            or state.notes_open or state.tasks_open or state.ftp_open or state.help_open
            or state.hack3270_open or state.confirm_open or state.themes_open
            or state.license_open or state.tools_popup):
        d.rectangle((0, 0, WIN_W, WIN_H), fill=(0, 0, 0))    # opaque dim behind the modal
        hm.add("block", (0, 0, WIN_W, WIN_H))                # swallow clicks to the app behind
    if state.settings_open:
        _settings_popup(d, hm, state)
    if state.themes_open:
        _themes_popup(d, hm, state)
    if state.license_open:
        _license_popup(d, hm, state)
    if state.tools_popup:
        _tools_popup(d, hm, state)
    if state.console_open:
        _console(d, hm, state)
    if state.about_open:
        _about(d, hm, state)
    if state.hack3270_open:
        _hack3270_popup(d, hm, state)
    if state.help_open:
        _help(d, hm, state)
    if state.confirm_open:               # always on top
        _confirm_popup(d, hm, state)
    if state.notes_open:
        _notes(d, hm, state)
    if state.tasks_open:
        _tasks(d, hm, state)
    if state.ftp_open:
        _ftp(d, hm, state)
    if hover and hover in KEY_HELP:
        box = next((b for w, b in hm.rects if w == hover), None)
        if box:
            _tooltip(d, KEY_HELP[hover], box)


def _frame_sig(s, hover, pressed):
    """Fingerprint of *everything* that affects the composited frame.  The main
    loop uses this to skip rendering entirely when nothing changed."""
    return (
        s.theme, s.themes_open,
        hover, pressed, s.focus, s.cmdline, s.status, s.connected,
        s.grid_gen, tuple(s.field_cursor.items()),
        len(s.results), len(s.packets), len(s.log), s.findings,
        s.colour, s.font_px, s.bezel, s.codepage, s.protocol,
        s.settings_open, s.console_open, s.about_open, s.notes_open, s.tasks_open,
        s.license_open, s.license_email, s.license_token, s.license_status,
        s.tools_unlocked, s.tools_popup, s.tools_pw, s.tools_status,
        s.ftp_open, s.help_open, s.hack3270_open, s.confirm_open,
        s.ftp_status, len(s.ftp_list), s.ftp_mode, s.xfer_mode, s.ftp_focus, s.ftp_dsn,
        s.ftp_host, s.ftp_user, s.ftp_pass,
        len(s.console_lines), s.console_scroll, s.console_cmd, s.console_title,
        s.help_scroll, s.themes_scroll, s.notes_scroll,
        s.trace_on, s.capture_on, s.shell_on,
        s.h3_proxy, s.h3_unprotect, s.h3_unhide,
        s.notes_text, s.notes_name, s.task_input, s.about_text, s.confirm_text,
        len(s.favourites), len(s.tasks),
    )


def _chrome_sig(s, hover, pressed):
    """Fingerprint of only what the *cached chrome* draws.  Hover/press highlights
    and every popup are drawn in the overlay stage now, so they're deliberately NOT
    here - that keeps the chrome cache warm (no full recompose on mouse-move or when
    a popup opens/updates)."""
    fc = tuple((k, v) for k, v in s.field_cursor.items() if k in ("host", "port"))
    return (
        _CURRENT_THEME, s.focus, s.connected, fc,
        s.host, s.port,
        len(s.results), len(s.packets), len(s.log), s.findings,
        s.colour, s.font_px, s.bezel, s.protocol,
        s.trace_on, s.capture_on, s.shell_on,
        s.h3_proxy, s.h3_unprotect, s.h3_unhide,
        s.tools_unlocked, s.xfer_mode,
        len(s.favourites),
    )


def _draw_command_line_text(img, state):
    """Dynamic overlay: the command-line text + caret, drawn over the cached box."""
    cy = TERM_Y + TERM_H + 8
    _text_caret(ImageDraw.Draw(img), (TERM_X + 10, cy + 7), state.cmdline,
                state.field_cursor.get("cmdline") if state.focus == "cmd" else None,
                _font(14, mono=True), FG, prefix="\u203a ")


_CHROME = {"sig": None, "img": None, "hm": None}


def _tools_popup(d, hm, state):
    """Unlock the pen-test tools with the one-time code (scrypt-verified)."""
    mw, mh = 520, 250
    mx, my = (WIN_W - mw) // 2, (WIN_H - mh) // 2
    d.rounded_rectangle((mx, my, mx + mw, my + mh), radius=12, fill=(16, 18, 20), outline=(200, 120, 60), width=2)
    d.text((mx + 24, my + 18), "\U0001f512 UNLOCK PEN-TEST TOOLS", font=_font(18), fill=(240, 200, 120))
    _button(d, hm, "tools_close", (mx + mw - 44, my + 16, mx + mw - 16, my + 42), "\u00d7", colour=WARN)
    d.text((mx + 24, my + 56), "Enter the one-time unlock code.", font=_font(11), fill=(150, 158, 172))
    tf = (state.focus == "tools_pw")
    d.rounded_rectangle((mx + 24, my + 84, mx + mw - 24, my + 112), radius=5, fill=(8, 10, 12),
                        outline=((90, 170, 255) if tf else (60, 64, 72)), width=2 if tf else 1)
    masked = "\u2022" * len(state.tools_pw)
    _text_caret(d, (mx + 32, my + 90), masked,
                state.field_cursor.get("tools_pw") if tf else None, _font(14, mono=True), (220, 228, 240))
    hm.add("toolsf_pw", (mx + 24, my + 84, mx + mw - 24, my + 112))
    _button(d, hm, "tools_activate", (mx + mw - 170, my + 126, mx + mw - 24, my + 154), "Unlock", colour=ACCENT)
    if state.tools_status:
        good = state.tools_status.startswith("unlocked")
        d.text((mx + 24, my + 168), state.tools_status[:60], font=_font(11),
               fill=(120, 220, 150) if good else (240, 150, 120))
    d.text((mx + 24, my + mh - 30), "Tools stay unlocked on this machine once entered.",
           font=_font(10), fill=(120, 128, 140))


def _license_popup(d, hm, state):
    """Activate paid skins with an emailed, cryptographically-signed license."""
    mw, mh = 620, 400
    mx, my = (WIN_W - mw) // 2, (WIN_H - mh) // 2
    d.rounded_rectangle((mx, my, mx + mw, my + mh), radius=12, fill=(16, 18, 20), outline=(120, 140, 200), width=2)
    d.text((mx + 24, my + 18), "ACTIVATE SKINS", font=_font(20), fill=(224, 230, 240))
    _button(d, hm, "lic_close", (mx + mw - 44, my + 16, mx + mw - 16, my + 42), "\u00d7", colour=WARN)
    d.text((mx + 24, my + 50), "Buy at offensivesec.org - a signed licence is emailed to you.",
           font=_font(11), fill=(150, 158, 172))
    d.text((mx + 24, my + 66), "Enter THAT email + paste the token - or just enter an unlock code as the token.",
           font=_font(11), fill=(150, 158, 172))
    # email field
    d.text((mx + 24, my + 96), "Email", font=_font(11), fill=(150, 158, 172))
    ef = (state.focus == "license_email")
    d.rounded_rectangle((mx + 24, my + 112, mx + mw - 24, my + 138), radius=5, fill=(8, 10, 12),
                        outline=((90, 170, 255) if ef else (60, 64, 72)), width=2 if ef else 1)
    _text_caret(d, (mx + 32, my + 118), state.license_email,
                state.field_cursor.get("license_email") if ef else None, _font(13, mono=True), (220, 228, 240))
    hm.add("licf_email", (mx + 24, my + 112, mx + mw - 24, my + 138))
    # token / unlock-code field (type a short unlock code, or paste a long token)
    d.text((mx + 24, my + 150), "Licence token or unlock code", font=_font(11), fill=(150, 158, 172))
    tfoc = (state.focus == "license_token")
    d.rounded_rectangle((mx + 24, my + 166, mx + mw - 24, my + 214), radius=5, fill=(8, 10, 12),
                        outline=((90, 170, 255) if tfoc else (60, 64, 72)), width=2 if tfoc else 1)
    tok = state.license_token or ""
    shown = (tok[:52] + "\u2026" + tok[-8:]) if len(tok) > 64 else tok
    if tok:
        d.text((mx + 32, my + 174), shown + ("_" if tfoc and len(tok) <= 64 else ""),
               font=_font(11, mono=True), fill=(190, 200, 210))
        d.text((mx + 32, my + 192), f"{len(tok)} chars", font=_font(9), fill=(110, 116, 124))
    else:
        d.text((mx + 32, my + 174), "type an unlock code, or Paste a licence token",
               font=_font(11, mono=True), fill=(90, 96, 104))
    hm.add("licf_token", (mx + 24, my + 166, mx + mw - 24, my + 214))
    _button(d, hm, "lic_paste", (mx + 24, my + 226, mx + 150, my + 252), "\U0001f4cb Paste token", small=True, colour=AMBER)
    _button(d, hm, "lic_activate", (mx + mw - 180, my + 226, mx + mw - 24, my + 252), "Activate licence", colour=ACCENT)
    # status
    if state.license_status:
        good = state.license_status.startswith(("activated", "licence valid"))
        d.text((mx + 24, my + 264), state.license_status[:74], font=_font(11),
               fill=(120, 220, 150) if good else (240, 150, 120))
    # entitlement summary
    from phosphor.app.themes import THEMES
    paid = [t for t in THEMES.values() if t.paid]
    unlocked = sum(1 for t in paid if t.name in state.unlocked)
    d.text((mx + 24, my + mh - 30), f"Paid skins unlocked: {unlocked} / {len(paid)}",
           font=_font(11), fill=(150, 158, 172))


def _screen_preview(t):
    from phosphor.crt.config import PALETTES, COLOUR_3279
    p = PALETTES.get(t.screen_mode)
    if p is None:
        p = COLOUR_3279["green"]
    return tuple(int(c * 255) for c in p)


def _themes_popup(d, hm, state):
    """Phosphor Skins picker - a modal grid of theme cards with live swatches."""
    from phosphor.app.themes import THEMES, ORDER
    cols, cw, ch, gap = 3, 300, 96, 14
    rows = (len(ORDER) + cols - 1) // cols
    mw = 990
    mh = 74 + rows * (ch + gap) + 60           # header + card grid + footer, auto-sized
    mx, my = (WIN_W - mw) // 2, (WIN_H - mh) // 2
    d.rectangle((0, 0, WIN_W, WIN_H), fill=(0, 0, 0))            # dim behind (opaque modal bg via block)
    d.rounded_rectangle((mx, my, mx + mw, my + mh), radius=12, fill=(16, 18, 20), outline=(120, 140, 200), width=2)
    d.text((mx + 24, my + 18), "PHOSPHOR SKINS", font=_font(20), fill=(224, 230, 240))
    d.text((mx + 24, my + 46), "Tap a skin to apply it. Add-on skins are marked PRO.",
           font=_font(11), fill=(140, 150, 170))

    cols, cw, ch, gap = 3, 300, 96, 14
    x0, y0 = mx + 24, my + 74
    for i, name in enumerate(ORDER):
        t = THEMES.get(name)
        if t is None:
            continue
        cx = x0 + (i % cols) * (cw + gap)
        cy = y0 + (i // cols) * (ch + gap)
        active = (state.theme == name)
        locked = t.paid and name not in state.unlocked
        # card body
        d.rounded_rectangle((cx, cy, cx + cw, cy + ch), radius=8,
                            fill=(28, 30, 34) if not active else (36, 44, 60),
                            outline=(90, 170, 255) if active else (60, 64, 72), width=2 if active else 1)
        # live swatch: case / plate / keycap / legend / screen field + text
        sw_x, sw_y = cx + 12, cy + 12
        for j, col in enumerate((t.CASE, t.PLATE, t.KEY_FACE, t.LEGEND)):
            d.rounded_rectangle((sw_x + j * 22, sw_y, sw_x + j * 22 + 18, sw_y + 30), radius=3, fill=col, outline=(50, 54, 60))
        # mini "screen"
        scr_x = sw_x + 4 * 22 + 6
        d.rounded_rectangle((scr_x, sw_y, scr_x + 40, sw_y + 30), radius=3, fill=t.screen_field, outline=(50, 54, 60))
        d.text((scr_x + 5, sw_y + 8), "A>_", font=_font(12, mono=True), fill=_screen_preview(t))
        # label + blurb
        d.text((cx + 12, cy + 50), t.label, font=_font(14), fill=(230, 234, 240) if not locked else (150, 154, 160))
        d.text((cx + 12, cy + 70), t.blurb[:46], font=_font(9), fill=(140, 148, 160))
        # tags
        if active:
            d.text((cx + cw - 66, cy + 12), "ACTIVE", font=_font(10), fill=(120, 200, 255))
        elif t.paid:
            tag = "PRO \u25c6" if locked else "PRO"
            d.text((cx + cw - (52 if locked else 40), cy + 12), tag, font=_font(10),
                   fill=(255, 196, 90) if locked else (150, 220, 160))
        hm.add(f"theme_{name}", (cx, cy, cx + cw, cy + ch))

    _button(d, hm, "themes_close", (mx + mw - 120, my + mh - 44, mx + mw - 24, my + mh - 16), "Close", colour=AMBER)
    _button(d, hm, "b_license", (mx + 24, my + mh - 44, mx + 180, my + mh - 16), "\U0001f511 Enter licence", small=True, colour=ACCENT)
    d.text((mx + 200, my + mh - 38), "Add-on skins \u2014 support the project at offensivesec.org",
           font=_font(10), fill=(120, 130, 150))


def apply_theme(name):
    """Rebind the module-level colour globals to the named theme.  Every drawing
    routine reads these globals, so this re-skins the whole UI with no other
    changes; the chrome cache is invalidated so the next frame recomposes."""
    from phosphor.app.themes import THEMES, DEFAULT_THEME
    t = THEMES.get(name) or THEMES[DEFAULT_THEME]
    g = globals()
    for k, v in t.chrome_dict().items():
        g[k] = v
    g["SCREEN_FIELD"] = t.screen_field
    g["SCREEN_PALETTE"] = getattr(t, "screen_palette", None)
    g["KEY_PF"] = getattr(t, "key_pf", None)
    g["KEY_OUTLINE"] = getattr(t, "key_outline", None)
    g["KEY_PF_FG"] = getattr(t, "key_pf_fg", None)
    g["HEADER_FG"] = getattr(t, "header", None)
    g["WORDMARK"] = getattr(t, "wordmark", None)
    g["SKIN_LOGO"] = getattr(t, "logo", None)
    g["FIELD_FG"] = getattr(t, "field_fg", None)
    g["_CURRENT_THEME"] = t.name
    _CHROME["sig"] = None
    return t


def render_app_frame(state: AppState, crt: SoftCRT, t: float = 0.0, hover: str = None, pressed: str = None):
    """Compose a frame.  The static chrome is cached and reused; only the terminal
    glass and the command-line text are redrawn each call, so a keystroke or a host
    screen update costs a cheap copy + two overlays instead of a full re-composite."""
    csig = _chrome_sig(state, hover, pressed)
    if _CHROME["sig"] != csig or _CHROME["img"] is None:
        _CHROME["img"], _CHROME["hm"] = _compose_chrome(state, None, None)   # hover-neutral
        _CHROME["sig"] = csig
    img = _CHROME["img"].copy()             # start from the cached chrome
    _blit_terminal_glass(img, state, crt, t)
    _draw_command_line_text(img, state)
    d = ImageDraw.Draw(img)
    _draw_hover(d, hover, pressed)          # cheap hover/press cue (no recompose)
    # popups + tooltips render on TOP of the terminal glass (not under it)
    hm = _CHROME["hm"]
    if _has_overlay(state, hover):
        hm = Hitmap()
        hm.rects = list(_CHROME["hm"].rects)     # don't mutate the cached hitmap
        _draw_overlays(d, hm, state, hover)
    return img, hm


def _draw_hover(d, hover, pressed):
    """Draw a light highlight over the hovered/pressed widget, using the cached
    hitmap - so hover feedback costs one outline, not a full chrome recompose."""
    hm = _CHROME.get("hm")
    if hm is None:
        return
    for wid, strong in ((hover, False), (pressed, True)):
        if not wid or wid in ("block", "screen", "packets"):
            continue
        box = next((b for w, b in hm.rects if w == wid), None)
        if not box:
            continue
        x0, y0, x1, y1 = box
        if (x1 - x0) * (y1 - y0) > 14000:      # skip panels / large areas
            continue
        col = ACCENT if strong else (LEGEND_DIM if isinstance(LEGEND_DIM, tuple) else (180, 180, 180))
        d.rounded_rectangle(box, radius=6, outline=col, width=2)


def _confirm_popup(d, hm, state):
    w, h = 560, 210
    x0, y0 = WIN_W // 2 - w // 2, WIN_H // 2 - h // 2
    x1, y1 = x0 + w, y0 + h
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=(28, 18, 12), outline=WARN, width=2)
    d.text((x0 + 24, y0 + 20), "\u26a0  Authorised testing only", font=_font(17), fill=AMBER)
    msg = state.confirm_text or "Are you sure? Do you have written permission to test this target?"
    # simple word-wrap
    words, line, yy = msg.split(), "", y0 + 58
    for wd in words:
        if d.textlength(line + " " + wd, font=_font(13)) > w - 48:
            d.text((x0 + 24, yy), line, font=_font(13), fill=FG); yy += 22; line = wd
        else:
            line = (line + " " + wd).strip()
    if line:
        d.text((x0 + 24, yy), line, font=_font(13), fill=FG)
    _button(d, hm, "confirm_no", (x0 + 24, y1 - 46, x0 + 220, y1 - 18), "Cancel", small=True)
    _button(d, hm, "confirm_yes", (x1 - 300, y1 - 46, x1 - 24, y1 - 18),
            "Yes - I have permission, continue", small=True, colour=WARN)


def _hack3270_popup(d, hm, state):
    x0, y0, x1, y1 = WIN_W // 2 - 300, WIN_H // 2 - 235, WIN_W // 2 + 300, WIN_H // 2 + 235
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=PANEL, outline=AMBER, width=2)
    d.text((x0 + 24, y0 + 18), "STRIP3270  -  CICS data-stream manipulation", font=_font(16), fill=AMBER)
    _button(d, hm, "h3_close", (x1 - 44, y0 + 14, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    inst = (state.tool_status or {}).get("hack3270", {}).get("installed")
    d.ellipse((x0 + 26, y0 + 54, x0 + 34, y0 + 62), fill=ACCENT if inst else WARN)
    d.text((x0 + 42, y0 + 52),
           "hack3270 binary detected" if inst else "hack3270 not installed - inline mode still works (no binary needed)",
           font=_font(11), fill=DIM)
    rows = [
        ("set_h3_proxy", "Auto-proxy on connect", state.h3_proxy,
         "Launch hack3270 as a MITM proxy and route the session through it (needs the binary)."),
        ("set_h3_unprotect", "Unprotect fields (inline)", state.h3_unprotect,
         "Clear the protected bit so read-only fields accept input - in-process, no binary."),
        ("set_h3_unhide", "Reveal hidden fields (inline)", state.h3_unhide,
         "Unmask non-display fields (e.g. password/MFA inputs) - in-process, no binary."),
    ]
    yy = y0 + 84
    for wid, label, on, desc in rows:
        _button(d, hm, wid, (x0 + 24, yy, x0 + 300, yy + 26),
                ("\u2611 " if on else "\u2610 ") + label, small=True, colour=(ACCENT if on else None))
        d.text((x0 + 314, yy + 6), desc[:44], font=_font(9), fill=DIM)
        d.text((x0 + 314, yy + 17), desc[44:90], font=_font(9), fill=DIM)
        yy += 40
    # --- field injection / brute force (hack3270 "Inject Into Fields") ---
    iy = yy + 6
    d.line((x0 + 24, iy, x1 - 24, iy), fill=LINE)
    d.text((x0 + 24, iy + 8), "FIELD INJECTION / BRUTE FORCE", font=_font(11), fill=AMBER)
    from phosphor.toolchain import injections as _inj
    tid = _inj.type_ids()[state.h3_inject_idx % len(_inj.type_ids())]
    n = _inj.count(tid)
    ncnt = "?" if n < 0 else (f"{n:,}" if n < 100000 else f"{n:,} (capped)")
    d.text((x0 + 24, iy + 30), "wordlist type:", font=_font(11), fill=DIM)
    _button(d, hm, "h3_inject_type", (x0 + 130, iy + 26, x0 + 400, iy + 52),
            f"\u25c2  {_inj.label_for(tid)}  \u25b8", small=True, colour=ACCENT)
    d.text((x0 + 412, iy + 32), f"{ncnt} candidates", font=_font(10), fill=DIM)
    _button(d, hm, "h3_inject_save", (x0 + 24, iy + 60, x0 + 200, iy + 86), "Save wordlist to tools", small=True)
    _button(d, hm, "h3_inject_run", (x0 + 210, iy + 60, x0 + 400, iy + 86), "\u25b6 Inject now", small=True, colour=AMBER)
    d.text((x0 + 24, iy + 94),
           "Type the mask char '*' into the target field on the screen, then Inject. Hits are",
           font=_font(9), fill=DIM)
    d.text((x0 + 24, iy + 105),
           "flagged by response size (like hack3270). Point PHOSPHOR_INJECTIONS_DIR at the full set.",
           font=_font(9), fill=DIM)
    d.text((x0 + 24, y1 - 22), "Inline toggles apply live; auto-proxy engages on the next Connect.",
           font=_font(10), fill=DIM)


def _help(d, hm, state):
    from phosphor.app.help import help_for
    title, lines = help_for(state)
    x0, y0, x1, y1 = WIN_W // 2 - 320, WIN_H // 2 - 210, WIN_W // 2 + 320, WIN_H // 2 + 210
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=PANEL, outline=AMBER, width=2)
    d.text((x0 + 24, y0 + 18), title, font=_font(17), fill=AMBER)
    _button(d, hm, "help_close", (x1 - 44, y0 + 14, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    maxlines = 22
    total = len(lines)
    scroll = max(0, min(getattr(state, "help_scroll", 0), max(0, total - maxlines)))
    state.help_scroll = scroll
    yy = y0 + 54
    for line in lines[scroll:scroll + maxlines]:
        col = DIM if line.startswith(("Keys:", "       ", "Tip", "Note", "  ")) else FG
        d.text((x0 + 24, yy), line[:88], font=_font(12, mono=line.startswith(("Keys:", "       "))), fill=col)
        yy += 16
    foot = "context-sensitive - open a panel and press ? for help on it"
    if total > maxlines:
        foot = f"{scroll + 1}-{min(scroll + maxlines, total)} / {total}   \u2191\u2193 wheel to scroll"
    d.text((x0 + 24, y1 - 26), foot, font=_font(10), fill=DIM)


def _about(d, hm, state):
    mw, mh = 600, 452
    x0, y0 = (WIN_W - mw) // 2, (WIN_H - mh) // 2
    x1, y1 = x0 + mw, y0 + mh
    d.rounded_rectangle((x0, y0, x1, y1), radius=12, fill=PANEL, outline=ACCENT, width=2)
    d.text((x0 + 28, y0 + 22), "PHOSPHOR", font=_font(26), fill=ACCENT)
    vw = d.textlength("PHOSPHOR", font=_font(26))
    d.text((x0 + 34 + vw, y0 + 34), "v1.0.0", font=_font(12), fill=DIM)
    d.text((x0 + 28, y0 + 58), "A TN3270 / TN5250 mainframe audit terminal", font=_font(13), fill=FG)
    _button(d, hm, "about_close", (x1 - 44, y0 + 16, x1 - 16, y0 + 42), "\u00d7", colour=WARN)
    d.line((x0 + 28, y0 + 84, x1 - 28, y0 + 84), fill=LINE)

    def para(lines, yy, colour=FG, font=None, gap=19):
        f = font or _font(12)
        for ln in lines:
            d.text((x0 + 28, yy), ln, font=f, fill=colour)
            yy += gap
        return yy

    yy = y0 + 96
    yy = para(["Developed by Kev Milne  \u00b7  offensivesec.org"], yy, ACCENT, _font(13), 26)
    yy = para([
        "PHOSPHOR is free to use.  Additional skins can be",
        "purchased for \u00a35 from the OffensiveSec site.",
    ], yy, FG)
    yy += 8
    yy = para([
        "It carries offensive security tooling.  You must have",
        "explicit permission / authorisation to use those tools",
        "against any system.",
    ], yy, (240, 200, 120))
    yy += 8
    yy = para([
        "Tools unlock code: it's in the No Starch Press book",
        "\"Hacking Mainframes\", or PM me on LinkedIn - so I can",
        "make sure the security work you're doing is legitimate.",
    ], yy, FG)
    yy += 6
    para(["Authorised, defensive / training use only.",
          "\u00a9 2026 Kev Milne \u00b7 OffensiveSec.  All rights reserved."], yy, DIM, _font(11), 17)

    lf = _font(13)
    d.text((x0 + 28, y1 - 34), "\u00bb offensivesec.org", font=lf, fill=(90, 170, 255))
    lw = d.textlength("\u00bb offensivesec.org", font=lf)
    d.line((x0 + 28, y1 - 17, x0 + 28 + lw, y1 - 17), fill=(90, 170, 255))
    hm.add("link_offsec", (x0 + 26, y1 - 36, x0 + 28 + lw + 6, y1 - 14))


def _console(d, hm, state):
    x0, y0, x1, y1 = 40, 40, WIN_W - 40, WIN_H - 40
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=(6, 10, 8), outline=ACCENT, width=2)
    d.text((x0 + 20, y0 + 14), state.console_title, font=_font(16), fill=ACCENT)
    _button(d, hm, "con_copy", (x1 - 200, y0 + 12, x1 - 120, y0 + 40), "Copy all", small=True)
    _button(d, hm, "con_close", (x1 - 44, y0 + 12, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    # editable command line (edit + Run)
    cy = y0 + 48
    # API / SQL modes get dedicated editable Host + Port fields + a Build button
    if state.console_mode in ("api", "sql"):
        d.text((x0 + 20, cy), "Host", font=_font(11), fill=DIM)
        d.rounded_rectangle((x0 + 58, cy - 4, x0 + 340, cy + 22), radius=5, fill=(2, 5, 3),
                            outline=(ACCENT if state.focus == "tool_host" else LINE), width=1)
        _text_caret(d, (x0 + 66, cy + 2), state.tool_host,
                    state.field_cursor.get("tool_host") if state.focus == "tool_host" else None,
                    _font(13, mono=True), FG)
        hm.add("tool_host", (x0 + 58, cy - 4, x0 + 340, cy + 22))
        d.text((x0 + 356, cy), "Port", font=_font(11), fill=DIM)
        d.rounded_rectangle((x0 + 394, cy - 4, x0 + 474, cy + 22), radius=5, fill=(2, 5, 3),
                            outline=(ACCENT if state.focus == "tool_port" else LINE), width=1)
        _text_caret(d, (x0 + 402, cy + 2), state.tool_port,
                    state.field_cursor.get("tool_port") if state.focus == "tool_port" else None,
                    _font(13, mono=True), FG)
        hm.add("tool_port", (x0 + 394, cy - 4, x0 + 474, cy + 22))
        _button(d, hm, "con_build", (x0 + 490, cy - 4, x0 + 600, cy + 22), "Build command", small=True, colour=ACCENT)
        d.text((x0 + 616, cy + 2), "(edit Host/Port then Build)", font=_font(10), fill=DIM)
        cy += 36
    d.text((x0 + 20, cy), "command (editable - press Run to execute):", font=_font(10), fill=DIM)
    d.rounded_rectangle((x0 + 20, cy + 14, x1 - 130, cy + 40), radius=5, fill=(2, 5, 3),
                        outline=(ACCENT if state.focus == "console_cmd" else LINE), width=1)
    _text_caret(d, (x0 + 28, cy + 20), state.console_cmd,
                state.field_cursor.get("console_cmd") if state.focus == "console_cmd" else None,
                _font(12, mono=True), FG)
    hm.add("con_cmd", (x0 + 20, cy + 14, x1 - 130, cy + 40))
    _button(d, hm, "con_run", (x1 - 120, cy + 14, x1 - 20, cy + 40), "\u25b6 Run", colour=ACCENT, small=True)
    # output body — readable mono text, scrollable (F7/F8), disclaimer pinned at the bottom
    body_top = cy + 52
    line_h = 22
    maxlines = max(1, int((y1 - body_top - 44) // line_h))   # reserve a line for the disclaimer
    lines = state.console_lines
    total = len(lines)
    scroll = max(0, min(getattr(state, "console_scroll", 0), max(0, total - maxlines)))
    state.console_scroll = scroll                            # write back the clamped value
    end = total - scroll
    start = max(0, end - maxlines)
    for i, ln in enumerate(lines[start:end]):
        colour = CONSOLE_TEXT
        low = ln.lower()
        if ln.startswith(("$", "#", ">")):
            colour = ACCENT
        elif "error" in low or "fail" in low or "denied" in low:
            colour = WARN
        d.text((x0 + 20, body_top + i * line_h), ln[:130], font=_font(16, mono=True), fill=colour)
    if total > maxlines:                                     # scroll indicator
        d.text((x1 - 250, body_top - 4),
                f"\u2191 F7 / F8 \u2193   lines {start + 1}-{end} of {total}", font=_font(10), fill=DIM)
    # pinned disclaimer
    d.line((x0 + 16, y1 - 30, x1 - 16, y1 - 30), fill=LINE)
    d.text((x0 + 20, y1 - 24),
           "Authorised testing only \u2014 you are responsible for having written permission for this target.",
           font=_font(10), fill=AMBER)


def _settings_popup(d, hm, state):
    ov = Image.new("RGBA", (WIN_W, WIN_H), (0, 0, 0, 150))
    # (drawn by caller compositing not available here; emulate with dark rect)
    d.rectangle((0, 0, WIN_W, WIN_H), fill=None)
    px0, py0, px1, py1 = WIN_W // 2 - 220, WIN_H // 2 - 260, WIN_W // 2 + 220, WIN_H // 2 + 260
    d.rounded_rectangle((px0, py0, px1, py1), radius=10, fill=PANEL, outline=ACCENT, width=2)
    d.text((px0 + 20, py0 + 16), "SETTINGS", font=_font(16), fill=ACCENT)
    _button(d, hm, "set_close", (px1 - 44, py0 + 14, px1 - 16, py0 + 40), "\u00d7", colour=WARN)
    # appearance / mode row - the skin picker and toggles live here now
    _button(d, hm, "b_themes", (px0 + 20, py0 + 48, px0 + 128, py0 + 74), "\u25a3 Skins\u2026", small=True, colour=AMBER)
    _button(d, hm, "b_bezel", (px0 + 136, py0 + 48, px0 + 236, py0 + 74),
            "Bezel \u25cf" if state.bezel else "Bezel \u25cb", small=True,
            colour=(ACCENT if state.bezel else None), active=state.bezel)
    _button(d, hm, "b_focus", (px0 + 244, py0 + 48, px0 + 330, py0 + 74), "\u26f6 Focus", small=True, colour=ACCENT)
    _button(d, hm, "b_about", (px0 + 338, py0 + 48, px0 + 420, py0 + 74), "About", small=True)
    y = py0 + 92
    d.text((px0 + 20, y), "Screen colour", font=_font(12), fill=DIM)
    _button(d, hm, "c_green", (px0 + 170, y - 4, px0 + 270, y + 22), "Green", active=state.colour == "green", small=True)
    _button(d, hm, "c_amber", (px0 + 278, y - 4, px0 + 378, y + 22), "Amber", active=state.colour == "amber", small=True)
    y += 40
    d.text((px0 + 20, y), "Font size", font=_font(12), fill=DIM)
    _button(d, hm, "font_dec", (px0 + 170, y - 4, px0 + 200, y + 22), "A-", small=True)
    d.text((px0 + 214, y), f"{state.font_px}px", font=_font(12), fill=FG)
    _button(d, hm, "font_inc", (px0 + 268, y - 4, px0 + 298, y + 22), "A+", small=True)
    y += 40
    d.text((px0 + 20, y), "Codepage", font=_font(12), fill=DIM)
    _button(d, hm, "set_cp", (px0 + 170, y - 4, px0 + 378, y + 22), state.codepage, small=True, colour=AMBER)
    y += 40
    _eng = getattr(state, "engine", "native")
    d.text((px0 + 20, y), "TN3270 engine", font=_font(12), fill=DIM)
    _button(d, hm, "set_engine", (px0 + 170, y - 4, px0 + 298, y + 22),
            ("IBM tnz" if _eng == "tnz" else "Native"), small=True,
            colour=(ACCENT if _eng == "tnz" else AMBER))
    d.text((px0 + 306, y), "real z/OS" if _engines_available().get("tnz") else "pip install tnz",
           font=_font(9), fill=LEGEND_DIM)
    y += 44
    d.text((px0 + 20, y), "Keyboard toggles", font=_font(12), fill=DIM)
    y += 24
    for tid, label, on in [("t_monocase", "Monocase", state.monocase),
                           ("t_typeahead", "Typeahead", state.typeahead)]:
        _button(d, hm, f"set_{tid}", (px0 + 20, y, px0 + 200, y + 24),
                ("\u2611 " if on else "\u2610 ") + label, small=True)
        y += 30
    # hack3270 CICS data-stream manipulation
    y += 10
    d.text((px0 + 20, y), "STRIP3270  (CICS app-layer testing)", font=_font(12), fill=AMBER)
    y += 24
    for tid, label, on in [("h3_proxy", "Auto-proxy on connect", state.h3_proxy),
                           ("h3_unprotect", "Unprotect fields (inline)", state.h3_unprotect),
                           ("h3_unhide", "Reveal hidden fields (inline)", state.h3_unhide)]:
        _button(d, hm, f"set_{tid}", (px0 + 20, y, px0 + 260, y + 24),
                ("\u2611 " if on else "\u2610 ") + label, small=True,
                colour=(ACCENT if on else None))
        y += 30


def pixel_to_cell(x, y, grid):
    rows = len(grid) if grid else 24
    cols = len(grid[0]) if grid and grid[0] else 80
    gx, gy, gw, gh = GLASS_RECT
    cx = (x - gx) / max(1, gw) * cols
    cy = (y - gy) / max(1, gh) * rows
    return min(rows, max(1, int(cy) + 1)), min(cols, max(1, int(cx) + 1))


def _wrap(text, width):
    """Wrap text into lines of at most `width` chars, honouring newlines."""
    out = []
    for para in text.split("\n"):
        if not para:
            out.append("")
            continue
        while len(para) > width:
            out.append(para[:width])
            para = para[width:]
        out.append(para)
    return out


def _notes(d, hm, state):
    x0, y0, x1, y1 = 60, 50, WIN_W - 60, WIN_H - 50
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=(16, 22, 17), outline=AMBER, width=2)
    d.text((x0 + 20, y0 + 14), "NOTEPAD", font=_font(16), fill=AMBER)
    d.text((x0 + 130, y0 + 18), "notes auto-save · name a file + Save to tools for wordlists (users.txt ...)",
           font=_font(11), fill=DIM)
    _button(d, hm, "notes_close", (x1 - 44, y0 + 12, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    # filename + save-to-tools row
    fy0 = y0 + 46
    d.text((x0 + 20, fy0 + 6), "file", font=_font(11), fill=DIM)
    d.rounded_rectangle((x0 + 56, fy0, x0 + 300, fy0 + 26), radius=5, fill=(6, 10, 8),
                        outline=(ACCENT if state.focus == "notes_name" else LINE), width=1)
    _fname = state.notes_name if (state.notes_name or state.focus == "notes_name") else "wordlist.txt"
    _text_caret(d, (x0 + 64, fy0 + 5), _fname,
                state.field_cursor.get("notes_name") if state.focus == "notes_name" else None,
                _font(12, mono=True), FG if state.notes_name else DIM)
    hm.add("notes_name", (x0 + 56, fy0, x0 + 300, fy0 + 26))
    _button(d, hm, "notes_save_tools", (x0 + 312, fy0, x0 + 440, fy0 + 26), "Save to tools", colour=ACCENT, small=True)
    # existing wordlists in the tools dir (click to open)
    d.text((x0 + 458, fy0 + 6), "tools:", font=_font(11), fill=DIM)
    for i, name in enumerate((state.tools_files or [])[:5]):
        bx = x0 + 502 + i * 128
        if bx + 120 > x1 - 20:
            break
        _button(d, hm, f"notes_openfile_{i}", (bx, fy0, bx + 120, fy0 + 26), name[:15], small=True)
    # editable text body (with caret)
    by0 = fy0 + 38
    d.rounded_rectangle((x0 + 16, by0, x1 - 16, y1 - 16), radius=6, fill=(6, 10, 8),
                        outline=(ACCENT if state.focus == "notes" else LINE), width=1)
    cur = state.field_cursor.get("notes_text") if state.focus == "notes" else None
    shown = state.notes_text if cur is not None else state.notes_text + ("_" if state.focus == "notes" else "")
    lines = _wrap(shown, 120)
    fy = by0 + 10
    for ln in lines[-38:]:
        d.text((x0 + 26, fy), ln, font=_font(13, mono=True), fill=FG)
        fy += 17
    hm.add("notes_body", (x0 + 16, by0, x1 - 16, y1 - 16))


def _tasks(d, hm, state):
    x0, y0, x1, y1 = WIN_W // 2 - 300, 70, WIN_W // 2 + 300, WIN_H - 70
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=(16, 22, 17), outline=AMBER, width=2)
    d.text((x0 + 20, y0 + 14), "TASK LIST", font=_font(16), fill=AMBER)
    _button(d, hm, "tasks_close", (x1 - 44, y0 + 12, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    # input row
    iy = y0 + 50
    d.rounded_rectangle((x0 + 20, iy, x1 - 120, iy + 28), radius=5, fill=(6, 10, 8),
                        outline=(ACCENT if state.focus == "task_input" else LINE), width=1)
    d.text((x0 + 28, iy + 7), (state.task_input or "add a task...") + ("_" if state.focus == "task_input" else ""),
           font=_font(13, mono=True), fill=FG if state.task_input else DIM)
    hm.add("task_field", (x0 + 20, iy, x1 - 120, iy + 28))
    _button(d, hm, "task_add", (x1 - 108, iy, x1 - 20, iy + 28), "+ Add", colour=ACCENT, small=True)
    # task rows
    ty = iy + 44
    for i, task in enumerate(state.tasks[:22]):
        done = task.get("done")
        _button(d, hm, f"task_toggle_{i}", (x0 + 20, ty, x0 + 48, ty + 24),
                "\u2713" if done else " ", active=done, small=True)
        col = DIM if done else FG
        txt = task.get("text", "")
        d.text((x0 + 58, ty + 5), txt[:64], font=_font(13), fill=col)
        if done:
            tw = d.textlength(txt[:64], font=_font(13))
            d.line((x0 + 58, ty + 13, x0 + 58 + tw, ty + 13), fill=DIM)
        _button(d, hm, f"task_del_{i}", (x1 - 48, ty, x1 - 20, ty + 24), "\u00d7", colour=WARN, small=True)
        ty += 30


def _ftp(d, hm, state):
    x0, y0, x1, y1 = WIN_W // 2 - 320, 60, WIN_W // 2 + 320, WIN_H - 60
    d.rounded_rectangle((x0, y0, x1, y1), radius=10, fill=(16, 22, 17), outline=AMBER, width=2)
    d.text((x0 + 20, y0 + 14), "FTP CLIENT", font=_font(16), fill=AMBER)
    _button(d, hm, "ftp_close", (x1 - 44, y0 + 12, x1 - 16, y0 + 40), "\u00d7", colour=WARN)
    # connection fields
    def fld(fx, w, key, label, val, mask=False):
        d.text((fx, y0 + 46), label, font=_font(10), fill=DIM)
        foc = state.ftp_focus == key
        d.rounded_rectangle((fx, y0 + 60, fx + w, y0 + 84), radius=5, fill=(6, 10, 8),
                            outline=(ACCENT if foc else LINE), width=1)
        shown = ("*" * len(val)) if mask else val
        d.text((fx + 8, y0 + 66), shown + ("_" if foc else ""), font=_font(12, mono=True), fill=FG)
        hm.add("ftpf_" + key, (fx, y0 + 60, fx + w, y0 + 84))
    fld(x0 + 20, 200, "host", "Host", state.ftp_host or state.host)
    fld(x0 + 230, 140, "user", "User", state.ftp_user)
    fld(x0 + 380, 140, "pass", "Password", state.ftp_pass, mask=True)
    _button(d, hm, "ftp_connect", (x1 - 110, y0 + 60, x1 - 20, y0 + 84), "Connect", colour=ACCENT, small=True)
    # status
    d.text((x0 + 20, y0 + 96), state.ftp_status[:80], font=_font(11), fill=DIM)
    # editable dataset / HLQ to list or download (e.g. SYS1 or SYS1.PARMLIB)
    dy = y0 + 114
    d.text((x0 + 20, dy + 5), "Dataset / HLQ", font=_font(10), fill=DIM)
    dfoc = state.ftp_focus == "dsn"
    d.rounded_rectangle((x0 + 122, dy, x0 + 420, dy + 24), radius=5, fill=(6, 10, 8),
                        outline=(ACCENT if dfoc else LINE), width=1)
    _text_caret(d, (x0 + 130, dy + 4), state.ftp_dsn,
                state.field_cursor.get("ftp_dsn") if dfoc else None, _font(12, mono=True), FG)
    hm.add("ftpf_dsn", (x0 + 122, dy, x0 + 420, dy + 24))
    _button(d, hm, "ftp_list_hlq", (x0 + 430, dy, x0 + 520, dy + 24), "\u21bb List HLQ", small=True)
    _button(d, hm, "ftp_download_dsn", (x0 + 528, dy, x1 - 20, dy + 24), "\u2b07 Download", small=True, colour=ACCENT)
    # action buttons
    ay = y0 + 150
    _button(d, hm, "ftp_refresh", (x0 + 20, ay, x0 + 120, ay + 26), "\u21bb List", small=True)
    _button(d, hm, "ftp_upload", (x0 + 128, ay, x0 + 240, ay + 26), "\u2b06 Upload", small=True)
    _button(d, hm, "ftp_submit", (x0 + 248, ay, x0 + 400, ay + 26), "\u25b6 Submit JCL", small=True, colour=ACCENT)
    # transfer type: ASCII (host translates EBCDIC<->ASCII text) vs Binary (raw bytes)
    ascii_on = state.ftp_mode == "ascii"
    _button(d, hm, "ftp_mode", (x0 + 408, ay, x1 - 20, ay + 26),
            ("Mode: ASCII" if ascii_on else "Mode: BINARY"), small=True,
            colour=(AMBER if ascii_on else ACCENT), active=True)
    d.text((x0 + 408, ay + 30),
           "ASCII = readable text (EBCDIC\u2194ASCII) \u00b7 Binary = raw bytes",
           font=_font(9), fill=DIM)
    # dataset list
    ly = ay + 48
    d.rounded_rectangle((x0 + 20, ly, x1 - 20, y1 - 20), radius=6, fill=(6, 10, 8), outline=LINE, width=1)
    d.text((x0 + 28, ly + 8), "datasets / files:", font=_font(10), fill=DIM)
    ry = ly + 28
    for i, name in enumerate(state.ftp_list[:26]):
        _button(d, hm, f"ftpget_{i}", (x0 + 28, ry, x0 + 60, ry + 20), "\u2b07", small=True)
        d.text((x0 + 70, ry + 3), str(name)[:70], font=_font(11, mono=True), fill=FG)
        ry += 24
        if ry > y1 - 30:
            break
