"""Free-form notes and a simple task list, persisted under ~/.config/phosphor/."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional


def _dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    p = Path(base) / "phosphor"
    p.mkdir(parents=True, exist_ok=True)
    return p


def load_notes() -> str:
    try:
        return (_dir() / "notes.txt").read_text()
    except Exception:
        return ""


def save_notes(text: str) -> None:
    try:
        (_dir() / "notes.txt").write_text(text or "")
    except Exception:
        pass


def load_tasks() -> List[Dict]:
    try:
        data = json.loads((_dir() / "tasks.json").read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_tasks(tasks: List[Dict]) -> None:
    try:
        (_dir() / "tasks.json").write_text(json.dumps(tasks, indent=2))
    except Exception:
        pass


# --- in-client file save into the tools/working directory (wordlists etc.) ---
def tools_dir() -> Path:
    """Where scans look for users.txt / passwords.txt (the working directory).
    Overridable with PHOSPHOR_TOOLS_DIR."""
    p = Path(os.environ.get("PHOSPHOR_TOOLS_DIR") or os.getcwd())
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return p


def _safe_name(name: str) -> str:
    """Confine to a bare filename in the tools dir (no path traversal)."""
    base = os.path.basename((name or "").strip().replace("\\", "/"))
    return base or "wordlist.txt"


def save_tool_file(name: str, text: str) -> Optional[str]:
    """Write text to <tools_dir>/<name>. Returns the full path, or None on error."""
    try:
        p = tools_dir() / _safe_name(name)
        body = text or ""
        if body and not body.endswith("\n"):
            body += "\n"
        p.write_text(body, encoding="utf-8")
        return str(p)
    except Exception:
        return None


def load_tool_file(name: str) -> str:
    try:
        return (tools_dir() / _safe_name(name)).read_text(encoding="utf-8")
    except Exception:
        return ""


def list_tool_files() -> List[str]:
    try:
        return sorted(f.name for f in tools_dir().glob("*.txt") if f.is_file())
    except Exception:
        return []
