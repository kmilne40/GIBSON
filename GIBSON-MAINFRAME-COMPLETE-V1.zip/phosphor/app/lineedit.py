"""A reusable single-line text editor: text + cursor with insert/overwrite editing.

Pure and dependency-free so it unit-tests without a display. Drives every editable
field in PHOSPHOR (command line, tool console, host/port, notepad filename, ...), so you
can move the caret and insert instead of only appending/backspacing.
"""
from __future__ import annotations


def _is_word(ch: str) -> bool:
    return ch.isalnum() or ch in "_-./"


class LineEditor:
    def __init__(self, text: str = "", cursor: int | None = None, insert: bool = True):
        self.text = text or ""
        self.cursor = len(self.text) if cursor is None else max(0, min(int(cursor), len(self.text)))
        self.insert = bool(insert)

    # --- navigation helpers ---
    def _word_left(self) -> int:
        c = self.cursor
        while c > 0 and not _is_word(self.text[c - 1]):
            c -= 1
        while c > 0 and _is_word(self.text[c - 1]):
            c -= 1
        return c

    def _word_right(self) -> int:
        n = len(self.text); c = self.cursor
        while c < n and not _is_word(self.text[c]):
            c += 1
        while c < n and _is_word(self.text[c]):
            c += 1
        return c

    def key(self, ch: str | None, keyname: str | None, ctrl: bool = False):
        """Apply one key. keyname is the special-key name (left/right/home/end/
        backspace/delete/insert); ch is the printable character otherwise.
        Returns (text, cursor)."""
        kn = (keyname or "").lower()
        t, c = self.text, self.cursor
        if kn == "left":
            self.cursor = self._word_left() if ctrl else max(0, c - 1)
        elif kn == "right":
            self.cursor = self._word_right() if ctrl else min(len(t), c + 1)
        elif kn == "home":
            self.cursor = 0
        elif kn == "end":
            self.cursor = len(t)
        elif kn == "insert":
            self.insert = not self.insert
        elif kn == "backspace":
            if ctrl:
                w = self._word_left()
                self.text = t[:w] + t[c:]; self.cursor = w
            elif c > 0:
                self.text = t[:c - 1] + t[c:]; self.cursor = c - 1
        elif kn == "delete":
            if c < len(t):
                self.text = t[:c] + t[c + 1:]
        elif ch is not None and len(ch) == 1 and ch.isprintable():
            if self.insert or c >= len(t):
                self.text = t[:c] + ch + t[c:]
            else:
                self.text = t[:c] + ch + t[c + 1:]
            self.cursor = c + 1
        return self.text, self.cursor

    def set(self, text: str, cursor: int | None = None):
        self.text = text or ""
        self.cursor = len(self.text) if cursor is None else max(0, min(int(cursor), len(self.text)))
        return self
