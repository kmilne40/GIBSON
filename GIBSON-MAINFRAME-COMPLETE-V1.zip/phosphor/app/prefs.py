"""User preferences + skin licensing for PHOSPHOR.

Persists the small set of UI choices (active skin, font size, bezel, focus) under
~/.config/phosphor/prefs.json so they survive restarts, and resolves which add-on
skins are unlocked.  Unlocking is deliberately offline and pluggable:

  * prefs.json  "unlocked": [...]        - skins the user has unlocked
  * licence.json "unlocked": [...]       - dropped in by a purchase/licence flow
  * env PHOSPHOR_UNLOCK="lcars,cyber"    - handy for testing / site licences
  * env PHOSPHOR_UNLOCK_ALL=1            - unlock everything

Swap unlock_from_licence() for a real signature check when you wire up a store.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List

_FREE = {"classic", "green", "lcars", "pink", "bbc", "z17"}


def _dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    p = Path(base) / "phosphor"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _prefs_path() -> Path:
    return _dir() / "prefs.json"


def _licence_path() -> Path:
    return _dir() / "licence.json"


def load() -> Dict:
    try:
        return json.loads(_prefs_path().read_text())
    except Exception:
        return {}


def unlocked_skins() -> set:
    """Every skin the user is entitled to: the free set plus anything a valid,
    signed license grants (verified offline), plus env/licence-file overrides."""
    from phosphor.app import license as lic
    unlocked = set(_FREE) | lic.entitlements()
    data = load()
    unlocked |= set(data.get("unlocked", []))          # legacy manual unlocks
    unlocked |= unlock_from_licence()
    env = os.environ.get("PHOSPHOR_UNLOCK", "")
    unlocked |= {s.strip() for s in env.split(",") if s.strip()}
    if os.environ.get("PHOSPHOR_UNLOCK_ALL") == "1":
        from phosphor.app.themes import THEMES
        unlocked |= set(THEMES.keys())
    return unlocked


def unlock_from_licence() -> set:
    """Read a dropped-in licence file (a real store would sign this)."""
    try:
        data = json.loads(_licence_path().read_text())
        return set(data.get("unlocked", []))
    except Exception:
        return set()


def apply_to(state) -> None:
    """Load saved prefs into a fresh AppState and apply the skin."""
    from phosphor.app import ui
    data = load()
    state.unlocked = unlocked_skins()
    state.font_px = int(data.get("font_px", state.font_px))
    if "bezel" in data:
        state.bezel = bool(data["bezel"])
    theme = data.get("theme", "classic")
    if theme not in state.unlocked:
        theme = "classic"
    state.theme = theme
    t = ui.apply_theme(theme)
    state.colour = t.screen_mode


def save(state) -> None:
    """Persist the current UI choices (best-effort)."""
    try:
        _prefs_path().write_text(json.dumps({
            "theme": state.theme,
            "font_px": state.font_px,
            "bezel": bool(state.bezel),
            "unlocked": sorted(set(state.unlocked) - _FREE),
        }, indent=2))
    except Exception:
        pass
