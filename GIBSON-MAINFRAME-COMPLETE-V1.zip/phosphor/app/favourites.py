"""Saved ("favourite") connections, persisted to ~/.config/phosphor/favourites.json."""
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Dict, List


def _path() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "phosphor" / "favourites.json"


def load() -> List[Dict]:
    try:
        data = json.loads(_path().read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save(items: List[Dict]) -> None:
    p = _path(); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(items, indent=2))


def add(name: str, host: str, port: str, codepage: str = "cp037") -> List[Dict]:
    items = [i for i in load() if i.get("name") != (name or host)]
    items.append({"name": name or host, "host": host, "port": str(port), "codepage": codepage})
    items = items[-12:]; save(items); return items


def remove(name: str) -> List[Dict]:
    items = [i for i in load() if i.get("name") != name]; save(items); return items
