"""Phosphor Skins - swappable colour themes for the PHOSPHOR UI.

Each Theme is a full palette: the "case / keycap / legend" family that paints the
chrome, plus the dark "readout / popup / screen-text" family and the terminal
glass colour.  Every drawing routine reads module-level colour globals in ui.py,
so applying a theme is just rebinding those globals (see ui.apply_theme) - no
drawing code changes.

These are *inspired-by* palettes only: original colour choices, no logos, fonts,
or trade dress from any product.  Names are deliberately generic for the same
reason (e.g. "Breadbin Blue", "LCARS Console" are evocative, not affiliated).
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Dict, Tuple

RGB = Tuple[int, int, int]

_SEV_DEFAULT = {"high": (255, 90, 90), "medium": (255, 176, 0),
                "low": (240, 215, 90), "info": (110, 180, 255)}


@dataclass
class Theme:
    name: str
    label: str
    blurb: str = ""
    paid: bool = False
    # --- chrome: case / keycaps / legends -----------------------------------
    CASE: RGB = (201, 197, 188)
    CASE_HI: RGB = (223, 220, 212)
    CASE_LO: RGB = (150, 147, 139)
    PLATE: RGB = (210, 207, 199)
    KEY_FACE: RGB = (198, 195, 187)
    KEY_HI: RGB = (226, 223, 216)
    KEY_LO: RGB = (150, 148, 141)
    KEY_DARK: RGB = (128, 126, 120)
    LEGEND: RGB = (52, 50, 46)
    LEGEND_DIM: RGB = (104, 101, 95)
    NAMEPLATE: RGB = (182, 179, 171)
    IBM_BLUE: RGB = (36, 74, 140)          # "accent" (active / selected / links)
    IBM_RED: RGB = (170, 44, 46)           # power / warn / logo
    # --- dark readout / popup / screen-text family --------------------------
    BG: RGB = (8, 12, 10)
    PANEL: RGB = (14, 22, 16)
    PANEL_HI: RGB = (22, 34, 24)
    LINE: RGB = (34, 54, 38)
    FG: RGB = (150, 230, 165)              # text on dark readouts / popups
    DIM: RGB = (95, 145, 105)
    ACCENT: RGB = (60, 230, 120)
    AMBER: RGB = (255, 176, 0)
    WARN: RGB = (255, 90, 90)
    CONSOLE_TEXT: RGB = (140, 225, 255)
    SCREEN_BG: RGB = (10, 14, 11)          # OUTPUT / PACKETS inset fill
    SEVCOL: dict = field(default_factory=lambda: dict(_SEV_DEFAULT))
    # --- terminal glass ------------------------------------------------------
    screen_mode: str = "green"             # phosphor tint key (see config.PALETTES)
    screen_field: RGB = (0, 0, 0)          # glass background colour
    screen_palette: dict = None            # optional per-cell text colours (colour_name -> rgb)
    key_pf: RGB = None                     # optional PF/keypad keycap colour (e.g. BBC red)
    key_pf_fg: RGB = None                  # optional PF/keypad legend colour (e.g. BBC black)
    key_outline: RGB = None                # optional thin surround on PF/AID keycaps
    header: RGB = None                     # wordmark colour (defaults to LEGEND)
    field_fg: RGB = None                   # input-field text colour (defaults to LEGEND)
    wordmark: str = None                   # header text override (defaults to "PHOSPHOR")
    logo: str = None                       # optional brand logo asset (filename in app/assets)

    def chrome_dict(self) -> Dict[str, object]:
        skip = {"name", "label", "blurb", "paid", "screen_mode", "screen_field", "wordmark", "logo"}
        return {f.name: getattr(self, f.name) for f in fields(self) if f.name not in skip}


# ---------------------------------------------------------------------------
# The Phosphor Skins set.  Free skins ship with the tool; paid skins are the
# add-on pack.  Tune on real hardware - these are strong first-cut palettes.
# ---------------------------------------------------------------------------
THEMES: Dict[str, Theme] = {}


def _add(t: Theme):
    THEMES[t.name] = t


# 1. Classic 3270 - the default (IBM Model M workstation + dark 3270 monitor).
_add(Theme(
    name="classic", label="Classic 3270",
    blurb="Model M keycaps, beige case, green 3270 glass.",
))

# 2. Green Room - the original all-green phosphor terminal look.
_add(Theme(
    name="green", label="Green Room",
    blurb="The original: dark green phosphor throughout.",
    CASE=(8, 12, 10), CASE_HI=(30, 46, 34), CASE_LO=(4, 8, 6),
    PLATE=(14, 22, 16), KEY_FACE=(24, 32, 27), KEY_HI=(40, 58, 44),
    KEY_LO=(10, 16, 12), KEY_DARK=(18, 26, 21),
    LEGEND=(168, 212, 178), LEGEND_DIM=(95, 145, 105), NAMEPLATE=(6, 10, 8),
    IBM_BLUE=(60, 230, 120), IBM_RED=(255, 90, 90),
    screen_mode="green",
))

# 3. Amber Glass - amber monochrome CRT.
_add(Theme(
    name="amber", label="Amber Glass",
    blurb="Warm amber phosphor, dark chassis.",
    paid=True,
    CASE=(14, 10, 4), CASE_HI=(52, 38, 12), CASE_LO=(8, 6, 2),
    PLATE=(22, 16, 6), KEY_FACE=(38, 28, 10), KEY_HI=(64, 48, 18),
    KEY_LO=(16, 12, 4), KEY_DARK=(28, 20, 8),
    LEGEND=(255, 202, 120), LEGEND_DIM=(176, 130, 60), NAMEPLATE=(12, 9, 3),
    IBM_BLUE=(255, 176, 0), IBM_RED=(255, 120, 70),
    BG=(14, 10, 4), PANEL=(24, 17, 6), LINE=(70, 50, 16),
    FG=(255, 196, 96), DIM=(176, 130, 50), ACCENT=(255, 176, 0),
    AMBER=(255, 200, 90), WARN=(255, 120, 70), CONSOLE_TEXT=(255, 210, 130),
    SCREEN_BG=(14, 10, 4), screen_mode="amber",
))

# 4. Workstation Grey - serious, neutral developer grey (NeXT / SGI feel).
_add(Theme(
    name="grey", label="Workstation Grey",
    blurb="Cool neutral grey, understated and legible.",
    paid=True,
    CASE=(196, 198, 201), CASE_HI=(224, 226, 229), CASE_LO=(140, 142, 146),
    PLATE=(204, 206, 210), KEY_FACE=(192, 195, 200), KEY_HI=(222, 225, 230),
    KEY_LO=(142, 145, 150), KEY_DARK=(120, 123, 128),
    LEGEND=(40, 42, 46), LEGEND_DIM=(96, 99, 104), NAMEPLATE=(176, 179, 184),
    IBM_BLUE=(46, 90, 168), IBM_RED=(176, 52, 54),
    screen_mode="next", screen_field=(6, 8, 10),
))

# 5. Enterprise Z - modern professional, near-black with a cool blue accent (PAID).
_add(Theme(
    name="enterprise", label="Enterprise Z",
    blurb="Sleek enterprise black with a steel-blue accent.",
    paid=True,
    CASE=(24, 26, 30), CASE_HI=(44, 48, 54), CASE_LO=(12, 13, 16),
    PLATE=(30, 33, 38), KEY_FACE=(40, 44, 50), KEY_HI=(60, 66, 74),
    KEY_LO=(18, 20, 24), KEY_DARK=(30, 33, 38),
    LEGEND=(214, 220, 230), LEGEND_DIM=(130, 138, 150), NAMEPLATE=(18, 20, 24),
    IBM_BLUE=(64, 140, 240), IBM_RED=(230, 84, 88),
    BG=(14, 16, 20), PANEL=(22, 25, 30), LINE=(46, 52, 60),
    FG=(206, 224, 250), DIM=(120, 134, 156), ACCENT=(64, 140, 240),
    AMBER=(240, 190, 90), WARN=(230, 84, 88), CONSOLE_TEXT=(150, 210, 255),
    SCREEN_BG=(10, 12, 16), screen_mode="white", screen_field=(6, 8, 12),
))

# 6. Breadbin Blue - fun home-micro retro: tan case, iconic blue screen (PAID).
_add(Theme(
    name="c64", label="Breadbin Blue",
    blurb="Tan home-computer case with a periwinkle-on-blue screen.",
    paid=True,
    CASE=(201, 184, 152), CASE_HI=(224, 210, 182), CASE_LO=(150, 134, 104),
    PLATE=(208, 192, 160), KEY_FACE=(150, 122, 86), KEY_HI=(184, 158, 120),
    KEY_LO=(104, 82, 54), KEY_DARK=(120, 96, 66),
    LEGEND=(240, 232, 214), LEGEND_DIM=(96, 78, 52), NAMEPLATE=(180, 164, 132),
    IBM_BLUE=(72, 84, 196), IBM_RED=(176, 68, 60),
    BG=(38, 44, 140), PANEL=(48, 54, 150), PANEL_HI=(72, 80, 176),
    LINE=(90, 98, 190), FG=(158, 168, 255), DIM=(120, 130, 220),
    ACCENT=(158, 168, 255), AMBER=(230, 200, 120), WARN=(240, 130, 120),
    CONSOLE_TEXT=(170, 180, 255), SCREEN_BG=(40, 46, 142),
    screen_mode="c64", screen_field=(48, 54, 150),
))

# 7. LCARS Console - sci-fi ops console: black field, warm rounded key blocks (PAID).
_add(Theme(
    name="lcars", label="LCARS Console",
    blurb="Black console, bright orange blocks, lilac/salmon accents, orange screen.",
    CASE=(0, 0, 0), CASE_HI=(52, 34, 8), CASE_LO=(0, 0, 0),
    PLATE=(10, 8, 4), KEY_FACE=(255, 153, 84), KEY_HI=(255, 194, 140),
    KEY_LO=(198, 108, 48), KEY_DARK=(204, 110, 128),
    LEGEND=(18, 10, 2), LEGEND_DIM=(255, 153, 84), NAMEPLATE=(28, 20, 10),
    IBM_BLUE=(153, 153, 255), IBM_RED=(204, 110, 110),
    header=(255, 153, 84), field_fg=(255, 194, 150),
    BG=(0, 0, 0), PANEL=(10, 8, 6), PANEL_HI=(40, 26, 10),
    LINE=(200, 120, 40), FG=(255, 153, 0), DIM=(210, 150, 90), ACCENT=(255, 204, 102),
    AMBER=(255, 204, 102), WARN=(204, 110, 110), CONSOLE_TEXT=(153, 153, 255),
    SCREEN_BG=(0, 0, 0), screen_mode="lcars", screen_field=(0, 0, 0),
    key_pf=(153, 153, 255),                                     # lilac PF blocks
))

# 8. Cyberdeck - neon-on-black hacker demo mode (PAID).
_add(Theme(
    name="cyber", label="Cyberdeck",
    blurb="Neon green + magenta on black - the demo-mode look.",
    paid=True,
    CASE=(6, 8, 10), CASE_HI=(20, 30, 34), CASE_LO=(2, 4, 6),
    PLATE=(12, 16, 20), KEY_FACE=(20, 26, 32), KEY_HI=(36, 48, 56),
    KEY_LO=(8, 12, 16), KEY_DARK=(16, 22, 28),
    LEGEND=(120, 255, 180), LEGEND_DIM=(70, 150, 110), NAMEPLATE=(8, 12, 16),
    IBM_BLUE=(0, 230, 255), IBM_RED=(255, 60, 140),
    BG=(6, 8, 10), PANEL=(12, 16, 20), LINE=(30, 60, 70),
    FG=(120, 255, 180), DIM=(70, 160, 120), ACCENT=(0, 230, 255),
    AMBER=(180, 255, 60), WARN=(255, 60, 140), CONSOLE_TEXT=(0, 230, 255),
    SCREEN_BG=(4, 8, 8), screen_mode="cyber",
))

# 9. ISPF Blue - mainframe-native blue panel (free; fits the tool's home turf).
_add(Theme(
    name="ispf", label="ISPF Blue",
    blurb="Native mainframe blue panels, 3270 colour text.",
    paid=True,
    CASE=(28, 38, 62), CASE_HI=(48, 62, 92), CASE_LO=(16, 24, 42),
    PLATE=(36, 48, 76), KEY_FACE=(52, 66, 100), KEY_HI=(78, 96, 138),
    KEY_LO=(26, 36, 60), KEY_DARK=(40, 52, 82),
    LEGEND=(214, 224, 244), LEGEND_DIM=(140, 156, 190), NAMEPLATE=(24, 34, 58),
    IBM_BLUE=(96, 156, 255), IBM_RED=(230, 96, 96),
    BG=(8, 16, 40), PANEL=(16, 26, 54), PANEL_HI=(28, 40, 74),
    LINE=(48, 66, 108), FG=(120, 220, 150), DIM=(110, 140, 190),
    ACCENT=(96, 156, 255), AMBER=(240, 200, 90), WARN=(230, 96, 96),
    CONSOLE_TEXT=(120, 220, 255), SCREEN_BG=(8, 16, 40),
    screen_mode="colour", screen_field=(8, 16, 44),
))

# 10. Dark Ops - blacked-out tactical, red accents (PAID).
_add(Theme(
    name="darkops", label="Dark Ops",
    blurb="Blacked-out chassis, red accents, green glass.",
    paid=True,
    CASE=(16, 16, 18), CASE_HI=(34, 34, 38), CASE_LO=(8, 8, 10),
    PLATE=(22, 22, 25), KEY_FACE=(32, 32, 36), KEY_HI=(50, 50, 56),
    KEY_LO=(14, 14, 16), KEY_DARK=(24, 24, 27),
    LEGEND=(206, 208, 212), LEGEND_DIM=(120, 122, 128), NAMEPLATE=(14, 14, 16),
    IBM_BLUE=(90, 160, 240), IBM_RED=(232, 66, 66),
    BG=(10, 10, 12), PANEL=(18, 18, 21), LINE=(44, 44, 50),
    FG=(150, 230, 165), DIM=(110, 130, 116), ACCENT=(232, 66, 66),
    AMBER=(240, 180, 80), WARN=(232, 66, 66), CONSOLE_TEXT=(150, 210, 255),
    SCREEN_BG=(8, 10, 9), screen_mode="green",
))


# 11. Beeb Cream - 8-bit British micro: cream case, red function-key accent (PAID).
_add(Theme(
    name="bbc", label="BBC Micro B",
    blurb="Light micro case with bright RED function-key accents.",
    CASE=(225, 220, 206), CASE_HI=(241, 237, 226), CASE_LO=(170, 164, 148),
    PLATE=(229, 223, 209), KEY_FACE=(212, 205, 188), KEY_HI=(236, 231, 218),
    KEY_LO=(164, 157, 140), KEY_DARK=(206, 54, 40),
    LEGEND=(48, 44, 38), LEGEND_DIM=(108, 100, 86), NAMEPLATE=(200, 193, 176),
    IBM_BLUE=(214, 52, 40), IBM_RED=(196, 40, 34),
    BG=(14, 10, 10), PANEL=(24, 16, 16), PANEL_HI=(40, 24, 24),
    LINE=(70, 34, 32), FG=(240, 224, 220), DIM=(190, 130, 124),
    ACCENT=(224, 60, 46), AMBER=(240, 170, 90), WARN=(230, 70, 60),
    CONSOLE_TEXT=(255, 150, 130), SCREEN_BG=(8, 6, 6),
    screen_mode="colour", screen_field=(0, 0, 0),
    key_pf=(210, 52, 42), key_pf_fg=(0, 0, 0),                  # RED PF keys, BLACK legend
    screen_palette={
        "green": (235, 232, 224), "default": (235, 232, 224),   # base text -> off-white
        "white": (245, 244, 240), "neutral": (220, 216, 208),
        "blue": (120, 170, 255), "turquoise": (120, 210, 220),
        "red": (232, 60, 46), "yellow": (240, 176, 60), "pink": (232, 60, 46),   # RED highlights
    },
))


# 12. Bubblegum - hot-pink dollhouse workstation, green screen (FREE).
_add(Theme(
    name="pink", label="Bubblegum",
    blurb="Hot-pink dollhouse case, deep-magenta readouts, green screen.",
    CASE=(242, 190, 208), CASE_HI=(250, 216, 228), CASE_LO=(224, 140, 176),
    PLATE=(244, 206, 222), KEY_FACE=(248, 212, 226), KEY_HI=(255, 234, 242),
    KEY_LO=(228, 150, 186), KEY_DARK=(240, 128, 184),
    LEGEND=(150, 24, 86), LEGEND_DIM=(196, 96, 146), NAMEPLATE=(246, 200, 218),
    IBM_BLUE=(232, 48, 132), IBM_RED=(220, 40, 96),
    BG=(48, 4, 28), PANEL=(72, 10, 44), PANEL_HI=(96, 20, 60),
    LINE=(110, 30, 70), FG=(255, 176, 212), DIM=(210, 130, 170),
    ACCENT=(255, 90, 175), AMBER=(255, 150, 120), WARN=(255, 70, 120),
    CONSOLE_TEXT=(255, 180, 220), SCREEN_BG=(48, 6, 30),
    screen_mode="colour", screen_field=(0, 0, 0),
    screen_palette={
        "green": (255, 105, 175), "default": (255, 105, 175),   # base text -> pink
        "blue": (255, 150, 205), "turquoise": (255, 160, 210),
        "neutral": (255, 140, 195), "white": (255, 190, 222),
        "pink": (255, 120, 190),
        "red": (235, 45, 75), "yellow": (245, 90, 70),           # attention -> red highlights
    },
))


# 13. Grid - neon cyan-on-black light-cycle look (PAID).
_add(Theme(
    name="tron", label="Grid",
    blurb="Black grid with glowing cyan lines and an orange warning accent.",
    paid=True,
    CASE=(6, 10, 14), CASE_HI=(20, 40, 52), CASE_LO=(2, 6, 10),
    PLATE=(10, 16, 22), KEY_FACE=(14, 24, 32), KEY_HI=(34, 64, 82),
    KEY_LO=(4, 10, 16), KEY_DARK=(10, 18, 26),
    LEGEND=(140, 236, 255), LEGEND_DIM=(70, 150, 180), NAMEPLATE=(8, 14, 20),
    IBM_BLUE=(0, 224, 255), IBM_RED=(255, 130, 40),
    BG=(2, 8, 12), PANEL=(8, 16, 22), PANEL_HI=(16, 34, 46),
    LINE=(20, 70, 90), FG=(150, 238, 255), DIM=(80, 170, 200),
    ACCENT=(0, 224, 255), AMBER=(255, 150, 40), WARN=(255, 110, 60),
    CONSOLE_TEXT=(120, 236, 255), SCREEN_BG=(2, 10, 14),
    screen_mode="colour", screen_field=(0, 6, 10),
    screen_palette={
        "green": (0, 228, 255), "default": (0, 228, 255),       # base -> cyan
        "white": (180, 245, 255), "neutral": (120, 210, 230),
        "blue": (60, 180, 255), "turquoise": (0, 240, 240),
        "red": (255, 140, 40), "yellow": (255, 190, 60), "pink": (255, 140, 40),  # orange accents
    },
))

# 14. ZX Rubber - black micro, blue-grey rubber keys, rainbow accent (PAID).
_add(Theme(
    name="zx", label="ZX Rubber",
    blurb="Black rubber-key micro with a red/yellow/green/cyan rainbow accent.",
    paid=True,
    CASE=(20, 20, 22), CASE_HI=(44, 44, 48), CASE_LO=(8, 8, 10),
    PLATE=(28, 30, 32), KEY_FACE=(96, 122, 138), KEY_HI=(128, 156, 172),
    KEY_LO=(58, 78, 90), KEY_DARK=(74, 96, 110),
    LEGEND=(232, 236, 238), LEGEND_DIM=(150, 158, 164), NAMEPLATE=(16, 16, 18),
    IBM_BLUE=(0, 196, 224), IBM_RED=(220, 40, 40),
    BG=(10, 10, 12), PANEL=(18, 18, 20), PANEL_HI=(30, 30, 34),
    LINE=(46, 48, 52), FG=(236, 238, 240), DIM=(150, 156, 162),
    ACCENT=(64, 200, 96), AMBER=(240, 200, 60), WARN=(220, 40, 40),
    CONSOLE_TEXT=(0, 210, 230), SCREEN_BG=(6, 6, 8),
    screen_mode="colour", screen_field=(0, 0, 0),
    screen_palette={   # ZX bright palette on black
        "green": (0, 220, 0), "default": (220, 220, 220),
        "white": (255, 255, 255), "neutral": (200, 200, 200),
        "blue": (0, 110, 240), "turquoise": (0, 210, 210),
        "red": (232, 40, 40), "yellow": (240, 220, 40), "pink": (232, 40, 200),
    },
))

# 15. Mainframe Z - blacked-out big-iron with a bright electric-blue accent (FREE).
_add(Theme(
    name="z17", label="Mainframe Z",
    blurb="Black mainframe chassis, silver edges, electric-blue accent, green screen.",
    CASE=(18, 18, 20), CASE_HI=(74, 78, 86), CASE_LO=(8, 8, 10),
    PLATE=(26, 27, 30), KEY_FACE=(40, 42, 48), KEY_HI=(84, 88, 98),
    KEY_LO=(18, 19, 22), KEY_DARK=(30, 31, 35),
    LEGEND=(224, 228, 236), LEGEND_DIM=(140, 146, 156), NAMEPLATE=(14, 15, 18),
    IBM_BLUE=(0, 112, 240), IBM_RED=(224, 72, 72),
    BG=(10, 11, 13), PANEL=(18, 20, 24), PANEL_HI=(30, 34, 42),
    LINE=(44, 50, 60), FG=(150, 230, 165), DIM=(120, 150, 170),
    ACCENT=(0, 132, 255), AMBER=(240, 190, 90), WARN=(224, 72, 72),
    CONSOLE_TEXT=(120, 200, 255), SCREEN_BG=(8, 10, 12),
    screen_mode="green", screen_field=(0, 0, 0),
))


# 16. Vertali - white chassis, Vertali's two brand greens, green screen (FREE).
# Colours sampled from the Vertali logo: lime-green hexagon (128,188,0) and the
# dark-teal "VERTALI" wordmark (0,101,72), on a white background.  Customer skin
# added at the user's request; colour scheme + wordmark + a drawn hex mark only,
# no actual logo file or other trade dress.
_V_LIME = (138, 205, 0)                    # #8ACD00 hexagon / bright accent
_V_TEAL = (0, 120, 95)                     # #00785F wordmark / primary brand green
_add(Theme(
    name="vertali", label="Vertali", wordmark="vertali",
    blurb="Vertali: white chassis, lime + dark-teal brand greens, green screen.",
    CASE=(244, 244, 244), CASE_HI=(255, 255, 255), CASE_LO=(206, 210, 206),
    PLATE=(236, 238, 236), KEY_FACE=(250, 251, 249), KEY_HI=(255, 255, 255),
    KEY_LO=(205, 210, 205), KEY_DARK=(150, 160, 150),
    LEGEND=_V_TEAL, LEGEND_DIM=(92, 148, 130), NAMEPLATE=(232, 236, 232),
    IBM_BLUE=_V_TEAL, IBM_RED=(198, 60, 48),   # active / links / underline = dark teal
    BG=(8, 16, 12), PANEL=(14, 24, 18), PANEL_HI=(22, 36, 28),
    LINE=(34, 60, 46), FG=(160, 222, 170), DIM=(110, 160, 130),
    ACCENT=_V_LIME, AMBER=(210, 180, 70), WARN=(210, 80, 66),
    CONSOLE_TEXT=(160, 214, 120), SCREEN_BG=(0, 0, 0),
    screen_mode="green", screen_field=(0, 0, 0),
    header=_V_TEAL,                        # dark-teal "vertali" wordmark
))


# 17. Covert Access Team - matte-black tactical chassis, brand-red accents, white legends.
# Brand skin for Covert Access Team (covertaccessteam.com): their red logo on black, a
# covert-entry / black-team aesthetic.  Colour scheme + wordmark only; no logo file.
_CAT_RED = (206, 32, 38)                    # Covert Access Team brand red
_add(Theme(
    name="covertaccess", label="Covert Access Team", wordmark="COVERT ACCESS TEAM",
    logo="logo_covertaccess.png",
    blurb="Covert Access Team: matte-black tactical chassis, brand-red accents, white legends.",
    paid=True,
    CASE=(18, 18, 20), CASE_HI=(46, 46, 50), CASE_LO=(8, 8, 10),
    PLATE=(24, 24, 26), KEY_FACE=(38, 38, 42), KEY_HI=(70, 70, 76),
    KEY_LO=(20, 20, 24), KEY_DARK=(28, 28, 32),
    LEGEND=(226, 228, 230), LEGEND_DIM=(140, 142, 146), NAMEPLATE=(14, 14, 16),
    IBM_BLUE=_CAT_RED, IBM_RED=_CAT_RED,       # accent / links / selection = brand red
    BG=(14, 12, 12), PANEL=(22, 18, 18), PANEL_HI=(34, 26, 26),
    LINE=(64, 40, 40), FG=(228, 230, 233), DIM=(150, 120, 120),
    ACCENT=_CAT_RED, AMBER=(230, 160, 70), WARN=(240, 80, 80),
    CONSOLE_TEXT=(238, 130, 130), SCREEN_BG=(10, 8, 8),
    screen_mode="colour", screen_field=(10, 7, 7),
    screen_palette={
        "green": (232, 234, 236), "default": (232, 234, 236),   # base -> white
        "white": (248, 249, 250), "neutral": (188, 190, 194),
        "blue": (210, 90, 92), "turquoise": (230, 150, 150),
        "red": (230, 46, 50), "yellow": (236, 180, 90), "pink": (236, 120, 140),
        "amber": (232, 150, 70),
    },
    key_pf=_CAT_RED, key_pf_fg=(245, 245, 245),   # red PF/keypad keys, white legend
    header=_CAT_RED,                              # brand-red wordmark
))

# 18. Graphite - charcoal chassis, warm-white legends, restrained blue accent (PAID).
_add(Theme(
    name="graphite", label="Graphite", wordmark="PHOSPHOR",
    blurb="Sleek charcoal-graphite chassis, warm-white legends, subtle blue accent.",
    paid=True,
    CASE=(38, 39, 42), CASE_HI=(70, 72, 78), CASE_LO=(20, 21, 23),
    PLATE=(30, 31, 34), KEY_FACE=(52, 54, 58), KEY_HI=(92, 95, 102),
    KEY_LO=(26, 27, 30), KEY_DARK=(38, 39, 43),
    LEGEND=(224, 224, 220), LEGEND_DIM=(150, 150, 146), NAMEPLATE=(24, 25, 27),
    IBM_BLUE=(90, 150, 220), IBM_RED=(210, 90, 84),
    BG=(14, 15, 17), PANEL=(22, 23, 26), PANEL_HI=(34, 36, 40),
    LINE=(50, 52, 58), FG=(222, 226, 230), DIM=(150, 156, 162),
    ACCENT=(96, 158, 230), AMBER=(232, 196, 110), WARN=(220, 96, 90),
    CONSOLE_TEXT=(150, 196, 240), SCREEN_BG=(10, 11, 13),
    screen_mode="colour", screen_field=(0, 0, 0),
    screen_palette={
        "green": (224, 228, 232), "default": (224, 228, 232),   # base -> warm white
        "white": (248, 250, 252), "neutral": (188, 194, 200),
        "blue": (120, 170, 235), "turquoise": (110, 205, 220),
        "red": (232, 120, 110), "yellow": (238, 205, 120), "pink": (226, 150, 205),
    },
))


# 19. HVCK - heavy red chassis, white keycaps, neon-green legends + screen text.
# Brand skin for HVCK magazine ("a celebration of digital counter culture"): matches the
# cover - red field, neon-green wordmark and text.  Colour scheme + wordmark only.
_add(Theme(
    name="hvck", label="HVCK Magazine", wordmark="HVCK Magazine",
    logo="logo_hvck.png",
    blurb="HVCK Magazine: dark-grey surround, red panels, white keycaps, neon-green text.",
    paid=True,
    CASE=(46, 46, 48), CASE_HI=(72, 72, 76), CASE_LO=(28, 28, 30),   # dark-grey surround
    PLATE=(120, 14, 18), KEY_FACE=(240, 240, 238), KEY_HI=(255, 255, 255),   # panels stay red
    KEY_LO=(198, 198, 196), KEY_DARK=(168, 168, 166),
    LEGEND=(24, 150, 30), LEGEND_DIM=(96, 140, 96), NAMEPLATE=(110, 12, 16),
    IBM_BLUE=(30, 200, 50), IBM_RED=(220, 40, 40),      # accent = neon green
    BG=(30, 6, 8), PANEL=(44, 8, 10), PANEL_HI=(60, 12, 14),
    LINE=(96, 20, 22), FG=(90, 240, 100), DIM=(70, 150, 78),
    ACCENT=(50, 230, 70), AMBER=(255, 180, 0), WARN=(255, 90, 90),
    CONSOLE_TEXT=(120, 245, 130), SCREEN_BG=(26, 5, 7),
    screen_mode="colour", screen_field=(20, 4, 6),
    screen_palette={
        "green": (80, 240, 90), "default": (80, 240, 90),       # base -> neon green
        "white": (235, 255, 235), "neutral": (150, 210, 150),
        "blue": (90, 220, 120), "turquoise": (80, 235, 160),
        "red": (255, 120, 110), "yellow": (240, 220, 90), "pink": (255, 140, 180),
        "amber": (240, 200, 80),
    },
    key_pf=(240, 240, 238), key_pf_fg=(24, 150, 30),    # white PF keys, green legend
    key_outline=(0, 0, 0),                              # thin black surround on all keys
    header=(70, 235, 80),                               # neon-green HVCK wordmark
))


DEFAULT_THEME = "classic"
ORDER = ["classic", "green", "lcars", "pink", "bbc", "z17",
         "amber", "grey", "ispf", "enterprise", "c64", "cyber", "darkops",
         "tron", "zx", "vertali", "covertaccess", "graphite", "hvck"]
