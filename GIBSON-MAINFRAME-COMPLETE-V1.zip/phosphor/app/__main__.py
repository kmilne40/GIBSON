"""PHOSPHOR integrated client - pygame driver.

Deliberately thin: it opens a window, and each frame it asks the (tested) UI
compositor for an image + hit-map, blits the image, and routes clicks/keys to
action handlers that drive the (tested) engine.  pygame draws via SDL2 (bundled
in its wheel) with no OpenGL, so this needs no system GL libraries.

    pip install pygame numpy pillow
    python -m phosphor.app            # or the 'phosphor-app' command
"""
from __future__ import annotations

import os
import sys
import threading
import time

from phosphor.app.ui import (AppState, render_app_frame, render_terminal_only,
                             WIN_W, WIN_H, TERM_W, TERM_H, pixel_to_cell, CODEPAGES)
from phosphor.app.crt_render import SoftCRT
from phosphor.app.lineedit import LineEditor
from phosphor.app import favourites as favs
from phosphor.app import notes as notesmod


def _run_bg(fn):
    threading.Thread(target=fn, daemon=True).start()


_NMAP_MAP = {"vtam": "vtam-enum", "tso": "tso-enum", "cics": "cics-enum",
             "cics_users": "cics-user-enum", "cics_info": "cics-info",
             "ftp": "ftp-anon", "db2": "db2-das-info", "scan_all": None}


def nmap_command(wid, host, port):
    """The exact nmap command this scan is equivalent to (book syntax)."""
    try:
        from phosphor.recon_menu import REGISTRY
        sid = _NMAP_MAP.get(wid)
        for s in REGISTRY:
            if s.id == sid:
                vals = {o.key: o.default for o in s.opts}
                if "userdb" in vals and not vals["userdb"]:
                    vals["userdb"] = "users.txt"
                return s.nmap(host, port, vals)
    except Exception:
        return None
    return None


class Client:
    def __init__(self):
        self.state = AppState()
        self.state.favourites = favs.load()
        self.state.tool_status = {}
        # tool discovery shells out to `which` for each tool; do it off the
        # startup path so the window paints immediately instead of stalling.
        def _probe_tools():
            try:
                from phosphor.toolchain import tool_status
                self.state.tool_status = tool_status()
            except Exception:
                self.state.tool_status = {}
        _run_bg(_probe_tools)
        self.crt = SoftCRT(self.state.cfg, (TERM_W, TERM_H))
        self.conn = None            # TN3270Client when connected
        self.editor = None          # FieldEditor for on-screen 3270 input
        self._findings = []

    # ---- engine actions (each is small; the engine underneath is tested) --
    def _refresh_grid(self):
        if self.editor:
            try:
                self.state.grid = self.editor.grid_with_edits()
                self.state.cursor_rc = tuple(self.editor.cursor)   # for the blinking glass cursor
                self._trace_screen()
            except Exception as e:
                self.state.note(f"screen error: {e}")
        elif self.conn is not None:
            # 5250 (or any editor-less session): draw straight from the buffer
            try:
                self.state.grid = [[(c, col) for (c, col, _hl) in row]
                                   for row in self.conn.colour_grid()]
            except Exception as e:
                self.state.note(f"screen error: {e}")

    def connect(self):
        s = self.state
        if s.connected:
            try:
                self.conn.terminate()
            except Exception:
                pass
            self._stop_hack3270()
            self.conn = None
            s.connected = False
            s.status = "not connected"
            return

        def work():
            from phosphor.protocols.tn3270.client import TN3270Client
            from phosphor.protocols.tn5250.client import TN5250Client
            is5250 = (s.protocol == "5250")
            use_tnz = (getattr(s, "engine", "native") == "tnz") and not is5250
            try:
                s.status = f"connecting to {s.host}:{s.port}..."
                if use_tnz:
                    # IBM tnz engine for real z/OS / zPDT (3270 only). The live pcap
                    # tap and hack3270 proxy are native-engine features, skipped here.
                    from phosphor.session import make_connection
                    c = make_connection("3270", "tnz")
                    c.packets = []
                    s.packets = c.packets
                else:
                    if is5250:
                        c = TN5250Client()
                    else:
                        from phosphor.protocols.tn3270.client import client_for_model
                        c = client_for_model(getattr(s, "term_model", "2"))
                    c.packets = []
                    s.packets = c.packets
                    if s.capture_on and getattr(self, "_pcap", None):
                        c.pcap = self._pcap        # keep capturing across a reconnect
                    if not is5250 and (s.h3_unprotect or s.h3_unhide):
                        c.manip = {"unprotect": s.h3_unprotect, "unhide": s.h3_unhide}
                target_host, target_port = s.host, int(s.port)
                # TLS: honour state toggles and x3270-style host prefixes (L:/Y:)
                from phosphor.protocols import tls as _tls
                tgt = _tls.parse_target(target_host)
                target_host = tgt.host
                use_tls = tgt.tls or getattr(s, "tls", False) or _tls.default_secure_port(target_port)
                tls_verify = tgt.verify and getattr(s, "tls_verify", True)
                tls_accept = tgt.accept_hostname or (getattr(s, "tls_accept_hostname", "") or None)
                if not is5250 and not use_tnz and s.h3_proxy:   # hack3270 proxy is native 3270-only
                    target_host, target_port = self._start_hack3270(target_host, target_port)
                    use_tls = False        # proxy terminates locally in clear text
                if use_tls and not use_tnz:
                    c.connect(target_host, target_port, tls=True, tls_verify=tls_verify,
                              tls_accept_hostname=tls_accept)
                    if not tls_verify:
                        s.note("TLS: certificate NOT verified (testing mode)")
                elif getattr(s, "tls_starttls", False) and not use_tnz and not is5250:
                    c.connect(target_host, target_port, tls_starttls=True,
                              tls_verify=tls_verify, tls_accept_hostname=tls_accept)
                    s.note("TLS: negotiated STARTTLS" + ("" if tls_verify else " (unverified)"))
                else:
                    c.connect(target_host, target_port)
                self.conn = c
                from phosphor.session import make_editor
                self.editor = make_editor(c)   # tnz gets the tnz-native editor
                s.connected = True
                s.focus = "screen"             # so you can type on the panel right away
                s.status = f"connected to {s.host}:{s.port}"
                s.note("connected (EBCDIC / " + ("TN5250" if is5250 else "TN3270") + ")")
                self._refresh_grid()
            except Exception as e:
                s.status = f"connect failed: {e}"
                s.note(str(e))
        _run_bg(work)

    def send_command(self):
        if not self.conn:
            return
        cmd = self.state.cmdline
        self.state.cmdline = ""

        def work():
            try:
                if cmd:
                    self.conn.send_string(cmd)
                self.conn.send_enter()
                self._refresh_grid()
            except Exception as e:
                self.state.note(f"send error: {e}")
        _run_bg(work)

    def run_tool(self, wid):
        s = self.state
        if not s.host:
            s.note("set a host first")
            return

        def work():
            from phosphor.audit import enumerate as au
            host, port = s.host, int(s.port)
            got = []
            try:
                self.console_open(f"{wid}  -  {s.host}:{s.port}")
                cmd = nmap_command(wid, host, port)
                s.console_cmd = cmd or ""
                if cmd:
                    self.console_line("# full nmap command that this runs:")
                    self.console_line("  " + cmd)
                    self.console_line("")
                self.console_line(f"# running native engine against {s.host}:{s.port} ...")
                self.console_line("")
                s.status = f"running {wid}..."
                if wid == "vtam":
                    got = au.vtam_applids(host, port)
                elif wid == "tso":
                    got = au.tso_users(host, port)
                elif wid == "cics":
                    got = au.cics_transactions(host, port)
                elif wid == "cics_users":
                    got = au.cics_users(host, port)
                elif wid == "cics_info":
                    got = au.cics_region_info(host, port)
                elif wid == "ftp":
                    r = au.ftp_anon(host, 21); got = [r] if r else []
                elif wid == "db2":
                    r = au.db2_das_info(host, 50000); got = [r] if r else []
                elif wid == "scan_all":
                    got = [au.tn3270_screen(host, port)]
                    got += au.vtam_applids(host, port)
                    got += au.tso_users(host, port)
                    got += au.cics_region_info(host, port)
                got = [g for g in got if g]
                self._findings = self._findings + got
                s.findings = len(self._findings)
                s.results = self._findings
                for g in got:
                    self.console_line(f"[{g.severity.upper():6}] {g.title}")
                    if getattr(g, "detail", ""):
                        self.console_line(f"         {g.detail}")
                    if getattr(g, "evidence", ""):
                        for ev in str(g.evidence).strip().splitlines()[:6]:
                            self.console_line(f"         | {ev}")
                    self.console_line("")
                self.console_line(f"-- {len(got)} finding(s) --")
                s.status = f"{wid}: {len(got)} finding(s)"
                if not got:
                    self.console_line("no findings")
            except Exception as e:
                self.console_line("")
                self.console_line(f"ERROR: {e}")
                self.console_line("(check the host/port are reachable)")
                s.note(f"{wid} error: {e}")
                s.status = "scan error"
        _run_bg(work)

    def transfer(self, upload: bool):
        if not self.conn:
            self.state.note("connect and log into TSO (READY) first"); return
        from phosphor.app import filepick
        binary = (self.state.xfer_mode == "binary")

        def flow():
            # entire picker + transfer runs in a background thread, so the pygame
            # loop never blocks (the old Tk-on-main-thread dialog is what hung).
            try:
                if upload:
                    local = filepick.open_file("Choose local file to upload")
                    if not local:
                        return
                    dsn = filepick.ask_text("Upload", "Target dataset name:")
                    if not dsn:
                        return
                else:
                    dsn = filepick.ask_text("Download", "Dataset name to download:")
                    if not dsn:
                        return
                    ext = ".bin" if binary else ".txt"
                    local = filepick.save_file("Save as", dsn.replace(".", "_") + ext)
                    if not local:
                        return
            except Exception as e:
                self.state.note(f"file dialog unavailable: {e}"); return
            self._do_transfer(upload, local, dsn, binary=binary)

        self.state.note(f"transfer ({'BINARY' if binary else 'ASCII'}) - see dialog")
        _run_bg(flow)

    def _do_transfer(self, upload: bool, local: str, dsn: str, binary: bool = False):
        """The actual IND$FILE transfer (no UI) - testable on its own."""
        s = self.state
        try:
            from phosphor.protocols.indfile.dft import IndFileClient
            ind = IndFileClient(self.conn)
            if upload:
                s.status = f"uploading -> {dsn}..."
                with open(local, "rb") as f:
                    data = f.read()
                ok = ind.put(dsn, data, binary=binary)
                s.note(f"upload {'ok' if ok else 'failed'}: {dsn}")
            else:
                s.status = f"downloading {dsn}..."
                data = ind.get(dsn, binary=binary)
                if not binary:
                    try:
                        data = data.decode("cp037").replace("\x15", "\n").encode("utf-8")
                    except Exception:
                        pass
                with open(local, "wb") as f:
                    f.write(data)
                s.note(f"downloaded {dsn} ({len(data)} bytes)")
            s.status = f"connected to {s.host}:{s.port}"
            self._refresh_grid()
        except Exception as e:
            s.note(f"transfer error: {e}")
            s.status = "transfer failed"

    def save_report(self):
        found = getattr(self, "_findings", [])
        if not found:
            self.state.note("no findings to report")
            return

        def work():
            from phosphor.report import write_report
            path = "phosphor_report.html"
            write_report(found, path, f"{self.state.host}:{self.state.port}")
            self.state.note(f"report saved: {path}")
        _run_bg(work)

    def set_colour(self, colour):
        self.state.colour = colour

    def bump_font(self, delta):
        self.state.font_px = max(12, min(48, self.state.font_px + delta))
        if self.crt is not None:
            self.crt._app_sig = None          # re-render the glass at the new size
        self._save_prefs()

    def cycle_codepage(self):
        i = (CODEPAGES.index(self.state.codepage) + 1) % len(CODEPAGES) \
            if self.state.codepage in CODEPAGES else 0
        self.state.codepage = CODEPAGES[i]

    # ---- favourites ------------------------------------------------------
    def save_favourite(self):
        s = self.state
        if not s.host:
            s.note("set a host first"); return
        from phosphor.app import filepick

        def flow():
            name = filepick.ask_text("Save connection", "Name:", s.host) or s.host
            s.favourites = favs.add(name, s.host, s.port, s.codepage)
            s.note(f"saved favourite: {name}")
        _run_bg(flow)

    def load_favourite(self, name):
        for f in self.state.favourites:
            if f["name"] == name:
                self.state.host = f["host"]; self.state.port = str(f["port"])
                self.state.codepage = f.get("codepage", "cp037 (EBCDIC)")
                self.connect(); return

    def remove_favourite(self, name):
        self.state.favourites = favs.remove(name)

    # ---- keypad ----------------------------------------------------------
    def keypad(self, key):
        ed = self.editor
        if not ed:
            return
        if key.startswith("pf"):
            ed.pf(int(key[2:]))
        elif key.startswith("pa"):
            ed.pa(int(key[2:]))
        elif key in ("enter", "newline"):
            ed.enter()
        elif key == "clear":
            ed.clear()
        elif key == "tab":
            ed.tab()
        elif key == "eeof":
            ed.erase_eof()
        elif key == "einp":
            ed._edits.clear()
        elif key == "attn":
            ed.pa(1)
        elif key in ("up", "down", "left", "right"):
            r, c = ed.cursor
            r += (key == "down") - (key == "up")
            c += (key == "right") - (key == "left")
            ed.cursor = (max(1, min(24, r)), max(1, min(80, c)))
        self._refresh_grid()

    # ---- console / trace / clipboard ------------------------------------
    def _popup_scroll(self, y):
        """Mouse-wheel / key scroll for whichever scrollable popup is open.
        y > 0 is wheel-up (toward older / top)."""
        s = self.state
        step = 3
        if s.console_open:                       # PCAP / report / findings / inject - bottom-anchored
            s.console_scroll = max(0, s.console_scroll + y * step)
        elif s.help_open:
            s.help_scroll = max(0, getattr(s, "help_scroll", 0) - y * step)
        elif s.themes_open:
            s.themes_scroll = max(0, getattr(s, "themes_scroll", 0) - y)
        elif s.notes_open:
            s.notes_scroll = max(0, getattr(s, "notes_scroll", 0) - y * step)

    def console_open(self, title):
        self.state.console_title = title
        self.state.console_lines = []
        self.state.console_scroll = 0
        self.state.console_open = True

    def _grab_screen_text(self):
        """The current 3270/5250 screen as plain text (rstrip'd rows)."""
        if not self.state.grid:
            return ""
        return "\n".join("".join(ch for ch, *_ in row).rstrip() for row in self.state.grid).rstrip()

    def capture_screen(self):
        """Snapshot the current terminal screen for the report."""
        if not hasattr(self, "_captures"):
            self._captures = []
        txt = self._grab_screen_text()
        if not txt.strip():
            self.state.note("nothing on screen to capture"); return
        import time as _t
        label = f"{self.state.host or 'host'} @ {_t.strftime('%H:%M:%S')}"
        self._captures.append((label, txt))
        self.state.note(f"captured screen #{len(self._captures)}")

    def _open_finding(self, idx):
        """Show a single finding's detail in the scrollable console."""
        try:
            fnd = self.state.results[idx]
        except Exception:
            return
        self.console_open("FINDING")
        self.console_line(getattr(fnd, "title", str(fnd)))
        self.console_line("severity: " + str(getattr(fnd, "severity", "info")))
        for attr in ("host", "port", "detail", "description", "evidence", "recommendation"):
            v = getattr(fnd, attr, None)
            if v:
                self.console_line("")
                self.console_line(f"{attr}:")
                for line in str(v).splitlines() or [str(v)]:
                    self.console_line("  " + line)

    def pentest_report(self):
        """Build a markdown pen-test report from notes + captured screens +
        findings, save it, and preview it in the console."""
        from phosphor.app import notes as notesmod
        import time as _t
        s = self.state
        caps = getattr(self, "_captures", [])
        try:
            note_text = notesmod.load_notes()
        except Exception:
            note_text = getattr(s, "notes_text", "") or ""

        md = []
        md.append(f"# PHOSPHOR Pen-Test Report")
        md.append("")
        md.append(f"- **Target:** {s.host or '(not set)'}:{s.port}")
        md.append(f"- **Protocol:** {'TN5250' if s.protocol == '5250' else 'TN3270'}")
        md.append(f"- **Generated:** {_t.strftime('%Y-%m-%d %H:%M:%S')}")
        md.append(f"- **Findings:** {len(s.results)}   **Screens captured:** {len(caps)}")
        md.append("")
        md.append("## Findings")
        if s.results:
            for i, f in enumerate(s.results, 1):
                sev = str(getattr(f, "severity", "info")).upper()
                md.append(f"### {i}. [{sev}] {getattr(f, 'title', str(f))}")
                for attr in ("host", "port", "detail", "description", "evidence", "recommendation"):
                    v = getattr(f, attr, None)
                    if v:
                        md.append(f"- **{attr.title()}:** {v}")
                md.append("")
        else:
            md.append("_No findings recorded._\n")
        md.append("## Captured screens")
        if caps:
            for label, txt in caps:
                md.append(f"### {label}")
                md.append("```")
                md.append(txt)
                md.append("```")
                md.append("")
        else:
            md.append("_No screens captured. Use Grab to snapshot a screen._\n")
        md.append("## Notes")
        md.append((note_text.strip() or "_No notes._"))
        md.append("")
        report = "\n".join(md)

        # preview in the console
        self.console_open("PEN-TEST REPORT (markdown)")
        for line in report.splitlines():
            self.console_line(line)

        # save to disk (off-thread picker; falls back to the output dir)
        def _save():
            path = None
            try:
                from phosphor.app import filepick
                path = filepick.save_file("Save pen-test report", "phosphor-report.md")
            except Exception:
                path = None
            if not path:
                try:
                    path = str(notesmod.tools_dir() / "phosphor-report.md")
                except Exception:
                    path = "phosphor-report.md"
            try:
                with open(path, "w") as fh:
                    fh.write(report)
                s.note(f"report saved: {path}")
            except Exception as e:
                s.note(f"report save error: {e}")
        _run_bg(_save)

    def _open_packet_log(self):
        """Expand the packet monitor into the scrollable console view."""
        from phosphor.app.packets import format_packets
        from phosphor.app import notes as notesmod
        self.console_open("PACKETS  (EBCDIC / ASCII)")
        self.state.console_mode = "packets"
        tdir = notesmod.tools_dir()
        if self.state.capture_on and self.state.capture_path:
            self.console_line(f"# recording .pcap -> {self.state.capture_path}")
        else:
            self.console_line(f"# 'Capture PCAP' saves a .pcap into: {tdir}")
        self.console_line("# 'Copy all' copies these lines (or saves a .txt here if no clipboard tool)")
        self.console_line("")
        pkts = self.state.packets or []
        if not pkts:
            self.console_line("(no packets captured yet - connect to a host)")
        for direction, line in format_packets(pkts, width=64, max_lines=1500):
            self.console_line(("  > " if direction == ">" else "  < ") + line)

    def console_line(self, text):
        self.state.console_lines.append(text)
        self.state.console_lines = self.state.console_lines[-2000:]
        if self.state.console_scroll > 0:        # keep the viewport put while scrolled up
            self.state.console_scroll += 1

    def run_console_cmd(self):
        """Execute the (editable) console command and stream its real output."""
        cmd = self.state.console_cmd.strip()
        if not cmd:
            return
        # EZrecon console: the command box runs a recon OPERATION, not a shell
        # command - "dns example.com", "subs vertali.com", "shodan_host 8.8.8.8".
        if self.state.console_mode == "ezrecon":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_ezrecon(cmd)
            return
        # live GIBSON DB2 shell (WebSocket): "gibson [host] [port]" opens it, then
        # every line (LOGIN ... first, then SQL) goes down the socket
        if self.state.console_mode == "sql" and cmd.split()[:1] == ["gibson"]:
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._db2ws_open(cmd.split()[1:])
            return
        if self.state.console_mode == "sql" and cmd.split()[:1] == ["drda"]:
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_drda(cmd.split()[1:])
            return
        if self.state.console_mode == "sql" and cmd.split()[:1] == ["connect"]:
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._drdasql_open(cmd.split()[1:])
            return
        if self.state.console_mode == "drdasql":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_drdasql(cmd)
            return
        if self.state.console_mode == "db2ws":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_db2ws(cmd)
            return
        if self.state.console_mode == "nje":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_nje(cmd)
            return
        if self.state.console_mode == "passticket":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_passticket(cmd)
            return
        if self.state.console_mode == "localshell":
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            self._run_localshell(cmd)
            return
        # if a reverse shell is connected, the console drives the shell instead
        sh = getattr(self, "_shell", None)
        if sh is not None and sh.connected:
            self.console_line(f"shell> {cmd}")
            sh.send(cmd)
            self.state.console_cmd = ""
            self.state.field_cursor["console_cmd"] = 0
            return

        def work():
            import subprocess
            self.console_line("")
            self._console_wrapped(f"$ {cmd}")
            try:
                p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, bufsize=1)
                for line in iter(p.stdout.readline, ""):
                    if not line:
                        break
                    self.console_line(line.rstrip("\n")[:200])
                p.wait()
                self.console_line(f"[exit {p.returncode}]")
            except FileNotFoundError:
                self.console_line("ERROR: command not found (is nmap installed?)")
            except Exception as e:
                self.console_line(f"ERROR: {e}")
        _run_bg(work)

    def toggle_trace(self):
        self.state.trace_on = not self.state.trace_on
        if self.state.trace_on:
            self._trace_path = os.path.expanduser("~/phosphor_trace.txt")
            self.state.note(f"tracing -> {self._trace_path}")
        else:
            self.state.note("tracing off")

    def _start_hack3270(self, host, port):
        from phosphor.toolchain.hack3270_proxy import Hack3270Proxy
        try:
            self._h3 = Hack3270Proxy(host, port)
            lh, lp = self._h3.start()
            self.state.note(f"hack3270 proxy up - session routed via {lh}:{lp}")
            return lh, lp
        except Exception as e:
            self._h3 = None
            self.state.note(f"hack3270 proxy unavailable ({e}); connecting direct")
            return host, port

    def _stop_hack3270(self):
        h3 = getattr(self, "_h3", None)
        if h3 is not None:
            h3.stop(); self._h3 = None

    def toggle_h3_proxy(self):
        self.state.h3_proxy = not self.state.h3_proxy
        self.state.note("hack3270 proxy will launch on next connect" if self.state.h3_proxy
                        else "hack3270 proxy disabled")

    def _sync_manip(self):
        s = self.state
        if self.conn is not None:
            self.conn.manip = {"unprotect": s.h3_unprotect, "unhide": s.h3_unhide}

    def toggle_h3_unprotect(self):
        self.state.h3_unprotect = not self.state.h3_unprotect
        self._sync_manip()
        self.state.note(f"unprotect fields {'ON' if self.state.h3_unprotect else 'off'}")

    def toggle_h3_unhide(self):
        self.state.h3_unhide = not self.state.h3_unhide
        self._sync_manip()
        self.state.note(f"reveal hidden fields {'ON' if self.state.h3_unhide else 'off'}")

    # --- hack3270 field injection / brute force ---
    def cycle_inject_type(self):
        from phosphor.toolchain import injections as I
        self.state.h3_inject_idx = (self.state.h3_inject_idx + 1) % len(I.type_ids())
        tid = I.type_ids()[self.state.h3_inject_idx]
        self.state.note(f"inject type: {I.label_for(tid)}")

    def save_inject_wordlist(self):
        from phosphor.toolchain import injections as I
        from phosphor.app import notes as notesmod
        tid = I.type_ids()[self.state.h3_inject_idx % len(I.type_ids())]
        path = I.materialise(tid, str(notesmod.tools_dir()))
        self.state.note(f"wrote {os.path.basename(path)}" if path else "could not write wordlist")

    def run_inject(self):
        self.state.hack3270_open = False
        self.ask_confirm(self._do_run_inject)

    def _do_run_inject(self):
        from phosphor.toolchain import injections as I, inject as J
        from phosphor.app import notes as notesmod
        s = self.state
        tid = I.type_ids()[s.h3_inject_idx % len(I.type_ids())]
        self.console_open(f"STRIP3270 inject - {I.label_for(tid)}")
        cands = I.candidates(tid)
        self.console_line(f"# wordlist: {tid}  ({len(cands)} candidates, cap {I.DEFAULT_LIMIT})")
        path = I.materialise(tid, str(notesmod.tools_dir()))
        if path:
            self.console_line(f"# saved to {os.path.basename(path)}")
        tgt = J.find_mask_field(s.grid or [], s.h3_mask)
        if self.conn is not None and self.editor is not None and tgt:
            row, col, length = tgt
            self.console_line(f"# target field row {row + 1} col {col + 1} len {length}; injecting via the live session ...")

            def send_fn(value, aid):
                try:
                    # write the candidate across the whole field width so residual
                    # mask/previous-guess characters are cleared (the old click+
                    # backspace couldn't erase before the field start and left them).
                    padded = value[:length].ljust(length)
                    self.editor.set_field(row + 1, col + 1, padded)
                    self.editor.enter(); self._refresh_grid()
                    # rstrip each row + drop blank rows: the raw 24x80 grid is a
                    # constant size, so length-based hit detection only works on the
                    # actual content, not the padded frame.
                    rows = [r.rstrip() for r in self.conn.screen.to_rows()]
                    return "\n".join(r for r in rows if r)
                except Exception as e:
                    return f"ERR {e}"
            rep = J.Hack3270Injector(send_fn).run(cands, field_len=length, aid="enter", limit=500)
            for h in rep.hits[:20]:
                self.console_line(f"[HIT] {h.candidate:12} resp_len={h.length}")
            self.console_line(f"-- {len(rep.results)} tried, {len(rep.hits)} interesting (size != {rep.baseline_len}) --")
        else:
            self.console_line("# not connected, or no mask field on the screen. To brute-force a field:")
            self.console_line(f"#   1) connect   2) type the mask char '{s.h3_mask}' into the target field")
            self.console_line("#   3) reopen STRIP3270 and press Inject now.  Sample candidates:")
            for c in cands[:12]:
                self.console_line("    " + c)

    def select_theme(self, name):
        """Apply a Phosphor Skin.  Paid skins that aren't unlocked are previewed
        with a note rather than applied."""
        from phosphor.app import ui
        from phosphor.app.themes import THEMES
        s = self.state
        t = THEMES.get(name)
        if t is None:
            return
        if t.paid and name not in s.unlocked:
            s.note(f"{t.label} is part of the PHOSPHOR skin add-on pack.")
            return
        s.theme = name
        t = ui.apply_theme(name)          # rebinds the colour globals + clears chrome cache
        s.colour = t.screen_mode          # glass tint follows the skin
        if self.crt is not None:
            self.crt._app_sig = None      # force the terminal glass to re-render
        self._save_prefs()
        s.note(f"skin: {t.label}")

    def _save_prefs(self):
        try:
            from phosphor.app import prefs
            prefs.save(self.state)
        except Exception:
            pass

    def _tools_activate(self):
        from phosphor.app import license as lic
        s = self.state
        if lic.unlock_tools(s.tools_pw.strip()):
            s.tools_unlocked = True
            s.tools_status = "unlocked - pen-test tools enabled"
            s.tools_popup = False
            s.tools_pw = ""
            s.note("pen-test tools unlocked")
        else:
            s.tools_status = "wrong unlock code"

    def _license_paste(self):
        txt = ""
        try:
            import pygame
            if not pygame.scrap.get_init():
                pygame.scrap.init()
            data = pygame.scrap.get_text()          # SDL clipboard (works in-app)
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
            txt = (data or "").strip()
        except Exception:
            txt = ""
        if not txt:
            try:
                from phosphor.app import filepick
                txt = (filepick.paste_text() or "").strip()
            except Exception:
                txt = ""
        if txt:
            self.state.license_token = txt
            self.state.license_status = f"pasted {len(txt)} chars - press Activate"
        else:
            self.state.license_status = "clipboard empty (copy the token first, then Paste)"

    def _license_activate(self):
        from phosphor.app import license as lic
        s = self.state
        ok, msg, skins = lic.activate(s.license_email.strip(), s.license_token.strip())
        s.license_status = msg if ok else ("could not activate: " + msg)
        if ok:
            s.unlocked = skins
            self._save_prefs()
            s.note("licence activated - paid skins unlocked")

    def toggle_capture(self):
        """Start/stop writing a .pcap of the live TN3270 traffic into the tools dir."""
        from phosphor.toolchain import pcap as pcapmod
        from phosphor.app import notes as notesmod
        s = self.state
        if not s.capture_on:
            path = pcapmod.default_capture_path(s.host or "session", str(notesmod.tools_dir()))
            try:
                writer = pcapmod.PcapWriter(path, server_ip=(s.host or "10.0.0.1"),
                                            server_port=int(s.port or 23))
            except Exception as e:
                s.note(f"capture failed: {e}"); return
            if self.conn is not None:
                self.conn.pcap = writer
            self._pcap = writer
            s.capture_on = True; s.capture_path = path
            s.note(f"capturing -> {path}")
        else:
            w = getattr(self, "_pcap", None)
            n = w.count if w else 0
            if self.conn is not None:
                self.conn.pcap = None
            if w:
                w.close()
            self._pcap = None
            s.capture_on = False
            s.note(f"capture saved ({n} packets): {s.capture_path}")

    def _trace_screen(self):
        if not (self.state.trace_on and self.state.grid):
            return
        try:
            with open(getattr(self, "_trace_path", os.path.expanduser("~/phosphor_trace.txt")), "a") as f:
                f.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
                for row in self.state.grid:
                    f.write("".join(ch for ch, _ in row).rstrip() + "\n")
        except Exception as e:
            self.state.note(f"trace error: {e}")

    def _to_clipboard(self, text):
        from phosphor.app import filepick
        self.state.note("copied" if filepick.copy_text(text) else "clipboard unavailable")

    def _copy_or_save(self, text, kind="packets"):
        """Copy text to the clipboard; if no clipboard tool is available (common on
        a headless Kali box), save it to a timestamped file in the tools dir and
        tell the user exactly where it went, so 'Copy all' always does something.
        Feedback is echoed into the open console too, since the OUTPUT panel note
        is hidden behind the popup."""
        import time
        from phosphor.app import filepick
        from phosphor.app import notes as notesmod
        def report(msg):
            self.state.note(msg)
            if self.state.console_open:
                self.console_line("")
                self.console_line("# " + msg)
        if not text.strip():
            report("nothing to copy yet"); return
        if filepick.copy_text(text):
            report(f"copied {len(text.splitlines())} lines to the clipboard")
            return
        try:
            path = notesmod.tools_dir() / f"{kind}-{time.strftime('%Y%m%d-%H%M%S')}.txt"
            path.write_text(text)
            report(f"no clipboard tool (install xclip/xsel/wl-copy) - saved to {path}")
        except Exception as e:
            report(f"copy/save failed: {e}")

    def _from_clipboard(self):
        from phosphor.app import filepick
        return filepick.paste_text()

    def copy_screen(self):
        if not self.state.grid:
            self.state.note("no screen to copy yet"); return
        text = "\n".join("".join(ch for ch, _ in row).rstrip() for row in self.state.grid)
        self._copy_or_save(text, kind="screen")

    def paste(self):
        text = self._from_clipboard().split("\n")[0]
        if self.state.focus == "screen" and self.editor:
            for ch in text:
                self.editor.type_char(ch)
            self._refresh_grid()
        elif self.state.focus == "notes":
            self.state.notes_text += self._from_clipboard()
        else:
            self.state.cmdline += text

    # ---- notepad + tasks -------------------------------------------------
    def open_notes(self):
        self.state.notes_text = notesmod.load_notes()
        self.state.tools_files = notesmod.list_tool_files()
        self.state.notes_open = True
        self.state.focus = "notes"

    def save_notes_to_tools(self):
        s = self.state
        name = s.notes_name or "wordlist.txt"
        path = notesmod.save_tool_file(name, s.notes_text)
        s.tools_files = notesmod.list_tool_files()
        s.note(f"saved {name} to tools dir" if path else f"could not save {name}")

    def open_tool_file(self, idx: int):
        s = self.state
        files = s.tools_files or []
        if 0 <= idx < len(files):
            s.notes_name = files[idx]
            s.notes_text = notesmod.load_tool_file(files[idx])
            s.field_cursor["notes_text"] = len(s.notes_text)
            s.focus = "notes"

    def close_notes(self):
        notesmod.save_notes(self.state.notes_text)
        self.state.notes_open = False
        self.state.focus = None

    def open_tasks(self):
        self.state.tasks = notesmod.load_tasks()
        self.state.tasks_open = True
        self.state.focus = "task_input"

    def add_task(self):
        t = self.state.task_input.strip()
        if t:
            self.state.tasks.append({"text": t, "done": False})
            self.state.task_input = ""
            notesmod.save_tasks(self.state.tasks)

    def toggle_task(self, i):
        if 0 <= i < len(self.state.tasks):
            self.state.tasks[i]["done"] = not self.state.tasks[i].get("done")
            notesmod.save_tasks(self.state.tasks)

    def remove_task(self, i):
        if 0 <= i < len(self.state.tasks):
            del self.state.tasks[i]
            notesmod.save_tasks(self.state.tasks)

    # ---- FTP client ------------------------------------------------------
    def open_ftp(self):
        self.state.ftp_open = True
        self.state.ftp_focus = "host"
        if not self.state.ftp_host:
            self.state.ftp_host = self.state.host

    def ftp_connect(self):
        s = self.state

        def work():
            from phosphor.protocols.ftp.client import MainframeFTP
            try:
                s.ftp_status = f"connecting to {s.ftp_host}:21 ..."
                f = MainframeFTP(mode=s.ftp_mode)
                f.connect(s.ftp_host or s.host, 21)
                f.login(s.ftp_user or "anonymous", s.ftp_pass or "anonymous@")
                f.set_mode(s.ftp_mode)
                self._ftp = f
                s.ftp_list = f.list()
                s.ftp_status = f"connected ({s.ftp_mode.upper()}) - {len(s.ftp_list)} item(s)"
            except Exception as e:
                s.ftp_status = f"error: {e}"
        _run_bg(work)

    def ftp_refresh(self):
        s = self.state
        if not getattr(self, "_ftp", None):
            s.ftp_status = "connect first"; return

        def work():
            try:
                s.ftp_list = self._ftp.list()
                s.ftp_status = f"{len(s.ftp_list)} item(s)"
            except Exception as e:
                s.ftp_status = f"error: {e}"
        _run_bg(work)

    def ftp_upload(self):
        s = self.state
        if not getattr(self, "_ftp", None):
            s.ftp_status = "connect first"; return

        def work():
            local, dsn = self._pick_file_and_name(upload=True)
            if not (local and dsn):
                return
            try:
                with open(local, "rb") as fh:
                    self._ftp.put(dsn, fh.read())
                s.ftp_status = f"uploaded -> {dsn}"
                s.ftp_list = self._ftp.list()
            except Exception as e:
                s.ftp_status = f"upload error: {e}"
        _run_bg(work)

    def ftp_submit(self):
        s = self.state
        if not getattr(self, "_ftp", None):
            s.ftp_status = "connect first"; return
        from phosphor.app import filepick

        def work():
            local = filepick.open_file("Choose JCL file to submit")
            if not local:
                return
            try:
                with open(local, "rb") as fh:
                    jid = self._ftp.submit_jcl(fh.read())
                s.ftp_status = f"submitted - {jid}"
                self.console_open("JCL submit")
                self.console_line(f"$ SITE FILETYPE=JES  +  PUT {local}")
                self.console_line(f"job submitted: {jid}")
            except Exception as e:
                s.ftp_status = f"submit error: {e}"
        _run_bg(work)

    def ftp_download(self, i):
        s = self.state
        if not getattr(self, "_ftp", None) or i >= len(s.ftp_list):
            return
        self._ftp_get(str(s.ftp_list[i]).split()[-1])

    def ftp_list_hlq(self):
        """List datasets under the typed dataset/HLQ (e.g. SYS1 or SYS1.PARMLIB)."""
        s = self.state
        if not getattr(self, "_ftp", None):
            s.ftp_status = "connect first"; return
        hlq = (s.ftp_dsn or "").strip()

        def work():
            try:
                s.ftp_list = self._ftp.list(hlq)
                s.ftp_status = f"{len(s.ftp_list)} item(s) under {hlq or '(default)'}"
            except Exception as e:
                s.ftp_status = f"list error: {e}"
        _run_bg(work)

    def ftp_download_dsn(self):
        """Download the exact dataset typed in the Dataset/HLQ field."""
        s = self.state
        if not getattr(self, "_ftp", None):
            s.ftp_status = "connect first"; return
        dsn = (s.ftp_dsn or "").strip()
        if not dsn:
            s.ftp_status = "type a dataset name to download"; return
        self._ftp_get(dsn)

    def _ftp_get(self, dsn):
        """Prompt for a local path and download `dsn` in the background."""
        s = self.state
        from phosphor.app import filepick
        binary = (s.ftp_mode == "binary")

        def work():
            local = filepick.save_file("Save as", dsn.replace(".", "_") + (".bin" if binary else ".txt"))
            if not local:
                return
            try:
                data = self._ftp.get(dsn)
                with open(local, "wb") as fh:
                    fh.write(data)
                s.ftp_status = f"downloaded {dsn} ({len(data)} bytes)"
            except Exception as e:
                s.ftp_status = f"download error: {e}"
        _run_bg(work)

    def _pick_file_and_name(self, upload):
        """Off-main-thread picker; returns (local, dsn) or (None, None)."""
        from phosphor.app import filepick
        local = filepick.open_file("Choose local file")
        if not local:
            return None, None
        dsn = filepick.ask_text("Upload", "Target dataset name:")
        return (local, dsn) if dsn else (None, None)
    def on_click(self, wid, x, y):
        s = self.state
        if wid == "screen":
            if self.editor and s.grid:
                row, col = pixel_to_cell(x, y, s.grid)
                self.editor.click(row, col)
                self._refresh_grid()
            s.focus = "screen"
        elif wid == "b_connect":
            self.connect()
        elif wid == "b_enter" or wid == "cmd":
            s.focus = "cmd" if wid == "cmd" else s.focus
            if wid == "b_enter":
                self.send_command()
        elif wid and wid.startswith("f_"):
            s.focus = wid
        elif wid and wid.startswith("t_"):
            self.ask_confirm(lambda w=wid[2:]: self.run_tool(w))
        elif wid == "b_upload":
            self.transfer(True)
        elif wid == "b_download":
            self.transfer(False)
        elif wid == "b_xfer_mode":
            s.xfer_mode = "ascii" if s.xfer_mode == "binary" else "binary"
            s.note(f"transfer type: {s.xfer_mode.upper()}")
        elif wid == "packets":
            self._open_packet_log()
        elif wid and wid.startswith("finding_"):
            self._open_finding(int(wid.split("_")[1]))
        elif wid == "b_report":
            self.pentest_report()
        elif wid == "b_grab":
            self.capture_screen()
        elif wid in ("c_colour", "c_green", "c_amber"):
            self.set_colour(wid[2:])
        elif wid == "b_about":
            s.about_open = True
        elif wid == "about_close":
            s.about_open = False
        elif wid == "b_notes":
            self.open_notes()
        elif wid == "notes_close":
            self.close_notes()
        elif wid == "notes_body":
            s.focus = "notes"
        elif wid == "notes_name":
            s.focus = "notes_name"
        elif wid == "notes_save_tools":
            self.save_notes_to_tools()
        elif wid and wid.startswith("notes_openfile_"):
            self.open_tool_file(int(wid.rsplit("_", 1)[1]))
        elif wid == "b_tasks":
            self.open_tasks()
        elif wid == "tasks_close":
            s.tasks_open = False
        elif wid == "task_field":
            s.focus = "task_input"
        elif wid == "task_add":
            self.add_task()
        elif wid and wid.startswith("task_toggle_"):
            self.toggle_task(int(wid.rsplit("_", 1)[1]))
        elif wid and wid.startswith("task_del_"):
            self.remove_task(int(wid.rsplit("_", 1)[1]))
        elif wid == "b_ftp":
            self.open_ftp()
        elif wid == "ftp_close":
            s.ftp_open = False
        elif wid and wid.startswith("ftpf_"):
            s.ftp_focus = wid[5:]
        elif wid == "ftp_connect":
            self.ftp_connect()
        elif wid == "ftp_refresh":
            self.ftp_refresh()
        elif wid == "ftp_list_hlq":
            self.ftp_list_hlq()
        elif wid == "ftp_download_dsn":
            self.ftp_download_dsn()
        elif wid == "ftp_upload":
            self.ftp_upload()
        elif wid == "ftp_submit":
            self.ftp_submit()
        elif wid == "ftp_mode":
            s.ftp_mode = "ascii" if s.ftp_mode == "binary" else "binary"
            if getattr(self, "_ftp", None):
                try:
                    self._ftp.set_mode(s.ftp_mode)
                    s.ftp_status = f"transfer mode: {s.ftp_mode.upper()} " + \
                        ("(TYPE A - EBCDIC<->ASCII text)" if s.ftp_mode == "ascii" else "(TYPE I - raw bytes)")
                except Exception as e:
                    s.ftp_status = f"mode error: {e}"
        elif wid and wid.startswith("ftpget_"):
            self.ftp_download(int(wid.rsplit("_", 1)[1]))
        elif wid == "link_offsec":
            try:
                import webbrowser
                webbrowser.open("https://offensivesec.org")
                s.note("opening offensivesec.org")
            except Exception as e:
                s.note(f"link error: {e}")
        elif wid == "font_inc":
            self.bump_font(+2)
        elif wid == "font_dec":
            self.bump_font(-2)
        elif wid in ("b_cp", "set_cp"):
            self.cycle_codepage()
        elif wid == "b_protocol":
            s.protocol = "3270" if s.protocol == "5250" else "5250"
            s.note("protocol: " + ("TN5250 (IBM i)" if s.protocol == "5250" else "TN3270 (z/OS)")
                   + (" - reconnect to apply" if s.connected else ""))
        elif wid == "set_engine":
            from phosphor.session import available_engines
            if not available_engines().get("tnz"):
                s.note("IBM tnz not installed - run: pip install tnz ebcdic")
            else:
                s.engine = "native" if getattr(s, "engine", "native") == "tnz" else "tnz"
                s.note(f"TN3270 engine: {'IBM tnz (real z/OS)' if s.engine == 'tnz' else 'native'}"
                       + (" - reconnect to apply" if s.connected else ""))
        elif wid == "b_settings":
            s.settings_open = True
        elif wid == "set_close":
            s.settings_open = False
        elif wid == "b_bezel":
            s.bezel = not s.bezel
            self._save_prefs()
        elif wid == "b_themes":
            s.themes_open = True
            s.settings_open = False        # don't leave Settings on top of the picker
        elif wid == "tools_unlock":
            s.tools_popup = True
            s.tools_status = ""
        elif wid == "tools_close":
            s.tools_popup = False
        elif wid == "toolsf_pw":
            s.focus = "tools_pw"
        elif wid == "tools_activate":
            self._tools_activate()
        elif wid == "b_license":
            from phosphor.app import license as lic
            s.license_open = True
            s.focus = "license_token"       # focus the code box so you can type immediately
            if not s.license_email:
                s.license_email = lic.saved_email()
            s.license_status = "Type the unlock code (or paste a licence token), then Activate"
        elif wid == "lic_close":
            s.license_open = False
        elif wid == "licf_email":
            s.focus = "license_email"
        elif wid == "licf_token":
            s.focus = "license_token"      # focusable so short unlock codes can be typed
        elif wid == "lic_paste":
            self._license_paste()
        elif wid == "lic_activate":
            self._license_activate()
        elif wid == "b_focus":
            s.focus_mode = True
        elif wid == "themes_close":
            s.themes_open = False
        elif wid and wid.startswith("theme_"):
            self.select_theme(wid[len("theme_"):])
        elif wid == "b_trace":
            self.toggle_trace()
        elif wid == "b_pcap":
            self.toggle_capture()
        elif wid == "b_quit" or wid == "b_power":
            self.shutdown()
        elif wid == "b_help":
            self.state.help_open = True
        elif wid == "help_close":
            self.state.help_open = False
        elif wid == "a_hydra":
            self.ask_confirm(self.open_hydra)
        elif wid == "a_john":
            self.open_john()
        elif wid == "a_passticket":
            self.scan_passtickets()
        elif wid == "a_cicspwn":
            self.ask_confirm(self.open_cicspwn)
        elif wid == "a_api":
            self.ask_confirm(self.open_api)
        elif wid == "a_sql":
            self.ask_confirm(self.open_sql)
        elif wid == "a_ezrecon":
            self.ask_confirm(self.open_ezrecon)
        elif wid == "confirm_yes":
            s.confirm_open = False
            act = getattr(self, "_pending", None)
            self._pending = None
            if act:
                act()
        elif wid == "confirm_no":
            s.confirm_open = False
            self._pending = None
            s.note("cancelled - no test launched")
        elif wid == "a_hack3270":
            self.state.hack3270_open = True
        elif wid == "a_injector":
            self.ask_confirm(self.open_nje)
        elif wid == "h3_close":
            self.state.hack3270_open = False
        elif wid == "h3_inject_type":
            self.cycle_inject_type()
        elif wid == "h3_inject_save":
            self.save_inject_wordlist()
        elif wid == "h3_inject_run":
            self.run_inject()
        elif wid == "a_shell":
            self.open_shell()
        elif wid == "b_copy":
            self.copy_screen()
        elif wid == "b_paste":
            self.paste()
        elif wid == "con_close":
            s.console_open = False
            s.console_mode = ""
        elif wid == "con_copy":
            self._copy_or_save("\n".join(s.console_lines),
                               kind=(s.console_mode or "console"))
        elif wid == "con_cmd":
            s.focus = "console_cmd"
        elif wid == "tool_host":
            s.focus = "tool_host"
        elif wid == "tool_port":
            s.focus = "tool_port"
        elif wid == "con_build":
            self.build_tool_cmd()
        elif wid == "con_run":
            self.run_console_cmd()
        elif wid == "block":
            pass                                    # modal backdrop - swallow the click
        elif wid and wid.startswith("set_t_"):
            attr = {"set_t_cursorblink": "cursor_blink", "set_t_crosshair": "crosshair",
                    "set_t_monocase": "monocase", "set_t_typeahead": "typeahead"}.get(wid)
            if attr:
                setattr(s, attr, not getattr(s, attr))
                s.note(f"{attr.replace('_', ' ')}: {'on' if getattr(s, attr) else 'off'}")
        elif wid == "set_h3_proxy":
            self.toggle_h3_proxy()
        elif wid == "set_h3_unprotect":
            self.toggle_h3_unprotect()
        elif wid == "set_h3_unhide":
            self.toggle_h3_unhide()
        elif wid == "b_fav_save":
            self.save_favourite()
        elif wid and wid.startswith("favx_"):
            self.remove_favourite(wid[5:])
        elif wid and wid.startswith("fav_"):
            self.load_favourite(wid[4:])
        elif wid and wid.startswith("k_"):
            self.keypad(wid[2:])
        else:
            s.focus = None

    def ask_confirm(self, action, text=None):
        """Show the permission warning; run `action` only after the user confirms."""
        self._pending = action
        tgt = self.state.host or "this target"
        self.state.confirm_text = text or (
            f"You are about to launch an active test against {tgt}. Do you have written "
            "authorisation to test this system? Unauthorised access to computer systems is illegal.")
        self.state.confirm_open = True

    def _run_now(self, cmd: str):
        """Stage a command in the console and execute it immediately (streamed)."""
        s = self.state
        s.console_cmd = cmd
        s.field_cursor["console_cmd"] = len(cmd)
        s.focus = "console_cmd"
        self.run_console_cmd()

    def open_api(self):
        from phosphor.toolchain import api_sql as A
        s = self.state
        s.console_mode = "api"
        s.tool_host = s.host or ""
        s.tool_port = "443"
        self.console_open(f"API / curl  -  {s.tool_host or 'HOST'}")
        if not A.curl_available():
            self.console_line("# curl not on PATH - install curl to run this")
        self.console_line("# z/OS REST endpoints worth probing (set Host/Port, Build, edit path, Run):")
        for label, method, path in A.API_ENDPOINTS:
            self.console_line(f"    {method:4} {path:42} # {label}")
        self.console_line("")
        self.build_tool_cmd()
        s.focus = "tool_host"

    def open_sql(self):
        from phosphor.toolchain import api_sql as A
        s = self.state
        s.console_mode = "sql"
        s.tool_host = s.host or ""
        s.tool_port = "446"
        self.console_open(f"SQL / DB2  -  {s.tool_host or 'HOST'}")
        self.console_line("# A live DB2 client. Three ways in:")
        self.console_line("#")
        self.console_line("#  1) connect <host> [port] [user] [pass] [rdb]   <- interactive DRDA login+SQL")
        self.console_line("#       opens the session, then:  LOGIN <userid> <password>   (if not given)")
        self.console_line("#       then just type SQL:  SELECT CURRENT SQLID FROM SYSIBM.SYSDUMMY1")
        self.console_line("#       (DB2 for z/OS DDF is usually :446; GIBSON's DRDA listener is :50000)")
        self.console_line("#")
        self.console_line("#  2) gibson [host] [port]     GIBSON DB2 WebSocket shell (:50001), then LOGIN + SQL")
        self.console_line("#")
        self.console_line("#  3) driver path (SQL result sets on a real host): set Host/Port, Build, edit, Run")
        if not (A.ibm_db_available() or A.db2_available()):
            self.console_line("#       needs the ibm_db driver (pip install ibm_db) or the db2 CLP")
        self.console_line("")
        self.console_line("# handy statements:")
        for label, q in A.DB2_QUERIES:
            self._console_wrapped(f"    {label:18} {q}")
        self.console_line("")
        self.build_tool_cmd()
        s.focus = "console_cmd"

    def _db2ws_open(self, args):
        """Open a live GIBSON DB2 WebSocket shell: 'gibson [host] [port]'."""
        from phosphor.protocols import db2ws
        s = self.state
        host = args[0] if args else (s.tool_host or s.host or "127.0.0.1")
        try:
            port = int(args[1]) if len(args) > 1 else 50001
        except ValueError:
            port = 50001
        self.console_line("")
        self.console_line(f"# connecting to GIBSON DB2 (WebSocket) {host}:{port} ...")

        def work():
            try:
                cli = db2ws.Db2WsClient(host, port)
                greeting = cli.connect()
                self._db2ws = cli
                s.console_mode = "db2ws"
                for ln in greeting.splitlines():
                    self.console_line("  " + ln)
                self.console_line("# now log in:  LOGIN <userid> <password>")
            except Exception as e:
                self.console_line(f"# connect failed: {e}")
                self.console_line("# is GIBSON running with the DB2 WebSocket service on that port?")
        threading.Thread(target=work, daemon=True).start()

    def _run_db2ws(self, cmd):
        """One line into the live GIBSON DB2 shell (LOGIN first, then SQL)."""
        cli = getattr(self, "_db2ws", None)
        if cli is None:
            self.console_line("# not connected - type: gibson [host] [port]")
            return
        low = cmd.lower()
        if low in ("quit", "exit", ":q", "disconnect"):
            try: cli.close()
            except Exception: pass
            self._db2ws = None
            self.state.console_mode = "sql"
            self.console_line("# disconnected from GIBSON DB2")
            return
        # never echo the password back to the console
        shown = "LOGIN " + cmd.split()[1] + " ********" if low.startswith("login ") and len(cmd.split()) >= 3 else cmd
        self.console_line(f"db2> {shown}")

        def work():
            try:
                if low.startswith("login ") and len(cmd.split()) >= 3:
                    _u = cmd.split()[1]; _pw = cmd.split()[2]
                    good, reply = cli.login(_u, _pw)
                    for ln in reply.splitlines():
                        self.console_line("  " + ln)
                else:
                    out = cli.command(cmd)
                    for ln in out.splitlines():
                        self.console_line("  " + ln)
            except Exception as e:
                self.console_line(f"# error: {e}")
                self._db2ws = None
                self.state.console_mode = "sql"
        threading.Thread(target=work, daemon=True).start()

    def open_nje(self):
        """iNJEctor - NJE (Network Job Entry) recon: probe node names and test node
        trust / passwords.  Driven from the command box."""
        s = self.state
        s.tool_host = s.host or ""
        s.tool_port = "175"
        self.console_open("iNJEctor  -  NJE node recon (authorised targets only)")
        s.console_mode = "nje"
        self.console_line("NJE trusts nodes by name, often with no encryption and no /")
        self.console_line("weak node password. Set Host below, then in the command box:")
        self.console_line("")
        self.console_line("  probe <OHOST> [RHOST]     OPEN-probe one node (does it exist / trust RHOST?)")
        self.console_line("  enum [RHOST]              probe a list of common node names")
        self.console_line("  signon <OHOST> <RHOST> [PW]   test the node sign-on password (empty = none)")
        self.console_line("  cmd <operator command>    after signon, run a JES2 command ($D NODE, $D NJEDEF)")
        self.console_line("  submit <run-as-user> <id|racf_backdoor|file>  submit a job that runs as run-as-user")
        self.console_line("  tls on|off                use the NJE TLS port (2252) instead of 175")
        self.console_line("")
        self.console_line("Reason codes:  ACK=OHOST exists & trusts RHOST (spoofable) |")
        self.console_line("               0x04=OHOST exists, RHOST not trusted | 0x01=unknown node")
        self.console_line("")
        self._nje_tls = False
        s.focus = "tool_host"

    def _run_nje(self, cmd):
        from phosphor.toolchain import nje as N
        s = self.state
        host = s.tool_host or s.host or ""
        try:
            port = int(s.tool_port) if s.tool_port else N.NJE_PORT
        except ValueError:
            port = N.NJE_PORT
        parts = cmd.split()
        if not parts:
            return
        op = parts[0].lower()
        if op == "tls":
            self._nje_tls = (len(parts) > 1 and parts[1].lower() == "on")
            s.tool_port = str(N.NJE_TLS_PORT if self._nje_tls else N.NJE_PORT)
            self.console_line(f"# NJE TLS {'on (port 2252)' if self._nje_tls else 'off (port 175)'}")
            return
        if not host:
            self.console_line("# set a target Host first"); return
        tls = getattr(self, "_nje_tls", False)

        def emit(r):
            tag = "ACK" if r.reason == N.R_OK else (f"0x{(r.reason or 0):02x}")
            self.console_line(f"  {r.ohost:<8} rhost={r.rhost:<8} {tag:>4}  {r.reason_text()}")
            for f in r.findings:
                self.console_line(f"      [!] {f}")
            if r.error:
                self.console_line(f"      (error: {r.error})")

        def work():
            try:
                if op == "probe" and len(parts) >= 2:
                    rhost = parts[2] if len(parts) > 2 else "FAKE"
                    self.console_line(f"$ probe {parts[1]} as {rhost} -> {host}:{port}")
                    emit(N.open_probe(host, parts[1], rhost=rhost, port=port, tls=tls))
                elif op == "enum":
                    rhost = parts[1] if len(parts) > 1 else "FAKE"
                    self.console_line(f"$ enum {len(N.COMMON_NODES)} names as {rhost} -> {host}:{port}")
                    for r in N.enumerate_nodes(host, N.COMMON_NODES, rhost=rhost, port=port, tls=tls):
                        emit(r)
                    self.console_line("# done")
                elif op == "signon" and len(parts) >= 3:
                    pw = parts[3] if len(parts) > 3 else ""
                    self.console_line(f"$ signon {parts[1]} as {parts[2]} pw={'(empty)' if not pw else '****'}")
                    r = N.signon_test(host, parts[1], rhost=parts[2], password=pw, port=port, tls=tls)
                    emit(r)
                    if r.signon_ok:
                        self._nje_target = (parts[1], parts[2], pw)
                        self.console_line(f"  # signed on - now:  cmd <operator command>   e.g. cmd $D NODE")
                elif op == "cmd" and len(parts) >= 2:
                    tgt = getattr(self, "_nje_target", None)
                    if not tgt:
                        self.console_line("# sign on first:  signon <OHOST> <RHOST> [PW]")
                    else:
                        oh, rh, pw = tgt
                        command = cmd.split(None, 1)[1]
                        self.console_line(f"$ cmd '{command}' -> {oh} (as {rh})")
                        r = N.send_command(host, oh, rh, command, password=pw, port=port, tls=tls)
                        for f in r.findings:
                            self.console_line(f"      {f}")
                        if r.error:
                            self.console_line(f"      (error: {r.error})")
                elif op == "submit" and len(parts) >= 3:
                    tgt = getattr(self, "_nje_target", None)
                    if not tgt:
                        self.console_line("# sign on first:  signon <OHOST> <RHOST> [PW]")
                    else:
                        oh, rh, pw = tgt
                        run_as = parts[1]
                        key = parts[2]
                        jcls = N.bundled_jcl()
                        if key in jcls:
                            jcl = jcls[key]
                        elif os.path.isfile(key):
                            jcl = open(key).read()
                        else:
                            self.console_line(f"# unknown JCL '{key}'. builtin: {', '.join(jcls)} or a file path")
                            return
                        self.console_line(f"$ submit '{key}' -> {oh} run-as {run_as}")
                        r = N.submit_job(host, oh, rh, jcl, password=pw, userid=run_as,
                                         port=port, tls=tls)
                        for f in r.findings:
                            self.console_line(f"      {f}")
                        if r.error:
                            self.console_line(f"      (error: {r.error})")
                else:
                    self.console_line("# usage: probe <OHOST> [RHOST] | enum [RHOST] | "
                                      "signon <OHOST> <RHOST> [PW] | cmd <command> | "
                                      "submit <run-as-user> <id|racf_backdoor|file> | tls on|off")
            except Exception as e:
                self.console_line(f"# error: {e}")
        threading.Thread(target=work, daemon=True).start()

    def _run_drda(self, args):
        """Native DRDA: fingerprint DB2 DDF and optionally test credentials.
        usage: drda <host> [port] [userid] [password] [rdb]"""
        from phosphor.protocols.drda import client as D
        s = self.state
        host = args[0] if args else (s.tool_host or s.host or "")
        if not host:
            self.console_line("# usage: drda <host> [port] [userid] [password] [rdb]")
            return
        try:
            port = int(args[1]) if len(args) > 1 else 446
        except (ValueError, IndexError):
            port = 446
        user = args[2] if len(args) > 2 else ""
        pw = args[3] if len(args) > 3 else ""
        rdb = args[4] if len(args) > 4 else ""
        sql = " ".join(args[5:]) if len(args) > 5 else ""
        self.console_line("")
        self.console_line(f"$ drda {host}:{port}" + (f" as {user}" if user else " (fingerprint only)")
                          + (f" | SQL: {sql[:40]}" if sql else ""))

        def work():
            try:
                if sql and user:
                    code, text = D.execute_sql(host, port, user, pw, rdb, sql)
                    if code is None:
                        self.console_line(f"  [-] {text}")
                    else:
                        self.console_line(f"  SQLCODE {code}")
                        for line in text.splitlines()[:60]:
                            self.console_line("    " + line)
                    return
                r = D.probe(host, port, userid=user, password=pw, rdbnam=rdb)
                if not r.reachable:
                    self.console_line(f"# unreachable: {r.error}"); return
                if not r.is_drda:
                    self.console_line(f"# not a DRDA server: {r.error}"); return
                self.console_line(f"  server : {r.srvclsnm}  {r.srvrlslv}")
                self.console_line(f"  location: {r.srvnam}   extnam: {r.extnam}")
                if r.auth_attempted:
                    if r.auth_ok:
                        self.console_line(f"  [+] {user} ACCEPTED  (SECCHKCD 0x00)")
                        if r.rdb_opened is not None:
                            self.console_line(f"  [+] RDB {rdb}: {'opened' if r.rdb_opened else 'denied/not found'}")
                    else:
                        self.console_line(f"  [-] {user} rejected: {r.secchk_text()}")
                for f in r.findings:
                    self.console_line(f"      {f}")
                if r.error:
                    self.console_line(f"  (note: {r.error})")
            except Exception as e:
                self.console_line(f"# drda error: {e}")
        threading.Thread(target=work, daemon=True).start()

    def _drdasql_open(self, args):
        """Open a live DB2 DRDA session: connect [host] [port] [user] [pass] [rdb].
        Then it becomes an interactive SQL prompt (login first if creds weren't given)."""
        from phosphor.protocols.drda import client as D
        s = self.state
        host = args[0] if args else (s.tool_host or s.host or "")
        if not host:
            self.console_line("# usage: connect <host> [port] [user] [pass] [rdb]")
            return
        try:
            port = int(args[1]) if len(args) > 1 else int(s.tool_port or 446)
        except (ValueError, IndexError):
            port = 446
        user = args[2] if len(args) > 2 else ""
        pw = args[3] if len(args) > 3 else ""
        rdb = args[4] if len(args) > 4 else ""
        self.console_line("")
        self.console_line(f"# connecting to DB2 DRDA {host}:{port} ...")

        def work():
            try:
                sess = D.DrdaSession(host, port)
                fp = sess.open()
                self._drda_sess = sess
                s.console_mode = "drdasql"
                self.console_line("  " + fp)
                if user:
                    oklogin, msg = sess.login(user, pw, rdb)
                    self.console_line("  " + msg)
                    if not oklogin:
                        self.console_line("  # try: LOGIN <userid> <password> [rdb]")
                else:
                    self.console_line("  # log in:  LOGIN <userid> <password> [rdb]")
            except Exception as e:
                self.console_line(f"# connect failed: {e}")
        threading.Thread(target=work, daemon=True).start()

    def _run_drdasql(self, cmd):
        sess = getattr(self, "_drda_sess", None)
        if sess is None:
            self.console_line("# not connected - type: connect <host> [port] [user] [pass] [rdb]")
            return
        low = cmd.strip().lower()
        if low in ("quit", "exit", "disconnect", ":q"):
            try: sess.close()
            except Exception: pass
            self._drda_sess = None
            self.state.console_mode = "sql"
            self.console_line("# disconnected from DB2")
            return
        parts = cmd.split()
        if parts and parts[0].upper() == "LOGIN" and len(parts) >= 3:
            user, pw = parts[1], parts[2]
            rdb = parts[3] if len(parts) > 3 else ""
            self.console_line(f"db2> LOGIN {user} ********")

            def work_login():
                try:
                    okl, msg = sess.login(user, pw, rdb)
                    self.console_line("  " + msg)
                except Exception as e:
                    self.console_line(f"# {e}")
            threading.Thread(target=work_login, daemon=True).start()
            return
        self.console_line(f"db2> {cmd}")

        def work():
            try:
                code, text = sess.execute(cmd)
                if code is None:
                    self.console_line("  " + text)
                else:
                    if code != 0:
                        self.console_line(f"  SQLCODE {code}")
                    for line in (text or "").splitlines()[:80]:
                        self._console_wrapped("    " + line)
                    if code == 0 and not text.strip():
                        self.console_line("  (0 rows)")
            except Exception as e:
                self.console_line(f"# error: {e}")
                self._drda_sess = None
                self.state.console_mode = "sql"
        threading.Thread(target=work, daemon=True).start()

    def _console_wrapped(self, text, width=112):
        """Emit a console line, wrapping overlong content instead of clipping it (fixes
        the connection-string / result overrun off the right edge of the box)."""
        if len(text) <= width:
            self.console_line(text)
            return
        indent = " " * (len(text) - len(text.lstrip()))
        while text:
            self.console_line(text[:width])
            text = indent + "  " + text[width:]

    def open_ezrecon(self):
        """EZrecon OSINT / recon toolkit - an interactive console.  You drive it by
        typing an operation and target into the command box and pressing Run, e.g.
        'dns example.com' or 'subs vertali.com'.  Same core as the TUI; API keys are
        prompted on first use and stored under ~/.config/phosphor.
        """
        from phosphor.audit import ezrecon as ez
        self.console_open("EZrecon  -  OSINT / recon (authorised targets only)")
        self.state.console_mode = "ezrecon"
        self.console_line("Type an operation + target in the command box, then Run:")
        self.console_line("")
        for op, desc, need in ez.OPERATIONS:
            arg = f" <{need}>" if need else ""
            self.console_line(f"  {op:<14}{arg:<10}  {desc}")
        self.console_line("")
        self.console_line("examples:  dns example.com   |   subs vertali.com   |   "
                          "shodan_host 8.8.8.8   |   backend")
        self.console_line("")

    def _run_ezrecon(self, cmd):
        """Run one EZrecon command from the console ('<op> [target]')."""
        from phosphor.audit import ezrecon as ez
        from phosphor.app import filepick
        parts = cmd.split(None, 1)
        op = parts[0].lower()
        target = parts[1].strip() if len(parts) > 1 else ""
        spec = next((o for o in ez.OPERATIONS if o[0] == op), None)
        self.console_line("")
        self.console_line(f"ezrecon> {cmd}")
        if spec is None:
            self.console_line(f"unknown operation '{op}'. try one of: "
                              + ", ".join(o[0] for o in ez.OPERATIONS))
            return
        _id, desc, need = spec
        if need and not target:
            self.console_line(f"usage: {op} <{need}>   e.g.  {op} example.com")
            return

        def work():
            prompt = lambda label: filepick.ask_text("EZrecon API key", f"{label}:")
            try:
                lines = ez.run(op, target, prompt=prompt)
            except Exception as e:
                lines = [f"error: {type(e).__name__}: {e}"]
            for ln in lines:
                self.console_line(ln)
            self._recon_log = (getattr(self, "_recon_log", [])
                               + [f"### EZrecon {op} {target}"] + list(lines))
        _run_bg(work)

    def build_tool_cmd(self):
        """(Re)build the staged command from the editable Host/Port fields."""
        from phosphor.toolchain import api_sql as A
        s = self.state
        h = s.tool_host or "HOST"
        p = s.tool_port.strip() if s.tool_port else ""
        if s.console_mode == "api":
            port = int(p) if p.isdigit() else 443
            s.console_cmd = A.curl_command(h, port, "/zosmf/info", "GET", "USER:PASS")
        elif s.console_mode == "sql":
            port = int(p) if p.isdigit() else 446
            s.console_cmd = A.db2_python_command(h, port)
        else:
            return
        s.field_cursor["console_cmd"] = len(s.console_cmd)
        s.note(f"command rebuilt for {h}:{p or '(default)'}")

    def open_hydra(self):
        from phosphor.toolchain import hydra as H
        s = self.state
        self.console_open(f"Hydra  -  {s.host or 'TARGET'}:{s.port}")
        if not H.have_hydra():
            self.console_line("# hydra not on PATH - install: apt install hydra")
        cmd = H.hydra_cmd_string(s.host or "TARGET", "telnet", int(s.port or 23),
                                 "users.txt", "passwords.txt")
        if s.host:
            self.console_line("# running now (edit the command and press Run to re-run):")
            self._run_now(cmd)               # <-- run it now
        else:
            self.console_line("# set a Host first, then press Run:")
            s.console_cmd = cmd
            s.field_cursor["console_cmd"] = len(cmd)
            s.focus = "console_cmd"

    def open_john(self):
        from phosphor.toolchain import crack as C
        from phosphor.toolchain import hashid as HID
        from phosphor.app import notes as notesmod
        import glob, os
        s = self.state
        self.console_open("John + hash-format detector  (GIBSON RACF DB)")
        # find a hash file in the tools dir and identify what's in it FIRST
        tools = str(notesmod.tools_dir())
        cands = (glob.glob(os.path.join(tools, "*.hashes")) + glob.glob(os.path.join(tools, "*racf*"))
                 + glob.glob(os.path.join(tools, "*.john")))
        hashfile = cands[0] if cands else None
        if hashfile:
            rep = HID.analyse_file(hashfile)
            for line in HID.format_report(rep, os.path.basename(hashfile)).splitlines():
                self.console_line(line)
            self.console_line("")
        else:
            self.console_line("# drop a hash file (*.hashes / *racf*) in the tools dir to auto-detect its type")
        if not C.have("john"):
            self.console_line("# john not found - install John jumbo (racf / racf-kdfaes)")
        self.console_line("# RACF crack chain (needs a GIBSON SYS1.RACFDS unload):")
        chain = C.full_chain_commands("SYS1.RACFDS", wordlist="passwords.txt")
        for c in chain:
            self.console_line("    " + c)
        self.console_line("# native RACF DES crack (no John - folds case, truncates to 8):")
        wl = os.path.join(tools, "passwords.txt")
        native = (f"python3 -m phosphor.toolchain.racf_des {hashfile} {wl}") if hashfile else None
        self.console_line("    " + (native or "python3 -m phosphor.toolchain.racf_des racf.hashes passwords.txt"))
        if native and os.path.exists(wl):
            self.console_line("# running native crack now (edit + Run for the John chain):")
            self._run_now(native)            # <-- run it now (works without external John)
        else:
            self.console_line("# add a hash file + passwords.txt to the tools dir to auto-run the native crack")
            s.console_cmd = chain[1] if len(chain) > 1 else chain[0]
            s.field_cursor["console_cmd"] = len(s.console_cmd)
            s.focus = "console_cmd"

    def open_cicspwn(self):
        from phosphor.toolchain import cicspwn as CP
        s = self.state
        self.console_open(f"CICSpwn  -  {s.host or 'TARGET'}:{s.port}")
        path = os.environ.get("PHOSPHOR_CICSPWN", "cicspwn.py")
        self.console_line("# CICSpwn through PHOSPHOR's emulator (no x3270). Edit --action to pick a mode:")
        for aid in CP.action_ids():
            self.console_line(f"#   {aid:<9} {CP.describe(aid)}")
        self.console_line("# reverse shells (rev_tso/rev_unix) need --lhost H:P + a Shell listener running.")
        s.console_cmd = CP.build_command(path, s.host or "TARGET", int(s.port or 23), "info", applid="CICS")
        s.field_cursor["console_cmd"] = len(s.console_cmd)
        s.focus = "console_cmd"

    def open_shell(self):
        """A simple local command prompt with scrollable history: type a command, it
        runs on this machine and the output streams into the console you can page
        up/down through (netcat, nmap, ssh, etc.). The reverse-shell listener is still
        here as the `listen` command."""
        s = self.state
        self._shell_cwd = getattr(self, "_shell_cwd", os.path.expanduser("~"))
        self.console_open("Shell  -  local command prompt")
        s.console_mode = "localshell"
        self.console_line("Local shell. Type a command and press Run/Enter; scroll with the")
        self.console_line("wheel or PgUp/PgDn. Built-ins:")
        self.console_line("  cd <dir>            change directory (persists between commands)")
        self.console_line("  listen [host:port]  start the reverse-shell listener (default 0.0.0.0:4444)")
        self.console_line("  clear               clear the screen")
        self.console_line("")
        self.console_line(f"{self._shell_cwd} $")
        s.focus = "console_cmd"

    def _run_localshell(self, cmd):
        s = self.state
        cwd = getattr(self, "_shell_cwd", os.path.expanduser("~"))
        # if a reverse shell has connected, drive it instead of running locally
        sh = getattr(self, "_shell", None)
        if sh is not None and sh.connected:
            self.console_line(f"remote> {cmd}")
            sh.send(cmd)
            return
        low = cmd.strip()
        if not low:
            self.console_line(f"{cwd} $")
            return
        if low in ("clear", "cls"):
            s.console_lines = []
            self.console_line(f"{cwd} $")
            return
        if low in ("exit", "quit"):
            self.console_line("# (local shell stays open; use another tool button to leave)")
            return
        if low.split()[0] == "cd":
            target = low[2:].strip() or os.path.expanduser("~")
            target = os.path.expanduser(target)
            if not os.path.isabs(target):
                target = os.path.normpath(os.path.join(cwd, target))
            if os.path.isdir(target):
                self._shell_cwd = target
                self.console_line(f"{target} $")
            else:
                self.console_line(f"cd: no such directory: {target}")
            return
        if low.split()[0] == "listen":
            ep = low.split(None, 1)[1].strip() if len(low.split()) > 1 else \
                os.environ.get("PHOSPHOR_SHELL_LISTEN", "0.0.0.0:4444")
            self._start_reverse_listener(ep)
            return

        def work():
            import subprocess
            self.console_line(f"{cwd} $ {cmd}")
            try:
                p = subprocess.Popen(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, bufsize=1)
                for line in iter(p.stdout.readline, ""):
                    if not line:
                        break
                    self.console_line(line.rstrip("\n")[:200])
                p.wait()
                self.console_line(f"[exit {p.returncode}]")
            except Exception as e:
                self.console_line(f"ERROR: {e}")
        _run_bg(work)

    def _start_reverse_listener(self, ep):
        from phosphor.toolchain.shell import ShellSession
        s = self.state
        if getattr(self, "_shell", None) and s.shell_on:
            self.console_line("# reverse-shell listener already running")
            return
        self._shell = ShellSession("listen", ep)
        self._shell.start()
        s.shell_on = True
        self.console_line(f"# reverse-shell listener on {ep} - point a TShocker / CICSpwn shell back here")
        self.console_line("# when it connects, commands you type go to the remote (remote>)")

    def toggle_shell(self):
        from phosphor.toolchain.shell import ShellSession
        s = self.state
        if not s.shell_on:
            ep = os.environ.get("PHOSPHOR_SHELL_LISTEN", "0.0.0.0:4444")
            self._shell = ShellSession("listen", ep)
            self._shell.start()
            s.shell_on = True
            self.console_open("Reverse shell listener")
            self.console_line(f"# listening on {ep} - point a TShocker / CICSpwn reverse shell back here")
            self.console_line("# once it connects, type in the command box to drive the shell")
            s.focus = "console_cmd"
        else:
            if getattr(self, "_shell", None):
                self._shell.stop()
            self._shell = None
            s.shell_on = False
            self.console_line("# shell listener stopped")

    def _poll_shell(self):
        sh = getattr(self, "_shell", None)
        if sh is not None:
            for line in sh.drain():
                self.console_line(line)

    def scan_passtickets(self):
        s = self.state
        self.console_open("PassTicket  -  recognise (scan) and forge (gen)")
        s.console_mode = "passticket"
        self.console_line("A PassTicket is a single-use, time-bound credential RACF accepts")
        self.console_line("instead of a password. Commands (type in the box, then Run):")
        self.console_line("")
        self.console_line("  scan                         classify captured logon credentials")
        self.console_line("  gen <user> <applid> <keyhex> forge a PassTicket (16-hex secured-signon key)")
        self.console_line("  genwin <user> <applid> <keyhex>   forge for now +/-2s (host clock skew)")
        self.console_line("")
        self.console_line("The key is the RACF PTKTDATA/SESSKEY for the application; recover it from")
        self.console_line("the RACF database (unmask) or a config. Ticket is valid +/-10 min of host GMT.")
        self.console_line("")
        self._passticket_scan()

    def _passticket_scan(self):
        from phosphor.toolchain import passticket as PT
        from phosphor.toolchain import pcap as pcapmod
        from phosphor.app import notes as notesmod
        import glob
        s = self.state
        pkts = list(s.packets or [])
        source = "live tap"
        if not pkts:
            path = s.capture_path
            if not path:
                caps = sorted(glob.glob(str(notesmod.tools_dir() / "*.pcap")),
                              key=os.path.getmtime)
                path = caps[-1] if caps else ""
            if path:
                pkts = pcapmod.read_pcap(path, int(s.port or 23))
                source = os.path.basename(path)
        self.console_line(f"# scan source: {source}  ({len(pkts)} record(s))")
        for line in PT.format_report(PT.scan_capture(pkts)).splitlines():
            self.console_line(line)
        if not pkts:
            self.console_line("# tip: enable Capture PCAP and log in, or drop a .pcap in the tools dir.")

    def _run_passticket(self, cmd):
        from phosphor.toolchain import passticket as PT
        parts = cmd.split()
        op = parts[0].lower() if parts else ""
        if op == "scan":
            self.console_line(""); self._passticket_scan(); return
        if op in ("gen", "genwin"):
            if len(parts) < 4:
                self.console_line(f"# usage: {op} <userid> <applid> <keyhex-16>")
                return
            user, applid, key = parts[1], parts[2], parts[3]
            try:
                if op == "gen":
                    t = PT.generate_passticket(user, applid, key)
                    self.console_line(f"$ gen {user} {applid}")
                    self.console_line(f"  PassTicket: {t}   (valid now +/-10 min of host GMT)")
                else:
                    self.console_line(f"$ genwin {user} {applid}  (host-clock-skew spread)")
                    for off, t in PT.passticket_window(user, applid, key, spread=2):
                        self.console_line(f"  t{off:+d}s  {t}")
            except ValueError as e:
                self.console_line(f"# {e}")
            except Exception as e:
                self.console_line(f"# generation failed: {e}")
            return
        self.console_line("# usage: scan | gen <user> <applid> <keyhex> | genwin <user> <applid> <keyhex>")

    def shutdown(self):
        """Clean up (close capture, stop proxy, disconnect) and exit the app."""
        self._save_prefs()
        try:
            if getattr(self, "_pcap", None):
                self._pcap.close()
            self._stop_hack3270()
            if getattr(self, "_shell", None):
                self._shell.stop()
            if self.conn is not None:
                self.conn.terminate()
        except Exception:
            pass
        self.state.quit = True

    def _apply_edit(self, attr: str, ch, keyname) -> None:
        """Edit a string field via the shared LineEditor (cursor + insert)."""
        s = self.state
        text = getattr(s, attr)
        cur = s.field_cursor.get(attr, len(text))
        ed = LineEditor(text, cur, s.insert_mode)
        ed.key(ch, keyname, ctrl=s.ctrl_down)
        setattr(s, attr, ed.text)
        s.field_cursor[attr] = ed.cursor
        s.insert_mode = ed.insert

    def on_key(self, ch, keyname):
        s = self.state
        kn = (keyname or "").lower()
        # '?' opens help when nothing editable is focused; Esc closes any popup/help
        if kn == "escape" and (s.help_open or s.about_open):
            s.help_open = False; s.about_open = False; return
        if ch == "?" and not s.help_open and s.focus is None:
            s.help_open = True; return
        if s.help_open:
            if kn in ("escape", "return", "space"):
                s.help_open = False
            return
        # F7 / F8 scroll the tool console output (up / down)
        if s.console_open and kn in ("f7", "f8"):
            if kn == "f7":
                s.console_scroll += 5
            else:
                s.console_scroll = max(0, s.console_scroll - 5)
            return
        # editable console command (the tool / nmap box)
        if s.focus == "console_cmd":
            if kn == "return":
                self.run_console_cmd()
            else:
                self._apply_edit("console_cmd", ch, keyname)
            return
        # API/SQL editable Host / Port fields
        if s.focus in ("tool_host", "tool_port"):
            if kn == "return":
                self.build_tool_cmd()
                s.focus = "console_cmd"
            elif kn == "tab":
                s.focus = "tool_port" if s.focus == "tool_host" else "tool_host"
            else:
                self._apply_edit(s.focus, ch, keyname)
            return
        # notepad editing
        if s.focus == "notes":
            if kn == "return":
                self._apply_edit("notes_text", "\n", None)
            else:
                self._apply_edit("notes_text", ch, keyname)
            return
        # task input
        if s.focus == "task_input":
            if kn == "return":
                self.add_task()
            else:
                self._apply_edit("task_input", ch, keyname)
            return
        # notepad filename field (in-client file naming)
        if s.focus == "notes_name":
            self._apply_edit("notes_name", ch, keyname)
            return
        # tools unlock password field
        if s.tools_popup and s.focus == "tools_pw":
            if kn == "return":
                self._tools_activate(); return
            self._apply_edit("tools_pw", ch, keyname)
            return
        # license email + token fields
        if s.license_open and s.focus == "license_email":
            if kn == "return":
                self._license_activate(); return
            self._apply_edit("license_email", ch, keyname)
            return
        if s.license_open and s.focus == "license_token":
            if kn == "return":
                self._license_activate(); return
            self._apply_edit("license_token", ch, keyname)
            return
        # FTP fields
        if s.ftp_open and s.ftp_focus in ("host", "user", "pass", "dsn"):
            if kn == "return":
                if s.ftp_focus == "dsn":
                    self.ftp_list_hlq(); return
                self.ftp_connect(); return
            self._apply_edit("ftp_" + s.ftp_focus, ch, keyname)
            return
        # PF1-PF12 and PA keys drive the session whenever connected
        if self.editor and kn.startswith("f") and kn[1:].isdigit():
            self.editor.pf(int(kn[1:])); self._refresh_grid(); return
        # typing directly on the 3270 screen (the real terminal behaviour)
        if s.focus == "screen" and self.editor:
            if kn == "return":
                self.editor.enter(); self._refresh_grid()
            elif kn == "tab":
                (self.editor.tab(back=True) if s.shift_down else self.editor.tab()); self._refresh_grid()
            elif kn == "down":
                self.editor.field_down(); self._refresh_grid()
            elif kn == "up":
                self.editor.field_up(); self._refresh_grid()
            elif kn == "left":
                self.editor.move(0, -1); self._refresh_grid()
            elif kn == "right":
                self.editor.move(0, 1); self._refresh_grid()
            elif kn == "home":
                f = self.editor._field_at(*self.editor.cursor)
                if f:
                    self.editor.cursor = (f.row, f.col); self._refresh_grid()
            elif kn == "backspace":
                self.editor.backspace(); self._refresh_grid()
            elif kn == "escape":
                self.editor.clear(); self._refresh_grid()
            elif ch and ch.isprintable():
                self.editor.type_char(ch); self._refresh_grid()
            return
        # otherwise the sidebar fields / command line
        target = {"cmd": "cmdline", "f_host": "host", "f_port": "port"}.get(s.focus)
        if target is None:
            return
        if kn == "return" and target == "cmdline":
            self.send_command(); return
        self._apply_edit(target, ch, keyname)


def _volatile_sig(s, hover, pressed):
    """A cheap fingerprint of everything that affects what's on screen, so the
    loop can skip rendering (and CPU) when nothing has changed.  Shares the exact
    field list with the renderer (ui._frame_sig) so the two never drift."""
    from phosphor.app.ui import _frame_sig
    return _frame_sig(s, hover, pressed)


def _parse_target(argv):
    """Parse a `host`, `host:port`, or `host port` target (+ optional --5250/--tn5250)
    from argv, for launching straight into a connected session.  Returns
    (host, port, protocol) or None."""
    args = list(argv if argv is not None else sys.argv[1:])
    proto = "3270"
    engine = "native"
    rest = []
    skip = False
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        low = a.lower()
        if low in ("--5250", "--tn5250", "-5"):
            proto = "5250"
        elif low in ("--3270", "--tn3270"):
            proto = "3270"
        elif low == "--engine":
            engine = args[i + 1] if i + 1 < len(args) else "native"
            skip = True
        elif low.startswith("--engine="):
            engine = low.split("=", 1)[1]
        elif low in ("--gui", "--connect"):
            continue
        else:
            rest.append(a)
    if not rest:
        return None
    host, port = rest[0], (rest[1] if len(rest) > 1 else None)

    # secure URI schemes -> implicit TLS (kept as an L: prefix for the connect flow)
    secure = False
    for scheme in ("tn3270s://", "tn5250s://", "telnets://"):
        if host.lower().startswith(scheme):
            secure = True
            if scheme.startswith("tn5250"):
                proto = "5250"
            host = host[len(scheme):]; break
    else:
        for scheme in ("tn3270://", "tn5250://", "telnet://"):
            if host.lower().startswith(scheme):
                if scheme.startswith("tn5250"):
                    proto = "5250"
                host = host[len(scheme):]; break

    # peel x3270-style single-letter prefixes (L:/Y:/A:) before splitting the port,
    # then re-attach them so the connect path can act on them
    prefix = ""
    while len(host) > 2 and host[1] == ":" and host[0].isalpha():
        prefix += host[:2]; host = host[2:]
    if ":" in host and port is None:
        host, _, p = host.rpartition(":")
        port = p
    try:
        port = int(port) if port else None
    except ValueError:
        port = None
    if secure and "L:" not in prefix.upper():
        prefix = "L:" + prefix
    tls_on = "L:" in prefix.upper() or "Y:" in prefix.upper()
    if port is None:
        port = 992 if (tls_on or proto == "5250") else 23
    if not host:
        return None
    return prefix + host, port, proto, engine


def main(argv=None):
    try:
        import pygame
    except Exception:
        print("PHOSPHOR needs pygame:  pip install pygame numpy pillow")
        return 2
    import numpy as np  # noqa

    target = _parse_target(argv)
    client = Client()
    try:
        from phosphor.app import prefs
        prefs.apply_to(client.state)          # restore saved skin / font / bezel / unlocks
        from phosphor.app import license as lic
        client.state.tools_unlocked = lic.tools_unlocked()
        client.crt._app_sig = None            # glass re-renders in the restored skin
    except Exception:
        pass
    # init only the subsystems we use.  A plain pygame.init() also spins up the
    # audio/mixer subsystem, which on machines with no / an odd audio device can
    # block for ~30s probing hardware - PHOSPHOR uses no audio, so skip it.
    os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
    try:
        pygame.display.init()
        pygame.font.init()
    except Exception:
        pygame.init()                     # fall back if selective init isn't available
    win_w, win_h = WIN_W, WIN_H
    flags = pygame.RESIZABLE
    screen = pygame.display.set_mode((win_w, win_h), flags)
    pygame.display.set_caption("PHOSPHOR")
    # window / taskbar / dock icon while running (same art as the packaged app icon).
    # Bundled under phosphor/app/assets, so it resolves in dev and under PyInstaller.
    try:
        _icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "assets", "phosphor_icon.png")
        pygame.display.set_icon(pygame.image.load(_icon_path))
    except Exception:
        pass
    try:
        hintfont = pygame.font.Font(None, 24)
    except Exception:
        hintfont = None
    fullscreen = False

    if target:                                # launched as: phosphor host[:port] [--5250]
        host, port, proto, engine = target
        client.state.host = host
        client.state.port = str(port)
        client.state.protocol = proto
        client.state.engine = engine
        client.state.status = f"connecting to {host}:{port} ..."
        try:
            client.connect()                  # non-blocking (connects on a worker thread)
        except Exception as e:
            client.state.note(f"auto-connect error: {e}")

    def _fit():
        """Scale + offset to fit the WIN_W x WIN_H design canvas into the current
        window, preserving aspect (letterboxed)."""
        sw, sh = screen.get_size()
        s = min(sw / WIN_W, sh / WIN_H)
        w, h = int(WIN_W * s), int(WIN_H * s)
        return s, (sw - w) // 2, (sh - h) // 2, w, h

    def _to_design(pos):
        s, ox, oy, _, _ = _fit()
        return ((pos[0] - ox) / s, (pos[1] - oy) / s)

    t0 = time.time()
    running = True
    hm = None
    hover = None
    pressed = None
    last_sig = None
    dirty = True                      # force the first frame
    while running:
        if getattr(client.state, "quit", False):
            break

        # 1) Draw only when something actually changed (an input this iteration,
        #    a background thread mutating state, or live CRT animation).
        sig = _volatile_sig(client.state, hover, pressed) + (screen.get_size(), client.state.focus_mode)
        animated = getattr(client.crt, "_animated", False)
        if dirty or sig != last_sig or animated:
            if client.state.focus_mode:
                # detached terminal: bezel + glass, scaled to fill the window (x zoom)
                term_img, _gr = render_terminal_only(client.state, client.crt, time.time() - t0)
                tw, th = term_img.size
                sw, sh = screen.get_size()
                zoom = max(0.5, min(client.state.font_px / 20.0, 3.0))
                # 'cover' fill so the terminal fills the screen (minimal surround);
                # only the outer bezel edge is cropped, never the glass.
                scale = max(sw / tw, sh / th) * zoom
                dw, dh = max(1, int(tw * scale)), max(1, int(th * scale))
                surf = pygame.transform.smoothscale(
                    pygame.image.frombuffer(term_img.tobytes(), (tw, th), "RGB"), (dw, dh))
                screen.fill((6, 6, 8))
                screen.blit(surf, ((sw - dw) // 2, (sh - dh) // 2))
                if hintfont is not None:                       # small exit / zoom hint
                    tip = hintfont.render("Esc / F10 exit  \u00b7  Ctrl +/- zoom", True, (150, 156, 168))
                    tip.set_alpha(150); screen.blit(tip, (16, sh - 28))
                pygame.display.flip()
                hm = None
            else:
                img, hm = render_app_frame(client.state, client.crt, time.time() - t0, hover, pressed)
                surf = pygame.image.frombuffer(img.tobytes(), img.size, "RGB")
                s, ox, oy, w, h = _fit()
                if (w, h) != (WIN_W, WIN_H):
                    surf = pygame.transform.smoothscale(surf, (w, h))
                screen.fill((14, 14, 14))       # letterbox bars
                screen.blit(surf, (ox, oy))
                pygame.display.flip()
            last_sig = sig
            dirty = False

        # 2) Sleep until an event arrives (near-zero CPU while idle).  The timeout
        #    is only as long as our slowest periodic need: ~33ms while the CRT is
        #    animating, otherwise a 100ms poll so background-thread updates (scans,
        #    shell output) still surface promptly without busy-spinning.
        ev = pygame.event.wait(33 if animated else 100)
        events = []
        if ev.type != pygame.NOEVENT:
            events.append(ev)
            events.extend(pygame.event.get())   # drain the rest of the burst -> one redraw
        client._poll_shell()

        for e in events:
            dirty = True                        # any input -> redraw next pass
            if e.type == pygame.QUIT:
                running = False
            elif e.type in (pygame.VIDEOEXPOSE, pygame.ACTIVEEVENT):
                dirty = True                    # WM asked us to repaint (fixes blank-until-click)
            elif e.type == pygame.VIDEORESIZE and not fullscreen:
                screen = pygame.display.set_mode((max(800, e.w), max(500, e.h)), flags)
            elif e.type == pygame.MOUSEMOTION and hm is not None:
                hover = hm.hit(*_to_design(e.pos))
            elif e.type == pygame.MOUSEWHEEL:
                client._popup_scroll(e.y)
            elif e.type == pygame.MOUSEBUTTONDOWN:
                if e.button in (4, 5):                     # wheel (older SDL reports as buttons)
                    client._popup_scroll(1 if e.button == 4 else -1)
                elif client.state.focus_mode:
                    sw, sh = screen.get_size()
                    if e.pos[0] > sw - 70 and e.pos[1] < 70:   # top-right corner exits
                        client.state.focus_mode = False
                elif hm is not None:
                    dp = _to_design(e.pos)
                    pressed = hm.hit(*dp)
                    client.on_click(pressed, *dp)
            elif e.type == pygame.MOUSEBUTTONUP:
                pressed = None
            elif e.type == pygame.KEYDOWN:
                name = pygame.key.name(e.key)
                mods = getattr(e, "mod", 0) or pygame.key.get_mods()
                client.state.ctrl_down = bool(mods & pygame.KMOD_CTRL)
                client.state.shift_down = bool(mods & pygame.KMOD_SHIFT)
                ctrl = bool(mods & pygame.KMOD_CTRL)
                if name == "f10":
                    client.state.focus_mode = not client.state.focus_mode
                elif name == "escape" and client.state.focus_mode:
                    client.state.focus_mode = False
                elif name == "f11" or (name == "return" and (mods & pygame.KMOD_ALT)):
                    fullscreen = not fullscreen
                    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN) if fullscreen \
                        else pygame.display.set_mode((WIN_W, WIN_H), flags)
                elif name == "escape" and fullscreen:
                    fullscreen = False
                    screen = pygame.display.set_mode((WIN_W, WIN_H), flags)
                elif ctrl and name in ("=", "+", "kp+", "kp_plus"):
                    client.state.font_px = min(48, client.state.font_px + 2)
                    client.crt._app_sig = None
                    client._save_prefs()
                elif ctrl and name in ("-", "_", "kp-", "kp_minus"):
                    client.state.font_px = max(12, client.state.font_px - 2)
                    client.crt._app_sig = None
                    client._save_prefs()
                elif ctrl and name == "0":
                    client.state.font_px = 20
                    client.crt._app_sig = None
                    client._save_prefs()
                else:
                    client.on_key(e.unicode, name)
    pygame.quit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
