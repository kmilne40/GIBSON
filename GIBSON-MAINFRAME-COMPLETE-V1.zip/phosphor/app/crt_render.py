"""Software CRT renderer - the cool-retro-term look, computed on the CPU.

No OpenGL, no GPU.  The trick for real-time speed: the expensive effects (bloom,
curvature/glass, scanlines, chroma, vignette) depend only on the *text*, so they
are computed once in prepare() when the screen changes.  render(t) then only adds
the genuinely time-varying effects (glow-line sweep, flicker, noise), which are
cheap - so it stays smooth on modest hardware with no GPU.
"""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageFilter

from phosphor.crt.config import EffectConfig


def _to_float(img):
    return np.asarray(img.convert("RGB"), dtype=np.float32) / 255.0


class SoftCRT:
    def __init__(self, cfg, size):
        self.cfg = cfg
        self.w, self.h = size
        self._static = None
        self._prev_static = None
        self._geom = {}
        self._glow_y = np.linspace(0, 1, self.h)

    def _curvature_map(self, amount):
        key = ("curve", amount)
        if key not in self._geom:
            h, w = self.h, self.w
            yy, xx = np.meshgrid(np.linspace(-1, 1, h), np.linspace(-1, 1, w), indexing="ij")
            off = np.abs(np.stack([yy, xx])) ** 2
            cx = xx + xx * off[0] * amount * 1.3
            cy = yy + yy * off[1] * amount * 1.3
            sx = np.clip(((cx + 1) * 0.5 * (w - 1)).astype(np.int32), 0, w - 1)
            sy = np.clip(((cy + 1) * 0.5 * (h - 1)).astype(np.int32), 0, h - 1)
            inside = ((cx >= -1) & (cx <= 1) & (cy >= -1) & (cy <= 1))[:, :, None]
            self._geom[key] = (sy, sx, inside.astype(np.float32))
        return self._geom[key]

    def _vignette(self, amount):
        key = ("vig", amount)
        if key not in self._geom:
            yy, xx = np.meshgrid(np.linspace(-1, 1, self.h), np.linspace(-1, 1, self.w), indexing="ij")
            v = np.clip(1.0 - (xx ** 2 + yy ** 2) * amount * 0.9, 0, 1)
            self._geom[key] = v[:, :, None].astype(np.float32)
        return self._geom[key]

    def _scanmask(self, amount):
        key = ("scan", amount)
        if key not in self._geom:
            s = np.sin(np.linspace(0, np.pi * self.h, self.h)) ** 2
            self._geom[key] = (1.0 - amount * 0.6 * s)[:, None, None].astype(np.float32)
        return self._geom[key]

    def _bloom(self, arr):
        a = self.cfg.bloom
        if a <= 0:
            return arr
        lum = arr.max(axis=2, keepdims=True)
        bright = arr * np.clip((lum - 0.45) / 0.35, 0, 1)
        qw, qh = max(1, self.w // 4), max(1, self.h // 4)
        small = Image.fromarray(np.clip(bright * 255, 0, 255).astype(np.uint8)).resize((qw, qh))
        small = small.filter(ImageFilter.GaussianBlur(1.5 + 3.0 * self.cfg.bloom_radius))
        blur = np.asarray(small.resize((self.w, self.h)), dtype=np.float32) / 255.0
        return 1.0 - (1.0 - arr) * (1.0 - blur * a * 1.7)

    def prepare(self, text_img):
        cfg = self.cfg
        if text_img.size != (self.w, self.h):
            text_img = text_img.resize((self.w, self.h), Image.LANCZOS)
        # FAST PATH: with no CRT effects (the default flat look), skip the whole
        # float pipeline - it was re-processing ~460k pixels on every keystroke and
        # is the typing lag. Just hand back the RGB bytes, crisp and cheap.
        if not (cfg.bloom or cfg.scanlines or cfg.curvature or cfg.vignette
                or cfg.rgb_shift or cfg.burn_in or cfg.ambient or cfg.glow_line
                or cfg.noise or cfg.flicker or cfg.contrast != 1 or cfg.brightness != 1):
            arr = np.asarray(text_img.convert("RGB"), dtype=np.uint8)
            self._static_u8 = arr
            self._static = arr            # non-None so render() returns pixels, not black
            self._prev_static = None
            self._animated = False
            return
        img = _to_float(text_img)
        img = self._bloom(img)
        img = img + cfg.ambient * 0.06
        if cfg.scanlines > 0:
            img = img * self._scanmask(cfg.scanlines)
        if cfg.rgb_shift > 0:
            px = max(1, int(round(cfg.rgb_shift * 4)))
            img[:, :, 0] = np.roll(img[:, :, 0], px, axis=1)
            img[:, :, 2] = np.roll(img[:, :, 2], -px, axis=1)
        if cfg.curvature > 0:
            sy, sx, inside = self._curvature_map(cfg.curvature)
            img = img[sy, sx] * inside
        if cfg.vignette > 0:
            img = img * self._vignette(cfg.vignette)
        if cfg.burn_in > 0 and self._prev_static is not None:
            decay = 0.30 + 0.62 * cfg.burn_in
            img = np.maximum(img, self._prev_static * decay)
        self._prev_static = img.copy()
        # bake the non-animating levels in, and store in 0-255 so per-frame has
        # no *255 pass; also keep a ready uint8 copy for the "no animation" case.
        if cfg.contrast != 1:
            img = (img - 0.5) * cfg.contrast + 0.5
        img = img * (cfg.brightness * 255.0)
        self._static = img                                   # float 0-255
        self._static_u8 = np.clip(img, 0, 255).astype(np.uint8)
        # precompute the animated flag so render() can early-out
        self._animated = (cfg.glow_line > 0 or cfg.noise > 0 or cfg.flicker > 0)

    def render(self, t):
        cfg = self.cfg
        if self._static is None:
            return np.zeros((self.h, self.w, 3), np.uint8)
        if not self._animated:
            return self._static_u8                            # nothing moves -> reuse
        img = self._static.copy()
        if cfg.glow_line > 0:
            pos = (t * 0.12) % 1.0
            band = np.exp(-((self._glow_y - pos) ** 2) / (2 * 0.02 ** 2)) * (cfg.glow_line * 0.25 * 255.0)
            img += band[:, None, None]
        if cfg.noise > 0:
            img += (np.random.random((self.h, self.w, 1)).astype(np.float32) - 0.5) * (cfg.noise * 0.15 * 255.0)
        if cfg.flicker > 0:
            img *= 1.0 - cfg.flicker * 0.10 * (np.random.random() - 0.5)
        return np.clip(img, 0, 255).astype(np.uint8)

    def frame(self, text_img, t=0.0):
        self.prepare(text_img)
        return self.render(t)
