"""File-open / save dialogs that don't hang the pygame loop.

The old code built a Tk root on the main thread and ran a modal dialog, which
deadlocks against SDL (two GUI toolkits fighting for the main thread / WM focus).
Here every dialog runs in a *separate process* (native zenity/kdialog on Linux,
osascript on macOS, PowerShell on Windows, or a one-shot Tk subprocess as a last
resort).  Call these from a background thread; the pygame event loop keeps
spinning while the dialog is open, so it never freezes.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from typing import Optional

_TIMEOUT = 300  # seconds a dialog may stay open


def _run(cmd) -> Optional[str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=_TIMEOUT)
    except Exception:
        return None
    if p.returncode != 0:
        return None
    out = (p.stdout or "").strip()
    return out or None


def _tk_subprocess(mode: str, title: str, default: str) -> Optional[str]:
    """Last resort: run Tk in its own process so it can't touch our SDL thread."""
    code = (
        "import sys,tkinter as tk\n"
        "from tkinter import filedialog\n"
        "r=tk.Tk();r.withdraw();r.update()\n"
        f"m={mode!r};t={title!r};d={default!r}\n"
        "p=filedialog.asksaveasfilename(title=t,initialfile=d) if m=='save' "
        "else filedialog.askopenfilename(title=t)\n"
        "sys.stdout.write(p or '')\n"
    )
    return _run([sys.executable, "-c", code])


def _pick(mode: str, title: str, default: str = "") -> Optional[str]:
    if shutil.which("zenity"):
        args = ["zenity", "--file-selection", "--title", title]
        if mode == "save":
            args += ["--save", "--confirm-overwrite"]
            if default:
                args += ["--filename", default]
        return _run(args)
    if shutil.which("kdialog"):
        flag = "--getsavefilename" if mode == "save" else "--getopenfilename"
        return _run(["kdialog", flag, default or os.path.expanduser("~"), "", "--title", title])
    if sys.platform == "darwin" and shutil.which("osascript"):
        act = "choose file name" if mode == "save" else "choose file"
        script = f'POSIX path of (%s with prompt "%s")' % (act, title)
        return _run(["osascript", "-e", script])
    if sys.platform.startswith("win"):
        return _tk_subprocess(mode, title, default)
    return _tk_subprocess(mode, title, default)


def open_file(title: str = "Choose a file") -> Optional[str]:
    return _pick("open", title)


def save_file(title: str = "Save as", default: str = "") -> Optional[str]:
    return _pick("save", title, default)


def ask_text(title: str, prompt: str, default: str = "") -> Optional[str]:
    """A one-line text prompt (dataset name, etc.), also off the main thread."""
    if shutil.which("zenity"):
        return _run(["zenity", "--entry", "--title", title, "--text", prompt,
                     "--entry-text", default])
    if shutil.which("kdialog"):
        return _run(["kdialog", "--inputbox", prompt, default, "--title", title])
    code = ("import sys,tkinter as tk\nfrom tkinter import simpledialog\n"
            "r=tk.Tk();r.withdraw();r.update()\n"
            f"v=simpledialog.askstring({title!r},{prompt!r},initialvalue={default!r})\n"
            "sys.stdout.write(v or '')\n")
    return _run([sys.executable, "-c", code])


def available() -> bool:
    """True if any real dialog backend exists (else callers should prompt in-app)."""
    return bool(shutil.which("zenity") or shutil.which("kdialog")
                or (sys.platform == "darwin" and shutil.which("osascript"))
                or sys.platform.startswith("win"))


def _clip_cmds(write: bool):
    if sys.platform == "darwin":
        return [["pbcopy"] if write else ["pbpaste"]]
    if sys.platform.startswith("win"):
        return [["clip"]] if write else []
    cmds = []
    if shutil.which("wl-copy") or shutil.which("wl-paste"):
        cmds.append(["wl-copy"] if write else ["wl-paste", "-n"])
    if shutil.which("xclip"):
        cmds.append(["xclip", "-selection", "clipboard"] + ([] if write else ["-o"]))
    if shutil.which("xsel"):
        cmds.append(["xsel", "-b", "-i"] if write else ["xsel", "-b", "-o"])
    return cmds


def copy_text(text: str) -> bool:
    for cmd in _clip_cmds(True):
        try:
            subprocess.run(cmd, input=text, text=True, timeout=5, check=True)
            return True
        except Exception:
            continue
    return False


def paste_text() -> str:
    for cmd in _clip_cmds(False):
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if p.returncode == 0:
                return p.stdout
        except Exception:
            continue
    return ""
