"""3270 screen model.

A ``ScreenBuffer`` is a grid of ``Cell`` objects.  Every cell carries not just a
character but its full presentation: 3270 base colour, extended highlighting,
protection and intensity.  That is deliberate -- the audit engine only needs the
text, but the CRT frontend needs the colour and highlight of every cell to paint
a real colour-3279 display, so the model records it from the very first parse.

Clean-room implementation (PHOSPHOR).  No third-party 3270 code.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# 3270 base colours (extended attribute 0x42 values).  Names, not RGB -- the
# frontend maps a name to whatever phosphor/palette is active.
COLOURS = {
    0xF1: "blue",
    0xF2: "red",
    0xF3: "pink",
    0xF4: "green",
    0xF5: "turquoise",
    0xF6: "yellow",
    0xF7: "white",
    0xF0: "neutral",
}
DEFAULT_COLOUR = "green"

# Extended highlighting (extended attribute 0x41 values).
HIGHLIGHTS = {
    0x00: "normal",
    0xF1: "blink",
    0xF2: "reverse",
    0xF4: "underscore",
}


@dataclass
class Cell:
    char: str = " "
    colour: str = DEFAULT_COLOUR
    highlight: str = "normal"
    protected: bool = True
    intensified: bool = False
    hidden: bool = False          # non-display (still holds the real value)
    is_field_start: bool = False  # this cell holds a field attribute

    def copy(self) -> "Cell":
        return Cell(self.char, self.colour, self.highlight, self.protected,
                    self.intensified, self.hidden, self.is_field_start)


@dataclass
class Field:
    """A contiguous field starting just after a field-attribute cell."""
    row: int
    col: int
    length: int
    protected: bool
    colour: str
    highlight: str
    intensified: bool
    hidden: bool

    @property
    def is_input(self) -> bool:
        return not self.protected


class ScreenBuffer:
    def __init__(self, rows: int = 24, cols: int = 80) -> None:
        self.rows = rows
        self.cols = cols
        self.cells: List[Cell] = [Cell() for _ in range(rows * cols)]
        self.cursor: int = 0            # linear buffer address
        self.field_table = None         # explicit field list (5250 gives lengths)
        self.keyboard_locked: bool = False

    # --- addressing ------------------------------------------------------
    def addr(self, row: int, col: int) -> int:
        return (row - 1) * self.cols + (col - 1)

    def rc(self, addr: int) -> Tuple[int, int]:
        return (addr // self.cols) + 1, (addr % self.cols) + 1

    # --- mutation --------------------------------------------------------
    def clear(self) -> None:
        self.cells = [Cell() for _ in range(self.rows * self.cols)]
        self.cursor = 0

    def set_cell(self, addr: int, cell: Cell) -> None:
        if 0 <= addr < len(self.cells):
            self.cells[addr] = cell

    # --- reading ---------------------------------------------------------
    def row_text(self, row: int) -> str:
        start = (row - 1) * self.cols
        return "".join(c.char for c in self.cells[start:start + self.cols])

    def to_rows(self) -> List[str]:
        """List of row strings -- the classic ``screen_get`` surface."""
        return [self.row_text(r) for r in range(1, self.rows + 1)]

    def text(self) -> str:
        return "\n".join(self.to_rows())

    def find(self, needle: str) -> bool:
        return needle in self.text()

    def fields(self) -> List[Field]:
        """Reconstruct fields from field-attribute cells (for input tabbing and
        for the frontend to know where input areas are).

        If an explicit field table has been set (5250 sends each field's length
        directly, and later writes can clobber the attribute cells), that is used
        verbatim - otherwise fields are inferred 3270-style as the run from one
        field-attribute cell to the next."""
        if self.field_table is not None:
            return list(self.field_table)
        out: List[Field] = []
        starts = [i for i, c in enumerate(self.cells) if c.is_field_start]
        for idx, s in enumerate(starts):
            attr = self.cells[s]
            body = s + 1
            end = starts[idx + 1] if idx + 1 < len(starts) else len(self.cells)
            r, c = self.rc(body % len(self.cells))
            out.append(Field(row=r, col=c, length=max(0, end - body),
                             protected=attr.protected, colour=attr.colour,
                             highlight=attr.highlight, intensified=attr.intensified,
                             hidden=attr.hidden))
        return out

    def input_fields(self) -> List[Field]:
        return [f for f in self.fields() if f.is_input]

    # --- colour export for the CRT frontend ------------------------------
    def colour_grid(self) -> List[List[Tuple[str, str, str]]]:
        """rows x cols of (char, colour, highlight) -- what the renderer draws."""
        grid = []
        for r in range(self.rows):
            line = []
            for c in range(self.cols):
                cell = self.cells[r * self.cols + c]
                line.append((cell.char, cell.colour, cell.highlight))
            grid.append(line)
        return grid
