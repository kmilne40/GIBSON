"""A tiny built-in "notepad" for wordlists.

When a scan wants a users.txt / passwords.txt / idlist that isn't there, the menu
opens this instead of erroring: a dependency-free, line-per-entry editor with
add / delete / list / seed / save, so you never have to leave the tool or
remember an external editor.
"""
from __future__ import annotations

import os
from typing import Callable, List, Optional

# starter lists so nobody stares at a blank file
SEEDS = {
    "users": ["IBMUSER", "SYSADM", "SYSPROG", "CICSUSER", "CICSADM", "OPER",
              "OPERATOR", "TSOUSER", "DB2ADM", "OMVSKERN", "START1", "GUEST",
              "ADMIN", "SYS1", "PROD", "TEST", "USER01", "STC"],
    "passwords": ["PASSWORD", "PASS", "SYS1", "IBMUSER", "CICS", "TEST",
                  "TEMP", "LETMEIN", "MASTER", "ADMIN", "PROD", "CHANGEME",
                  "FIRSTPW", "NEWPASS", "SECRET"],
    "cics": ["CEMT", "CECI", "CEDA", "CEBR", "CEDF", "CESN", "CESF", "CECS",
             "CMAC", "CWTO", "CEOT", "CEST", "CDBC", "CETR"],
    "applids": ["TSO", "TSO001", "CICS", "CICSPROD", "CICSTEST", "DB2", "DB2A",
                "IMS", "IMSPROD", "NETVIEW", "TPX", "ZVM", "TPF"],
}


def _load(path: str) -> List[str]:
    try:
        with open(path, encoding="utf-8") as f:
            return [ln.rstrip("\n") for ln in f if ln.strip()]
    except Exception:
        return []


def _save(path: str, lines: List[str]) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))


def edit_wordlist(path: str, kind: str = "users",
                  inp: Callable[[str], str] = input,
                  out: Callable[[str], None] = print) -> Optional[str]:
    """Interactively edit ``path``.  Returns the saved path, or None if cancelled.

    ``inp``/``out`` are injectable so the editor is scriptable/testable.
    """
    lines = _load(path)
    out(f"\n  notepad — editing {path}" + ("" if lines else "  (new file)"))
    out("  type a line to add it; commands: :list  :del N  :seed [users|passwords|"
        "cics|applids]  :clear  :save  :quit")
    if not lines and kind in SEEDS:
        out(f"  (tip: ':seed {kind}' fills a starter {kind} list)")
    while True:
        try:
            raw = inp(f"  [{len(lines)} entries] > ")
        except (EOFError, KeyboardInterrupt):
            raw = ":quit"
        s = raw.strip()
        low = s.lower()
        if low in (":q", ":quit", ":cancel"):
            out("  (cancelled — no changes saved)")
            return None
        if low in (":w", ":save"):
            _save(path, lines)
            out(f"  saved {len(lines)} entries to {path}")
            return path
        if low in (":list", ":l"):
            if not lines:
                out("  (empty)")
            for i, v in enumerate(lines, 1):
                out(f"    {i:>3}  {v}")
            continue
        if low == ":clear":
            lines = []
            out("  cleared")
            continue
        if low.startswith(":del"):
            parts = s.split()
            if len(parts) == 2 and parts[1].isdigit():
                n = int(parts[1])
                if 1 <= n <= len(lines):
                    removed = lines.pop(n - 1)
                    out(f"  removed '{removed}'")
                else:
                    out("  no such line")
            else:
                out("  usage: :del N")
            continue
        if low.startswith(":seed"):
            parts = s.split()
            key = parts[1].lower() if len(parts) > 1 else kind
            seed = SEEDS.get(key)
            if not seed:
                out(f"  no seed '{key}' (have: {', '.join(SEEDS)})")
                continue
            added = [x for x in seed if x not in lines]
            lines.extend(added)
            out(f"  added {len(added)} starter {key} entries")
            continue
        if not s:
            continue
        # plain line(s): allow comma/space separated bulk add
        for token in s.replace(",", " ").split():
            if token and token not in lines:
                lines.append(token)


def ensure_wordlist(path: str, kind: str = "users",
                    inp: Callable[[str], str] = input,
                    out: Callable[[str], None] = print) -> Optional[str]:
    """If ``path`` exists, use it; otherwise offer to build it in the notepad."""
    if path and os.path.exists(path):
        return path
    out(f"\n  wordlist '{path}' not found.")
    ans = inp("  [E]dit/create it now, or [S]kip (use built-in defaults)? ").strip().lower()
    if ans.startswith("e"):
        return edit_wordlist(path or f"{kind}.txt", kind, inp, out)
    return None
