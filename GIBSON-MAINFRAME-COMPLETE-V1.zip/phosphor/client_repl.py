"""Interactive TN3270 / TN5250 client for the shell (a plain terminal, no GUI).

    phosphor <host> [port] --client            # TN3270
    phosphor <host> [port] --client --5250     # TN5250 / IBM i

Renders the live screen in colour with a visible light-blue cursor block, and
drives it from a small prompt:

  <text>            type <text> at the cursor and press ENTER (the common case)
  :type <text>      type without sending (multi-field screens, e.g. CESN)
  :at <row> <col>   move the cursor
  :enter :clear     send ENTER / CLEAR
  :pf3 :pf5 ...     send a PF key       :pa1 :pa2 :pa3   send a PA key
  :menu             file transfer menu (IND$FILE upload/download, FTP)
  :save <file>      save the current screen text to a file
  :refresh          redraw    :mono   toggle green-screen    :q   quit

This is a lighter tool than the PHOSPHOR desktop app: no skins, no pen-test
tooling, no packet view - just a terminal + transfers for headless / SSH use.
"""
from __future__ import annotations
import sys
from phosphor.frontend_ansi import render

_CLEAR = "\033[2J\033[H"


def _screen_text(screen) -> str:
    return "\n".join("".join(ch for ch, *_ in row).rstrip()
                     for row in [[(c.char,) for c in screen.cells[i:i + screen.cols]]
                                 for i in range(0, len(screen.cells), screen.cols)]).rstrip()


def _ind_menu(c, host: str) -> None:
    """A small text menu for IND$FILE transfers and FTP."""
    while True:
        print("\n\033[96mPHOSPHOR file-transfer menu\033[0m")
        print("  1) IND$FILE  upload   (local file  -> dataset)")
        print("  2) IND$FILE  download (dataset      -> local file)")
        print("  3) FTP       list / get / put")
        print("  4) Save current screen to a file")
        print("  5) Back to the terminal")
        try:
            sel = input("menu> ").strip()
        except (EOFError, KeyboardInterrupt):
            return
        if sel in ("5", "", ":q", "b", "back"):
            return
        try:
            if sel == "1":
                local = input("  local file to upload: ").strip()
                dsn = input("  target dataset name: ").strip()
                binary = input("  binary? [y/N]: ").strip().lower().startswith("y")
                from phosphor.protocols.indfile.dft import IndFileClient
                with open(local, "rb") as f:
                    data = f.read()
                ok = IndFileClient(c).put(dsn, data, binary=binary)
                print(f"  {'[+] uploaded' if ok else '[!] upload failed'}: {dsn} ({len(data)} bytes)")
            elif sel == "2":
                dsn = input("  dataset to download: ").strip()
                binary = input("  binary? [y/N]: ").strip().lower().startswith("y")
                local = input("  save to local file: ").strip()
                from phosphor.protocols.indfile.dft import IndFileClient
                data = IndFileClient(c).get(dsn, binary=binary)
                if not binary:
                    try:
                        data = data.decode("cp037").replace("\x15", "\n").encode("utf-8")
                    except Exception:
                        pass
                with open(local, "wb") as f:
                    f.write(data)
                print(f"  [+] downloaded {dsn} -> {local} ({len(data)} bytes)")
            elif sel == "3":
                _ftp_menu(host)
            elif sel == "4":
                path = input("  save screen to: ").strip()
                with open(path, "w") as f:
                    f.write(_screen_text(c.screen) + "\n")
                print(f"  [+] screen saved to {path}")
        except Exception as e:
            print(f"  [!] {type(e).__name__}: {e}")


def _ftp_menu(default_host: str) -> None:
    from phosphor.protocols.ftp.client import MainframeFTP
    host = input(f"  FTP host [{default_host}]: ").strip() or default_host
    port = input("  port [21]: ").strip() or "21"
    user = input("  user [anonymous]: ").strip() or "anonymous"
    pw = input("  password: ").strip() or "anonymous@"
    mode = input("  mode ascii/binary [ascii]: ").strip().lower() or "ascii"
    f = MainframeFTP(mode=mode)
    try:
        print("  " + f.connect(host, int(port)))
        print("  " + f.login(user, pw))
        while True:
            cmd = input("  ftp> ").strip()
            if cmd in ("quit", "q", "bye", ""):
                break
            parts = cmd.split(None, 1)
            op = parts[0].lower()
            arg = parts[1] if len(parts) > 1 else ""
            if op in ("ls", "list", "dir"):
                for line in f.list(arg):
                    print("    " + line)
            elif op == "get":
                dsn, _, local = arg.partition(" ")
                data = f.get(dsn)
                local = local.strip() or dsn.replace(".", "_")
                with open(local, "wb") as fh:
                    fh.write(data)
                print(f"    [+] got {dsn} -> {local} ({len(data)} bytes)")
            elif op == "put":
                local, _, dsn = arg.partition(" ")
                with open(local.strip(), "rb") as fh:
                    data = fh.read()
                print("    " + f.put(dsn.strip() or local.strip(), data))
            else:
                print("    commands: ls [path] | get <dsn> [local] | put <local> <dsn> | quit")
    except Exception as e:
        print(f"  [!] FTP {type(e).__name__}: {e}")
    finally:
        try:
            f.quit()
        except Exception:
            pass


def interactive(host: str, port: int = 23, protocol: str = "3270") -> int:
    if protocol == "5250":
        from phosphor.protocols.tn5250.client import TN5250Client as Client
    else:
        from phosphor.protocols.tn3270.client import TN3270Client as Client
    c = Client()
    try:
        c.connect(host, port)
    except Exception as e:
        print(f"[!] connect failed: {e}", file=sys.stderr)
        return 1
    mono = False
    kind = "TN5250" if protocol == "5250" else "TN3270"
    print(f"[+] {kind} connected to {host}:{port}   (:menu for transfers, :help for keys, :q to quit)")
    try:
        while True:
            r, col = c.get_pos()
            sys.stdout.write(_CLEAR + render(c.screen, phosphor=mono, cursor=(r, col)) + "\n")
            try:
                line = input(f"phosphor[{r},{col}]> ")
            except (EOFError, KeyboardInterrupt):
                break
            s = line.strip()
            low = s.lower()
            if low in (":q", ":quit"):
                break
            elif low in (":help", "?"):
                print(__doc__); input("[enter]"); continue
            elif low in (":menu", ":m"):
                _ind_menu(c, host); continue
            elif low.startswith(":save "):
                try:
                    with open(s[6:].strip(), "w") as f:
                        f.write(_screen_text(c.screen) + "\n")
                    print(f"[+] saved to {s[6:].strip()}"); input("[enter]")
                except Exception as e:
                    print(f"[!] {e}"); input("[enter]")
                continue
            elif low in (":enter", ":e", ""):
                c.send_enter()
            elif low == ":clear":
                c.send_clear()
            elif low == ":refresh":
                continue
            elif low == ":mono":
                mono = not mono; continue
            elif low.startswith(":pf"):
                c.send_pf(int(s[3:]))
            elif low.startswith(":pa"):
                c.send_pa(int(s[3:]))
            elif low.startswith(":at "):
                _, rr, cc = s.split(); c.move_to(int(rr), int(cc))
            elif low.startswith(":type "):
                c.send_string(s[6:])
            else:
                c.send_string(s); c.send_enter()
    finally:
        c.terminate()
    print("\n[+] disconnected")
    return 0
