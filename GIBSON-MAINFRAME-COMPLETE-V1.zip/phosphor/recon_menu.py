"""Interactive recon menu.

Every mainframe-specific scan is an entry the user configures through a plain
form (target, port, and only that scan's options, pre-filled with sane defaults)
and runs either with PHOSPHOR's native engine (default, no nmap needed) or by
emitting the exact ``nmap --script ...`` command.  Missing wordlists are built on
the spot in the notepad.  Findings can be collected into an HTML/Markdown report.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from phosphor.audit import enumerate as au
from phosphor.notepad import ensure_wordlist


@dataclass
class Opt:
    key: str
    label: str
    default: str = ""
    kind: str = "text"          # text | wordlist
    seed: str = "users"         # notepad seed kind for wordlist options


@dataclass
class Script:
    id: str
    name: str
    desc: str
    port: int
    opts: List[Opt]
    native: Callable            # (host, port, values) -> List[Finding]
    nmap: Callable              # (host, port, values) -> str


def _wordlist(values: Dict[str, str], key: str) -> Optional[List[str]]:
    path = values.get(key)
    if path and os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return [ln.strip() for ln in f if ln.strip()]
        except Exception:
            return None
    return None


# ------- native adapters (map the form values onto the audit functions) ----
def _n_tn3270(h, p, v):     return [au.tn3270_screen(h, p)]
def _n_vtam(h, p, v):       return au.vtam_applids(h, p, (v.get("applids") or "").split(",") if v.get("applids") else None)
def _n_tso(h, p, v):        return au.tso_users(h, p, _wordlist(v, "userdb"), v.get("applid", "TSO"))
def _n_cicsenum(h, p, v):   return au.cics_transactions(h, p, v.get("applid", "CICS"), _wordlist(v, "idlist"))
def _n_cicsuser(h, p, v):   return au.cics_users(h, p, v.get("applid", "CICS"), _wordlist(v, "userdb"))
def _n_cicsinfo(h, p, v):   return au.cics_region_info(h, p, v.get("applid", "CICS"))
def _n_ftp(h, p, v):        r = au.ftp_anon(h, p); return [r] if r else []
def _n_db2(h, p, v):        r = au.db2_das_info(h, p); return [r] if r else []


# ------- nmap command templates (from the book) ----------------------------
def _args(pairs: List[str]) -> str:
    return "--script-args " + ",".join(pairs) if pairs else ""

def _m_tn3270(h, p, v):   return f"nmap -p {p} --script tn3270-screen {h}"
def _m_vtam(h, p, v):
    a = [f'vtam-enum.applids={{{v["applids"]}}}'] if v.get("applids") else []
    return f"nmap -p {p} --script vtam-enum {_args(a)} {h}".replace("  ", " ")
def _m_tso(h, p, v):
    a = [f'userdb={v.get("userdb","users.txt")}', f'tso-enum.commands="logon applid({v.get("applid","TSO")})"']
    return f"nmap -p {p} --script tso-enum {_args(a)} {h}"
def _m_cicsenum(h, p, v):
    a = [f'cics-enum.commands="logon applid({v.get("applid","CICS")})"']
    return f"nmap -p {p} --script cics-enum {_args(a)} {h}"
def _m_cicsuser(h, p, v):
    a = [f'userdb={v.get("userdb","users.txt")}', f'cics-user-enum.commands="exit;logon applid({v.get("applid","CICS")})"']
    return f"nmap -p {p} --script cics-user-enum {_args(a)} {h}"
def _m_cicsinfo(h, p, v):
    a = [f'cics-info.commands="logon applid({v.get("applid","CICS")})"']
    return f"nmap -p {p} --script cics-info {_args(a)} {h}"
def _m_ftp(h, p, v):      return f"nmap -p {p} --script ftp-anon {h}"
def _m_db2(h, p, v):      return f"nmap -p {p} --script db2-das-info {h}"


REGISTRY: List[Script] = [
    Script("tn3270-screen", "TN3270 screen capture", "Grab the logon screen/banner",
           23, [], _n_tn3270, _m_tn3270),
    Script("vtam-enum", "VTAM applid enumeration", "Find reachable VTAM applications",
           23, [Opt("applids", "applids to try (comma list, blank=defaults)", "")],
           _n_vtam, _m_vtam),
    Script("tso-enum", "TSO user enumeration", "Find valid TSO userids",
           23, [Opt("userdb", "userid wordlist file", "users.txt", "wordlist", "users"),
                Opt("applid", "TSO applid", "TSO")], _n_tso, _m_tso),
    Script("cics-enum", "CICS transaction enumeration", "Find reachable CICS transactions",
           23, [Opt("applid", "CICS applid", "CICS"),
                Opt("idlist", "transaction id list (optional)", "", "wordlist", "cics")],
           _n_cicsenum, _m_cicsenum),
    Script("cics-user-enum", "CICS user enumeration", "Enumerate users via CICS sign-on",
           23, [Opt("userdb", "userid wordlist file", "users.txt", "wordlist", "users"),
                Opt("applid", "CICS applid", "CICS")], _n_cicsuser, _m_cicsuser),
    Script("cics-info", "CICS region info / posture", "Region identity + unauth CECI check",
           23, [Opt("applid", "CICS applid", "CICS")], _n_cicsinfo, _m_cicsinfo),
    Script("ftp-anon", "Anonymous FTP check", "Test anonymous FTP login",
           21, [], _n_ftp, _m_ftp),
    Script("db2-das-info", "DB2 DRDA info", "Identify the DB2 server via DRDA",
           50000, [], _n_db2, _m_db2),
]


class ReconMenu:
    def __init__(self, host: str = "", inp: Callable[[str], str] = input,
                 out: Callable[[str], None] = print):
        self.host = host
        self.inp = inp
        self.out = out
        self.findings: List = []

    # -- small input helpers ---------------------------------------------
    def _ask(self, prompt: str, default: str = "") -> str:
        d = f" [{default}]" if default else ""
        v = self.inp(f"  {prompt}{d}: ").strip()
        return v or default

    def _configure(self, s: Script) -> Optional[Dict[str, str]]:
        self.out(f"\n== {s.name} — {s.desc} ==")
        host = self._ask("target host", self.host)
        if not host:
            self.out("  (no target)"); return None
        self.host = host
        port = self._ask("port", str(s.port))
        values: Dict[str, str] = {"_host": host, "_port": port}
        for o in s.opts:
            val = self._ask(o.label, o.default)
            if o.kind == "wordlist" and val:
                got = ensure_wordlist(val, o.seed, self.inp, self.out)
                val = got or val
            values[o.key] = val
        return values

    def _run(self, s: Script, values: Dict[str, str]) -> None:
        host, port = values["_host"], int(values["_port"])
        mode = self._ask("run with [N]ative engine or [nmap] command", "N").lower()
        if mode.startswith("nmap") or mode == "m":
            cmd = s.nmap(host, port, values)
            self.out(f"\n  nmap command:\n    {cmd}\n")
            if shutil.which("nmap"):
                if self._ask("run it now? [y/N]", "N").lower().startswith("y"):
                    try:
                        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120)
                        self.out(r.stdout + (r.stderr or ""))
                    except Exception as e:
                        self.out(f"  nmap failed: {e}")
            else:
                self.out("  (nmap not installed — command shown above to run elsewhere)")
            return
        # native
        self.out("\n  running native scan...")
        try:
            found = [f for f in s.native(host, port, values) if f]
        except Exception as e:
            self.out(f"  scan error: {e}"); return
        if not found:
            self.out("  no findings.")
            return
        for f in found:
            self.out(f"  [{f.severity.upper():6}] {f.title}")
            self.out(f"           {f.detail[:100]}")
        if self._ask("add these to the report? [Y/n]", "Y").lower().startswith("y"):
            self.findings += found
            self.out(f"  ({len(self.findings)} findings collected)")

    def loop(self) -> None:
        while True:
            self.out("\n=== PHOSPHOR recon menu ===  target: " + (self.host or "(unset)"))
            for i, s in enumerate(REGISTRY, 1):
                self.out(f"  {i:>2}. {s.name:<28} {s.desc}")
            self.out("   r. write report from collected findings"
                     f" ({len(self.findings)})   q. quit")
            choice = self.inp("  select > ").strip().lower()
            if choice in ("q", "quit", ""):
                break
            if choice == "r":
                self._write_report(); continue
            if choice.isdigit() and 1 <= int(choice) <= len(REGISTRY):
                s = REGISTRY[int(choice) - 1]
                values = self._configure(s)
                if values:
                    self._run(s, values)
            else:
                self.out("  ?")

    def _write_report(self) -> None:
        if not self.findings:
            self.out("  no findings collected yet."); return
        path = self._ask("report path", "phosphor_report.html")
        from phosphor.report import write_report
        write_report(self.findings, path, self.host or "target")
        self.out(f"  report written to {path}")


def run_menu(host: str = "") -> int:
    ReconMenu(host).loop()
    return 0
