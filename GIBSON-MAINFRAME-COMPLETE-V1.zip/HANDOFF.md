# PHOSPHOR — Session Handoff (continue here)

## What PHOSPHOR is
Python TN3270/TN5250 mainframe audit terminal for Kev Milne (mainframe security author,
OffensiveSec.org). Two clients over a shared engine:
- **GUI**: pygame/PIL desktop app (`phosphor/app/__main__.py` + `phosphor/app/ui.py`)
- **TUI**: full-screen curses client, c3270-style (`phosphor/client_tui.py` + `phosphor/client_panels.py`)
Plus recon/audit tools, IND$FILE transfer, EZrecon OSINT, skins, pcap capture.

## Working tree & deliverable
- Source: `/home/claude/phosphor`
- Ship: `/mnt/user-data/outputs/PHOSPHOR-FINAL.zip`
- Repackage each turn: clean caches then
  `zip -r -q -X /mnt/user-data/outputs/PHOSPHOR-FINAL.zip . -x '*.DS_Store' -x '*__pycache__*' -x '*.pyc'`
  then `present_files`.
- Doc log appended each turn: `Whats-New-and-Components.md`
- Test runner: `for t in tests/test_*.py; do python3 "$t"; done` — all suites green
  across 26 files (+test_tn3270_tso_ready.py this turn: zPDT TSO READY cursor/typing,
  built from the tn3270.pcap record-23 bytes).
  (test_license.py exits rc=1 only because pytest absent — ignore.)
- `tnz` + `ebcdic` are pip-installed in this sandbox (`pip install --break-system-packages tnz ebcdic`).

## Style / working rules
Terse, autonomous, no hand-holding. NSP book voice in prose (no em dashes, no AI-sounding
phrasing). GIBSON and the *Hacking Mainframes* book are SEPARATE projects — out of scope unless
named. Always run the full suite + repackage + present_files at the end of a turn.
When protocol issues arise the ONLY reliable fix is analysing a real pcap (see parser below).

## Architecture quick map
- `phosphor/protocols/tn3270/{telnet.py,client.py,datastream.py,fields.py}` — native 3270
- `phosphor/protocols/tn5250/{client.py,datastream.py}` — native 5250
- `phosphor/protocols/indfile/dft.py` — IND$FILE
- `phosphor/session/__init__.py` — engine factory: `available_engines()`, `make_connection(protocol,engine)`, `make_editor(conn)`
- `phosphor/session/tnz_backend.py` — IBM tnz backend (`TnzSession`, `TnzEditor`, `screen_from_tnz`)
- `phosphor/core/screen.py` — `ScreenBuffer`, `Cell`, `Field` (`.rc(addr)`→(row,col) 1-based; `.cursor` linear addr; `is_field_start`, `protected`, `input_fields()`)
- `phosphor/audit/ezrecon.py` — EZrecon core
- `phosphor/app/themes.py` — skins (incl. `vertali`)
- CLI: `phosphor/cli.py` (`--client` TUI, `--gui`, `--5250`, `--engine native|tnz`, `--scan`, `--menu`)

## Engines
- **native** (default, zero-dep clean-room) and **tnz** (IBM tnz, 3270 only; robust vs real z/OS).
- GUI Settings has a "TN3270 engine: Native / IBM tnz" toggle; CLI `--engine tnz`.
- 3270/5250 toggle is the button above Connect (`b_protocol`).
- tnz path: `TnzEditor` routes every keystroke/AID straight to tnz (tnz owns fields/echo). Native
  path: `FieldEditor` funnels input via `conn.move_to`+`send_string`+`send_{aid}`.

## RESOLVED this arc (all in the shipped zip, tested)
1. **Green/Amber GUI toggle** — renderer ignored mode when a skin set a palette. Fixed: both
   `render_grid_image` call sites in ui.py use `palette=(SCREEN_PALETTE if state.colour=="colour" else None)`.
2. **PCAP save location + Copy all** — `toggle_capture` shows full path; `_open_packet_log` shows
   tools dir; `_copy_or_save(text,kind)` falls back to saving a .txt when no clipboard tool and echoes
   feedback INTO the console (was hidden behind popup). Kali needs xclip/xsel/wl-copy for real copy.
3. **Vertali skin** — light/white chassis `#f4f4f4`, lime `#8ACD00`, dark-teal `#00785F`. Wordmark
   text override via `Theme.wordmark` (+ global `WORDMARK`, set in `apply_theme`). Logo drawn from the
   real SVG path (`_vertali_logo` in ui.py) with the "V" INSIDE the hexagon; **no underline**. SVG at
   `/mnt/user-data/uploads/vertali_logo.svg` (path M405,154 L274,82 L127,154 L127,323 L274,407 L403,339).
4. **tnz typing** — added `TnzEditor` (routes to tnz), `make_editor(conn)` picks it for tnz sessions.
5. **IC cursor** — `FieldEditor.sync_cursor` now honours the host Insert-Cursor position, INCLUDING on
   UNFORMATTED screens (TSO READY, no fields). This is the "cursor at top-left" fix.
6. **Multi-record / extra-Enter** — `telnet.feed()` now returns `(reply, segments, eor)` split at EOR
   boundaries; client applies EVERY complete record in order (`_consume`/`_apply_record`), reassembles
   records split across TCP segments.
7. **Lag / GIBSON hang** — the multi-record fix waited a full 1.5s socket timeout after each Enter.
   Fixed: `_read_until_eor` returns as soon as a SCREEN record arrives + a short `_drain_fast` (~80ms).
   `_apply_record` returns False for a WSF Query reply (keep reading for the real screen). Measured
   1500ms→~85ms. Applies to both clients (shared read path).
8. **EZrecon interface** — GUI was reusing the shell console (typing "subs" ran `/bin/sh: subs`).
   Now a dedicated console: `console_mode=="ezrecon"` → `run_console_cmd` routes to `_run_ezrecon`
   which dispatches `ez.run(op,target)` ("dns example.com", "subs vertali.com", "shodan_host 8.8.8.8").
   Keys prompted on first use, stored `~/.config/phosphor/ezrecon_keys.json`. Backend tools reported
   (subfinder/nmap/whois/shodan etc.).
9. **TN5250 SF parsing rebuilt** — a 5250 SF is output-only (attr byte only) OR input (FFW 2b +
   optional FCW pairs + attr + 2b length). `_is_attr(b)=(b&0xE0)==0x20`; `_colour_from_attr`; protection
   = `not has_ffw or (ffw & 0x2000)`. Fixed label-eating + undetectable input fields. Re-added the
   3270/5250 toggle + `--5250` + connect branch. (Approach informed by public web3270/lib5250, clean-room.)

## RESOLVED next arc (field-model fixes; in the shipped zip, tested)
- **A (labels + explicit length).** Input-field explicit lengths already honoured
  (verified against the decoded pub400 sign-on). Fixed: the 5250 field table now
  holds BOTH protected labels and input fields (output lengths computed post-parse
  as distance-to-next-field-start), so labels are protected and Tab moves to the
  next field. Fixed two dead-code 5250 tests (defined after `__main__`) + rebuilt
  the malformed roundtrip stream. New `tests/test_tn5250_pub400.py`.
  STILL OPEN (needs live host / raw pcap): the exact inbound wire format from
  `build_inbound` vs the real seg7 bytes `05 21 f1 11 05 <ebcdic>` - left as-is
  because it round-trips through the parser and reversing 9 bytes without the spec
  risks breaking the working path.
- **B (IND$FILE empty downloads).** `recv_record` merged every record in one read
  into a blob so DATA frames after the first were dropped. Now returns one record
  per call, queues extras, carries split records; driver only processes 0xD0 SFs.
  New `tests/test_indfile_live.py` (scripted fake socket).
- **C (TSO typing) — partially.** Unformatted READY / line-mode now typable: the
  FieldEditor synthesises an unprotected field from IC to end-of-buffer when the
  screen has no field attributes, with linear addressing in type_char/backspace.
  If the real zPDT screen is instead FORMATTED with a short field, replay
  `capture-192_168_0_248-*.pcap` (not re-uploaded this arc) to confirm.

## OPEN / IN-PROGRESS (do these next)

### A. TN5250 still failing on pub400 (tab/enter sends cursor to start of same text)
Real capture: `/mnt/user-data/uploads/tn5250.pcap` (HAS traffic). I decoded the sign-on stream.
**Ground truth (pub400 QINTER, IBM-3179-2):**
- TN5250E GDS-wrapped. Record = `[lenHi lenLo][12 a0][flow 0000][04 00 00 03][04(ESC) 40(CMD)...]`.
  Header before ESC is 10 bytes after the length; opcode 03 = PUT/GET. `gds_unwrap` must handle this.
- Negotiation seen: WONT NEW-ENVIRON(0x27), WILL TTYPE (IBM-3179-2), DO/WILL EOR(19)+BINARY(00).
- The screen: `ESC 40`(=CMD_CLEAR_UNIT?) then `ESC 11`(WTD) `00 18`(ctrl) then orders. Decoded orders:
  `SOH len=7`, then SBA/attr/text runs, then the two INPUT fields:
  - **username**: `SBA r5 c24` then `SF IN ffw=4020 attr=24 len=10` then literal `coachkev..`
  - **password**: `SBA r6 c24` then `SF IN ffw=4000 attr=27 len=128`
  - `IC` positions cursor; RA fills.
- KEY POINT observed: the field is written at `SBA r5 c24` and the SF attr occupies c24, so the field
  BODY starts at c25, length 10. The "tab/enter sends cursor to start of same text" symptom means the
  native field model is putting the whole line into one field OR the input field length (10 / 128) is
  not being used so the field runs to the next field-start. **The 5250 parser must use the explicit SF
  length to bound the field**, and the FieldEditor tab must move to the NEXT input field, not wrap
  within the same one. Also note pub400 rewrites the same SBA positions (r6 c24 appears twice — once as
  the SF, once as `attr 27` + RA) — the parser must not double-count.
- ACTION: replay `tn5250.pcap` seg[8] (925B) through `TN5250Client` + `FieldEditor`, assert exactly 2
  input fields at (5,25 len10) and (6,25 len128), IC lands on username, Tab→password, Enter builds
  inbound `[cursorRow cursorCol AID]` + per-modified-field `[SBA row col]+ebcdic`, GDS-wrapped
  (opcode PUT/GET) with IAC EOR. The inbound the real client sent is seg[7]/[9]:
  seg7 `0018 12a0 0000 0400 0003 05 21 f1 1105 1983968183889285a5 ffef` — that's GDS + `05 21`(?) then
  AID `f1`=ENTER, `11 05`=SBA? then `1983968183889285a5`=EBCDIC "coachkev". Use this to match the exact
  inbound format. **The 5250 field length from SF is the missing piece.** ScreenBuffer.fields() computes
  length as distance-to-next-field (3270 style) — for 5250 you must store the explicit SF length on the
  Field and have fields() honour it. Add a `length` carried from the SF order.

### B. IND$FILE download produces empty files
`phosphor/protocols/indfile/dft.py` (`IndFileClient.get`/`put`) + `client.py recv_record`/`send_record`.
`recv_record` was updated this arc for the segments API:
`buf += segs[0]; if len(segs)>1: return bytes(buf + b"".join(segs[1:-1]))`.
Likely the structured-field (WSF) exchange for download isn't reading the data records, or the DFT
`get()` writes before data arrives. Investigate the get() flow + how the WSF data records are framed
(they're 3270 records via recv_record). Verify against a capture if possible.

### C. zPDT TSO: can't type past 6 characters (can't enter commands)
Screenshot showed "addus" + blocked cursor. This is native 3270. `type_char` in
`phosphor/protocols/tn3270/fields.py` bounds typing by the field length. On the TSO command line the
input field length is being computed too short (6). Likely the unformatted/formatted detection or the
field-length (distance to next field-start / IC) is wrong for the TSO entry field. Check `type_char`,
`_field_at`, and how the TSO command field length is derived. May be related to the same
"field length" gap as the 5250 issue. Reproduce with a captured zPDT TSO command screen.

## Tooling: manual pcap parser (no scapy/dpkt in sandbox)
Reuse `/tmp/pcapparse.py` (parses classic pcap, linktype 1 Ethernet, strips to TCP payload). PHOSPHOR's
own pcap writer tags direction unreliably, so CLASSIFY BY CONTENT: 5250 outbound starts with GDS
`..12a0..` or `04`(ESC); inbound has the GDS `..12a0..` then AID. 3270 inbound starts with an AID byte
(7d=ENTER, f1-f3=PF, 6c/6d/6e/6b=PA, etc.), outbound with a command+WCC. Decode EBCDIC with cp037.
Uploaded pcaps this project: `tn5250.pcap` (pub400, HAS traffic — use for A), earlier
`capture-192_168_0_248-*.pcap` (zPDT TSO logon), `3270dump.pcap` (tcpdump -A TEXT format).

## Latest user asks (this turn) = A, B, C above, in priority order:
1. Fix TN5250 pub400 tab/enter (use the decoded ground truth above — the SF explicit length is the key).
2. Fix IND$FILE download empty files.
3. Fix zPDT TSO 6-character typing limit.

Ongoing caveat to relay: protocol fixes are validated against constructed streams + real pcaps but not
always live end-to-end from the sandbox (no live host). Offer to confirm the last mile against fresh
captures WITH traffic.

---

## UPDATE 2026-07-13 (this turn): zPDT typing/cursor RESOLVED; 5250 double-ENTER pending a capture

### C (zPDT 6-character limit + cursor stuck top-left) — RESOLVED, evidenced by `tn3270.pcap`
Root cause was NOT field length nor unformatted detection nor the attribute decode. The
READY screen is FORMATTED. Record 23 of the capture:
`EW SBA(23,79) SF(0x40) SBA(0,0) SF(0xc8) SBA(0,1) 'READY ' SF(0x40) IC SBA(1,0) IC`.
The command area is ONE unprotected field from (0,8) to end of screen (length 1911, spans
rows 1-24). `_field_at` matched formatted fields with `f.row == row`, so a multi-row field
was only found on its first row; the cursor could not be recognised inside it, `sync_cursor`
could not honour the IC, and it fell back to the first field = the 6-wide `READY ` label at
top-left. Hence "stuck top-left" and 6-char clip (`LISTCAT` -> `LSITCT` at (0,1)). Logon
worked by luck because its first field is the 24-wide userid label.
Fix in `phosphor/protocols/tn3270/fields.py`: `_field_at` now matches by LINEAR buffer span
(wrap-aware) so multi-row fields resolve on any row; `sync_cursor` honours the IC into them;
no-IC fallback is the deterministic top-left-most input field. Attribute decode unchanged
(0xc8 line-mode fields are genuinely unprotected in this ADCD datastream; 0xe8 stays
protected). New `tests/test_tn3270_tso_ready.py` (17 assertions, built from the record-23
bytes). Suite green across 26 files.

### 5250 double-ENTER (requires 2x ENTER) — OPEN, needs a TN5250 capture
The uploaded pcap is 3270 only, no 5250 evidence. Ruled out client-side swallow:
`keyboard_locked` does not gate the send in `tn5250/client.py`, and `_aid` builds+sends on
the first call. This is a host read handshake question. Did NOT change the 5250 wire on a
guess (Kev reports 5250 "almost perfect"; risk of regressing the pub400 path). To pin it:
capture ONE misbehaving ENTER as `tn5250.pcap`. Then check, in order: (1) is the first AID
record actually transmitted; (2) GDS opcode/flags on it (`_aid` sends opcode 0x03 PUTGET,
ATN only for PA/ATTN) vs what the host's read expects; (3) does the host re-invite / send a
read record that the parser drops at `datastream.parse` line 141-144 (`if cmd != CMD_WTD:
continue`). Candidate fix area if confirmed: answer the pending host read, or correct the
GDS response opcode/flags. Reproduce against the capture before touching the wire.

## Reusable pcap tooling built this turn (in /tmp, regenerate if gone)
`/tmp/pcapparse.py` (classic pcap -> TCP flows), `/tmp/splitrec.py` (telnet IAC-EOR record
split, strips negotiation), `/tmp/hostdecode.py` (3270 order decoder: SBA/SF/SFE/IC/RA/EUA
with addresses + cp037 text), `/tmp/o3270.py` (inbound AID+cursor+SBA decoder), `/tmp/repro.py`
+ `/tmp/repro2.py` (reproduce the READY typing bug from constructed record-23 bytes).
3270 ASCII-coded commands: W=0x01 EW=0x05 EWA=0x0d WSF=0x11. Inbound AID ENTER=0x7d.

---

## UPDATE 2026-07-14: TN5250 double-ENTER RESOLVED (from tn5250.pcap); STRIP3270 rename

### TN5250 double-ENTER — RESOLVED, evidenced by `tn5250.pcap`
Client-side capture (pub400) proved the OUTBOUND side is byte-correct: well-formed GDS
frames (`00 LL 12 a0 00 00 04 00 00 03`, opcode 0x03), cursor+AID+SBA fields; the sign-on
uses the same format and works in one press. Enter records doubled; PF3 (0x33) never did.
Root cause was READ-side: IBM i answers a field-reading Enter with two records (message +
screen); the old loop applied only the first, so the panel did not change and the operator
pressed Enter again. Fix ported the 3270 client's robust read path to
`phosphor/protocols/tn5250/client.py`: `_apply_record` (one GDS record at a time),
`_consume` (per-record apply + partial carry), `_drain_fast` (0.08s straggler poll),
rewritten `_read_until_eor`. Back-compat `_apply_screen` kept (delegates to `_apply_record`).
Outbound untouched. New `tests/test_tn5250_double_enter.py`. Suite green across 27 files.
NOTE: not yet confirmed live end-to-end from the sandbox (no live IBM i host); validated
against a scripted two-record host that reproduces the exact message-then-screen timing.

### STRIP3270 rename
hack3270 button + popup title + settings/help headings + tooltip + inject console lines now
read STRIP3270. LEFT as hack3270 on purpose (real external tool / internal): install hint,
"hack3270 binary" status text, MITM proxy launch text, `PHOSPHOR_HACK3270_CMD` env var,
tool_status key "hack3270", button id `a_hack3270`, `h3_*`/`hack3270_open` state fields,
`hack3270_proxy` module, `Hack3270Proxy` class. test_toolchain / test_injections still green.

---

## UPDATE 2026-07-14 (b): zPDT READY cursor-jump-on-typing RESOLVED
Reported: at READY the cursor jumps from below "READY " up to the line above when typing.
(The uploaded tn3270-session.pcap was empty - 24-byte header, 0 packets - but the fault
reproduces from the record-23 READY bytes.) Cause: host sets the cursor on the line BELOW
"READY " via its final IC; the command field spans from the top line down, so the lower line
is inside it. `type_char`'s snap-to-field-start dragged the first keystroke up to the field
start on the "READY " line. Fix in `phosphor/protocols/tn3270/fields.py`: FieldEditor now
tracks `_cursor_host_set` (True when sync_cursor honours the IC; cleared on move/click/tab/
field_up/field_down and after a keystroke). `type_char` skips the snap when the cursor is
host-placed, so it types where the host put it. Snap still fires for operator moves into a
blank field (left-justify for userid/password). `grid_with_edits` overlay now walks by true
buffer address so an edit that crosses the row edge renders on the correct line (was clipped
at col 80). test_tn3270_tso_ready.py updated (+cursor-below-READY, +manual-move-left-justify,
userid case now asserts host-cursor behaviour). 27 test files green.

---

## UPDATE 2026-07-14 (c): CRT app icon wired for runtime + PyInstaller
Master: assets_src/phosphor_icon_master.png. Generator: packaging/make_icons.py (rounded
mask radius 259/1254 of side -> transparent corners). Regenerates: packaging/icons/
{phosphor.png 1024, phosphor-256.png, phosphor.ico multi-size 16-256, phosphor.icns,
phosphor.iconset/* 12 std files} and phosphor/app/assets/phosphor_icon.png (256 runtime).
packaging/build.py now runs make_icons before PyInstaller. Runtime: __main__.py calls
pygame.display.set_icon(load(app/assets/phosphor_icon.png)) after set_mode (guarded).
Spec already bundled phosphor/app/assets, so runtime icon is included. Windows ICON_WIN +
iss SetupIconFile = phosphor.ico; macOS ICON_MAC + BUNDLE = phosphor.icns (iconutil also
builds from iconset); Linux install.sh installs phosphor-256.png. To change the icon later:
replace the master and run packaging/make_icons.py (or just build.py).

---

## UPDATE 2026-07-14 (e): iNJEctor -> NJE tool; live GIBSON DB2 WebSocket client
- iNJEctor button (a_injector, relabelled) now opens an NJE recon console (was field
  injection). `phosphor/toolchain/nje.py`: OPEN probe (reason 0x00 ACK/0x04/0x01 node
  enum + trust), signon_test (node password / no-password finding), enumerate_nodes,
  bundled_jcl (explicit job-submission payloads). Clean-room (NOT the GPL bitstring
  njelib). Cross-validated vs GIBSON gibson/net/nje_protocol.py. tests/test_nje.py (13).
  Console: probe/enum/signon/tls. Ports 175 clear / 2252 TLS.
- SQL button: `phosphor/protocols/db2ws.py` dependency-free RFC6455 WS client for
  GIBSON DB2 (50001, LOGIN then SQL - the db2-connect.py protocol). Console: `gibson
  [host] [port]` then LOGIN + SQL. tests/test_db2ws.py (7) vs real websockets server.
- Real z/OS DB2 DRDA: still ibm_db/db2 CLP path. GIBSON gibson/net/drda.py has the DDM
  code points (EXCSAT 0x1041, ACCSEC 0x106D, SECCHK 0x106E, ACCRDB 0x2001,
  SECMEC_USRIDPWD 0x0003) for a future native client. drda_setup_notes() documents setup.
- 30 test files green. Reference sources studied: /tmp/injector_x (bigendiansmalls
  iNJEctor+njelib), /tmp/gibson_x (GIBSON), db2-connect.py.

---

## UPDATE 2026-07-14 (f): PassTicket generation; STRIP3270 confirmed intact
- passticket.py gains generate_passticket(user, applid, key_hex, when) + passticket_window().
  Faithful RACF SKALGO/ALGOR port (bigendiansmalls gen_passticket), DES via racf_des._des_encrypt
  (cryptography fallback, no pycryptodome needed). VALIDATED byte-for-byte vs GIBSON
  gibson/assets/passticket/gen_passticket.py -> golden vectors in tests/test_passticket_gen.py (11).
  PassTicket button now interactive console (console_mode="passticket"): scan | gen | genwin.
- STRIP3270 verified UNCHANGED: a_hack3270 -> hack3270_open (popup); h3_inject_type/save/run +
  "Inject now" intact; a_injector -> open_nje only (never hack3270_open). test_injections(15) +
  test_toolchain(16) green.
- 31 test files green. Next options: native DRDA client (GIBSON drda.py reference) or NJE job
  submission over an established trusted session.

---

## UPDATE 2026-07-14 (g): native DRDA client (DB2 for z/OS)
- phosphor/protocols/drda/client.py (NOT top-level drda.py - that dir is a package with
  probe.py). Full handshake: build_excsat/accsec/secchk/accrdb + parse_reply; probe(host,
  port, userid, password, rdbnam) -> DrdaResult (fingerprint + auth_ok + secchkcd); spray().
  DSS request fmt 0x01, reply parse tolerant. SECCHKCD map for reporting.
- Wired into SQL console: `drda <host> [port] [user] [pass] [rdb]` (console_mode sql intercept
  -> _run_drda). SQL button now: gibson (WS 50001) | drda (446 native) | ibm_db/CLP builder.
- VALIDATED vs GIBSON gibson/net/drda.py respond() (real server codec). tests/test_drda.py (11).
- SQL result sets (EXCSQLIMM/OPNQRY/FD:OCA) still driver path (ibm_db). Next if wanted: EXCSQLIMM
  for simple statements against GIBSON's DRDA listener, or NJE job submission.
- 32 test files green.

---

## UPDATE 2026-07-14 (h): iNJEctor NMR operator commands
- nje.py: make_scb (SCB compression, byte-exact port of njelib), make_ttb, calc_ttr,
  build_nmr(rhost, ohost, command, fcs, seq, target_node, own_node), send_command(),
  next_sequence(). RCB_NMR=0x9A. build_nmr VALIDATED byte-for-byte vs njelib (SCB+TTB/TTR
  framing) -> golden vectors in tests/test_nje_nmr.py (14).
- iNJEctor console: signon now remembers _nje_target; `cmd <operator command>` sends an NMR
  ($D NODE etc.) to it. Grammar: probe | enum | signon | cmd | tls.
- CAVEAT: NMR reply round-trip needs a live JES2 node (GIBSON stops at sign-on). Send bytes
  confirmed vs njelib; FCS defaults to 8fcf (real host may negotiate a different FCS at
  sign-on - capture if a live reply is empty). Full /*XEQ job submission still TODO
  (nje.bundled_jcl payloads ready).
- 33 test files green. (bitstring installed in this env only to run njelib as an oracle;
  NOT a PHOSPHOR dependency - build_nmr is pure-python.)

---

## UPDATE 2026-07-14 (i): NJE job submission + GIBSON NJE update
- nje.py: build_njh, sysin_footer, build_sysin_stream, build_job, submit_job (SINGLE
  connection now), scb_decompress. build_job/build_njh VALIDATED byte-for-byte vs njelib
  (makeSYSIN_header + sendNJE_multiple) -> tests/test_nje_job.py (9, incl run-as user +
  SCB roundtrip). NJHTOUSR/NJHTOGRP = run-as identity.
- iNJEctor console: submit <run-as-user> <id|racf_backdoor|file> (uses remembered
  _nje_target from signon). bundled_jcl() payloads.
- GIBSON was IDENTICAL to prior for NJE (confirmed via diff) - STILL stopped at signon.
  UPDATED gibson_v2: nje_protocol.py +scb_decompress/+parse_sysin_stream; nje_server.py now
  reads+parses the job after signon, logs "NJE JOB SUBMIT" run-as, routes to jes.submit,
  acks. Shipped as GIBSON-NJE-JOBSUBMIT-UPDATE.zip. SCB decompress bug fixed: use &0xE0 to
  tell 0x80 space-run from 0xA0 char-run (was &0xC0).
- END-TO-END verified PHOSPHOR submit -> updated GIBSON receive/parse/JES. 34 test files green.
- bitstring installed in sandbox ONLY as njelib oracle; NOT a PHOSPHOR dep.

---

## UPDATE 2026-07-14 (j): local shell + STARTTLS + models + DRDA SQL
- Local shell: a_shell -> open_shell() (was toggle_shell). console_mode "localshell",
  _run_localshell: cd (persists _shell_cwd), clear, listen (reverse shell preserved),
  else subprocess in cwd -> scrollback. tests/test_localshell.py (9).
- STARTTLS: telnet.py Negotiator +want_starttls/start_tls/starttls_done, OPT_START_TLS 0x2E;
  client connect(tls_starttls=True) + _do_starttls wraps mid-stream. app wires s.tls_starttls.
  tests/test_starttls.py (7).
- Models: client.py MODELS + client_for_model(model); app builds via client_for_model(
  s.term_model). state term_model. tests/test_models.py (9). REMAINING x3270: LU-name
  (TN3270E CONNECT), NVT/line mode, s3270 scripting.
- DRDA EXCSQLIMM: drda/client.py build_excsqlimm/build_sqlstt/execute_sql; console
  drda <...> [SQL]. GIBSON drda.py +extract_sqlstt/build_sqlcard/respond_sql (uses state.db2
  run_sql/shell_command). tests/test_drda.py now 14 (test dir path -> /tmp/gibson_v2).
- 37 test files green. GIBSON update now covers NJE job submit + DRDA SQL (both in the zip).

---

## UPDATE 2026-07-14 (k): GIBSON integration verified against REAL GibsonState
Checked the GIBSON update's wiring against the actual state (gibson.cli.build_state), found
+ fixed real mismatches:
- jes.submit signature is (jcl, owner, runner=, sql_runner=, submitter=) NOT (jcl, userid=).
  Fixed nje_server to submit with a real TsoCommandProcessor(state, run_as).run runner so the
  NJE job EXECUTES as run_as (verified: ADDUSER over NJE actually creates the user in RACF).
- GibsonState has NO .db2 attribute; respond_sql now constructs Db2Simulator(state) per call
  and maps its ValueError "SQLCODE=-nnn" into the SQLCARD. (verified: SELECT -> SQLCODE 0.)
- record_security_event(userid, event, details, *, ...) - pass run_as as userid.
GIBSON-UPDATE.zip repackaged with all 3 fixed files (nje_protocol.py, nje_server.py, drda.py).
PHOSPHOR side needed NO changes (fixes were all GIBSON-side). Real-state test:
  build_state -> NjeHandler/handle against real state -> ATKR created; drda.respond -> SQLCODE 0.

---

## UPDATE 2026-07-14 (l): live SQL/DB2 client + quoting/overrun fixes
- DrdaSession (drda/client.py): open()/login()/execute()/close() - persistent DRDA
  login+multi-statement. SQL console: `connect <host> [port] [user] [pass] [rdb]` ->
  console_mode "drdasql"; LOGIN then SQL lines. gibson (WS) path unchanged.
- FIXED api_sql.db2_python_command: base64-encode the python (was nested double quotes ->
  SyntaxError/truncation). tests updated to decode b64.
- FIXED overrun: _console_wrapped() wraps long lines; used in SQL client + subprocess echo.
- GIBSON drda.py respond(data, state, session=None): session tracks SECCHK userid ->
  respond_sql(userid=...) so SQLID is the logged-in user; Db2DasHandler keeps session per
  connection. VERIFIED interactive session vs real GibsonState.
- tests/test_drda.py 21 (session + quoting regression). 37 files green.

---

## UPDATE 2026-07-14 (m): native DRDA result sets (OPNQRY/QRYDSC/QRYDTA)
- drda/client.py: build_opnqry/prpsqlstt/clsqry, recv_dss_raw(), decode_qrydsc/decode_qrydta
  (FD:OCA subset: CHAR/VARCHAR/SMALLINT/INTEGER + nulls), _query(); DrdaSession.query() +
  execute() routes SELECT -> query -> format_result_table. T_VARCHAR/CHAR/SMALLINT/INTEGER.
- GIBSON drda.py: OPNQRY/PRPSQLSTT/CLSQRY routed; build_qrydsc/build_qrydta/build_opnqryrm/
  build_endqryrm/respond_query; _columns_from_rows infers types from sim rows. OBJDSS fmt 0x03.
- VERIFIED vs real GibsonState: SELECT NAME,CREATOR FROM SYSIBM.SYSTABLES -> 63 typed rows.
  tests/test_drda.py 30 (native result set + FD:OCA codec roundtrip).
- CAVEAT: real z/OS FD:OCA has more types (DECIMAL/DATE/packed/CCSID) - confirm on metal;
  ibm_db path remains for guaranteed real-host result sets. GIBSON-UPDATE.zip carries the emitter.

---

## UPDATE 2026-07-14 (n): GIBSON NJE node-password enforcement by security mode
GIBSON-side only (PHOSPHOR unchanged). nje_protocol.check_node_password(...secure=) +
nje_server brute-force lockout, gated on is_secure_mode(state):
- VULN: passwordless node accepts anything; weak node pw brute-forceable (no lockout).
- SECURE: passwordless sign-on rejected; blank pw rejected; per-source lockout after 3
  fails (_NJE_MAX_FAILS); correct pw still authenticates + resets the counter.
Verified vs real GibsonState (vuln allows attack, secure blocks passwordless + brute force,
legit auth still works). tests/test_nje_secure_signon.py (7) ships in GIBSON-UPDATE.zip.

---

## UPDATE 2026-07-14 (n2): live-host smoke-test harness
- tools/smoketest.py: drives PHOSPHOR modules vs a real host, PASS/FAIL/UNCONF/SKIP per
  feature (tn3270+model, tls/starttls, tn5250 single-enter, nje probe/signon/NMR-reply,
  drda fingerprint/cred/result-set with FD:OCA-type flagging, ptkt offline). Read-only by
  default; --nje-submit/spray need --i-have-authorization.
- tools/capture.sh (scoped tcpdump), tools/SMOKETEST.md (runbook). Validated vs GIBSON
  servers. tests/test_smoketest.py (10). 38 test files green.
- I cannot reach a live host from the sandbox; running these is the user's manual step. Any
  FAIL/UNCONF -> capture.sh pcap -> diagnose (same loop as the tn3270/tn5250 captures).

---

## UPDATE 2026-07-14 (o): batch mode
- tools/smoketest.py: --config <ini> runs every section (per-suite host/port); --all runs
  all suites vs --host on default ports. _load_config/_suite_args map sections->args
  (pass->pw, nodes->nje_nodes, spec->ptkt, etc). tools/smoke.conf.example template.
- run-tests.sh: runs all tests/test_*.py (pytest if present, else standalone), summary,
  optional name filter. test_license.py auto-skipped when no pytest.
- tests/test_smoketest.py 15 (config/batch). 38 files green.
