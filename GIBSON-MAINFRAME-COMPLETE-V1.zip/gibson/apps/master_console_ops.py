"""Realistic z/OS master-console operator commands for Gibson.

This module implements the classic MVS / VTAM / subsystem / TCP / JES2 operator
commands that a mainframer expects to work from the master console, with output
formatted to match real z/OS message formats (IEE114I, IEE457I, IEE254I,
IXC359I, ISG343I, BPXO0nnI, IST/EZZ/$HASP ...).

It also provides:
  * a *context-specific* help facility (only commands valid at the master
    console appear), reached with HELP or ? at the console prompt, and
  * a TSO-style completion facility: typing the start of a command followed by
    '?' lists the ways it can be completed (e.g. "D U,?", "$D?", "D OMVS,?").

The engine is intentionally data-driven: a single COMMAND TABLE feeds dispatch,
help and completion so the three never drift apart.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, List, Optional, Tuple


# --------------------------------------------------------------------------- #
# Command table
# --------------------------------------------------------------------------- #
@dataclass
class OpsCommand:
    """One operator command family for dispatch, help and completion."""
    category: str
    syntax: str                       # canonical syntax shown in help / completion
    desc: str                         # one-line description
    pattern: str                      # regex (anchored, case-insensitive) that recognises it
    handler: str                      # method name on MasterConsoleOps
    aliases: Tuple[str, ...] = ()     # extra syntaxes shown under ? completion
    _rx: Optional[re.Pattern] = field(default=None, repr=False)

    def rx(self) -> re.Pattern:
        if self._rx is None:
            self._rx = re.compile(self.pattern, re.I)
        return self._rx


# The prefix character for JES2 is $ on most keyboards (£ on some). Gibson
# accepts either and normalises to $ before matching.
COMMAND_TABLE: List[OpsCommand] = [
    # ---- MVS DISPLAY -------------------------------------------------------
    OpsCommand("MVS DISPLAY", "D R,L", "Display outstanding replies (WTORs) - first stop when things hang",
               r"^D(?:ISPLAY)?\s+R,\s*(?:L|LIST|LONG)$", "d_replies"),
    OpsCommand("MVS DISPLAY", "D R,R", "Display outstanding requests eligible for reply",
               r"^D(?:ISPLAY)?\s+R,\s*R$", "d_replies_r"),
    OpsCommand("MVS DISPLAY", "D A,L", "Display active jobs, started tasks and TSO users",
               r"^D(?:ISPLAY)?\s+A,\s*L(?:IST)?$", "d_active"),
    OpsCommand("MVS DISPLAY", "D A,L,USERID=xxxxxxxx", "Display active work owned by a user id",
               r"^D(?:ISPLAY)?\s+A,\s*L(?:IST)?,\s*(?:USERID|U)=\S+$", "d_active_user",
               aliases=("D A,jobname",)),
    OpsCommand("MVS DISPLAY", "D TS,L", "Display active TSO users",
               r"^D(?:ISPLAY)?\s+TS,\s*L(?:IST)?$", "d_ts"),
    OpsCommand("MVS DISPLAY", "D IPLINFO", "Display IPL time, LOADxx member and IPL parameters",
               r"^D(?:ISPLAY)?\s+IPLINFO$", "d_iplinfo"),
    OpsCommand("MVS DISPLAY", "D SSI", "Display the configured subsystems (subsystem name table)",
               r"^D(?:ISPLAY)?\s+SSI$", "d_ssi"),
    OpsCommand("MVS DISPLAY", "D SSI,SUB=name", "Display detail for one subsystem",
               r"^D(?:ISPLAY)?\s+SSI,\s*SUB=\S+$", "d_ssi_sub"),
    # ---- DEVICES -----------------------------------------------------------
    OpsCommand("DEVICES (U)", "D U,DASD,ONLINE", "Display online DASD volumes",
               r"^D(?:ISPLAY)?\s+U,\s*DASD,\s*ONLINE$", "d_u_dasd_online"),
    OpsCommand("DEVICES (U)", "D U,,,cuu,nn", "Display nn devices starting at address cuu (e.g. D U,,,A80,16)",
               r"^D(?:ISPLAY)?\s+U,\s*,?\s*,?\s*[0-9A-F]{3,4}\s*(?:,\s*\d+)?$", "d_u_range"),
    OpsCommand("DEVICES (U)", "D U,VOL=volser", "Display the unit holding a volume serial",
               r"^D(?:ISPLAY)?\s+U,\s*VOL=\S+$", "d_u_vol"),
    # ---- OMVS / USS --------------------------------------------------------
    OpsCommand("OMVS / USS", "D OMVS", "Display whether z/OS UNIX (OMVS) is active",
               r"^D(?:ISPLAY)?\s+OMVS$", "d_omvs"),
    OpsCommand("OMVS / USS", "D OMVS,F", "Display mounted file systems",
               r"^D(?:ISPLAY)?\s+OMVS,\s*F(?:ILE)?$", "d_omvs_f"),
    OpsCommand("OMVS / USS", "D OMVS,OPTIONS", "Display current OMVS (BPXPRMxx) options",
               r"^D(?:ISPLAY)?\s+OMVS,\s*O(?:PTIONS)?$", "d_omvs_options"),
    # ---- SYSPLEX (XCF) -----------------------------------------------------
    OpsCommand("SYSPLEX (XCF)", "D XCF,STR", "List coupling-facility structures",
               r"^D(?:ISPLAY)?\s+XCF,\s*STR$", "d_xcf_str"),
    OpsCommand("SYSPLEX (XCF)", "D XCF,STRNAME=name", "Display detail for one structure",
               r"^D(?:ISPLAY)?\s+XCF,\s*STRNAME=\S+$", "d_xcf_strname"),
    # ---- GRS ENQUEUES ------------------------------------------------------
    OpsCommand("GRS ENQUEUES", "D GRS,C", "Display resource contention",
               r"^D(?:ISPLAY)?\s+GRS,\s*C(?:ONTENTION)?$", "d_grs_c"),
    OpsCommand("GRS ENQUEUES", "D GRS,RES=(qname,rname)", "Display ENQ holders/waiters for a resource (e.g. D GRS,RES=(SYSDSN))",
               r"^D(?:ISPLAY)?\s+GRS,\s*RES=\(.*\)$", "d_grs_res"),
    OpsCommand("GRS ENQUEUES", "D GRS,E,C", "Display the resource everyone is waiting on",
               r"^D(?:ISPLAY)?\s+GRS,\s*E,\s*C$", "d_grs_ec"),
    # ---- JOBS & TASKS ------------------------------------------------------
    OpsCommand("JOBS & TASKS", "CANCEL jobname", "Cancel a batch job or started task",
               r"^(?:C|CANCEL)\s+(?!U=)\S+$", "cancel_job"),
    OpsCommand("JOBS & TASKS", "CANCEL U=userid", "Cancel (force off) a TSO user",
               r"^(?:C|CANCEL)\s+U=\S+$", "cancel_user"),
    OpsCommand("JOBS & TASKS", "S proc", "Start a system task from a PROCLIB member",
               r"^(?:S|START)\s+[^\s.,]+$", "start_proc"),
    OpsCommand("JOBS & TASKS", "S proc.id", "Start a named instance of a task (e.g. S CICS.CICS1)",
               r"^(?:S|START)\s+\S+[.,]\S+$", "start_proc_id"),
    OpsCommand("JOBS & TASKS", "P proc", "Stop a system task that listens for STOP",
               r"^(?:P|STOP)\s+(?!JES2$)[^\s.,]+$", "stop_proc"),
    OpsCommand("JOBS & TASKS", "P jobname.id,A=asid", "Stop one instance of a multi-copy task",
               r"^(?:P|STOP)\s+\S+\.\S+,\s*A=\S+$", "stop_proc_asid"),
    OpsCommand("JOBS & TASKS", "F jobname,parm", "Modify (pass a command to) a running task",
               r"^(?:F|MODIFY)\s+\S+,.+$", "modify_task"),
    # ---- APF / PROG --------------------------------------------------------
    OpsCommand("APF / PROG", "SETPROG APF,ADD,DSN=dsn,VOLUME=vol", "APF-authorise a library",
               r"^SETPROG\s+APF,\s*ADD,.+$", "setprog_apf_add"),
    OpsCommand("APF / PROG", "D PROG,APF", "Display the APF-authorised library list",
               r"^D(?:ISPLAY)?\s+PROG,\s*APF$", "d_prog_apf"),
    # ---- VTAM --------------------------------------------------------------
    OpsCommand("VTAM", "D NET,ID=name", "Display a VTAM node (major/minor)",
               r"^D(?:ISPLAY)?\s+NET,\s*ID=\S+.*$", "d_net_id"),
    OpsCommand("VTAM", "V NET,ACT,ID=name", "Activate a VTAM node",
               r"^V(?:ARY)?\s+NET,\s*ACT,\s*ID=\S+$", "v_net_act"),
    OpsCommand("VTAM", "V NET,INACT,ID=name", "Deactivate a VTAM node",
               r"^V(?:ARY)?\s+NET,\s*INACT,\s*ID=\S+.*$", "v_net_inact"),
    OpsCommand("VTAM", "Z NET,QUICK", "Shut VTAM down (quick)",
               r"^Z\s+NET,\s*QUICK$", "z_net_quick"),
    # ---- SUBSYSTEMS --------------------------------------------------------
    OpsCommand("SUBSYSTEMS", "SETSSI ADD,S=name,I=init,INITPARM='...'", "Dynamically add a subsystem (DB2/MQ)",
               r"^SETSSI\s+ADD,.+$", "setssi_add"),
    OpsCommand("SUBSYSTEMS", "%qmgr START QMGR", "Route a command to an MQ queue manager (e.g. %CSQ9 START QMGR)",
               r"^%\S+.*$", "mq_command"),
    OpsCommand("SUBSYSTEMS", "-DB2 START DB2", "Route a command to a Db2 subsystem (e.g. -DBCG START DB2)",
               r"^-\S+.*$", "db2_command"),
    # ---- TCP/IP ------------------------------------------------------------
    OpsCommand("TCP/IP", "D TCPIP", "Display the TCP/IP stacks that are available",
               r"^D(?:ISPLAY)?\s+TCPIP$", "d_tcpip"),
    OpsCommand("TCP/IP", "D TCPIP,proc,NETSTAT,CONN", "Display active connections (name the stack if >1)",
               r"^D(?:ISPLAY)?\s+TCPIP,\s*\S*,\s*N(?:ETSTAT)?,\s*CONN$", "d_tcpip_conn"),
    OpsCommand("TCP/IP", "D TCPIP,proc,NETSTAT,HOME", "Display the IP addresses (HOME list) of a stack",
               r"^D(?:ISPLAY)?\s+TCPIP,\s*\S*,\s*N(?:ETSTAT)?,\s*HOME$", "d_tcpip_home"),
    # ---- JES2 (prefix $) ---------------------------------------------------
    OpsCommand("JES2", "$DJES2", "Display current activity in the JES2 address space",
               r"^\$D\s*JES2$", "jes2_djes2"),
    OpsCommand("JES2", "$DI / $DIn-m", "Display initiators (optionally a range, e.g. $DI1-5)",
               r"^\$D\s*I(?:\d+(?:-\d+)?)?$", "jes2_di"),
    OpsCommand("JES2", "$SIn-m", "Start initiators n through m",
               r"^\$S\s*I\d+(?:-\d+)?$", "jes2_si"),
    OpsCommand("JES2", "$PIn-m", "Stop (drain) initiators n through m",
               r"^\$P\s*I\d+(?:-\d+)?$", "jes2_pi"),
    OpsCommand("JES2", "$ADD PRTn,UNIT=cuu", "Define a printer",
               r"^\$ADD\s+PRT\d+,.+$", "jes2_add_prt"),
    OpsCommand("JES2", "$DPRTn / $DPRT*", "Display one or all printers",
               r"^\$D\s*PRT(?:\d+|\*)$", "jes2_dprt"),
    OpsCommand("JES2", "$SPRTn", "Start a printer",
               r"^\$S\s*PRT\d+$", "jes2_sprt"),
    OpsCommand("JES2", "$PPRTn", "Stop (drain) a printer",
               r"^\$P\s*PRT\d+$", "jes2_pprt"),
    OpsCommand("JES2", "$DU,STA", "Display which JES2 units (devices) are started",
               r"^\$D\s*U,\s*STA$", "jes2_du_sta"),
    OpsCommand("JES2", "$T JOBCLASS(x),OUTDISP=(,)", "Display/alter where STC output is going",
               r"^\$T\s+JOBCLASS\(\w+\),\s*OUTDISP=\(.*\)$", "jes2_t_jobclass"),
    OpsCommand("JES2", "$PJES2", "Withdraw JES2 (only after everything is quiesced)",
               r"^\$P\s*JES2$", "jes2_pjes2"),
]


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
class MasterConsoleOps:
    """Dispatch, help and completion for master-console operator commands.

    Bound to a MasterConsoleController so it can reuse the live GibsonState
    (service manager, sessions, symbols) and timestamp helper.
    """

    # A small, coherent DASD map so the U commands are internally consistent.
    # Address (hex, upper) -> (device type, volser).
    _DASD = {
        "0A80": "SBSYS1", "0A81": "SBSYS2", "0A82": "SBCFG1", "0A83": "SBPAGE",
        "0A84": "SBUSS1", "0A85": "SBDB21", "0A86": "SBDB22", "0A87": "SBWORK",
        "0A88": "SBSPL1", "0A89": "SBSMP1", "0A8A": "SBUSR1", "0A8B": "SBUSR2",
        "0A8C": "SBHFS1", "0A8D": "SBHFS2", "0A8E": "SBTEMP", "0A8F": "SBDLB1",
        "0A30": "SBRES1", "0A31": "A3RES1", "0A32": "A3RES2",
    }

    def __init__(self, controller):
        self.c = controller
        self.state = controller.state

    # -- small helpers -------------------------------------------------------
    def _ts(self) -> str:
        return datetime.now().strftime("%H.%M.%S")

    def _julian(self) -> str:
        return datetime.now().strftime("%Y.%j")

    def _serial(self) -> str:
        # z/OS multiline messages carry a 2-3 digit reply/serial number.
        return f"{(datetime.now().microsecond // 1000) % 900 + 100:03d}"

    def _sysname(self) -> str:
        return str(getattr(self.state.network, "hostname", "GIBSON") or "GIBSON").upper()[:8]

    def _services(self):
        mgr = getattr(self.state, "service_manager", None)
        return mgr.status_rows() if mgr is not None else []

    def _started(self):
        return [name for name, st, *_ in self._services() if st == "STARTED"]

    def _tso_users(self):
        reg = getattr(self.state, "sessions", None)
        try:
            users = [u for u, info in reg.sessions.items() if getattr(info, "active", True)]
        except Exception:
            users = []
        return sorted(set(users))

    # ------------------------------------------------------------------ #
    # dispatch
    # ------------------------------------------------------------------ #
    def normalise(self, raw: str) -> str:
        s = (raw or "").strip()
        # JES2 prefix: accept £ (some keyboards) as $
        if s[:1] == "\u00a3":
            s = "$" + s[1:]
        return s

    def dispatch(self, raw: str) -> Optional[str]:
        """Return realistic output for an operator command, or None if the
        command is not one of ours (caller then falls through)."""
        s = self.normalise(raw)
        u = re.sub(r"\s+", " ", s.upper()).strip()
        # Simple start/stop of a *managed* service stays on the controller's
        # authorization-checked path; instance forms (proc.id / ,A=) and
        # unknown procs get the realistic $HASP/IEF acknowledgement below.
        m = re.match(r"^(?:S|START|P|STOP|PAUSE|RESUME)\s+([^\s.,]+)$", u)
        if m:
            svc = self.c._service_name(m.group(1))
            mgr = getattr(self.state, "service_manager", None)
            if mgr is not None and mgr.get(svc) is not None:
                return None
        for spec in COMMAND_TABLE:
            if spec.rx().match(u):
                return getattr(self, spec.handler)(s)
        return None

    # ------------------------------------------------------------------ #
    # help facility (context-specific)
    # ------------------------------------------------------------------ #
    def help(self) -> str:
        out = ["IEE163I MASTER CONSOLE COMMANDS - GIBSON TRAINING LPAR",
               "Type the start of a command followed by ? for completion (e.g. D U,?)",
               ""]
        cat = None
        for spec in COMMAND_TABLE:
            if spec.category != cat:
                cat = spec.category
                out.append(f"{cat}")
            out.append(f"  {spec.syntax:<34} {spec.desc}")
        out.append("")
        out.append("  R nn,text                          Reply to outstanding WTOR nn")
        out.append("  Z EOD                              Simulated end-of-day shutdown")
        out.append("  QUIT | EXIT                        Leave the master console")
        return "\n".join(out)

    # ------------------------------------------------------------------ #
    # ? completion facility (TSO-style)
    # ------------------------------------------------------------------ #
    def complete(self, buffer: str) -> str:
        """Given the text typed before a trailing '?', list the ways the
        command can be completed - mirroring the TSO READY '?' facility."""
        stem = re.sub(r"\s+", " ", self.normalise(buffer).upper()).strip()
        if stem[:1] == "\u00a3":
            stem = "$" + stem[1:]

        def norm(x: str) -> str:
            return re.sub(r"\s+", " ", x.upper()).strip()

        if not stem:
            return self.help()

        def fixed_prefix(cand: str) -> str:
            # the literal leading portion of a syntax, up to the first
            # placeholder (lowercase word, '(', or '='), e.g. "D U," from
            # "D U,,,cuu,nn" and "$DI" from "$DI / $DIn-m".
            return norm(re.split(r"[a-z]|\(|=|/", cand)[0])

        matches: List[OpsCommand] = []
        for spec in COMMAND_TABLE:
            for cand in (spec.syntax, *spec.aliases):
                fp = fixed_prefix(cand)
                full = norm(cand)
                if full.startswith(stem) or (fp and (fp.startswith(stem) or stem.startswith(fp))):
                    matches.append(spec)
                    break

        seen, uniq = set(), []
        for m in matches:
            if m.syntax not in seen:
                seen.add(m.syntax)
                uniq.append(m)

        if not uniq:
            return f"IEE305I NO COMPLETION FOR: {buffer.strip()}"

        out = [f"IEE163I COMMAND COMPLETION FOR {buffer.strip()!r}", "COMMAND / SYNTAX"]
        for spec in uniq:
            out.append(f"  {spec.syntax:<34} {spec.desc}")
        return "\n".join(out)

    # ================================================================== #
    # HANDLERS
    # ================================================================== #

    # ---- MVS DISPLAY -------------------------------------------------------
    def d_replies(self, raw: str) -> str:
        return self._format_replies(reply_only=False)

    def d_replies_r(self, raw: str) -> str:
        return self._format_replies(reply_only=True)

    def _format_replies(self, reply_only: bool) -> str:
        reqs = list(self.c._state_obj().get("outstanding", {}).values())
        if reply_only:
            reqs = [r for r in reqs if getattr(r, "kind", "WTOR") == "WTOR"]
        head = [f"IEE112I {self._ts()} PENDING REQUESTS {self._serial()}",
                " RM=0     IM=0     CEM=0     EM=0     RU=0     IR=0     NOAMRF"]
        if not reqs:
            head.append(" NO OUTSTANDING MESSAGES OR REQUESTS")
            return "\n".join(head)
        head.append(" ID:R/K T SYSNAME  MESSAGE TEXT")
        for r in reqs:
            rid = getattr(r, "reply_id", 0)
            head.append(f" {rid:>2} R      {self._sysname():<8} {r.render()}")
        return "\n".join(head)

    def _activity_body(self, tasks):
        """Format address spaces two-per-line as real IEE114I does."""
        def cell(jn, sn, ps, sw="NSW", sc="S"):
            return f"{jn:<8} {sn:<8} {ps:<8} {sw:<3}  {sc}"
        lines, buf = [], ""
        for i, t in enumerate(tasks):
            entry = cell(*t)
            if i % 2 == 0:
                buf = " " + entry
            else:
                lines.append(buf + "   " + entry)
                buf = ""
        if buf:
            lines.append(buf)
        return lines

    def _system_spaces(self):
        # Core z/OS system address spaces always present, in IPL order.
        base = ["PCAUTH", "RASP", "TRACE", "DUMPSRV", "XCFAS", "GRS", "SMSPDSE",
                "CONSOLE", "WLM", "ANTMAIN", "OMVS", "IEFSCHAS", "JESXCF",
                "ALLOCAS", "SMS", "CATALOG"]
        return [(n, n, n if n in ("CONSOLE", "ALLOCAS") else "IEFPROC") for n in base]

    def d_active(self, raw: str) -> str:
        from gibson.core.address_spaces import system_address_spaces
        spaces = system_address_spaces(self.state)
        # started tasks / system address spaces (two-per-line, like real IEE114I)
        tasks = [(s.jobname, s.stepname, s.stepname)
                 for s in spaces if s.astype in ("STC", "SYSTEM", "INIT")]
        body = self._activity_body(tasks)
        # TSO users at the bottom as OWT owners, three per line
        tso = [s.jobname for s in spaces if s.astype == "TSU"] or self._tso_users()
        tso_lines, row = [], []
        for u in tso:
            row.append(f"{u:<8} OWT")
            if len(row) == 3:
                tso_lines.append(" " + "   ".join(row)); row = []
        if row:
            tso_lines.append(" " + "   ".join(row))
        jobs = sum(1 for s in spaces if s.astype == "JOB")
        ms = sum(1 for s in spaces if s.astype == "STC")
        sas = sum(1 for s in spaces if s.astype == "SYSTEM")
        inits = sum(1 for s in spaces if s.astype == "INIT")
        tsu = len(tso)
        head = [
            f"IEE114I {self._ts()} {self._julian()} ACTIVITY {self._serial()}",
            " JOBS     M/S      TS USERS    SYSAS    INITS    ACTIVE/MAX VTAM     OAS",
            f" {jobs:05d}    {ms:05d}    {tsu:05d}       {sas:05d}    {inits:05d}    "
            f"{tsu + jobs:05d}/00050         00000",
        ]
        return "\n".join(head + body + tso_lines)

    def d_active_user(self, raw: str) -> str:
        m = re.search(r"(?:USERID|U)=(\S+)", raw, re.I)
        uid = (m.group(1) if m else "").upper()
        tso = [u for u in self._tso_users() if u == uid]
        head = [f"IEE114I {self._ts()} {self._julian()} ACTIVITY {self._serial()}",
                " JOBS     M/S      TS USERS    SYSAS    INITS    ACTIVE/MAX VTAM     OAS",
                f" 00000    00000    {len(tso):05d}       00000    00000    00000/00020         00000"]
        if tso:
            head.append(f" {uid:<8} {uid:<8} OWT")
            head.append(f" ASID=00{(hash(uid) % 200) + 40:02X}  CT=000.312S  ET=00021.44S  WUID=TSU{(hash(uid)%9000)+1000}")
        else:
            head.append(f" IEE115I NO ACTIVE WORK FOR USERID {uid}")
        return "\n".join(head)

    def d_ts(self, raw: str) -> str:
        tso = self._tso_users()
        head = [f"IEE114I {self._ts()} {self._julian()} ACTIVITY {self._serial()}",
                " JOBS     M/S      TS USERS    SYSAS    INITS    ACTIVE/MAX VTAM     OAS",
                f" 00000    00000    {len(tso):05d}       00000    00000    00000/00020         00000"]
        if not tso:
            head.append(" NO TSO USERS ACTIVE")
            return "\n".join(head)
        row = []
        for u in tso:
            row.append(f"{u:<8} OWT")
            if len(row) == 3:
                head.append(" " + "   ".join(row)); row = []
        if row:
            head.append(" " + "   ".join(row))
        return "\n".join(head)

    def d_iplinfo(self, raw: str) -> str:
        st = self.c._state_obj()
        member = str(st.get("ieasys_member", "00") or "00").replace("IEASYS", "")
        parms = st.get("ipl_parms") or "00"
        now = datetime.now()
        return "\n".join([
            f"IEE254I {self._ts()} IPLINFO DISPLAY {self._serial()}",
            f" SYSTEM IPLED AT {now.strftime('%H.%M.%S')} ON {now.strftime('%m/%d/%Y')}",
            " RELEASE z/OS 02.05.00          LICENSE = z/OS",
            " USED LOAD00 IN SYS1.IPLPARM ON 0A80",
            " ARCHLVL = 2   MTLSHARE = N",
            " IEASYM LIST = 00",
            f" IEASYS LIST = ({member}) (OP)",
            " IODF DEVICE: ORIGINAL(0A80) CURRENT(0A80)",
            " IPL DEVICE: ORIGINAL(0A80) CURRENT(0A80) VOLUME(SBSYS1)",
        ])

    def d_ssi(self, raw: str) -> str:
        # Subsystem name table (IEFSSNxx). Primary = JES2.
        subs = [("JES2", "PRIMARY", "ACTIVE"), ("MSTR", "MASTER", "ACTIVE"),
                ("SMS", "-", "ACTIVE"), ("RACF", "-", "ACTIVE"),
                ("OMVS", "-", "ACTIVE"), ("ICSF", "-", "ACTIVE"),
                ("DB2", "-", "ACTIVE" if "DB2" in self._started() else "INACTIVE"),
                ("CSQ9", "-", "INACTIVE")]
        out = [f"IEFJSVMSG SUBSYSTEM SUMMARY {self._serial()}",
               "SUBSYS   TYPE      STATUS   DYNAMIC  COMMAND PREFIX",
               "-------- --------- -------- -------- --------------"]
        for name, typ, status in subs:
            dyn = "YES" if name in ("DB2", "CSQ9", "OMVS") else "NO"
            pfx = {"JES2": "$", "DB2": "-DB2", "CSQ9": "%CSQ9"}.get(name, "N/A")
            out.append(f"{name:<8} {typ:<9} {status:<8} {dyn:<8} {pfx}")
        return "\n".join(out)

    def d_ssi_sub(self, raw: str) -> str:
        m = re.search(r"SUB=(\S+)", raw, re.I)
        name = (m.group(1) if m else "").upper()
        active = name in ("JES2", "MSTR", "SMS", "RACF", "OMVS", "ICSF") or name in self._started()
        return "\n".join([
            f"IEFJSVMSG SUBSYSTEM {name} {self._serial()}",
            f"  SUBSYSTEM NAME . . . : {name}",
            f"  STATUS . . . . . . . : {'ACTIVE' if active else 'INACTIVE'}",
            f"  DYNAMIC. . . . . . . : {'YES' if name in ('DB2','CSQ9','OMVS') else 'NO'}",
            f"  COMMANDS ACCEPTED. . : {'YES' if active else 'NO'}",
        ])

    # ---- DEVICES -----------------------------------------------------------
    def _unit_line(self, addr, volser, status="A", volstate="PRIV/RSDNT"):
        return f" {addr[-4:]} 3390 {status:<7}{volser:<6} {volstate}"

    def _u_header(self):
        return [f"IEE457I {self._ts()} UNIT STATUS {self._serial()}",
                " UNIT TYPE STATUS      VOLSER VOLSTATE"]

    def d_u_dasd_online(self, raw: str) -> str:
        out = self._u_header()
        for addr in sorted(self._DASD):
            vol = self._DASD[addr]
            status = "A" if addr in ("0A80", "0A31") else "O"
            out.append(self._unit_line(addr, vol, status))
        return "\n".join(out)

    def d_u_range(self, raw: str) -> str:
        m = re.search(r"U,\s*,?\s*,?\s*([0-9A-Fa-f]{3,4})\s*(?:,\s*(\d+))?", raw, re.I)
        base = int(m.group(1), 16)
        count = int(m.group(2) or "1")
        out = self._u_header()
        for i in range(min(count, 256)):
            addr = f"{base + i:04X}"
            vol = self._DASD.get("0" + addr[-3:] if len(addr) == 3 else addr, None)
            key = addr if addr in self._DASD else ("0" + addr)[-4:]
            vol = self._DASD.get(key)
            if vol:
                out.append(self._unit_line(addr, vol, "O"))
            else:
                out.append(f" {addr[-4:]} 3390 OFFLINE")
        return "\n".join(out)

    def d_u_vol(self, raw: str) -> str:
        m = re.search(r"VOL=(\S+)", raw, re.I)
        vol = (m.group(1) if m else "").upper()
        out = self._u_header()
        for addr, v in sorted(self._DASD.items()):
            if v == vol:
                out.append(self._unit_line(addr, v, "A"))
                return "\n".join(out)
        out.append(f" IEE455I VOLUME {vol} NOT MOUNTED")
        return "\n".join(out)

    # ---- OMVS / USS --------------------------------------------------------
    def _omvs_active(self):
        return "OMVS" in self._started()

    def d_omvs(self, raw: str) -> str:
        if not self._omvs_active():
            return "\n".join([f"BPXO042I {self._ts()} DISPLAY OMVS {self._serial()}",
                              "OMVS     NOT ACTIVE"])
        return "\n".join([f"BPXO042I {self._ts()} DISPLAY OMVS {self._serial()}",
                          "OMVS     000E ACTIVE             OMVS=(00)"])

    def d_omvs_f(self, raw: str) -> str:
        if not self._omvs_active():
            return f"BPXO042I {self._ts()} DISPLAY OMVS {self._serial()}\nOMVS     NOT ACTIVE"
        today = datetime.now().strftime("%m/%d/%Y")
        mounts = [("ZFS", 1, "OMVS.ROOT.ZFS", "/", "RDWR"),
                  ("ZFS", 2, "OMVS.USR.ZFS", "/usr", "READ"),
                  ("ZFS", 3, "OMVS.VAR.ZFS", "/var", "RDWR"),
                  ("ZFS", 4, "OMVS.TMP.ZFS", "/tmp", "RDWR")]
        out = [f"BPXO045I {self._ts()} DISPLAY OMVS {self._serial()}",
               "OMVS     000E ACTIVE             OMVS=(00)",
               "TYPENAME    DEVICE ----------STATUS----------- MODE  MOUNTED     LATCHES"]
        for typ, dev, name, path, mode in mounts:
            out.append(f"{typ:<11} {dev:>5} ACTIVE                       {mode:<5} {today}  L=0")
            out.append(f"  NAME={name}")
            out.append(f"  PATH={path}")
        return "\n".join(out)

    def d_omvs_options(self, raw: str) -> str:
        return "\n".join([
            f"BPXO043I {self._ts()} DISPLAY OMVS {self._serial()}",
            "OMVS     000E ACTIVE             OMVS=(00)",
            "CURRENT UNIX CONFIGURATION SETTINGS:",
            " MAXPROCSYS      =        900  MAXPROCUSER     =        512",
            " MAXFILEPROC     =      65535  MAXPTYS         =        256",
            " MAXTHREADS      =      100000 MAXTHREADTASKS  =       5000",
            " IPCMSGQBYTES    =    2147483647",
            " SUPERUSER       = BPXROOT     FORKCOPY        = COW",
            " STEPLIBLIST     = /etc/steplib",
        ])

    # ---- XCF ---------------------------------------------------------------
    _STRUCTURES = ["ISGLOCK", "SYSZWLM_WORKUNIT", "IXCPLEX_PATH1",
                   "DSNDB0G_LOCK1", "DSNDB0G_GBP0", "CSQ_ADMIN"]

    def d_xcf_str(self, raw: str) -> str:
        out = [f"IXC359I {self._ts()} DISPLAY XCF {self._serial()}",
               "STRNAME          ALLOCATION TIME     STATUS   TYPE"]
        for s in self._STRUCTURES:
            out.append(f"{s:<16} 07/11/2026 06.27.55 ALLOCATED {'LOCK' if 'LOCK' in s else 'LIST/CACHE'}")
        return "\n".join(out)

    def d_xcf_strname(self, raw: str) -> str:
        m = re.search(r"STRNAME=(\S+)", raw, re.I)
        name = (m.group(1) if m else "").upper()
        if name not in [s.upper() for s in self._STRUCTURES]:
            return f"IXC358I {self._ts()} DISPLAY XCF {self._serial()}\n STRNAME {name} NOT FOUND"
        return "\n".join([
            f"IXC360I {self._ts()} DISPLAY XCF {self._serial()}",
            f"STRNAME: {name}",
            " STATUS: ALLOCATED",
            " TYPE: SERIALIZED LIST",
            " POLICY SIZE    : 20480 K",
            " ACTUAL SIZE    : 20480 K",
            " PREFERENCE LIST: CF01     CF02",
            " EXCLUSION LIST IS EMPTY",
            f" ACTIVE STRUCTURE VERSION: D3C4F0{self._serial()}",
        ])

    # ---- GRS ---------------------------------------------------------------
    def d_grs_c(self, raw: str) -> str:
        return "\n".join([
            f"ISG343I {self._ts()} GRS STATUS {self._serial()}",
            "NO ENQ CONTENTION EXISTS",
        ])

    def d_grs_res(self, raw: str) -> str:
        m = re.search(r"RES=\(([^,\)]+)(?:,([^\)]+))?\)", raw, re.I)
        qname = (m.group(1) if m else "*").strip().upper()
        rname = (m.group(2) if m and m.group(2) else "*").strip().upper()
        if qname in ("*", "SYSDSN"):
            return "\n".join([
                f"ISG343I {self._ts()} GRS STATUS {self._serial()}",
                f"S=SYSTEM  {qname:<8} {('SYS1.PARMLIB' if rname=='*' else rname)}",
                " SYSNAME        JOBNAME         ASID     TCBADDR   EXC/SHR    STATUS",
                f" {self._sysname():<14} JES2            0028     008FDA90  SHARE      OWN",
                f" {self._sysname():<14} CATALOG         0023     008FE110  SHARE      OWN",
            ])
        return "\n".join([
            f"ISG343I {self._ts()} GRS STATUS {self._serial()}",
            f"NO REQUESTORS FOR RESOURCE {qname} {rname}",
        ])

    def d_grs_ec(self, raw: str) -> str:
        return "\n".join([
            f"ISG343I {self._ts()} GRS STATUS {self._serial()}",
            "NO ENQ CONTENTION EXISTS",
        ])

    # ---- JOBS & TASKS ------------------------------------------------------
    def cancel_job(self, raw: str) -> str:
        job = raw.split(None, 1)[1].strip().upper()
        if job in self._started():
            return f"IEE301I {job} CANCEL COMMAND ACCEPTED"
        return f"IEE341I {job} NOT ACTIVE"

    def cancel_user(self, raw: str) -> str:
        m = re.search(r"U=(\S+)", raw, re.I)
        uid = (m.group(1) if m else "").upper()
        if uid in self._tso_users():
            return f"IEE301I {uid} CANCEL COMMAND ACCEPTED\nIKJ600I USER {uid} LOGGED OFF BY OPERATOR"
        return f"IEE341I TSO USER {uid} NOT LOGGED ON"

    def start_proc(self, raw: str) -> str:
        # Defer to Gibson's service manager where the proc maps to a service,
        # otherwise emit a realistic start acknowledgement.
        name = raw.split(None, 1)[1].strip().upper().split(".")[0].split(",")[0]
        svc = self.c._service_name(name)
        mgr = getattr(self.state, "service_manager", None)
        if mgr is not None and mgr.get(svc) is not None:
            return mgr.start(svc)[1]
        return f"$HASP100 {name} ON STCINRDR\n$HASP373 {name} STARTED\nIEF403I {name} - STARTED"

    def start_proc_id(self, raw: str) -> str:
        m = re.match(r"(?:S|START)\s+(\S+?)[.,](\S+)", raw, re.I)
        proc, ident = (m.group(1).upper(), m.group(2).upper()) if m else ("?", "?")
        return "\n".join([
            f"$HASP100 {ident} ON STCINRDR",
            f"$HASP373 {ident} STARTED",
            f"IEF403I {ident} - STARTED - TIME={self._ts()}",
        ])

    def stop_proc(self, raw: str) -> str:
        name = raw.split(None, 1)[1].strip().upper().split(".")[0].split(",")[0]
        svc = self.c._service_name(name)
        mgr = getattr(self.state, "service_manager", None)
        if mgr is not None and mgr.get(svc) is not None:
            return mgr.stop(svc)[1]
        return f"IEE301I {name} STOP COMMAND ACCEPTED\nIEF404I {name} - ENDED"

    def stop_proc_asid(self, raw: str) -> str:
        m = re.match(r"(?:P|STOP)\s+(\S+?)\.(\S+),\s*A=(\S+)", raw, re.I)
        job, jid, asid = (m.group(1), m.group(2), m.group(3)) if m else ("?", "?", "?")
        return f"IEE301I {job.upper()} STOP COMMAND ACCEPTED\nIEF404I {job.upper()}.{jid.upper()} (ASID={asid}) - ENDED"

    def modify_task(self, raw: str) -> str:
        m = re.match(r"(?:F|MODIFY)\s+(\S+),(.+)", raw, re.I)
        job, cmd = (m.group(1).upper(), m.group(2).strip()) if m else ("?", "")
        return f"IEE295I MODIFY {job} COMMAND ACCEPTED - {cmd}"

    # ---- APF / PROG --------------------------------------------------------
    def setprog_apf_add(self, raw: str) -> str:
        dsn = re.search(r"DSN(?:AME)?=([^,\s]+)", raw, re.I)
        vol = re.search(r"VOL(?:UME)?=([^,\s]+)", raw, re.I)
        dsn = dsn.group(1).upper() if dsn else "UNKNOWN.LIB"
        vol = vol.group(1).upper() if vol else "SMS"
        # register into the live APF list so a subsequent D PROG,APF shows it
        try:
            lst = getattr(self.state, "apf_libraries", None)
            if isinstance(lst, list) and dsn not in lst:
                lst.append(dsn)
        except Exception:
            pass
        return f"CSV410I DATA SET {dsn} ON VOLUME {vol} ADDED TO APF LIST\nCSV560I APF LIST UPDATE PROCESSED"

    def d_prog_apf(self, raw: str) -> str:
        return self.c._display_prog_apf()

    # ---- VTAM --------------------------------------------------------------
    def d_net_id(self, raw: str) -> str:
        m = re.search(r"ID=([^,\s]+)", raw, re.I)
        node = (m.group(1) if m else "").upper()
        return "\n".join([
            f"IST097I DISPLAY ACCEPTED",
            f"IST075I NAME = {node}, TYPE = APPL SEGMENT",
            f"IST486I STATUS= ACTIV, DESIRED STATE= ACTIV",
            f"IST1447I REGISTRATION TYPE = CDSERVR",
            f"IST977I MDLTAB=***NA*** ASLTAB=***NA***",
            f"IST861I MODETAB=***NA*** USSTAB=***NA*** LOGTAB=***NA***",
            f"IST314I END",
        ])

    def v_net_act(self, raw: str) -> str:
        m = re.search(r"ID=(\S+)", raw, re.I)
        node = (m.group(1) if m else "").upper()
        return f"IST097I VARY ACCEPTED\nIST093I {node} ACTIVE"

    def v_net_inact(self, raw: str) -> str:
        m = re.search(r"ID=([^,\s]+)", raw, re.I)
        node = (m.group(1) if m else "").upper()
        return f"IST097I VARY ACCEPTED\nIST105I {node} NODE NOW INACTIVE"

    def z_net_quick(self, raw: str) -> str:
        return "\n".join([
            "IST097I HALT ACCEPTED",
            "IST1305I HALT NET QUICK COMMAND IN PROGRESS",
            "IST802I QUICK CLOSEDOWN OF VTAM IN PROGRESS",
        ])

    # ---- SUBSYSTEMS --------------------------------------------------------
    def setssi_add(self, raw: str) -> str:
        s = re.search(r"S=([^,\s]+)", raw, re.I)
        name = (s.group(1) if s else "").upper()
        return f"IEFJ001I SUBSYSTEM {name} ADDED VIA SETSSI COMMAND"

    def mq_command(self, raw: str) -> str:
        m = re.match(r"%(\S+)\s*(.*)", raw)
        qmgr = (m.group(1) if m else "").upper()
        rest = (m.group(2) if m else "").strip().upper()
        if "START" in rest:
            return "\n".join([f"CSQ9022I {qmgr} START QMGR ACCEPTED",
                              f"CSQ9022I {qmgr} CSQYASCP ' START QMGR' NORMAL COMPLETION"])
        return f"CSQ9022I {qmgr} '{rest}' NORMAL COMPLETION"

    def db2_command(self, raw: str) -> str:
        m = re.match(r"-(\S+)\s*(.*)", raw)
        ssid = (m.group(1) if m else "").upper()
        rest = (m.group(2) if m else "").strip().upper()
        if "START" in rest:
            return "\n".join([f"DSNY001I  -{ssid} SUBSYSTEM STARTING",
                              f"DSN9022I  -{ssid} DSNYASCP 'START DB2' NORMAL COMPLETION"])
        if "STOP" in rest:
            return "\n".join([f"DSNY002I  -{ssid} SUBSYSTEM STOPPING",
                              f"DSN9022I  -{ssid} DSNYASCP 'STOP DB2' NORMAL COMPLETION"])
        return f"DSN9022I  -{ssid} DSNTFRCV '{rest}' NORMAL COMPLETION"

    # ---- TCP/IP ------------------------------------------------------------
    def _stacks(self):
        return ["TCPIP"]  # single stack in the Gibson LPAR

    def d_tcpip(self, raw: str) -> str:
        stacks = self._stacks()
        out = [f"EZAOP01I TCPIP STATUS REPORT {self._serial()}",
               "  COUNT        TCP/IP NAME   VERSION   STATUS"]
        for i, s in enumerate(stacks, 1):
            out.append(f"  {i}            {s:<13} CS V2R5   ACTIVE")
        return "\n".join(out)

    def _tcp_conns(self):
        # Derive plausible connections from open ports / services.
        rows = [("TCPIP", "TN3270", "0.0.0.0..23", "*..*", "Listen"),
                ("TCPIP", "FTPD1", "0.0.0.0..21", "*..*", "Listen"),
                ("TCPIP", "TCPIP", "0.0.0.0..8080", "*..*", "Listen")]
        return rows

    def d_tcpip_conn(self, raw: str) -> str:
        out = ["EZZ2500I NETSTAT CS V2R5 TCPIP",
               "USER ID  CONN     LOCAL SOCKET           FOREIGN SOCKET         STATE"]
        for i, (proc, uid, loc, frn, st) in enumerate(self._tcp_conns(), 1):
            out.append(f"{uid:<8} {i:08X} {loc:<22} {frn:<22} {st}")
        out.append(f"{len(self._tcp_conns())} OF {len(self._tcp_conns())} RECORDS DISPLAYED")
        return "\n".join(out)

    def d_tcpip_home(self, raw: str) -> str:
        host = self._sysname()
        return "\n".join([
            "EZZ2500I NETSTAT CS V2R5 TCPIP",
            "HOME ADDRESS LIST:",
            "LINKNAME:   LOOPBACK",
            "  ADDRESS: 127.0.0.1  FLAGS: PRIMARY",
            "LINKNAME:   ETH1",
            f"  ADDRESS: 10.1.1.10  FLAGS:",
            "2 OF 2 RECORDS DISPLAYED",
        ])

    # ---- JES2 --------------------------------------------------------------
    def jes2_djes2(self, raw: str) -> str:
        return "\n".join([
            f"$HASP9250 DISPLAY JES2 ACTIVITY",
            "  OUTSTANDING I/O . . : 0",
            "  ACTIVE ADDRESS SPACES: JES2",
            "  ACTIVE NETWORKING DEVICES: 0",
            "  SPOOL UTILIZATION . : 12 PERCENT",
            "$HASP000 OK",
        ])

    def _init_range(self, raw: str):
        m = re.search(r"I\s*(\d+)?(?:-(\d+))?", raw, re.I)
        if not m or not m.group(1):
            return list(range(1, 11))
        lo = int(m.group(1)); hi = int(m.group(2) or lo)
        return list(range(lo, hi + 1))

    def jes2_di(self, raw: str) -> str:
        # An idle training LPAR: initiators are defined but inactive (drained
        # of work). $S makes them active; a live job would show JOBNAME/ASID.
        out = []
        for n in self._init_range(raw):
            cls = "ABC" if n <= 3 else ("DE" if n <= 6 else "STC")
            out.append(f"$HASP890 INIT({n})      STATUS=INACTIVE,CLASS={cls}")
        return "\n".join(out) if out else "$HASP003 RC=(52) - NO INITIATORS MATCH"

    def jes2_si(self, raw: str) -> str:
        rng = self._init_range(raw)
        out = []
        for n in rng:
            out.append(f"$HASP890 INIT({n})      STATUS=ACTIVE,CLASS=ABC")
        out.append("$HASP000 OK")
        return "\n".join(out)

    def jes2_pi(self, raw: str) -> str:
        rng = self._init_range(raw)
        out = [f"$HASP395 INIT({n}) ENDED" for n in rng]
        out.append("$HASP000 OK")
        return "\n".join(out)

    def jes2_add_prt(self, raw: str) -> str:
        m = re.match(r"\$ADD\s+(PRT\d+),\s*UNIT=([0-9A-Fa-f]+)", raw, re.I)
        prt, unit = (m.group(1).upper(), m.group(2).upper()) if m else ("PRT?", "????")
        return f"$HASP000 OK\n$HASP603 {prt}      UNIT={unit},STATUS=DRAINED"

    def jes2_dprt(self, raw: str) -> str:
        m = re.search(r"PRT(\d+|\*)", raw, re.I)
        which = (m.group(1) if m else "*")
        nums = ["1", "2"] if which == "*" else [which]
        out = []
        for n in nums:
            out.append(f"$HASP603 PRT{n}      UNIT={'000E' if n=='1' else '000F'},STATUS=DRAINED,")
            out.append(f"$HASP603                CLASS=A,FORMS=STD,FCB=6,UCS=GF10,")
            out.append(f"$HASP603                MARK=YES,WS=(W,R,Q,PMD,LIM/F,P)")
        return "\n".join(out)

    def jes2_sprt(self, raw: str) -> str:
        m = re.search(r"PRT(\d+)", raw, re.I)
        n = m.group(1) if m else "?"
        return f"$HASP000 OK\n$HASP150 PRT{n}      STARTED"

    def jes2_pprt(self, raw: str) -> str:
        m = re.search(r"PRT(\d+)", raw, re.I)
        n = m.group(1) if m else "?"
        return f"$HASP000 OK\n$HASP160 PRT{n}      INACTIVE - DRAINED"

    def jes2_du_sta(self, raw: str) -> str:
        return "\n".join([
            "$HASP830 DEVICES WITH STATUS STARTED",
            "$HASP603 PRT1      UNIT=000E,STATUS=DRAINED",
            "$HASP603 RDR1      UNIT=00C,STATUS=DRAINED",
            "$HASP000 OK",
        ])

    def jes2_t_jobclass(self, raw: str) -> str:
        m = re.search(r"JOBCLASS\((\w+)\)", raw, re.I)
        cls = (m.group(1) if m else "STC").upper()
        return "\n".join([
            f"$HASP837 JOBCLASS({cls})",
            f"$HASP837 JOBCLASS({cls})  OUTDISP=(WRITE,WRITE),OUTPUT=YES,",
            f"$HASP837                  SCHENV=,MODE=JES",
            "$HASP000 OK",
        ])

    def jes2_pjes2(self, raw: str) -> str:
        # JES2 will not go dormant while other subsystems that depend on it are
        # still up; JES2 itself running is expected (we are stopping it).
        blockers = [b for b in self.c._shutdown_blockers() if b != "JES2"]
        if blockers:
            return "$HASP607 JES2 NOT DORMANT - ACTIVE ADDRESS SPACES: " + ", ".join(blockers)
        mgr = getattr(self.state, "service_manager", None)
        if mgr is not None and mgr.get("JES2") is not None:
            mgr.stop("JES2")
        return "\n".join([
            "$HASP099 ALL AVAILABLE FUNCTIONS COMPLETE",
            "$HASP085 JES2 TERMINATION COMPLETE",
        ])
