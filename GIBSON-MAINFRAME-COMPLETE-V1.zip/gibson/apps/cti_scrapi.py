"""ScrAPI Bear - API-to-mainframe threat actor for the GIBSON SENTRY CTI.

Phase-1 proof-of-concept, modelled 1:1 on ``gibson/apps/cti_hms.py`` (Heavy Metal
Spider).  Where HMS is a network/3270/FTP intruder, ScrAPI Bear is API-first: the
whole campaign enters through z/OS Connect REST and rides identity propagation
down into CICS/Db2.  Each stage fires the field-correct SMF record(s) into the
shared ``state.audit`` stream; 3+ distinct signatures raise a single correlation
alarm delivered to the Master Console, dashboard, and KEVIN/IBMUSER - exactly as
HMS does.

Training content only; the actor, attribution, identities and data are fictional.
The destructive ``ddf_impact`` stage stays a *rejected, audited* attempt.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

# Reuse the shared TTP shape so ScrAPI Bear renders in the same CTI widgets as HMS.
from gibson.apps.cti_hms import Ttp

ALARM_THRESHOLD = 3
ACTOR = "SCRAPI BEAR"

# --------------------------------------------------------------------------- #
#  TTP catalogue - the API-to-mainframe chain, in kill-chain order
# --------------------------------------------------------------------------- #
SCRAPI_TTPS: List[Ttp] = [
    Ttp("api_recon", 1, "T1595", "API discovery",
        "Enumerate z/OS Connect APIs / scrape OpenAPI on :8080 and :9443",
        "SMF 119.1 TCP connect :8080/:9443; SMF 123 API-INVOKE (admin GET), some 403",
        "Restrict admin interface; generic errors; alert on scraping", "curl-scraper"),
    Ttp("saf_denied", 2, "T1190", "Unauthorised invoke (SAF)",
        "Invoke an API without an INVOKE-capable SAF identity",
        "SMF 80 RACROUTE REQUEST=AUTH FAILURE (CLASS EJBROLE/SERVER, ZCONINV); BAQR0419W",
        "Least-privilege SAF groups; per-API authority", ""),
    Ttp("sqli_probe", 3, "T1190", "SQL error/baseline probe",
        "Baseline customer lookup then quote-break probe through customersAPI",
        "SMF 123 API-INVOKE customersAPI; SMF 101 Db2 accounting (SELECT CBSA.ACCOUNT)",
        "Parameterised static SQL (host vars); gateway schema validation", "sqlmap"),
    Ttp("sqli_bypass", 4, "T1190", "Auth-bypass mass disclosure",
        "' OR '1'='1 returns every account row via the API",
        "SMF 123 API-INVOKE; SMF 102 Db2 audit (ROWSET_EXPANDED); sqli_events ROWSET_EXPANDED",
        "Parameterised SQL; row-count alerts", "sqlmap"),
    Ttp("sqli_union", 5, "T1190", "UNION schema disclosure",
        "UNION SELECT ... FROM SYSIBM.SYSDUMMY1 maps the Db2 schema",
        "SMF 102 Db2 audit reads of SYSIBM.SYS*; sqli_events UNION_METADATA",
        "Parameterised SQL; least-priv on catalog", "sqlmap"),
    Ttp("sqli_blind", 6, "T1190", "Blind boolean inference",
        "' AND '1'='2 true/false oracle to extract data with no visible output",
        "SMF 123 bursts; SMF 102 alternating BOOLEAN_FALSE/NORMAL",
        "Parameterised SQL; anomaly detection on 4xx/row-count", "sqlmap"),
    Ttp("cics_abuse", 7, "T1059", "CICS transaction abuse",
        "Drive CICS transaction OMEN via COMMAREA from the accountsAPI",
        "SMF 110 CICS transaction OMEN; SMF 80 SURROGAT/EXTERNAL SECURITY",
        "CICS transaction + surrogate security; validate COMMAREA", ""),
    Ttp("bulk_exfil", 8, "T1213", "Bulk account/PII exfiltration",
        "High-volume account/customer pull through the API",
        "SMF 123 high-volume; SMF 102 large rowsets; SMF 119.70 FTP RETR (optional pivot)",
        "Rate limiting; least-priv Db2 plan; egress control", ""),
    Ttp("ddf_impact", 9, "T1489", "Subsystem disruption attempt",
        "Attempt -STOP DDF / stop the CICS region via a mis-privileged service id",
        "SMF 80 OPERCMDS AUTH FAILURE (-STOP DDF / $P) REJECTED; SMF 90 param change REJECTED",
        "Deny OPERCMDS to service ids; correct identity propagation", ""),
]

SCRAPI_TOOLS: List[Ttp] = [
    Ttp("sqlmap", 90, "T1190", "sqlmap (Db2/DRDA)",
        "Automated SQL injection against the Db2-backed API",
        "SMF 123 + SMF 102 bursts; classic sqlmap payload shapes",
        "Schema validation; WAF; parameterised SQL", "sqlmap"),
    Ttp("curl-scraper", 91, "T1595", "OpenAPI scraper",
        "Scripted enumeration of /zosConnect/apis and api-docs",
        "SMF 123 admin GET bursts; 403 BAQR0419W",
        "Restrict admin API; alert on enumeration", "curl-scraper"),
    Ttp("apifuzz", 92, "T1190", "API fuzzer",
        "Fuzz path/params against the published operations",
        "SMF 123 4xx bursts; malformed input",
        "Schema enforcement; rate limiting", "apifuzz"),
]

_TTP_BY_ID = {t.id: t for t in (SCRAPI_TTPS + SCRAPI_TOOLS)}

# Kill chain as framed for the CTI actor-profile page and the book chapter.
SCRAPI_KILLCHAIN = [
    ("Discovery", "Enumerate z/OS Connect APIs / OpenAPI",
     "SMF 119.1, SMF 123", "Admin API reachable; verbose errors",
     "Restrict admin interface; generic errors; alert on scraping"),
    ("Authorisation bypass", "Obtain an INVOKE-capable SAF identity",
     "SMF 80 (AUTH/CONNECT)", "Over-broad ZCONINV; shared service ids",
     "Least-privilege SAF groups; per-API authority"),
    ("Injection", "' OR '1'='1 / UNION / blind through customersAPI",
     "SMF 123, SMF 101/102", "COBOL builds dynamic SQL from COMMAREA input",
     "Parameterised static SQL (host vars); gateway schema validation"),
    ("Collection", "Bulk pull of accounts and PII",
     "SMF 123, SMF 102", "No row-count/rate limits; region holds broad SELECT",
     "Least-priv Db2 plan; rate limiting; row-count alerts"),
    ("Impact (attempted)", "Try to disrupt DDF / CICS",
     "SMF 80 (REJECTED), SMF 90", "Mis-privileged region id may hold OPERCMDS",
     "Deny operator commands to service ids; OPERCMDS in RACF"),
    ("Anti-forensics gap", "The missing log",
     "Absent SMF 123/102", "API/Db2 audit not cut or forwarded",
     "Enable API + Db2 audit; forward SMF off-platform"),
]


# --------------------------------------------------------------------------- #
@dataclass
class ScrapiSighting:
    ts: str
    ttp_id: str
    attack: str
    name: str
    src_ip: str
    userid: str
    detail: str
    smf: List[str] = field(default_factory=list)


@dataclass
class ScrapiState:
    sightings: List[ScrapiSighting] = field(default_factory=list)
    alarm: Optional[dict] = None
    corr_seq: int = 0
    auto_fired: set = field(default_factory=set)
    ddf_stopped: bool = False          # set only when a ddf_impact succeeds (vulnerable-mode)
    vulnerable_mode: Optional[bool] = None  # instructor override; None -> use env default


def _vulnerable_mode(state: Any) -> bool:
    """Instructor toggle: does the service identity (mis-)hold OPERCMDS authority?
    Off by default (the shutdown attempt is REJECTED + audited). Enable per-state via
    set_vulnerable_mode(), or globally via GIBSON_SCRAPI_VULNERABLE=1."""
    scr = getattr(state, "scrapi", None)
    if scr is not None and getattr(scr, "vulnerable_mode", None) is not None:
        return bool(scr.vulnerable_mode)
    return os.getenv("GIBSON_SCRAPI_VULNERABLE", "").lower() in ("1", "y", "yes", "true", "on")


def set_vulnerable_mode(state: Any, on: bool) -> None:
    get_scrapi_state(state).vulnerable_mode = bool(on)


def get_scrapi_state(state: Any) -> ScrapiState:
    st = getattr(state, "scrapi", None)
    if st is None:
        st = ScrapiState()
        try:
            state.scrapi = st
        except Exception:
            pass
    return st


def _now() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _corr(scr: ScrapiState) -> str:
    scr.corr_seq += 1
    return f"CORR-{datetime.now().strftime('%Y%m%d%H%M%S')}-{scr.corr_seq:04d}"


# --------------------------------------------------------------------------- #
#  SMF emission (field-correct, into the shared audit stream) - mirrors HMS._smf
# --------------------------------------------------------------------------- #
def _smf(state: Any, smf_type: int, subtype: Optional[int], event: str, userid: str,
         fields: Dict[str, str], result: str = "SUCCESS") -> str:
    audit = getattr(state, "audit", None)
    sub = f".{subtype}" if subtype is not None else ""
    command = f"SMF TYPE {smf_type}{(' SUBTYPE ' + str(subtype)) if subtype is not None else ''} {event}".strip()
    extra = {"RECORD_TYPE": str(smf_type), "SUBTYPE": ("" if subtype is None else str(subtype)),
             "EVENT": event.upper(), "RESULT": result.upper(), "ACTOR": ACTOR,
             "TIME": datetime.now().strftime("%H:%M:%S"), "DATE": datetime.now().strftime("%Y-%m-%d")}
    extra.update({str(k).upper(): str(v) for k, v in fields.items()})
    detail = " ".join(f"{k}={v}" for k, v in fields.items())
    if audit is not None:
        try:
            audit.record(userid.upper(), command, f"{result.upper()} {detail}".strip(),
                         f"SMF{smf_type}", extra=extra)
        except Exception:
            pass
    return f"SMF {smf_type}{sub} {event} {detail}".strip()


# --------------------------------------------------------------------------- #
#  Per-TTP evidence generators - the field-correct SMF for each API-attack stage
# --------------------------------------------------------------------------- #
def _gen(state: Any, scr: ScrapiState, ttp: Ttp, src_ip: str, userid: str, detail: str) -> List[str]:
    ip = src_ip or "203.0.113.44"
    u = (userid or "APIUSER").upper()
    cid = _corr(scr)
    out: List[str] = []

    if ttp.id == "api_recon":
        out.append(_smf(state, 119, 1, "TCP CONNECTION INITIATION", u, {
            "SRCIP": ip, "DSTPORT": "8080", "SERVICE": "ZOSCONNECT"}))
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "API": "admin", "METHOD": "GET", "URI": "/zosConnect/apis", "SAFUSER": u,
            "RESPONSECODE": "403", "CORRELATION_ID": cid}, result="FAILURE"))

    elif ttp.id == "saf_denied":
        # SMF 80 event 2 (resource access), qualifier 1 = insufficient authority
        out.append(_smf(state, 80, 2, "RACROUTE REQUEST=AUTH", u, {
            "EVENTQUAL": "1", "CLASS": "SERVER", "RESOURCE": "BBG.SECPFX.BBGZDFLT",
            "GROUP": "ZCONINV", "MSGID": "BAQR0419W", "VIOLATION": "1"}, result="FAILURE"))

    elif ttp.id == "sqli_probe":
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "API": "customersAPI", "METHOD": "GET", "URI": "/customers/1001", "SAFUSER": u,
            "SERVICE": "customerQueryService", "RESPONSECODE": "200", "CORRELATION_ID": cid}))
        out.append(_smf(state, 101, None, "DB2 ACCOUNTING", u, {
            "PLAN": "CBSAPLAN", "AUTHID": u, "CORRID": "DSN2CBSA", "STMT": "SELECT CBSA.ACCOUNT",
            "ROWS_EXAMINED": "2", "CORRELATION_ID": cid}))

    elif ttp.id == "sqli_bypass":
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "API": "customersAPI", "METHOD": "GET", "URI": "/customers/' OR '1'='1", "SAFUSER": u,
            "RESPONSECODE": "200", "CORRELATION_ID": cid}))
        # SMF 102 IFCID 145 = SQL statement text, IFCID 144 = first read of table
        out.append(_smf(state, 102, None, "DB2 AUDIT", u, {
            "IFCID": "145", "OBJECT": "CBSA.ACCOUNT", "AUTHID": u, "RESULT_CLASS": "ROWSET_EXPANDED",
            "ROWS_RETURNED": "4", "SQL_TEXT": "SELECT * FROM CBSA.ACCOUNT WHERE CUSTOMER_ID = '' OR '1'='1'",
            "CORRELATION_ID": cid}, result="VIOLATION"))

    elif ttp.id == "sqli_union":
        out.append(_smf(state, 102, None, "DB2 AUDIT", u, {
            "IFCID": "145", "OBJECT": "SYSIBM.SYSTABLES", "AUTHID": u, "RESULT_CLASS": "UNION_METADATA",
            "ROWS_RETURNED": "19", "SQL_TEXT": "... UNION SELECT ... FROM SYSIBM.SYSDUMMY1--",
            "CORRELATION_ID": cid}, result="VIOLATION"))

    elif ttp.id == "sqli_blind":
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "API": "customersAPI", "METHOD": "GET", "URI": "/customers/' AND '1'='2", "SAFUSER": u,
            "RESPONSECODE": "200", "CORRELATION_ID": cid}))
        out.append(_smf(state, 102, None, "DB2 AUDIT", u, {
            "IFCID": "145", "OBJECT": "CBSA.ACCOUNT", "AUTHID": u, "RESULT_CLASS": "BOOLEAN_FALSE",
            "ROWS_RETURNED": "0", "CORRELATION_ID": cid}))

    elif ttp.id == "cics_abuse":
        # SMF 110 subtype 1 = CICS monitoring (performance class)
        out.append(_smf(state, 110, 1, "CICS TRANSACTION", u, {
            "TRAN": "OMEN", "TERM": "(API)", "PROGRAM": "ACCTINQ", "RESPONSE": "NORMAL",
            "CORRELATION_ID": cid}))
        # SMF 80 event 2, qualifier 0 = access permitted (surrogate check passed)
        out.append(_smf(state, 80, 2, "RACROUTE REQUEST=AUTH", u, {
            "EVENTQUAL": "0", "CLASS": "SURROGAT", "RESOURCE": "ZOSCSTC.DFHSTART"}, result="SUCCESS"))

    elif ttp.id == "bulk_exfil":
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "API": "customersAPI", "METHOD": "GET", "URI": "/customers/*", "SAFUSER": u,
            "RESPONSECODE": "200", "VOLUME": "HIGH", "CORRELATION_ID": cid}))
        out.append(_smf(state, 102, None, "DB2 AUDIT", u, {
            "IFCID": "144", "OBJECT": "CBSA.ACCOUNT", "AUTHID": u, "RESULT_CLASS": "BULK_READ",
            "ROWS_RETURNED": "10422", "CORRELATION_ID": cid}, result="VIOLATION"))

    elif ttp.id == "ddf_impact":
        if _vulnerable_mode(state):
            # Mis-privileged service id DOES hold OPERCMDS -> the command succeeds.
            scr.ddf_stopped = True
            out.append(_smf(state, 80, 2, "OPERCMDS AUTH", u, {
                "EVENTQUAL": "0", "CLASS": "OPERCMDS", "RESOURCE": "MVS.STOP.DDF", "COMMAND": "-STOP DDF",
                "NOTE": "service id holds OPERCMDS (mis-privileged)"}, result="SUCCESS"))
            out.append(_smf(state, 90, None, "DDF STOP", u, {
                "PARAM": "DDF", "ACTION": "STOP",
                "RESULT": "DSNL005I DDF IS STOPPED - remote Db2 access down"}, result="SUCCESS"))
        else:
            # Correctly de-privileged service id -> RACF rejects the command (qualifier 1).
            out.append(_smf(state, 80, 2, "OPERCMDS AUTH", u, {
                "EVENTQUAL": "1", "CLASS": "OPERCMDS", "RESOURCE": "MVS.STOP.DDF", "COMMAND": "-STOP DDF",
                "VIOLATION": "1"}, result="REJECTED"))
            out.append(_smf(state, 90, None, "SET PARAM ATTEMPT", u, {
                "PARAM": "DDF", "ACTION": "STOP", "RESULT": "REJECTED"}, result="REJECTED"))

    else:  # tool signatures
        out.append(_smf(state, 123, 2, "API-INVOKE", u, {
            "TOOL": ttp.tool or ttp.id, "URI": "/customers/{id}", "SAFUSER": u,
            "CORRELATION_ID": cid}, result="FAILURE"))
    return out


# --------------------------------------------------------------------------- #
#  Trigger / correlation / alarm  (mirrors HMS)
# --------------------------------------------------------------------------- #
def trigger_ttp(state: Any, ttp_id: str, *, src_ip: str = "", userid: str = "",
                detail: str = "") -> Optional[ScrapiSighting]:
    ttp = _TTP_BY_ID.get(ttp_id)
    if ttp is None:
        return None
    scr = get_scrapi_state(state)
    smf = _gen(state, scr, ttp, src_ip, userid, detail)
    sight = ScrapiSighting(_now(), ttp.id, ttp.attack, ttp.name, src_ip or "203.0.113.44",
                           (userid or "APIUSER").upper(), detail or ttp.procedure, smf)
    scr.sightings.append(sight)
    _evaluate_correlation(state, scr)
    return sight


def seen_ttp_ids(scr: ScrapiState) -> List[str]:
    out: List[str] = []
    for s in scr.sightings:
        if s.ttp_id not in out:
            out.append(s.ttp_id)
    return out


def _evaluate_correlation(state: Any, scr: ScrapiState) -> None:
    distinct = seen_ttp_ids(scr)
    if len(distinct) >= ALARM_THRESHOLD and scr.alarm is None:
        scr.alarm = {
            "ts": _now(), "actor": ACTOR,
            "message": "Potential ScrAPI Bear detected (API-to-mainframe intrusion)",
            "ttps_seen": distinct, "associated_tools": [t.id for t in SCRAPI_TOOLS],
            "count": len(distinct), "delivered": False, "notified": ["KEVIN", "IBMUSER"],
        }
        _smf(state, 80, None, "SCRAPI CORRELATION ALARM", "GSENTRY", {
            "ACTOR": ACTOR, "TTPS": ",".join(distinct), "THRESHOLD": str(ALARM_THRESHOLD),
            "DETAIL": "Potential ScrAPI Bear detected"}, result="VIOLATION")
        _deliver_alarm(state, scr.alarm)


def _deliver_alarm(state: Any, alarm: dict) -> None:
    msg = alarm["message"]
    detail = f"{msg} - {alarm['count']} TTPs: {', '.join(alarm['ttps_seen'])}"
    try:
        state.notify_console(f"*SCB001A {detail}", severity="ALERT")
    except Exception:
        pass
    try:
        state.raise_dashboard_alert(detail, severity="ALERT", event_type="SCRAPI")
    except Exception:
        pass
    delivered_to = []
    for who in ("KEVIN", "IBMUSER"):
        live = False
        try:
            sessions = getattr(state, "sessions", None)
            if sessions is not None:
                live = bool(sessions.notify(who, f"SCRAPI ALERT FROM GIBSON-SENTRY: {msg}"))
        except Exception:
            live = False
        if not live:
            try:
                state.pending_messages.setdefault(who.upper(), []).append(
                    ("GSENTRY", f"SCRAPI ALERT: {msg}"))
            except Exception:
                pass
        delivered_to.append(f"{who}{'(live)' if live else '(queued)'}")
    alarm["delivered"] = True
    alarm["delivery"] = delivered_to


def reset(state: Any) -> None:
    scr = get_scrapi_state(state)
    scr.sightings.clear()
    scr.alarm = None
    scr.auto_fired.clear()
    scr.ddf_stopped = False


def run_scenario(state: Any, *, src_ip: str = "203.0.113.44", userid: str = "APIUSER") -> List[ScrapiSighting]:
    """Fire the full ScrAPI Bear kill chain in order (lab runner)."""
    out = []
    for ttp in SCRAPI_TTPS:
        s = trigger_ttp(state, ttp.id, src_ip=src_ip, userid=userid)
        if s:
            out.append(s)
    return out


# --------------------------------------------------------------------------- #
#  Auto-detection - map organic API/Db2 events to ScrAPI Bear TTPs (fire once)
# --------------------------------------------------------------------------- #
def observe_api_event(state: Any, userid: str, api: str, path: str, result: str,
                      code: int, addr: str = "") -> Optional[str]:
    """Called from zosconnect._invoke: classify an API call and fire a TTP once."""
    scr = get_scrapi_state(state)
    p = (path or "").upper()
    fired: Optional[str] = None
    if code == 403 or (result or "").upper() in ("DENIED", "FAILURE"):
        fired = "saf_denied"
    elif "/ZOSCONNECT/APIS" in p:
        fired = "api_recon"
    elif "UNION" in p:
        fired = "sqli_union"
    elif "OR '1'='1" in p or "OR 1=1" in p:
        fired = "sqli_bypass"
    elif "AND '1'='2" in p or "AND 1=2" in p:
        fired = "sqli_blind"
    elif "'" in p or "--" in p:
        fired = "sqli_probe"
    if fired and fired not in scr.auto_fired:
        scr.auto_fired.add(fired)
        trigger_ttp(state, fired, src_ip=addr or "203.0.113.44",
                    userid=userid or "APIUSER", detail="auto-detected: " + (path or "")[:60])
        return fired
    return None


def observe_sqli(state: Any, customer_input: str, result_class: str, rows: int,
                 correlation_id: str = "", userid: str = "APIUSER") -> Optional[str]:
    """Called from cbsa/vuln_sql.sqli_search after it classifies the result."""
    scr = get_scrapi_state(state)
    rc = (result_class or "").upper()
    fired = {"ROWSET_EXPANDED": "sqli_bypass", "UNION_METADATA": "sqli_union",
             "BOOLEAN_FALSE": "sqli_blind"}.get(rc)
    if fired and fired not in scr.auto_fired:
        scr.auto_fired.add(fired)
        trigger_ttp(state, fired, userid=userid,
                    detail=f"auto-detected: {rc} rows={rows} {correlation_id}")
        return fired
    return None
