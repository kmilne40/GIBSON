"""zSecure ISPF front-end (full-screen 3270).

The interface a zSecure practitioner actually navigates: a primary option menu
(SE Setup, RA RACF, AU Audit, EV Events, RE Resource, CO Commands/CARLa,
CM Compliance) that surfaces Gibson's zSecure engine - the CARLa interpreter,
the CKFREEZE snapshot and the STIG/PCI compliance framework - through panels
instead of only the ``ZSEC`` command line.  The CO panel is an interactive
CARLa editor, so a learner can type ``NEWLIST TYPE=RACF ...`` and see results.
"""
from __future__ import annotations

from typing import List, Optional

from gibson.render import colors
from gibson.render.screen3270 import ScreenBuffer
from gibson.render.panels import PanelInput, PanelSession

_TURQ = getattr(colors, "TURQUOISE", colors.GREEN)
_ZVER = "zSecure Suite 3.1.0"

_MENU = [
    ("SE", "Setup", "Options and input data sets (RACF / SMF / CKFREEZE)"),
    ("RA", "RACF", "RACF administration and privilege reports"),
    ("AU", "Audit", "Status auditing and verification"),
    ("EV", "Events", "SMF and other security events"),
    ("RE", "Resource", "Sensitive data sets, APF, started tasks"),
    ("CO", "Commands", "CARLa command / query editor (CKRCARLA)"),
    ("CM", "Compliance", "STIG / PCI-DSS compliance framework"),
    ("X", "Exit", "Return to ISPF"),
]

_RA_MENU = [
    ("1", "SPECIAL users", "CARLA SPECIAL"),
    ("2", "OPERATIONS users", "CARLA OPERATIONS"),
    ("3", "UID(0) superusers", "CARLA UID0"),
    ("4", "Revoked users", "CARLA REVOKED"),
    ("5", "Groups", 'CARLA "NEWLIST TYPE=GROUP; SORTLIST GROUP(9) SUPGROUP OWNER MEMBERS"'),
]
_RE_MENU = [
    ("1", "Sensitive data sets", "CARLA SENSDSN"),
    ("2", "APF libraries", "CARLA APF"),
    ("3", "Writable APF (finding)", "CARLA APFWRIT"),
    ("4", "Started tasks", "CARLA STC"),
    ("5", "Privileged started tasks", "CARLA STCRISK"),
]

_CARLA_SAMPLE = ["NEWLIST TYPE=RACF",
                 "SELECT SPECIAL",
                 "SORTLIST USERID(8) NAME(20) DFLTGRP OWNER",
                 "", "", ""]


class Zsecure3270Session(PanelSession):
    def __init__(self, state, peer_addr: str = "", userid: str = "IBMUSER"):
        self.state = state
        self.peer_addr = peer_addr or ""
        self.userid = (userid or "IBMUSER").upper()
        self._screen = "MENU"
        self._message = ""
        self._lines: List[str] = []
        self._top = 0
        self._title = ""
        self._submenu: List = []
        self._sub_kind = ""
        self._carla_lines = list(_CARLA_SAMPLE)

    # ---------------------------------------------------------------- API
    def initial_screen(self) -> ScreenBuffer:
        return self._menu_panel()

    def handle(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        s = self._screen
        if s == "MENU":
            return self._handle_menu(pi)
        if s == "REPORT":
            return self._handle_report(pi)
        if s == "SUBMENU":
            return self._handle_submenu(pi)
        if s == "CARLA":
            return self._handle_carla(pi)
        return None

    # --------------------------------------------------------------- MENU
    def _menu_panel(self) -> ScreenBuffer:
        s = ScreenBuffer(); s.extended_attributes = True
        s.put(1, 2, f"{_ZVER}  -  Main menu", colors.BLUE)
        s.put(1, 60, self.userid, colors.GREEN)
        s.put(3, 2, "Option ===>", colors.WHITE)
        s.add_field("OPTION", 3, 14, 30, colour=_TURQ, role="command")
        if self._message:
            s.put(4, 2, self._message[:76], colors.YELLOW)
        s.put(6, 2, "Select an option and press ENTER:", colors.GREEN)
        row = 8
        for code, name, desc in _MENU:
            s.put(row, 5, f"{code:<3} {name:<12} {desc}", colors.TURQUOISE)
            row += 1
        s.put(row + 1, 2, "Input sources: Live RACF ACTIVE | CKFREEZE ACTIVE | SMF ACTIVE", colors.GREEN)
        self._pf(s, "F1=Help  F3=Exit")
        s.set_cursor(3, 14)
        return s

    def _handle_menu(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self._message = ""
        if pi.key in ("PF3", "PF15"):
            return None
        opt = pi.stripped("OPTION").upper()
        if not opt:
            return self._menu_panel()
        if opt in ("X", "EXIT"):
            return None
        from gibson.apps.zsecure_engine import zsecure_command
        if opt == "SE":
            return self._report("Setup - input data sets", zsecure_command(self.state, self.userid, "ZSEC SE"))
        if opt == "AU":
            return self._report("Audit - status audit", zsecure_command(self.state, self.userid, "ZSEC AU"))
        if opt == "EV":
            return self._report("Events - security events", zsecure_command(self.state, self.userid, "ZSEC EVENTS"))
        if opt == "CM":
            return self._report("Compliance - STIG + PCI-DSS", zsecure_command(self.state, self.userid, "ZSEC COMPLIANCE"))
        if opt == "RA":
            return self._open_submenu("RACF administration", _RA_MENU, "RA")
        if opt == "RE":
            return self._open_submenu("Resource reports", _RE_MENU, "RE")
        if opt == "CO":
            self._screen = "CARLA"
            return self._carla_panel()
        self._message = f"INVALID OPTION '{opt}'  (SE RA AU EV RE CO CM X)"
        return self._menu_panel()

    # ------------------------------------------------------------ SUBMENU
    def _open_submenu(self, title: str, menu: List, kind: str) -> ScreenBuffer:
        self._screen = "SUBMENU"
        self._title = title
        self._submenu = menu
        self._sub_kind = kind
        return self._submenu_panel()

    def _submenu_panel(self) -> ScreenBuffer:
        s = ScreenBuffer(); s.extended_attributes = True
        s.put(1, 2, f"{_ZVER}  -  {self._title}", colors.BLUE)
        s.put(3, 2, "Option ===>", colors.WHITE)
        s.add_field("OPTION", 3, 14, 12, colour=_TURQ, role="command")
        if self._message:
            s.put(4, 2, self._message[:76], colors.YELLOW)
        row = 6
        for code, name, _cmd in self._submenu:
            s.put(row, 5, f"{code:<3} {name}", colors.TURQUOISE)
            row += 1
        self._pf(s, "F3=Return")
        s.set_cursor(3, 14)
        return s

    def _handle_submenu(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self._message = ""
        if pi.key in ("PF3", "PF15"):
            self._screen = "MENU"
            return self._menu_panel()
        opt = pi.stripped("OPTION").upper()
        if not opt:
            return self._submenu_panel()
        match = next((c for code, _n, c in self._submenu if code == opt), None)
        if match is None:
            self._message = f"INVALID OPTION '{opt}'"
            return self._submenu_panel()
        from gibson.apps.zsecure_engine import zsecure_command
        name = next((n for code, n, _c in self._submenu if code == opt), opt)
        return self._report(f"{self._title} - {name}",
                            zsecure_command(self.state, self.userid, "ZSEC " + match),
                            back="SUBMENU")

    # ------------------------------------------------------------- REPORT
    def _report(self, title: str, text: str, back: str = "MENU") -> ScreenBuffer:
        self._title = title
        self._lines = (text or "").split("\n")
        self._top = 0
        self._report_back = back
        self._screen = "REPORT"
        return self._report_panel()

    def _report_panel(self) -> ScreenBuffer:
        s = ScreenBuffer(); s.extended_attributes = True
        s.put(1, 2, f"{_ZVER}  -  {self._title}"[:78], colors.BLUE)
        total = len(self._lines)
        s.put(1, 66, f"Row {self._top+1} of {total}", colors.GREEN)
        s.put(2, 2, "Command ===>", colors.WHITE)
        s.add_field("CMD", 2, 15, 40, colour=_TURQ, role="command")
        view = self._lines[self._top:self._top + 19]
        for i, line in enumerate(view):
            s.put(4 + i, 1, line[:79], colors.TURQUOISE)
        self._pf(s, "F3=Return  F7=Up  F8=Down")
        s.set_cursor(2, 15)
        return s

    def _handle_report(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        if pi.key in ("PF3", "PF15"):
            self._screen = getattr(self, "_report_back", "MENU")
            return self._submenu_panel() if self._screen == "SUBMENU" else self._menu_panel()
        if pi.key in ("PF8", "PF20"):
            self._top = min(max(0, len(self._lines) - 19), self._top + 18)
        elif pi.key in ("PF7", "PF19"):
            self._top = max(0, self._top - 18)
        return self._report_panel()

    # -------------------------------------------------------------- CARLA
    def _carla_panel(self) -> ScreenBuffer:
        s = ScreenBuffer(); s.extended_attributes = True
        s.put(1, 2, f"{_ZVER}  -  CO  CARLa command (CKRCARLA)", colors.BLUE)
        s.put(2, 2, "Command ===>", colors.WHITE)
        s.add_field("CMD", 2, 15, 40, colour=_TURQ, role="command")
        s.put(3, 2, "(F1/HELP  FIELDS TYPE=RACF  EXAMPLES  or edit the query below, then ENTER)",
              colors.GREEN)
        s.put(5, 2, "Enter CARLa statements:", colors.WHITE)
        for i in range(6):
            s.put(6 + i, 2, f"{i+1}", colors.BLUE)
            s.add_field(f"C{i}", 6 + i, 5, 72, value=self._carla_lines[i][:72], colour=_TURQ)
        if self._message:
            s.put(13, 2, self._message[:76], colors.YELLOW)
        for i, line in enumerate((self._lines or [])[self._top:self._top + 9]):
            s.put(14 + i, 1, line[:79], colors.TURQUOISE)
        self._pf(s, "F1=Help  F3=Return  F7=Up  F8=Down")
        s.set_cursor(6, 5)
        return s

    def _handle_carla(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self._message = ""
        if pi.key in ("PF3", "PF15"):
            self._screen = "MENU"
            return self._menu_panel()
        from gibson.core.carla import run_carla
        cmd = pi.stripped("CMD").upper()
        if pi.key in ("PF7", "PF19"):
            self._top = max(0, self._top - 8); return self._carla_panel()
        if pi.key in ("PF8", "PF20"):
            self._top = min(max(0, len(self._lines) - 9), self._top + 8); return self._carla_panel()
        if pi.key in ("PF1", "PF13") or cmd in ("HELP", "?"):
            self._lines = run_carla(self.state, "HELP").split("\n"); self._top = 0
            return self._carla_panel()
        if cmd in ("EXAMPLES", "EXAMPLE") or cmd.startswith("FIELDS"):
            self._lines = run_carla(self.state, cmd).split("\n"); self._top = 0
            return self._carla_panel()
        # capture the edited query lines, run them
        self._carla_lines = [pi.stripped(f"C{i}") for i in range(6)]
        source = "\n".join(l for l in self._carla_lines if l.strip())
        if not source:
            self._message = "ENTER A CARLa QUERY (or type HELP / EXAMPLES on the command line)"
            return self._carla_panel()
        self._lines = run_carla(self.state, source).split("\n")
        self._top = 0
        self._message = "CKR00001I CARLA QUERY COMPLETE"
        return self._carla_panel()

    # --------------------------------------------------------------- util
    @staticmethod
    def _pf(s: ScreenBuffer, legend: str) -> None:
        s.put(24, 1, legend[:79], colors.BLUE)
