"""Operation DARVADER - capturable CTF flags across GIBSON's attack surface.

Flags span traditional infrastructure attacks (nmap, hydra, ftp, JES, SURROGAT, APF)
through to the API / SQL-injection path. Every flag is LOCKED with an unlock password
the instructor sets in the dataset ``KEV.PW.TEXT`` - which is RACF-protected so that
only GUEST may read it. To claim a flag a player must:

  1. perform the attack to obtain the flag token (e.g. GIBSON{...}),
  2. read the unlock password from KEV.PW.TEXT (only GUEST can),
  3. submit the flag + password to ``submit_flag``,
  4. send an email to DARVADER (the drop) to finalise the capture.

Everything is defensive (try/except) so seeding can never abort startup. Training
content only; all users, passwords, and data are fictional.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

# The instructor sets the real value in KEV.PW.TEXT; this is the seeded default.
DEFAULT_UNLOCK_PW = "KEVPW26"
PW_DATASET = "KEV.PW.TEXT"
SCORES_DATASET = "GIBSON.CTF.SCORES"   # persistent per-player scoreboard (survives restarts)


@dataclass
class Flag:
    id: str
    category: str
    flag: str
    points: int
    attack: str        # what the player does to obtain the token
    hint: str
    location: str      # where the token is seeded / revealed


# The flag catalogue - one per attack class the book covers.
FLAGS: List[Flag] = [
    Flag("nmap", "Reconnaissance", "GIBSON{n m a p _ f o u n d _ t h e _ d o o r s}".replace(" ", ""), 100,
         "Port-scan GIBSON's listeners and read the service banner that leaks the flag.",
         "Not every open port is boring. Scan them all, then actually talk to the odd one out and read what it says hello with.",
         "TCP service banner on a high listener port"),
    Flag("hydra", "Credential Access", "GIBSON{brute_force_is_loud_but_works}", 150,
         "Brute-force a login (FTP or TSO) with the seeded wordlist; the flag is shown on first success.",
         "GIBSON.WORDLIST is right there. Point your favourite bruteforcer at a login and watch for the one that sticks.",
         "Login banner / MOTD shown on the first successful cracked logon"),
    Flag("ftp", "Exfiltration", "GIBSON{ftp_type_a_and_away_it_goes}", 150,
         "Use FTP to RETR a sensitive dataset; the flag is a record inside it.",
         "The mainframe speaks FTP. Log in, list the datasets you can see, and pull the one that looks too interesting to leave.",
         "A record inside an exfiltrated dataset"),
    Flag("jes", "Execution", "GIBSON{jes_reader_runs_what_you_submit}", 200,
         "Submit a job through the JES internal reader / spool and read the flag from its SYSOUT.",
         "If you can submit JCL, you can run code. Submit a small job and read what comes back on the spool.",
         "SYSOUT of a submitted job"),
    Flag("surrogat", "Privilege / Identity", "GIBSON{surrogat_lets_me_be_someone_else}", 200,
         "Abuse a SURROGAT permission to run work as another user, then read a dataset only they can see.",
         "SURROGAT means 'act as'. Find who you're allowed to become, become them, and open the door that was closed to you.",
         "A dataset readable only by the surrogated identity"),
    Flag("apf", "Privilege Escalation", "GIBSON{apf_writable_equals_game_over}", 250,
         "Exploit the writable APF library to run authorised code and lift privilege.",
         "An APF library you can WRITE to is a skeleton key. D PROG,APF shows the list - find the one with your name on it.",
         "Revealed after an authorised program runs from the writable APF library"),
    Flag("api", "API to Mainframe", "GIBSON{api_sqli_reached_the_mainframe}", 250,
         "SQL-inject the z/OS Connect customers API so the response leaks a flag row from Db2.",
         "The customer lookup builds SQL from your input. Break out of the quotes and the database will hand you rows it shouldn't - one of them is the flag.",
         "A flag row returned by the vulnerable CBSA.ACCOUNT query"),
]
_FLAG_BY_ID = {f.id: f for f in FLAGS}
_FLAG_BY_TOKEN = {f.flag.upper(): f for f in FLAGS}


# --------------------------------------------------------------------------- #
#  State
# --------------------------------------------------------------------------- #
@dataclass
class CtfState:
    captured: Dict[str, str] = field(default_factory=dict)   # flag_id -> userid
    darvader_mail: set = field(default_factory=set)          # userids who mailed DARVADER
    unlock_pw: str = DEFAULT_UNLOCK_PW


def get_ctf_state(state: Any) -> CtfState:
    st = getattr(state, "ctf_flags", None)
    if st is None:
        st = CtfState()
        try:
            state.ctf_flags = st
        except Exception:
            pass
    return st


# --------------------------------------------------------------------------- #
#  Persistent per-player scores (stored in a dataset -> survives restarts)
# --------------------------------------------------------------------------- #
def _load_scores(state: Any) -> Dict[str, Dict[str, str]]:
    """Return {player: {flag_id: iso_timestamp}} from the persistent dataset."""
    try:
        text = state.datasets.read("GIBSON", SCORES_DATASET)
        data = json.loads(text) if text and text.strip() else {}
        if isinstance(data, dict):
            return {str(p).upper(): dict(v) for p, v in data.items() if isinstance(v, dict)}
    except Exception:
        pass
    return {}


def _save_scores(state: Any, scores: Dict[str, Dict[str, str]]) -> None:
    try:
        try:
            state.datasets.allocate("GIBSON", SCORES_DATASET, org="PS")
        except Exception:
            pass
        state.datasets.write("GIBSON", SCORES_DATASET, json.dumps(scores, indent=2))
    except Exception:
        pass


def _record_capture(state: Any, player: str, flag_id: str) -> None:
    scores = _load_scores(state)
    scores.setdefault(player.upper(), {}).setdefault(
        flag_id, datetime.now().replace(microsecond=0).isoformat())
    _save_scores(state, scores)


# --------------------------------------------------------------------------- #
#  Seeding: KEV.PW.TEXT (GUEST-only) + flag tokens in-world
# --------------------------------------------------------------------------- #
def seed_ctf_flags(state: Any, password: Optional[str] = None) -> None:
    """Seed the unlock password into KEV.PW.TEXT, RACF-protect it so only GUEST can
    read it, and place the flag tokens where their attack path reveals them."""
    ctf = get_ctf_state(state)
    pw = (password or DEFAULT_UNLOCK_PW)
    ctf.unlock_pw = pw

    # 1. Write the password dataset (owned by GUEST) ...
    try:
        state.datasets.allocate("GUEST", PW_DATASET, org="PS")
    except Exception:
        pass
    try:
        state.datasets.write("GUEST", PW_DATASET,
                             f"CTF FLAG UNLOCK PASSWORD (KEEP SECRET)\n{pw}\n")
    except Exception:
        pass
    # 2. ... and RACF-protect it: UACC(NONE) + permit only GUEST READ.
    try:
        state.dynamic_racf.define("DATASET", PW_DATASET, "GUEST", "NONE",
                                  warning=False, volume="SBSYS1")
        state.dynamic_racf.permit("DATASET", PW_DATASET, "GUEST", "READ", save=False)
    except Exception:
        pass

    # 3. Seed the flag tokens into their in-world locations (best-effort).
    try:
        _seed_tokens(state)
    except Exception:
        pass


def _seed_tokens(state: Any) -> None:
    """Place each flag token where its attack reveals it (defensive/best-effort)."""
    # surrogat: flag inside a dataset only SYSPROG can read
    try:
        state.datasets.allocate("SYSPROG", "SYSPROG.SECRET.TEXT", org="PS")
    except Exception:
        pass
    try:
        state.datasets.write("SYSPROG", "SYSPROG.SECRET.TEXT",
                             f"IF YOU CAN READ THIS YOU BECAME SOMEONE ELSE.\n{_FLAG_BY_ID['surrogat'].flag}\n")
    except Exception:
        pass
    try:
        state.dynamic_racf.define("DATASET", "SYSPROG.SECRET.TEXT", "SYSPROG", "NONE", volume="SBSYS1")
    except Exception:
        pass
    # ftp: flag inside a sensitive dataset that can be RETR'd
    try:
        state.datasets.allocate("IBMUSER", "IBMUSER.PAYROLL.DATA", org="PS")
    except Exception:
        pass
    try:
        state.datasets.write("IBMUSER", "IBMUSER.PAYROLL.DATA",
                             f"EMP001 J WILLIAMS 51000\nEMP002 A CHEN 42250\n{_FLAG_BY_ID['ftp'].flag}\n")
    except Exception:
        pass
    # api: flag as a Db2 row the SQLi mass-disclosure returns
    try:
        from gibson.apps.cbsa.store import get_cbsa_store
        store = get_cbsa_store(state)
        store.seed()
        class _FlagAcct:
            customer_id = "FLAG"
            def row(self):
                return {"ACCOUNT_NUMBER": "00000199", "CUSTOMER_ID": "FLAG",
                        "ACCOUNT_TYPE": _FLAG_BY_ID["api"].flag}
        store.accounts["00000199"] = _FlagAcct()
    except Exception:
        pass


# --------------------------------------------------------------------------- #
#  Password: GUEST-only read
# --------------------------------------------------------------------------- #
def read_unlock_password(state: Any, userid: str) -> Optional[str]:
    """Read the unlock password from KEV.PW.TEXT *as* userid, enforcing that only
    GUEST is permitted. Returns None if the user is not authorised."""
    try:
        dec = state.dynamic_racf.access_decision("DATASET", PW_DATASET, userid, "READ",
                                                 users_repo=getattr(state, "racf", None))
        if not getattr(dec, "allowed", False):
            return None
    except Exception:
        pass
    try:
        text = state.datasets.read(userid, PW_DATASET)
        for line in text.splitlines():
            line = line.strip()
            if line and "PASSWORD" not in line.upper():
                return line
    except Exception:
        return None
    return None


def can_read_password(state: Any, userid: str) -> bool:
    try:
        dec = state.dynamic_racf.access_decision("DATASET", PW_DATASET, userid, "READ",
                                                 users_repo=getattr(state, "racf", None))
        return bool(getattr(dec, "allowed", False))
    except Exception:
        return False


# --------------------------------------------------------------------------- #
#  DARVADER email (the drop)
# --------------------------------------------------------------------------- #
def send_to_darvader(state: Any, userid: str, subject: str = "", body: str = "") -> bool:
    """Deliver an email to DARVADER (the CTF drop) and record the sender. Works via
    the real mail store if present, and always records the send for flag finalising."""
    ctf = get_ctf_state(state)
    ctf.darvader_mail.add(userid.upper())
    delivered = False
    try:
        from gibson.apps.mail3270.mail_store import MailStore, Message
        ms = MailStore(state, userid)
        msg = Message(frm=userid.upper(), to="DARVADER",
                      subj=subject or "CTF flag capture", body=(body or "").splitlines() or ["captured"])
        delivered = bool(ms.deliver_internal("DARVADER", msg))
    except Exception:
        delivered = False
    if not delivered:
        try:
            state.pending_messages.setdefault("DARVADER", []).append(
                (userid.upper(), subject or "CTF flag capture"))
            delivered = True
        except Exception:
            pass
    return delivered


def emailed_darvader(state: Any, userid: str) -> bool:
    u = userid.upper()
    ctf = get_ctf_state(state)
    if u in ctf.darvader_mail:
        return True
    # also honour a message dropped via the real mail app / pending queue
    try:
        for sender, _ in getattr(state, "pending_messages", {}).get("DARVADER", []):
            if str(sender).upper() == u:
                return True
    except Exception:
        pass
    try:
        text = state.datasets.read("DARVADER", "DARVADER.MAIL.IN")
        if u in text.upper():
            return True
    except Exception:
        pass
    return False


# --------------------------------------------------------------------------- #
#  Submit / score
# --------------------------------------------------------------------------- #
def submit_flag(state: Any, userid: str, flag_value: str, password: str) -> Dict[str, Any]:
    """Validate a flag capture. Requires: a real flag token, the correct unlock
    password (matching KEV.PW.TEXT), and an email already sent to DARVADER."""
    ctf = get_ctf_state(state)
    token = (flag_value or "").strip().upper()
    flag = _FLAG_BY_TOKEN.get(token)
    if flag is None:
        return {"ok": False, "reason": "UNKNOWN_FLAG",
                "message": "That is not a valid flag token."}
    if (password or "").strip() != ctf.unlock_pw:
        return {"ok": False, "reason": "BAD_PASSWORD",
                "message": "Wrong unlock password. Read it from KEV.PW.TEXT (only GUEST can)."}
    if not emailed_darvader(state, userid):
        return {"ok": False, "reason": "NO_DARVADER_MAIL",
                "message": "Send your capture email to DARVADER first, then resubmit."}
    already = flag.id in ctf.captured
    ctf.captured[flag.id] = userid.upper()
    _record_capture(state, userid, flag.id)   # durable per-player record (survives restarts)
    return {"ok": True, "flag_id": flag.id, "category": flag.category, "points": flag.points,
            "already_captured": already,
            "message": f"Flag captured: {flag.category} (+{flag.points}). Reported to DARVADER."}


def get_hint(flag_id: str) -> Optional[str]:
    f = _FLAG_BY_ID.get(flag_id.lower())
    return f.hint if f else None


def scoreboard(state: Any, player: Optional[str] = None) -> Dict[str, Any]:
    """Scoreboard from the persistent store. With `player`, returns that player's
    view; otherwise a global summary (any flag captured by anyone)."""
    scores = _load_scores(state)
    total = sum(f.points for f in FLAGS)
    if player:
        pflags = set(scores.get(player.upper(), {}))
        won = sum(_FLAG_BY_ID[fid].points for fid in pflags if fid in _FLAG_BY_ID)
        captured = {fid: player.upper() for fid in pflags}
    else:
        captured = {}
        for p, flags in scores.items():
            for fid in flags:
                captured.setdefault(fid, p)
        won = sum(_FLAG_BY_ID[fid].points for fid in captured if fid in _FLAG_BY_ID)
    return {
        "captured": captured,
        "count": len(captured),
        "total_flags": len(FLAGS),
        "points": won,
        "max_points": total,
        "remaining": [f.id for f in FLAGS if f.id not in captured],
    }


def leaderboard(state: Any) -> List[Dict[str, Any]]:
    """Ranked per-player leaderboard from the persistent store."""
    scores = _load_scores(state)
    rows = []
    for p, flags in scores.items():
        pts = sum(_FLAG_BY_ID[fid].points for fid in flags if fid in _FLAG_BY_ID)
        last = max(flags.values()) if flags else ""
        rows.append({"player": p, "points": pts, "count": len(flags),
                     "flags": sorted(flags), "last": last})
    # rank: most points, then most flags, then finished earliest
    rows.sort(key=lambda r: (-r["points"], -r["count"], r["last"] or "9999"))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return rows


def list_flags(include_tokens: bool = False) -> List[dict]:
    out = []
    for f in FLAGS:
        d = {"id": f.id, "category": f.category, "points": f.points,
             "attack": f.attack, "hint": f.hint, "location": f.location}
        if include_tokens:
            d["flag"] = f.flag
        out.append(d)
    return out
