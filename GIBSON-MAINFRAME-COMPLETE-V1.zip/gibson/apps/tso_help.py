"""Authentic z/OS TSO HELP facility for Gibson.

Reproduces the real SYS1.HELP member format shown by the TSO/E HELP command:

    Function -
      <description>

    Syntax -
          CMD    operand
                 operand ...
      Required - ...
      Defaults - ...

    Operands -
      operand - description
      ...

Supports the keyword operands the real HELP command accepts to limit output:
HELP cmd FUNCTION | SYNTAX | OPERANDS | OPERANDS(keyword).

This module deliberately does NOT touch the '?' completion facility - that is a
separate feature (autocomplete.py) and must keep returning command lists.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class HelpMember:
    function: str                              # prose description
    syntax: List[str]                          # lines rendered under "Syntax -"
    operands: List[Tuple[str, str]] = field(default_factory=list)
    required: str = "NONE"
    defaults: str = "NONE"
    aliases: str = ""


# --------------------------------------------------------------------------- #
# helpers for laying out the SYNTAX block the way real HELP members do
# --------------------------------------------------------------------------- #
def _syntax(cmd: str, operands: List[str]) -> List[str]:
    """Lay out a command and its operands: command at col 8, first operand at
    col 18, continuation operands aligned under the first."""
    lines: List[str] = []
    pad = " " * 18
    if not operands:
        lines.append(f"        {cmd}")
        return lines
    lines.append(f"        {cmd:<9} {operands[0]}")
    for op in operands[1:]:
        lines.append(f"{pad}{op}")
    return lines


def _wrap(text: str, width: int = 66, indent: str = "  ") -> List[str]:
    out, line = [], indent
    for word in text.split():
        if len(line) + len(word) + 1 > width and line.strip():
            out.append(line.rstrip())
            line = indent
        line += word + " "
    if line.strip():
        out.append(line.rstrip())
    return out


# --------------------------------------------------------------------------- #
# member store
# --------------------------------------------------------------------------- #
MEMBERS: Dict[str, HelpMember] = {
    "LISTCAT": HelpMember(
        function="The LISTCAT command lists entries from either the master catalog or a user catalog.",
        syntax=_syntax("LISTCAT", [
            "CATALOG('catname/password')",
            "LIBRARY('lib_name')",
            "FILE('dname')",
            "OUTFILE('dname')",
            "LEVEL('level')",
            "  (NOCDILVL | CDILVL) |",
            "ENTRIES('entryname/password' ...) |",
            "LIBRARYENTRIES('library_entryname') |",
            "VOLUMEENTRIES('volume_entryname')",
            "CREATION('nnnn')",
            "EXPIRATION('nnnn')",
            "NOTUSABLE",
            "CLUSTER  DATA  INDEX  ALIAS  SPACE  NONVSAM",
            "  USERCATALOG  GENERATIONDATAGROUP  PAGESPACE",
            "  ALTERNATEINDEX  PATH",
            "ALL | NAME | HISTORY | VOLUME | ALLOCATION",
        ]),
        required="NONE",
        defaults="NAME",
        operands=[
            ("ENTRIES", "specifies the names of the entries to be listed."),
            ("LEVEL", "specifies that all entries at the given level of qualification are to be listed."),
            ("ALL", "specifies that all fields for each entry are to be listed."),
            ("NAME", "specifies that only the name and type of each entry are to be listed."),
        ],
    ),
    "LISTDS": HelpMember(
        function="The LISTDS command lists the attributes of a data set: the volume, "
                 "DCB attributes, allocation, and, optionally, the member names or catalog history.",
        syntax=_syntax("LISTDS", [
            "'data-set-list'",
            "STATUS  HISTORY  MEMBERS  LABEL",
            "CATALOG  DIRECTORY  LEVEL",
        ]),
        required="'data-set-list'",
        defaults="STATUS",
        operands=[
            ("STATUS", "lists the volume, device type and disposition of the data set."),
            ("HISTORY", "lists the creation date, expiration date and dsorg."),
            ("MEMBERS", "lists the members of a partitioned data set."),
            ("LABEL", "lists the entire data set label."),
        ],
    ),
    "ALLOCATE": HelpMember(
        function="The ALLOCATE command dynamically allocates a data set to your TSO/E "
                 "session, either by name or as a new data set with the attributes you specify.",
        syntax=_syntax("ALLOCATE", [
            "DATASET('dsname' | *)  |  DSNAME(...)",
            "FILE(ddname) | DDNAME(ddname)",
            "NEW | OLD | SHR | MOD",
            "CATALOG | KEEP | DELETE",
            "SPACE(prim,sec) TRACKS | CYLINDERS | BLOCK(n)",
            "DIR(n) LRECL(n) RECFM(f b) BLKSIZE(n)",
            "LIKE('model-dsname')",
        ]),
        required="DATASET or FILE",
        defaults="NEW disposition assumes CATALOG",
        operands=[
            ("DATASET", "names the data set to allocate; * means the terminal."),
            ("FILE", "the ddname the program will use to reference the data set."),
            ("NEW|OLD|SHR|MOD", "the status/disposition of the data set."),
            ("SPACE", "primary and secondary space for a new data set."),
        ],
        aliases="ALLOC",
    ),
    "FREE": HelpMember(
        function="The FREE command releases (deallocates) data sets or attribute lists "
                 "that are currently allocated to your session.",
        syntax=_syntax("FREE", ["DATASET('dsname-list') | FILE(ddname-list) | ALL",
                                 "ATTRLIST(name-list)"]),
        required="DATASET, FILE, ATTRLIST or ALL",
        defaults="NONE",
        aliases="UNALLOC",
    ),
    "ALTLIB": HelpMember(
        function="The ALTLIB command controls the application-level libraries that are "
                 "searched for implicitly-invoked CLISTs and REXX execs, in addition to "
                 "the system libraries (SYSPROC, SYSEXEC). You can activate, deactivate, "
                 "reset, or display the CLIST/EXEC search order for your session.",
        syntax=_syntax("ALTLIB", [
            "ACTIVATE | DEACTIVATE | RESET | DISPLAY",
            "APPLICATION(CLIST | EXEC)",
            "SYSTEM(CLIST | EXEC)",
            "USER(CLIST | EXEC)",
            "DATASET(dsname) | DDNAME(ddname)",
            "QUIET",
        ]),
        required="a function (ACTIVATE/DEACTIVATE/RESET/DISPLAY)",
        defaults="NONE",
        operands=[
            ("ACTIVATE", "adds a library to the front of the CLIST or EXEC search order."),
            ("DEACTIVATE", "removes a previously activated application-level library."),
            ("RESET", "restores the search order to the system libraries only."),
            ("DISPLAY", "shows the current CLIST and EXEC search order."),
            ("APPLICATION", "specifies the CLIST or EXEC application-level library type."),
            ("DATASET", "the data set to add to the search order."),
        ],
    ),
    "ALTUSER": HelpMember(
        function="The ALTUSER command changes a user's profile in the RACF data base, "
                 "including password, attributes, and segment information such as TSO and OMVS.",
        syntax=_syntax("ALTUSER", [
            "userid",
            "PASSWORD(password) | NOPASSWORD",
            "REVOKE | RESUME",
            "SPECIAL | NOSPECIAL   OPERATIONS | NOOPERATIONS",
            "AUDITOR | NOAUDITOR   ROAUDIT | NOROAUDIT",
            "DFLTGRP(group)  OWNER(userid|group)",
            "TSO(...) | NOTSO      OMVS(...) | NOOMVS",
            "DFP(...) | NODFP      MFA(...) | NOMFA",
        ]),
        required="userid",
        defaults="NONE",
        operands=[
            ("PASSWORD", "assigns a new password (marked expired unless NOEXPIRED)."),
            ("REVOKE|RESUME", "prevents or restores the user's ability to log on."),
            ("SPECIAL", "gives the user the system-wide SPECIAL attribute."),
            ("DFLTGRP", "changes the user's default connect group."),
            ("OMVS", "alters the z/OS UNIX segment (UID, HOME, PROGRAM)."),
        ],
        aliases="ALU",
    ),
    "ADDUSER": HelpMember(
        function="The ADDUSER command defines a new user to RACF, creating a user profile "
                 "and connecting the user to a default group.",
        syntax=_syntax("ADDUSER", [
            "userid",
            "PASSWORD(password)  NAME('user name')",
            "DFLTGRP(group)  OWNER(userid|group)",
            "SPECIAL  OPERATIONS  AUDITOR",
            "TSO(...)  OMVS(...)",
        ]),
        required="userid",
        defaults="password defaults to the default group name",
        aliases="AU",
    ),
    "DELUSER": HelpMember(
        function="The DELUSER command removes a user profile from the RACF data base and "
                 "deletes the user's connections to groups.",
        syntax=_syntax("DELUSER", ["userid"]),
        required="userid",
        defaults="NONE",
    ),
    "LISTUSER": HelpMember(
        function="The LISTUSER command displays the contents of a RACF user profile, "
                 "including attributes, group connections, and segment data.",
        syntax=_syntax("LISTUSER", ["userid | *", "TSO  OMVS  DFP  CICS  WORKATTR", "NORACF"]),
        required="NONE",
        defaults="the issuing user's own profile",
        operands=[
            ("userid", "the user profile to list; * lists your own profile."),
            ("TSO|OMVS", "list only the named segment."),
        ],
        aliases="LU",
    ),
    "PERMIT": HelpMember(
        function="The PERMIT command maintains the access list of a resource profile, "
                 "granting or removing access authority for users and groups.",
        syntax=_syntax("PERMIT", [
            "profile-name",
            "CLASS(classname)",
            "ID(name ...)  ACCESS(access-level) | DELETE",
            "RESET  FROM(profile)  WHEN(...)",
        ]),
        required="profile-name",
        defaults="CLASS(DATASET)  ACCESS(READ)",
        operands=[
            ("ID", "the users or groups whose access is being changed."),
            ("ACCESS", "the access level: NONE, EXECUTE, READ, UPDATE, CONTROL or ALTER."),
            ("DELETE", "removes the named ids from the access list."),
        ],
        aliases="PE",
    ),
    "SEARCH": HelpMember(
        function="The SEARCH command (RACF) locates and lists the names of RACF profiles "
                 "in a class that match the criteria you specify.",
        syntax=_syntax("SEARCH", ["CLASS(classname)", "MASK(char1,char2) | FILTER(filter)",
                                  "USER(userid) | WARNING | LEVEL(n)", "CLIST(...)"]),
        required="NONE",
        defaults="CLASS(DATASET)",
        aliases="SR",
    ),
    "SETROPTS": HelpMember(
        function="The SETROPTS command sets system-wide RACF options: password rules, "
                 "class activation, auditing, protection defaults and in-storage refresh.",
        syntax=_syntax("SETROPTS", [
            "LIST",
            "PASSWORD(HISTORY(n) REVOKE(n) INTERVAL(n) WARNING(n) MINCHANGE(n) RULEn(...))",
            "CLASSACT(class ...)  RACLIST(class ...)  REFRESH",
            "AUDIT(class ...)  LOGOPTIONS(...)  SAUDIT  OPERAUDIT",
            "GENERIC(class ...)  GENCMD(class ...)",
        ]),
        required="NONE",
        defaults="NONE",
        operands=[
            ("LIST", "displays the current system-wide RACF options."),
            ("PASSWORD", "sets the password rules (history, interval, revoke, rules)."),
            ("CLASSACT", "activates one or more resource classes."),
            ("RACLIST ... REFRESH", "refreshes the in-storage profiles for a class."),
        ],
    ),
    "RLIST": HelpMember(
        function="The RLIST command lists the contents of general resource profiles in a "
                 "class other than DATASET.",
        syntax=_syntax("RLIST", ["classname profile-name", "AUTHUSER  ALL  RESGROUP"]),
        required="classname and profile-name",
        defaults="NONE",
        aliases="RL",
    ),
    "DELETE": HelpMember(
        function="The DELETE command deletes data sets and members and removes their "
                 "catalog entries.",
        syntax=_syntax("DELETE", ["'data-set-list'", "PURGE | NOPURGE", "CLUSTER | ALIAS | GDG"]),
        required="'data-set-list'",
        defaults="NOPURGE",
        aliases="DEL",
    ),
    "RENAME": HelpMember(
        function="The RENAME command changes the name of a non-VSAM data set or a member "
                 "of a partitioned data set, and its catalog entry.",
        syntax=_syntax("RENAME", ["'old-name' 'new-name'", "ALIAS | NOALIAS"]),
        required="old-name and new-name",
        defaults="NOALIAS",
        aliases="REN",
    ),
    "PROFILE": HelpMember(
        function="The PROFILE command establishes, changes, or lists the characteristics "
                 "of your user profile, such as prefix, prompting and message handling.",
        syntax=_syntax("PROFILE", ["PREFIX(qualifier) | NOPREFIX", "PROMPT | NOPROMPT",
                                   "INTERCOM | NOINTERCOM", "MSGID | NOMSGID", "LIST"]),
        required="NONE",
        defaults="lists the current profile when no operand is given",
        aliases="PROF",
    ),
    "SEND": HelpMember(
        function="The SEND command sends a message to another user or to the operator. "
                 "The message is delivered immediately if the user is logged on.",
        syntax=_syntax("SEND", ["'message'", "USER(userid ...) | OPERATOR(n)",
                                "NOW | LOGON | SAVE"]),
        required="'message'",
        defaults="NOW",
        aliases="SE",
    ),
    "SUBMIT": HelpMember(
        function="The SUBMIT command submits one or more data sets containing JCL for "
                 "background (batch) processing.",
        syntax=_syntax("SUBMIT", ["'data-set-list' | *", "END(char)  PAUSE  NOPAUSE"]),
        required="'data-set-list' or *",
        defaults="NONE",
        aliases="SUB",
    ),
    "STATUS": HelpMember(
        function="The STATUS command displays the status (awaiting execution, executing, "
                 "or on the output queue) of jobs you have submitted.",
        syntax=_syntax("STATUS", ["jobname(jobid) ..."]),
        required="NONE",
        defaults="all of your jobs",
        aliases="ST",
    ),
    "LOGON": HelpMember(
        function="The LOGON command identifies you to the system and starts your TSO/E "
                 "session under the terminal monitor program.",
        syntax=_syntax("LOGON", ["userid/password", "ACCT(account)  PROC(procname)",
                                 "SIZE(n)  RECONNECT  NOMAIL  NONOTICE"]),
        required="userid",
        defaults="the installation-defined logon procedure",
    ),
    "LOGOFF": HelpMember(
        function="The LOGOFF command ends your TSO/E session and frees the resources "
                 "allocated to your address space.",
        syntax=_syntax("LOGOFF", []),
        required="NONE",
        defaults="NONE",
    ),
    "TIME": HelpMember(
        function="The TIME command displays the current time of day, the date, and the "
                 "amount of CPU time and service units used in your session.",
        syntax=_syntax("TIME", []),
        required="NONE",
        defaults="NONE",
    ),
    "EXEC": HelpMember(
        function="The EXEC command explicitly invokes a CLIST or REXX exec contained in a "
                 "data set, passing it any parameters you supply.",
        syntax=_syntax("EXEC", ["'data-set-name(member)' | %member", "'parameters'",
                                "LIST  NOLIST  EXEC  CLIST  PROMPT"]),
        required="a data set name or %member",
        defaults="NONE",
        aliases="EX",
    ),
    "PRINTDS": HelpMember(
        function="The PRINTDS command prints a data set or selected members on a "
                 "system printer or writes them to the output queue.",
        syntax=_syntax("PRINTDS", ["DATASET('dsname') | DSNAME(...)", "MEMBERS(name ...)",
                                   "SYSOUT(class)  DEST(dest)  COPIES(n)  FORMS(form)"]),
        required="DATASET",
        defaults="SYSOUT default class",
        aliases="PR",
    ),
    "TRANSMIT": HelpMember(
        function="The TRANSMIT command sends data sets or messages to a user at your node "
                 "or another network node.",
        syntax=_syntax("TRANSMIT", ["node.userid", "DATASET('dsname') | FILE(ddname) | MESSAGE",
                                    "MEMBERS(name ...)  SEQ  NOLOG"]),
        required="node.userid",
        defaults="NONE",
        aliases="XMIT",
    ),
    "RECEIVE": HelpMember(
        function="The RECEIVE command retrieves data sets and messages that were sent to "
                 "you with the TRANSMIT command.",
        syntax=_syntax("RECEIVE", ["INDATASET('dsname') | INFILE(ddname)", "operands supplied at the prompt"]),
        required="NONE",
        defaults="your reader queue",
        aliases="RECEIVE",
    ),
}

# aliases -> canonical member name
ALIAS_INDEX: Dict[str, str] = {}
for _name, _m in MEMBERS.items():
    for _a in (_m.aliases or "").replace(",", " ").split():
        ALIAS_INDEX[_a.upper()] = _name


# --------------------------------------------------------------------------- #
# top-level HELP (no operand) - the real HELP command lists the command set
# --------------------------------------------------------------------------- #
_TOP_GROUPS = [
    ("DATA SET COMMANDS",
     ["ALLOCATE", "ALTLIB", "ATTRIB", "DELETE", "FREE", "LISTALC", "LISTCAT",
      "LISTDS", "PRINTDS", "PROTECT", "RENAME"]),
    ("SESSION COMMANDS",
     ["EXEC", "LOGON", "LOGOFF", "PROFILE", "STATUS", "SUBMIT", "TERMINAL",
      "TIME", "WHEN"]),
    ("COMMUNICATION",
     ["LISTBC", "RECEIVE", "SEND", "TRANSMIT"]),
    ("SECURITY (RACF)",
     ["ADDUSER", "ALTUSER", "DELUSER", "LISTUSER", "PERMIT", "RLIST",
      "SEARCH", "SETROPTS"]),
]


def _top_level_help() -> str:
    out = ["", "Function -",
           "  The HELP command displays information about the commands available",
           "  in the TSO/E environment.  Enter  HELP  followed by a command name",
           "  for a description of that command, for example  HELP LISTCAT.", ""]
    out.append("Syntax -")
    out.append("        HELP      command-name")
    out.append("                  FUNCTION | SYNTAX | OPERANDS | OPERANDS(keyword)")
    out.append("")
    out.append("Commands -")
    for title, cmds in _TOP_GROUPS:
        out.append(f"  {title}")
        # three per line
        row = []
        for c in cmds:
            row.append(f"{c:<11}")
            if len(row) == 4:
                out.append("    " + "".join(row).rstrip()); row = []
        if row:
            out.append("    " + "".join(row).rstrip())
        out.append("")
    out.append("Enter  HELP command-name  for details on a specific command.")
    return "\n".join(out)


# --------------------------------------------------------------------------- #
# renderer
# --------------------------------------------------------------------------- #
def _render_member(name: str, m: HelpMember, section: Optional[str],
                   operand_kw: Optional[str]) -> str:
    sec = (section or "").upper()

    def function_block() -> List[str]:
        return ["", "Function -"] + _wrap(m.function)

    def syntax_block() -> List[str]:
        b = ["", "Syntax -"] + list(m.syntax)
        b.append(f"  Required - {m.required}")
        b.append(f"  Defaults - {m.defaults}")
        return b

    def operands_block() -> List[str]:
        if not m.operands:
            return ["", "Operands -", "  None."]
        b = ["", "Operands -"]
        rows = m.operands
        if operand_kw:
            rows = [(n, d) for (n, d) in m.operands if n.upper() == operand_kw.upper()]
            if not rows:
                return ["", f"  Keyword {operand_kw} is not a documented operand of {name}."]
        for n, d in rows:
            wrapped = _wrap(d, width=64, indent="")
            b.append(f"  {n} - {wrapped[0]}")
            for extra in wrapped[1:]:
                b.append(f"      {extra}")
        return b

    def aliases_block() -> List[str]:
        return ["", "Aliases -", f"  {m.aliases}"] if m.aliases else []

    if sec == "FUNCTION":
        body = function_block()
    elif sec == "SYNTAX":
        body = syntax_block()
    elif sec == "OPERANDS":
        body = operands_block()
    else:
        body = function_block() + syntax_block() + operands_block() + aliases_block()
    return "\n".join(body)


def help_output(argument: str = "") -> Optional[str]:
    """Return realistic z/OS HELP text, or None if this isn't a HELP request we
    own (so the caller can fall through). `argument` is everything after HELP."""
    arg = (argument or "").strip()
    if not arg:
        return _top_level_help()

    # Parse:  cmd [FUNCTION|SYNTAX|OPERANDS|OPERANDS(kw)]
    tokens = arg.split()
    cmd = tokens[0].upper()
    section = None
    operand_kw = None
    for t in tokens[1:]:
        tu = t.upper()
        if tu.startswith("OPERANDS(") and tu.endswith(")"):
            section = "OPERANDS"
            operand_kw = tu[len("OPERANDS("):-1]
        elif tu in ("FUNCTION", "FUNCTIO", "SYNTAX", "OPERANDS", "ALL"):
            section = "SYNTAX" if tu == "SYNTAX" else ("OPERANDS" if tu == "OPERANDS" else ("FUNCTION" if tu.startswith("FUNCTIO") else None))

    canonical = cmd if cmd in MEMBERS else ALIAS_INDEX.get(cmd)
    if not canonical:
        return None  # not one of our documented commands; caller decides
    return _render_member(canonical, MEMBERS[canonical], section, operand_kw)
