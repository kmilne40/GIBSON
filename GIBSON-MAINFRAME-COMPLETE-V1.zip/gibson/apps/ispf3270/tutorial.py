"""ISPF Program Development Facility Tutorial - content tree for Gibson.

Reached with F1 from any ISPF panel. Navigable like the real ISPF tutorial:
enter a selection code in the option field to descend, F3 to back up, F7/F8 to
scroll. Each node has a title, body lines, and an optional selection menu.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

# node id -> (title, body_lines, menu[(code, target_id, label)])
Node = Tuple[str, List[str], List[Tuple[str, str, str]]]

TOPICS: Dict[str, Node] = {
    "TUTOR": (
        "TUTORIAL ------------------ ISPF Program Development Facility ------------------",
        [
            "The following topics are presented in sequence, or may be selected by",
            "entering a selection code in the option field:",
        ],
        [
            ("G", "GENERAL", "General    - General information about ISPF"),
            ("0", "SETTINGS", "Settings  - Specify terminal and user parameters"),
            ("1", "VIEW", "View      - Display source data or output listings"),
            ("2", "EDIT", "Edit      - Create or change source data"),
            ("3", "UTIL", "Utilities - Perform utility functions"),
            ("4", "FORE", "Foreground- Invoke language processors in foreground"),
            ("6", "CMD", "Command   - Enter TSO command, CLIST, or REXX exec"),
            ("R", "RACF", "RACF      - Security administration panels"),
            ("A", "APPX", "Appendices- Dynamic allocation errors and listing formats"),
            ("I", "INDEX", "Index     - Alphabetical index of tutorial topics"),
            ("X", "EXIT", "Exit      - Terminate the tutorial"),
        ],
    ),
    "GENERAL": (
        "TUTORIAL -------------------------- General ----------------------------------",
        [
            "ISPF (Interactive System Productivity Facility) provides a full-screen",
            "panel interface to the services of TSO/E on z/OS.  From the primary",
            "option menu you can edit and browse data sets, run utilities, submit",
            "foreground and batch language processors, issue TSO commands, and reach",
            "the security administration (RACF) panels.",
            "",
            "Panels are driven from the OPTION or COMMAND field near the top of the",
            "screen.  Type a selection code and press ENTER to proceed.  The function",
            "keys along the bottom of each panel provide navigation:",
            "",
            "   F1  Help        F2  Split        F3  Exit / End",
            "   F7  Backward     F8  Forward      F9  Swap",
            "   F10 Actions      F12 Cancel",
            "",
            "You can jump directly to any primary option by typing '=' followed by the",
            "option number in the command field (for example  =3.4  for the data set",
            "list utility) from any panel.",
        ],
        [],
    ),
    "SETTINGS": (
        "TUTORIAL -------------------------- Settings ---------------------------------",
        [
            "The Settings panel (option 0) controls terminal and user parameters:",
            "",
            "   Command delimiter  - the character that separates stacked commands.",
            "   Screen format      - DATA, STD or MAX display density.",
            "   Terminal type      - 3278, 3279 and related model characteristics.",
            "   Log / List         - disposition of the ISPF log and list data sets.",
            "",
            "Changes take effect immediately and persist for the remainder of your",
            "ISPF session.  Panel and command settings are stored in your ISPF profile.",
        ],
        [],
    ),
    "VIEW": (
        "TUTORIAL ---------------------------- View -----------------------------------",
        [
            "View (option 1) and Browse display the contents of a data set without",
            "allowing changes to be saved.  You can scroll with F7/F8 (up/down) and",
            "F10/F11 (left/right), locate a string with the FIND (F5) command, and",
            "leave with F3.  View is the safe way to inspect source, listings and",
            "control data before editing.",
        ],
        [],
    ),
    "EDIT": (
        "TUTORIAL ---------------------------- Edit -----------------------------------",
        [
            "Edit (option 2) creates or changes the records of a sequential data set",
            "or a member of a partitioned data set.  The line-command area on the left",
            "accepts commands such as:",
            "",
            "   I  insert a line          D  delete a line",
            "   C  copy a line            M  move a line",
            "   R  repeat a line          X  exclude a line from the display",
            "",
            "Primary commands are entered in the COMMAND field, for example:",
            "",
            "   FIND  string      CHANGE old new      SAVE      CANCEL",
            "",
            "F3 saves and exits; CANCEL leaves without saving.",
        ],
        [],
    ),
    "UTIL": (
        "TUTORIAL ------------------------- Utilities ---------------------------------",
        [
            "The Utilities menu (option 3) performs common data set operations:",
            "",
            "   3.1 Library     - compress, print, rename or delete PDS members.",
            "   3.2 Data Set    - allocate, rename, delete or catalog a data set.",
            "   3.4 Dslist      - list data sets by name pattern and act on them.",
            "",
            "Enter the utility number in the option field, or jump directly with",
            "=3.4 from any panel.",
        ],
        [],
    ),
    "FORE": (
        "TUTORIAL ------------------------- Foreground --------------------------------",
        [
            "Foreground (option 4) invokes language processors interactively:",
            "assemblers, compilers and the linkage editor run under your TSO session",
            "and return their listings to the terminal.  Batch (option 5) submits the",
            "same processors as background jobs through the JES2 internal reader.",
        ],
        [],
    ),
    "CMD": (
        "TUTORIAL -------------------------- Command ----------------------------------",
        [
            "Command (option 6) lets you enter a TSO command, CLIST or REXX exec",
            "directly.  The command runs under your TSO session and its output is",
            "displayed in a scrollable list.  This is equivalent to typing the command",
            "at the READY prompt.  Useful commands include:",
            "",
            "   LISTCAT      LISTDS 'dsname'     ALLOCATE      ALTLIB DISPLAY",
            "   LISTUSER     SEARCH CLASS(...)   HELP command",
            "",
            "Enter  HELP command-name  for a full description of any TSO command.",
        ],
        [],
    ),
    "RACF": (
        "TUTORIAL --------------------- RACF Administration ---------------------------",
        [
            "The RACF option reaches the Resource Access Control Facility panels used",
            "to administer security on the system:",
            "",
            "   1  Data Set Profiles      - protect data sets and maintain access lists.",
            "   2  General Resource       - protect resources in classes other than",
            "                               DATASET (FACILITY, SURROGAT, TSOAUTH ...).",
            "   3  Group Profiles         - define groups and user-to-group connections.",
            "   4  User Profiles          - add, change, delete and list user profiles.",
            "   5  System Options         - SETROPTS: password rules, class activation,",
            "                               auditing and in-storage refresh.",
            "",
            "Each service panel offers ADD, CHANGE, DELETE, ACCESS, AUDIT, DISPLAY and",
            "SEARCH actions that map to the underlying RACF commands (ADDUSER, ALTUSER,",
            "PERMIT, LISTUSER, RLIST, SETROPTS and so on).  Every action reports the",
            "corresponding ICH message and updates the RACF data base.",
        ],
        [],
    ),
    "APPX": (
        "TUTORIAL ------------------------- Appendices --------------------------------",
        [
            "The appendices describe dynamic allocation reason codes returned by the",
            "ALLOCATE command and the format of ISPF list data sets produced by the",
            "utilities.  These are reference material and are presented only when",
            "selected.",
        ],
        [],
    ),
    "INDEX": (
        "TUTORIAL ---------------------------- Index ----------------------------------",
        [
            "Alphabetical index of tutorial topics.  Select a topic code from the main",
            "tutorial menu (F3 to return there):",
            "",
            "   Command .......... 6        Edit ............. 2",
            "   General .......... G        RACF ............. R",
            "   Settings ......... 0        Utilities ........ 3",
            "   View ............. 1        Foreground ....... 4",
        ],
        [],
    ),
}

ROOT = "TUTOR"

# Map an ISPF screen name to the tutorial node F1 should open (context help).
CONTEXT: Dict[str, str] = {
    "PRIMARY": "TUTOR",
    "SETTINGS": "SETTINGS",
    "COMMAND": "CMD",
    "CMDOUT": "CMD",
    "EDIT_ENTRY": "EDIT",
    "BROWSE": "VIEW",
    "UTIL": "UTIL",
    "DSLIST": "UTIL",
    "DSL_ENTRY": "UTIL",
    "MEMBERS": "UTIL",
    "DSUTIL": "UTIL",
    "DSALLOC": "UTIL",
    "RACF": "RACF",
}
