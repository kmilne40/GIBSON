"""Forensic PCAP writer for the GIBSON SENTRY CTI.

Renders the in-memory ``Packet`` model (see ``gibson/apps/cti_plonk.py``) to real
libpcap bytes (magic 0xa1b2c3d4, LINKTYPE_ETHERNET) that open in Wireshark/tshark.
Pure ``struct`` - no external dependency, offline-first, consistent with GIBSON.

Also seeds the ScrAPI Bear forensic captures (one per attack stage) so the actor
page can offer a "Forensic PCAP - ScrAPI Bear" download button.

Training content only; all IPs, ports and payloads are fictional.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import List, Tuple

PCAP_MAGIC = 0xA1B2C3D4
LINKTYPE_ETHERNET = 1


@dataclass
class Pkt:
    """Minimal packet for the writer (mirrors cti_plonk.Packet fields we need)."""
    ts_sec: int
    src: str          # "ip:port"
    dst: str          # "ip:port"
    proto: str
    info: str
    payload: bytes = b""


@dataclass
class ScrapiCapture:
    name: str
    description: str
    packets: List[Pkt] = field(default_factory=list)


# --------------------------------------------------------------------------- #
#  Frame synthesis
# --------------------------------------------------------------------------- #
def _split_hostport(hp: str) -> Tuple[str, int]:
    if ":" in hp:
        ip, _, port = hp.rpartition(":")
        try:
            return ip, int(port)
        except ValueError:
            return hp, 0
    return hp, 0


def _ip_to_bytes(ip: str) -> bytes:
    parts = (ip.split(".") + ["0", "0", "0", "0"])[:4]
    out = []
    for p in parts:
        try:
            out.append(int(p) & 0xFF)
        except ValueError:
            out.append(0)
    return bytes(out)


def _checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    s = 0
    for i in range(0, len(data), 2):
        s += (data[i] << 8) + data[i + 1]
    s = (s >> 16) + (s & 0xFFFF)
    s += s >> 16
    return (~s) & 0xFFFF


def _eth(dst_mac: bytes, src_mac: bytes) -> bytes:
    return dst_mac + src_mac + struct.pack(">H", 0x0800)  # IPv4


def _ipv4(src_ip: str, dst_ip: str, payload_len: int, ident: int) -> bytes:
    ver_ihl = 0x45
    tos = 0
    total_len = 20 + 20 + payload_len  # IP + TCP + data
    flags_frag = 0x4000  # DF
    ttl = 64
    proto = 6  # TCP
    hdr = struct.pack(">BBHHHBBH4s4s", ver_ihl, tos, total_len, ident & 0xFFFF,
                      flags_frag, ttl, proto, 0,
                      _ip_to_bytes(src_ip), _ip_to_bytes(dst_ip))
    chk = _checksum(hdr)
    return struct.pack(">BBHHHBBH4s4s", ver_ihl, tos, total_len, ident & 0xFFFF,
                       flags_frag, ttl, proto, chk,
                       _ip_to_bytes(src_ip), _ip_to_bytes(dst_ip))


def _tcp(sport: int, dport: int, seq: int, ack: int, payload_len: int) -> bytes:
    data_off = (5 << 4)             # 20-byte header, no options
    flags = 0x18 if payload_len else 0x10  # PSH+ACK on data, else ACK
    window = 0xFFFF
    return struct.pack(">HHLLBBHHH", sport & 0xFFFF, dport & 0xFFFF,
                       seq & 0xFFFFFFFF, ack & 0xFFFFFFFF,
                       data_off, flags, window, 0, 0)  # checksum 0 (unverified)


def _frame(pkt: Pkt, seq: int, ack: int) -> bytes:
    src_ip, sport = _split_hostport(pkt.src)
    dst_ip, dport = _split_hostport(pkt.dst)
    data = pkt.payload if isinstance(pkt.payload, (bytes, bytearray)) else str(pkt.payload).encode("utf-8", "replace")
    dst_mac = b"\x02\x00\x00\x00\x00\x02"
    src_mac = b"\x02\x00\x00\x00\x00\x01"
    return _eth(dst_mac, src_mac) + _ipv4(src_ip, dst_ip, len(data), seq ^ 0x1234) + _tcp(sport, dport, seq, ack, len(data)) + data


def write_pcap(packets: List[Pkt]) -> bytes:
    """Return valid libpcap bytes for the given packets."""
    out = bytearray()
    out += struct.pack("<IHHiIII", PCAP_MAGIC, 2, 4, 0, 0, 65535, LINKTYPE_ETHERNET)
    seq = 1000
    ack = 5000
    base_ts = packets[0].ts_sec if packets else 0
    for i, pkt in enumerate(packets):
        frame = _frame(pkt, seq, ack)
        ts = pkt.ts_sec or (base_ts + i)
        out += struct.pack("<IIII", ts, (i * 1000) % 1000000, len(frame), len(frame))
        out += frame
        seq += max(1, len(pkt.payload) if pkt.payload else 1)
        ack += 1
    return bytes(out)


# --------------------------------------------------------------------------- #
#  Seeded ScrAPI Bear captures (one per attack stage)
# --------------------------------------------------------------------------- #
_C = "203.0.113.44:51000"      # attacker
_API = "10.20.1.9:8080"        # z/OS Connect HTTP
_DDF = "10.20.1.9:446"         # Db2 DDF / DRDA

def scrapi_captures() -> List[ScrapiCapture]:
    b = 1_720_000_000
    recon = ScrapiCapture("scrapi_api_recon.pcap", "API discovery + SAF-denied probe", [
        Pkt(b + 0, _C, _API, "HTTP", "GET /zosConnect/apis (no SAF identity)",
            b"GET /zosConnect/apis HTTP/1.1\r\nHost: gibson:8080\r\nAccept: application/json\r\n\r\n"),
        Pkt(b + 0, _API, _C, "HTTP", "403 BAQR0419W",
            b"HTTP/1.1 403 Forbidden\r\nContent-Type: application/json\r\n\r\n"
            b'{"errorMessage":"BAQR0419W: The user is not authorized to perform the requested action."}'),
        Pkt(b + 2, _C, _API, "HTTP", "GET /zosConnect/apis (authorised)",
            b"GET /zosConnect/apis HTTP/1.1\r\nHost: gibson:8080\r\nAuthorization: Basic QVBJVVNFUjoq\r\n\r\n"),
        Pkt(b + 2, _API, _C, "HTTP", "200 lists accountsAPI/customersAPI",
            b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{"apis":[{"name":"accountsAPI"},{"name":"customersAPI"}]}'),
    ])
    bypass = ScrapiCapture("scrapi_sqli_bypass.pcap", "' OR '1'='1 mass disclosure via the API", [
        Pkt(b + 10, _C, _API, "HTTP", "GET /customers/' OR '1'='1",
            b"GET /customers/'%20OR%20'1'='1 HTTP/1.1\r\nHost: gibson:8080\r\nAuthorization: Basic QVBJVVNFUjoq\r\n\r\n"),
        Pkt(b + 10, _API, _C, "HTTP", "200 - 4 account rows (ROWSET_EXPANDED)",
            b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{"result":"ROWSET_EXPANDED","rows_returned":4}'),
    ])
    union = ScrapiCapture("scrapi_union_schema.pcap", "UNION schema disclosure", [
        Pkt(b + 20, _C, _API, "HTTP", "GET /customers/' UNION SELECT ...",
            b"GET /customers/'%20UNION%20SELECT%201%20FROM%20SYSIBM.SYSDUMMY1-- HTTP/1.1\r\nHost: gibson:8080\r\n\r\n"),
        Pkt(b + 20, _API, _C, "HTTP", "200 - 19 table names (UNION_METADATA)",
            b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{"result":"UNION_METADATA","rows_returned":19}'),
    ])
    drda = ScrapiCapture("scrapi_ddf_drda.pcap", "DRDA/DDF the Db2 server sees (EXCSQLSTT)", [
        Pkt(b + 11, _API, _DDF, "DRDA", "EXCSQLSTT SELECT * FROM CBSA.ACCOUNT WHERE ...",
            b"\xd0\x41\x00\x2fEXCSQLSTT SELECT * FROM CBSA.ACCOUNT WHERE CUSTOMER_ID = '' OR '1'='1'"),
        Pkt(b + 11, _DDF, _API, "DRDA", "QRYDTA 4 rows returned",
            b"\xd0\x03\x00\x10QRYDTA rows=4"),
    ])
    return [recon, bypass, union, drda]


def get_scrapi_capture(name: str):
    for c in scrapi_captures():
        if c.name == name:
            return c
    return None
