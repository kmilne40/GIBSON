"""Compatibility shim for the relocated REST gateway.

The unified REST listener that used to live here was refactored into
``gibson.services.cbsa_rest8080`` (the App8080 router + ``Cbsa8080Handler``).
This module re-exports the old public names so pre-refactor tests and any
external integrations that imported ``serve_rest`` / ``_FallbackHandler``
continue to work against the current implementation.
"""
from __future__ import annotations

from gibson.services.cbsa_rest8080 import (
    serve_cbsa_rest8080 as serve_rest,
    Cbsa8080Handler as _FallbackHandler,
)

__all__ = ["serve_rest", "_FallbackHandler"]
