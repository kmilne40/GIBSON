"""HostServices (spec X0): the only coupling point between the language engines
and GIBSON.

Engines talk to `HostServices`; `HostServices` talks to a `DatasetBackend`.
`MemoryBackend` makes the engines unit-testable in isolation; `GibsonBackend`
adapts the real `DatasetCatalog`.  `HostServices.tso()` implements the small set
of TSO commands REXX execs actually issue (ALLOC/FREE/DELETE/LISTDS), mapping DD
names to datasets so EXECIO can resolve them.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple


class DatasetBackend:
    def read_dataset(self, dsn: str) -> List[str]: raise NotImplementedError
    def write_dataset(self, dsn: str, recs: List[str], disp: str = "OLD") -> None: raise NotImplementedError
    def exists(self, dsn: str) -> bool: raise NotImplementedError
    def alloc(self, dsn: str, org="PS", recfm="FB", lrecl=80) -> None: raise NotImplementedError
    def delete(self, dsn: str) -> None: raise NotImplementedError
    def members(self, dsn: str) -> List[str]: return []


class MemoryBackend(DatasetBackend):
    """In-memory dataset store for tests."""
    def __init__(self):
        self.store: Dict[str, List[str]] = {}

    def _k(self, dsn): return dsn.strip().strip("'").upper()
    def read_dataset(self, dsn):
        k = self._k(dsn)
        if k not in self.store:
            raise KeyError(f"dataset not found: {k}")
        return list(self.store[k])
    def write_dataset(self, dsn, recs, disp="OLD"):
        k = self._k(dsn)
        if disp == "MOD" and k in self.store:
            self.store[k].extend(recs)
        else:
            self.store[k] = list(recs)
    def exists(self, dsn): return self._k(dsn) in self.store
    def alloc(self, dsn, org="PS", recfm="FB", lrecl=80):
        self.store.setdefault(self._k(dsn), [])
    def delete(self, dsn): self.store.pop(self._k(dsn), None)


class GibsonBackend(DatasetBackend):
    """Adapter over GIBSON's DatasetCatalog (state.datasets)."""
    def __init__(self, catalog, userid: str):
        self.cat = catalog
        self.userid = userid.upper()
    def read_dataset(self, dsn):
        text = self.cat.read(self.userid, dsn.strip().strip("'"))
        return text.split("\n") if text else []
    def write_dataset(self, dsn, recs, disp="OLD"):
        name = dsn.strip().strip("'")
        if disp == "MOD" and self.cat.exists(self.userid, name):
            existing = self.cat.read(self.userid, name)
            recs = (existing.split("\n") if existing else []) + list(recs)
        self.cat.write(self.userid, name, "\n".join(recs))
    def exists(self, dsn):
        try:
            self.cat.read(self.userid, dsn.strip().strip("'"))
            return True
        except Exception:
            return False
    def alloc(self, dsn, org="PS", recfm="FB", lrecl=80):
        self.cat.allocate(self.userid, dsn.strip().strip("'"), org=org, recfm=recfm, lrecl=lrecl)
    def delete(self, dsn): self.cat.delete(self.userid, dsn.strip().strip("'"))
    def members(self, dsn):
        try:
            return self.cat.members(self.userid, dsn.strip().strip("'"))
        except Exception:
            return []


_ALLOC_RE = re.compile(r"\b(?:FI|FILE|DD|DDNAME)\(([^)]+)\)", re.I)
_DA_RE = re.compile(r"\b(?:DA|DATASET|DSNAME|DSN)\(([^)]+)\)", re.I)


class HostServices:
    def __init__(self, backend: DatasetBackend, userid: str = "IBMUSER", command_runner=None):
        self.backend = backend
        self.userid = userid.upper()
        self.dd: Dict[str, str] = {}          # ddname -> dsn
        self.output: List[str] = []
        self.command_runner = command_runner  # optional fallback to GIBSON's TSO processor
        self.gdg: Dict[str, dict] = {}        # base -> {current,limit,pending}
        self.sql_backend = None               # optional callable(sql, params, userid) -> rows
        self.sql_tables: Dict[str, list] = {} # in-memory tables for standalone SQL (tests/labs)

    def define_gdg(self, base: str, limit: int = 255) -> None:
        self.gdg[base.strip().strip("'").upper()] = {"current": 0, "limit": limit, "pending": {}}

    def resolve_gdg(self, dsn: str) -> str:
        """Resolve BASE(+n)/BASE(0)/BASE(-n) to a physical generation name."""
        raw = dsn.strip().strip("'").upper()
        m = re.fullmatch(r"(.+?)\(([+-]?\d+)\)", raw)
        if not m:
            return raw
        base, rel = m.group(1), int(m.group(2))
        g = self.gdg.setdefault(base, {"current": 0, "limit": 255, "pending": {}})
        if rel > 0:
            gen = g["current"] + rel
            g["pending"][rel] = max(g["pending"].get(rel, 0), gen)
        else:
            gen = g["current"] + rel
        if gen < 1:
            gen = 1
        return f"{base}.G{gen:04d}V00"

    def rollin_gdg(self) -> None:
        """Commit pending +n generations at job end (respecting LIMIT)."""
        for base, g in self.gdg.items():
            if g["pending"]:
                g["current"] = max(g["current"], max(g["pending"].values()))
                g["pending"] = {}
                # enforce LIMIT: uncatalog generations older than the window
                keep = g["limit"]
                oldest = g["current"] - keep
                for n in range(1, oldest + 1):
                    try:
                        self.backend.delete(f"{base}.G{n:04d}V00")
                    except Exception:
                        pass

    @property
    def sysuid(self) -> str: return self.userid

    # ---- embedded-SQL bridge (EXEC SQL from the COBOL engine lands here) ----
    def sql(self, sql: str, params=None, userid: str = None) -> List[dict]:
        """Execute a SQL statement for the COBOL engine. If a sql_backend is wired
        (live GIBSON -> Db2/sqli_search) it is used; otherwise a small in-memory
        executor runs against self.sql_tables so the engine is testable standalone.

        `params` are bound values for '?' placeholders (parameterised host variables):
        they are matched as DATA and never parsed as SQL, so the safe form is
        injection-proof. A value written directly into the SQL text (dynamic SQL built
        by STRING) is parsed, so the vulnerable form is injectable."""
        if self.sql_backend is not None:
            return self.sql_backend(sql, list(params or []), (userid or self.userid)) or []
        return self._sql_inmemory(sql, list(params or []))

    def _sql_inmemory(self, sql: str, params) -> List[dict]:
        m = re.match(r"\s*SELECT\s+(.*?)\s+FROM\s+([A-Za-z0-9_.$]+)(?:\s+WHERE\s+(.*))?$",
                     sql.strip().rstrip(";"), re.I | re.S)
        if not m:
            return []
        cols_raw, table, where = m.group(1).strip(), m.group(2).strip().upper(), (m.group(3) or "").strip()
        rows = list(self.sql_tables.get(table, []))
        # UNION-based schema disclosure -> table metadata
        if re.search(r"\bUNION\b", where, re.I):
            return [{"TABLE_SCHEMA": table.split(".")[0] if "." in table else "", "TABLE_NAME": t}
                    for t in self.sql_tables]
        result = rows
        wm = re.match(r"([A-Za-z0-9_]+)\s*=\s*(\?|'.*'|\S+)", where, re.I | re.S) if where else None
        if wm:
            col = wm.group(1).upper(); rhs = wm.group(2)
            if rhs == "?":                                   # bound host var -> EXACT match
                val = params[0] if params else ""
                result = [r for r in rows if str(r.get(col, "")).strip() == str(val).strip()]
            else:                                            # inline literal -> parse for injection
                inner = rhs[1:-1] if rhs.startswith("'") and rhs.endswith("'") else rhs
                u = inner.upper()
                if ("OR" in u and "1" in u and "=" in u):    # ' OR '1'='1  -> whole table
                    result = rows
                elif ("AND" in u and ("1'='2" in u or "1=2" in u)):
                    result = []
                else:
                    result = [r for r in rows if str(r.get(col, "")).strip() == inner.strip()]
        # project requested columns (SELECT * -> all)
        if cols_raw == "*":
            return [dict(r) for r in result]
        cols = [c.strip().upper() for c in cols_raw.split(",")]
        return [{c: r.get(c, "") for c in cols} for r in result]

    def sysvar(self, name: str) -> str:
        return {"SYSUID": self.userid, "SYSNODE": "GIBSON", "SYSENV": "FORE"}.get(name.upper(), "")

    def console(self, text: str) -> None:
        self.output.append(text)

    def ispexec(self, service: str) -> int:
        # R4 stub: VPUT/VGET update a shared pool; other services accepted.
        return 0

    # dataset helpers used by EXECIO
    def dd_to_dsn(self, ddname: str) -> Optional[str]:
        return self.dd.get(ddname.upper())

    def read_dataset(self, dsn: str) -> List[str]:
        return self.backend.read_dataset(dsn)

    def write_dataset(self, dsn: str, recs: List[str], disp="OLD") -> None:
        self.backend.write_dataset(dsn, recs, disp)

    # ---- TSO command dispatch (the subset execs use) ----
    def tso(self, command: str) -> Tuple[int, List[str]]:
        cmd = command.strip()
        if not cmd:
            return 0, []
        verb = cmd.split()[0].upper()
        try:
            if verb in ("ALLOC", "ALLOCATE"):
                return self._alloc(cmd)
            if verb in ("FREE", "UNALLOC"):
                m = _ALLOC_RE.search(cmd)
                if m:
                    self.dd.pop(m.group(1).strip().upper(), None)
                return 0, []
            if verb == "DELETE":
                dsn = cmd[len(verb):].strip()
                self.backend.delete(dsn)
                return 0, [f"DATASET {dsn.strip(chr(39)).upper()} DELETED"]
            if verb in ("LISTDS", "LISTDSI"):
                dsn = cmd.split()[1] if len(cmd.split()) > 1 else ""
                ok = self.backend.exists(dsn)
                return (0 if ok else 8), ([f"{dsn.strip(chr(39)).upper()}", "--RECFM-LRECL-BLKSIZE-DSORG",
                                          "  FB    80    800    PS"] if ok else [f"{dsn} NOT IN CATALOG"])
            # unknown command -> GIBSON's TSO processor if wired, else accept as no-op
            if self.command_runner is not None:
                try:
                    result = self.command_runner(cmd)
                    lines = result.splitlines() if isinstance(result, str) else list(result or [])
                    return 0, lines
                except Exception as e:
                    return 12, [str(e)]
            return 0, []
        except Exception as e:
            return 12, [str(e)]

    def _alloc(self, cmd: str):
        dd = _ALLOC_RE.search(cmd)
        da = _DA_RE.search(cmd)
        up = cmd.upper()
        status = "SHR"
        for s in ("NEW", "OLD", "SHR", "MOD"):
            if re.search(rf"\b{s}\b", up):
                status = s; break
        if not dd:
            return 12, ["ALLOC: missing FI()/DD()"]
        ddname = dd.group(1).strip().upper()
        dsn = da.group(1).strip().strip("'").upper() if da else f"&&{ddname}"
        self.dd[ddname] = dsn
        if status == "NEW" and da:
            self.backend.alloc(dsn)
        return 0, []
