"""A real S/390 assembler + interpreter.

A two-pass assembler with a location counter and symbol table, and a fetch-decode-execute
interpreter with a program counter, condition code and a working instruction set - enough to
run *arbitrary* training HLASM (loops, conditionals, MVC/CLC, BCT/BXLE, SVC, WTO), not just the
ELV exploit subset. It stays API-compatible with the ELV Level B engine:

    S390(storage, r13=...).run(source)      # execute against a host-storage image
    assemble_and_run(source, storage, r13)  # convenience
    S390(...).reg / .supervisor / .st       # unchanged attributes

and adds a listing path for JCL assembler steps:

    assemble_listing(source[, storage])     # -> (rc, listing_text, symbols)

Authorised GIBSON training use only.
"""
from __future__ import annotations
import re
from typing import Callable, Dict, List, Optional, Tuple

MASK32 = 0xFFFFFFFF


class AsmError(Exception):
    pass


# ---------------------------------------------------------------------------
# Storage: a simple bytearray image for standalone / JCL runs. The ELV path
# passes its own HostStorage (same read/write/word/putword/alloc interface).
# ---------------------------------------------------------------------------
class Storage:
    def __init__(self, size: int = 1 << 20):
        self.mem = bytearray(size)
        self._top = 0x1000            # bump allocator start

    def read(self, addr: int, length: int) -> bytes:
        return bytes(self.mem[addr:addr + length])

    def write(self, addr: int, data: bytes) -> None:
        self.mem[addr:addr + len(data)] = data

    def word(self, addr: int) -> int:
        return int.from_bytes(self.mem[addr:addr + 4], "big")

    def putword(self, addr: int, val: int) -> None:
        self.mem[addr:addr + 4] = (val & MASK32).to_bytes(4, "big")

    def half(self, addr: int) -> int:
        return int.from_bytes(self.mem[addr:addr + 2], "big")

    def alloc(self, size: int) -> int:
        a = self._top
        self._top = (self._top + max(1, size) + 7) & ~7
        return a


def _signed(v: int) -> int:
    v &= MASK32
    return v - (1 << 32) if v & 0x80000000 else v


def _pack_read(st, addr: int, length: int) -> int:
    """Read a packed-decimal (BCD) field: digits two-per-byte, last nibble is sign."""
    b = st.read(addr, length)
    if not b:
        return 0
    digits = ""
    for i, byte in enumerate(b):
        hi, lo = byte >> 4, byte & 0xF
        digits += str(hi)
        if i < length - 1:
            digits += str(lo)
    sign = b[-1] & 0xF
    val = int(digits) if digits else 0
    return -val if sign in (0xB, 0xD) else val


def _pack_write(st, addr: int, length: int, val: int) -> None:
    neg = val < 0
    maxd = 2 * length - 1
    ds = str(abs(val))[-maxd:].rjust(maxd, "0")
    nibbles = [int(c) for c in ds] + [0xD if neg else 0xC]
    out = bytearray(length)
    for i in range(length):
        out[i] = (nibbles[i * 2] << 4) | nibbles[i * 2 + 1]
    st.write(addr, bytes(out))


def _imm(tok: str) -> int:
    tok = tok.strip()
    m = re.fullmatch(r"X'([0-9A-Fa-f]+)'", tok)
    if m:
        return int(m.group(1), 16)
    m = re.fullmatch(r"B'([01]+)'", tok)
    if m:
        return int(m.group(1), 2)
    m = re.fullmatch(r"C'(.)'", tok)
    if m:
        return ord(m.group(1).encode("cp037"))
    return int(tok, 0) if tok.lower().startswith("0x") else int(tok)


# instruction length in bytes by format (drives the location counter + PC)
_RR = {"LR", "LTR", "AR", "SR", "MR", "DR", "CR", "CLR", "NR", "OR", "XR",
       "BR", "BALR", "BCR", "BCTR", "MODESET", "LCR", "LNR", "LPR", "BASR"}
_RX = {"L", "LA", "LH", "ST", "STH", "A", "AH", "S", "SH", "M", "C", "CH",
       "CL", "N", "O", "X", "BAL", "BC", "BCT", "BXH", "BXLE",
       "IC", "STC", "BAS", "CVB", "CVD"}
_RS = {"STM", "LM", "SLL", "SRL", "SLA", "SRA", "ICM", "STCM", "CLM"}
_SI = {"NI", "OI", "XI", "CLI", "MVI", "TM"}
_SS = {"MVC", "CLC", "NC", "OC", "XC", "MVN", "MVZ",
       "PACK", "UNPK", "AP", "SP", "ZAP", "CP"}
# extended branch mnemonics -> BC mask (CC bit = 8>>cc)
_EXT = {"B": 15, "NOP": 0, "BE": 8, "BZ": 8, "BNE": 7, "BNZ": 7,
        "BH": 2, "BP": 2, "BL": 4, "BM": 4, "BNH": 13, "BNP": 13,
        "BNL": 11, "BNM": 11, "BO": 1, "BNO": 14}
_DIRECTIVES = {"CSECT", "DSECT", "START", "USING", "DROP", "AMODE", "RMODE",
               "END", "EJECT", "SPACE", "PRINT", "TITLE", "LTORG", "ENTRY",
               "EXTRN", "REGS", "COPY"}


class S390:
    """Assemble and execute HLASM against a storage image."""

    def __init__(self, storage=None, r13: Optional[int] = None):
        self.st = storage if storage is not None else Storage()
        self.reg: List[int] = [0] * 16
        self.cc = 0
        self.supervisor = False
        self.labels: Dict[str, int] = {}          # symbol -> address
        self.trace: List[str] = []
        self.wto: List[str] = []                  # WTO/console messages
        self.svc_calls: List[int] = []
        self.listing: List[str] = []
        self.errors: List[str] = []
        self.reg[13] = r13 if r13 is not None else self.st.alloc(72)
        self._code: Dict[int, Tuple[str, List[str], str]] = {}   # loc -> instr
        self._order: List[int] = []               # ordered instruction locs

    # ----- operand helpers -------------------------------------------------
    def _len_of(self, mnem: str) -> int:
        if mnem in _RR:
            return 2
        if mnem in _SS:
            return 6
        return 4                                   # RX / RS / SI / macros

    def _val(self, tok: str) -> int:
        tok = tok.strip()
        m = re.fullmatch(r"([A-Za-z@#$][A-Za-z0-9@#$]*)\s*([+\-]\s*\w+)?", tok)
        if m and m.group(1) in self.labels:
            base = self.labels[m.group(1)]
            if m.group(2):
                base += int(m.group(2).replace(" ", ""))
            return base
        mx = re.fullmatch(r"X'([0-9A-Fa-f]+)'", tok)
        if mx:
            return int(mx.group(1), 16)
        return int(tok)

    def _ea(self, operand: str) -> int:
        """Effective address of D(B), D(X,B), label(+n) or absolute."""
        operand = operand.strip()
        m = re.fullmatch(r"(.+?)\((\d+),(\d+)\)", operand)      # D(X,B)
        if m:
            return (self._val(m.group(1)) + self.reg[int(m.group(2))] +
                    self.reg[int(m.group(3))]) & MASK32
        m = re.fullmatch(r"(.+?)\((\d+)\)", operand)           # D(B)
        if m:
            return (self._val(m.group(1)) + self.reg[int(m.group(2))]) & MASK32
        return self._val(operand) & MASK32

    def _ss(self, ops: List[str]) -> Tuple[int, int, int]:
        """SS operands: op1='D(L,B)'/'label(L)', op2='D(B)'/'label' -> (a1,length,a2)."""
        m = re.fullmatch(r"(.+?)\((\d+)(?:,(\d+))?\)", ops[0].strip())
        if m:
            length = int(m.group(2))
            base = self.reg[int(m.group(3))] if m.group(3) else 0
            a1 = (self._val(m.group(1)) + base) & MASK32
        else:
            a1, length = self._val(ops[0]) & MASK32, 1
        a2 = self._ea(ops[1]) if len(ops) > 1 else 0
        return a1, length, a2

    @staticmethod
    def _operand_field(s: str) -> str:
        depth, inq, out = 0, False, ""
        for ch in s:
            if ch == "'":
                inq = not inq
            elif ch == "(" and not inq:
                depth += 1
            elif ch == ")" and not inq:
                depth -= 1
            elif ch == " " and depth == 0 and not inq:
                break
            out += ch
        return out

    def _ss2(self, ops):
        """SS operands with two lengths: op1='d1(l1[,b])', op2='d2(l2[,b])'."""
        def parse(o):
            import re as _re
            m = _re.fullmatch(r"(.+?)\((\d+)(?:,(\d+))?\)", o.strip())
            if m:
                base = self.reg[int(m.group(3))] if m.group(3) else 0
                return (self._val(m.group(1)) + base) & MASK32, int(m.group(2))
            return self._ea(o), 1
        a1, l1 = parse(ops[0])
        a2, l2 = parse(ops[1])
        return a1, l1, a2, l2

    @staticmethod
    def _split_ops(ops: str) -> List[str]:
        out, depth, inq, cur = [], 0, False, ""
        for ch in ops:
            if ch == "'":
                inq = not inq
            if ch == "(" and not inq:
                depth += 1
            elif ch == ")" and not inq:
                depth -= 1
            if ch == "," and depth == 0 and not inq:
                out.append(cur.strip()); cur = ""
            else:
                cur += ch
        if cur.strip():
            out.append(cur.strip())
        return out

    # ----- DS/DC ------------------------------------------------------------
    @staticmethod
    def _dc_bytes(ops: str) -> bytes:
        m = re.match(r"(\d*)([FHCXPB])(?:L(\d+))?'?(.*?)'?$", ops.strip())
        if not m:
            return b"\x00\x00\x00\x00"
        dup = int(m.group(1)) if m.group(1) else 1
        typ, exp_len, val = m.group(2), m.group(3), m.group(4)
        if typ == "C":
            data = val.encode("cp037")
            if exp_len:
                data = data.ljust(int(exp_len), b"\x40")[:int(exp_len)]
        elif typ == "X":
            data = bytes.fromhex(val) if val else b"\x00"
        elif typ == "F":
            data = (int(val) & MASK32).to_bytes(4, "big") if val else b"\x00\x00\x00\x00"
        elif typ == "H":
            data = (int(val) & 0xFFFF).to_bytes(2, "big") if val else b"\x00\x00"
        elif typ == "B":
            data = bytes([int(val, 2) & 0xFF]) if val else b"\x00"
        elif typ == "P":  # packed decimal BCD (digits 2/byte, sign in last nibble)
            n = int(val) if val else 0
            length = int(exp_len) if exp_len else max(1, (len(str(abs(n))) // 2) + 1)
            maxd = 2 * length - 1
            ds = str(abs(n))[-maxd:].rjust(maxd, "0")
            nibbles = [int(c) for c in ds] + [0xD if n < 0 else 0xC]
            data = bytes((nibbles[i * 2] << 4) | nibbles[i * 2 + 1] for i in range(length))
        else:
            data = (int(val) if val else 0).to_bytes(4, "big", signed=False)
        return data * dup

    @staticmethod
    def _ds_size(ops: str) -> int:
        m = re.match(r"(\d*)([FHDCXPB])(?:L(\d+))?", ops.strip() or "F")
        n = int(m.group(1)) if m and m.group(1) else 1
        if m and m.group(3):
            unit = int(m.group(3))
        else:
            unit = {"F": 4, "H": 2, "D": 8, "C": 1, "X": 1, "P": 1, "B": 1}.get(
                m.group(2) if m else "F", 4)
        return max(1, n * unit)

    # ----- assemble (two passes: labels/LOC, then it's ready to run) --------
    def assemble(self, source: str) -> List[Tuple[str, List[str], str]]:
        self._code, self._order, self.listing, self.errors = {}, [], [], []
        loc = 0
        equ_pending: List[Tuple[str, str]] = []
        for raw in source.splitlines():
            if not raw.strip() or raw.lstrip().startswith("*") or raw.lstrip().startswith(".*"):
                continue
            m = re.match(r"^(\S+)?\s+(\S+)(?:\s+(.*))?$", raw.rstrip())
            if not m:
                continue
            label, mnem, rest = m.group(1), m.group(2).upper(), (m.group(3) or "").strip()
            objhex = ""
            if mnem == "EQU":
                if label:
                    equ_pending.append((label, rest))
                self.listing.append(f"{'':8} {label or '':<8} EQU  {rest}")
                continue
            if mnem in ("DS", "DC"):
                size = self._ds_size(rest)
                addr = self.st.alloc(size)
                if label:
                    self.labels[label] = addr
                if mnem == "DC":
                    self.st.write(addr, self._dc_bytes(rest))
                    objhex = self._dc_bytes(rest)[:8].hex().upper()
                self.listing.append(f"{addr:06X} {objhex:<16} {label or '':<8} {mnem} {rest}")
                continue
            if mnem in _DIRECTIVES:
                if label:
                    self.labels[label] = loc
                self.listing.append(f"{loc:06X} {'':16} {label or '':<8} {mnem} {rest}")
                continue
            # executable instruction
            if label:
                self.labels[label] = loc
            ops = self._split_ops(self._operand_field(rest))
            self._code[loc] = (mnem, ops, label or "")
            self._order.append(loc)
            self.listing.append(f"{loc:06X} {'':16} {label or '':<8} {mnem} {rest}")
            loc += self._len_of(mnem)
        # resolve EQU now that labels exist
        for lbl, expr in equ_pending:
            try:
                self.labels[lbl] = self._val(expr)
            except Exception:
                self.labels[lbl] = 0
        # symbol table listing
        self.listing.append("")
        self.listing.append("SYMBOL TABLE")
        for k, v in sorted(self.labels.items()):
            self.listing.append(f"  {k:<16} {v:06X}")
        return [self._code[l] for l in self._order]

    # ----- execute ----------------------------------------------------------
    def run(self, source: str, max_steps: int = 100000) -> "S390":
        self.assemble(source)
        if not self._order:
            return self
        idx_of = {loc: i for i, loc in enumerate(self._order)}
        pc = self._order[0]
        steps = 0
        while pc in self._code and steps < max_steps:
            steps += 1
            mnem, ops, _ = self._code[pc]
            nxt = pc + self._len_of(mnem)
            branch_to = self._exec(mnem, ops)     # returns target loc or None or "HALT"
            if branch_to == "HALT":
                break
            pc = branch_to if branch_to is not None else nxt
        return self

    def _target(self, tok: str) -> Optional[int]:
        try:
            return self._val(tok)
        except Exception:
            return None

    def _exec(self, mnem: str, ops):
        reg, st = self.reg, self.st

        # ----- branches (extended + base) -----
        if mnem in _EXT:
            mask = _EXT[mnem]
            if mask == 15 and ops and ops[0].strip() in ("14", "R14"):
                return "HALT"                      # B/BR-style return
            if mask & (8 >> self.cc):
                return self._target(ops[0]) if ops else None
            return None
        if mnem == "BR":
            if ops and ops[0].strip() in ("14", "R14"):
                return "HALT"
            return reg[int(ops[0])] if ops and ops[0].isdigit() else None
        if mnem == "BC":
            mask = int(ops[0])
            if mask == 15 and ops[1].strip() in ("14", "R14"):
                return "HALT"
            if mask & (8 >> self.cc):
                return self._target(ops[1])
            return None
        if mnem == "BCR":
            mask = int(ops[0])
            if mask & (8 >> self.cc):
                return "HALT" if int(ops[1]) == 14 else reg[int(ops[1])]
            return None
        if mnem in ("BAL", "BALR"):
            # store return addr in r1 (approximate); branch to target
            if mnem == "BALR":
                if len(ops) > 1 and int(ops[1]) == 0:
                    return None                    # BALR r,0 = load base, no branch
                return reg[int(ops[1])] if len(ops) > 1 else None
            return self._target(ops[1])
        if mnem == "BCT":
            reg[int(ops[0])] = (reg[int(ops[0])] - 1) & MASK32
            if reg[int(ops[0])] != 0:
                return self._target(ops[1])
            return None
        if mnem == "BCTR":
            if int(ops[1]) == 0:
                reg[int(ops[0])] = (reg[int(ops[0])] - 1) & MASK32
                return None
            reg[int(ops[0])] = (reg[int(ops[0])] - 1) & MASK32
            return reg[int(ops[1])] if reg[int(ops[0])] != 0 else None
        if mnem in ("BXH", "BXLE"):
            r1, r3 = int(ops[0]), int(ops[1])
            reg[r1] = (reg[r1] + reg[r3]) & MASK32
            limit = reg[r3 | 1]
            cond = (_signed(reg[r1]) > _signed(limit)) if mnem == "BXH" else (_signed(reg[r1]) <= _signed(limit))
            return self._target(ops[2]) if cond else None

        # ----- system / macros -----
        if mnem == "MODESET":
            self.supervisor = True
            return None
        if mnem == "SVC":
            n = _imm(ops[0]) if ops else 0
            self.svc_calls.append(n)
            return None
        if mnem == "WTO":
            m = re.search(r"'([^']*)'", " ".join(ops))
            self.wto.append(m.group(1) if m else "")
            return None

        # ----- load / store -----
        if mnem == "L":
            reg[int(ops[0])] = st.word(self._ea(ops[1])); return None
        if mnem == "LR":
            reg[int(ops[0])] = reg[int(ops[1])]; return None
        if mnem == "LA":
            reg[int(ops[0])] = self._ea(ops[1]) & MASK32; return None
        if mnem == "LH":
            reg[int(ops[0])] = st.half(self._ea(ops[1])); return None
        if mnem == "LTR":
            v = reg[int(ops[1])]; reg[int(ops[0])] = v
            self.cc = 0 if _signed(v) == 0 else (1 if _signed(v) < 0 else 2); return None
        if mnem == "ST":
            st.putword(self._ea(ops[1]), reg[int(ops[0])]); return None
        if mnem == "STH":
            a = self._ea(ops[1]); st.write(a, (reg[int(ops[0])] & 0xFFFF).to_bytes(2, "big")); return None
        if mnem == "STM":
            r1, r2, ea = int(ops[0]), int(ops[1]), self._ea(ops[2]); i = 0
            while True:
                st.putword(ea + i * 4, reg[(r1 + i) & 15])
                if (r1 + i) & 15 == r2:
                    break
                i += 1
            return None
        if mnem == "LM":
            r1, r2, ea = int(ops[0]), int(ops[1]), self._ea(ops[2]); i = 0
            while True:
                reg[(r1 + i) & 15] = st.word(ea + i * 4)
                if (r1 + i) & 15 == r2:
                    break
                i += 1
            return None

        # ----- arithmetic (sets CC) -----
        def setcc_arith(v):
            s = _signed(v)
            self.cc = 0 if s == 0 else (1 if s < 0 else 2)
        if mnem in ("A", "AR", "AH", "S", "SR", "SH"):
            r1 = int(ops[0])
            if mnem == "A":
                b = st.word(self._ea(ops[1]))
            elif mnem == "AH":
                b = st.half(self._ea(ops[1]))
            elif mnem == "S":
                b = st.word(self._ea(ops[1]))
            elif mnem == "SH":
                b = st.half(self._ea(ops[1]))
            else:
                b = reg[int(ops[1])]
            if mnem in ("S", "SR", "SH"):
                reg[r1] = (reg[r1] - b) & MASK32
            else:
                reg[r1] = (reg[r1] + b) & MASK32
            setcc_arith(reg[r1]); return None
        if mnem in ("M", "MR"):
            r1 = int(ops[0]); b = st.word(self._ea(ops[1])) if mnem == "M" else reg[int(ops[1])]
            reg[(r1 + 1) & 15] = (_signed(reg[(r1 + 1) & 15]) * _signed(b)) & MASK32; return None

        # ----- compare (sets CC) -----
        if mnem in ("C", "CR", "CH", "CL", "CLR"):
            a = _signed(reg[int(ops[0])])
            if mnem == "C":
                b = _signed(st.word(self._ea(ops[1])))
            elif mnem == "CH":
                b = _signed(st.half(self._ea(ops[1])))
            elif mnem == "CL":
                a, b = reg[int(ops[0])] & MASK32, st.word(self._ea(ops[1])) & MASK32
            elif mnem == "CLR":
                a, b = reg[int(ops[0])] & MASK32, reg[int(ops[1])] & MASK32
            else:
                b = _signed(reg[int(ops[1])])
            self.cc = 0 if a == b else (1 if a < b else 2); return None

        # ----- logical register / immediate -----
        if mnem in ("NR", "OR", "XR", "N", "O", "X"):
            r1 = int(ops[0])
            b = reg[int(ops[1])] if mnem in ("NR", "OR", "XR") else st.word(self._ea(ops[1]))
            reg[r1] = (reg[r1] & b) if mnem in ("N", "NR") else (reg[r1] | b) if mnem in ("O", "OR") else (reg[r1] ^ b)
            reg[r1] &= MASK32
            self.cc = 0 if reg[r1] == 0 else 1; return None
        if mnem in ("NI", "OI", "XI"):
            ea, imm = self._ea(ops[0]), _imm(ops[1]); b = st.read(ea, 1)[0]
            b = (b & imm) if mnem == "NI" else (b | imm) if mnem == "OI" else (b ^ imm)
            st.write(ea, bytes([b & 0xFF])); self.cc = 0 if (b & 0xFF) == 0 else 1; return None
        if mnem == "MVI":
            st.write(self._ea(ops[0]), bytes([_imm(ops[1]) & 0xFF])); return None
        if mnem == "CLI":
            b = st.read(self._ea(ops[0]), 1)[0]; imm = _imm(ops[1]) & 0xFF
            self.cc = 0 if b == imm else (1 if b < imm else 2); return None
        if mnem == "TM":
            b = st.read(self._ea(ops[0]), 1)[0]; mask = _imm(ops[1]) & 0xFF
            r = b & mask
            self.cc = 0 if r == 0 else (3 if r == mask else 1); return None

        # ----- shifts -----
        if mnem in ("SLL", "SRL", "SLA", "SRA"):
            r1 = int(ops[0]); n = self._ea(ops[1]) & 0x3F
            if mnem == "SLL":
                reg[r1] = (reg[r1] << n) & MASK32
            elif mnem == "SRL":
                reg[r1] = (reg[r1] & MASK32) >> n
            elif mnem == "SLA":
                reg[r1] = (_signed(reg[r1]) << n) & MASK32
            else:
                reg[r1] = (_signed(reg[r1]) >> n) & MASK32
            return None

        # ----- storage-to-storage -----
        if mnem in ("MVC", "NC", "OC", "XC", "CLC"):
            a1, length, a2 = self._ss(ops)
            d1, d2 = st.read(a1, length), st.read(a2, length)
            if mnem == "MVC":
                st.write(a1, d2)
            elif mnem == "CLC":
                self.cc = 0 if d1 == d2 else (1 if d1 < d2 else 2)
            else:
                res = bytes((x & y) if mnem == "NC" else (x | y) if mnem == "OC" else (x ^ y)
                            for x, y in zip(d1, d2))
                st.write(a1, res); self.cc = 0 if all(b == 0 for b in res) else 1
            return None

        # ----- load complement/negative/positive (RR, set CC) -----
        if mnem in ("LCR", "LNR", "LPR"):
            v = _signed(reg[int(ops[1])])
            v = -v if mnem == "LCR" else -abs(v) if mnem == "LNR" else abs(v)
            reg[int(ops[0])] = v & MASK32
            self.cc = 0 if v == 0 else (1 if v < 0 else 2); return None

        # ----- branch and save (like BAL/BALR) -----
        if mnem == "BASR":
            if len(ops) > 1 and int(ops[1]) == 0:
                return None
            return reg[int(ops[1])] if len(ops) > 1 else None
        if mnem == "BAS":
            return self._target(ops[1])

        # ----- insert/store character(s) -----
        if mnem == "IC":
            reg[int(ops[0])] = (reg[int(ops[0])] & 0xFFFFFF00) | st.read(self._ea(ops[1]), 1)[0]; return None
        if mnem == "STC":
            st.write(self._ea(ops[0 if len(ops) == 1 else 0]), bytes([reg[int(ops[0])] & 0xFF]))
            st.write(self._ea(ops[1]), bytes([reg[int(ops[0])] & 0xFF])); return None
        if mnem in ("ICM", "STCM", "CLM"):
            r1, mask, ea = int(ops[0]), _imm(ops[1]) & 0xF, self._ea(ops[2])
            byts = [(reg[r1] >> 24) & 0xFF, (reg[r1] >> 16) & 0xFF, (reg[r1] >> 8) & 0xFF, reg[r1] & 0xFF]
            sel = [i for i in range(4) if mask & (8 >> i)]
            if mnem == "ICM":
                data = st.read(ea, len(sel)); val = reg[r1]
                for k, i in enumerate(sel):
                    val = (val & ~(0xFF << (8 * (3 - i)))) | (data[k] << (8 * (3 - i)))
                reg[r1] = val & MASK32
                self.cc = 0 if all(data[k] == 0 for k in range(len(sel))) else 2
            elif mnem == "STCM":
                st.write(ea, bytes(byts[i] for i in sel))
            else:  # CLM
                data = st.read(ea, len(sel)); a = bytes(byts[i] for i in sel)
                self.cc = 0 if a == data else (1 if a < data else 2)
            return None

        # ----- move numerics / zones (SS) -----
        if mnem in ("MVN", "MVZ"):
            a1, length, a2 = self._ss(ops)
            d1, d2 = bytearray(st.read(a1, length)), st.read(a2, length)
            for i in range(length):
                if mnem == "MVN":
                    d1[i] = (d1[i] & 0xF0) | (d2[i] & 0x0F)
                else:
                    d1[i] = (d1[i] & 0x0F) | (d2[i] & 0xF0)
            st.write(a1, bytes(d1)); return None

        # ----- packed decimal -----
        if mnem in ("AP", "SP", "ZAP", "CP"):
            a1, l1, a2, l2 = self._ss2(ops)
            v1, v2 = _pack_read(st, a1, l1), _pack_read(st, a2, l2)
            if mnem == "ZAP":
                res = v2
            elif mnem == "AP":
                res = v1 + v2
            elif mnem == "SP":
                res = v1 - v2
            else:  # CP
                self.cc = 0 if v1 == v2 else (1 if v1 < v2 else 2); return None
            _pack_write(st, a1, l1, res)
            self.cc = 0 if res == 0 else (1 if res < 0 else 2); return None
        if mnem in ("PACK", "UNPK"):
            a1, l1, a2, l2 = self._ss2(ops)
            if mnem == "PACK":
                zoned = st.read(a2, l2)
                digits = "".join(str(b & 0x0F) for b in zoned)
                sign = zoned[-1] >> 4 if zoned else 0xF
                val = int(digits) if digits else 0
                if sign == 0xD:
                    val = -val
                _pack_write(st, a1, l1, val)
            else:  # UNPK packed -> zoned
                val = _pack_read(st, a2, l2)
                ds = str(abs(val)).rjust(l1, "0")[-l1:]
                out = bytearray(0xF0 | int(c) for c in ds)
                out[-1] = ((0xD if val < 0 else 0xC) << 4) | (out[-1] & 0x0F)
                st.write(a1, bytes(out))
            return None
        if mnem == "CVB":
            reg[int(ops[0])] = _pack_read(st, self._ea(ops[1]), 8) & MASK32; return None
        if mnem == "CVD":
            _pack_write(st, self._ea(ops[1]), 8, _signed(reg[int(ops[0])])); return None

        # unknown mnemonic: record + treat as no-op so arbitrary HLASM keeps running
        self.errors.append(f"ASMA057E UNDEFINED OP CODE - {mnem}")
        return None


class HlasmReport:
    """Result of assembling + running HLASM (for JES ASMA90 steps and reports)."""
    def __init__(self, rc: int, listing: str, symbols: Dict[str, int],
                 registers: Dict[int, int], cc: int):
        self.rc = rc
        self.listing = listing
        self.symbols = symbols
        self.registers = registers
        self.cc = cc


def hlasm_assemble(source: str, storage=None) -> HlasmReport:
    """Assemble + run HLASM and return a full report (listing, symbol table, final GPRs, CC).
    Replaces the legacy HlasmSimulator for JES assembler steps and the HLASM runtime lab."""
    cpu = S390(storage)
    rc = 0
    try:
        cpu.run(source)
        rc = 4 if cpu.errors else 0
    except Exception:
        rc = 8
    listing = ("ASMA90 High Level Assembler - GIBSON\n"
               " LOC    OBJECT CODE      LABEL    SOURCE\n"
               + "\n".join(cpu.listing)
               + f"\nMAXIMUM CONDITION CODE WAS {rc:04d}")
    return HlasmReport(rc, listing, dict(cpu.labels),
                       {i: cpu.reg[i] for i in range(16)}, cpu.cc)


def assemble_and_run(source: str, storage=None, r13: Optional[int] = None) -> S390:
    """Assemble and execute HLASM against a storage image; returns the S390 state."""
    return S390(storage, r13=r13).run(source)


def assemble_listing(source: str, storage=None) -> Tuple[int, str, Dict[str, int]]:
    """Assemble for a JCL ASMA90/ASMAHL step: returns (rc, listing_text, symbols).

    rc = 0 clean, 4 if undefined op codes were found (still listed).  Does not execute.
    """
    cpu = S390(storage)
    cpu.assemble(source)
    head = ["ASMA90 High Level Assembler - GIBSON",
            " LOC    OBJECT CODE      LABEL    SOURCE"]
    body = cpu.listing
    rc = 0
    # a dry static check for undefined opcodes (assemble doesn't flag them)
    for loc, (mnem, _ops, _l) in cpu._code.items():
        known = (mnem in _RR or mnem in _RX or mnem in _RS or mnem in _SI or mnem in _SS
                 or mnem in _EXT or mnem in ("BR", "BC", "BCR", "BCT", "BCTR", "BXH", "BXLE",
                                             "BAL", "BALR", "MODESET", "SVC", "WTO"))
        if not known:
            body.append(f"** ASMA057E UNDEFINED OP CODE - {mnem}")
            rc = 4
    body.append(f"MAXIMUM CONDITION CODE WAS {rc:04d}")
    return rc, "\n".join(head + body), dict(cpu.labels)
