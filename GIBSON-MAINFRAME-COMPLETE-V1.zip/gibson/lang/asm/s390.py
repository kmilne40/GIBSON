"""A minimal S/390 assembler + interpreter for the privilege-escalation lab.

It assembles and *executes* the small instruction subset the ELV.APF / ELV.SVC / ELV.SELF
exploits generate, running them against the same host-storage control-block image the REXX
tools walk.  So when an exploit's assembled program does ``OI X'26'(5),X'B1'`` after
chasing PSA -> ASCB -> ASXB -> ACEE, the ACEE flag byte is genuinely flipped in storage -
exactly as on a real system, minus a real CPU.

Supported: CSECT/USING/AMODE/DS/DC/END (directives), STM/LM/L/LA/ST/NI/OI/XR/BALR/BR, and
MODESET (macro -> marks supervisor state).  Not a full ESA/390; only what the lab needs.
Authorised GIBSON training use only.
"""
from __future__ import annotations
import re
from typing import Dict, List, Optional, Tuple


class AsmError(Exception):
    pass


def _imm(tok: str) -> int:
    tok = tok.strip()
    m = re.fullmatch(r"X'([0-9A-Fa-f]+)'", tok)
    if m:
        return int(m.group(1), 16)
    return int(tok)


class S390:
    """Execute a parsed HLASM program against a host-storage image."""

    def __init__(self, storage, r13: Optional[int] = None):
        self.st = storage                       # HostStorage: read/write/word/putword/alloc
        self.reg: List[int] = [0] * 16
        self.labels: Dict[str, int] = {}
        self.supervisor = False
        self.trace: List[str] = []
        # scratch save area so STM/LM have somewhere to go
        self.reg[13] = r13 if r13 is not None else storage.alloc(72)

    # --- operand helpers ---
    def _ea(self, operand: str) -> int:
        """Effective address of a D(B) / label / absolute operand."""
        operand = operand.strip()
        m = re.fullmatch(r"(.+)\((\d+)\)", operand)      # D(B)
        if m:
            disp = self._val(m.group(1))
            return (disp + self.reg[int(m.group(2))]) & 0xFFFFFFFF
        return self._val(operand)                        # absolute or label(+n)

    def _val(self, tok: str) -> int:
        tok = tok.strip()
        m = re.fullmatch(r"([A-Za-z@#$][A-Za-z0-9@#$]*)\s*([+\-]\s*\d+)?", tok)
        if m and m.group(1) in self.labels:
            base = self.labels[m.group(1)]
            return base + (int(m.group(2).replace(" ", "")) if m.group(2) else 0)
        mx = re.fullmatch(r"X'([0-9A-Fa-f]+)'", tok)
        if mx:
            return int(mx.group(1), 16)
        return int(tok)

    # --- assemble: collect labels (allocate DS/DC storage) + instruction list ---
    def assemble(self, source: str) -> List[Tuple[str, List[str]]]:
        program: List[Tuple[str, List[str]]] = []
        for raw in source.splitlines():
            if not raw.strip() or raw.lstrip().startswith("*"):
                continue
            # label in col 1, mnemonic, operands
            m = re.match(r"^(\S+)?\s+(\S+)(?:\s+(.*))?$", raw.rstrip())
            if not m:
                continue
            label, mnem, ops = m.group(1), m.group(2).upper(), (m.group(3) or "").strip()
            if mnem in ("CSECT", "USING", "AMODE", "END", "DROP", "EJECT", "SPACE", "PRINT"):
                if label and mnem == "CSECT":
                    self.labels[label] = self.st.alloc(4)
                continue
            if mnem in ("DS", "DC"):
                size = self._ds_size(ops)
                if label:
                    self.labels[label] = self.st.alloc(size)
                continue
            program.append((mnem, self._split_ops(self._operand_field(ops)), label))
        # second pass would resolve forward labels; the lab progs are backward-only
        return program

    @staticmethod
    def _operand_field(s: str) -> str:
        """Operand field only: stop at the first blank outside quotes/parens (drop comment)."""
        depth, inq, out = 0, False, ""
        for ch in s:
            if ch == "'":
                inq = not inq
            elif ch == "(" and not inq:
                depth += 1
            elif ch == ")" and not inq:
                depth -= 1
            elif ch == " " and depth == 0 and not inq:
                break
            out += ch
        return out

    @staticmethod
    def _split_ops(ops: str) -> List[str]:
        out, depth, cur = [], 0, ""
        for ch in ops:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                out.append(cur.strip()); cur = ""
            else:
                cur += ch
        if cur.strip():
            out.append(cur.strip())
        return out

    @staticmethod
    def _ds_size(ops: str) -> int:
        m = re.match(r"(\d*)([FHDCXP])", ops.strip() or "F")
        n = int(m.group(1)) if m and m.group(1) else 1
        unit = {"F": 4, "H": 2, "D": 8, "C": 1, "X": 1, "P": 1}.get(m.group(2) if m else "F", 4)
        return max(1, n * unit)

    # --- execute ---
    def run(self, source: str, max_steps: int = 10000) -> "S390":
        prog = self.assemble(source)
        # allocate any labels referenced only after the exec list was built
        pc, steps = 0, 0
        while pc < len(prog) and steps < max_steps:
            steps += 1
            mnem, ops, _label = prog[pc]
            pc += 1
            if mnem == "BR":
                if ops and ops[0].strip() == "14":
                    break                                # return to caller -> halt
                continue
            self._exec(mnem, ops)
        return self

    def _exec(self, mnem: str, ops: List[str]) -> None:
        st, reg = self.st, self.reg
        if mnem == "MODESET":
            self.supervisor = True
        elif mnem == "L":
            reg[int(ops[0])] = st.word(self._ea(ops[1]))
        elif mnem == "LA":
            reg[int(ops[0])] = self._ea(ops[1]) & 0xFFFFFFFF
        elif mnem == "ST":
            st.putword(self._ea(ops[1]), reg[int(ops[0])])
        elif mnem == "STM":
            r1, r2, ea = int(ops[0]), int(ops[1]), self._ea(ops[2])
            i = 0
            while True:
                st.putword(ea + i * 4, reg[(r1 + i) & 15]); 
                if (r1 + i) & 15 == r2:
                    break
                i += 1
        elif mnem == "LM":
            r1, r2, ea = int(ops[0]), int(ops[1]), self._ea(ops[2])
            i = 0
            while True:
                reg[(r1 + i) & 15] = st.word(ea + i * 4)
                if (r1 + i) & 15 == r2:
                    break
                i += 1
        elif mnem in ("NI", "OI", "XI"):
            ea, imm = self._ea(ops[0]), _imm(ops[1])
            b = st.read(ea, 1)[0]
            b = (b & imm) if mnem == "NI" else (b | imm) if mnem == "OI" else (b ^ imm)
            st.write(ea, bytes([b & 0xFF]))
        elif mnem == "XR":
            reg[int(ops[0])] ^= reg[int(ops[1])]
        elif mnem == "BALR":
            if ops and int(ops[1]) != 0:
                pass                                     # branch target ignored in the lab
        # BR handled in run(); unknown mnemonics are ignored (macros/no-ops)


def assemble_and_run(source: str, storage, r13: Optional[int] = None) -> S390:
    """Assemble and execute HLASM against the storage image; returns the S390 state."""
    return S390(storage, r13=r13).run(source)
