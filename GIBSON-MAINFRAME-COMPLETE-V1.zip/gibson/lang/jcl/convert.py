"""JCL converter (spec J2): symbolic substitution + PROC expansion.

Transforms raw JCL into *effective* JCL: resolves ``&symbol`` references and
``SET``, expands instream and cataloged PROCs, applies EXEC symbol overrides and
``//procstep.ddname`` DD overrides.  A text->text pass (as z/OS conversion is),
so the scanner downstream is unchanged.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from . import split_params, _top_split

_SYM = re.compile(r"&([A-Za-z@#$][A-Za-z0-9@#$]*)\.?")


def _subst(text: str, symbols: Dict[str, str]) -> str:
    def one(m):
        name = m.group(1).upper()
        return symbols[name] if name in symbols else m.group(0)
    return _SYM.sub(one, text)


def _units(lines: List[str]) -> List[Tuple[str, List[str]]]:
    """Group each // statement with any following in-stream data lines."""
    units = []
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("//"):
            data = []
            j = i + 1
            while j < len(lines) and not lines[j].startswith("//"):
                data.append(lines[j]); j += 1
            units.append((ln, data))
            i = j
        else:
            i += 1
    return units


def _join_continuations(lines: List[str]) -> List[str]:
    out, i = [], 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("//") and not ln.startswith("//*"):
            body = ln
            while body.rstrip().endswith(",") and i + 1 < len(lines) \
                    and lines[i + 1].startswith("//") and not lines[i + 1].startswith("//*"):
                i += 1
                body = body.rstrip() + lines[i][2:].strip()
            out.append(body)
        else:
            out.append(ln)
        i += 1
    return out


def _parse_stmt(line: str):
    m = re.match(r"//(\S*)\s+(\S+)\s*(.*)", line)
    if not m:
        return None
    return m.group(1), m.group(2).upper(), m.group(3)


def convert(jcl_text: str, proclib: Optional[Dict[str, str]] = None,
            sysuid: str = "IBMUSER") -> str:
    proclib = dict(proclib or {})
    raw = _join_continuations(jcl_text.splitlines())

    # pass 1: pull out instream PROC definitions + SET symbols
    symbols: Dict[str, str] = {"SYSUID": sysuid, "SYSNODE": "GIBSON"}
    main: List[str] = []
    i = 0
    while i < len(raw):
        ln = raw[i]
        st = _parse_stmt(ln) if ln.startswith("//") and not ln.startswith("//*") else None
        if st and st[1] == "PROC" and st[0]:
            name = st[0].upper()
            body = []
            defaults = split_params(st[2])
            i += 1
            while i < len(raw):
                s2 = _parse_stmt(raw[i]) if raw[i].startswith("//") else None
                if s2 and s2[1] == "PEND":
                    break
                body.append(raw[i]); i += 1
            proclib[name] = "\n".join(body)
            proclib[name + "\0DEF"] = defaults  # stash defaults
        elif st and st[1] == "SET":
            for k, v in split_params(st[2]).items():
                if not k.startswith("_POS"):
                    symbols[k] = v.strip()
        else:
            main.append(ln)
        i += 1

    # pass 2: expand
    out: List[str] = []
    units = _units(main)
    idx = 0
    while idx < len(units):
        line, data = units[idx]
        st = _parse_stmt(line)
        if st and st[1] == "EXEC":
            params = split_params(st[2])
            procname = None
            if "PGM" in params:
                out.append(_subst(line, symbols))
                out.extend(_subst(d, symbols) for d in data)
                idx += 1
                continue
            if "PROC" in params:
                procname = params["PROC"].strip().upper()
            elif "_POS0" in params:
                procname = params["_POS0"].strip().upper()
            if procname and procname in proclib:
                idx = _expand_proc(st[0] or "STEP", procname, params, proclib,
                                   symbols, units, idx, out, sysuid)
                continue
        out.append(_subst(line, symbols))
        out.extend(_subst(d, symbols) for d in data)
        idx += 1
    return "\n".join(out)


def _expand_proc(stepname, procname, exec_params, proclib, base_symbols,
                 units, idx, out, sysuid) -> int:
    # symbol table: system + PROC defaults + SET + EXEC overrides (EXEC wins)
    sym = dict(base_symbols)
    defaults = proclib.get(procname + "\0DEF", {})
    for k, v in defaults.items():
        if not k.startswith("_POS"):
            sym[k] = v.strip()
    for k, v in exec_params.items():
        if k not in ("PROC",) and not k.startswith("_POS"):
            sym[k] = v.strip()

    # collect DD overrides that follow this EXEC: name has a '.'
    overrides: Dict[str, Tuple[str, List[str]]] = {}
    j = idx + 1
    while j < len(units):
        l2, d2 = units[j]
        s2 = _parse_stmt(l2)
        if not s2:
            break
        nm, op = s2[0], s2[1]
        if op == "EXEC" or "." not in nm:
            break
        overrides[nm.upper()] = (l2, d2)   # e.g. COPY.SYSUT1
        j += 1

    # emit the PROC body, substituting symbols and applying overrides
    body_units = _units(proclib[procname].splitlines())
    cur_procstep = None
    for l2, d2 in body_units:
        s2 = _parse_stmt(l2)
        if s2 and s2[1] == "EXEC":
            cur_procstep = s2[0].upper()
            out.append(_subst(l2, sym))
        elif s2 and s2[1] == "DD":
            key = f"{cur_procstep}.{s2[0].upper()}" if cur_procstep else s2[0].upper()
            if key in overrides:
                ol, od = overrides.pop(key)
                # re-emit override DD under its plain ddname
                newname = "//" + s2[0]
                rest = ol.split(None, 1)[1] if len(ol.split(None, 1)) > 1 else "DD"
                out.append(_subst(f"{newname:<9} {rest}", sym))
                out.extend(_subst(x, sym) for x in od)
            else:
                out.append(_subst(l2, sym))
                out.extend(_subst(x, sym) for x in d2)
        else:
            out.append(_subst(l2, sym))
            out.extend(_subst(x, sym) for x in d2)
    # any overrides that ADD new DDs
    for key, (ol, od) in overrides.items():
        ddname = key.split(".", 1)[1]
        rest = ol.split(None, 1)[1] if len(ol.split(None, 1)) > 1 else "DD"
        out.append(_subst(f"//{ddname:<7} {rest}", sym))
        out.extend(_subst(x, sym) for x in od)
    return j
