"""JCL allocation + programs + initiator (spec J3/J4/J5 slice)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import DD, Step, Job, scan, split_params, _top_split
from gibson.lang.hostsvc import HostServices


@dataclass
class Alloc:
    ddname: str
    dsn: Optional[str] = None
    instream: Optional[List[str]] = None
    sysout: Optional[str] = None
    dummy: bool = False
    disp: tuple = ("SHR", "KEEP", "KEEP")

    def records(self, host: HostServices) -> List[str]:
        if self.instream is not None:
            return list(self.instream)
        if self.dsn:
            try:
                return host.read_dataset(self.dsn)
            except Exception:
                return []
        return []


def _parse_disp(v: str):
    if not v:
        return ("SHR", "KEEP", "KEEP")
    inner = v.strip()
    if inner.startswith("("):
        inner = inner[1:-1]
    parts = [p.strip().upper() for p in _top_split(inner)]
    status = parts[0] if parts and parts[0] else "SHR"
    normal = parts[1] if len(parts) > 1 and parts[1] else ("DELETE" if status == "NEW" else "KEEP")
    abnormal = parts[2] if len(parts) > 2 and parts[2] else normal
    return (status, normal, abnormal)


def allocate_step(step: Step, host: HostServices, log: List[str]) -> Dict[str, Alloc]:
    allocs: Dict[str, Alloc] = {}
    host.dd.clear()
    for dd in step.dds:
        a = Alloc(ddname=dd.name)
        p = dd.params
        if dd.dummy:
            a.dummy = True
        elif dd.instream is not None:
            a.instream = dd.instream
        elif "SYSOUT" in p:
            a.sysout = p["SYSOUT"].strip("*") or "A"
        elif "DSN" in p or "DSNAME" in p:
            raw = (p.get("DSN") or p.get("DSNAME")).strip().strip("'").upper()
            a.dsn = host.resolve_gdg(raw)
            a.disp = _parse_disp(p.get("DISP", ""))
            if a.disp[0] == "NEW":
                host.backend.alloc(a.dsn)
            host.dd[dd.name] = a.dsn
        allocs[dd.name] = a
    return allocs


# ---- program registry ----
REGISTRY = {}

def program(name):
    def deco(fn):
        REGISTRY[name.upper()] = fn
        return fn
    return deco


@program("IEFBR14")
def _iefbr14(allocs, parm, host, log):
    return 0


@program("IEBGENER")
def _iebgener(allocs, parm, host, log):
    src = allocs.get("SYSUT1")
    dst = allocs.get("SYSUT2")
    if not src or not dst:
        log.append("IEBGENER: SYSUT1/SYSUT2 required")
        return 12
    recs = src.records(host)
    if dst.dsn:
        host.write_dataset(dst.dsn, recs, disp="OLD")
    log.append(f"IEB352I {len(recs)} RECORDS COPIED")
    return 0


@program("IDCAMS")
def _idcams(allocs, parm, host, log):
    sysin = allocs.get("SYSIN")
    ctl = sysin.records(host) if sysin else []
    rc = 0
    text = " ".join(l.strip() for l in ctl if l.strip() and not l.strip().startswith("/*"))
    # split into commands on typical verbs
    for cmd in re.split(r"(?i)(?=\bDELETE\b|\bREPRO\b|\bDEFINE\b|\bLISTCAT\b)", text):
        cmd = cmd.strip()
        if not cmd:
            continue
        verb = cmd.split()[0].upper()
        if verb == "DELETE":
            dsn = cmd.split()[1].strip().strip("'").upper()
            host.backend.delete(dsn)
            log.append(f"IDC0550I ENTRY (A) {dsn} DELETED")
        elif verb == "REPRO":
            infn = _kw(cmd, "INFILE") or _kw(cmd, "INDATASET")
            outfn = _kw(cmd, "OUTFILE") or _kw(cmd, "OUTDATASET")
            indsn = host.dd_to_dsn(infn) if infn and infn in host.dd else (infn.strip("'").upper() if infn else None)
            outdsn = host.dd_to_dsn(outfn) if outfn and outfn in host.dd else (outfn.strip("'").upper() if outfn else None)
            if indsn and outdsn:
                recs = host.read_dataset(indsn)
                host.write_dataset(outdsn, recs, disp="OLD")
                log.append(f"IDC0005I NUMBER OF RECORDS PROCESSED WAS {len(recs)}")
            else:
                rc = 12
        elif verb == "LISTCAT":
            log.append("IDCAMS  LISTCAT OUTPUT (simulated)")
        elif verb == "DEFINE":
            mname = re.search(r"NAME\(([^)]+)\)", cmd, re.I)
            mlim = re.search(r"LIMIT\((\d+)\)", cmd, re.I)
            if mname and re.search(r"\bGDG\b", cmd, re.I):
                host.define_gdg(mname.group(1).strip(), int(mlim.group(1)) if mlim else 255)
                log.append(f"IDC0512I NAME GENERATED-({mname.group(1).strip().upper()})")
            log.append("IDC0001I FUNCTION COMPLETED, HIGHEST CONDITION CODE WAS 0")
    log.append(f"IDC0002I IDCAMS PROCESSING COMPLETE. MAXIMUM CONDITION CODE WAS {rc}")
    return rc


@program("SORT")
def _sort(allocs, parm, host, log):
    si = allocs.get("SORTIN")
    so = allocs.get("SORTOUT")
    if not si or not so:
        log.append("ICE052I  SORTIN/SORTOUT REQUIRED"); return 16
    recs = si.records(host)
    ctl = " ".join(l.strip() for l in (allocs["SYSIN"].records(host) if "SYSIN" in allocs else [])
                   if l.strip() and not l.strip().startswith("/*"))
    out = recs[:]
    mcopy = re.search(r"SORT\s+FIELDS\s*=\s*COPY", ctl, re.I)
    mflds = re.search(r"SORT\s+FIELDS\s*=\s*\(([^)]*)\)", ctl, re.I)
    if mcopy:
        pass
    elif mflds:
        specs = [s.strip() for s in mflds.group(1).split(",") if s.strip()]
        fields = []
        for i in range(0, len(specs), 4):
            pos = int(specs[i]); ln = int(specs[i + 1])
            fmt = specs[i + 2].upper() if i + 2 < len(specs) else "CH"
            d = specs[i + 3].upper() if i + 3 < len(specs) else "A"
            fields.append((pos, ln, fmt, d))

        def _keyval(rec, pos, ln, fmt):
            sub = rec[pos - 1: pos - 1 + ln]
            if fmt in ("ZD", "PD", "BI", "FI"):
                digits = re.sub(r"\D", "", sub) or "0"
                return int(digits)
            return sub
        # stable multi-key: sort by least-significant field first
        for pos, ln, fmt, d in reversed(fields):
            out.sort(key=lambda r, p=pos, l=ln, f=fmt: _keyval(r, p, l, f), reverse=(d == "D"))
    host.write_dataset(so.dsn, out, disp="OLD")
    log.append(f"ICE054I  RECORDS SORTED - PROCESSED: {len(recs)},  SORTED OUT: {len(out)}")
    log.append("ICE000I  SORT PROCESSING COMPLETE")
    return 0
REGISTRY["ICEMAN"] = REGISTRY["SORT"]
REGISTRY["SYNCSORT"] = REGISTRY["SORT"]


@program("IKJEFT01")
def _ikjeft01(allocs, parm, host, log):
    from gibson.lang.rexx.interp import RexxEngine
    sysin = allocs.get("SYSTSIN")
    lines = sysin.records(host) if sysin else []
    text = "\n".join(lines)
    stripped = text.strip()
    rc = 0
    if stripped.startswith("/*"):          # a REXX exec in-stream
        eng = RexxEngine(host)
        res = eng.run(text)
        log.extend(res.output)
        rc = int(res.rc or 0)
    else:                                   # TSO commands, one per line
        for ln in lines:
            ln = ln.strip()
            if not ln or ln.startswith("/*"):
                continue
            r, out = host.tso(ln)
            log.extend(out)
            rc = r
    return rc
REGISTRY["IKJEFT1B"] = REGISTRY["IKJEFT01"]


def _kw(cmd, key):
    m = re.search(rf"{key}\(([^)]+)\)", cmd, re.I)
    return m.group(1).strip() if m else None


# ---- initiator ----
class JobResult:
    def __init__(self, job: Job):
        self.job = job
        self.steps = []          # (name, pgm, rc, sysout_lines)
        self.max_rc = 0

    def sysout(self):
        out = []
        for name, pgm, rc, lines in self.steps:
            out.append(f"=== {name} PGM={pgm} RC={rc} ===")
            out.extend(lines)
        return out


class JclEngine:
    def __init__(self, host: HostServices, proclib=None, cobol_pgms=None):
        self.host = host
        self.proclib = proclib or {}
        self.cobol_pgms = cobol_pgms or {}     # PGM name -> COBOL source (a "load library")

    def submit(self, jcl_text: str) -> JobResult:
        from .convert import convert
        effective = convert(jcl_text, self.proclib, self.host.sysuid)
        job = scan(effective)
        result = JobResult(job)
        result.effective_jcl = effective
        prior_rcs = {}
        any_abend = False
        abend_steps = set()
        for step in job.steps:
            log: List[str] = []
            if self._cond_bypass(step, prior_rcs, any_abend) or \
                    self._if_bypass(step, prior_rcs, any_abend, abend_steps):
                log.append(f"IEF272I {step.name} - STEP WAS NOT EXECUTED")
                step.rc = None
                result.steps.append((step.name, step.pgm.upper(), "FLUSH", log))
                continue
            allocs = allocate_step(step, self.host, log)
            pgm = step.pgm.upper()
            handler = REGISTRY.get(pgm)
            abended = False
            if handler is None and pgm in self.cobol_pgms:
                rc = self._run_cobol(pgm, log)
            elif handler is None:
                log.append(f"IEF142I {step.name} - PGM={pgm} SIMULATED (no module)")
                rc = 0
            else:
                try:
                    rc = handler(allocs, step.params.get("PARM", ""), self.host, log)
                except Exception as e:
                    log.append(f"ABEND in {pgm}: {e}")
                    rc = 12; abended = True
            step.rc = rc
            if abended:
                any_abend = True
                abend_steps.add(step.name)
            prior_rcs[step.name] = rc
            self._process_disp(step, allocs)
            result.steps.append((step.name, pgm, rc, log))
            result.max_rc = max(result.max_rc, rc)
        self.host.rollin_gdg()
        return result

    def _if_bypass(self, step, prior_rcs, any_abend, abend_steps) -> bool:
        for cond, in_else in step.if_context:
            res = self._eval_ifcond(cond, prior_rcs, any_abend, abend_steps)
            if in_else:
                res = not res
            if not res:
                return True
        return False

    def _eval_ifcond(self, cond, prior_rcs, any_abend, abend_steps) -> bool:
        for or_part in cond.split("|"):
            terms = [t.strip() for t in or_part.split("&") if t.strip()]
            if terms and all(self._eval_ifterm(t, prior_rcs, any_abend, abend_steps) for t in terms):
                return True
        return False

    def _eval_ifterm(self, term, prior_rcs, any_abend, abend_steps) -> bool:
        up = term.upper().strip()
        neg = False
        if up.startswith("NOT "):
            neg = True; up = up[4:].strip()
        def _r(v):
            return (not v) if neg else v
        if up == "ABEND":
            return _r(any_abend)
        m = re.fullmatch(r"([A-Z0-9#@$]+)\.ABEND", up)
        if m:
            return _r(m.group(1) in abend_steps)
        m = re.fullmatch(r"([A-Z0-9#@$]+)\.RUN", up)
        if m:
            return _r(m.group(1) in prior_rcs)
        m = re.fullmatch(r"(?:([A-Z0-9#@$]+)\.)?RC\s*(<>|>=|<=|¬=|=|>|<|NE|EQ|GT|LT|GE|LE)\s*(\d+)", up)
        if m:
            sname, op, num = m.group(1), m.group(2), int(m.group(3))
            rc = prior_rcs.get(sname) if sname else (list(prior_rcs.values())[-1] if prior_rcs else None)
            if rc is None:
                return _r(False)
            op = {"=": "EQ", "<>": "NE", "¬=": "NE", ">": "GT", "<": "LT", ">=": "GE", "<=": "LE"}.get(op, op)
            res = {"EQ": rc == num, "NE": rc != num, "GT": rc > num,
                   "LT": rc < num, "GE": rc >= num, "LE": rc <= num}.get(op, False)
            return _r(res)
        return True

    def _cond_bypass(self, step, prior_rcs, any_abend) -> bool:
        cond = step.params.get("COND")
        if not cond:
            return False
        up = cond.upper().strip().strip("(").strip(")").strip()
        if up == "EVEN" or up == "ONLY":
            return False        # these modify abend behaviour, handled elsewhere
        for code, op, sname in self._parse_cond(cond):
            if sname and sname in prior_rcs:
                rcs = [prior_rcs[sname]]
            elif sname:
                rcs = []        # named step didn't run
            else:
                rcs = list(prior_rcs.values())
            for rc in rcs:
                if isinstance(rc, int) and self._cmp(code, op, rc):
                    return True
        return False

    @staticmethod
    def _parse_cond(cond):
        conds = []
        inner = cond.strip()
        # find all (code,op[,step]) groups
        groups = re.findall(r"\(([^()]+)\)", inner)
        if not groups:
            groups = [inner]
        for g in groups:
            parts = [p.strip() for p in g.split(",")]
            if len(parts) >= 2 and parts[0].isdigit():
                code = int(parts[0]); op = parts[1].upper()
                sname = parts[2].upper() if len(parts) > 2 else None
                conds.append((code, op, sname))
        return conds

    @staticmethod
    def _cmp(code, op, rc) -> bool:
        return {"GT": code > rc, "GE": code >= rc, "LT": code < rc,
                "LE": code <= rc, "EQ": code == rc, "NE": code != rc}.get(op, False)

    def _run_cobol(self, pgm, log):
        from gibson.lang.cobol.interp import Cobol
        from gibson.lang.cobol.lexer import tokenize
        from gibson.lang.cobol.parser import Parser
        try:
            prog = Parser(tokenize(self.cobol_pgms[pgm])).parse()
            out = Cobol(prog, self.host).run()
            log.extend(out)
            return 0
        except Exception as e:
            log.append(f"COBOL ABEND in {pgm}: {e}")
            return 12

    def _process_disp(self, step, allocs):
        for a in allocs.values():
            if not a.dsn:
                continue
            normal = a.disp[1]
            if normal == "DELETE":
                self.host.backend.delete(a.dsn)


def run(jcl_text: str, host: Optional[HostServices] = None) -> JobResult:
    from gibson.lang.hostsvc import MemoryBackend
    host = host or HostServices(MemoryBackend(), "IBMUSER")
    return JclEngine(host).submit(jcl_text)
