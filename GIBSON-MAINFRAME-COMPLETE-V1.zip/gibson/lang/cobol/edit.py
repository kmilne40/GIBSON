"""COBOL numeric-edited PICTURE formatting (spec C3).

Common teaching set: zero suppression (Z), check protection (*), digit (9),
comma and decimal insertion, fixed leading currency ($), fixed/trailing sign
(+/-), trailing CR/DB, B/0/ / insertion. Floating currency (multiple $) is
approximated as leading suppression with one fixed symbol (correct width,
readable), sufficient for the training material's report formatting.
"""
from __future__ import annotations
import re
from decimal import Decimal, ROUND_HALF_UP


def _expand(s):
    return re.sub(r'([9ZX*A])\((\d+)\)', lambda m: m.group(1)*int(m.group(2)), s)


def is_edited(spec: str) -> bool:
    s = spec.upper()
    if "X" in s or "A" in s:
        return False
    return any(c in s for c in "Z*,$+/B") or "." in s or "-" in s \
        or "CR" in s or "DB" in s


def _normalise_floats(intpic: str):
    if intpic.count("$") > 1:
        first = intpic.index("$")
        chars = list(intpic)
        for i, c in enumerate(chars):
            if c == "$" and i != first:
                chars[i] = "Z"
        return "".join(chars)
    return intpic


def format_edited(value: Decimal, pic: str) -> str:
    pic = _expand(pic.upper())
    neg = value < 0
    v = abs(Decimal(value))
    trailing = ""
    if pic.endswith("CR"):
        trailing = "CR" if neg else "  "; pic = pic[:-2]
    elif pic.endswith("DB"):
        trailing = "DB" if neg else "  "; pic = pic[:-2]
    elif pic.endswith("-"):
        trailing = "-" if neg else " "; pic = pic[:-1]
    elif pic.endswith("+"):
        trailing = "-" if neg else "+"; pic = pic[:-1]
    intpic, dot, fracpic = pic.partition(".")
    intpic = _normalise_floats(intpic)
    fracn = sum(1 for c in fracpic if c in "9Z*")
    intn = sum(1 for c in intpic if c in "9Z*")
    scaled = int((v * (Decimal(10) ** fracn)).to_integral_value(ROUND_HALF_UP))
    alldig = str(scaled).rjust(intn + fracn, "0")
    intdig = alldig[:intn]
    fracdig = alldig[intn:] if fracn else ""
    star = '*' in intpic
    out = []
    di = 0
    suppress = True
    for ch in intpic:
        if ch == "9":
            out.append(intdig[di]); di += 1; suppress = False
        elif ch in "Z*":
            d = intdig[di]; di += 1
            if suppress and d == "0":
                out.append(" " if ch == "Z" else "*")
            else:
                suppress = False; out.append(d)
        elif ch == "$":
            out.append("$")
        elif ch in "+-":
            out.append("-" if neg else ("+" if ch == "+" else " "))
        elif ch == ",":
            out.append("," if not suppress else ("*" if star else " "))
        elif ch == "B":
            out.append(" ")
        elif ch == "0":
            out.append("0")
        elif ch == "/":
            out.append("/")
    body = "".join(out)
    if fracn:
        body += "." + fracdig
    return body + trailing
