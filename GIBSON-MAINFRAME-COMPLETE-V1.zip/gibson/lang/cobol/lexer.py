"""COBOL lexer (spec C1). Fixed-form aware (drops seq cols 1-6 and 73+, col-7
comment indicator), tokenizes words, numeric/alphanumeric literals, punctuation.
"""
from __future__ import annotations
import re
from dataclasses import dataclass

WORD, NUM, STR, DOT, PUNCT, PIC, EOF = "WORD", "NUM", "STR", "DOT", "PUNCT", "PIC", "EOF"
EXECBLOCK = "EXECBLOCK"


@dataclass
class Tok:
    kind: str
    value: str


def _normalize(line: str) -> str:
    if len(line) >= 7 and line[6] in "*/":
        return ""                                  # comment line
    # strip cols 73-80 only if they look like a sequence number area
    if len(line) > 72 and all(c.isdigit() or c == " " for c in line[72:80]):
        line = line[:72]
    if len(line) >= 6 and all(c == " " or c.isdigit() for c in line[:6]):
        line = line[6:]                            # drop sequence area
    return line


def tokenize(src: str):
    text = "\n".join(_normalize(l) for l in src.splitlines())
    toks = []
    i, n = 0, len(text)
    pic_next = False
    while i < n:
        c = text[i]
        if c in " \t\r\n":
            i += 1; continue
        # capture a PICTURE character-string as one token
        if pic_next:
            j = i
            while j < n and text[j] not in " \t\r\n":
                j += 1
            chunk = text[i:j]
            if chunk.upper() == "IS":
                i = j; continue                    # skip optional IS, stay in pic mode
            trailing_dot = False
            if chunk.endswith(".") and not chunk.endswith(".."):
                # trailing '.' that ends the clause (decimal points sit between digits)
                if len(chunk) >= 2 and chunk[-2] not in "9ZX*AV":
                    chunk = chunk[:-1]; trailing_dot = True
                elif chunk.count(".") > 1:
                    chunk = chunk[:-1]; trailing_dot = True
                else:
                    # ambiguous: a lone trailing '.' after a digit => clause terminator
                    # keep internal decimal only if pattern like 9.9 (dot between digits)
                    core = chunk[:-1]
                    if core and core[-1] in "9ZX*A" and "." not in core:
                        chunk = core; trailing_dot = True
            toks.append(Tok(PIC, chunk))
            pic_next = False
            i = j
            if trailing_dot:
                toks.append(Tok(DOT, "."))
            continue
        if c in "'\"":
            q = c; j = i + 1; buf = []
            while j < n and text[j] != q:
                buf.append(text[j]); j += 1
            toks.append(Tok(STR, "".join(buf))); i = j + 1; continue
        if c.isdigit() or (c == "." and i + 1 < n and text[i + 1].isdigit()):
            j = i; seen_dot = False
            while j < n and (text[j].isdigit() or (text[j] == "." and not seen_dot
                             and j + 1 < n and text[j + 1].isdigit())):
                if text[j] == ".":
                    seen_dot = True
                j += 1
            toks.append(Tok(NUM, text[i:j])); i = j; continue
        if c.isalpha():
            j = i
            while j < n and (text[j].isalnum() or text[j] in "-_"):
                j += 1
            w = text[i:j].upper()
            if w == "EXEC":
                # Capture the whole EXEC ... END-EXEC block as one raw token so the
                # embedded SQL text (dots, quotes, spacing) survives verbatim -
                # exactly how a DB2 precompiler extracts it.
                m = re.search(r"END-EXEC", text[j:], re.I)
                if m:
                    inner = text[j:j + m.start()].strip()
                    toks.append(Tok(EXECBLOCK, inner))
                    i = j + m.end()
                    if i < n and text[i] == "." and (i + 1 >= n or text[i + 1] in " \t\r\n"):
                        toks.append(Tok(DOT, ".")); i += 1
                    continue
            toks.append(Tok(WORD, w)); i = j
            if w in ("PIC", "PICTURE"):
                pic_next = True
            continue
        if c == ".":
            if i + 1 >= n or text[i + 1] in " \t\r\n":
                toks.append(Tok(DOT, ".")); i += 1; continue
            i += 1; continue
        toks.append(Tok(PUNCT, c)); i += 1
    toks.append(Tok(EOF, ""))
    return toks
