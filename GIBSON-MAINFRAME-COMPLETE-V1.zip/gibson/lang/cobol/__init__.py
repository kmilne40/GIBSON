"""GIBSON COBOL subset interpreter (C1-C3)."""
from .interp import Cobol, run
