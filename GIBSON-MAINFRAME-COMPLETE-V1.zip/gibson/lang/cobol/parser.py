"""COBOL subset interpreter (spec C1-C3).

Parses the four divisions and interprets a teaching subset: WORKING-STORAGE and
FILE SECTION items with PIC/VALUE/group layout, and the common PROCEDURE verbs
(DISPLAY MOVE COMPUTE ADD/SUBTRACT/MULTIPLY/DIVIDE IF/ELSE PERFORM
OPEN/READ/WRITE/CLOSE STOP RUN).  File I/O maps SELECT...ASSIGN DDs to GIBSON
datasets through HostServices.
"""
from __future__ import annotations

import re
from decimal import Decimal, ROUND_DOWN
from typing import Dict, List, Optional

from .lexer import tokenize, WORD, NUM, STR, DOT, PUNCT, PIC, EOF


# ---------- data model ----------
class Pic:
    def __init__(self, spec: str):
        self.spec = spec.upper()
        from .edit import is_edited
        self.edited = is_edited(self.spec)
        self.raw = self._expand(self.spec)
        self.signed = self.spec.startswith("S")
        s = self.spec[1:] if self.signed else self.spec
        s = self._expand(s)
        self.alnum = ("X" in s or "A" in s) and not self.edited
        self.intdig = 0
        self.decdig = 0
        point = "V" if "V" in s else ("." if ("." in s and self.edited) else None)
        if point:
            a, b = s.split(point, 1)
            self.intdig = sum(1 for c in a if c in "9Z*")
            self.decdig = sum(1 for c in b if c in "9Z*")
        else:
            self.intdig = sum(1 for c in s if c in "9Z*") if not self.alnum else 0
        if self.alnum:
            self.size = len(s.replace("V", ""))
        elif self.edited:
            self.size = len(self.raw.replace("V", ""))
        else:
            self.size = self.intdig + self.decdig

    @staticmethod
    def _expand(s):
        # X(20) -> XXXXXXXXXXXXXXXXXXXX ; 9(5) -> 99999
        def rep(m):
            return m.group(1) * int(m.group(2))
        return re.sub(r"([9XAV])\((\d+)\)", rep, s)


class Item:
    def __init__(self, level, name, pic=None, value=None, occurs=1):
        self.level = level
        self.name = name
        self.pic: Optional[Pic] = Pic(pic) if pic else None
        self.children: List["Item"] = []
        self.occurs = occurs
        self.value = value          # Decimal | str
        if self.pic and value is None:
            self.value = Decimal(0) if not self.pic.alnum else ""
        self.occurs_values = None
        self.dims = 0                 # number of OCCURS dimensions (set by parser)
        self.cells = {}               # subscript-tuple -> value (for dims >= 1)
        if occurs > 1:
            default = Decimal(0) if (self.pic and not self.pic.alnum) else (self.value if self.value is not None else "")
            self.occurs_values = [default for _ in range(occurs)]

    def is_group(self):
        return bool(self.children)

    def size(self):
        if self.pic:
            return self.pic.size
        return sum(c.size() for c in self.children)

    # get/set raw string representation (for file records)
    def get_raw(self) -> str:
        if self.pic:
            return _format(self.value, self.pic)
        return "".join(c.get_raw() for c in self.children)

    def set_raw(self, s: str):
        if self.pic:
            self.value = _parse(s.ljust(self.pic.size)[: self.pic.size], self.pic)
        else:
            off = 0
            for c in self.children:
                sz = c.size()
                c.set_raw(s[off: off + sz]); off += sz


def _format(value, pic: Pic) -> str:
    if getattr(pic, "edited", False):
        from .edit import format_edited
        s = format_edited(Decimal(value if value != "" else 0), pic.raw)
        return s.ljust(pic.size)[: pic.size]
    if pic.alnum:
        return str(value).ljust(pic.size)[: pic.size]
    v = Decimal(value if value != "" else 0)
    neg = v < 0
    v = abs(v)
    scaled = int((v * (Decimal(10) ** pic.decdig)).to_integral_value(ROUND_DOWN))
    digits = str(scaled).rjust(pic.intdig + pic.decdig, "0")[-(pic.intdig + pic.decdig):]
    return digits


def _parse(s: str, pic: Pic):
    if pic.alnum:
        return s
    digits = re.sub(r"\D", "", s) or "0"
    v = Decimal(digits)
    if pic.decdig:
        v = v / (Decimal(10) ** pic.decdig)
    return v


def _display(value, pic: Optional[Pic]) -> str:
    if pic is None:
        return str(value).rstrip()
    if getattr(pic, "edited", False):
        from .edit import format_edited
        from decimal import Decimal as _D
        try:
            return format_edited(_D(str(value) if value != "" else 0), pic.raw)
        except Exception:
            return str(value)
    if pic.alnum:
        return str(value).rstrip()
    v = Decimal(value if value != "" else 0)
    if pic.decdig:
        q = Decimal(10) ** -pic.decdig
        return str(v.quantize(q))
    return str(int(v))


# ---------- parser ----------
class Parser:
    def __init__(self, toks):
        self.t = toks; self.i = 0

    def peek(self, k=0): return self.t[min(self.i + k, len(self.t) - 1)]
    def next(self):
        tok = self.t[self.i]
        if self.i < len(self.t) - 1:
            self.i += 1
        return tok
    def w(self): return self.peek().value

    def parse(self):
        prog = {"files": {}, "assign": {}, "ws": {}, "records": {}, "paras": {},
                "order": [], "conds": {}}
        toks = self.t
        # crude division slicing by keywords
        text_words = [t.value for t in toks]
        self._prog = prog
        self._parse_environment()
        self._parse_data()
        self._parse_procedure()
        return prog

    def _skip_to(self, *words):
        while self.peek().kind != EOF and self.w() not in words:
            self.next()

    def _parse_environment(self):
        self._skip_to("INPUT-OUTPUT", "DATA", "PROCEDURE", "EOF")
        # find SELECT ... ASSIGN TO dd
        while self.peek().kind != EOF and self.w() not in ("DATA", "PROCEDURE"):
            if self.w() == "SELECT":
                self.next(); fname = self.next().value
                self._skip_to("ASSIGN", "SELECT", "DATA", "PROCEDURE")
                if self.w() == "ASSIGN":
                    self.next()
                    if self.w() == "TO":
                        self.next()
                    dd = self.next().value
                    self._prog["assign"][fname] = dd.split("-")[-1]
                # skip to '.'
                while self.peek().kind not in (DOT, EOF) and self.w() not in ("SELECT", "DATA", "PROCEDURE"):
                    self.next()
            else:
                self.next()

    def _parse_data(self):
        self._skip_to("DATA", "PROCEDURE", "EOF")
        if self.w() != "DATA":
            return
        self.next()  # DATA
        self._skip_to("FILE", "WORKING-STORAGE", "PROCEDURE", "EOF")
        cur_file = None
        stack = []          # (level, item)
        while self.peek().kind != EOF and self.w() != "PROCEDURE":
            wd = self.w()
            if wd == "FD":
                self.next(); cur_file = self.next().value
                self._skip_dot()
            elif wd in ("FILE", "SECTION", "WORKING-STORAGE", "LOCAL-STORAGE", "LINKAGE"):
                self.next()
            elif self.peek().kind == NUM:
                item = self._parse_item()
                if item.level == 88:
                    parent = stack[-1][1].name if stack else None
                    self._prog["conds"][item.name] = (parent, item.cond_values)
                    continue
                while stack and stack[-1][0] >= item.level:
                    stack.pop()
                # dimensions = OCCURS ancestors (still on stack) + own OCCURS
                anc_dims = sum(1 for _lvl, it in stack if it.occurs > 1)
                item.dims = anc_dims + (1 if item.occurs > 1 else 0)
                if stack:
                    stack[-1][1].children.append(item)
                else:
                    if cur_file is not None:
                        self._prog["records"][cur_file] = item
                        cur_file = None
                    self._prog["order"].append(item)
                self._prog["ws"][item.name] = item     # register every named item
                stack.append((item.level, item))
            else:
                self.next()

    def _parse_item(self) -> Item:
        level = int(self.next().value)
        name = self.next().value if self.peek().kind == WORD else "FILLER"
        if level == 88:
            values = []
            while self.peek().kind not in (DOT, EOF):
                wd = self.w()
                if wd in ("VALUE", "VALUES", "ARE", "IS"):
                    self.next(); continue
                if wd in ("THRU", "THROUGH"):
                    self.next()
                    hi = self.next()
                    lo = values.pop() if values else ("", "")
                    values.append(("range", lo[1], hi.value))
                    continue
                t = self.next()
                if t.kind in (NUM, STR):
                    values.append(("val", t.value))
            self._skip_dot()
            it = Item(88, name)
            it.cond_values = values
            return it
        pic = None; value = None; occurs = 1
        while self.peek().kind not in (DOT, EOF):
            wd = self.w()
            if wd in ("PIC", "PICTURE"):
                self.next()
                if self.w() == "IS":
                    self.next()
                pic = self._read_pic()
            elif wd == "VALUE":
                self.next()
                if self.w() == "IS":
                    self.next()
                sign = ""
                if self.peek().kind == PUNCT and self.w() in "+-":
                    sign = self.next().value
                v = self.next()
                if v.kind == NUM:
                    value = Decimal(sign + v.value)
                else:
                    value = v.value
            elif wd == "OCCURS":
                self.next(); occurs = int(self.next().value)
                if self.w() == "TIMES":
                    self.next()
            elif wd in ("COMP", "COMP-3", "COMP-4", "BINARY", "PACKED-DECIMAL", "USAGE", "DISPLAY"):
                self.next()
            else:
                self.next()
        self._skip_dot()
        it = Item(level, name, pic, value, occurs)
        return it

    def _read_pic(self):
        return self.next().value            # lexer emits the picture as one PIC token

    def _register(self, item: Item):
        self._prog["ws"][item.name] = item
        self._prog["order"].append(item)

    def _parse_procedure(self):
        self._skip_to("PROCEDURE", "EOF")
        if self.w() != "PROCEDURE":
            return
        self.next()
        if self.w() == "DIVISION":
            self.next()
        while self.peek().kind not in (DOT, EOF):    # skip USING ... header
            self.next()
        self._skip_dot()
        para = "MAIN"
        self._prog["paras"][para] = []
        self._prog["main"] = para
        self._prog["order_paras"] = [para]
        prev_dot = True
        while self.peek().kind != EOF:
            if (prev_dot and self.peek().kind == WORD and self.peek(1).kind == DOT
                    and self.w() not in _VERBS and self.w() not in ("SECTION",)):
                para = self.next().value; self.next()
                self._prog["paras"].setdefault(para, [])
                self._prog["order_paras"].append(para)
                prev_dot = True
                continue
            tok = self.next()
            self._prog["paras"][para].append(tok)
            prev_dot = (tok.kind == DOT)


_VERBS = {"DISPLAY", "MOVE", "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE",
          "IF", "PERFORM", "OPEN", "READ", "WRITE", "CLOSE", "STOP", "ACCEPT",
          "GO", "CONTINUE", "INITIALIZE"}


# fallback for skipping dots
def _p_skip_dot(self):
    if self.peek().kind == DOT:
        self.next()
Parser._skip_dot = _p_skip_dot
