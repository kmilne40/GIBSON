"""COBOL interpreter runtime (spec C2-C3)."""
from __future__ import annotations

import re
from decimal import Decimal, ROUND_DOWN
from typing import Dict, List, Optional

from .lexer import tokenize, Tok, WORD, NUM, STR, DOT, PUNCT, PIC, EOF, EXECBLOCK
from .parser import Parser, Item, Pic, _display, _format


class Halt(Exception):
    pass


class _S:
    """Token stream cursor."""
    def __init__(self, toks):
        self.toks = toks; self.i = 0

    def peek(self, k=0):
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else Tok(EOF, "")

    def next(self):
        t = self.peek(); self.i += 1; return t

    def w(self):
        return self.peek().value

    def eof(self):
        return self.i >= len(self.toks)


_STOP = {"END-IF", "END-PERFORM", "END-READ", "END-EVALUATE", "ELSE", "WHEN"}


class Cobol:
    def __init__(self, prog, host=None):
        self.p = prog
        self.host = host
        self.out: List[str] = []
        self.paras = prog["paras"]
        self.paranames = set(prog.get("order_paras", []))
        self.conds = prog.get("conds", {})
        self.files: Dict[str, dict] = {}
        self.rc = 0
        # --- embedded SQL (EXEC SQL) state ---
        self.sql_cursors: Dict[str, str] = {}     # cursor -> declared query or STMT ref
        self.sql_prepared: Dict[str, str] = {}    # prepared stmt -> resolved SQL text
        self.sql_rs: Dict[str, list] = {}         # cursor -> open result set
        self.sql_pos: Dict[str, int] = {}         # cursor -> fetch position
        if "SQLCODE" not in self.p["ws"]:         # DB2 declares this via INCLUDE SQLCA
            self.p["ws"]["SQLCODE"] = Item(1, "SQLCODE", "S9(9)", Decimal(0))

    # ---------- item access ----------
    def item(self, name) -> Optional[Item]:
        return self.p["ws"].get(name)

    def _num(self, v) -> Decimal:
        if isinstance(v, Decimal):
            return v
        try:
            return Decimal(str(v).strip() or "0")
        except Exception:
            return Decimal(0)

    def operand(self, tok):
        if tok.kind == NUM:
            return Decimal(tok.value)
        if tok.kind == STR:
            return tok.value
        if tok.kind == WORD:
            it = self.item(tok.value)
            if it is not None:
                return it.value
            return tok.value
        return ""

    def setval(self, name, value):
        it = self.item(name)
        if it is None:
            return
        if it.pic and not it.pic.alnum:
            v = self._num(value)
            # truncate to declared decimals
            if it.pic.decdig is not None:
                q = Decimal(10) ** -it.pic.decdig
                v = v.quantize(q, rounding=ROUND_DOWN)
            it.value = v
        else:
            s = str(value)
            if it.pic:
                s = s.ljust(it.pic.size)[: it.pic.size]
            it.value = s

    # ---- OCCURS subscripting (N-dimensional) ----
    def _indexed_get(self, name, subs):
        it = self.item(name)
        if it is None:
            return name
        if subs and it.dims >= 1:
            default = Decimal(0) if (it.pic and not it.pic.alnum) else ""
            return it.cells.get(tuple(subs), default)
        return it.value

    def _indexed_set(self, name, subs, value):
        it = self.item(name)
        if it is None:
            return
        if subs and it.dims >= 1:
            if it.pic and not it.pic.alnum:
                v = self._num(value)
                if it.pic.decdig:
                    v = v.quantize(Decimal(10) ** -it.pic.decdig, rounding=ROUND_DOWN)
                it.cells[tuple(subs)] = v
            else:
                s = str(value)
                if it.pic:
                    s = s.ljust(it.pic.size)[: it.pic.size]
                it.cells[tuple(subs)] = s
        else:
            self.setval(name, value)

    def _split_subs(self, inner):
        """Split a subscript token list on top-level commas -> list of int subscripts."""
        subs, cur, depth = [], [], 0
        for tk in inner:
            if tk.kind == PUNCT and tk.value == "(":
                depth += 1; cur.append(tk)
            elif tk.kind == PUNCT and tk.value == ")":
                depth -= 1; cur.append(tk)
            elif tk.kind == PUNCT and tk.value == "," and depth == 0:
                subs.append(int(self._num(self._eval_expr(self._collapse(cur))))); cur = []
            else:
                cur.append(tk)
        if cur:
            subs.append(int(self._num(self._eval_expr(self._collapse(cur)))))
        return subs

    def _collapse(self, toks):
        out = []
        i = 0
        while i < len(toks):
            t = toks[i]
            if (t.kind == WORD and i + 1 < len(toks) and toks[i + 1].kind == PUNCT
                    and toks[i + 1].value == "(" and self.item(t.value) is not None
                    and self.item(t.value).dims >= 1):
                depth = 0; j = i + 2; inner = []
                while j < len(toks):
                    if toks[j].kind == PUNCT and toks[j].value == "(":
                        depth += 1; inner.append(toks[j])
                    elif toks[j].kind == PUNCT and toks[j].value == ")":
                        if depth == 0:
                            break
                        depth -= 1; inner.append(toks[j])
                    else:
                        inner.append(toks[j])
                    j += 1
                subs = tuple(self._split_subs(inner))
                val = self._indexed_get(t.value, subs)
                out.append(Tok(NUM, str(val)) if not isinstance(val, str) else Tok(STR, val))
                i = j + 1
            else:
                out.append(t); i += 1
        return out

    def _read_ref(self, s):
        """Read NAME or NAME(sub[,sub...]) -> (name, subs_tuple|None)."""
        name = s.next().value
        subs = None
        if s.peek().kind == PUNCT and s.w() == "(":
            s.next()
            inner = []; depth = 0
            while not s.eof():
                t = s.peek()
                if t.kind == PUNCT and t.value == "(":
                    depth += 1; inner.append(s.next())
                elif t.kind == PUNCT and t.value == ")":
                    if depth == 0:
                        break
                    depth -= 1; inner.append(s.next())
                else:
                    inner.append(s.next())
            if s.peek().kind == PUNCT and s.w() == ")":
                s.next()
            subs = tuple(self._split_subs(inner))
        return name, subs

    # ---------- run ----------
    def run(self):
        try:
            for pname in self.p.get("order_paras", [self.p["main"]]):
                self._exec_para(pname)
        except Halt:
            pass
        return self.out

    def _exec_para(self, name):
        s = _S(self.paras.get(name, []))
        self._exec_until(s, set())

    def _exec_until(self, s: _S, stops):
        while not s.eof():
            if s.peek().kind == DOT:
                s.next(); continue
            w = s.w()
            if w in stops:
                return
            self._exec_stmt(s)

    def _exec_stmt(self, s: _S):
        if s.peek().kind == EXECBLOCK:
            self._exec_sql(s.next().value)
            return
        verb = s.next().value
        fn = getattr(self, f"_v_{verb.replace('-', '_')}", None)
        if fn:
            fn(s)
        else:
            # unknown/no-op verb: skip its operands to next terminator
            while not s.eof() and s.peek().kind != DOT and s.w() not in _VERBS and s.w() not in _STOP:
                s.next()

    # ---------- embedded SQL (EXEC SQL ... END-EXEC) ----------
    def _sqlcode(self, n: int):
        self.setval("SQLCODE", Decimal(n))

    def _hostval(self, name: str) -> str:
        it = self.item(name.upper())
        if it is None:
            return ""
        return _display(it.value, it.pic).rstrip() if it.pic else str(it.value)

    def _bind_hostvars(self, text: str):
        """Replace :HOSTVAR with a bound '?' placeholder + collect the values, so the
        executor matches them as DATA (parameterised) - never parsing their content
        as SQL. This is what makes the static/host-variable form injection-proof."""
        params: List[str] = []
        def repl(m):
            params.append(self._hostval(m.group(1)))
            return "?"
        bound = re.sub(r":([A-Za-z][A-Za-z0-9_-]*)", repl, text)
        return bound, params

    def _sql_run(self, sql: str, params):
        if self.host is not None and hasattr(self.host, "sql"):
            try:
                return self.host.sql(sql, params, getattr(self.host, "userid", "IBMUSER")) or []
            except Exception:
                return []
        return []

    def _exec_sql(self, text: str):
        t = (text or "").strip()
        up = t.upper()
        if up.startswith("SQL"):
            t = t[3:].strip(); up = t.upper()
        elif up.startswith("CICS"):
            return  # EXEC CICS ... - out of scope for the SQL bridge (no-op)

        if up.startswith("INCLUDE") or up.startswith("WHENEVER") or up.startswith("BEGIN") or up.startswith("END DECLARE"):
            return
        if up.startswith("DECLARE") and "CURSOR" in up:
            m = re.match(r"DECLARE\s+(\S+)\s+CURSOR\s+FOR\s+(.*)", t, re.I | re.S)
            if m:
                self.sql_cursors[m.group(1).upper()] = m.group(2).strip()
            return
        if up.startswith("PREPARE"):
            m = re.match(r"PREPARE\s+(\S+)\s+FROM\s+:([A-Za-z][\w-]*)", t, re.I)
            if m:
                # dynamic SQL: the host string already contains whatever was concatenated
                self.sql_prepared[m.group(1).upper()] = self._hostval(m.group(2))
            return
        if up.startswith("OPEN"):
            m = re.match(r"OPEN\s+(\S+)", t, re.I)
            cur = m.group(1).upper() if m else ""
            decl = self.sql_cursors.get(cur, "")
            if decl.upper() in self.sql_prepared:            # cursor over a prepared (dynamic) stmt
                sql, params = self.sql_prepared[decl.upper()], []
            else:                                            # static cursor - bind host vars safely
                sql, params = self._bind_hostvars(decl)
            self.sql_rs[cur] = list(self._sql_run(sql, params))
            self.sql_pos[cur] = 0
            self._sqlcode(0)
            return
        if up.startswith("FETCH"):
            m = re.match(r"FETCH\s+(\S+)\s+INTO\s+(.*)", t, re.I | re.S)
            cur = m.group(1).upper() if m else ""
            targets = [x.strip().lstrip(":") for x in (m.group(2).split(",") if m else [])]
            rs = self.sql_rs.get(cur, []); pos = self.sql_pos.get(cur, 0)
            if pos < len(rs):
                self.sql_pos[cur] = pos + 1
                row = rs[pos]
                vals = list(row.values()) if isinstance(row, dict) else list(row)
                for tgt, val in zip(targets, vals):
                    self.setval(tgt.upper(), val)
                self._sqlcode(0)
            else:
                self._sqlcode(100)
            return
        if up.startswith("CLOSE"):
            m = re.match(r"CLOSE\s+(\S+)", t, re.I)
            if m:
                cur = m.group(1).upper()
                self.sql_rs.pop(cur, None); self.sql_pos.pop(cur, None)
            return
        if up.startswith("SELECT") and " INTO " in up:
            m = re.match(r"SELECT\s+(.*?)\s+INTO\s+(.*?)\s+FROM\s+(.*)", t, re.I | re.S)
            if m:
                targets = [x.strip().lstrip(":") for x in m.group(2).split(",")]
                bound, params = self._bind_hostvars("SELECT " + m.group(1) + " FROM " + m.group(3))
                rows = self._sql_run(bound, params)
                if rows:
                    row = rows[0]
                    vals = list(row.values()) if isinstance(row, dict) else list(row)
                    for tgt, val in zip(targets, vals):
                        self.setval(tgt.upper(), val)
                    self._sqlcode(0)
                else:
                    self._sqlcode(100)
            return
        # other SQL (INSERT/UPDATE/DELETE) - run and report success
        self._sql_run(t, [])
        self._sqlcode(0)

    def _read_expr_toks(self, s: _S):
        toks = []
        while not s.eof() and s.peek().kind != DOT and not _barrier(s.w()):
            toks.append(s.next())
        return self._collapse(toks)

    # ---------- verbs ----------
    def _v_DISPLAY(self, s):
        parts = []
        while not s.eof() and s.peek().kind != DOT and not _barrier(s.w()):
            if s.w() in ("WITH", "NO", "ADVANCING", "UPON", "CONSOLE"):
                s.next(); continue
            tok = s.peek()
            it = self.item(tok.value) if tok.kind == WORD else None
            if it is not None:
                name, idx = self._read_ref(s)
                parts.append(_display(self._indexed_get(name, idx), it.pic))
            else:
                tok = s.next()
                if tok.kind == NUM:
                    parts.append(tok.value)
                elif tok.kind == STR:
                    parts.append(tok.value)
        line = "".join(parts)
        self.out.append(line)
        if self.host is not None:
            try:
                self.host.console(line)
            except Exception:
                pass

    def _v_MOVE(self, s):
        t = s.peek()
        if t.kind in (NUM, STR):
            src = self.operand(s.next())
        else:
            sname, sidx = self._read_ref(s)
            src = self._indexed_get(sname, sidx)
        if s.w() == "TO":
            s.next()
        while not s.eof() and s.peek().kind == WORD and not _barrier(s.w()):
            tname, tidx = self._read_ref(s)
            self._indexed_set(tname, tidx, src)

    def _v_COMPUTE(self, s):
        tname, tidx = self._read_ref(s)
        if s.w() == "=" or s.w() == "EQUAL":
            s.next()
        toks = self._read_expr_toks(s)
        val = self._eval_expr(toks)
        self._indexed_set(tname, tidx, val)

    def _v_ADD(self, s):
        toks = self._read_expr_toks(s)
        self._arith_verb("ADD", toks)

    def _v_SUBTRACT(self, s):
        self._arith_verb("SUBTRACT", self._read_expr_toks(s))

    def _v_MULTIPLY(self, s):
        self._arith_verb("MULTIPLY", self._read_expr_toks(s))

    def _v_DIVIDE(self, s):
        self._arith_verb("DIVIDE", self._read_expr_toks(s))

    def _arith_verb(self, verb, toks):
        words = [t.value for t in toks]
        def val(tok):
            return self._num(self.operand(tok))
        if verb == "ADD":
            if "GIVING" in words:
                gi = words.index("GIVING")
                terms = [val(t) for t in toks[:gi] if t.value != "TO"]
                res = sum(terms)
                for t in toks[gi + 1:]:
                    self.setval(t.value, res)
            else:  # ADD a [b] TO t...
                ti = words.index("TO")
                addends = [val(t) for t in toks[:ti]]
                for t in toks[ti + 1:]:
                    self.setval(t.value, self._num(self.item(t.value).value) + sum(addends))
        elif verb == "SUBTRACT":
            fi = words.index("FROM")
            subs = [val(t) for t in toks[:fi]]
            rest = toks[fi + 1:]
            if "GIVING" in words:
                gi = words.index("GIVING")
                minuend = val(toks[fi + 1])
                res = minuend - sum(subs)
                for t in toks[gi + 1:]:
                    self.setval(t.value, res)
            else:
                for t in rest:
                    self.setval(t.value, self._num(self.item(t.value).value) - sum(subs))
        elif verb == "MULTIPLY":
            bi = words.index("BY")
            a = val(toks[0])
            if "GIVING" in words:
                gi = words.index("GIVING")
                res = a * val(toks[bi + 1])
                for t in toks[gi + 1:]:
                    self.setval(t.value, res)
            else:
                for t in toks[bi + 1:]:
                    self.setval(t.value, a * self._num(self.item(t.value).value))
        elif verb == "DIVIDE":
            a = val(toks[0])
            if "INTO" in words:
                ii = words.index("INTO")
                if "GIVING" in words:
                    gi = words.index("GIVING")
                    res = val(toks[ii + 1]) / a
                    for t in toks[gi + 1:]:
                        self.setval(t.value, res)
                else:
                    for t in toks[ii + 1:]:
                        self.setval(t.value, self._num(self.item(t.value).value) / a)
            elif "BY" in words:
                bi = words.index("BY")
                gi = words.index("GIVING")
                res = a / val(toks[bi + 1])
                for t in toks[gi + 1:]:
                    self.setval(t.value, res)

    def _v_IF(self, s):
        cond_toks = []
        while not s.eof() and s.w() != "THEN" and s.w() not in _VERBS and s.peek().kind != DOT:
            cond_toks.append(s.next())
        if s.w() == "THEN":
            s.next()
        truth = self._eval_cond(cond_toks)
        if truth:
            self._exec_until(s, {"ELSE", "END-IF"})
            if s.w() == "ELSE":
                s.next(); self._skip_block(s, {"END-IF"})
        else:
            self._skip_block(s, {"ELSE", "END-IF"})
            if s.w() == "ELSE":
                s.next(); self._exec_until(s, {"END-IF"})
        if s.w() == "END-IF":
            s.next()

    def _v_PERFORM(self, s):
        # out-of-line: PERFORM para-name [n TIMES | UNTIL cond]
        if s.peek().kind == WORD and s.w() in self.paranames:
            para = s.next().value
            if s.w() == "UNTIL":
                s.next(); cond = self._read_cond_toks(s)
                while not self._eval_cond(cond):
                    self._exec_para(para)
            elif s.peek().kind == NUM or (s.peek().kind == WORD and self.item(s.w())):
                n = int(self._num(self.operand(s.next())))
                if s.w() == "TIMES":
                    s.next()
                for _ in range(n):
                    self._exec_para(para)
            else:
                self._exec_para(para)
            return
        # inline PERFORM ... END-PERFORM
        mode = None; var = frm = by = None; cond = None; n = None
        if s.w() == "VARYING":
            s.next(); var = s.next().value
            if s.w() == "FROM":
                s.next()
            frm = self.operand(s.next())
            if s.w() == "BY":
                s.next(); by = self.operand(s.next())
            if s.w() == "UNTIL":
                s.next(); cond = self._read_cond_toks(s)
            mode = "VARYING"
        elif s.w() == "UNTIL":
            s.next(); cond = self._read_cond_toks(s); mode = "UNTIL"
        elif s.peek().kind == NUM:
            n = int(self._num(self.operand(s.next())))
            if s.w() == "TIMES":
                s.next()
            mode = "TIMES"
        body_start = s.i
        # execute loop by re-running the body slice
        if mode == "TIMES":
            for _ in range(n):
                s.i = body_start; self._exec_until(s, {"END-PERFORM"})
        elif mode == "UNTIL":
            while not self._eval_cond(cond):
                s.i = body_start; self._exec_until(s, {"END-PERFORM"})
        elif mode == "VARYING":
            self.setval(var, frm)
            while not self._eval_cond(cond):
                s.i = body_start; self._exec_until(s, {"END-PERFORM"})
                self.setval(var, self._num(self.item(var).value) + self._num(by))
        else:
            self._exec_until(s, {"END-PERFORM"})
        # ensure cursor past END-PERFORM
        s.i = body_start
        self._skip_block(s, {"END-PERFORM"})
        if s.w() == "END-PERFORM":
            s.next()

    def _v_EVALUATE(self, s):
        subj_toks = []
        while not s.eof() and s.w() != "WHEN" and s.peek().kind != DOT and s.w() != "END-EVALUATE":
            subj_toks.append(s.next())
        is_bool = len(subj_toks) == 1 and subj_toks[0].value in ("TRUE", "FALSE")
        subject = subj_toks[0].value if is_bool else self._operand_span(subj_toks)
        matched = False
        while s.w() == "WHEN":
            s.next()
            if s.w() == "OTHER":
                s.next()
                if matched:
                    self._skip_block(s, {"WHEN", "END-EVALUATE"})
                else:
                    self._exec_until(s, {"WHEN", "END-EVALUATE"}); matched = True
                continue
            cond_toks = []
            while (not s.eof() and s.w() not in _VERBS and s.peek().kind != DOT
                   and s.w() != "WHEN" and s.w() != "END-EVALUATE"):
                cond_toks.append(s.next())
            ok = False
            if not matched:
                if is_bool:
                    ok = self._eval_cond(cond_toks)
                    if subject == "FALSE":
                        ok = not ok
                else:
                    ok = self._apply_relop(subject, "=", self._operand_span(cond_toks))
            if ok:
                self._exec_until(s, {"WHEN", "END-EVALUATE"}); matched = True
            else:
                self._skip_block(s, {"WHEN", "END-EVALUATE"})
        if s.w() == "END-EVALUATE":
            s.next()

    def _eval_condname(self, name) -> bool:
        parent, values = self.conds[name]
        pv = self.item(parent).value if self.item(parent) else ""
        for entry in values:
            if entry[0] == "val":
                if self._apply_relop(pv, "=", entry[1]):
                    return True
            elif entry[0] == "range":
                lo, hi = entry[1], entry[2]
                pn = self._maybe_num(pv)
                if pn is not None and self._maybe_num(lo) is not None:
                    if self._num(lo) <= pn <= self._num(hi):
                        return True
                elif str(lo) <= str(pv).rstrip() <= str(hi):
                    return True
        return False

    def _v_SET(self, s):
        name = s.next().value
        if s.w() == "TO":
            s.next()
        target = s.w()
        if target in ("TRUE", "FALSE"):
            s.next()
            if name in self.conds and target == "TRUE":
                parent, values = self.conds[name]
                if values and values[0][0] == "val":
                    self.setval(parent, values[0][1])
        elif target in ("UP", "DOWN"):
            s.next()
            if s.w() == "BY":
                s.next()
            n = self._num(self.operand(s.next()))
            cur = self._num(self.item(name).value) if self.item(name) else Decimal(0)
            self.setval(name, cur + n if target == "UP" else cur - n)
        else:
            self.setval(name, self.operand(s.next()))

    def _send_val(self, s):
        """Read a sending operand value (literal / figurative / item) from the stream."""
        t = s.next()
        if t.kind == STR:
            return t.value
        if t.kind == NUM:
            return t.value
        if t.value in ("SPACE", "SPACES"):
            return " "
        if t.value in ("ZERO", "ZEROS", "ZEROES"):
            return "0"
        it = self.item(t.value)
        if it is not None:
            if s.peek().kind == PUNCT and s.w() == "(":
                s2 = s
                name = t.value
                # reuse _read_ref-style subscript
                s2.i -= 1
                nm, idx = self._read_ref(s2)
                return str(self._indexed_get(nm, idx))
            return str(it.value)
        return t.value

    def _v_STRING(self, s):
        pending = []          # values awaiting a DELIMITED clause
        pieces = []           # (value, delimiter)
        while not s.eof() and s.w() != "INTO" and s.peek().kind != DOT and s.w() not in _STOP:
            if s.w() == "DELIMITED":
                s.next()
                if s.w() == "BY":
                    s.next()
                if s.w() == "SIZE":
                    s.next(); delim = None
                else:
                    delim = self._send_val(s)
                for v in pending:
                    pieces.append((v, delim))
                pending = []
            else:
                pending.append(self._send_val(s))
        for v in pending:
            pieces.append((v, None))
        if s.w() == "INTO":
            s.next()
        tname, tidx = self._read_ref(s)
        ptr = None
        if s.w() == "WITH":
            s.next()
        if s.w() == "POINTER":
            s.next(); ptr = s.next().value
        result = ""
        for v, delim in pieces:
            v = str(v)
            if delim is not None and delim != "":
                k = v.find(str(delim))
                if k >= 0:
                    v = v[:k]
            result += v
        it = self.item(tname)
        if it is not None and it.pic:
            start = 0
            if ptr and self.item(ptr):
                start = int(self._num(self.item(ptr).value)) - 1
            cur = str(it.value).ljust(it.pic.size)
            newv = (cur[:start] + result)[: it.pic.size].ljust(it.pic.size)
            self._indexed_set(tname, tidx, newv)
            if ptr and self.item(ptr):
                self.setval(ptr, start + len(result) + 1)
        # consume optional ON OVERFLOW / END-STRING
        self._skip_block(s, {"END-STRING"}) if s.w() == "ON" else None
        if s.w() == "END-STRING":
            s.next()

    def _v_UNSTRING(self, s):
        source = self._send_val(s)
        delims = []
        if s.w() == "DELIMITED":
            s.next()
            if s.w() == "BY":
                s.next()
            if s.w() == "ALL":
                s.next()
            delims.append(str(self._send_val(s)))
            while s.w() == "OR":
                s.next()
                if s.w() == "ALL":
                    s.next()
                delims.append(str(self._send_val(s)))
        if s.w() == "INTO":
            s.next()
        targets = []
        while not s.eof() and s.peek().kind == WORD and self.item(s.w()) is not None and not _barrier(s.w()):
            targets.append(self._read_ref(s))
            if s.w() == "DELIMITER":            # DELIMITER IN x - skip
                s.next()
                if s.w() == "IN":
                    s.next()
                s.next()
        # split
        if delims:
            import re as _re
            pat = "|".join(_re.escape(d) for d in delims if d)
            parts = _re.split(pat, str(source)) if pat else [str(source)]
        else:
            parts = str(source).split()
        for i, (tname, tidx) in enumerate(targets):
            self._indexed_set(tname, tidx, parts[i] if i < len(parts) else "")
        if s.w() == "END-UNSTRING":
            s.next()

    def _v_INSPECT(self, s):
        fname, fidx = self._read_ref(s)
        it = self.item(fname)
        text = str(self._indexed_get(fname, fidx)) if it else ""
        if s.w() == "TALLYING":
            s.next()
            counter = s.next().value
            total = int(self._num(self.item(counter).value)) if self.item(counter) else 0
            if s.w() == "FOR":
                s.next()
            while s.w() in ("ALL", "LEADING", "CHARACTERS"):
                mode = s.next().value
                if mode == "CHARACTERS":
                    total += len(text)
                else:
                    needle = str(self._send_val(s))
                    if mode == "ALL":
                        total += text.count(needle) if needle else 0
                    elif mode == "LEADING":
                        c = 0; i = 0
                        while needle and text[i:i + len(needle)] == needle:
                            c += 1; i += len(needle)
                        total += c
            self.setval(counter, total)
        elif s.w() == "REPLACING":
            s.next()
            while s.w() in ("ALL", "LEADING", "FIRST", "CHARACTERS"):
                mode = s.next().value
                if mode == "CHARACTERS":
                    if s.w() == "BY":
                        s.next()
                    by = str(self._send_val(s))
                    text = by * len(text)
                else:
                    old = str(self._send_val(s))
                    if s.w() == "BY":
                        s.next()
                    new = str(self._send_val(s))
                    if mode == "FIRST":
                        text = text.replace(old, new, 1)
                    else:
                        text = text.replace(old, new)
            self._indexed_set(fname, fidx, text)
        if s.w() == "END-INSPECT":
            s.next()

    def _v_STOP(self, s):
        if s.w() == "RUN":
            s.next()
        raise Halt()

    def _v_GOBACK(self, s):
        raise Halt()

    def _v_CONTINUE(self, s):
        pass

    def _v_ACCEPT(self, s):
        # ACCEPT x [FROM ...] - no interactive input; leave as-is
        while not s.eof() and s.peek().kind != DOT and s.w() not in _VERBS and s.w() not in _STOP:
            s.next()

    def _v_INITIALIZE(self, s):
        while s.peek().kind == WORD and s.w() not in _VERBS and s.w() not in _STOP:
            name = s.next().value
            it = self.item(name)
            if it:
                it.value = Decimal(0) if (it.pic and not it.pic.alnum) else ""

    # ---------- files ----------
    def _v_OPEN(self, s):
        mode = s.next().value          # INPUT / OUTPUT / I-O / EXTEND
        while s.peek().kind == WORD and s.w() not in _VERBS and s.w() not in _STOP:
            fname = s.next().value
            dd = self.p["assign"].get(fname, fname)
            dsn = self.host.dd_to_dsn(dd) if self.host else None
            recs = []
            if mode == "INPUT" and dsn:
                try:
                    recs = self.host.read_dataset(dsn)
                except Exception:
                    recs = []
            self.files[fname] = {"dd": dd, "dsn": dsn, "mode": mode, "recs": recs,
                                 "pos": 0, "out": []}

    def _v_READ(self, s):
        fname = s.next().value
        into = None
        f = self.files.get(fname)
        # optional INTO
        # scan the READ clause: [INTO x] [AT END stmts] [NOT AT END stmts] END-READ
        at_end_start = not_end_start = None
        # first handle INTO
        if s.w() == "INTO":
            s.next(); into = s.next().value
        got = None
        if f and f["pos"] < len(f["recs"]):
            got = f["recs"][f["pos"]]; f["pos"] += 1
            rec_item = self.p["records"].get(fname)
            if rec_item is not None:
                rec_item.set_raw(got)
            if into:
                self.setval(into, got)
        # AT END / NOT AT END handling
        end_hit = got is None
        # parse the two optional branches
        while s.w() in ("AT", "NOT", "END") or s.w() == "END-READ":
            if s.w() == "END-READ":
                s.next(); break
            if s.w() == "NOT":
                s.next()
                if s.w() == "AT":
                    s.next()
                if s.w() == "END":
                    s.next()
                if end_hit:
                    self._skip_block(s, {"AT", "END-READ"})
                else:
                    self._exec_until(s, {"AT", "END-READ", "NOT"})
                continue
            if s.w() == "AT":
                s.next()
                if s.w() == "END":
                    s.next()
                if end_hit:
                    self._exec_until(s, {"NOT", "END-READ"})
                else:
                    self._skip_block(s, {"NOT", "END-READ"})
                continue
            break

    def _v_WRITE(self, s):
        rec = s.next().value
        frm = None
        if s.w() == "FROM":
            s.next(); frm = s.next().value
        # find the file owning this record
        fname = None
        for fn, ri in self.p["records"].items():
            if ri.name == rec:
                fname = fn; break
        rec_item = self.p["records"].get(fname) if fname else None
        if frm and rec_item is not None:
            rec_item.set_raw(str(self.item(frm).value if self.item(frm) else frm))
        line = rec_item.get_raw().rstrip() if rec_item is not None else ""
        f = self.files.get(fname)
        if f is not None:
            f["out"].append(line)

    def _v_CLOSE(self, s):
        while s.peek().kind == WORD and s.w() not in _VERBS and s.w() not in _STOP:
            fname = s.next().value
            f = self.files.get(fname)
            if f and f["mode"] in ("OUTPUT", "EXTEND", "I-O") and f["dsn"] and self.host:
                self.host.write_dataset(f["dsn"], f["out"],
                                        disp="MOD" if f["mode"] == "EXTEND" else "OLD")

    # ---------- expressions & conditions ----------
    def _read_cond_toks(self, s):
        toks = []
        depth = 0
        while not s.eof() and s.peek().kind != DOT:
            if s.peek().kind == EXECBLOCK and depth == 0:
                break                       # an EXEC SQL block begins the loop body
            w = s.w()
            if w in _VERBS and depth == 0:
                break
            if w in _STOP and depth == 0:
                break
            toks.append(s.next())
        return toks

    def _eval_expr(self, toks):
        toks = self._collapse(toks)
        # shunting-yard to RPN then evaluate with Decimal
        out, ops = [], []
        prec = {"+": 1, "-": 1, "*": 2, "/": 2, "**": 3}
        for t in toks:
            if t.kind in (NUM, WORD):
                out.append(self._num(self.operand(t)))
            elif t.value in prec:
                while ops and ops[-1] != "(" and prec.get(ops[-1], 0) >= prec[t.value]:
                    out.append(ops.pop())
                ops.append(t.value)
            elif t.value == "(":
                ops.append("(")
            elif t.value == ")":
                while ops and ops[-1] != "(":
                    out.append(ops.pop())
                if ops:
                    ops.pop()
        while ops:
            out.append(ops.pop())
        st = []
        for x in out:
            if isinstance(x, Decimal):
                st.append(x)
            else:
                b = st.pop(); a = st.pop()
                st.append({"+": a + b, "-": a - b, "*": a * b,
                           "/": a / b if b != 0 else Decimal(0), "**": a ** int(b)}[x])
        return st[0] if st else Decimal(0)

    def _eval_cond(self, toks) -> bool:
        # 88-level condition names
        if len(toks) == 1 and toks[0].value in self.conds:
            return self._eval_condname(toks[0].value)
        if len(toks) == 2 and toks[0].value == "NOT" and toks[1].value in self.conds:
            return not self._eval_condname(toks[1].value)
        toks = self._collapse(toks)
        words = [t.value for t in toks]
        # split on AND/OR (no precedence beyond left-to-right for subset)
        # find relational operator
        relops = {"=", ">", "<", ">=", "<=", "EQUAL", "GREATER", "LESS", "NOT"}
        # handle simple: A op B
        # normalize verbose operators
        joined = toks
        # locate operator
        for i, t in enumerate(joined):
            if t.value in ("=", ">", "<") or t.value in ("EQUAL", "GREATER", "LESS", "NOT"):
                left = self._operand_span(joined[:i])
                op, rhs_start = self._read_relop(joined, i)
                right = self._operand_span(joined[rhs_start:])
                return self._apply_relop(left, op, right)
        return False

    def _operand_span(self, toks):
        # a single operand (last meaningful token) - subset: use first NUM/WORD/STR
        for t in toks:
            if t.kind in (NUM, WORD, STR):
                return self.operand(t)
        return ""

    def _read_relop(self, toks, i):
        w = toks[i].value
        if w == "NOT":
            nxt = toks[i + 1].value if i + 1 < len(toks) else "="
            base = "=" if nxt in ("EQUAL", "=") else (">" if nxt in ("GREATER", ">") else "<")
            return ("NOT" + base, i + (3 if nxt in ("EQUAL", "GREATER", "LESS") else 2))
        if w in ("EQUAL",):
            j = i + 1
            if j < len(toks) and toks[j].value == "TO":
                j += 1
            return ("=", j)
        if w in ("GREATER",):
            j = i + 1
            if j < len(toks) and toks[j].value == "THAN":
                j += 1
            return (">", j)
        if w in ("LESS",):
            j = i + 1
            if j < len(toks) and toks[j].value == "THAN":
                j += 1
            return ("<", j)
        # symbolic, maybe followed by '='
        if i + 1 < len(toks) and toks[i + 1].value == "=":
            return (w + "=", i + 2)
        return (w, i + 1)

    def _apply_relop(self, left, op, right):
        ln, rn = self._maybe_num(left), self._maybe_num(right)
        if ln is not None and rn is not None:
            a, b = ln, rn
        else:
            a, b = str(left).rstrip(), str(right).rstrip()
        if op in ("=",):
            return a == b
        if op in ("NOT=",):
            return a != b
        if op == ">":
            return a > b
        if op == "<":
            return a < b
        if op == ">=":
            return a >= b
        if op == "<=":
            return a <= b
        if op == "NOT>":
            return not (a > b)
        if op == "NOT<":
            return not (a < b)
        return False

    def _maybe_num(self, v):
        try:
            return Decimal(str(v).strip())
        except Exception:
            return None

    # ---------- skipping ----------
    def _skip_block(self, s: _S, stops):
        depth = 0
        while not s.eof():
            w = s.w()
            if w in ("IF", "EVALUATE", "READ") or (w == "PERFORM" and not (s.peek(1).kind == WORD and s.peek(1).value in self.paranames)):
                depth += 1; s.next(); continue
            if w in ("END-IF", "END-PERFORM", "END-READ", "END-EVALUATE"):
                if depth == 0 and w in stops:
                    return
                depth -= 1; s.next(); continue
            if depth == 0 and w in stops:
                return
            if s.peek().kind == DOT and depth == 0 and "." in stops:
                return
            s.next()


_VERBS = {"DISPLAY", "MOVE", "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE",
          "IF", "PERFORM", "OPEN", "READ", "WRITE", "CLOSE", "STOP", "ACCEPT",
          "GO", "CONTINUE", "INITIALIZE", "GOBACK", "EVALUATE", "SET",
          "STRING", "UNSTRING", "INSPECT"}

# COBOL clause keywords that terminate an operand list mid-statement
_CLAUSE = {"NOT", "AT", "END", "WHEN", "INVALID", "THEN", "ELSE"}


def _barrier(w):
    return w in _VERBS or w in _STOP or w in _CLAUSE


def run(src: str, host=None):
    prog = Parser(tokenize(src)).parse()
    return Cobol(prog, host).run()
