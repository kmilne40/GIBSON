"""Integration seam between the new language engines and live GIBSON.

Everything here is additive and flag-gated. When the `GIBSON_FULL_*` environment
flags are off (default), GIBSON keeps using its legacy interpreters; when on, the
call sites route through these factories. All entry points are defensive: any
failure should let the caller fall back to the legacy path.
"""
from __future__ import annotations

import os
from typing import Callable, List, Optional, Tuple


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def full_rexx_enabled() -> bool:
    return _flag("GIBSON_FULL_REXX")


def full_jcl_enabled() -> bool:
    return _flag("GIBSON_FULL_JCL")


def full_cobol_enabled() -> bool:
    return _flag("GIBSON_FULL_COBOL")


def _gibson_sql_backend(state, userid):
    """SQL backend for EXEC SQL running live in GIBSON. Routes CBSA.ACCOUNT customer
    lookups through the real (vulnerable) sqli_search - so dynamic/concatenated SQL is
    injectable and fires the SENTRY CTI (ScrAPI Bear), while a bound '?' host variable
    is matched exactly and is injection-proof. Other SQL falls through to the Db2 sim."""
    import re as _re

    def _project(rows, cols):
        if cols.strip() == "*":
            return [dict(r) for r in rows]
        names = [c.strip().upper() for c in cols.split(",")]
        return [{n: r.get(n, "") for n in names} for r in rows]

    def run(sql, params, uid):
        m = _re.match(r"\s*SELECT\s+(.*?)\s+FROM\s+CBSA\.ACCOUNT\s+WHERE\s+CUSTOMER_ID\s*=\s*(\?|'.*')\s*$",
                      sql, _re.I | _re.S)
        if m:
            cols, rhs = m.group(1), m.group(2)
            if rhs == "?":                        # parameterised host var -> exact, no injection, no CTI
                val = str(params[0]) if params else ""
                from gibson.apps.cbsa.store import get_cbsa_store
                store = get_cbsa_store(state)
                rows = [a.row() for a in store.accounts.values() if str(a.customer_id) == val]
                return _project(rows, cols)
            inner = rhs[1:-1]                      # dynamic literal -> vulnerable path (fires ScrAPI Bear)
            from gibson.apps.cbsa.db2_bridge import call_vuln_account_search
            res = call_vuln_account_search(state, inner)
            return _project(res.get("rows", []), cols)
        try:                                       # general SQL -> Db2 simulator
            from gibson.apps.db2_sim import Db2Simulator
            return Db2Simulator(state).run_sql(sql, uid) or []
        except Exception:
            return []
    return run


def host_for_state(state, userid: str, command_runner: Optional[Callable] = None):
    """Build a HostServices bound to GIBSON's real dataset catalog."""
    from .hostsvc import HostServices, GibsonBackend
    backend = GibsonBackend(state.datasets, userid)
    host = HostServices(backend, userid, command_runner=command_runner)
    host.sql_backend = _gibson_sql_backend(state, userid)   # EXEC SQL -> real Db2/sqli_search
    return host


def run_rexx_full(state, userid: str, source: str, args: str = "",
                  tso_runner: Optional[Callable[[str], str]] = None) -> str:
    """Run a REXX exec on the new engine against live GIBSON datasets.

    Returns the exec's console output as a newline-joined string (matching the
    legacy RexxInterpreter.run contract).
    """
    from .rexx.interp import RexxEngine
    host = host_for_state(state, userid, command_runner=tso_runner)
    result = RexxEngine(host).run(source, args)
    return "\n".join(result.output)


def make_cobol_runner(state, userid: str, dd_map: Optional[dict] = None):
    """Return a callable matching GIBSON JES's cobol_runner seam.

    Signature: (source:str) -> (rc:int, stdout:str, spool_lines:List[str]).
    """
    from .cobol.interp import Cobol
    from .cobol.lexer import tokenize
    from .cobol.parser import Parser

    def _run(source: str) -> Tuple[int, str, List[str]]:
        host = host_for_state(state, userid)
        if dd_map:
            host.dd.update(dd_map)
        try:
            prog = Parser(tokenize(source)).parse()
            out = Cobol(prog, host).run()
            return 0, "\n".join(out), out
        except Exception as e:  # never crash the initiator
            return 12, f"COBOL ABEND: {e}", [f"COBOL ABEND: {e}"]

    return _run


def submit_jcl_full(state, userid: str, jcl_text: str,
                    proclib: Optional[dict] = None, cobol_pgms: Optional[dict] = None):
    """Run a JCL job on the new engine against live GIBSON datasets."""
    from .jcl import JclEngine
    host = host_for_state(state, userid)
    return JclEngine(host, proclib=proclib, cobol_pgms=cobol_pgms).submit(jcl_text)
