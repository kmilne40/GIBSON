"""REXX AST nodes (R1)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple


# ---- expressions ----
@dataclass
class Const:
    value: str

@dataclass
class Var:
    name: str                       # already uppercased stem/simple name

@dataclass
class Compound:
    stem: str
    tails: List[Any]                # list of expr nodes forming the tail

@dataclass
class Unary:
    op: str
    operand: Any

@dataclass
class Binary:
    op: str
    left: Any
    right: Any

@dataclass
class Concat:
    left: Any
    right: Any
    blank: bool                     # abuttal-with-space -> insert one blank

@dataclass
class FuncCall:
    name: str
    args: List[Any]


# ---- clauses ----
@dataclass
class Say:
    expr: Optional[Any]

@dataclass
class Assign:
    target: Any                     # Var or Compound
    expr: Any

@dataclass
class Command:
    expr: Any                       # bare expression -> host command
    raw: Any = None                 # original clause text (for non-expression cmd syntax)

@dataclass
class If:
    cond: Any
    then: Any
    els: Optional[Any]

@dataclass
class Do:
    body: List[Any]
    ctrl: Optional[str] = None      # None | "TIMES" | "CONTROLLED" | "WHILE" | "UNTIL" | "FOREVER"
    var: Optional[str] = None
    start: Optional[Any] = None
    to: Optional[Any] = None
    by: Optional[Any] = None
    forn: Optional[Any] = None
    cond: Optional[Any] = None      # WHILE/UNTIL expression
    times: Optional[Any] = None

@dataclass
class Select:
    whens: List[Tuple[Any, Any]]    # (cond, clause)
    otherwise: Optional[List[Any]]

@dataclass
class Call:
    name: str
    args: List[Any]

@dataclass
class Return:
    expr: Optional[Any]

@dataclass
class Exit:
    expr: Optional[Any]

@dataclass
class Nop:
    pass

@dataclass
class Leave:
    pass

@dataclass
class Iterate:
    pass

@dataclass
class Parse:
    source: str                     # "ARG" | "VAR" | "VALUE" | "PULL" | "LINEIN"
    var: Optional[str]              # for PARSE VAR
    value_expr: Optional[Any]       # for PARSE VALUE ... WITH
    template: List[Any]             # template items

@dataclass
class Label:
    name: str

@dataclass
class Address:
    env: Optional[str]
    command: Optional[Any]

@dataclass
class Drop:
    names: List[str]

@dataclass
class Signal:
    label: str

@dataclass
class SignalOn:
    onoff: str          # ON | OFF
    cond: str           # ERROR | SYNTAX | NOVALUE | HALT | FAILURE
    label: Optional[str]

@dataclass
class SignalValue:
    expr: Any

@dataclass
class Interpret:
    expr: Any

@dataclass
class Program:
    clauses: List[Any]
