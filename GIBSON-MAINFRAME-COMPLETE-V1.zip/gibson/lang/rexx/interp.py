"""REXX interpreter (R1/early-R2): tree-walking evaluator."""
from __future__ import annotations

import re
from decimal import Decimal, getcontext, localcontext
from typing import Any, List, Optional

from . import ast as A
from .parser import parse, _StackOp
from .builtins import BUILTINS


class RexxError(Exception):
    def __init__(self, number: int, msg: str):
        super().__init__(f"REXX error {number}: {msg}")
        self.number = number


class _Exit(Exception):
    def __init__(self, value): self.value = value

class _Return(Exception):
    def __init__(self, value): self.value = value

class _Leave(Exception):
    pass

class _Iterate(Exception):
    pass


class _Signal(Exception):
    def __init__(self, label):
        self.label = label


class RexxResult:
    def __init__(self, rc, result, output):
        self.rc = rc
        self.result = result
        self.output = output


class Interpreter:
    def __init__(self, host=None, trace=False, max_clauses=1_000_000):
        self.host = host
        self.trace = trace
        self.max_clauses = max_clauses
        self.digits = 9
        self.vars = {"RC": "0", "RESULT": "", "SIGL": "0"}
        if host is not None:
            self.vars["USERID"] = host.sysuid
            self.vars["SYSUID"] = host.sysuid
        self.out: List[str] = []
        self.queue: List[str] = []
        self.top: List[Any] = []
        self.labels = {}
        self._clauses = 0
        self.address_env = "TSO"
        self.traps = {}          # condition -> label

    # ---------- public ----------
    def run(self, source: str, arg: str = "") -> RexxResult:
        prog = parse(source)
        self.top = prog.clauses
        self.labels = {c.name: i for i, c in enumerate(self.top) if isinstance(c, A.Label)}
        self.vars["ARG"] = arg
        self.vars["ARG1"] = arg
        self._arg = arg
        self._argcount = 1 if arg != "" else 0
        pc = 0
        while True:
            try:
                self._exec_from(pc)
                break
            except _Exit as e:
                if e.value is not None:
                    self.vars["RC"] = e.value
                break
            except _Signal as sig:
                if sig.label in self.labels:
                    self.vars["SIGL"] = str(self._clauses)
                    pc = self.labels[sig.label]
                else:
                    raise RexxError(16, f"label '{sig.label}' not found")
            except RexxError as e:
                if "SYNTAX" in self.traps:
                    self.vars["RC"] = str(e.number)
                    self.vars["SIGL"] = str(self._clauses)
                    lbl = self.traps["SYNTAX"]
                    if lbl in self.labels:
                        self.traps.pop("SYNTAX", None)  # avoid re-trapping loops
                        pc = self.labels[lbl]
                        continue
                raise
        return RexxResult(self.vars.get("RC", "0"), self.vars.get("RESULT", ""), self.out)

    # ---------- execution ----------
    def _exec_from(self, idx: int):
        i = idx
        while i < len(self.top):
            self.exec_clause(self.top[i])
            i += 1

    def exec_block(self, clauses: List[Any]):
        for c in clauses:
            self.exec_clause(c)

    def exec_clause(self, node):
        self._clauses += 1
        if self._clauses > self.max_clauses:
            raise RexxError(0, "clause limit exceeded")
        m = getattr(self, "_ex_" + type(node).__name__, None)
        if m is None:
            if isinstance(node, _StackOp):
                return self._ex_stack(node)
            return
        return m(node)

    def _ex_Label(self, n):  # falling into a label is a no-op
        pass

    def _ex_Nop(self, n):
        pass

    def _ex_Signal(self, n):
        raise _Signal(n.label)

    def _ex_SignalValue(self, n):
        raise _Signal(str(self.eval(n.expr)).upper())

    def _ex_SignalOn(self, n):
        if n.onoff == "ON":
            self.traps[n.cond] = n.label or n.cond
        else:
            self.traps.pop(n.cond, None)

    def _ex_Interpret(self, n):
        code = self.eval(n.expr)
        try:
            prog = parse(code)
        except Exception:
            return
        for c in prog.clauses:
            self.exec_clause(c)

    def _ex_Say(self, n):
        text = "" if n.expr is None else self.eval(n.expr)
        self.out.append(text)
        if self.host is not None:
            try:
                self.host.console(text)
            except Exception:
                pass

    def _ex_Assign(self, n):
        val = self.eval(n.expr)
        self._set_target(n.target, val)

    def _ex_Command(self, n):
        cmd = self.eval(n.expr)
        self._issue_command(self.address_env, cmd)

    def _ex_Address(self, n):
        if n.command is not None:
            self._issue_command(n.env or self.address_env, self.eval(n.command))
        elif n.env:
            self.address_env = n.env

    def _issue_command(self, env, cmd):
        if cmd.strip().upper().startswith("EXECIO"):
            self.vars["RC"] = str(self._execio(cmd))
            return
        # SUBMIT * [END(dlm)] : an in-stream job assembled onto the REXX stack.
        # ELV.APF/ELV.SVC drivers QUEUE their assemble-and-run JCL then SUBMIT * END($$);
        # drain it and route an ELV job to the Level B engine (else fall through).
        if self._maybe_submit_instream(cmd):
            return
        rc = 0
        lines = []
        if self.host is not None:
            try:
                if env == "TSO":
                    rc, lines = self.host.tso(cmd)
                    self._last_cmd_out = lines
                elif env == "ISPEXEC":
                    rc = self.host.ispexec(cmd)
                else:
                    rc, lines = self.host.tso(cmd)
            except Exception:
                rc = -3
        # OUTTRAP: route command output into a stem instead of the terminal
        stem = getattr(self, "outtrap_stem", None)
        if stem and lines:
            for i, ln in enumerate(lines, 1):
                self.vars[f"{stem}.{i}"] = ln
            self.vars[f"{stem}.0"] = str(len(lines))
        self.vars["RC"] = str(rc)
        if rc != 0 and "ERROR" in self.traps:
            raise _Signal(self.traps["ERROR"])
        if rc < 0 and "FAILURE" in self.traps:
            raise _Signal(self.traps["FAILURE"])

    def _maybe_submit_instream(self, cmd: str) -> bool:
        """Handle `SUBMIT * [END(dlm)]`; return True if it was consumed here."""
        s = cmd.strip()
        toks = s.split()
        if len(toks) < 2 or toks[0].upper() != "SUBMIT" or toks[1] != "*":
            return False
        m = re.search(r"END\(\s*([^)]*?)\s*\)", s, re.I)
        delim = (m.group(1).strip() if m else "") or None
        # drain the queued in-stream JCL up to the end-of-data delimiter (or empty)
        jcl_lines: List[str] = []
        while self.queue:
            line = self.queue.pop(0)
            if delim is not None and line.strip() == delim:
                break
            jcl_lines.append(line)

        lines: List[str]
        host = self.host
        state = getattr(host, "gibson_state", None)
        hs = getattr(host, "storage", None)
        if state is None and hs is not None:
            state = getattr(hs, "state", None)
        userid = (getattr(host, "sysuid", None) or self.vars.get("USERID", "IBMUSER"))
        routed = None
        if state is not None and jcl_lines:
            try:
                from gibson.tools.elv_submit import route_submitted_jcl
                routed = route_submitted_jcl(state, userid, jcl_lines)
            except Exception:
                routed = None
        if routed is not None:
            lines = routed
        else:
            lines = ["IKJ56250I IN-STREAM JOB SUBMITTED"] if jcl_lines else \
                    ["IKJ56700I MISSING DATA SET NAME"]

        self._last_cmd_out = lines
        for ln in lines:
            self.out.append(ln)
            if host is not None:
                try:
                    host.console(ln)
                except Exception:
                    pass
        stem = getattr(self, "outtrap_stem", None)
        if stem:
            for i, ln in enumerate(lines, 1):
                self.vars[f"{stem}.{i}"] = ln
            self.vars[f"{stem}.0"] = str(len(lines))
        self.vars["RC"] = "0"
        return True

    def _execio(self, cmd: str) -> int:
        """EXECIO count DISKR|DISKW ddname (STEM s. | FINIS | LIFO ...)."""
        if self.host is None:
            return 1
        body = cmd.strip()[len("EXECIO"):].strip()
        head, _, opts = body.partition("(")
        htoks = head.split()
        if len(htoks) < 3:
            return 20
        count_tok, direction, ddname = htoks[0], htoks[1].upper(), htoks[2]
        opts_up = opts.upper()
        mstem = re.search(r"STEM\s+([A-Za-z@#$][A-Za-z0-9@#$.]*)", opts, re.I)
        stem = mstem.group(1).rstrip(".").upper() if mstem else None
        lifo = "LIFO" in opts_up
        dsn = self.host.dd_to_dsn(ddname)
        if dsn is None:
            return 1
        if direction.startswith("DISKW"):
            if stem is None:
                return 20
            n = int(self._numval(self.vars.get(f"{stem}.0", "0")))
            recs = [self.vars.get(f"{stem}.{i}", "") for i in range(1, n + 1)]
            if count_tok != "*":
                recs = recs[:int(count_tok)]
            self.host.write_dataset(dsn, recs, disp="OLD")
            return 0
        if direction == "DISKR":
            try:
                recs = self.host.read_dataset(dsn)
            except Exception:
                return 1
            if count_tok != "*":
                recs = recs[:int(count_tok)]
            if stem is not None:
                for i, r in enumerate(recs, 1):
                    self.vars[f"{stem}.{i}"] = r
                self.vars[f"{stem}.0"] = str(len(recs))
            else:
                if lifo:
                    for r in reversed(recs):
                        self.queue.insert(0, r)
                else:
                    self.queue.extend(recs)
            return 0
        return 20

    def _ex_If(self, n):
        if self._truth(self.eval(n.cond)):
            if n.then is not None:
                self.exec_clause(n.then)
        elif n.els is not None:
            self.exec_clause(n.els)

    def _ex_Select(self, n):
        for cond, clause in n.whens:
            if self._truth(self.eval(cond)):
                self.exec_clause(clause)
                return
        if n.otherwise is not None:
            self.exec_block(n.otherwise)
        else:
            raise RexxError(7, "no OTHERWISE in SELECT")

    def _ex_Do(self, n):
        try:
            if n.ctrl is None:
                self.exec_block(n.body)
            elif n.ctrl == "FOREVER":
                while True:
                    self._do_iter(n)
            elif n.ctrl == "TIMES":
                cnt = int(self._numval(self.eval(n.times)))
                for _ in range(cnt):
                    self._do_iter(n)
            elif n.ctrl == "WHILE":
                while self._truth(self.eval(n.cond)):
                    self._do_iter(n)
            elif n.ctrl == "UNTIL":
                while True:
                    self._do_iter(n)
                    if self._truth(self.eval(n.cond)):
                        break
            elif n.ctrl in ("CONTROLLED", "CWHILE", "CUNTIL"):
                self._do_controlled(n)
        except _Leave:
            pass

    def _do_iter(self, n):
        try:
            self.exec_block(n.body)
        except _Iterate:
            pass

    def _do_controlled(self, n):
        i = self._numval(self.eval(n.start))
        by = self._numval(self.eval(n.by)) if n.by is not None else Decimal(1)
        to = self._numval(self.eval(n.to)) if n.to is not None else None
        forn = int(self._numval(self.eval(n.forn))) if n.forn is not None else None
        count = 0
        while True:
            if to is not None:
                if by >= 0 and i > to:
                    break
                if by < 0 and i < to:
                    break
            if forn is not None and count >= forn:
                break
            self.vars[n.var] = self._fmt(i)
            if n.ctrl == "CWHILE" and not self._truth(self.eval(n.cond)):
                break
            try:
                self.exec_block(n.body)
            except _Iterate:
                pass
            if n.ctrl == "CUNTIL" and self._truth(self.eval(n.cond)):
                break
            i += by
            count += 1

    def _ex_Leave(self, n):
        raise _Leave()

    def _ex_Iterate(self, n):
        raise _Iterate()

    def _ex_Exit(self, n):
        raise _Exit(self.eval(n.expr) if n.expr is not None else None)

    def _ex_Return(self, n):
        raise _Return(self.eval(n.expr) if n.expr is not None else None)

    def _ex_Drop(self, n):
        for name in n.names:
            self.vars.pop(name, None)

    def _ex_Call(self, n):
        result = self._invoke(n.name, [self.eval(a) for a in n.args])
        self.vars["RESULT"] = result if result is not None else ""

    def _ex_stack(self, n):
        val = self.eval(n.expr) if n.expr is not None else ""
        if n.op == "PUSH":
            self.queue.insert(0, val)
        else:
            self.queue.append(val)

    def _ex_Parse(self, n):
        if n.source == "ARG":
            source = [self._arg]
        elif n.source == "PULL":
            source = [self.queue.pop(0) if self.queue else ""]
        elif n.source == "VAR":
            source = [self._getvar(n.var)]
        elif n.source == "VALUE":
            source = [self.eval(n.value_expr)]
        elif n.source == "LINEIN":
            source = [""]
        else:
            source = [""]
        text = source[0]
        self._parse_template(text, n.template)

    def _parse_template(self, text, template):
        """Full-ish REXX PARSE: word targets, literal delimiters, absolute/relative
        column positions, and (var) indirect literals."""
        if not template:
            return
        pos = 0
        i = 0
        n = len(template)
        while i < n:
            targets = []
            while i < n and template[i][0] in ("var", "."):
                targets.append(template[i]); i += 1
            # find the section end determined by the next pattern
            if i < n and template[i][0] in ("lit", "litvar"):
                lit = template[i][1] if template[i][0] == "lit" else self.vars.get(template[i][1], template[i][1])
                i += 1
                idx = text.find(lit, pos)
                if idx < 0:
                    section = text[pos:]; newpos = len(text)
                else:
                    section = text[pos:idx]; newpos = idx + len(lit)
                self._assign_parse(targets, section)
                pos = newpos
            elif i < n and template[i][0] == "pos":
                col = template[i][1] - 1; i += 1
                if col < 0:
                    col = 0
                section = text[pos:col] if col > pos else ""
                self._assign_parse(targets, section)
                pos = col
            elif i < n and template[i][0] == "rpos":
                col = pos + template[i][1]; i += 1
                col = max(0, col)
                section = text[pos:col] if col > pos else ""
                self._assign_parse(targets, section)
                pos = col
            else:
                self._assign_parse(targets, text[pos:])
                pos = len(text)

    def _assign_parse(self, targets, section):
        if not targets:
            return
        if len(targets) == 1:
            k, name = targets[0]
            if k == "var":
                self.vars[name] = section
            return
        parts = section.split(None, len(targets) - 1)
        for idx, (k, name) in enumerate(targets):
            val = parts[idx] if idx < len(parts) else ""
            if k == "var":
                self.vars[name] = val

    # ---------- routines ----------
    def _invoke(self, name, argvals):
        if name in self.labels and name not in ("",):
            return self._run_routine(name, argvals)
        if name in BUILTINS:
            return BUILTINS[name](argvals, self)
        raise RexxError(43, f"routine {name} not found")

    def _run_routine(self, name, argvals):
        idx = self.labels[name]
        saved_arg = self._arg
        self._arg = argvals[0] if argvals else ""
        saved_argcount = getattr(self, '_argcount', 0)
        self._argcount = len(argvals)
        # PROCEDURE scoping if the first following clause is a procedure marker
        new_scope = None
        start = idx + 1
        if start < len(self.top):
            nxt = self.top[start]
            if getattr(nxt, "is_procedure", False):
                exposed = getattr(nxt, "exposed", [])
                new_scope = {k: self.vars[k] for k in exposed if k in self.vars}
                new_scope.update({"RC": self.vars.get("RC", "0"), "RESULT": ""})
                start += 1
        saved_vars = None
        if new_scope is not None:
            saved_vars = self.vars
            self.vars = new_scope
        # bind ARG.n
        for k, v in enumerate(argvals, 1):
            self.vars[f"ARG{k}"] = v
        result = None
        try:
            i = start
            while i < len(self.top):
                c = self.top[i]
                if isinstance(c, A.Label):
                    break  # fell through to next routine
                self.exec_clause(c)
                i += 1
        except _Return as r:
            result = r.value
        finally:
            if saved_vars is not None:
                for k in ("RC",):
                    saved_vars[k] = self.vars.get(k, saved_vars.get(k))
                self.vars = saved_vars
            self._arg = saved_arg
            self._argcount = saved_argcount
        return result

    # ---------- evaluation ----------
    def eval(self, node) -> str:
        return getattr(self, "_ev_" + type(node).__name__)(node)

    def _ev_Const(self, n): return n.value

    def _ev_Var(self, n): return self._getvar(n.name)

    def _ev_Compound(self, n):
        key = self._compound_key(n)
        return self.vars.get(key, key)

    def _ev_Concat(self, n):
        return self.eval(n.left) + (" " if n.blank else "") + self.eval(n.right)

    def _ev_Unary(self, n):
        v = self.eval(n.operand)
        if n.op in ("\\", "¬"):
            return "0" if self._truth(v) else "1"
        if n.op == "-":
            return self._fmt(-self._numval(v))
        if n.op == "+":
            return self._fmt(+self._numval(v))
        return v

    def _ev_FuncCall(self, n):
        args = [self.eval(a) for a in n.args]
        val = self._invoke(n.name, args)
        return val if val is not None else ""

    def _ev_Binary(self, n):
        op = n.op
        if op in ("&", "|", "&&"):
            l = self._truth(self.eval(n.left))
            r = self._truth(self.eval(n.right))
            if op == "&": return "1" if (l and r) else "0"
            if op == "|": return "1" if (l or r) else "0"
            return "1" if (l != r) else "0"
        left = self.eval(n.left)
        right = self.eval(n.right)
        if op in ("+", "-", "*", "/", "%", "//", "**"):
            return self._arith(op, left, right)
        # comparison
        return "1" if self._compare(op, left, right) else "0"

    def _arith(self, op, l, r):
        with localcontext() as ctx:
            ctx.prec = self.digits
            a, b = self._numval(l), self._numval(r)
            if op == "+": v = a + b
            elif op == "-": v = a - b
            elif op == "*": v = a * b
            elif op == "/": v = a / b
            elif op == "%": v = (a / b).to_integral_value(rounding="ROUND_DOWN")
            elif op == "//": v = a - b * ((a / b).to_integral_value(rounding="ROUND_DOWN"))
            elif op == "**": v = a ** int(b)
            else: v = Decimal(0)
        return self._fmt(v)

    def _compare(self, op, l, r):
        ln, rn = self._maybe_num(l), self._maybe_num(r)
        strict = op in ("==", "\\==", "¬==")
        if op in ("=", "==") :
            if ln is not None and rn is not None and not strict:
                return ln == rn
            return (l == r) if strict else (l.strip() == r.strip())
        if op in ("\\=", "/=", "><", "<>", "¬="):
            if ln is not None and rn is not None:
                return ln != rn
            return l.strip() != r.strip()
        # ordering
        if ln is not None and rn is not None:
            a, b = ln, rn
        else:
            a, b = l.strip(), r.strip()
        if op in ("<", "\\>", "¬>"): return a < b
        if op in (">", "\\<", "¬<"): return a > b
        if op == "<=": return a <= b
        if op == ">=": return a >= b
        return False

    # ---------- helpers ----------
    def _getvar(self, name):
        if name in self.vars:
            return self.vars[name]
        if "NOVALUE" in self.traps:
            raise _Signal(self.traps["NOVALUE"])
        return name

    def _set_target(self, target, val):
        if isinstance(target, A.Compound):
            self.vars[self._compound_key(target)] = val
        else:
            self.vars[target.name] = val

    def _compound_key(self, node: A.Compound):
        tails = []
        for piece in node.tails:
            if piece == "":
                tails.append("")
            elif _looks_const(piece):
                tails.append(piece.upper())
            else:
                tails.append(self.vars.get(piece.upper(), piece.upper()))
        return node.stem + "." + ".".join(tails)

    def _truth(self, v) -> bool:
        s = str(v).strip()
        if s == "1": return True
        if s == "0": return False
        raise RexxError(34, f"logical value must be 0 or 1, got '{v}'")

    def _numval(self, v) -> Decimal:
        try:
            return Decimal(str(v).strip() or "0")
        except Exception:
            raise RexxError(41, f"bad arithmetic operand '{v}'")

    def _maybe_num(self, v):
        try:
            s = str(v).strip()
            if s == "":
                return None
            return Decimal(s)
        except Exception:
            return None

    def _fmt(self, d: Decimal) -> str:
        if d == d.to_integral_value() and abs(d) < Decimal(10) ** self.digits:
            return str(int(d))
        s = str(d.normalize())
        if "E" in s:
            s = format(d, "f")
        return s


def _looks_const(piece: str) -> bool:
    p = piece.strip()
    if p == "":
        return True
    try:
        Decimal(p)
        return True
    except Exception:
        return p[:1] in "0123456789"


# ---- public engine + legacy shim ----
class RexxEngine:
    def __init__(self, host=None, trace=False, max_clauses=1_000_000):
        self._it = Interpreter(host, trace, max_clauses)

    def run(self, source: str, arg: str = "") -> RexxResult:
        return self._it.run(source, arg)
