"""REXX tokenizer (R1).

REXX has no reserved words, so this emits a flat token stream and the parser
decides meaning.  Subtleties handled: nested ``/* */`` comments, ``'..'``/``".."``
strings with doubled-quote escaping and ``X``/``B`` literal suffixes, and
whitespace-adjacency (``had_space``) so the parser can implement abuttal
concatenation correctly.
"""
from __future__ import annotations

from dataclasses import dataclass

SYMBOL, STRING, OP, SPECIAL, EOL, EOF = "SYMBOL", "STRING", "OP", "SPECIAL", "EOL", "EOF"

# multi-char operators first so the scanner is greedy
_OPS = ["||", "**", "==", "\\=", "//", "/=", "><", "<>", "<=", ">=", "\\<", "\\>",
        "&&", "¬=", "¬<", "¬>", "+", "-", "*", "/", "%", "|", "&", "=", "<", ">",
        "\\", "¬"]
_SPECIAL = "(),;:"


@dataclass
class Token:
    kind: str
    value: str
    had_space: bool = False   # whitespace preceded this token (for abuttal)
    pos: int = 0


def _is_sym_start(c: str) -> bool:
    return c.isalpha() or c in "@#$._!?"


def _is_sym(c: str) -> bool:
    return c.isalnum() or c in "@#$._!?"


def tokenize(src: str) -> list[Token]:
    toks: list[Token] = []
    i, n = 0, len(src)
    pending_space = False
    while i < n:
        c = src[i]
        # comments (nestable)
        if c == "/" and i + 1 < n and src[i + 1] == "*":
            depth, i = 1, i + 2
            while i < n and depth:
                if src[i] == "/" and i + 1 < n and src[i + 1] == "*":
                    depth += 1; i += 2
                elif src[i] == "*" and i + 1 < n and src[i + 1] == "/":
                    depth -= 1; i += 2
                else:
                    i += 1
            pending_space = True
            continue
        # line continuation: trailing comma + newline
        if c == "," and i + 1 < n and src[i + 1] in "\r\n":
            i += 1
            while i < n and src[i] in "\r\n":
                i += 1
            pending_space = True
            continue
        if c in "\r\n":
            toks.append(Token(EOL, "\n", pending_space, i)); pending_space = False
            i += 1
            continue
        if c in " \t":
            pending_space = True; i += 1
            continue
        # strings, with optional X/B suffix
        if c in "'\"":
            q, j = c, i + 1
            buf = []
            while j < n:
                if src[j] == q:
                    if j + 1 < n and src[j + 1] == q:
                        buf.append(q); j += 2; continue
                    break
                buf.append(src[j]); j += 1
            j += 1  # closing quote
            suffix = ""
            text = "".join(buf)
            if j < n and src[j] in "xXbB" and (j + 1 >= n or not _is_sym(src[j + 1])):
                cand = src[j].upper()
                body = text.replace(" ", "")
                if cand == "X":
                    valid = body == "" or all(c in "0123456789abcdefABCDEF" for c in body)
                else:  # B
                    valid = body != "" and all(c in "01" for c in body)
                if valid:
                    suffix = cand; j += 1
            if suffix == "X":
                text = bytes.fromhex(text.replace(" ", "")).decode("latin-1")
            elif suffix == "B":
                bits = text.replace(" ", "")
                bits = bits.rjust(((len(bits) + 7) // 8) * 8, "0")
                text = "".join(chr(int(bits[k:k + 8], 2)) for k in range(0, len(bits), 8))
            toks.append(Token(STRING, text, pending_space, i)); pending_space = False
            i = j
            continue
        # symbols (identifiers + numbers; REXX numbers are symbols)
        if _is_sym_start(c):
            j = i + 1
            while j < n and _is_sym(src[j]):
                j += 1
            toks.append(Token(SYMBOL, src[i:j], pending_space, i)); pending_space = False
            i = j
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i
            while j < n and (src[j].isdigit() or src[j] == "."):
                j += 1
            # exponent
            if j < n and src[j] in "eE":
                k = j + 1
                if k < n and src[k] in "+-":
                    k += 1
                if k < n and src[k].isdigit():
                    j = k
                    while j < n and src[j].isdigit():
                        j += 1
            toks.append(Token(SYMBOL, src[i:j], pending_space, i)); pending_space = False
            i = j
            continue
        if c in _SPECIAL:
            toks.append(Token(SPECIAL, c, pending_space, i)); pending_space = False
            i += 1
            continue
        # operators (greedy longest match)
        for op in _OPS:
            if src.startswith(op, i):
                toks.append(Token(OP, op, pending_space, i)); pending_space = False
                i += len(op)
                break
        else:
            i += 1  # skip anything unknown
    toks.append(Token(EOF, "", pending_space, n))
    return toks
