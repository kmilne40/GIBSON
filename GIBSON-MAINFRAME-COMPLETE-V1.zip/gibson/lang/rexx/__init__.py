"""GIBSON REXX engine (new implementation, R1)."""
from .interp import RexxEngine, RexxResult, RexxError

def run(source: str, arg: str = "", host=None) -> RexxResult:
    return RexxEngine(host).run(source, arg)
