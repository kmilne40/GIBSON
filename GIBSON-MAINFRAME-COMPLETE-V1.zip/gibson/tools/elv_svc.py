"""ELV.SVC - find and call a magic/auth SVC (privilege-escalation lab).

`LIST` scans the SVC table (CVT+x'C8' -> SCVT -> +x'84' -> SVC table) for a user SVC (>200)
whose auth bit is on - a back-door/vendor SVC.  Calling it runs a supervisor-state routine
that flips the caller's ACEE to SPECIAL (modelled by `elv_engine.call_magic_svc`).
Authorised GIBSON training use only.
"""
from __future__ import annotations
import re

_WALK = r"""
/* ELV.SVC - scan user SVCs (>200) for a magic/auth SVC */
cvt  = GetPtr(16)
scvt = GetPtr(cvt+200)
svct = GetPtr(scvt+132)
say '+ ELV.SVC - scanning user SVCs (>200) for a magic/auth SVC ...'
found = 0
do n = 201 to 255
  ent = svct + (n*8)
  rad = GetPtr(ent)
  if rad <> 0 & c2d(bitand(storage(d2x(ent+4),1),'80'x)) > 0 then do
    say '  SVC 'n'  routine=X'd2x(rad)'  AUTH bit ON  <== possible back-door SVC'
    found = found + 1
  end
end
if found = 0 then say '  No magic SVC found.'
say 'ELVSVC00I  To escalate:  ex ''ELV.SVC'' ''NUM=233'''
exit
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
"""


def elv_svc(state, userid: str, command: str) -> str:
    """LIST (default) walks the SVC table; NUM=nnn calls that SVC to escalate."""
    args = command.split("'")
    argstr = args[1].strip() if len(args) >= 3 else (command.split(None, 1)[1].strip() if " " in command else "")
    m = re.search(r"NUM\s*=\s*(\d+)", argstr, re.I)
    if m or argstr.strip().upper() in ("CALL", "GET", "SPECIAL"):
        svc = m.group(1) if m else "233"
        from gibson.tools.elv_engine import call_magic_svc
        return call_magic_svc(state, userid, svc)
    # default: list / scan
    try:
        from gibson.lang.integration import run_rexx_full
        out = run_rexx_full(state, userid, _WALK)
        if out and out.strip():
            return out
    except Exception as exc:
        return f"ELVSVC99E  {type(exc).__name__}: {exc}"
    return "ELVSVC99E  SVC table not available."
