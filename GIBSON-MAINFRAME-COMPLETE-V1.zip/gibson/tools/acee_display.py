"""ACEE display command - dumps the caller's Accessor Environment Element.

Runs a REXX exec that walks the live control-block chain
(PSA+x'224' -> ASCB -> +x'6C' -> ASXB -> +x'C8' -> ACEE) and formats the ACEE, decoding
the ACEEFLG1 SPECIAL/OPERATIONS/AUDITOR bits.  A demonstration that the ACEE exists and is
wired to the user's real RACF attributes.  Authorised GIBSON training use only.
"""
from __future__ import annotations

_SHOWACEE = r"""
/* SHOWACEE - dump the caller's ACEE from live control blocks */
ascb = GetPtr(548)                       /* PSA+x'224' -> ASCB          */
asxb = GetPtr(ascb+108)                  /* ASCB+x'6C' -> ASXB          */
acee = GetPtr(asxb+200)                  /* ASXB+x'C8' -> ACEE          */
say '+-----------------------------------------------------------+'
say '|  ACEE  -  Accessor Environment Element (live control block)|'
say '+-----------------------------------------------------------+'
say ' ACEE address : X'd2x(acee)
say ' Eyecatcher   : 'storage(d2x(acee),4)
say ' Userid       : 'strip(storage(d2x(acee+21),8))
say ' Group        : 'strip(storage(d2x(acee+29),8))
flgb = storage(d2x(acee+38),1)
say ' ACEEFLG1     : X'd2x(c2d(flgb))
say '   SPECIAL    : 'onoff(bitand(flgb,'80'x))
say '   OPERATIONS : 'onoff(bitand(flgb,'40'x))
say '   AUDITOR    : 'onoff(bitand(flgb,'20'x))
say '+-----------------------------------------------------------+'
say 'ACEE00I  ACEE displayed from live storage - no system modified.'
exit
onoff: procedure
  if c2d(arg(1)) > 0 then return 'ON'
  return 'off'
GetPtr: procedure
  return c2d(storage(d2x(arg(1)),4))
"""


def _storage_dump(base: int, raw: bytes, label: str = "ACEE", char_ranges=None) -> str:
    """Classic z/OS-style storage dump: offset, 4x fullword hex, EBCDIC char panel.

    Only the byte ranges in `char_ranges` (character fields) are shown in EBCDIC (so the
    'ACEE' eyecatcher reads C1C3C5C5 and the userid decodes); binary fields - pointers and
    flag bytes such as ACEEFLG1 - are shown raw, as on a real system.  Defaults to the ACEE
    layout: eyecatcher (0-3) and userid+group (x'15'-x'24')."""
    if char_ranges is None:
        char_ranges = [(0, 4), (0x15, 0x25)]

    def is_char(off: int) -> bool:
        return any(lo <= off < hi for lo, hi in char_ranges)

    def to_ebcdic(off: int, b: int) -> int:
        if is_char(off) and 0x20 <= b <= 0x7E:
            try:
                return chr(b).encode("cp037")[0]
            except Exception:
                return b
        return b

    out = ["", f"{label} storage (as it appears in memory) at X'{base:08X}':", ""]
    for off in range(0, len(raw), 16):
        chunk = bytes(to_ebcdic(off + i, c) for i, c in enumerate(raw[off:off + 16])).ljust(16, b"\x00")
        words = " ".join(chunk[i:i + 4].hex().upper() for i in range(0, 16, 4))
        try:
            dec = chunk.decode("cp037")
        except Exception:
            dec = " " * 16
        chars = "".join(c if 32 <= ord(c) < 127 else "." for c in dec)
        out.append(f" +{off:06X}  {words}  *{chars}*")
    return "\n".join(out)


def dump_acee(state, userid: str = "IBMUSER", length: int = 80) -> str:
    """Return a storage dump of the caller's ACEE region."""
    try:
        from gibson.lang.rexx.hoststorage import build_storage
        hs = build_storage(state, userid)
        return _storage_dump(hs.acee, hs.read(hs.acee, length))
    except Exception as exc:
        return f"\nACEE98W  storage dump unavailable: {type(exc).__name__}: {exc}"


def show_acee(state, userid: str = "IBMUSER") -> str:
    """Return a formatted dump of userid's ACEE (decoded fields + a storage dump)."""
    try:
        from gibson.lang.integration import run_rexx_full
        out = run_rexx_full(state, userid, _SHOWACEE)
        if out and out.strip():
            return out.rstrip() + "\n" + dump_acee(state, userid)
    except Exception as exc:
        return f"ACEE99E  could not read ACEE: {type(exc).__name__}: {exc}"
    return "ACEE99E  ACEE not available (control-block image not built)."
