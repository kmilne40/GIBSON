"""GIBSON Software Manager - an SMP/E-style installer for REXX tools (M.2).

Mirrors SMP/E RECEIVE / APPLY / RESTORE and keeps a small JSON CSI inventory, so students
add new REXX tools/scripts without touching Python:

    RECEIVE  - stage a REXX member into the SMPPTS staging library
    APPLY    - install it into the exec library ({user}.MVP.EXEC) so  ex 'NAME'  runs it
    RESTORE  - remove it from the exec library
    LIST     - show the CSI inventory (name / type / status / description)

Authorised GIBSON training use only.
"""
from __future__ import annotations
import json
from typing import Dict, List

_CSI = "SMPE.CSI"
_STAGE = "SMPE.SMPPTS"
_EXEC = "MVP.EXEC"

_SEED = [
    {"name": "ENUM",    "type": "REXX", "status": "APPLIED", "desc": "z/OS enumeration (control-block walker)"},
    {"name": "ELVAPF",  "type": "REXX", "status": "APPLIED", "desc": "APF privilege-escalation lab"},
    {"name": "ELVSVC",  "type": "REXX", "status": "APPLIED", "desc": "SVC privilege-escalation lab"},
    {"name": "ELVSELF", "type": "REXX", "status": "APPLIED", "desc": "ACEE impersonation lab"},
    {"name": "ACEE",    "type": "REXX", "status": "APPLIED", "desc": "ACEE display"},
]


def _q(userid: str, dsn: str, member: str = "") -> str:
    base = f"{userid.upper()}.{dsn}"
    return f"{base}({member.upper()})" if member else base


def load_csi(state, userid: str) -> List[Dict]:
    try:
        return json.loads(state.datasets.read(userid, _q(userid, _CSI)))
    except Exception:
        save_csi(state, userid, _SEED)
        return [dict(x) for x in _SEED]


def save_csi(state, userid: str, csi: List[Dict]) -> None:
    try:
        state.datasets.write(userid, _q(userid, _CSI), json.dumps(csi, indent=1))
    except Exception:
        pass


def _set_status(state, userid, name, status, desc=None):
    csi = load_csi(state, userid)
    ent = next((c for c in csi if c["name"] == name), None)
    if ent:
        ent["status"] = status
        if desc:
            ent["desc"] = desc
    else:
        csi.append({"name": name, "type": "REXX", "status": status, "desc": desc or "user-supplied REXX"})
    save_csi(state, userid, csi)


def receive(state, userid: str, name: str, source_text: str) -> str:
    name = name.upper()
    try:
        state.datasets.write(userid, _q(userid, _STAGE, name), source_text or "/* REXX */\nexit")
    except Exception as exc:
        return f"GIM99901E  RECEIVE failed: {exc}"
    _set_status(state, userid, name, "RECEIVED")
    return f"GIM30001I  {name} RECEIVED into {_q(userid, _STAGE)}."


def apply(state, userid: str, name: str) -> str:
    name = name.upper()
    try:
        src = state.datasets.read(userid, _q(userid, _STAGE, name))
    except Exception:
        return f"GIM99902E  {name} not RECEIVED - issue RECEIVE first."
    try:
        state.datasets.write(userid, _q(userid, _EXEC, name), src)
    except Exception as exc:
        return f"GIM99903E  APPLY failed: {exc}"
    _set_status(state, userid, name, "APPLIED")
    return f"GIM22701I  {name} APPLIED into {_q(userid, _EXEC)} - run it with  ex '{name}'"


def restore(state, userid: str, name: str) -> str:
    name = name.upper()
    try:
        state.datasets.delete(userid, _q(userid, _EXEC, name))
    except Exception:
        pass
    _set_status(state, userid, name, "RECEIVED")
    return f"GIM25601I  {name} RESTORED - removed from the exec library."
