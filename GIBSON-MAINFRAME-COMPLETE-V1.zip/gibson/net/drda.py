"""Minimal DRDA (Distributed Relational Database Architecture) server codec.

Lets Gibson's port-50000 listener answer like a real IBM DB2 for z/OS DRDA
server: it responds to a client EXCSAT (Exchange Server Attributes) with a
valid EXCSATRD reply, and to ACCSEC with ACCSECRD, so that nmap's
``drda-info`` / ``-sV`` detection identifies it as "IBM DB2 Database Server"
and extracts the version, platform, instance and external name.

Wire format (from the DDM / DRDA reference and Wireshark decoding, matching
nmap's nselib/drda.lua):

  DSS header (6 bytes):  length(2) 0xD0 format(1) correlation-id(2)
  DDM object:           length(2) codepoint(2) <parameters...>
  Parameter:            length(2) codepoint(2) <data>

String parameters (EXTNAM/SRVCLSNM/SRVNAM/SRVRLSLV/PRDID) are EBCDIC (cp037);
nmap reads them with getDataAsASCII() i.e. EBCDIC->ASCII.
"""
from __future__ import annotations

import struct
from typing import Optional

# ---- DDM / DRDA code points (subset; values per the DRDA reference) --------
CODEPNT = 0x000C
TYPDEFNAM = 0x002F
TYPDEFOVR = 0x0035
EXCSAT = 0x1041
ACCSEC = 0x106D
SECCHK = 0x106E
PRDID = 0x112E
SRVCLSNM = 0x1147
SVRCOD = 0x1149
SRVRLSLV = 0x115A
EXTNAM = 0x115E
SRVNAM = 0x116D
USRID = 0x11A0
PASSWORD = 0x11A1
SECMEC = 0x11A2
SECCHKCD = 0x11A4
SECCHKRM = 0x1219
MGRLVLLS = 0x1404
EXCSATRD = 0x1443
ACCSECRD = 0x14AC
ACCRDB = 0x2001
RDBNAM = 0x2110
ACCRDBRM = 0x2201
RDBNFNRM = 0x2211
RDBATHRM = 0x22CB

# Severity codes (SVRCOD)
SVRCOD_INFO = 0x0000
SVRCOD_ERROR = 0x0008
# Security check codes (SECCHKCD): 0x00 = successful
SECCHKCD_OK = 0x00

# Security mechanism: user id + password
SECMEC_USRIDPWD = 0x0003

_MAGIC = 0xD0
_RPYDSS = 0x02          # reply DSS (low nibble = DSS type 2)


def _ebcdic(text: str) -> bytes:
    try:
        return text.encode("cp037")
    except Exception:
        return text.encode("ascii", errors="replace")


def _param(codepoint: int, data: bytes) -> bytes:
    """A DDM parameter: length(2) codepoint(2) data; length includes header."""
    return struct.pack(">HH", len(data) + 4, codepoint) + data


def _dss(ddm: bytes, corr: int = 1, fmt: int = _RPYDSS) -> bytes:
    """Wrap a DDM object in a DSS reply header."""
    return struct.pack(">HBBH", len(ddm) + 6, _MAGIC, fmt, corr) + ddm


def parse_request_codepoint(data: bytes) -> Optional[int]:
    """Return the DDM code point of the first request in a DRDA buffer, or None.

    Tolerant: requires only the 6-byte DSS header plus a 4-byte DDM header.
    """
    if not data or len(data) < 10:
        return None
    if data[2] != _MAGIC:
        return None
    try:
        # DDM codepoint sits at offset 8 (after 6-byte DSS + 2-byte DDM length)
        return struct.unpack(">H", data[8:10])[0]
    except Exception:
        return None


def request_correlator(data: bytes) -> int:
    if data and len(data) >= 6 and data[2] == _MAGIC:
        try:
            return struct.unpack(">H", data[4:6])[0]
        except Exception:
            return 1
    return 1


def get_request_param(data: bytes, codepoint: int) -> Optional[bytes]:
    """Extract the data bytes of a parameter (by code point) from the first DDM
    in a DRDA request buffer.  Returns None if absent or unparyseable."""
    try:
        if not data or len(data) < 10 or data[2] != _MAGIC:
            return None
        dss_len = struct.unpack(">H", data[0:2])[0]
        ddm = data[6:dss_len]
        ddm_len = struct.unpack(">H", ddm[0:2])[0]
        off = 4
        while off + 4 <= ddm_len:
            plen = struct.unpack(">H", ddm[off:off + 2])[0]
            pcp = struct.unpack(">H", ddm[off + 2:off + 4])[0]
            if plen < 4:
                break
            if pcp == codepoint:
                return ddm[off + 4:off + plen]
            off += plen
    except Exception:
        return None
    return None


def build_excsatrd(*, extnam: str, srvclsnm: str, srvnam: str, srvrlslv: str,
                   mgrlvlls: bytes = b"", corr: int = 1) -> bytes:
    """Build an EXCSATRD reply object wrapped in a DSS."""
    if not mgrlvlls:
        # A realistic z/OS server manager-level set (AGENT/SQLAM/RDB/SECMGR/
        # CMNTCPIP/CCSIDMGR levels).  nmap does not parse the contents.
        mgrlvlls = bytes.fromhex(
            "1403000724070008240f000814400008147400081c0008146c0008")
    params = b""
    params += _param(EXTNAM, _ebcdic(extnam))
    params += _param(MGRLVLLS, mgrlvlls)
    params += _param(SRVCLSNM, _ebcdic(srvclsnm))
    params += _param(SRVNAM, _ebcdic(srvnam))
    params += _param(SRVRLSLV, _ebcdic(srvrlslv))
    ddm = struct.pack(">HH", len(params) + 4, EXCSATRD) + params
    return _dss(ddm, corr=corr)


def build_accsecrd(*, secmec: int = SECMEC_USRIDPWD, corr: int = 1) -> bytes:
    """Build an ACCSECRD reply advertising a security mechanism (USRID/PWD)."""
    params = _param(SECMEC, struct.pack(">H", secmec))
    ddm = struct.pack(">HH", len(params) + 4, ACCSECRD) + params
    return _dss(ddm, corr=corr)


def build_secchkrm(*, secchkcd: int = SECCHKCD_OK, corr: int = 1) -> bytes:
    """Build a SECCHKRM (security-check reply message).  secchkcd 0 = accepted."""
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_INFO))
    params += _param(SECCHKCD, bytes([secchkcd & 0xFF]))
    ddm = struct.pack(">HH", len(params) + 4, SECCHKRM) + params
    return _dss(ddm, corr=corr)


def build_accrdbrm(*, prdid: str, corr: int = 1) -> bytes:
    """Build an ACCRDBRM (access-RDB reply message) - successful DB connect."""
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_INFO))
    params += _param(PRDID, _ebcdic(prdid))
    params += _param(TYPDEFNAM, _ebcdic("QTDSQLASC"))   # ASCII SQL type def
    ddm = struct.pack(">HH", len(params) + 4, ACCRDBRM) + params
    return _dss(ddm, corr=corr)


def build_rdbnfnrm(*, rdbnam: bytes, corr: int = 1) -> bytes:
    """Build an RDBNFNRM (RDB-not-found reply message)."""
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_ERROR))
    params += _param(RDBNAM, rdbnam)
    ddm = struct.pack(">HH", len(params) + 4, RDBNFNRM) + params
    return _dss(ddm, corr=corr)


def build_db2_zos_excsatrd(state, corr: int = 1) -> bytes:
    """Build a DB2-for-z/OS EXCSATRD from Gibson's DB2 system info."""
    from gibson.apps.db2_sim import SYSTEM_INFO
    ver = str(SYSTEM_INFO.get("VERSION", "12.1"))
    # Map "12.1" -> DSN release level "DSN12015" (DB2 12 for z/OS).
    major = ver.split(".")[0].rjust(2, "0")
    srvrlslv = f"DSN{major}015"
    ssid = SYSTEM_INFO.get("SUBSYSTEM", "DB2A")
    location = SYSTEM_INFO.get("LOCATION", "GIBSONDB2")
    return build_excsatrd(
        extnam=f"{location} DDF {ssid}",
        srvclsnm="QDB2/zOS",        # contains "DB2" -> nmap: IBM DB2 Database Server
        srvnam=location,
        srvrlslv=srvrlslv,
        corr=corr,
    )


def respond(data: bytes, state, session: Optional[dict] = None) -> Optional[bytes]:
    """Given an inbound DRDA request buffer, return the bytes to send back.

    Implements the server side of the DB2 connect handshake:
      EXCSAT  -> EXCSATRD   (exchange server attributes)
      ACCSEC  -> ACCSECRD   (advertise USRID/PWD security)
      SECCHK  -> SECCHKRM   (validate credentials via RACF)
      ACCRDB  -> ACCRDBRM   (open the database if the RDB name matches)
                 RDBNFNRM   (if the requested RDB is not this location)
      EXCSQLIMM -> SQLCARD  (run the statement as the signed-on user)

    ``session`` is a per-connection dict (the caller keeps it across calls) so the
    authenticated userid from SECCHK drives the SQLID of later statements.

    Returns None if the buffer is not recognisable DRDA (caller may fall back
    to the DB2 DAS text response).
    """
    if session is None:
        session = {}
    cp = parse_request_codepoint(data)
    if cp is None:
        return None
    corr = request_correlator(data)
    if cp == EXCSAT:
        return build_db2_zos_excsatrd(state, corr=corr)
    if cp == ACCSEC:
        return build_accsecrd(corr=corr)
    if cp == SECCHK:
        # Validate user id / password against RACF where possible; a real DB2
        # accepts (SECCHKCD=0) and lets RDB-level authority decide afterwards.
        secchkcd = SECCHKCD_OK
        try:
            uid = get_request_param(data, USRID)
            pwd = get_request_param(data, PASSWORD)
            if uid is not None and pwd is not None:
                userid = uid.decode("cp037").strip()
                password = pwd.decode("cp037").strip()
                if userid and not state.racf.verify_password(userid, password):
                    secchkcd = 0x0F          # 0x0F = password invalid
                if secchkcd == SECCHKCD_OK and userid:
                    session["userid"] = userid.upper()   # remember for SQLID
                try:
                    state.record_security_event(
                        userid or "UNKNOWN", "DB2 DRDA SECCHK",
                        f"SECCHKCD={secchkcd:02X}", service="DB2",
                        result="SUCCESS" if secchkcd == 0 else "FAILURE", terminal="DRDA")
                except Exception:
                    pass
        except Exception:
            secchkcd = SECCHKCD_OK
        return build_secchkrm(secchkcd=secchkcd, corr=corr)
    if cp == ACCRDB:
        from gibson.apps.db2_sim import SYSTEM_INFO
        location = SYSTEM_INFO.get("LOCATION", "GIBSONDB2")
        rdb = get_request_param(data, RDBNAM)
        rdbname = ""
        if rdb is not None:
            try:
                rdbname = rdb.decode("cp037").strip()
            except Exception:
                rdbname = ""
        if rdbname and rdbname.upper() != location.upper():
            return build_rdbnfnrm(rdbnam=rdb, corr=corr)
        ver = str(SYSTEM_INFO.get("VERSION", "12.1")).split(".")[0].rjust(2, "0")
        return build_accrdbrm(prdid=f"DSN{ver}015", corr=corr)
    if cp == EXCSQLIMM:
        return respond_sql(data, state, corr=corr, userid=session.get("userid"))
    if cp == PRPSQLSTT:
        return build_sqlcard(0, "prepared", corr=corr)      # ack the prepare
    if cp == OPNQRY:
        return respond_query(data, state, corr=corr, userid=session.get("userid"))
    if cp == CLSQRY:
        return build_sqlcard(0, "query closed", corr=corr)
    # Unknown but valid-looking DRDA: still answer with server attributes so a
    # version probe gets a useful reply.
    return build_db2_zos_excsatrd(state, corr=corr)


# ============================================================================
#  Immediate SQL execution over DRDA  (added: EXCSQLIMM, not just the handshake)
# ============================================================================
# A connected DRDA client can run an immediate statement: it sends EXCSQLIMM plus an
# SQLSTT object with the statement text; we run it through the DB2 simulator and reply
# with an SQLCARD carrying the SQLCODE and result text.  This lets the native PHOSPHOR
# DRDA client run SQL against Gibson without the ibm_db driver.

EXCSQLIMM = 0x200A
SQLSTT = 0x2414
SQLCARD = 0x2408
SQLCARDDATA = 0x2411


def extract_sqlstt(data: bytes) -> Optional[str]:
    """Find the SQLSTT (statement text) anywhere in a DRDA request buffer."""
    i = 0
    n = len(data)
    while i + 4 <= n:
        if data[i + 2:i + 4] == struct.pack(">H", SQLSTT):
            ln = struct.unpack(">H", data[i:i + 2])[0]
            if 4 <= ln <= n - i:
                try:
                    return data[i + 4:i + ln].decode("cp037").strip()
                except Exception:
                    return None
        i += 1
    return None


def build_sqlcard(sqlcode: int, text: str, corr: int = 1) -> bytes:
    blob = struct.pack(">i", sqlcode) + _ebcdic(text)[:4096]
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_INFO if sqlcode >= 0 else SVRCOD_ERROR))
    params += _param(SQLCARDDATA, blob)
    ddm = struct.pack(">HH", len(params) + 4, SQLCARD) + params
    return _dss(ddm, corr=corr)


def respond_sql(data: bytes, state, corr: int = 1, userid: Optional[str] = None) -> Optional[bytes]:
    """Handle EXCSQLIMM by running the statement through the DB2 simulator as `userid`."""
    sql = extract_sqlstt(data)
    if sql is None:
        return build_sqlcard(-104, "SQLSTT not found", corr=corr)
    try:
        from gibson.apps.db2_sim import Db2Simulator
        who = userid or getattr(state, "current_user", None) or "IBMUSER"
        db2 = Db2Simulator(state)
        rows = db2.run_sql(sql, userid=who)
        if isinstance(rows, list):
            lines = [" | ".join(f"{k}={v}" for k, v in r.items()) for r in rows[:50]]
            text = "\n".join(lines) if lines else "0 rows"
        else:
            text = str(rows)
        return build_sqlcard(0, text, corr=corr)
    except ValueError as e:
        # Db2Simulator raises "SQLCODE=-nnn, ..." for SQL errors
        msg = str(e)
        code = -1
        import re as _re
        m = _re.search(r"SQLCODE=(-?\d+)", msg)
        if m:
            code = int(m.group(1))
        return build_sqlcard(code, msg, corr=corr)
    except Exception as e:
        return build_sqlcard(-901, f"error: {e}", corr=corr)


# ============================================================================
#  Query result sets over DRDA  (OPNQRY -> QRYDSC + QRYDTA)  [added]
# ============================================================================
# A real DB2 client runs a SELECT with OPNQRY and gets back a QRYDSC (an FD:OCA
# descriptor of the columns) and QRYDTA (the rows).  Previously Gibson only did
# EXCSQLIMM -> SQLCARD (a text blob).  Now it emits a structured, self-describing
# result set so PHOSPHOR's native client can retrieve typed rows without a driver.
#
# Wire format (symmetric with PHOSPHOR's decoder; spec-shaped but a subset - real
# z/OS FD:OCA carries more type/CCSID detail):
#   QRYDSC body : ncols(2) then per col [ type(2) maxlen(2) nullable(1) namelen(1) name ]
#   QRYDTA body : per row 0x00 then per col [ nullind(1) value ]  ; 0xFF ends the rows
#   value by type: VARCHAR/CHAR -> len(2)+EBCDIC ; SMALLINT -> 2 ; INTEGER -> 4

OPNQRY = 0x200C
PRPSQLSTT = 0x200D
CLSQRY = 0x2005
CNTQRY = 0x2006
QRYDSC = 0x241A
QRYDTA = 0x241B
OPNQRYRM = 0x2205
ENDQRYRM = 0x220B
SQLDARD = 0x2412

T_VARCHAR = 448
T_CHAR = 452
T_SMALLINT = 500
T_INTEGER = 496


def _is_int(v) -> bool:
    try:
        int(str(v)); return True
    except (TypeError, ValueError):
        return False


def build_qrydsc(columns) -> bytes:
    """columns: list of (name, type_code, maxlen)."""
    body = struct.pack(">H", len(columns))
    for name, tcode, maxlen in columns:
        nm = _ebcdic(name)[:255]
        body += struct.pack(">HHB B", tcode, maxlen, 1, len(nm)) + nm
    return _dss(struct.pack(">HH", len(body) + 4, QRYDSC) + body, fmt=_OBJDSS_FMT)


def build_qrydta(columns, rows) -> bytes:
    body = b""
    for row in rows:
        body += b"\x00"
        for name, tcode, maxlen in columns:
            val = row.get(name)
            if val is None:
                body += b"\xFF"; continue
            body += b"\x00"
            if tcode in (T_VARCHAR, T_CHAR):
                b = _ebcdic(str(val))
                body += struct.pack(">H", len(b)) + b
            elif tcode == T_SMALLINT:
                body += struct.pack(">h", int(val) & 0xFFFF if int(val) >= 0 else int(val))
            elif tcode == T_INTEGER:
                body += struct.pack(">i", int(val))
            else:
                b = _ebcdic(str(val)); body += struct.pack(">H", len(b)) + b
    body += b"\xFF"
    return _dss(struct.pack(">HH", len(body) + 4, QRYDTA) + body, fmt=_OBJDSS_FMT)


def build_opnqryrm(corr: int = 1) -> bytes:
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_INFO))
    return _dss(struct.pack(">HH", len(params) + 4, OPNQRYRM) + params, corr=corr)


def build_endqryrm(sqlcode: int = 100, corr: int = 1) -> bytes:
    params = _param(SVRCOD, struct.pack(">H", SVRCOD_INFO))
    return _dss(struct.pack(">HH", len(params) + 4, ENDQRYRM) + params, corr=corr) \
        + build_sqlcard(sqlcode, "end of data", corr=corr)


# OBJDSS format byte (object data stream) for QRYDSC/QRYDTA
_OBJDSS_FMT = 0x03


def _columns_from_rows(rows):
    """Infer (name, type, maxlen) per column from the sim's row dicts."""
    if not rows:
        return []
    cols = []
    first = rows[0]
    for k in first.keys():
        vals = [str(r.get(k, "")) for r in rows]
        if all(_is_int(v) for v in vals if v != ""):
            span = max((abs(int(v)) for v in vals if v != ""), default=0)
            tcode = T_INTEGER if span > 32767 else T_SMALLINT
            cols.append((k, tcode, 4 if tcode == T_INTEGER else 2))
        else:
            maxlen = max((len(v) for v in vals), default=0) or 1
            cols.append((k, T_VARCHAR, min(maxlen, 32704)))
    return cols


def respond_query(data: bytes, state, corr: int = 1, userid: Optional[str] = None) -> Optional[bytes]:
    """OPNQRY: run the SELECT and stream OPNQRYRM + QRYDSC + QRYDTA + ENDQRYRM."""
    sql = extract_sqlstt(data)
    if sql is None:
        return build_sqlcard(-104, "SQLSTT not found", corr=corr)
    try:
        from gibson.apps.db2_sim import Db2Simulator
        who = userid or getattr(state, "current_user", None) or "IBMUSER"
        rows = Db2Simulator(state).run_sql(sql, userid=who)
        if not isinstance(rows, list):
            rows = [{"RESULT": str(rows)}]
        cols = _columns_from_rows(rows)
        out = build_opnqryrm(corr)
        if cols:
            out += build_qrydsc(cols) + build_qrydta(cols, rows)
        out += build_endqryrm(0 if rows else 100, corr)
        return out
    except ValueError as e:
        import re as _re
        m = _re.search(r"SQLCODE=(-?\d+)", str(e))
        return build_sqlcard(int(m.group(1)) if m else -1, str(e), corr=corr)
    except Exception as e:
        return build_sqlcard(-901, f"error: {e}", corr=corr)
