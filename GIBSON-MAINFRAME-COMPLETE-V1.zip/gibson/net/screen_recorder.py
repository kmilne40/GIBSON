"""Server-side 3270 screen recorder.

Writes each rendered screen to a numbered text file (``GIB001.txt``,
``GIB002.txt`` ...) in a target directory, the way x3270/c3270 PrintText saves
screens.  Two ways to drive it:

* continuous  - set ``GIBSON_SCREEN_RECORD=1`` (or a directory path) in the
  environment before starting GIBSON; every screen sent to a TN3270 client is
  saved.  ``GIBSON_SCREEN_DIR`` overrides the directory (default ``/tmp``).
* on demand   - type ``LPR`` at any panel command line to snapshot the current
  screen, or ``LPR ON`` / ``LPR OFF`` to toggle continuous recording live.

Consecutive identical screens are de-duplicated so a redraw does not spam files.
"""
from __future__ import annotations

import glob
import os
import re
import time
from typing import Optional

_TRUE = {"1", "on", "true", "yes", "y"}
_FALSE = {"0", "off", "false", "no", "n", ""}


class ScreenRecorder:
    def __init__(self, directory: str = "/tmp", prefix: str = "GIB",
                 enabled: bool = False, header: bool = True):
        self.directory = directory or "/tmp"
        self.prefix = prefix or "GIB"
        self.enabled = enabled
        self.header = header
        self._n: Optional[int] = None      # lazily seeded from existing files
        self._last_text: Optional[str] = None

    @classmethod
    def from_env(cls, env: Optional[dict] = None) -> "ScreenRecorder":
        env = env if env is not None else os.environ
        val = (env.get("GIBSON_SCREEN_RECORD", "") or "").strip()
        directory = (env.get("GIBSON_SCREEN_DIR", "") or "/tmp").strip() or "/tmp"
        prefix = (env.get("GIBSON_SCREEN_PREFIX", "") or "GIB").strip() or "GIB"
        enabled = False
        low = val.lower()
        if val:
            if low in _FALSE:
                enabled = False
            elif "/" in val:              # a directory path both sets dir and enables
                directory = val
                enabled = True
            else:                          # "1"/"on"/anything truthy
                enabled = low in _TRUE or low not in _FALSE
        return cls(directory=directory, prefix=prefix, enabled=enabled)

    # ------------------------------------------------------------------ #
    def _seed(self) -> int:
        mx = 0
        pat = re.compile(rf"{re.escape(self.prefix)}(\d+)\.txt$")
        try:
            for f in glob.glob(os.path.join(self.directory, f"{self.prefix}*.txt")):
                m = pat.search(os.path.basename(f))
                if m:
                    mx = max(mx, int(m.group(1)))
        except Exception:
            pass
        return mx

    def _next_path(self) -> str:
        if self._n is None:
            self._n = self._seed()
        self._n += 1
        return os.path.join(self.directory, f"{self.prefix}{self._n:03d}.txt")

    @staticmethod
    def _screen_text(screen) -> Optional[str]:
        if screen is None:
            return None
        try:
            if hasattr(screen, "render_plain"):
                return screen.render_plain()
            if hasattr(screen, "display_text"):
                return screen.display_text()
        except Exception:
            return None
        return None

    def capture(self, screen, *, force: bool = False) -> Optional[str]:
        """Write one screen to the next GIBnnn.txt file.  Returns the path, or
        None if there was nothing new to write (deduped) or on error."""
        text = self._screen_text(screen)
        if text is None:
            return None
        norm = "\n".join(line.rstrip() for line in text.splitlines()).rstrip("\n")
        if not force and norm == self._last_text:
            return None
        self._last_text = norm
        path = self._next_path()
        try:
            os.makedirs(self.directory, exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                if self.header:
                    fh.write(f"* GIBSON screen capture  {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                    fh.write("*" + "-" * 78 + "\n")
                fh.write(norm + "\n")
        except Exception:
            return None
        return path

    def record(self, screen) -> Optional[str]:
        """Capture only when continuous recording is enabled."""
        if not self.enabled:
            return None
        return self.capture(screen)
