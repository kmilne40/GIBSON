"""IND$FILE DFT-mode (structured-field 0xD0) host implementation.

This is the *modern* IND$FILE file-transfer protocol used by c3270, x3270,
wc3270 and web3270 (as opposed to the older CUT/screen-buffer scheme in
``ft_cut_host``).  The host drives the exchange over Write Structured Field
(command 0xF3) frames carrying a 0xD0 structured field; the terminal answers
with an AID-0x88 structured-field reply.

Message flow (host perspective)::

    GET  (download, host -> terminal):
        -> OPEN (00 12) + CONTENTS + RECORDSIZE      <- 00 09  (ack)
        -> DATA (47 04) + data-record            [*] <- 47 05 + record-number
        -> CLOSE (41 12)                             <- 41 09  (ack)

    PUT  (upload, terminal -> host):
        -> OPEN (00 12) + CONTENTS + RECORDSIZE      <- 00 09  (ack)
        -> GET-REQ (46 11)                       [*] <- 46 05 + rec-num + data
                                                  or <- 46 08 + EOF error rec
        -> CLOSE (41 12)                             <- 41 09  (ack)

Wire format matches web3270's client exactly (validated by a loopback against
its real session.js), which is a faithful implementation of the IBM 3270 file
transfer / IND$FILE DFT protocol, so it also interoperates with c3270/x3270.
"""
from __future__ import annotations

from typing import Callable, Optional

# ── structured-field / protocol constants ──────────────────────────────────
SF_INDFILE = 0xD0          # structured-field id for IND$FILE
AID_SF     = 0x88          # AID used by the terminal's SF reply
WSF_CMD    = 0xF3          # Write Structured Field 3270 command

# request-type / subtype pairs the host sends
RT_OPEN,   ST_OPEN   = 0x00, 0x12
RT_DATA,   ST_DATA   = 0x47, 0x04     # download data -> terminal
RT_GETREQ, ST_GETREQ = 0x46, 0x11     # ask terminal for the next upload chunk
RT_CLOSE,  ST_CLOSE  = 0x41, 0x12

# record tags (generic form: tag, len, data...) — DATA is special (see below)
REC_CONTENTS   = 0x03
REC_RECORDSIZE = 0x08
REC_RECORDNUM  = 0x63
REC_ERROR      = 0x69
REC_DATA       = 0xC0

ERR_EOF    = 0x2200
ERR_CANCEL = 0x4700

EBCDIC_NL = 0x15           # record separator inside text-mode data


class DftError(Exception):
    pass


# ── frame builders ─────────────────────────────────────────────────────────
def _sf(rt: int, st: int, *records: bytes) -> bytes:
    """Wrap RT/ST + records into a 0xD0 structured field with a length prefix.
    The 2-byte length is inclusive of itself (per the 3270 SF convention)."""
    body = bytes([SF_INDFILE, rt, st]) + b"".join(records)
    ln = len(body) + 2
    return bytes([(ln >> 8) & 0xFF, ln & 0xFF]) + body


def _rec_contents(is_binary: bool) -> bytes:
    s = b"FT:DATA" + (b" BINARY" if is_binary else b"")
    return bytes([REC_CONTENTS, len(s) + 2]) + s


def _rec_recordsize(n: int) -> bytes:
    return bytes([REC_RECORDSIZE, 4, (n >> 8) & 0xFF, n & 0xFF])


def _rec_data(chunk: bytes) -> bytes:
    # C0 80 61 <total-len hi> <total-len lo> <data> ; 0x61 = uncompressed
    total = 5 + len(chunk)
    return bytes([REC_DATA, 0x80, 0x61, (total >> 8) & 0xFF, total & 0xFF]) + chunk


# ── reply parsing ──────────────────────────────────────────────────────────
def parse_reply(pkt: bytes) -> tuple[int, int, bytes]:
    """Return (cmd, subcmd, extra) from a terminal AID-0x88 SF reply."""
    if not pkt:
        raise DftError("empty reply (client disconnected)")
    if pkt[0] != AID_SF:
        raise DftError(f"unexpected AID 0x{pkt[0]:02x} (want 0x88)")
    if len(pkt) < 6:
        raise DftError("short SF reply")
    ln = (pkt[1] << 8) | pkt[2]
    if pkt[3] != SF_INDFILE:
        raise DftError(f"reply SF id 0x{pkt[3]:02x} (want 0xD0)")
    end = min(len(pkt), 1 + ln)
    return pkt[4], pkt[5], pkt[6:end]


def parse_records(buf: bytes) -> list[dict]:
    """Parse type-tagged sub-records (mirror of web3270's client parser)."""
    out: list[dict] = []
    p = 0
    n = len(buf)
    while p < n:
        tag = buf[p]
        if tag == REC_DATA:
            if p + 5 > n:
                break
            total = (buf[p + 3] << 8) | buf[p + 4]
            if total < 5 or p + total > n:
                break
            out.append({"tag": tag, "data": buf[p + 5:p + total]})
            p += total
        else:
            if p + 1 >= n:
                break
            ln = buf[p + 1] or 2
            if p + ln > n:
                break
            out.append({"tag": tag, "data": buf[p + 2:p + ln]})
            p += ln
    return out


class DftChannel:
    """Frames a 0xD0 structured field as a 3270 WSF and exchanges it for one
    terminal reply.  ``send_bytes`` is a raw socket write; ``recv_packet``
    returns one inbound packet (AID first, telnet framing already removed)."""

    IAC = 0xFF
    EOR = 0xEF

    def __init__(self, send_bytes: Callable[[bytes], None],
                 recv_packet: Callable[[], bytes]):
        self._send = send_bytes
        self._recv = recv_packet

    def exchange(self, sf: bytes) -> bytes:
        stream = bytes([WSF_CMD]) + sf
        body = stream.replace(b"\xff", b"\xff\xff")          # escape IAC
        self._send(body + bytes([self.IAC, self.EOR]))       # terminate record
        pkt = self._recv()
        if not pkt:
            raise DftError("client disconnected during transfer")
        return pkt


class DftHost:
    """Host side of an IND$FILE DFT transfer over one live 3270 session."""

    def __init__(self, channel: DftChannel, *, max_chunk: int = 2048):
        self.ch = channel
        self.max_chunk = max_chunk

    # -- helpers -----------------------------------------------------------
    def _open(self, is_binary: bool) -> None:
        cmd, sub, _ = parse_reply(self.ch.exchange(
            _sf(RT_OPEN, ST_OPEN, _rec_contents(is_binary),
                _rec_recordsize(self.max_chunk))))
        # Positive OPEN acknowledgement. web3270's bundled client replies 00/09;
        # real emulators (c3270/x3270) reply 00/08. Both are valid positive acks
        # for the same OPEN, so accept either rather than only web3270's variant.
        if cmd != 0x00 or sub not in (0x08, 0x09):
            raise DftError(f"OPEN not acknowledged (got {cmd:02x}/{sub:02x})")

    def _close(self) -> None:
        cmd, sub, _ = parse_reply(self.ch.exchange(_sf(RT_CLOSE, ST_CLOSE)))
        # CLOSE ack: web3270 replies 41/09, real emulators 41/08 - accept either.
        if cmd != 0x41 or sub not in (0x08, 0x09):
            raise DftError(f"CLOSE not acknowledged (got {cmd:02x}/{sub:02x})")

    # -- download: host -> terminal ---------------------------------------
    def get(self, data: bytes, *, is_binary: bool = False) -> None:
        self._open(is_binary)
        off = 0
        while off < len(data):
            chunk = data[off:off + self.max_chunk]
            off += len(chunk)
            cmd, sub, _ = parse_reply(self.ch.exchange(
                _sf(RT_DATA, ST_DATA, _rec_data(chunk))))
            if cmd != 0x47:
                raise DftError(f"DATA not acknowledged (got {cmd:02x}/{sub:02x})")
        self._close()

    # -- upload: terminal -> host -----------------------------------------
    def put(self, *, is_binary: bool = False) -> bytes:
        self._open(is_binary)
        data = bytearray()
        guard = 0
        while True:
            guard += 1
            if guard > 1_000_000:
                raise DftError("upload exceeded frame guard")
            cmd, sub, extra = parse_reply(self.ch.exchange(_sf(RT_GETREQ, ST_GETREQ)))
            if cmd == 0x46 and sub == 0x08:        # EOF
                break
            if cmd == 0x46 and sub == 0x05:        # a data chunk
                for rec in parse_records(extra):
                    if rec["tag"] == REC_DATA:
                        data += rec["data"]
                continue
            raise DftError(f"unexpected upload reply {cmd:02x}/{sub:02x}")
        self._close()
        return bytes(data)
