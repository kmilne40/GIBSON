"""Sandboxed reverse-shell landing.

When a cicspwn reverse-shell job is submitted through the CICS SPOOL interface,
the JCL contains a REXX stub that connects back to the attacker's listener
(rh='<host>';rp='<port>') and serves a shell.  On a real z/OS box that stub runs
and yields a genuine shell.  GIBSON reproduces the *observable* behaviour for the
student - it connects back to the listener and drives an interactive shell - but
that shell is GIBSON's fully-simulated OMVS/TSO session over fake data, so nothing
on the host is ever exposed.

Safety rails:
  * only ever *connects out* to the callback the payload names - it never binds,
    listens or accepts;
  * the callback host must be loopback or RFC1918 (the lab network) - public
    addresses are refused, so GIBSON can't be turned into an outbound relay;
  * the served shell is OmvsShellSession against simulated state - no real
    command ever executes;
  * it can be disabled entirely with GIBSON_REVSHELL_LANDING=0.
"""
from __future__ import annotations

import ipaddress
import re
import socket
import threading
from typing import Optional, Tuple

_CALLBACK_RE = re.compile(r"rh\s*=\s*'([^']+)'\s*;\s*rp\s*=\s*'([^']+)'", re.IGNORECASE)


def extract_callback(jcl: str) -> Optional[Tuple[str, int]]:
    """Pull (host, port) out of the cicspwn REXX stub, if present."""
    m = _CALLBACK_RE.search(jcl or "")
    if not m:
        return None
    host = m.group(1).strip()
    try:
        port = int(re.sub(r"\D", "", m.group(2)))
    except ValueError:
        return None
    if not host or not (0 < port < 65536):
        return None
    return host, port


def _in_lab_scope(host: str) -> bool:
    """Only loopback / RFC1918 / link-local callbacks are allowed."""
    try:
        ip = ipaddress.ip_address(socket.gethostbyname(host))
    except Exception:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


class _SockShellIO:
    """Adapt a connected socket to OmvsShellSession's reader/writer contract."""

    class _Result:
        __slots__ = ("text", "key")

        def __init__(self, text: str, key: str = ""):
            self.text = text
            self.key = key

    def __init__(self, sock: socket.socket):
        self.sock = sock
        self._buf = b""

    def write(self, text: str) -> None:
        if not text:
            return
        data = text.encode("latin-1", "replace") if isinstance(text, str) else text
        try:
            self.sock.sendall(data)
        except OSError:
            raise _Disconnected()

    def __call__(self, prompt: str = "", hidden: bool = False):
        # mainframe sends the prompt, then waits for the operator's command
        try:
            self.write(prompt)
        except _Disconnected:
            return self._Result("", "EOF")
        line = self._recv_line()
        if line is None:
            return self._Result("", "EOF")
        return self._Result(line, "")

    def _recv_line(self) -> Optional[str]:
        while b"\n" not in self._buf:
            try:
                chunk = self.sock.recv(4096)
            except OSError:
                chunk = b""
            if not chunk:
                if self._buf:
                    line, self._buf = self._buf, b""
                    return line.decode("latin-1", "replace").rstrip("\r")
                return None
            self._buf += chunk
        line, _, self._buf = self._buf.partition(b"\n")
        return line.decode("latin-1", "replace").rstrip("\r")


class _Disconnected(Exception):
    pass


def land_reverse_shell(state, jcl: str, owner: str, record: Optional[dict] = None) -> bool:
    """If the JCL carries a reverse-shell callback, connect back (in a daemon
    thread) and serve the simulated shell.  Returns True if a landing started."""
    if not getattr(state.config, "reverse_shell_landing", True):
        return False
    cb = extract_callback(jcl)
    if not cb:
        return False
    host, port = cb
    if not _in_lab_scope(host):
        if record is not None:
            record["landing"] = f"refused (out-of-scope callback {host})"
        return False
    kind = "USS" if ("BPXWUNIX" in (jcl or "").upper() or "BPXBATCH" in (jcl or "").upper()) else "TSO"

    def _worker():
        try:
            s = socket.create_connection((host, port), timeout=8)
            s.settimeout(300)          # generous idle timeout for the interactive session
        except OSError:
            if record is not None:
                record["landing"] = f"no listener at {host}:{port}"
            return
        if record is not None:
            record["landing"] = f"connected to {host}:{port}"
            record["active"] = True
        try:
            from gibson.apps.omvs import OmvsShellSession
            from gibson.apps.tso import TsoCommandProcessor
            mode = "USS" if kind == "USS" else "OMVS"
            shell = OmvsShellSession(state, owner,
                                     TsoCommandProcessor(state, owner), mode=mode)
            io = _SockShellIO(s)
            shell.run_interactive(io, io.write)
        except Exception:
            pass
        finally:
            try:
                s.close()
            except OSError:
                pass
            if record is not None:
                record["active"] = False
                record["landing"] = record.get("landing", "") + " (closed)"

    threading.Thread(target=_worker, daemon=True, name="GibsonRevShell").start()
    return True
