from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass
class IndFileOptions:
    direction: str = "GET"
    host: str = "TSO"
    host_file: str = ""
    local_file: str = "DESKTOP.FILE"
    mode: str = "ASCII"
    cr: str = "KEEP"
    exist: str = "REPLACE"
    recfm: str = "FB"
    lrecl: int = 80
    blksize: int = 6160


def parse_options(text: str) -> IndFileOptions:
    opts: dict[str, str] = {}
    for k, v in re.findall(r"\b([A-Z$]+)\(([^)]*)\)", text or "", re.I):
        opts[k.upper()] = v.strip().strip("'").strip('"')
    for k, v in re.findall(r"\b([A-Za-z]+)=([^,\s)]+)", text or ""):
        opts[k.upper()] = v.strip().strip("'").strip('"')
    u = (text or "").upper()
    direction = "PUT" if any(x in u for x in [" PUT", " SEND", "DIRECTION=SEND"]) else "GET"
    lrecl = int(opts.get("LRECL", "80") or 80)
    blksize = int(opts.get("BLKSIZE", "6160") or 6160)
    # Canonical IND$FILE client syntax uses bare keywords, e.g.
    #   IND$FILE GET FOO.TEXT A:FOO.TXT ASCII CRLF
    # Honour those in addition to the MODE(...)/CR(...) forms.
    tokens = re.findall(r"\b([A-Z]+)\b", u)
    mode = opts.get("MODE", "").upper()
    if not mode:
        mode = "BINARY" if "BINARY" in tokens else "ASCII"
    cr = opts.get("CR", "").upper()
    if not cr:
        if "NOCRLF" in tokens or "NOCR" in tokens:
            cr = "REMOVE"
        elif "CRLF" in tokens:
            cr = "CRLF"     # direction-aware line-ending translation (resolved below)
        else:
            cr = "KEEP"
    # Host data set name.  The keyword forms DSN(...)/DATASET(...)/HOSTFILE(...)
    # win when present; otherwise fall back to the canonical positional syntax
    # emitted by real emulators (c3270/x3270 File->Transfer):
    #   IND$FILE GET DATA.SET [localfile] [ASCII|BINARY] [CRLF] ...
    # The first bare token after the GET/PUT verb is the host data set.
    host_file = opts.get("DSN") or opts.get("DATASET") or opts.get("HOSTFILE") or ""
    if not host_file:
        _KW = {"IND$FILE", "INDSFILE", "IND\\$FILE", "GET", "PUT", "SEND",
               "RECEIVE", "ASCII", "BINARY", "CRLF", "NOCRLF", "NOCR", "CR",
               "APPEND", "REPLACE", "NEW", "OLD", "MOD", "TSO", "CICS", "VM"}
        _OPTKW = {"MODE", "CR", "DSN", "DATASET", "HOSTFILE", "HOST", "EXIST",
                  "RECFM", "LRECL", "BLKSIZE", "LOCAL", "LOCALFILE", "DIRECTION"}
        for tok in (text or "").split():
            up = tok.upper()
            if up in _KW or "=" in tok:
                continue
            if "(" in tok and tok.split("(", 1)[0].upper() in _OPTKW:
                continue  # a MODE(BINARY)-style option, not a DSN(MEMBER)
            host_file = tok.strip().strip("'").strip('"')
            break
    return IndFileOptions(
        direction=direction,
        host=opts.get("HOST", "TSO").upper(),
        host_file=host_file,
        local_file=opts.get("LOCAL") or opts.get("LOCALFILE") or "DESKTOP.FILE",
        mode=mode,
        cr=cr,
        exist=opts.get("EXIST", "REPLACE").upper(),
        recfm=opts.get("RECFM", "FB").upper(),
        lrecl=lrecl,
        blksize=blksize,
    )
