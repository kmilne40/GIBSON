"""zSecure-style compliance framework (STANDARD / DOMAIN / RULE).

Real zSecure ships automated compliance frameworks - the DISA **STIG** for z/OS
and **PCI-DSS** - expressed as STANDARD -> DOMAIN -> RULE, each rule producing a
PASS/FAIL with a control id, rolled up into a compliance percentage.  This module
implements that model over Gibson's live RACF database and the CKFREEZE snapshot,
so the output reads like the report a security auditor actually presents.

Control ids use the DISA z/OS STIG rule-id families (ACP*/RACF*/ZUSS* = the
Access-Control-Product / RACF / z/OS-UNIX groupings) and the PCI-DSS requirement
numbers; they are representative of those frameworks for training purposes.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Tuple


@dataclass
class Rule:
    id: str
    standard: str            # STIG | PCI
    domain: str
    severity: str            # CAT I|II|III  (STIG)  /  requirement (PCI)
    title: str
    check: Callable[["Ctx"], Tuple[bool, str]]
    fix: str = ""


class Ctx:
    """State computed once and shared by all rules."""
    def __init__(self, state: Any):
        self.state = state
        from gibson.core.carla import _racf_rows
        from gibson.core.ckfreeze import get_ckfreeze
        self.racf = _racf_rows(state)
        self.ck = get_ckfreeze(state)
        self.special = [r["USERID"] for r in self.racf if r["SPECIAL"]]
        self.operations = [r["USERID"] for r in self.racf if r["OPERATIONS"]]
        self.uid0 = [r["USERID"] for r in self.racf if str(r["UID"]).strip() == "0"]
        self.mfa_users = [r["USERID"] for r in self.racf if r["MFA"]]
        apf = self.ck.apf()
        self.writable_apf = [r["DSNAME"] for r in apf if r["WRITABLE"] == "YES"]
        self.writable_sens = [r["DSNAME"] for r in self.ck.sensitive_datasets()
                              if r["WRITABLE"] == "YES"]
        self.risky_stc = [r["JOBNAME"] for r in self.ck.started_tasks() if r["RISK"] == "YES"]
        pol = getattr(state, "password_policy", None)
        self.pw_interval = int(getattr(pol, "interval", 90) or 90)
        self.inactive = int(getattr(pol, "inactive", 0) or 0) or 90
        self.mfa_active = bool(getattr(state, "mfa_enabled", False))
        self.smf80 = self._smf80()
        self.protectall = True   # Gibson SETROPTS ships PROTECTALL(FAIL)

    def _smf80(self) -> bool:
        try:
            txt = self.state.datasets.read("IBMUSER", "SYS1.PARMLIB(SMFPRM00)")
            return "80" in txt.replace(" ", "")
        except Exception:
            return True


def _limited(names: List[str], cap: int, label: str) -> Tuple[bool, str]:
    ok = len(names) <= cap
    return ok, f"{len(names)} {label}: {', '.join(names[:6]) or 'none'}"


RULES: List[Rule] = [
    # ---- STIG ----------------------------------------------------------
    Rule("AAMV0450", "STIG", "SYSTEM", "CAT I",
         "APF-authorized libraries are protected from update by non-privileged users",
         lambda c: (not c.writable_apf,
                    "writable APF libraries: " + (", ".join(c.writable_apf) or "none")),
         "Remove UPDATE/ALTER from non-admin ids; profile the library UACC(NONE)."),
    Rule("ACP00280", "STIG", "PRIVILEGE", "CAT II",
         "The SPECIAL attribute is restricted to justified users",
         lambda c: _limited(c.special, 3, "SPECIAL users"),
         "Remove SPECIAL from unjustified ids; use group-SPECIAL scoped to need."),
    Rule("ACP00282", "STIG", "PRIVILEGE", "CAT II",
         "The OPERATIONS attribute is restricted to justified users",
         lambda c: _limited(c.operations, 2, "OPERATIONS users"),
         "Replace OPERATIONS with explicit dataset PERMITs."),
    Rule("ACP00294", "STIG", "PRIVILEGE", "CAT II",
         "Started tasks do not run with SPECIAL/OPERATIONS/UID(0)",
         lambda c: (not c.risky_stc,
                    "privileged started tasks: " + (", ".join(c.risky_stc) or "none")),
         "Assign each STC a dedicated, least-privileged STARTED-class id."),
    Rule("ZUSS0011", "STIG", "UNIX", "CAT II",
         "z/OS UNIX superuser (UID 0) is restricted to justified users",
         lambda c: _limited(c.uid0, 2, "UID(0) users"),
         "Give users BPX.SUPERUSER via su instead of a permanent UID(0)."),
    Rule("ACP00320", "STIG", "SYSTEM", "CAT II",
         "SETROPTS PROTECTALL(FAIL) is in effect",
         lambda c: (c.protectall, "PROTECTALL(FAIL) " + ("ACTIVE" if c.protectall else "INACTIVE")),
         "SETROPTS PROTECTALL(FAIL)."),
    Rule("RACF0640", "STIG", "IDENTIFICATION", "CAT II",
         "Password change interval is 60 days or less",
         lambda c: (c.pw_interval <= 60, f"password change interval is {c.pw_interval} days"),
         "SETROPTS PASSWORD(INTERVAL(60))."),
    Rule("ACP00340", "STIG", "SYSTEM", "CAT II",
         "Sensitive system data sets are protected from update by non-privileged users",
         lambda c: (not c.writable_sens,
                    "writable sensitive data sets: " + (", ".join(c.writable_sens) or "none")),
         "Profile PARMLIB/PROCLIB/RACFDS with UACC(NONE) and admin-only UPDATE."),
    Rule("ACP00130", "STIG", "AUDIT", "CAT II",
         "SMF type 80 (RACF) records are being collected",
         lambda c: (c.smf80, "SMF type 80 recording " + ("ACTIVE" if c.smf80 else "NOT ACTIVE")),
         "SMFPRM00 SYS(TYPE(...,80,...))."),
    Rule("RACF0770", "STIG", "IDENTIFICATION", "CAT III",
         "Inactive user ids are automatically revoked",
         lambda c: (c.inactive <= 90, f"INACTIVE interval is {c.inactive} days"),
         "SETROPTS INACTIVE(90)."),
    # ---- PCI-DSS -------------------------------------------------------
    Rule("PCI-2.2", "PCI", "SECURE-CONFIG", "Req 2.2",
         "System components are configured securely (no writable authorized libraries)",
         lambda c: (not c.writable_apf,
                    "writable APF libraries: " + (", ".join(c.writable_apf) or "none")),
         "Harden APF library access per the configuration standard."),
    Rule("PCI-7.1.2", "PCI", "ACCESS-CONTROL", "Req 7.1.2",
         "Privileged access is restricted to least privilege",
         lambda c: (len(c.special) + len(c.operations) <= 4,
                    f"{len(c.special)} SPECIAL + {len(c.operations)} OPERATIONS users"),
         "Reduce SPECIAL/OPERATIONS to the minimum justified set."),
    Rule("PCI-8.2.4", "PCI", "AUTHENTICATION", "Req 8.2.4",
         "User passwords are changed at least every 90 days",
         lambda c: (c.pw_interval <= 90, f"password change interval is {c.pw_interval} days"),
         "SETROPTS PASSWORD(INTERVAL(90))."),
    Rule("PCI-8.3.1", "PCI", "AUTHENTICATION", "Req 8.3.1",
         "Multi-factor authentication is in place for administrative access",
         lambda c: (c.mfa_active or bool(c.mfa_users),
                    "MFA " + ("ACTIVE" if (c.mfa_active or c.mfa_users) else "NOT CONFIGURED")),
         "Enable RACF MFA (ICTX/AZFTOTP1) for SPECIAL users."),
    Rule("PCI-10.2", "PCI", "LOGGING", "Req 10.2",
         "An audit trail records access to security-relevant events",
         lambda c: (c.smf80, "SMF type 80 recording " + ("ACTIVE" if c.smf80 else "NOT ACTIVE")),
         "Ensure SMF 80 and SAUDIT/CMDVIOL are active."),
    Rule("PCI-10.5.2", "PCI", "LOGGING", "Req 10.5.2",
         "Audit trails are protected from unauthorized modification",
         lambda c: (not any("SYS1.MAN" in d for d in c.writable_sens),
                    "SMF data sets protected"),
         "Profile SYS1.MAN* with UACC(NONE)."),
]


def run(state: Any, standard: str = "") -> str:
    ctx = Ctx(state)
    std = standard.strip().upper()
    rules = [r for r in RULES if not std or r.standard == std or std in ("ALL", "COMPLY")]
    if not rules:
        rules = RULES
    results = []
    for r in rules:
        try:
            passed, evidence = r.check(ctx)
        except Exception as exc:
            passed, evidence = False, f"rule error: {exc}"
        results.append((r, passed, evidence))

    npass = sum(1 for _, p, _ in results if p)
    total = len(results)
    pct = int(round(100 * npass / total)) if total else 100
    name = {"STIG": "DISA STIG for z/OS RACF", "PCI": "PCI-DSS v4.0"}.get(std, "STIG + PCI-DSS")

    L = [f"CKACUST   IBM Security zSecure Compliance   {name}",
         "=" * 72,
         f"{'DOMAIN':<16} {'CONTROL':<10} {'SEV':<7} {'STATUS':<7} RULE",
         "-" * 72]
    for r, passed, _ in results:
        L.append(f"{r.domain:<16} {r.id:<10} {r.severity:<7} "
                 f"{'PASS' if passed else 'FAIL':<7} {r.title[:34]}")
    L += ["-" * 72,
          f"COMPLIANCE SCORE: {pct}%   ({npass} of {total} rules passed)"]

    fails = [(r, e) for r, p, e in results if not p]
    if fails:
        L += ["", "OPEN FINDINGS (remediation required):"]
        for r, e in fails:
            L.append(f"  {r.id} [{r.severity}] {r.title}")
            L.append(f"      evidence : {e}")
            L.append(f"      remediate: {r.fix}")
    else:
        L += ["", "NO OPEN FINDINGS - system is compliant with the selected standard."]
    return "\n".join(L)
