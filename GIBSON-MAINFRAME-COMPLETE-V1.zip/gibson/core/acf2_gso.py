"""ACF2 GSO (Global System Options) records.

GSO records are the site-wide ACF2 controls - password rules, system mode, rule
options, TSO defaults, UNIX/OMVS defaults, and so on. In real ACF2 they are edited in
``SET CONTROL(GSO)`` mode with INSERT / CHANGE / LIST, and the running system reads its
behaviour from them. GIBSON previously printed static SHOW text; this module makes the
records real and editable, and the SHOW commands read back from here.

Pure and dependency-free. Training content only.
"""
from __future__ import annotations

import re
from typing import Dict, List, Tuple

# The GSO records GIBSON models, with authentic field names and default values.
GSO_DEFAULTS: Dict[str, Dict[str, str]] = {
    "OPTS": {
        "MODE": "ABORT", "MAXVIO": "10", "DATE": "MDY", "DFTLID": "-DFTLID",
        "DFTSTC": "STCUSER", "NOTIFY": "YES", "TEMPDS": "YES", "INFOLIST": "SECURITY",
        "STAMPSMF": "YES", "UIDMAX": "24",
    },
    "PSWD": {
        "MINPSWDLN": "8", "MAXTRY": "3", "PASSLMT": "3", "WRNDAYS": "5",
        "MAXDAYS": "90", "MINDAYS": "1", "PSWDHST": "12", "PSWDALPH": "YES",
        "PSWDNUM": "YES", "MIXCASE": "YES", "PSWDPHR": "YES", "PSWDREQ": "YES",
    },
    "RULEOPTS": {
        "RULEVLD": "YES", "CENTRAL": "NO", "DECOMP": "SECURITY", "NOSAVE": "NO",
        "RULELONG": "NO", "CHANGE": "SECURITY",
    },
    "TSO": {
        "LOGONCK": "YES", "BYPASS": "#", "TSOPROC": "IKJACCNT", "CMDSMF": "YES",
        "QLOGON": "YES", "SUBCLASS": "A", "SUBHOLD": "NONE", "SUBMSG": "NONE",
    },
    "UNIXOPTS": {
        "AUTOUID": "YES", "AUTOGID": "YES", "DFTGROUP": "OMVSGRP", "DFTUSER": "OMVSDFLT",
        "SUPGROUP": "SYS1", "HFSSEC": "YES", "UIDRANGE": "1-2147483647",
    },
    "SAFDEF": {
        "ID": "SAFDEF01", "MODE": "GLOBAL", "RACROUTE": "REQUEST=AUTH", "RETCODE": "4",
    },
    "APPLDEF": {
        "ID": "APPLDEF01", "MODE": "ACTIVE", "APPL": "-", "MASK": "-",
    },
}

# order the fields are shown in per record (falls back to sorted for unknown)
_FIELD_ORDER = {rec: list(fields.keys()) for rec, fields in GSO_DEFAULTS.items()}


def default_gso() -> Dict[str, Dict[str, str]]:
    """A fresh set of GSO records at their default values."""
    return {rec: dict(fields) for rec, fields in GSO_DEFAULTS.items()}


def known_record(record_id: str) -> bool:
    return record_id.upper() in GSO_DEFAULTS


def apply_fields(record: Dict[str, str], cmd: str) -> List[str]:
    """Apply FIELD(value) settings from a command to a GSO record. Also supports the
    ACF2 boolean forms ``FIELD`` (-> YES) and ``NOFIELD`` / ``NO-FIELD`` (-> NO).
    Returns the list of changed field names."""
    changed: List[str] = []
    # valued: FIELD(value)
    for m in re.finditer(r"([A-Z][A-Z0-9\-]*)\(([^)]*)\)", cmd, re.I):
        field = m.group(1).upper()
        if field in record or field in ("ID",):
            record[field] = m.group(2).strip().strip("'\"")
            changed.append(field)
    # booleans: NOFIELD / NO-FIELD -> NO ; bare FIELD (already a known YES/NO field) -> YES
    up = " " + cmd.upper() + " "
    for field, val in list(record.items()):
        if val not in ("YES", "NO"):
            continue
        if re.search(r"\s(?:NO-?" + re.escape(field) + r")\s", up):
            record[field] = "NO"; changed.append(field)
        elif re.search(r"\s" + re.escape(field) + r"\s", up):
            record[field] = "YES"; changed.append(field)
    return changed


def format_gso(record_id: str, record: Dict[str, str]) -> str:
    """Authentic ACF LIST display of one GSO record."""
    rid = record_id.upper()
    order = _FIELD_ORDER.get(rid, sorted(record.keys()))
    fields = [f for f in order if f in record] + [f for f in record if f not in order]
    out = [f"{rid} GSO RECORD"]
    # wrap fields across lines, a few per line, like real SHOW output
    line = "  "
    for f in fields:
        piece = f"{f}({record[f]}) "
        if len(line) + len(piece) > 74:
            out.append(line.rstrip()); line = "  "
        line += piece
    if line.strip():
        out.append(line.rstrip())
    return "\n".join(out)
