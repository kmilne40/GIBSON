"""ACF2 ACFFDR (field-definition record) and ACFRPTxx SMF reports.

Two Phase-5 pieces:

* **ACFFDR** - the field-definition record that defines the logonid fields ACF2 knows
  about. ``SHOW FIELDS`` renders it from the logonid field model.
* **ACFRPTxx** - the ACF2 SMF report generators. Real sites run these as batch jobs
  (ACFRPTPW password/logon activity, ACFRPTRV resource/access violations, ACFRPTDS
  data set access, ACFRPTLL logonid list). GIBSON generates authentic-looking reports
  over its audit trail.

Pure and dependency-free. Training content only; not real IBM SMF records.
"""
from __future__ import annotations

from typing import Any, Dict, List

from gibson.core import acf2_lid as _lid


# --------------------------------------------------------------------------- #
#  ACFFDR - field definition record
# --------------------------------------------------------------------------- #
def acffdr_fields() -> str:
    """Render the ACFFDR: each logonid field with its type and attributes."""
    out = ["ACFFDR FIELD DEFINITION RECORD (@CFDE)",
           "  FIELD          TYPE    LN  FLAGS"]

    def row(name: str, ftype: str, ln: str, flags: str) -> str:
        return f"  {name:<13}  {ftype:<6}  {ln:<2}  {flags}"

    for f in _lid.LID_PRIVILEGES:
        out.append(row(f, "BIT", "1", "RESTRICT LIST"))
    for f in _lid.LID_FACILITIES:
        out.append(row(f, "BIT", "1", "LIST"))
    for f in _lid.LID_STATUS:
        out.append(row(f, "BIT", "1", "RESTRICT LIST"))
    for f in _lid.LID_IDENT:
        out.append(row(f, "CHAR", "8", "LIST"))
    for f in _lid.LID_TSO:
        out.append(row(f, "CHAR", "8", "LIST NULL"))
    for f in _lid.LID_OMVS:
        out.append(row(f, "CHAR", "8", "LIST NULL"))
    for f in _lid.LID_STATS:
        out.append(row(f, "STAT", "4", "LIST NONULL"))
    out.append(f"  {len(_lid.LID_BOOLEANS) + len(_lid.LID_VALUED) + len(_lid.LID_STATS)} FIELDS DEFINED")
    return "\n".join(out)


# --------------------------------------------------------------------------- #
#  ACFRPTxx reports over the audit trail
# --------------------------------------------------------------------------- #
_VIOLATION_WORDS = ("VIOLATION", "REJECT", "FAIL", "DENY", "PREVENT", "WARNING", "LOGGED")


def _events(state: Any) -> List[Any]:
    audit = getattr(state, "audit", None)
    return list(getattr(audit, "events", []) or []) if audit is not None else []


def _row(ev: Any) -> Dict[str, str]:
    extra = {str(k).upper(): str(v) for k, v in (getattr(ev, "extra", {}) or {}).items()}
    return {
        "USERID": extra.get("USERID", getattr(ev, "userid", "")),
        "DATE": extra.get("DATE", ev.ts.strftime("%y.%j") if getattr(ev, "ts", None) else ""),
        "TIME": extra.get("TIME", ev.ts.strftime("%H:%M:%S") if getattr(ev, "ts", None) else ""),
        "EVENT": extra.get("EVENT", (getattr(ev, "command", "") or "")[:24]),
        "RESULT": extra.get("RESULT", (getattr(ev, "result", "") or "").split()[0] if getattr(ev, "result", "") else ""),
        "RESOURCE": extra.get("RESOURCE", extra.get("PROFILE", "")),
        "SERVICE": extra.get("SERVICE", ""),
        "SOURCE": extra.get("TERMINAL", extra.get("ADDR", "")),
        "SYSTEM": extra.get("SYSTEM", "GIBSON"),
    }


def _is_violation(r: Dict[str, str]) -> bool:
    blob = (r["RESULT"] + " " + r["EVENT"]).upper()
    return any(w in blob for w in _VIOLATION_WORDS)


def _header(title: str, subtitle: str) -> List[str]:
    return [f"ACF2  {title}",
            f"      {subtitle}",
            "-" * 78]


def report_pw(state: Any) -> str:
    """ACFRPTPW - password / logon activity and violations."""
    rows = [_row(e) for e in _events(state)]
    logon = [r for r in rows if "LOGON" in (r["EVENT"] + r["RESULT"]).upper()
             or "LOGIN" in r["EVENT"].upper() or "PASSWORD" in r["EVENT"].upper()]
    out = _header("ACFRPTPW - INVALID PASSWORD/AUTHORITY LOG",
                  "LOGONID   DATE      TIME      RESULT      SOURCE           EVENT")
    if not logon:
        out.append("  NO LOGON/PASSWORD ACTIVITY RECORDED IN THIS SESSION")
    for r in logon:
        out.append(f"  {r['USERID']:<8}  {r['DATE']:<8}  {r['TIME']:<8}  "
                   f"{r['RESULT']:<10}  {r['SOURCE']:<15}  {r['EVENT']}")
    viol = sum(1 for r in logon if _is_violation(r))
    out.append("-" * 78)
    out.append(f"  {len(logon)} LOGON EVENT(S), {viol} VIOLATION(S)")
    return "\n".join(out)


def report_rv(state: Any) -> str:
    """ACFRPTRV - resource / access-rule violations."""
    rows = [_row(e) for e in _events(state)]
    viol = [r for r in rows if _is_violation(r)]
    out = _header("ACFRPTRV - RESOURCE EVENT LOG (VIOLATIONS)",
                  "LOGONID   DATE      TIME      SERVICE   RESULT      RESOURCE")
    if not viol:
        out.append("  NO RESOURCE VIOLATIONS RECORDED IN THIS SESSION")
    for r in viol:
        out.append(f"  {r['USERID']:<8}  {r['DATE']:<8}  {r['TIME']:<8}  "
                   f"{r['SERVICE']:<8}  {r['RESULT']:<10}  {r['RESOURCE']}")
    out.append("-" * 78)
    out.append(f"  {len(viol)} VIOLATION(S) LOGGED")
    return "\n".join(out)


def report_ds(state: Any) -> str:
    """ACFRPTDS - data set access events."""
    rows = [_row(e) for e in _events(state)]
    ds = [r for r in rows if "." in r["RESOURCE"] or "DATASET" in r["EVENT"].upper()
          or "DSN" in r["EVENT"].upper()]
    out = _header("ACFRPTDS - DATA SET ACCESS LOG",
                  "LOGONID   DATE      TIME      SERVICE   RESULT      DATA SET")
    if not ds:
        out.append("  NO DATA SET ACCESS EVENTS RECORDED IN THIS SESSION")
    for r in ds:
        out.append(f"  {r['USERID']:<8}  {r['DATE']:<8}  {r['TIME']:<8}  "
                   f"{r['SERVICE']:<8}  {r['RESULT']:<10}  {r['RESOURCE']}")
    out.append("-" * 78)
    out.append(f"  {len(ds)} DATA SET EVENT(S)")
    return "\n".join(out)


def report_ll(userids: List[str], meta: Any) -> str:
    """ACFRPTLL - logonid list with key privileges."""
    out = _header("ACFRPTLL - LOGONID LISTING",
                  "LOGONID   GROUP     UID STRING            PRIVILEGES")
    users = getattr(meta, "users", {}) or {}
    for uid in sorted(userids):
        rec = users.get(uid.upper(), {})
        lidrec = rec.get("lid") or {}
        vals = lidrec.get("values", {}) if isinstance(lidrec, dict) else {}
        flags = lidrec.get("flags", []) if isinstance(lidrec, dict) else []
        group = vals.get("GROUP", "SYS1")
        uidstr = (group + uid).upper()
        privs = " ".join(p for p in _lid.LID_PRIVILEGES if p in set(flags))
        out.append(f"  {uid:<8}  {group:<8}  {uidstr:<20}  {privs}")
    out.append("-" * 78)
    out.append(f"  {len(userids)} LOGONID(S) LISTED")
    return "\n".join(out)
