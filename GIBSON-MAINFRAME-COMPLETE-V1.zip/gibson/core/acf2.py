from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import fnmatch
import hashlib
import json
import re
from typing import Optional

from gibson.core.racf import RacfRepository
from gibson.core.racf_dynamic import DynamicRacfStore, RacfGroup
from gibson.core import acf2_lid as _lid
from gibson.core import acf2_rules as _rules
from gibson.core import acf2_help as _help
from gibson.core import acf2_gso as _gso
from gibson.core import acf2_reports as _rpt


_ACCESS_TO_SERVICE = {
    "NONE": "",
    "READ": "READ",
    "UPDATE": "READ,UPDATE",
    "CONTROL": "READ,UPDATE,DELETE",
    "ALTER": "READ,UPDATE,DELETE",
    "EXECUTE": "EXECUTE",
}

_SERVICE_TO_ACCESS = {
    "": "NONE",
    "READ": "READ",
    "UPDATE": "UPDATE",
    "READ,UPDATE": "UPDATE",
    "READ,UPDATE,DELETE": "ALTER",
    "ADD": "UPDATE",
    "DELETE": "CONTROL",
    "EXEC": "EXECUTE",
    "EXECUTE": "EXECUTE",
}

# ACF2 CLASMAP: maps a 3-character resource type to a RACF class (and entity length).
# Real ACF2 sites define these as GSO CLASMAP records; SHOW CLASMAP lists them.
_CLASMAP = [
    # type, RACF class, entityln, description
    ("FAC", "FACILITY", 0, "General facility resources"),
    ("SUR", "SURROGAT", 0, "Surrogate (submit/act-as) authority"),
    ("OPR", "OPERCMDS", 0, "Operator commands"),
    ("APL", "APPL", 0, "Application access"),
    ("VAR", "RACFVARS", 0, "RACF variables"),
    ("TAC", "TSOAUTH", 0, "TSO authorities (ACCT, OPER, ...)"),
    ("PRG", "PROGRAM", 0, "Controlled programs"),
    ("TER", "TERMINAL", 8, "Terminals"),
    ("CKC", "CCICSCMD", 0, "CICS commands"),
    ("TCS", "TCICSTRN", 4, "CICS transactions"),
    ("DB2", "DSNADM", 0, "Db2 administrative authorities"),
    ("JES", "JESSPOOL", 0, "JES spool data sets"),
    ("SVR", "SERVER", 0, "Server (z/OS Connect, etc.)"),
    ("XFA", "XFACILIT", 0, "Extended facility resources"),
]
_RESOURCE_TYPE_TO_CLASS = {t: c for (t, c, _e, _d) in _CLASMAP}
_CLASS_TO_RESOURCE_TYPE = {c: t for (t, c, _e, _d) in _CLASMAP}


@dataclass
class Acf2Context:
    setting: str = "LID"
    division: str = ""
    profile_type: str = ""
    resource_type: str = ""


@dataclass
class Acf2MetaStore:
    path: Path
    users: dict[str, dict[str, object]] = field(default_factory=dict)
    groups: dict[str, dict[str, object]] = field(default_factory=dict)
    rules: dict[str, dict] = field(default_factory=dict)   # $KEY -> ruleset dict
    gso: dict[str, dict] = field(default_factory=dict)      # GSO record id -> fields
    xref: dict[str, dict] = field(default_factory=dict)     # scope kind -> {scopeid: [masks]}

    @classmethod
    def load(cls, path: Path) -> "Acf2MetaStore":
        p = Path(path)
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                return cls(p,
                           {k.upper(): v for k, v in (data.get("users") or {}).items()},
                           {k.upper(): v for k, v in (data.get("groups") or {}).items()},
                           {k.upper(): v for k, v in (data.get("rules") or {}).items()},
                           {k.upper(): v for k, v in (data.get("gso") or {}).items()},
                           {k.upper(): v for k, v in (data.get("xref") or {}).items()})
            except Exception:
                pass
        return cls(p)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(
            {"users": self.users, "groups": self.groups, "rules": self.rules,
             "gso": self.gso, "xref": self.xref},
            indent=2, sort_keys=True), encoding="utf-8")

    def _stable_num(self, seed: str, base: int = 10000, mod: int = 50000) -> int:
        digest = hashlib.sha1(seed.upper().encode("utf-8")).hexdigest()[:8]
        return base + (int(digest, 16) % mod)

    def uid_for(self, userid: str, users_repo: RacfRepository) -> int:
        uid = self.users.get(userid.upper(), {}).get("uid")
        if isinstance(uid, int):
            return uid
        user = users_repo.get(userid)
        if user and user.special and user.has_omvs:
            return 0
        return self._stable_num(userid, base=1000, mod=60000)

    def gid_for(self, group: str) -> int:
        gid = self.groups.get(group.upper(), {}).get("gid")
        if isinstance(gid, int):
            return gid
        if group.upper() == "SYS1":
            return 0
        return self._stable_num(group, base=2000, mod=60000)

    def ensure_user(self, userid: str, *, uid: int | None = None, home: str | None = None, program: str | None = None, no_omvs: bool | None = None, group: str | None = None) -> None:
        rec = dict(self.users.get(userid.upper(), {}))
        if uid is not None:
            rec["uid"] = int(uid)
        if home is not None:
            rec["home"] = home
        if program is not None:
            rec["program"] = program
        if no_omvs is not None:
            rec["no_omvs"] = bool(no_omvs)
        if group is not None:
            rec["group"] = group.upper()
        self.users[userid.upper()] = rec
        self.save()

    def ensure_group(self, group: str, *, gid: int | None = None) -> None:
        rec = dict(self.groups.get(group.upper(), {}))
        if gid is not None:
            rec["gid"] = int(gid)
        self.groups[group.upper()] = rec
        self.save()

    def user_home(self, userid: str) -> str:
        return str(self.users.get(userid.upper(), {}).get("home") or f"/u/{userid.lower()}")

    def user_program(self, userid: str) -> str:
        return str(self.users.get(userid.upper(), {}).get("program") or "/bin/sh")

    def user_group(self, userid: str, users_repo: RacfRepository) -> str:
        group = self.users.get(userid.upper(), {}).get("group")
        if group:
            return str(group).upper()
        user = users_repo.get(userid)
        return (user.default_group if user and user.default_group else "SYS1").upper()

    def user_no_omvs(self, userid: str, users_repo: RacfRepository) -> bool:
        if userid.upper() in self.users and "no_omvs" in self.users[userid.upper()]:
            return bool(self.users[userid.upper()]["no_omvs"])
        user = users_repo.get(userid)
        return not bool(user and user.has_omvs)


class Acf2Bridge:
    def __init__(self, state, requester: str):
        self.state = state
        self.requester = requester.upper()
        self.context = Acf2Context()
        self.meta = Acf2MetaStore.load(Path(state.config.sim_root) / "acf2_meta.json")

    def activate(self) -> str:
        self.context = Acf2Context()
        return (
            "ACF2 MODE ACTIVE\n"
            "CURRENT SETTING: LID\n"
            "USE SET LID, SET RULE, SET RESOURCE(type), SET CONTROL(GSO), OR SET PROFILE(GROUP) DIV(OMVS)."
        )

    def banner_racf(self) -> str:
        return "RACF MODE ACTIVE"

    def help_text(self) -> str:
        return _help.acf2_help("")

    def command(self, raw: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> Optional[str]:
        cmd = (raw or "").strip()
        if not cmd:
            return None
        upper = cmd.upper()
        first = upper.split()[0]
        if first not in {"SET", "SHOW", "LIST", "INSERT", "CHANGE", "DELETE", "ACCESS", "TEST", "RECKEY", "COMPILE", "DECOMP", "DECOMPILE", "ACFRPTPW", "ACFRPTRV", "ACFRPTDS", "ACFRPTLL", "ACFRPT", "END", "QUIT", "HELP", "?", "F1", "PF1", "PF01", "ROLES"}:
            return None
        if upper in {"HELP", "?", "F1", "PF1", "PF01"}:
            return self.help_text()
        # F1/PF1 with a command already typed -> help for that command (ISPF-style)
        if upper.startswith(("F1 ", "PF1 ", "PF01 ")):
            head = cmd.split(None, 1)[1] if len(cmd.split(None, 1)) > 1 else ""
            detail = _help.acf2_help(head.strip())
            return detail if detail is not None else self.help_text()
        # per-command help:  HELP cmd [SYNTAX|OPERANDS|FUNCTION] | cmd HELP | cmd ?
        if upper.startswith("HELP "):
            detail = _help.acf2_help(cmd[5:].strip())
            return detail if detail is not None else self.help_text()
        if upper.endswith(" HELP") or upper.endswith(" ?"):
            head = cmd[:-5] if upper.endswith(" HELP") else cmd[:-2]
            detail = _help.acf2_help(head.strip())
            if detail is not None:
                return detail
        if first in {"END", "QUIT"}:
            self.context = Acf2Context()
            return "ACF2 COMMAND SETTING RESET TO LID"
        if first == "SET":
            return self._set(cmd)
        if first == "SHOW":
            return self._show(cmd, users_repo)
        if first == "LIST":
            return self._list(cmd, users_repo, dynamic_racf)
        if first == "INSERT":
            return self._insert(cmd, users_repo, dynamic_racf)
        if first == "CHANGE":
            return self._change(cmd, users_repo, dynamic_racf)
        if first == "DELETE":
            return self._delete(cmd, users_repo, dynamic_racf)
        if first == "ACCESS":
            return self._access(cmd, users_repo, dynamic_racf)
        if first == "TEST":
            return self._test(cmd, users_repo, dynamic_racf)
        if first == "RECKEY":
            return self._reckey(cmd, users_repo, dynamic_racf)
        if first == "COMPILE":
            return self._compile(cmd, users_repo)
        if first in {"DECOMP", "DECOMPILE"}:
            return self._decomp(cmd)
        if first.startswith("ACFRPT"):
            return self._report(first, users_repo)
        if first == "ROLES":
            return self._roles(cmd, dynamic_racf)
        return None

    def _is_security_admin(self, users_repo: RacfRepository) -> bool:
        user = users_repo.get(self.requester)
        return bool(user and user.special)

    def _deny_field(self, field: str = "COMMAND") -> str:
        return f"ACF00103 NOT AUTHORIZED TO CHANGE FIELD {field.upper()}"

    def _deny_function(self) -> str:
        return "ACF04017 NOT AUTHORIZED FOR REQUESTED FUNCTION"

    def _set(self, cmd: str) -> str:
        upper = cmd.upper()
        if re.fullmatch(r"SET\s+(ACF|LID)", upper):
            self.context = Acf2Context(setting="LID")
            return "LID SETTING ACTIVE"
        m = re.fullmatch(r"SET\s+(?:CONTROL|C)\(([^)]+)\)", upper)
        if m:
            self.context = Acf2Context(setting="CONTROL", profile_type=m.group(1).upper())
            return f"CONTROL({self.context.profile_type}) SETTING ACTIVE"
        m = re.fullmatch(r"SET\s+(?:PROFILE|P)\(([^)]+)\)(?:\s+DIV\(([^)]+)\))?", upper)
        if m:
            self.context = Acf2Context(setting="PROFILE", profile_type=m.group(1).upper(), division=(m.group(2) or "").upper())
            div = f" DIV({self.context.division})" if self.context.division else ""
            return f"PROFILE({self.context.profile_type}){div} SETTING ACTIVE"
        m = re.fullmatch(r"SET\s+(?:RESOURCE|R)\(([^)]+)\)", upper)
        if m:
            self.context = Acf2Context(setting="RESOURCE", resource_type=m.group(1).upper())
            return f"RESOURCE({self.context.resource_type}) SETTING ACTIVE"
        if upper == "SET RULE":
            self.context = Acf2Context(setting="RULE")
            return "RULE SETTING ACTIVE"
        m = re.fullmatch(r"SET\s+XREF\(([^)]+)\)", upper)
        if m:
            kind = m.group(1).upper()
            if kind not in {"LID", "RES", "ROL"}:
                return "SET XREF(LID) | XREF(RES) | XREF(ROL)"
            self.context = Acf2Context(setting="XREF", profile_type=kind)
            return f"XREF({kind}) SETTING ACTIVE"
        return "INVALID SET SUBCOMMAND"

    def _show(self, cmd: str, users_repo: RacfRepository) -> str:
        upper = cmd.upper().strip()
        if not self._is_security_admin(users_repo) and upper not in {"SHOW MODE", "SHOW OMVS"} and not upper.startswith("SHOW OMVS"):
            return self._deny_function()
        if upper in {"SHOW MODE", "SHOW MOD"}:
            parts = [self.context.setting]
            if self.context.profile_type:
                parts.append(self.context.profile_type)
            if self.context.division:
                parts.append(self.context.division)
            if self.context.resource_type:
                parts.append(self.context.resource_type)
            return "ACF2 CURRENT SETTING: " + " ".join(parts)
        if upper in {"SHOW ACF2", "SHOW ALL"}:
            return "\n".join([
                "-- ACF2 SYSTEM PARAMETERS ACTIVE --",
                f"LOGONIDS={len(users_repo.users):04d}  GROUPS={len(self.state.dynamic_racf.groups):04d}",
                f"RULE SETS={sum(len(v) for v in self.state.dynamic_racf.profiles.values()):04d}",
                f"DEFAULT MODE={self._acf2_mode()}  UID STRING PROCESSING=ACTIVE",
                "COMMAND PROPAGATION=SIMULATED  INFOSTG=ACTIVE",
                "SHOW TSO, SHOW PSWD, SHOW DDSN AVAILABLE",
            ])
        if upper == "SHOW TSO":
            store = self._gso_store()
            return "-- TSO RELATED DEFAULTS ACTIVE --\n" + _gso.format_gso("TSO", store["TSO"])
        if upper in {"SHOW PSWD", "SHOW PSWDOPTS"}:
            store = self._gso_store()
            return "PASSWORD (PSWD) OPTIONS IN EFFECT:\n" + _gso.format_gso("PSWD", store["PSWD"])
        if upper in {"SHOW OPTS", "SHOW RULEOPTS", "SHOW UNIXOPTS", "SHOW SAFDEF", "SHOW APPLDEF"}:
            rid = upper.split()[1]
            store = self._gso_store()
            if rid in store:
                return _gso.format_gso(rid, store[rid])
            return f"GSO RECORD {rid} NOT FOUND"
        if upper == "SHOW DDSN":
            return "\n".join([
                "ACF2 DATABASE DATA SET NAMES IN EFFECT",
                f" LOGONID DB  : {self.state.config.gacf_path}",
                f" RULE DB     : {Path(self.state.config.sim_root) / 'racf_dynamic.json'}",
                f" INFOSTG DB  : {Path(self.state.config.sim_root) / 'acf2_meta.json'}",
            ])
        if upper.startswith("SHOW OMVS"):
            return self._show_omvs(cmd, users_repo)
        if upper in {"SHOW CLASMAP", "SHOW CLASMA"}:
            lines = ["CLASMAP RECORDS IN EFFECT",
                     "  TYPE  CLASS       ENTITYLN  RESOURCE"]
            for t, c, e, d in _CLASMAP:
                lines.append(f"  {t:<4}  {c:<10}  {e:<8}  {d}")
            return "\n".join(lines)
        if upper in {"SHOW STATE", "SHOW STA"}:
            return "\n".join([
                "-- ACF2 STATE --",
                f"ACF2 MODE={self._acf2_mode()}   SYSTEM=GIBSON   SUBSYS=ACF2",
                f"LOGONIDS={len(users_repo.users):04d}  RULE SETS={len(self.meta.rules):04d}  "
                f"CLASMAP ENTRIES={len(_CLASMAP):04d}",
                "UID STRING PROCESSING=ACTIVE   INFOSTG=ACTIVE   STORAGE=RESIDENT",
            ])
        if upper in {"SHOW FIELDS", "SHOW FIELD", "SHOW ACFFDR"}:
            return _rpt.acffdr_fields()
        if upper in {"SHOW SYSTEMS", "SHOW SYSID"}:
            return "\n".join(["ACF2 SYSTEMS IN EFFECT", "  SYSID  SYSTEM   ACF2 MODE",
                              "  GIBS   GIBSON   ABORT"])
        if upper in {"SHOW ACTIVE", "SHOW ACT"}:
            return "\n".join(["ACF2 ACTIVE OPTIONS",
                              "  ACF2=ACTIVE  UID STRING=ACTIVE  RULES=ACTIVE  INFOSTG=ACTIVE",
                              "  SMF RECORDING=ACTIVE  RESIDENT RULES=ACTIVE"])
        if upper in {"SHOW ZEROFLDS", "SHOW ZERO"}:
            return "\n".join(["FIELDS SET TO ZERO/NULL BY DEFAULT ON INSERT",
                              "  ACC-CNT  ACC-DATE  PSWD-VIO  TSOACCT  SHIFT  SOURCE"])
        if upper in {"SHOW PROGRAMS", "SHOW PPGM", "SHOW PGM"}:
            return "\n".join(["PROTECTED/PRIVILEGED PROGRAMS (PPGM) IN EFFECT",
                              "  IKJEFT01  IEFBR14  IRRUT200  IRRDBU00  ACFBATCH"])
        if upper in {"SHOW LINKLST", "SHOW LNK"}:
            return "\n".join(["LINKLST LIBRARIES PROTECTED",
                              "  SYS1.LINKLIB  SYS1.LPALIB  SYS1.MIGLIB  CEE.SCEERUN"])
        if upper == "SHOW MAINT":
            return "\n".join(["MAINTENANCE LOGONIDS/PROGRAMS (MAINT)",
                              "  LID       PGM       LIBRARY", "  MAINT01   ADRDSSU   SYS1.MIGLIB"])
        if upper in {"SHOW RESIDENT", "SHOW RESRULE"}:
            resident = sorted(self.meta.rules.keys())[:10]
            return "RESIDENT RULE SETS IN STORAGE\n  " + ("  ".join(resident) if resident else "NONE")
        if upper in {"SHOW SECVOLS", "SHOW RESVOLS"}:
            return f"{upper.split()[1]} IN EFFECT\n  (NONE DEFINED)"
        if upper == "SHOW EXITS":
            return "ACF2 EXITS IN EFFECT\n  (NO SITE EXITS ACTIVE)"
        if upper in {"SHOW XREF", "SHOW SCOPE"}:
            if not self.meta.xref:
                return "NO XREF SCOPE LISTS DEFINED"
            out = ["XREF SCOPE LISTS IN EFFECT"]
            for kind in ("LID", "RES", "ROL"):
                for sid, masks in sorted(self.meta.xref.get(kind, {}).items()):
                    out.append(f"  {sid:<10} XREF({kind})  " + "  ".join(masks))
            return "\n".join(out)
        return ("SHOW SUBCOMMAND NOT IMPLEMENTED (TRY ACF2, MODE, STATE, TSO, PSWD, DDSN, "
                "CLASMAP, FIELDS, SYSTEMS, ACTIVE, PROGRAMS, LINKLST, RESIDENT, OMVS)")

    def _show_omvs(self, cmd: str, users_repo: RacfRepository) -> str:
        upper = cmd.upper()
        m = re.search(r"USER\(([^)]+)\)", upper)
        if m:
            userid = m.group(1).upper()
            if not users_repo.exists(userid):
                return f"LOGONID {userid} NOT FOUND"
            return self._format_lid(users_repo.get(userid), users_repo, short=False, omvs_only=True)
        m = re.search(r"GROUP\(([^)]+)\)", upper)
        if m:
            gid = m.group(1)
            try:
                gid_num = int(gid)
            except ValueError:
                gid_num = -1
            rows = [g for g in sorted(self.state.dynamic_racf.groups) if self.meta.gid_for(g) == gid_num]
            return "\n".join(rows) if rows else f"NO GROUP FOR GID {gid}"
        rows = []
        for user in sorted(users_repo.users):
            if self.meta.user_no_omvs(user, users_repo):
                continue
            rows.append(f"{user:<8} UID({self.meta.uid_for(user, users_repo)}) GROUP({self.meta.user_group(user, users_repo)}) HOME({self.meta.user_home(user)})")
        return "\n".join(rows) if rows else "NO OMVS USERS FOUND"

    def _list(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        arg = cmd[4:].strip()
        if self.context.setting == "CONTROL":
            return self._control_list(arg)
        if self.context.setting == "LID":
            return self._list_lid(arg, users_repo, dynamic_racf)
        if self.context.setting == "PROFILE" and self.context.profile_type == "GROUP":
            return self._list_group(arg, users_repo, dynamic_racf)
        if self.context.setting == "RULE":
            return self._list_rules(arg, dynamic_racf, dataset_mode=True)
        if self.context.setting == "RESOURCE":
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(self.context.resource_type, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {self.context.resource_type}"
            return self._list_rules(arg, dynamic_racf, dataset_mode=False, racf_class=racf_class)
        if self.context.setting == "XREF":
            return self._xref_list(arg)
        return "LIST NOT VALID UNDER CURRENT SETTING"

    def _list_lid(self, arg: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        upper = arg.upper()
        section_m = re.search(r"SECTION\(([^)]+)\)", upper)
        section = section_m.group(1).upper() if section_m else ""
        if upper.startswith("UID("):
            uid_val = upper[4:-1] if upper.endswith(")") else upper[4:upper.find(")")]
            rows = []
            for user in sorted(users_repo.users):
                user_uid = str(self.meta.uid_for(user, users_repo))
                if uid_val == "0" and user_uid == "0":
                    rows.append(user)
                elif fnmatch.fnmatch(user_uid, uid_val.replace("-", "*")):
                    rows.append(user)
            return "\n".join(rows) if rows else "NO LOGONIDS MATCH CRITERIA"
        if upper.startswith("LIKE("):
            mask = arg[arg.find("(") + 1: arg.find(")")].strip().upper().replace("-", "*")
            rows = [u for u in sorted(users_repo.users) if fnmatch.fnmatch(u, mask)]
            if section == "PASSWORD":
                return "\n".join(self._format_password_section(users_repo.get(u)) for u in rows if users_repo.get(u)) or "NO LOGONIDS MATCH CRITERIA"
            return "\n".join(self._format_lid(users_repo.get(u), users_repo, short=True) for u in rows if users_repo.get(u)) or "NO LOGONIDS MATCH CRITERIA"
        if upper in {"*", ""}:
            rows = [self._format_lid(users_repo.get(u), users_repo, short=True) for u in sorted(users_repo.users)]
            return "\n".join(rows)
        target = arg.split()[0].upper()
        user = users_repo.get(target)
        if not user:
            return f"LOGONID {target} NOT FOUND"
        if section == "PASSWORD":
            return self._format_password_section(user)
        return self._format_lid(user, users_repo, short=False)

    def _list_group(self, arg: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        upper = arg.upper().strip()
        if not upper or upper == "*" or upper.startswith("LIKE("):
            if upper.startswith("LIKE("):
                mask = upper[5:upper.find(")")].replace("-", "*")
                names = [g for g in sorted(dynamic_racf.groups) if fnmatch.fnmatch(g, mask)]
            else:
                names = sorted(dynamic_racf.groups)
            return "\n\n".join(self._format_group(n, users_repo, dynamic_racf) for n in names) if names else "NO GROUP PROFILES MATCH CRITERIA"
        return self._format_group(upper.split()[0], users_repo, dynamic_racf)

    def _list_roles(self, arg: str, dynamic_racf: DynamicRacfStore) -> str:
        target = (arg or "").strip().upper()
        if not target:
            return "ROLES userid"
        groups = dynamic_racf.connected_groups(target)
        if not groups:
            return f"NO ROLES FOUND FOR {target}"
        return "\n".join(f"{target} ROLE({g})" for g in groups)

    def _insert(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if self.context.setting == "CONTROL":
            return self._control_edit(cmd, users_repo, "INSERT")
        if self.context.setting == "XREF":
            return self._xref_insert(cmd, users_repo)
        if self.context.setting == "LID":
            return self._insert_lid(cmd, users_repo, dynamic_racf)
        if self.context.setting == "PROFILE" and self.context.profile_type == "GROUP":
            return self._insert_group(cmd, dynamic_racf)
        if self.context.setting == "RULE":
            return self._insert_rule(cmd, dynamic_racf, dataset_mode=True)
        if self.context.setting == "RESOURCE":
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(self.context.resource_type, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {self.context.resource_type}"
            return self._insert_rule(cmd, dynamic_racf, dataset_mode=False, racf_class=racf_class)
        return "INSERT NOT VALID UNDER CURRENT SETTING"

    def _change(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if self.context.setting == "CONTROL":
            return self._control_edit(cmd, users_repo, "CHANGE")
        if self.context.setting == "LID":
            return self._change_lid(cmd, users_repo, dynamic_racf)
        if self.context.setting == "PROFILE" and self.context.profile_type == "GROUP":
            return self._change_group(cmd, dynamic_racf)
        if self.context.setting in {"RULE", "RESOURCE"}:
            return self._change_rule(cmd, dynamic_racf)
        return "CHANGE NOT VALID UNDER CURRENT SETTING"

    def _delete(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        arg = cmd[6:].strip()
        target = arg.split()[0].upper() if arg else ""
        if self.context.setting == "CONTROL":
            return self._control_delete(arg)
        if self.context.setting == "XREF":
            return self._xref_delete(arg)
        if self.context.setting == "LID":
            if not target:
                return "DELETE logonid"
            if target == self.requester:
                return "DELETE OF CURRENT LOGONID NOT PERMITTED"
            if not users_repo.exists(target):
                return f"LOGONID {target} NOT FOUND"
            users_repo.deleteuser(target)
            for group in dynamic_racf.groups.values():
                group.users.pop(target, None)
            dynamic_racf.save()
            self.meta.users.pop(target, None)
            self.meta.save()
            return f"LOGONID {target} DELETED"
        if self.context.setting == "PROFILE" and self.context.profile_type == "GROUP":
            if not target:
                return "DELETE group"
            dynamic_racf.groups.pop(target, None)
            dynamic_racf.save()
            self.meta.groups.pop(target, None)
            self.meta.save()
            return f"GROUP PROFILE {target} DELETED"
        if self.context.setting == "RULE":
            dsn = self._dataset_name(target)
            dynamic_racf.profiles.get("DATASET", {}).pop(dsn, None)
            dynamic_racf.save()
            return f"RULE SET {dsn} DELETED"
        if self.context.setting == "RESOURCE":
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(self.context.resource_type, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {self.context.resource_type}"
            profile = target
            dynamic_racf.profiles.get(racf_class, {}).pop(profile, None)
            dynamic_racf.save()
            return f"RESOURCE RULE {profile} TYPE({self.context.resource_type}) DELETED"
        return "DELETE NOT VALID UNDER CURRENT SETTING"

    def _access(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        upper = cmd.upper()
        m = re.search(r"DSNAME\('([^']+)'\)", cmd, re.I)
        if m:
            dsn = self._dataset_name(m.group(1))
            prof = dynamic_racf._find_profile("DATASET", dsn)
            return self._format_access_result(dsn, prof, users_repo, dynamic_racf, dataset_mode=True)
        m = re.search(r"RESOURCE\(([^)]+)\)\s+TYPE\(([^)]+)\)", upper)
        if m:
            name, typ = m.group(1).upper(), m.group(2).upper()
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(typ, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {typ}"
            prof = dynamic_racf._find_profile(racf_class, name)
            return self._format_access_result(name, prof, users_repo, dynamic_racf, dataset_mode=False, typecode=typ)
        return "ACCESS DSNAME('dataset') OR ACCESS RESOURCE(name) TYPE(type)"

    def _test(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        upper = cmd.upper()
        lid_m = re.search(r"LID\(([^)]+)\)", upper)
        svc_m = re.search(r"SERVICE\(([^)]+)\)", upper)
        ident = lid_m.group(1).upper() if lid_m else self.requester
        service = (svc_m.group(1).upper() if svc_m else "READ")
        uid = self._uid_string(ident, users_repo)
        ds_m = re.search(r"DSNAME\('([^']+)'\)", cmd, re.I)
        if ds_m:
            dsn = self._dataset_name(ds_m.group(1))
            key = dsn.split(".")[0].upper()                 # $KEY = high-level qualifier
            rs = self._get_ruleset(self._rule_key(key))
            if rs is not None:                              # authentic ACF2 rule evaluation
                raw, line = _rules.evaluate(rs, uid, service)
                eff, note = self._apply_mode(raw)
                why = (f"MATCHED UID({line.uid_mask})" if line else "DENY-BY-DEFAULT (NO RULE LINE MATCHED)")
                return (f"TEST DSNAME('{dsn}') LID({ident}) UID({uid}) SERVICE({service})\n"
                        f"  $KEY({key})  RESULT: {eff}  ({why}; {note})")
            # no ACF2 rule set for this key -> fall back to the RACF mapping
            ok = dynamic_racf.has_access("DATASET", dsn, ident, self._service_to_access(service), users_repo)
            return (f"TEST DSNAME('{dsn}') LID({ident}) UID({uid}) SERVICE({service})\n"
                    f"  $KEY({key})  RESULT: {'ALLOW' if ok else 'PREVENT'}  (NO ACF2 RULE SET; RACF-EQUIVALENT)")
        rsrc_m = re.search(r"RSRCNAME\('([^']+)'\)", cmd, re.I)
        if rsrc_m and self.context.setting == "RESOURCE":
            typ = self.context.resource_type
            name = rsrc_m.group(1).upper()
            key = name.split(".")[0]                        # $KEY = leading qualifier
            rs = self._get_ruleset(self._rule_key(key))
            if rs is not None:
                raw, line = _rules.evaluate(rs, uid, service)
                eff, note = self._apply_mode(raw)
                why = (f"MATCHED UID({line.uid_mask})" if line else "DENY-BY-DEFAULT")
                return (f"TEST TYPE({typ}) RSRCNAME('{name}') LID({ident}) UID({uid}) "
                        f"SERVICE({service})\n  $KEY({key})  RESULT: {eff}  ({why}; {note})")
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(typ, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {typ}"
            ok = dynamic_racf.has_access(racf_class, name, ident, self._service_to_access(service), users_repo)
            return (f"TEST TYPE({typ}) RSRCNAME('{name}') LID({ident}) UID({uid}) SERVICE({service})\n"
                    f"  RESULT: {'ALLOW' if ok else 'PREVENT'}  (NO ACF2 RULE SET; RACF-EQUIVALENT)")
        return "TEST DSNAME('dataset') LID(logonid) SERVICE(READ) OR SET RESOURCE(type) + TEST ... RSRCNAME('resource')"

    def _reckey(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        if self.context.setting not in {"RULE", "RESOURCE"}:
            return "RECKEY VALID ONLY IN RULE OR RESOURCE SETTINGS"
        m = re.match(r"RECKEY\s+([^\s]+)\s+ADD\((.+)\)\s*$", cmd, re.I)
        if not m:
            return "RECKEY key ADD( resource UID(id) SERVICE(READ) ALLOW )"
        key = m.group(1).strip("'\"").upper()
        body = m.group(2)
        uid_m = re.search(r"UID\(([^)]+)\)", body, re.I)
        svc_m = re.search(r"SERVICE\(([^)]+)\)", body, re.I)
        action = "ALLOW"
        if re.search(r"\bPREVENT\b", body, re.I):
            action = "PREVENT"
        elif re.search(r"\bLOG\b", body, re.I):
            action = "LOG"
        ident = uid_m.group(1).strip().upper() if uid_m else "*"
        access = self._service_to_access(svc_m.group(1) if svc_m else "READ")
        body2 = re.sub(r"UID\([^)]+\)", "", body, flags=re.I)
        body2 = re.sub(r"SERVICE\([^)]+\)", "", body2, flags=re.I)
        body2 = re.sub(r"\b(ALLOW|LOG|PREVENT)\b", "", body2, flags=re.I).strip()
        resource = body2.split()[0].strip("'\"") if body2 else ""
        if self.context.setting == "RULE":
            profile = self._compose_dataset_from_key_resource(key, resource)
            prof = dynamic_racf._find_profile("DATASET", profile) or dynamic_racf.define("DATASET", profile, self.requester, "NONE")
        else:
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(self.context.resource_type, "")
            if not racf_class:
                return f"UNKNOWN RESOURCE TYPE {self.context.resource_type}"
            profile = resource.upper() if resource else key
            prof = dynamic_racf._find_profile(racf_class, profile) or dynamic_racf.define(racf_class, profile, self.requester, "NONE")
        if ident == "*":
            prof.uacc = access if action != "PREVENT" else "NONE"
        else:
            prof.permits[ident] = access if action != "PREVENT" else "NONE"
        dynamic_racf.save()
        # store an authentic ACF2 rule line so TEST evaluates deny-by-default
        svc_name = (svc_m.group(1).upper() if svc_m else "READ")
        letter = _rules.service_to_letter(svc_name)
        perm_val = "P" if action == "PREVENT" else ("L" if action == "LOG" else "A")
        mask = ident
        if ident != "*" and users_repo.exists(ident):
            mask = self._uid_string(ident, users_repo)     # UID(userid) -> that user's UID string
        skey = self._rule_key(key)
        rs = self._get_ruleset(skey) or _rules.RuleSet(key=key.upper())
        _rules.add_rule_line(rs, mask if mask != "*" else "-", {letter: perm_val})
        self._store_ruleset(rs, skey)
        mode = "DATA SET" if self.context.setting == "RULE" else f"RESOURCE {self.context.resource_type}"
        return f"RECKEY {key} {mode} RULE LINE STORED FOR {profile} UID({ident}) {action}"

    def _roles(self, cmd: str, dynamic_racf: DynamicRacfStore) -> str:
        parts = cmd.split(maxsplit=1)
        if len(parts) < 2:
            return "ROLES userid"
        user = parts[1].strip().upper()
        groups = dynamic_racf.connected_groups(user)
        return "\n".join(f"{user} ROLE({group})" for group in groups) if groups else f"NO ROLES FOR {user}"

    def _insert_lid(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_field("LOGONID")
        parts = cmd.split()
        if len(parts) < 2:
            return "INSERT logonid PASSWORD(pw) [SECURITY] [GROUP(group)] [UID(uid)]"
        userid = parts[1].upper()
        pw_m = re.search(r"PASSWORD\(([^)]*)\)", cmd, re.I)
        password = pw_m.group(1) if pw_m else userid
        special = bool(re.search(r"(?:^|\s)SECURITY(?:\s|$)", cmd.upper()))
        no_special = bool(re.search(r"(?:^|\s)NOSECURITY(?:\s|$)", cmd.upper()))
        if no_special:
            special = False
        group_m = re.search(r"GROUP\(([^)]+)\)", cmd, re.I)
        group = group_m.group(1).upper() if group_m else "SYS1"
        uid_m = re.search(r"UID\(([^)]+)\)", cmd, re.I)
        uid = int(uid_m.group(1)) if uid_m and uid_m.group(1).isdigit() else None
        home_m = re.search(r"HOME\(([^)]+)\)", cmd, re.I)
        home = home_m.group(1).strip("'\"") if home_m else f"/u/{userid.lower()}"
        prog_m = re.search(r"(?:OMVSPGM|PROGRAM)\(([^)]+)\)", cmd, re.I)
        program = prog_m.group(1).strip("'\"") if prog_m else "/bin/sh"
        no_omvs = bool(re.search(r"NO-OMVS|NONO-OMVS|NOOMVS", cmd.upper()))
        omvs = not no_omvs and (uid is not None or home_m is not None or prog_m is not None or bool(re.search(r"\bOMVS\b", cmd.upper())))
        if group not in dynamic_racf.groups:
            dynamic_racf.groups.setdefault(group, RacfGroup(group, self.requester, 'SYS1'))
        out = users_repo.adduser(userid, password, special=special, omvs=omvs, default_group=group)
        dynamic_racf.connect_user(userid, group, "USE")
        self.meta.ensure_user(userid, uid=uid, home=home, program=program, no_omvs=not omvs, group=group)
        self.meta.ensure_group(group)
        lid = self._get_lid(userid, users_repo)          # full ACF2 Logonid record
        _lid.apply_command(lid, cmd)
        self._store_lid(userid, lid)
        return out.replace("ICH01003I USERID", "LOGONID") if out.startswith("ICH01003I") else out

    def _change_lid(self, cmd: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_field("LOGONID")
        parts = cmd.split()
        if len(parts) < 2:
            return "CHANGE logonid PASSWORD(pw) [SECURITY|NOSECURITY] [GROUP(group)] [UID(uid)]"
        userid = parts[1].upper()
        if not users_repo.exists(userid):
            return f"LOGONID {userid} NOT FOUND"
        pw_m = re.search(r"PASSWORD\(([^)]*)\)", cmd, re.I)
        password = pw_m.group(1) if pw_m else None
        text_u = " " + cmd.upper() + " "
        special = True if " SECURITY " in text_u and " NOSECURITY " not in text_u else False if " NOSECURITY " in text_u else None
        group_m = re.search(r"GROUP\(([^)]+)\)", cmd, re.I)
        group = group_m.group(1).upper() if group_m else None
        uid_m = re.search(r"UID\(([^)]+)\)", cmd, re.I)
        uid = int(uid_m.group(1)) if uid_m and uid_m.group(1).isdigit() else None
        home_m = re.search(r"HOME\(([^)]+)\)", cmd, re.I)
        home = home_m.group(1).strip("'\"") if home_m else None
        prog_m = re.search(r"(?:OMVSPGM|PROGRAM)\(([^)]+)\)", cmd, re.I)
        program = prog_m.group(1).strip("'\"") if prog_m else None
        if re.search(r"NO-OMVS|NONO-OMVS|NOOMVS", cmd.upper()):
            omvs = False
        elif uid_m or home_m or prog_m or re.search(r"\bOMVS\b", cmd.upper()):
            omvs = True
        else:
            omvs = None
        no_group_m = re.search(r"NOGROUP\(([^)]+)\)", cmd, re.I)
        no_group = no_group_m.group(1).upper() if no_group_m else None
        out = users_repo.altuser(userid, password=password, special=special, omvs=omvs, default_group=group)
        if group:
            dynamic_racf.connect_user(userid, group, "USE")
            self.meta.ensure_group(group)
        if no_group and no_group in dynamic_racf.groups:
            dynamic_racf.groups[no_group].users.pop(userid, None)
            dynamic_racf.save()
        self.meta.ensure_user(userid, uid=uid, home=home, program=program, no_omvs=(False if omvs else True) if omvs is not None else None, group=group)
        lid = self._get_lid(userid, users_repo)          # apply any ACF2 field changes
        _lid.apply_command(lid, cmd)
        self._store_lid(userid, lid)
        return out.replace("ICH01006I USERID", "LOGONID") if out.startswith("ICH01006I") else out

    def _insert_group(self, cmd: str, dynamic_racf: DynamicRacfStore) -> str:
        user = self.state.racf.get(self.requester)
        if not (user and user.special):
            return self._deny_field("GROUP")
        parts = cmd.split()
        if len(parts) < 2:
            return "INSERT group GID(n)"
        group = parts[1].upper()
        gid_m = re.search(r"(?:GID|AUTOGID)\(([^)]+)\)", cmd, re.I)
        gid = int(gid_m.group(1)) if gid_m and gid_m.group(1).isdigit() else None
        dynamic_racf.groups.setdefault(group, RacfGroup(group, self.requester, 'SYS1'))
        dynamic_racf.save()
        self.meta.ensure_group(group, gid=gid)
        return f"GROUP PROFILE {group} STORED"

    def _change_group(self, cmd: str, dynamic_racf: DynamicRacfStore) -> str:
        user = self.state.racf.get(self.requester)
        if not (user and user.special):
            return self._deny_field("GROUP")
        parts = cmd.split()
        if len(parts) < 2:
            return "CHANGE group GID(n)"
        group = parts[1].upper()
        if group not in dynamic_racf.groups:
            return f"GROUP PROFILE {group} NOT FOUND"
        gid_m = re.search(r"GID\(([^)]+)\)", cmd, re.I)
        gid = int(gid_m.group(1)) if gid_m and gid_m.group(1).isdigit() else None
        self.meta.ensure_group(group, gid=gid)
        return f"GROUP PROFILE {group} CHANGED"

    def _insert_rule(self, cmd: str, dynamic_racf: DynamicRacfStore, *, dataset_mode: bool, racf_class: str = "") -> str:
        user = self.state.racf.get(self.requester)
        if not (user and user.special):
            return self._deny_function()
        parts = cmd.split()
        if len(parts) < 2:
            return "INSERT profile-name"
        profile = parts[1].strip("'\"").upper()
        if dataset_mode:
            dsn = self._dataset_name(profile)
            dynamic_racf.define("DATASET", dsn, self.requester, "NONE")
            dynamic_racf.save()
            return f"RULE SET {dsn} STORED"
        dynamic_racf.define(racf_class, profile, self.requester, "NONE")
        dynamic_racf.save()
        return f"RESOURCE RULE {profile} TYPE({self.context.resource_type}) STORED"

    def _change_rule(self, cmd: str, dynamic_racf: DynamicRacfStore) -> str:
        user = self.state.racf.get(self.requester)
        if not (user and user.special):
            return self._deny_function()
        parts = cmd.split()
        if len(parts) < 2:
            return "CHANGE profile [ALLOW|LOG|PREVENT] ..."
        target = parts[1].strip("'\"").upper()
        warning = None
        if re.search(r"\bLOG\b", cmd.upper()):
            warning = True
        if re.search(r"\bNOLOG\b", cmd.upper()):
            warning = False
        if self.context.setting == "RULE":
            dsn = self._dataset_name(target)
            prof = dynamic_racf._find_profile("DATASET", dsn)
            if not prof:
                return f"RULE SET {dsn} NOT FOUND"
        else:
            racf_class = _RESOURCE_TYPE_TO_CLASS.get(self.context.resource_type, "")
            prof = dynamic_racf._find_profile(racf_class, target)
            if not prof:
                return f"RESOURCE RULE {target} NOT FOUND"
        uacc_m = re.search(r"UACC\(([^)]+)\)", cmd, re.I)
        if uacc_m:
            prof.uacc = uacc_m.group(1).upper()
        if warning is not None:
            prof.warning = warning
        dynamic_racf.save()
        return f"RULE {prof.name} CHANGED"

    def _get_lid(self, userid: str, users_repo: RacfRepository) -> dict:
        """Load (or lazily build) the full Logonid record for a user, synced with the
        RACF-mapped attributes so both managers show one reality."""
        uid = userid.upper()
        rec = self.meta.users.get(uid, {})
        stored = rec.get("lid")
        if stored:
            lid = _lid.lid_from_dict(stored)
        else:
            group = self.meta.user_group(uid, users_repo)
            lid = _lid.new_lid(uid, name=uid, group=group, created_by=self.requester)
        user = users_repo.get(uid)
        attrs = {a.upper() for a in user.attributes} if user else set()
        no_omvs = self.meta.user_no_omvs(uid, users_repo)
        _lid.sync_from_racf(
            lid,
            special=("SPECIAL" in attrs),
            group=self.meta.user_group(uid, users_repo),
            omvs_uid=str(self.meta.uid_for(uid, users_repo)) if not no_omvs else None,
            home=self.meta.user_home(uid) if not no_omvs else None,
            program=self.meta.user_program(uid) if not no_omvs else None,
            no_omvs=no_omvs,
            revoked=bool(getattr(user, "revoked", False)) if user else None,
        )
        return lid

    def _store_lid(self, userid: str, lid: dict) -> None:
        uid = userid.upper()
        rec = dict(self.meta.users.get(uid, {}))
        rec["lid"] = _lid.lid_to_dict(lid)
        self.meta.users[uid] = rec
        self.meta.save()

    # ---- ACF2 UID string + rule engine (Phase 2) ----
    def _uid_string(self, userid: str, users_repo: RacfRepository) -> str:
        return _rules.build_uid(self._get_lid(userid, users_repo))

    def _rule_key(self, key: str) -> str:
        """Storage key for a rule set. Resource rules are namespaced by their type so
        a resource $KEY cannot collide with a data set $KEY."""
        k = (key or "").upper()
        if self.context.setting == "RESOURCE" and self.context.resource_type:
            return f"@{self.context.resource_type}.{k}"
        return k

    def _get_ruleset(self, storage_key: str):
        d = self.meta.rules.get(storage_key.upper())
        return _rules.ruleset_from_dict(d) if d else None

    def _store_ruleset(self, rs, storage_key: str = None) -> None:
        self.meta.rules[(storage_key or rs.key).upper()] = _rules.ruleset_to_dict(rs)
        self.meta.save()

    def _compile(self, cmd: str, users_repo: RacfRepository) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        body = cmd[7:].strip()
        if body.startswith("*"):
            body = body[1:].strip()
        body = body.replace(";", "\n")            # allow one-line source with ';' separators
        rs = _rules.compile_rule(body)
        if not rs.key:
            return "ACF00013 $KEY REQUIRED - COMPILE $KEY(key) UID(mask) ..."
        self._store_ruleset(rs, self._rule_key(rs.key))
        scope = f"TYPE({self.context.resource_type}) " if self.context.setting == "RESOURCE" else ""
        return (f"ACF60050 {scope}RULE SET {rs.key} COMPILED\n"
                f"ACF60051 {len(rs.lines)} RULE LINE(S) STORED")

    def _decomp(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        arg = parts[1].strip() if len(parts) > 1 else ""
        m = re.search(r"\$?KEY\(([^)]*)\)", arg, re.I)
        key = (m.group(1) if m else arg).strip().strip("'\"").upper()
        if not key:
            return "DECOMP $KEY(key)"
        rs = self._get_ruleset(self._rule_key(key))
        if rs is None:
            return f"ACF60052 NO RULE SET FOUND FOR KEY {key}"
        return _rules.decompile_rule(rs)

    # ---- ACF2 enforcement mode (Phase 6): ABORT / LOG / WARN / QUIET ----
    def _acf2_mode(self) -> str:
        """The active enforcement mode from GSO OPTS (default ABORT)."""
        return str(self._gso_store().get("OPTS", {}).get("MODE", "ABORT")).upper()

    def _apply_mode(self, result: str):
        """Given a raw rule result (ALLOW/LOG/PREVENT), return the effective result and
        an explanatory note under the current ACF2 mode. In ABORT a PREVENT denies; in
        LOG/WARN/QUIET a would-be PREVENT is permitted (logged except in QUIET)."""
        mode = self._acf2_mode()
        if result == "ALLOW":
            return "ALLOW", f"MODE {mode}"
        if result == "LOG":
            return "ALLOW", f"PERMITTED AND LOGGED, MODE {mode}"
        # result == PREVENT
        if mode == "ABORT":
            return "PREVENT", "ACCESS DENIED, MODE ABORT"
        if mode == "QUIET":
            return "ALLOW", "RULE WOULD PREVENT - PERMITTED (NOT LOGGED), MODE QUIET"
        return "ALLOW", f"RULE WOULD PREVENT - PERMITTED AND LOGGED, MODE {mode}"

    # ---- XREF scope lists (Phase 6): decentralised administration ----
    def _xref_insert(self, cmd: str, users_repo: RacfRepository) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        kind = self.context.profile_type
        parts = cmd.split()
        if len(parts) < 3:
            return "INSERT scopeid entry [entry ...]"
        scopeid = parts[1].upper()
        entries = [p.upper() for p in parts[2:]]
        store = self.meta.xref.setdefault(kind, {})
        existing = store.setdefault(scopeid, [])
        for e in entries:
            if e not in existing:
                existing.append(e)
        self.meta.save()
        return f"XREF({kind}) SCOPE {scopeid} STORED WITH {len(existing)} ENTRY(IES)"

    def _xref_list(self, arg: str) -> str:
        kind = self.context.profile_type
        store = self.meta.xref.get(kind, {})
        rid = arg.split()[0].upper() if arg.strip() else ""
        if rid and rid not in ("*", "ALL"):
            if rid not in store:
                return f"XREF({kind}) SCOPE {rid} NOT FOUND"
            return f"{rid} XREF({kind})  " + "  ".join(store[rid])
        if not store:
            return f"NO XREF({kind}) SCOPE LISTS DEFINED"
        return "\n".join(f"{sid} XREF({kind})  " + "  ".join(masks) for sid, masks in sorted(store.items()))

    def _xref_delete(self, arg: str) -> str:
        kind = self.context.profile_type
        rid = arg.split()[0].upper() if arg.strip() else ""
        store = self.meta.xref.get(kind, {})
        if rid in store:
            store.pop(rid)
            self.meta.save()
            return f"XREF({kind}) SCOPE {rid} DELETED"
        return f"XREF({kind}) SCOPE {rid} NOT FOUND"

    def _in_scope(self, kind: str, entry: str) -> bool:
        """True if `entry` falls within a scope list of the given kind owned by the
        requester's group (or the requester). No scope lists = unrestricted."""
        store = self.meta.xref.get(kind.upper(), {})
        if not store:
            return True
        entry = (entry or "").upper()
        req_group = self.meta.user_group(self.requester, self.state.racf) if self.state else ""
        for sid, masks in store.items():
            if sid not in (req_group.upper(), self.requester):
                continue
            if any(_rules.uid_matches(mask, entry) for mask in masks):
                return True
        return False

    # ---- ACFRPTxx SMF reports (Phase 5) ----
    def _report(self, name: str, users_repo: RacfRepository) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        name = name.upper()
        if name == "ACFRPTPW":
            return _rpt.report_pw(self.state)
        if name == "ACFRPTRV":
            return _rpt.report_rv(self.state)
        if name == "ACFRPTDS":
            return _rpt.report_ds(self.state)
        if name == "ACFRPTLL":
            return _rpt.report_ll(list(users_repo.users), self.meta)
        return ("ACFRPTxx REPORTS: ACFRPTPW (password/logon)  ACFRPTRV (violations)  "
                "ACFRPTDS (data set access)  ACFRPTLL (logonid list)")

    # ---- GSO records (Phase 4) ----
    def _gso_store(self) -> dict:
        if not self.meta.gso:
            self.meta.gso = _gso.default_gso()
            self.meta.save()
        return self.meta.gso

    def _control_edit(self, cmd: str, users_repo: RacfRepository, verb: str) -> str:
        if not self._is_security_admin(users_repo):
            return self._deny_function()
        parts = cmd.split()
        if len(parts) < 2:
            return f"{verb} recordid FIELD(value) ...  (OPTS PSWD RULEOPTS TSO UNIXOPTS SAFDEF APPLDEF)"
        rid = parts[1].upper()
        if not _gso.known_record(rid):
            return f"ACF60060 UNKNOWN GSO RECORD {rid} (OPTS PSWD RULEOPTS TSO UNIXOPTS SAFDEF APPLDEF)"
        store = self._gso_store()
        rec = store.setdefault(rid, dict(_gso.GSO_DEFAULTS.get(rid, {})))
        changed = _gso.apply_fields(rec, cmd)
        self.meta.save()
        verb_txt = "STORED" if verb == "INSERT" else "CHANGED"
        return (f"{rid} GSO RECORD {verb_txt}"
                + (f" ({', '.join(changed)})" if changed else ""))

    def _control_list(self, arg: str) -> str:
        store = self._gso_store()
        rid = (arg.split()[0].upper() if arg.strip() else "")
        if not rid or rid in ("*", "ALL"):
            return "\n\n".join(_gso.format_gso(k, store[k]) for k in _gso.GSO_DEFAULTS if k in store)
        if rid not in store:
            if _gso.known_record(rid):
                store[rid] = dict(_gso.GSO_DEFAULTS[rid])
            else:
                return f"ACF60061 GSO RECORD {rid} NOT FOUND"
        return _gso.format_gso(rid, store[rid])

    def _control_delete(self, arg: str) -> str:
        rid = arg.split()[0].upper() if arg.strip() else ""
        if not rid:
            return "DELETE gso-record-id"
        store = self._gso_store()
        if rid in store and _gso.known_record(rid):
            store[rid] = dict(_gso.GSO_DEFAULTS[rid])   # DELETE resets a GSO record to defaults
            self.meta.save()
            return f"{rid} GSO RECORD RESET TO DEFAULTS"
        return f"ACF60061 GSO RECORD {rid} NOT FOUND"

    def _format_password_section(self, user) -> str:
        if not user:
            return ""
        masked = "ENCRYPTED" if str(user.password).startswith("$1$") else "CLEAR"
        return f"{user.userid:<8} PASSWORD({masked}) PASSDATE(25.020) MAXDAYS(090)"

    def _format_lid(self, user, users_repo: RacfRepository, *, short: bool = False, omvs_only: bool = False) -> str:
        if not user:
            return ""
        lid = self._get_lid(user.userid, users_repo)
        if omvs_only:
            v = lid.get("values", {})
            omvs = _lid._grp(_lid.LID_OMVS, v)
            return f"{user.userid} {omvs}" if omvs else f"{user.userid} NO-OMVS"
        if short:
            return _lid.format_lid_short(lid)
        return _lid.format_lid_full(lid, uid_string=_rules.build_uid(lid))

    def _format_group(self, group: str, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore) -> str:
        g = dynamic_racf.groups.get(group.upper())
        if not g:
            return f"GROUP PROFILE {group.upper()} NOT FOUND"
        lines = [f"{g.name} GID({self.meta.gid_for(g.name)}) OWNER({g.owner}) SUPGROUP({g.supgroup})"]
        members = sorted(g.users)
        if members:
            lines.append("MEMBERS")
            for user in members:
                lines.append(f"  {user} AUTH({g.users[user]})")
        return "\n".join(lines)

    def _list_rules(self, arg: str, dynamic_racf: DynamicRacfStore, *, dataset_mode: bool, racf_class: str = "") -> str:
        upper = (arg or "").upper().strip()
        if dataset_mode:
            clsname = "DATASET"
            typecode = "DSN"
        else:
            clsname = racf_class
            typecode = self.context.resource_type
        profiles = dynamic_racf.profiles.get(clsname, {})
        if not upper or upper == "*" or upper == "LIKE(-)":
            names = sorted(profiles)
        elif upper.startswith("LIKE("):
            mask = upper[5:upper.find(")")].replace("-", "*")
            names = [n for n in sorted(profiles) if fnmatch.fnmatch(n, mask)]
        else:
            target = upper.split()[0].strip("'\"")
            if dataset_mode:
                target = self._dataset_name(target)
            names = [n for n in sorted(profiles) if n == target or fnmatch.fnmatch(n, target.replace("-", "*"))]
        if not names:
            return "NO RULES MATCH CRITERIA"
        return "\n\n".join(self._format_rule_set(profiles[n], dataset_mode=dataset_mode, typecode=typecode) for n in names)

    def _format_rule_set(self, prof, *, dataset_mode: bool, typecode: str) -> str:
        name = prof.name.upper()
        if dataset_mode:
            key, _, remainder = name.partition('.')
            resource = remainder or name
        else:
            key = name.split('.', 1)[0]
            resource = name
        lines = [f"$KEY({key})" + ("" if dataset_mode else f" TYPE({typecode})")]
        if prof.permits:
            for ident, access in sorted(prof.permits.items()):
                service = _ACCESS_TO_SERVICE.get(access.upper(), "READ")
                if service:
                    lines.append(f"{resource} UID({ident}) SERVICE({service}) ALLOW")
                else:
                    lines.append(f"{resource} UID({ident}) PREVENT")
        if prof.uacc != "NONE":
            service = _ACCESS_TO_SERVICE.get(prof.uacc.upper(), "READ")
            lines.append(f"{resource} UID(*) SERVICE({service}) ALLOW")
        else:
            lines.append(f"{resource} UID(*) PREVENT")
        return "\n".join(lines)

    def _format_access_result(self, name: str, prof, users_repo: RacfRepository, dynamic_racf: DynamicRacfStore, *, dataset_mode: bool, typecode: str = "") -> str:
        title = name.upper()
        if not prof:
            return f"ACCESS SUBCOMMAND RESULTS FOR: {title}\n\nNO MATCHING RULES"
        lines = [f"ACCESS SUBCOMMAND RESULTS FOR: {title}", ""]
        if dataset_mode:
            key = title.split('.', 1)[0]
        else:
            key = title.split('.', 1)[0]
        lines.append(f"Key: {key}")
        for ident, access in sorted(prof.permits.items()):
            service = _ACCESS_TO_SERVICE.get(access.upper(), "READ")
            lines.append(f" {title} UID({ident}) SERVICE({service}) ALLOW")
        if prof.uacc != "NONE":
            service = _ACCESS_TO_SERVICE.get(prof.uacc.upper(), "READ")
            lines.append(f" {title} UID(*) SERVICE({service}) ALLOW")
        else:
            lines.append(f" {title} UID(*) PREVENT")
        return "\n".join(lines)

    def _dataset_name(self, value: str) -> str:
        name = value.strip().strip("'\"").upper()
        return name

    def _compose_dataset_from_key_resource(self, key: str, resource: str) -> str:
        key = key.upper().strip("'\"")
        resource = resource.upper().strip("'\"")
        if not resource:
            return key
        if resource.startswith(key + "."):
            return resource
        if key in {"*", "**"}:
            return resource
        return f"{key}.{resource}"

    def _service_to_access(self, text: str) -> str:
        services = ",".join(part.strip().upper() for part in (text or "").replace(" ", "").split(",") if part.strip())
        if services in _SERVICE_TO_ACCESS:
            return _SERVICE_TO_ACCESS[services]
        if "DELETE" in services:
            return "ALTER"
        if "UPDATE" in services or "ADD" in services:
            return "UPDATE"
        if "EXEC" in services:
            return "EXECUTE"
        return "READ"
