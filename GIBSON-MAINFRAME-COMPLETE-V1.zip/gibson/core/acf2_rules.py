"""ACF2 access-rule engine - the core of how ACF2 differs from RACF.

ACF2 is rule-based and deny-by-default. Access is decided by:
  * a **UID string** - a site-defined concatenation of logonid fields that identifies
    a user for rule matching (e.g. GROUP + LID -> ``PAYROLLJSMITH``); and
  * **compiled rule sets** keyed by ``$KEY`` (the dataset HLQ or a resource name), each
    a list of rule lines carrying a UID mask and per-access permissions
    (``R`` read, ``W`` write, ``A`` alloc, ``E`` exec), where each permission is
    ``A`` allow, ``L`` allow+log, or ``P``/blank prevent.

Evaluation walks the matching rule set's lines in order; the first line whose UID mask
(and environment) matches decides. If nothing matches, access is **prevented** - the
deny-by-default behaviour that is the heart of ACF2.

Pure and dependency-free for easy testing. Training content only.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

ACCESS_LETTERS = ["R", "W", "A", "E"]   # Read, Write, Alloc, Execute
_SERVICE_TO_LETTER = {
    "READ": "R", "WRITE": "W", "UPDATE": "W", "ALLOC": "A", "ALLOCATE": "A",
    "EXEC": "E", "EXECUTE": "E", "DELETE": "A", "SCRATCH": "A",
}


# --------------------------------------------------------------------------- #
#  UID string
# --------------------------------------------------------------------------- #
# The site UID string composition. GIBSON's default concatenates GROUP then LID,
# which is a common teaching layout (real sites define this in the ACFFDR / @UID).
DEFAULT_UID_TEMPLATE = "{GROUP}{LID}"


def build_uid(lid: Dict, template: str = DEFAULT_UID_TEMPLATE) -> str:
    """Compose the ACF2 UID string for a logonid from its fields."""
    v = lid.get("values", {})
    fields = {
        "LID": lid.get("LID", ""),
        "GROUP": v.get("GROUP", ""),
        "NAME": v.get("NAME", ""),
        "UID": v.get("UID", ""),
    }
    out = template
    for k, val in fields.items():
        out = out.replace("{" + k + "}", str(val or ""))
    return out.upper()


# --------------------------------------------------------------------------- #
#  Rule model
# --------------------------------------------------------------------------- #
@dataclass
class RuleLine:
    uid_mask: str = "-"                       # "-" matches every UID
    perms: Dict[str, str] = field(default_factory=dict)   # {"R":"A","W":"L",...}
    next_key: str = ""
    source: str = ""
    shift: str = ""
    until: str = ""
    data: str = ""


@dataclass
class RuleSet:
    key: str
    lines: List[RuleLine] = field(default_factory=list)


# --------------------------------------------------------------------------- #
#  UID-mask matching
# --------------------------------------------------------------------------- #
def uid_matches(mask: str, uid: str) -> bool:
    """ACF2 UID-mask match. ``-`` matches the rest, ``*`` matches one character,
    other characters match literally (case-insensitive). An empty mask or ``-``
    matches everything."""
    mask = (mask or "-").upper()
    uid = (uid or "").upper()
    if mask in ("", "-"):
        return True
    rx = []
    for ch in mask:
        if ch == "-":
            rx.append(".*")
        elif ch == "*":
            rx.append(".")
        else:
            rx.append(re.escape(ch))
    # a mask without a trailing '-' is a prefix match in ACF2 (rest unrestricted)
    pattern = "".join(rx)
    if not mask.endswith("-"):
        pattern += ".*"
    return re.match("^" + pattern + "$", uid) is not None


def _mask_specificity(mask: str) -> int:
    """More literal (non-wildcard) characters = more specific = checked first."""
    m = (mask or "-").upper()
    return sum(1 for c in m if c not in "-*")


# --------------------------------------------------------------------------- #
#  Compile / decompile ACF2 rule source
# --------------------------------------------------------------------------- #
def compile_rule(text: str) -> RuleSet:
    """Parse ACF2 rule source into a RuleSet.

    Example source::

        $KEY(PAYROLL)
         UID(PAYROLL-) R(A) W(A) E(A)
         UID(SYSADM-)  R(A) W(A) A(A) E(A)
         UID(-)        R(A)
    """
    key = ""
    lines: List[RuleLine] = []
    for raw in text.splitlines():
        s = raw.strip()
        if not s or s.startswith("$"):
            m = re.search(r"\$KEY\(([^)]*)\)", s, re.I)
            if m:
                key = m.group(1).strip().upper()
            continue
        um = re.search(r"UID\(([^)]*)\)", s, re.I)
        uid_mask = (um.group(1).strip() or "-").upper() if um else "-"
        perms: Dict[str, str] = {}
        for letter in ACCESS_LETTERS:
            pm = re.search(letter + r"\(([ALP])\)", s, re.I)
            if pm:
                perms[letter] = pm.group(1).upper()
        nk = re.search(r"NEXTKEY\(([^)]*)\)", s, re.I)
        src = re.search(r"SOURCE\(([^)]*)\)", s, re.I)
        shf = re.search(r"SHIFT\(([^)]*)\)", s, re.I)
        unt = re.search(r"UNTIL\(([^)]*)\)", s, re.I)
        lines.append(RuleLine(
            uid_mask=uid_mask, perms=perms,
            next_key=(nk.group(1).upper() if nk else ""),
            source=(src.group(1).upper() if src else ""),
            shift=(shf.group(1).upper() if shf else ""),
            until=(unt.group(1) if unt else ""),
        ))
    return RuleSet(key=key, lines=lines)


def decompile_rule(rs: RuleSet) -> str:
    """Render a RuleSet back into authentic ACF2 rule-set display."""
    out = [f"$KEY({rs.key})"]
    for ln in rs.lines:
        parts = [f"UID({ln.uid_mask})"]
        for letter in ACCESS_LETTERS:
            if letter in ln.perms:
                parts.append(f"{letter}({ln.perms[letter]})")
        if ln.source:
            parts.append(f"SOURCE({ln.source})")
        if ln.shift:
            parts.append(f"SHIFT({ln.shift})")
        if ln.until:
            parts.append(f"UNTIL({ln.until})")
        if ln.next_key:
            parts.append(f"NEXTKEY({ln.next_key})")
        out.append("  " + "  ".join(parts))
    return "\n".join(out)


# --------------------------------------------------------------------------- #
#  Evaluation (deny-by-default)
# --------------------------------------------------------------------------- #
def service_to_letter(service: str) -> str:
    return _SERVICE_TO_LETTER.get((service or "READ").upper(), "R")


def evaluate(rs: Optional[RuleSet], uid: str, service: str,
             source: str = "") -> Tuple[str, Optional[RuleLine]]:
    """Return (result, matched_line) where result is ALLOW / LOG / PREVENT.
    Deny-by-default: no rule set or no matching line -> PREVENT."""
    letter = service_to_letter(service)
    if rs is None or not rs.lines:
        return "PREVENT", None
    # ACF2 checks the most specific UID masks first
    ordered = sorted(rs.lines, key=lambda l: _mask_specificity(l.uid_mask), reverse=True)
    for ln in ordered:
        if not uid_matches(ln.uid_mask, uid):
            continue
        if ln.source and source and ln.source != source.upper():
            continue
        val = ln.perms.get(letter, "P")
        if val == "A":
            return "ALLOW", ln
        if val == "L":
            return "LOG", ln
        return "PREVENT", ln          # explicit P or blank on the matching line
    return "PREVENT", None


# --------------------------------------------------------------------------- #
#  Serialization (for the ACF2 meta store)
# --------------------------------------------------------------------------- #
def ruleset_to_dict(rs: RuleSet) -> Dict:
    return {"key": rs.key, "lines": [
        {"uid_mask": l.uid_mask, "perms": l.perms, "next_key": l.next_key,
         "source": l.source, "shift": l.shift, "until": l.until, "data": l.data}
        for l in rs.lines]}


def ruleset_from_dict(d: Dict) -> RuleSet:
    rs = RuleSet(key=(d or {}).get("key", ""))
    for ld in (d or {}).get("lines", []):
        rs.lines.append(RuleLine(
            uid_mask=ld.get("uid_mask", "-"), perms=dict(ld.get("perms", {})),
            next_key=ld.get("next_key", ""), source=ld.get("source", ""),
            shift=ld.get("shift", ""), until=ld.get("until", ""), data=ld.get("data", "")))
    return rs


def add_rule_line(rs: RuleSet, uid_mask: str, perms: Dict[str, str],
                  source: str = "", next_key: str = "") -> None:
    """Add or replace a rule line for a UID mask."""
    uid_mask = (uid_mask or "-").upper()
    for ln in rs.lines:
        if ln.uid_mask == uid_mask:
            ln.perms.update(perms)
            if source:
                ln.source = source.upper()
            if next_key:
                ln.next_key = next_key.upper()
            return
    rs.lines.append(RuleLine(uid_mask=uid_mask, perms=dict(perms),
                             source=source.upper(), next_key=next_key.upper()))
