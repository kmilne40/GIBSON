"""Living system address-space population.

A real z/OS LPAR runs dozens of persistent started tasks (STCs) and system
address spaces - JES2, TCPIP, VTAM, RACF, OMVS, WLM, GRS, CATALOG, LLA, VLF,
plus subsystems (Db2, CICS).  Gibson previously showed only the logged-on TSO
user and any submitted jobs, so ``SDSF DA`` / ``D A,L`` looked like an empty
lab.  This module models the standard population so the system looks and feels
like a real production LPAR, and - because every STC runs under a RACF identity
via the STARTED class - it doubles as a security-review surface (which tasks run
with SPECIAL/OPERATIONS or a shared id, a classic escalation path).

Everything here is deterministic: ASIDs are fixed in realistic order and CPU
figures jitter on a per-minute seed so ``DA`` "ticks" without needing a
background thread.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class AddressSpace:
    jobname: str
    stepname: str
    program: str
    owner: str            # owning RACF user id (STARTED class / STDATA)
    srvclass: str         # WLM service class
    astype: str           # SYSTEM | STC | TSU | INIT | JOB
    base_cpu: float       # nominal CPU% (jittered at render time)
    asid: int = 0         # assigned by system_address_spaces()
    subsystem: str = ""   # e.g. DB2, CICS - for grouping

    @property
    def asid_hex(self) -> str:
        return f"{self.asid:04X}"


# Canonical population, in the ASID order a real IPL brings them up.
# (jobname, stepname, program, owner, srvclass, astype, base_cpu, subsystem)
_CANON = [
    ("*MASTER*", "*MASTER*", "IEEMB860", "+MASTER+", "SYSTEM", "SYSTEM", 0.4, ""),
    ("PCAUTH",   "PCAUTH",   "IEFPCAUT", "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("RASP",     "RASP",     "IARMR000", "STCUSER",  "SYSTEM", "SYSTEM", 0.1, ""),
    ("TRACE",    "TRACE",    "ITTMTTR",  "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("DUMPSRV",  "DUMPSRV",  "IEAVTDSV", "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("XCFAS",    "XCFAS",    "IXCES860", "STCUSER",  "SYSTEM", "SYSTEM", 0.3, ""),
    ("GRS",      "GRS",      "ISGGRS00", "STCUSER",  "SYSTEM", "SYSTEM", 0.2, ""),
    ("SMSPDSE",  "SMSPDSE",  "ADYSPDSE", "STCUSER",  "SYSTEM", "SYSTEM", 0.1, ""),
    ("CONSOLE",  "CONSOLE",  "IEAVC700", "STCUSER",  "SYSTEM", "SYSTEM", 0.1, ""),
    ("WLM",      "WLM",      "IWMAM99",  "STCUSER",  "SYSTEM", "SYSTEM", 0.2, ""),
    ("ANTMAIN",  "ANTMAIN",  "ANTMAIN",  "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("OMVS",     "OMVS",     "BPXINIT",  "OMVSKERN", "SYSTEM", "SYSTEM", 0.6, ""),
    ("IEFSCHAS", "IEFSCHAS", "IEFSCHAS", "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("JESXCF",   "JESXCF",   "IXZIXCF",  "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("ALLOCAS",  "ALLOCAS",  "IEFAB4I0", "STCUSER",  "SYSTEM", "SYSTEM", 0.0, ""),
    ("IOSAS",    "IOSAS",    "IOSAS",    "STCUSER",  "SYSTEM", "SYSTEM", 0.1, ""),
    ("IXGLOGR",  "IXGLOGR",  "IXGBLF00", "STCUSER",  "SYSSTC", "STC",    0.1, ""),
    ("CEA",      "CEA",      "CEAINIT",  "STCUSER",  "SYSSTC", "STC",    0.0, ""),
    ("CATALOG",  "CATALOG",  "IGGCATLG", "STCUSER",  "SYSSTC", "STC",    0.3, ""),
    ("RRS",      "RRS",      "ATRIMIKI", "STCUSER",  "SYSSTC", "STC",    0.0, ""),
    ("JES2",     "IEFPROC",  "HASJES20", "STCUSER",  "SYSSTC", "STC",    0.5, ""),
    ("VLF",      "VLF",      "COFMINIT", "STCUSER",  "SYSSTC", "STC",    0.0, ""),
    ("LLA",      "LLA",      "CSVLLCRE", "STCUSER",  "SYSSTC", "STC",    0.1, ""),
    ("RACF",     "RACF",     "IRRSSM00", "STCUSER",  "SYSSTC", "STC",    0.2, ""),
    ("ICSF",     "ICSF",     "CSFMMAIN", "STCUSER",  "SYSSTC", "STC",    0.1, ""),
    ("NET",      "NET",      "ISTINM01", "STCUSER",  "SYSSTC", "STC",    0.4, ""),
    ("TCPIP",    "TCPIP",    "EZBTCPIP", "TCPIP",    "SYSSTC", "STC",    0.7, ""),
    ("RESOLVER", "RESOLVER", "EZBREINI", "TCPIP",    "SYSSTC", "STC",    0.0, ""),
    ("TN3270",   "TN3270",   "EZBTNINI", "TCPIP",    "SYSSTC", "STC",    0.3, ""),
    ("FTPD",     "FTPD",     "FTPD",     "FTPD",     "STCLO",  "STC",    0.0, ""),
    ("TCAS",     "TCAS",     "IKTCAS00", "STCUSER",  "SYSSTC", "STC",    0.2, ""),
    ("SDSF",     "SDSF",     "ISFHCTL",  "STCUSER",  "SYSSTC", "STC",    0.1, ""),
    ("BAQSTRT",  "BAQSTRT",  "BBGZSRV",  "ZCONSRV",  "STCHI",  "STC",    0.3, "ZOSCONNECT"),
    ("INIT",     "IEFIIC",   "IEFIIC",   "STCUSER",  "STCLO",  "INIT",   0.0, ""),
    ("INIT",     "IEFIIC",   "IEFIIC",   "STCUSER",  "STCLO",  "INIT",   0.0, ""),
    # Subsystems - owned by their own ids (STARTED class STDATA), the way a real
    # shop assigns dedicated task ids.  These are the interesting review targets.
    ("DSN1MSTR", "DSN1MSTR", "DSN3MSTR", "SYSDSP",   "SYSSTC", "STC",    0.4, "DB2"),
    ("DSN1DBM1", "DSN1DBM1", "DSNYASCP", "SYSDSP",   "SYSSTC", "STC",    0.6, "DB2"),
    ("DSN1DIST", "DSN1DIST", "DSNADMF0", "SYSDSP",   "SYSSTC", "STC",    0.2, "DB2"),
    ("DSN1IRLM", "DSN1IRLM", "DXRRLM00", "SYSDSP",   "SYSSTC", "STC",    0.1, "DB2"),
    ("CICS",     "CICS",     "DFHSIP",   "CICSUSER", "CICSHI", "STC",    0.5, "CICS"),
    ("CICSAOR",  "CICSAOR",  "DFHSIP",   "CICSUSER", "CICSHI", "STC",    0.4, "CICS"),
]


def _jitter(base: float, seed_key: str) -> float:
    """Deterministic per-minute CPU jitter so DA appears to tick."""
    if base <= 0:
        return round(base, 2)
    minute = int(time.time() // 60)
    h = abs(hash((seed_key, minute))) % 1000 / 1000.0     # 0.000 .. 0.999
    val = base * (0.6 + 0.8 * h)                            # 0.6x .. 1.4x
    return round(val, 2)


def system_address_spaces(state=None, *, include_tso: bool = True,
                          include_jobs: bool = True) -> List[AddressSpace]:
    """Return the live address-space population with ASIDs assigned.

    Persistent STCs first (fixed ASIDs), then any connected TSO users and
    active batch jobs from Gibson's session/JES state (higher ASIDs)."""
    spaces: List[AddressSpace] = []
    for asid, row in enumerate(_CANON, start=1):
        jn, sn, pgm, owner, srv, ast, cpu, subsys = row
        spaces.append(AddressSpace(jn, sn, pgm, owner, srv, ast, cpu,
                                   asid=asid, subsystem=subsys))
    next_asid = len(_CANON) + 1

    # optional hands-on escalation scenario (see gibson.core.escalation_lab)
    if state is not None and getattr(state, "_escalation_lab", False):
        spaces.append(AddressSpace("AUTOMON", "AUTOMON", "AOPBTCH", "AUTOOPER",
                                   "STCHI", "STC", 0.4, asid=next_asid))
        next_asid += 1

    if include_tso and state is not None:
        try:
            for sess in state.sessions.sessions.values():
                if getattr(sess, "connected", False):
                    uid = (getattr(sess, "userid", "") or "IBMUSER").upper()[:8]
                    spaces.append(AddressSpace(uid, "TSO", "IKJEFT01", uid,
                                               "TSO", "TSU", 0.2, asid=next_asid))
                    next_asid += 1
        except Exception:
            pass

    if include_jobs and state is not None:
        try:
            from gibson.core.jes import JobStatus
            for job in state.jes.jobs.values():
                if job.status in (JobStatus.EXECUTION, getattr(JobStatus, "ACTIVE", JobStatus.EXECUTION)):
                    spaces.append(AddressSpace(job.jobname[:8], job.jobname[:8],
                                               "IEFIIC", job.owner[:8], "BATCHHI",
                                               "JOB", 0.3, asid=next_asid))
                    next_asid += 1
        except Exception:
            pass

    # apply CPU jitter
    for sp in spaces:
        sp.base_cpu = _jitter(sp.base_cpu, sp.jobname + sp.stepname)
    return spaces


def started_task_identities(state) -> List[dict]:
    """STC -> owning RACF user, with the owner's attributes, for a STARTED-class
    security review.  Flags any task running under a SPECIAL/OPERATIONS id or a
    UID(0) OMVS id - the classic 'privileged started task' finding."""
    out: List[dict] = []
    seen = set()
    for sp in system_address_spaces(state, include_tso=False, include_jobs=False):
        if sp.astype not in ("STC", "SYSTEM") or sp.jobname in seen:
            continue
        seen.add(sp.jobname)
        owner = sp.owner
        attrs, uid0, special, oper = _owner_attrs(state, owner)
        flags = []
        if special:
            flags.append("SPECIAL")
        if oper:
            flags.append("OPERATIONS")
        if uid0:
            flags.append("UID(0)")
        out.append({
            "jobname": sp.jobname, "program": sp.program, "owner": owner,
            "attrs": attrs, "risk": flags,
        })
    return out


def _owner_attrs(state, owner: str):
    """Return (attr_text, uid0, special, operations) for a RACF user id.
    state.racf is authoritative (so remediation via ALTUSER clears findings);
    the CARLa store is only a fallback for ids not in the primary repository."""
    special = oper = uid0 = False
    resolved = False
    try:
        u = state.racf.get(owner)
        if u is not None:
            resolved = True
            attrs = {a.upper() for a in getattr(u, "attributes", []) or []}
            special = "SPECIAL" in attrs
            oper = "OPERATIONS" in attrs
            seg = getattr(u, "omvs_segment", {}) or {}
            uidval = str(seg.get("uid", seg.get("UID", ""))).strip()
            if uidval == "0":
                uid0 = True
    except Exception:
        pass
    if not resolved:
        try:
            from gibson.apps.racf_admin import get_racf_store
            rec = get_racf_store(state).users.get(owner.upper()) or {}
            a = {x.upper() for x in (rec.get("ATTRS") or set())}
            special = "SPECIAL" in a
            oper = "OPERATIONS" in a
            if str((rec.get("OMVS") or {}).get("UID", "")).strip() == "0":
                uid0 = True
        except Exception:
            pass
    parts = []
    if special:
        parts.append("SPECIAL")
    if oper:
        parts.append("OPERATIONS")
    if uid0:
        parts.append("UID(0)")
    return (" ".join(parts) or "NONE"), uid0, special, oper


# --------------------------------------------------------------------------- #
#  Ambient SYSLOG heartbeat                                                    #
# --------------------------------------------------------------------------- #
_HEARTBEAT = [
    ("JES2",   "$HASP630 NO ACTIVE OUTPUT LINES ON DEVICE"),
    ("JES2",   "$HASP263 WAITING FOR WORK - NO WORK TO DO"),
    ("TCPIP",  "EZD1176I TCPIP HAS SUCCESSFULLY CONNECTED TO THE OMPROUTE"),
    ("TCPIP",  "EZZ4313I INITIALIZATION COMPLETE FOR DEVICE LOOPBACK"),
    ("WLM",    "IWM063I WLM POLICY DEFAULT HAS BEEN ACTIVATED"),
    ("NET",    "IST1349I COMPONENT ID IS 5695-11701-000"),
    ("GRS",    "ISG343I GRS RING PROCESSING IS ACTIVE"),
    ("LLA",    "CSV210I LIBRARY LOOKASIDE REFRESH COMPLETE"),
    ("XCFAS",  "IXC466I HEARTBEAT CHECK COMPLETE FOR SYSTEM MVSC"),
    ("SMF",    "IEE362A SMF ENTER DUMP FOR SYS1.MANX ON SBSYS1 - 62 PERCENT FULL"),
    ("CATALOG","IEC351I CATALOG ADDRESS SPACE HEARTBEAT"),
    ("RACF",   "IRRH003I THE RACF SUBSYSTEM IS ACTIVE"),
]


def ambient_syslog_lines(count: int = 8, sysname: str = "MVSC") -> List[str]:
    """Return `count` realistic, timestamped ambient SYSLOG lines drawn from the
    running STCs, so the LOG panel looks alive every time it is viewed."""
    import datetime
    now = datetime.datetime.now()
    minute = int(time.time() // 60)
    lines: List[str] = []
    n = len(_HEARTBEAT)
    for i in range(count):
        stc, msg = _HEARTBEAT[(minute + i) % n]
        ts = (now - datetime.timedelta(seconds=17 * (count - i))).strftime("%H.%M.%S")
        lines.append(f"{ts} {sysname:<4} {msg}")
    return lines
