"""Registry of JCL step (EXEC PGM=) handlers.

Lets new batch programs be added without editing the monolithic dispatch in
``JES._interpret_steps``: register a handler with :func:`register_step_handler` (or the
``@step_handler`` decorator) and the JES engine will call it whenever a step runs that PGM.
A handler receives a :class:`StepContext` and appends to ``ctx.out`` / ``ctx.spool`` and sets
``ctx.rc`` / ``ctx.last_rc`` / ``ctx.summary``.

The engine consults this registry *before* its built-in branches, so registered handlers can
add new programs or (deliberately) override a built-in.  It starts empty except for the
handlers registered here, so existing behaviour is unchanged.
"""
from __future__ import annotations
from typing import Any, Callable, Dict, List, Optional

STEP_HANDLERS: Dict[str, "StepHandler"] = {}
StepHandler = Callable[["StepContext"], None]


def register_step_handler(*pgms: str) -> Callable[[StepHandler], StepHandler]:
    def deco(fn: StepHandler) -> StepHandler:
        for p in pgms:
            STEP_HANDLERS[p.upper()] = fn
        return fn
    return deco


class StepContext:
    def __init__(self, *, engine, job, stepname, pgm, operands, blocks, lines,
                 runner, sql_runner, cobol_runner, out: List[str], spool: list,
                 rc: int, last_rc: int):
        self.engine = engine
        self.job = job
        self.stepname = stepname
        self.pgm = pgm
        self.operands = operands
        self.blocks = blocks              # in-stream DD data (SYSIN/SYSTSIN/...)
        self.lines = lines                # full expanded JCL lines
        self.runner = runner
        self.sql_runner = sql_runner
        self.cobol_runner = cobol_runner
        self.out = out
        self.spool = spool
        self.rc = rc
        self.last_rc = last_rc
        self.summary: Optional[str] = None

    # --- convenience -------------------------------------------------------
    @property
    def state(self):
        proc = self.runner.__self__ if hasattr(self.runner, "__self__") else None
        return getattr(proc, "state", None)

    @property
    def user(self) -> str:
        proc = self.runner.__self__ if hasattr(self.runner, "__self__") else None
        return getattr(proc, "userid", self.job.owner)

    def say(self, *msgs: str) -> None:
        self.out.extend(msgs)

    def dd_dsn(self, ddname: str) -> Optional[str]:
        import re
        jcl = "\n".join(self.lines)
        m = re.search(rf"^//{ddname}\s+DD\s+DSN=([^,\s]+)", jcl, re.I | re.M)
        return m.group(1).strip().strip("'") if m else None

    def executed(self, cc: Optional[int] = None) -> None:
        cc = self.last_rc if cc is None else cc
        self.out.append(f"IEF142I {self.job.jobname} {self.stepname} - STEP WAS EXECUTED - COND CODE {cc:04d}")


# ---------------------------------------------------------------------------
# Built-in registered handlers (new PGMs added via the registry, not the core)
# ---------------------------------------------------------------------------
@register_step_handler("IEFBR14")
def _iefbr14(ctx: StepContext) -> None:
    """IEFBR14: the do-nothing utility - allocates any NEW DSN DDs (migrated from the
    core dispatch into the registry as the convergence proof)."""
    import re
    jcl = "\n".join(ctx.lines)
    state, user = ctx.state, ctx.user
    for m_dd in re.finditer(r"^//[A-Z0-9#$@]+\s+DD\s+DSN=([^,\s]+).*?DISP=\(([^)]*)\)", jcl, re.I | re.M):
        dsn = m_dd.group(1).strip().strip("'")
        disp = m_dd.group(2).upper()
        if state is not None and "NEW" in disp:
            try:
                state.datasets.allocate(user, dsn, org="PS")
                ctx.say(f"IEF285I {dsn.upper()} CATALOGED")
            except Exception as exc:
                ctx.rc = max(ctx.rc, 8); ctx.last_rc = 8
                ctx.say(f"IEC141I {dsn.upper()} ALLOCATION FAILED - {exc}")
    ctx.executed()
    ctx.last_rc = max(ctx.last_rc, 0)


@register_step_handler("ASMACG", "ASMAHLG", "ASMAG")
def _assemble_and_go(ctx: StepContext) -> None:
    """Assemble-and-go: assemble the SYSIN HLASM and RUN it on the real S/390 interpreter
    against the live control-block image, so HLASM can be written and executed inside a job.
    (The IBM ASMACG cataloged procedure = assemble + link + go.)"""
    src = ctx.blocks.get("C.SYSIN") or ctx.blocks.get("SYSIN") or ""
    ctx.say("ASMA90 ASSEMBLE-AND-GO STARTED")
    from gibson.lang.asm.s390 import S390, assemble_listing, Storage
    rc, listing, _syms = assemble_listing(src)
    ctx.spool.append(_spool("SYSPRINT", listing + "\n"))
    if rc >= 8:
        ctx.rc = max(ctx.rc, rc); ctx.last_rc = rc
        ctx.say(f"ASMA999E ASSEMBLY ERRORS - COND CODE {rc:04d}")
        ctx.executed(rc); return
    try:
        state = ctx.state
        if state is not None:
            from gibson.lang.rexx.hoststorage import build_storage
            cpu = S390(build_storage(state, ctx.user)).run(src)
        else:
            cpu = S390(Storage()).run(src)
        ctx.say("ASMA90 PROGRAM RAN - SUPERVISOR=%s CC=%d" % (cpu.supervisor, cpu.cc))
        ctx.say("  R0-R7  : " + " ".join(f"{cpu.reg[i]:08X}" for i in range(8)))
        ctx.say("  R8-R15 : " + " ".join(f"{cpu.reg[i]:08X}" for i in range(8, 16)))
        for w in cpu.wto:
            ctx.say(f"+{w}")                      # WTO -> console/spool
        if cpu.svc_calls:
            ctx.say("  SVC ISSUED: " + " ".join(str(n) for n in cpu.svc_calls))
    except Exception as exc:
        ctx.rc = max(ctx.rc, 8); ctx.last_rc = 8
        ctx.say(f"ASMA999E EXECUTION FAILED - {exc}")
    ctx.executed(ctx.last_rc)


@register_step_handler("IRXJCL", "IRXEXEC")
def _batch_rexx(ctx: StepContext) -> None:
    """Batch REXX: run SYSEXEC/SYSTSIN (or the PARM-named exec) on the full engine."""
    ctx.say("IRX0001I GIBSON BATCH REXX (IRXJCL)")
    source = ctx.blocks.get("SYSEXEC") or ctx.blocks.get("SYSTSIN") or ""
    state = ctx.state
    if not source.strip():
        # PARM='member' -> read from the MVP exec library
        import re
        m = re.search(r"PARM=\(?'?([A-Z0-9@#$]+)", ctx.operands.upper())
        if m and state is not None:
            try:
                source = state.datasets.read(ctx.user, f"{ctx.user.upper()}.MVP.EXEC({m.group(1)})")
            except Exception:
                source = ""
    if source.strip() and state is not None:
        try:
            from gibson.lang.integration import run_rexx_full
            from gibson.apps.tso import TsoCommandProcessor
            runner = TsoCommandProcessor(state, ctx.user).run
            out = run_rexx_full(state, ctx.user, source, "", tso_runner=runner)
            ctx.say(*[l for l in out.splitlines()])
            ctx.spool.append(_spool("SYSTSPRT", out + "\n"))
        except Exception as exc:
            ctx.rc = max(ctx.rc, 8); ctx.last_rc = 8
            ctx.say(f"IRX0040I ERROR RUNNING REXX - {exc}")
    else:
        ctx.say("IRX0003I NO REXX SOURCE (SYSEXEC/SYSTSIN/PARM) - NOTHING TO RUN")
    ctx.executed()


@register_step_handler("IEBCOPY")
def _iebcopy(ctx: StepContext) -> None:
    """IEBCOPY: copy members from SYSUT1 (input PDS) to SYSUT2 (output PDS)."""
    ctx.say("IEBCOPY  COPY OPERATION STARTED")
    src, dst = ctx.dd_dsn("SYSUT1"), ctx.dd_dsn("SYSUT2")
    state = ctx.state
    copied = 0
    if src and dst and state is not None:
        try:
            members = state.datasets.list_members(ctx.user, src)  # may not exist
        except Exception:
            members = []
        for mbr in (members or []):
            try:
                data = state.datasets.read(ctx.user, f"{src}({mbr})")
                state.datasets.write(ctx.user, f"{dst}({mbr})", data)
                ctx.say(f"IEB167I MEMBER {mbr} COPIED"); copied += 1
            except Exception:
                pass
    ctx.say(f"IEB1135I IEBCOPY COMPLETE - {copied} MEMBER(S) COPIED FROM "
            f"{(src or '?').upper()} TO {(dst or '?').upper()}")
    ctx.executed(0)


def _spool(ddname: str, content: str):
    from gibson.core.jes import SpoolFile
    return SpoolFile(ddname, content)
