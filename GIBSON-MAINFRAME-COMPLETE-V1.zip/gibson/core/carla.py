"""A CARLa mini-interpreter.

CARLa (CARLa Auditing and Reporting Language) is how a zSecure practitioner
actually drives the product - not fixed menu reports, but queries::

    NEWLIST TYPE=RACF
    SELECT SPECIAL
    SORTLIST USERID(8) NAME(20) DFLTGRP OWNER

This interpreter supports the core of that language - ``NEWLIST TYPE=...``,
``SELECT`` / ``EXCLUDE`` (field flags and ``field=value`` / ``<>`` / ``>`` /
``<`` comparisons, comma value-lists), ``SORTLIST`` / ``DISPLAY`` (columns with
optional ``(width)``), and ``SUMMARY`` - over the RACF database, SMF, and the
CKFREEZE snapshot (``TYPE=APF|SENSDSN|STC|ADDRSPACE|SUBSYS``).  It is
deliberately a faithful subset, enough that the queries an auditor reaches for
run and return real results from Gibson's live state.
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional, Tuple

_KEYWORDS = ("NEWLIST", "SELECT", "EXCLUDE", "SORTLIST", "DISPLAY", "SUMMARY",
             "TITLE", "DEFINE", "SORT", "LIMIT")


# ── data sources ───────────────────────────────────────────────────────────
def _racf_rows(state) -> List[Dict[str, str]]:
    from gibson.apps.racf_admin import get_racf_store
    st = get_racf_store(state)
    rows = []
    for uid, u in sorted(st.users.items()):
        attrs = u.get("ATTRS", set()) or set()
        rows.append({
            "USERID": uid, "KEY": uid, "NAME": u.get("NAME", ""),
            "DFLTGRP": u.get("DFLTGRP", ""), "OWNER": u.get("OWNER", u.get("DFLTGRP", "")),
            "SPECIAL": "YES" if "SPECIAL" in attrs else "",
            "OPERATIONS": "YES" if "OPERATIONS" in attrs else "",
            "AUDITOR": "YES" if "AUDITOR" in attrs else "",
            "UID": str((u.get("OMVS", {}) or {}).get("UID", "")),
            "REVOKE": "YES" if str(u.get("REVOKED", "N")).upper() in ("Y", "YES") else "",
            "MFA": "YES" if str((u.get("MFA", {}) or {}).get("ENABLED", "N")).upper() in ("Y", "YES") else "",
        })
    return rows


def _smf_rows(state) -> List[Dict[str, str]]:
    rows = []
    try:
        from gibson.core.smf.writer import get_smf_writer
        recs = list(get_smf_writer(state).records)
    except Exception:
        recs = list(getattr(state, "smf_records", []) or [])
    for r in recs:
        f = {}
        try:
            f = r.fields if isinstance(getattr(r, "fields", None), dict) else dict(r.__dict__)
        except Exception:
            f = {}
        rows.append({
            "TYPE": str(f.get("RECORD_TYPE", getattr(getattr(r, "header", None), "record_type", ""))),
            "TIME": str(f.get("TIME", f.get("TIMESTAMP", ""))),
            "USERID": str(f.get("USERID", f.get("USER", ""))),
            "EVENT": str(f.get("EVENT", f.get("EVENT_TYPE", ""))),
            "DESC": str(f.get("DETAIL", f.get("DESC", f.get("DESCRIPTION", "")))),
            "RESULT": str(f.get("RESULT", "")),
        })
    return rows


def _group_rows(state) -> List[Dict[str, str]]:
    from gibson.apps.racf_admin import get_racf_store
    st = get_racf_store(state)
    rows = []
    for g, members in sorted(st.groups.items()):
        rows.append({"GROUP": g, "SUPGROUP": "SYS1" if g != "SYS1" else "-",
                     "OWNER": "IBMUSER", "MEMBERS": str(len(members)),
                     "MEMBERLIST": ",".join(sorted(members)[:10])})
    return rows


def _source_rows(state, newlist_type: str) -> List[Dict[str, str]]:
    t = newlist_type.upper()
    if t == "RACF":
        return _racf_rows(state)
    if t == "GROUP":
        return _group_rows(state)
    if t in ("SMF", "SMF_STC", "ACCESS"):
        return _smf_rows(state)
    from gibson.core.ckfreeze import get_ckfreeze
    return get_ckfreeze(state).rows_for(t)


# ── field metadata (so learners can discover what they can query) ──────────
FIELDS: Dict[str, List[Tuple[str, str]]] = {
    "RACF": [("USERID", "User id (the profile key)"), ("NAME", "Programmer name"),
             ("DFLTGRP", "Default group"), ("OWNER", "Profile owner"),
             ("SPECIAL", "System-SPECIAL attribute - set = YES"),
             ("OPERATIONS", "OPERATIONS attribute (bypasses dataset access checks)"),
             ("AUDITOR", "AUDITOR attribute"), ("UID", "z/OS UNIX UID (0 = superuser)"),
             ("REVOKE", "User id is revoked"), ("MFA", "Multi-factor auth enabled")],
    "GROUP": [("GROUP", "Group name"), ("SUPGROUP", "Superior group"),
              ("OWNER", "Group owner"), ("MEMBERS", "Number of connected users"),
              ("MEMBERLIST", "Connected user ids")],
    "SMF": [("TYPE", "SMF record type (80 = RACF)"), ("TIME", "Timestamp"),
            ("USERID", "User"), ("EVENT", "Event"), ("DESC", "Description"),
            ("RESULT", "SUCCESS / FAILURE")],
    "APF": [("DSNAME", "Data set name"), ("VOLUME", "Volume serial"),
            ("APF", "APF-authorized"), ("WRITABLE", "Writable by a non-admin (finding)")],
    "SENSDSN": [("DSNAME", "Data set"), ("TYPE", "Category"), ("APF", "APF-authorized"),
                ("WRITABLE", "Writable by a non-admin"), ("REASON", "Why it is sensitive")],
    "STC": [("JOBNAME", "Started-task name"), ("PROGRAM", "Program run"),
            ("OWNER", "RACF id the task runs under"), ("ATTR", "Owner's attributes"),
            ("RISK", "Runs with SPECIAL/OPERATIONS/UID(0) - a finding")],
    "ADDRSPACE": [("JOBNAME", "Address space"), ("ASID", "ASID (hex)"),
                  ("PROGRAM", "Program"), ("OWNER", "Owner id"),
                  ("TYPE", "SYSTEM/STC/TSU/JOB"), ("SRVCLASS", "WLM service class")],
    "SUBSYS": [("SSNAME", "Subsystem name"), ("PROGRAM", "Initialization routine"),
               ("TYPE", "Kind of subsystem")],
}
_ALIASES = {"ADDRSPACE": ("AS",), "SENSDSN": ("SENSITIVE",), "STC": ("STARTED",)}


def carla_help() -> str:
    return "\n".join([
        "CKRCARLA - CARLa Auditing and Reporting Language  (Gibson subset)",
        "=" * 68,
        "CARLa is how you query zSecure.  A query is a NEWLIST that names a data",
        "source, plus optional statements that filter and format the result:",
        "",
        "  NEWLIST TYPE=RACF          pick a data source (see TYPES below)",
        "  SELECT   SPECIAL           keep only rows where a condition is true",
        "  EXCLUDE  DFLTGRP=SYS1      drop rows that match a condition",
        "  SORTLIST USERID(8) NAME(20) DFLTGRP   choose and size the columns",
        "  SUMMARY  DFLTGRP           (instead of SORTLIST) count rows by a field",
        "",
        "CONDITIONS:",
        "  FIELD                a flag is set          e.g. SELECT SPECIAL",
        "  FIELD=VALUE          equals                 e.g. SELECT DFLTGRP=SYS1",
        "  FIELD<>VALUE         not equal",
        "  FIELD>VALUE          greater than (numeric) e.g. SELECT UID>0",
        "  FIELD=VAL1,VAL2      any of the listed values",
        "  FIELD=ABC*           wildcard prefix match  e.g. SELECT USERID=IBM*",
        "  (put several conditions on one SELECT line to AND them together)",
        "",
        "TYPES (data sources):",
        "  RACF   users        GROUP  groups        SMF    audit events",
        "  APF    APF libs     SENSDSN sensitive DS  STC   started tasks",
        "  ADDRSPACE address spaces   SUBSYS subsystems      (from CKFREEZE)",
        "",
        "LEARN MORE:",
        "  ZSEC CARLA FIELDS TYPE=RACF   list the fields available for a type",
        "  ZSEC CARLA EXAMPLES           ready-to-run example queries",
        "  ZSEC CARLA <member>           run a saved query (SPECIAL, UID0, APFWRIT...)",
    ])


def carla_fields(newlist_type: str) -> str:
    t = (newlist_type or "").upper()
    for canon, aliases in _ALIASES.items():
        if t in aliases:
            t = canon
    flds = FIELDS.get(t)
    if not flds:
        return ("CKR0521E UNKNOWN NEWLIST TYPE '" + t + "'. VALID TYPES: "
                + ", ".join(sorted(FIELDS)))
    L = [f"CKRCARLA   FIELDS FOR NEWLIST TYPE={t}", "-" * 60]
    w = max(len(f) for f, _ in flds)
    for f, desc in flds:
        L.append(f"  {f.ljust(w)}  {desc}")
    L.append("")
    L.append(f"Example:  NEWLIST TYPE={t}; SORTLIST " +
             " ".join(f for f, _ in flds[:4]))
    return "\n".join(L)


def carla_examples() -> str:
    ex = [
        ("Users with the SPECIAL attribute",
         "NEWLIST TYPE=RACF\nSELECT SPECIAL\nSORTLIST USERID(8) NAME(20) DFLTGRP"),
        ("z/OS UNIX superusers (UID 0)",
         "NEWLIST TYPE=RACF\nSELECT UID=0\nSORTLIST USERID(8) UID"),
        ("APF libraries writable by a non-admin (an escalation path)",
         "NEWLIST TYPE=APF\nSELECT WRITABLE\nSORTLIST DSNAME(44) VOLUME WRITABLE"),
        ("Started tasks and the id they run under",
         "NEWLIST TYPE=STC\nSORTLIST JOBNAME(8) PROGRAM(9) OWNER(9) ATTR RISK"),
        ("Count users by default group",
         "NEWLIST TYPE=RACF\nSUMMARY DFLTGRP"),
        ("User ids that start with IBM",
         "NEWLIST TYPE=RACF\nSELECT USERID=IBM*\nSORTLIST USERID(8) NAME(20)"),
    ]
    L = ["CKRCARLA - CARLa EXAMPLES  (copy one, or run: ZSEC CARLA \"<query>\")", "=" * 68]
    for title, q in ex:
        L.append("")
        L.append("/* " + title + " */")
        L.extend(q.splitlines())
    return "\n".join(L)


# ── condition parsing ──────────────────────────────────────────────────────
_OPS = ("<>", ">=", "<=", "=", ">", "<")


def _parse_conditions(text: str) -> List[Tuple[str, str, str]]:
    """Return list of (field, op, value); a bare field means 'is truthy'."""
    conds = []
    for tok in text.split():
        matched = False
        for op in _OPS:
            if op in tok:
                fld, val = tok.split(op, 1)
                conds.append((fld.upper(), op, val))
                matched = True
                break
        if not matched:
            conds.append((tok.upper(), "TRUTHY", ""))
    return conds


def _match(row: Dict[str, str], conds: List[Tuple[str, str, str]]) -> bool:
    for fld, op, val in conds:
        cell = str(_get(row, fld))
        if op == "TRUTHY":
            if cell.upper() in ("", "NO", "N", "0", "NONE"):
                return False
            continue
        vals = [v.strip().upper() for v in val.split(",")]
        cu = cell.upper()
        if op == "=":
            if not any((cu == v or (v.endswith("*") and cu.startswith(v[:-1]))) for v in vals):
                return False
        elif op == "<>":
            if any((cu == v or (v.endswith("*") and cu.startswith(v[:-1]))) for v in vals):
                return False
        elif op in (">", "<", ">=", "<="):
            try:
                c, v = float(cell), float(val)
            except ValueError:
                c, v = cu, val.upper()
            if op == ">" and not c > v: return False
            if op == "<" and not c < v: return False
            if op == ">=" and not c >= v: return False
            if op == "<=" and not c <= v: return False
    return True


def _get(row: Dict[str, str], field: str) -> str:
    for k, v in row.items():
        if k.upper() == field.upper():
            return v
    return ""


def _parse_columns(text: str) -> List[Tuple[str, int]]:
    cols = []
    for tok in text.split():
        m = re.match(r"([A-Za-z0-9_#$@]+)(?:\((\d+)\))?$", tok)
        if m:
            cols.append((m.group(1).upper(), int(m.group(2)) if m.group(2) else 0))
    return cols


# ── the interpreter ────────────────────────────────────────────────────────
class Carla:
    def __init__(self, state: Any):
        self.state = state

    def run(self, source: str) -> str:
        raw = (source or "").strip()
        verb = raw.upper()
        # educational verbs
        if verb in ("HELP", "?", "TUTORIAL"):
            return carla_help()
        if verb in ("EXAMPLES", "EXAMPLE", "SAMPLES"):
            return carla_examples()
        if verb.startswith("FIELDS"):
            m = re.search(r"TYPE\s*=\s*([A-Z_]+)", verb)
            return carla_fields(m.group(1) if m else "RACF")
        source = re.sub(r"/\*.*?\*/", " ", source, flags=re.S)     # strip comments
        blocks = self._split_blocks(source)
        if not blocks:
            return ("CKR0500E NO NEWLIST STATEMENT FOUND.\n"
                    "A query must begin with NEWLIST TYPE=<source>.  "
                    "Try  ZSEC CARLA HELP  or  ZSEC CARLA EXAMPLES.")
        out: List[str] = []
        for blk in blocks:
            out.append(self._run_block(blk))
        return "\n".join(out)

    def _split_blocks(self, source: str) -> List[List[str]]:
        stmts: List[str] = []
        for raw in source.splitlines():
            line = raw.strip()
            if not line:
                continue
            stmts.append(line)
        blocks: List[List[str]] = []
        cur: List[str] = []
        for s in stmts:
            if s.upper().startswith("NEWLIST"):
                if cur:
                    blocks.append(cur)
                cur = [s]
            elif cur:
                cur.append(s)
        if cur:
            blocks.append(cur)
        return blocks

    def _run_block(self, stmts: List[str]) -> str:
        nl = stmts[0]
        m = re.search(r"TYPE\s*=\s*([A-Z_]+)", nl.upper())
        ntype = (m.group(1) if m else "RACF").upper()
        for canon, aliases in _ALIASES.items():
            if ntype in aliases:
                ntype = canon
        valid = set(FIELDS) | {"SMF"}
        if ntype not in valid:
            return (f"CKR0521E UNKNOWN NEWLIST TYPE '{ntype}'.\n"
                    f"VALID TYPES: {', '.join(sorted(valid))}.\n"
                    f"Try  ZSEC CARLA FIELDS TYPE=RACF  to see what you can query.")
        title = ""
        selects: List[List[Tuple[str, str, str]]] = []
        excludes: List[List[Tuple[str, str, str]]] = []
        columns: List[Tuple[str, int]] = []
        summary: Optional[str] = None
        for s in stmts[1:]:
            u = s.upper()
            if u.startswith("SELECT"):
                selects.append(_parse_conditions(s[6:]))
            elif u.startswith("EXCLUDE"):
                excludes.append(_parse_conditions(s[7:]))
            elif u.startswith("SORTLIST") or u.startswith("DISPLAY"):
                columns = _parse_columns(s.split(None, 1)[1] if " " in s else "")
            elif u.startswith("SUMMARY"):
                summary = s.split(None, 1)[1].strip().upper() if " " in s else None
            elif u.startswith("TITLE"):
                title = s.split(None, 1)[1].strip().strip('"').strip("'") if " " in s else ""

        rows = _source_rows(self.state, ntype)
        eligible = len(rows)
        for conds in selects:
            rows = [r for r in rows if _match(r, conds)]
        for conds in excludes:
            rows = [r for r in rows if not _match(r, conds)]

        # educational feedback
        notes: List[str] = []
        known = {f for f, _ in FIELDS.get(ntype, [])} | {"KEY"}
        if known and columns:
            unknown = [c for c, _ in columns if c not in known]
            if unknown:
                notes.append("NOTE: unknown field(s) for TYPE=" + ntype + ": "
                             + ", ".join(unknown) + "  (see ZSEC CARLA FIELDS TYPE=" + ntype + ")")
        if eligible == 0:
            notes.append("NOTE: the " + ntype + " source is currently empty.")
        elif not rows and (selects or excludes):
            notes.append("NOTE: no rows matched your SELECT/EXCLUDE - loosen the condition, "
                         "or run without SELECT to see all " + str(eligible) + " rows.")

        if summary:
            return self._render_summary(ntype, summary, rows, eligible, title, notes)
        if not columns and rows:
            columns = [(k, 0) for k in list(rows[0].keys()) if k not in ("KEY", "MEMBERLIST")][:6]
        return self._render(ntype, columns, rows, eligible, title, notes)

    def _render(self, ntype, columns, rows, eligible, title, notes=None) -> str:
        L = [f"CKRCARLA   IBM Security zSecure   NEWLIST TYPE={ntype}"]
        if title:
            L.append(title)
        widths = {}
        for c, w in columns:
            widths[c] = w or max([len(c)] + [len(str(_get(r, c))) for r in rows] + [1])
        L.append("  ".join(c.ljust(widths[c]) for c, _ in columns))
        L.append("  ".join("-" * widths[c] for c, _ in columns))
        for r in rows:
            L.append("  ".join(str(_get(r, c)).ljust(widths[c])[:widths[c]] for c, _ in columns))
        L.append(f"***  {eligible} ELIGIBLE RECORDS,  {len(rows)} SELECTED  ***")
        for n in (notes or []):
            L.append(n)
        return "\n".join(L)

    def _render_summary(self, ntype, field, rows, eligible, title, notes=None) -> str:
        counts: Dict[str, int] = {}
        for r in rows:
            counts[str(_get(r, field)) or "(none)"] = counts.get(str(_get(r, field)) or "(none)", 0) + 1
        L = [f"CKRCARLA   IBM Security zSecure   NEWLIST TYPE={ntype}  SUMMARY {field}"]
        if title:
            L.append(title)
        w = max([len(field)] + [len(k) for k in counts] + [1])
        L.append(f"{field.ljust(w)}  COUNT")
        L.append(f"{'-'*w}  -----")
        for k, n in sorted(counts.items(), key=lambda kv: -kv[1]):
            L.append(f"{k.ljust(w)}  {n:>5}")
        L.append(f"***  {eligible} ELIGIBLE RECORDS,  {len(rows)} SELECTED,  {len(counts)} GROUPS  ***")
        for n in (notes or []):
            L.append(n)
        return "\n".join(L)


# Ready-made CARLa members an auditor reaches for (a mini CKRSPROF library).
CANNED = {
    "SPECIAL": "NEWLIST TYPE=RACF\nSELECT SPECIAL\nSORTLIST USERID(8) NAME(20) DFLTGRP OWNER",
    "OPERATIONS": "NEWLIST TYPE=RACF\nSELECT OPERATIONS\nSORTLIST USERID(8) NAME(20) DFLTGRP",
    "UID0": "NEWLIST TYPE=RACF\nSELECT UID=0\nSORTLIST USERID(8) NAME(20) UID",
    "REVOKED": "NEWLIST TYPE=RACF\nSELECT REVOKE\nSORTLIST USERID(8) NAME(20) DFLTGRP",
    "APF": "NEWLIST TYPE=APF\nSORTLIST DSNAME(44) VOLUME WRITABLE",
    "APFWRIT": "NEWLIST TYPE=APF\nSELECT WRITABLE\nSORTLIST DSNAME(44) VOLUME WRITABLE",
    "SENSDSN": "NEWLIST TYPE=SENSDSN\nSORTLIST DSNAME(20) TYPE APF WRITABLE REASON(40)",
    "STC": "NEWLIST TYPE=STC\nSORTLIST JOBNAME(8) PROGRAM(9) OWNER(9) ATTR RISK",
    "STCRISK": "NEWLIST TYPE=STC\nSELECT RISK\nSORTLIST JOBNAME(8) OWNER(9) ATTR",
}


def run_carla(state, source: str) -> str:
    return Carla(state).run(source)
