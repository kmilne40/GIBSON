"""ACF2 Logonid (LID) record model.

Real Broadcom (CA) ACF2 logonids carry ~100 fields grouped into privileges, facility
privileges, access statistics, password control, restrictions, and TSO / OMVS
segments. GIBSON previously modelled ~4 of them. This module defines the field set,
parses ACF2 ``INSERT`` / ``CHANGE`` field syntax, and renders an authentic ``ACF LIST``
display. It is deliberately dependency-free and pure so it is easy to test.

Field syntax modelled:
  * boolean privilege:      ``NON-CNCL``  (set)   /  ``NO-NON-CNCL`` | ``NONON-CNCL`` (clear)
  * valued keyword:         ``TSOACCT(ACCT01)`` , ``GROUP(SYS1)`` , ``UID(0)``

Training content only; all data is fictional.
"""
from __future__ import annotations

import re
from typing import Dict, List, Tuple

# --- boolean privilege/attribute fields (ACF LIST shows those that are set) --- #
LID_PRIVILEGES = [
    "NON-CNCL", "SECURITY", "ACCOUNT", "AUDIT", "LEADER", "CONSULT",
    "READALL", "RULEVLD", "MUSASS", "REFRESH", "RESTRICT",
]
LID_FACILITIES = [
    "TSO", "CICS", "IMS", "JOB", "STC", "MOUNT", "OPERATOR", "PPGM", "BATCH",
]
LID_STATUS = ["SUSPEND", "CANCEL"]
LID_BOOLEANS = LID_PRIVILEGES + LID_FACILITIES + LID_STATUS

# --- valued keyword fields, grouped for display --- #
LID_IDENT = ["NAME", "GROUP", "UID", "ACCOUNT-NO", "PHONE"]
LID_RESTRICT = ["SHIFT", "SOURCE", "EXPIRE", "PROGRAM"]
LID_TSO = ["TSOACCT", "TSOPROC", "TSORGN", "TSOLSIZE", "TSOMSIZE",
           "TSOUNIT", "TSOHCLS", "TSOMCLS", "TSOSOUT"]
LID_OMVS = ["OMVSUID", "HOME", "OMVSPGM", "ASSIZE", "CPUTIME", "THREADS", "FILEPROC"]
LID_VALUED = LID_IDENT + LID_RESTRICT + LID_TSO + LID_OMVS

# system-maintained statistics (shown, not usually set by hand)
LID_STATS = ["ACC-CNT", "ACC-DATE", "ACC-TIME", "ACC-SRCE",
             "PSWD-DAT", "PSWD-VIO", "PSWD-TOD", "UPD-TOD"]

# aliases so common RACF-flavoured keywords still work
_ALIASES = {
    "PROGRAM": "OMVSPGM", "OMVSPROGRAM": "OMVSPGM",
    "ACCTNUM": "ACCOUNT-NO", "PSWDEXP": "EXPIRE",
}


def new_lid(userid: str, *, name: str = "", group: str = "SYS1",
            created_by: str = "IBMUSER", created_on: str = "24.001") -> Dict:
    """Create a fresh Logonid record with ACF2-style defaults."""
    return {
        "LID": userid.upper(),
        "flags": {"TSO"},                       # a normal user can use TSO by default
        "values": {"NAME": name or userid.upper(), "GROUP": group.upper()},
        "stats": {"ACC-CNT": "00000", "ACC-DATE": "00.000", "ACC-SRCE": "",
                  "PSWD-VIO": "000", "PSWD-DAT": created_on},
        "created-by": created_by.upper(),
        "created-on": created_on,
    }


def _canon(field: str) -> str:
    f = field.upper()
    return _ALIASES.get(f, f)


def apply_command(lid: Dict, cmd: str) -> List[str]:
    """Parse ACF2 field syntax from an INSERT/CHANGE command and apply it to `lid`.
    Returns the list of field names that were changed."""
    changed: List[str] = []
    up = " " + cmd.upper() + " "

    # 1. valued keywords: FIELD(value)
    for m in re.finditer(r"([A-Z][A-Z0-9\-]*)\(([^)]*)\)", cmd, re.I):
        raw = m.group(1).upper()
        field = _canon(raw)
        val = m.group(2).strip().strip("'\"")
        if field in LID_VALUED:
            lid["values"][field] = val
            changed.append(field)
        elif field == "PASSWORD":
            changed.append("PASSWORD")            # handled by the RACF backend, noted here

    # 2. booleans: FIELD sets, NO-FIELD / NOFIELD clears
    for field in LID_BOOLEANS:
        pat_set = r"\s" + re.escape(field) + r"\s"
        pat_clr = r"\s(?:NO-?" + re.escape(field) + r")\s"
        if re.search(pat_clr, up):
            if field in lid["flags"]:
                lid["flags"].discard(field); changed.append("NO-" + field)
            else:
                changed.append("NO-" + field)
        elif re.search(pat_set, up):
            lid["flags"].add(field); changed.append(field)
    return changed


def sync_from_racf(lid: Dict, *, special: bool = None, group: str = None,
                   omvs_uid: str = None, home: str = None, program: str = None,
                   no_omvs: bool = False, revoked: bool = None) -> None:
    """Mirror the RACF-mapped attributes into the LID record so the two managers show
    one consistent reality."""
    if special is True:
        lid["flags"].add("SECURITY")
    elif special is False:
        lid["flags"].discard("SECURITY")
    if group:
        lid["values"]["GROUP"] = group.upper()
    if revoked is True:
        lid["flags"].add("SUSPEND")
    # note: RACF non-revoked does NOT clear an ACF2-set SUSPEND (ACF2 owns that flag)
    if no_omvs:
        for f in ("OMVSUID", "HOME", "OMVSPGM"):
            lid["values"].pop(f, None)
    else:
        if omvs_uid is not None:
            lid["values"]["OMVSUID"] = str(omvs_uid)
        if home:
            lid["values"]["HOME"] = home
        if program:
            lid["values"]["OMVSPGM"] = program


def _grp(present: List[str], values: Dict) -> str:
    parts = [f"{f}({values[f]})" for f in present if values.get(f) not in (None, "")]
    return " ".join(parts)


def format_lid_full(lid: Dict, uid_string: str = "") -> str:
    """Authentic multi-section ACF LIST display of a logonid."""
    v = lid.get("values", {})
    flags = lid.get("flags", set())
    st = lid.get("stats", {})
    name = v.get("NAME", lid["LID"])
    out: List[str] = []
    out.append(f"{lid['LID']:<8} {name:<24} STDATE({lid.get('created-on','')}) "
               f"STCREATE({lid.get('created-by','')})")
    if uid_string:
        out.append(f"UID         {uid_string}")

    privs = [f for f in LID_PRIVILEGES if f in flags]
    out.append("PRIVILEGES  " + (" ".join(privs) if privs else "NONE"))
    facs = [f for f in LID_FACILITIES if f in flags]
    out.append("FACILITIES  " + (" ".join(facs) if facs else "NONE"))
    status = [f for f in LID_STATUS if f in flags]
    if status:
        out.append("STATUS      " + " ".join(status))

    out.append("ACCESS      " + (f"ACC-CNT({st.get('ACC-CNT','00000')}) "
                                  f"ACC-DATE({st.get('ACC-DATE','00.000')}) "
                                  f"ACC-TIME({st.get('ACC-TIME','00:00')}) "
                                  f"ACC-SRCE({st.get('ACC-SRCE','') or 'N/A'})"))
    out.append("PASSWORD    " + (f"PSWD-DAT({st.get('PSWD-DAT','00.000')}) "
                                 f"PSWD-VIO({st.get('PSWD-VIO','000')})"
                                 + (f" EXPIRE({v['EXPIRE']})" if v.get('EXPIRE') else "")))

    ident = _grp(["GROUP", "UID", "ACCOUNT-NO"], v)
    if ident:
        out.append("IDENT       " + ident)
    restr = _grp(["SHIFT", "SOURCE", "PROGRAM"], v)
    if restr:
        out.append("RESTRICT    " + restr)
    tso = _grp(LID_TSO, v)
    if tso:
        out.append("TSO         " + tso)
    omvs = _grp(LID_OMVS, v)
    if omvs:
        out.append("OMVS        " + omvs)
    return "\n".join(out)


def format_lid_short(lid: Dict) -> str:
    """One-line summary for LIST LIKE(mask)."""
    v = lid.get("values", {})
    flags = lid.get("flags", set())
    shown = [f for f in ("SECURITY", "ACCOUNT", "AUDIT", "NON-CNCL", "SUSPEND") if f in flags]
    tail = (" " + " ".join(shown)) if shown else ""
    uid = f" UID({v['OMVSUID']})" if v.get("OMVSUID") not in (None, "") else ""
    return f"{lid['LID']:<8} NAME({v.get('NAME', lid['LID'])}) GROUP({v.get('GROUP','SYS1')}){tail}{uid}"


def lid_to_dict(lid: Dict) -> Dict:
    """JSON-safe form (flags set -> sorted list) for persistence."""
    d = dict(lid)
    d["flags"] = sorted(lid.get("flags", set()))
    return d


def lid_from_dict(d: Dict) -> Dict:
    """Rehydrate a persisted LID record (flags list -> set)."""
    lid = dict(d or {})
    lid["flags"] = set(lid.get("flags", []) or [])
    lid.setdefault("values", {})
    lid.setdefault("stats", {})
    lid.setdefault("LID", lid.get("LID", ""))
    return lid
