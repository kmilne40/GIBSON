"""IBM z/OS Connect server model.

Reproduces the behaviour a z/OS Connect user actually sees: the ``/zosConnect``
RESTful admin API (list/inspect/lifecycle of APIs and services), the invoke path
that turns a REST call into a real back-end call (Db2 SQL / CICS transaction),
SAF authority levels (Administrator / Operations / Invoke / Reader) enforced
against RACF groups, ``BAQ``-prefixed messages with correct HTTP status codes,
and SMF 123 audit records - all driven by a Liberty ``server.xml`` configuration.

The model is transport-agnostic: ``handle(method, path, userid, ...)`` returns
``(status_code, json_body)`` so it can be driven by the HTTP router or by tests.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

HOST = "gibsondb2.gibson.example.com"
HTTPS_PORT = 9443


# ── configuration (Liberty server.xml, zosConnectManager) ──────────────────
@dataclass
class ZosConnectConfig:
    globalAdminGroup: str = "ZCONADM"
    globalOperationsGroup: str = "ZCONOPR"
    globalInvokeGroup: str = "ZCONINV"
    globalReaderGroup: str = "ZCONRDR"
    requireAuth: bool = True
    requireSecure: bool = True
    interceptors: Tuple[str, ...] = ("authorizationInterceptor", "auditInterceptor")

    def server_xml(self) -> str:
        interc = ", ".join(self.interceptors)
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<server description="GIBSON z/OS Connect server">\n'
            '  <featureManager>\n'
            '    <feature>zosconnect:zosConnect-2.0</feature>\n'
            '    <feature>zosconnect:apiRequester-1.0</feature>\n'
            '    <feature>restConnector-2.0</feature>\n'
            '    <feature>batchSMFLogging-1.0</feature>\n'
            '  </featureManager>\n'
            f'  <httpEndpoint id="defaultHttpEndpoint" host="*" httpPort="-1" httpsPort="{HTTPS_PORT}"/>\n'
            '  <zosconnect_auditInterceptor id="auditInterceptor" sequence="1" apiProviderSmfVersion="2"/>\n'
            '  <zosconnect_authorizationInterceptor id="authorizationInterceptor" sequence="2"/>\n'
            f'  <zosconnect_zosConnectInterceptors id="interceptorList" interceptorRef="{interc}"/>\n'
            '  <zosconnect_zosConnectManager globalInterceptorsRef="interceptorList"\n'
            f'      globalAdminGroup="{self.globalAdminGroup}" globalOperationsGroup="{self.globalOperationsGroup}"\n'
            f'      globalInvokeGroup="{self.globalInvokeGroup}" globalReaderGroup="{self.globalReaderGroup}"\n'
            f'      requireAuth="{str(self.requireAuth).lower()}" requireSecure="{str(self.requireSecure).lower()}"\n'
            '      setUTF8ResponseEncoding="true"/>\n'
            '</server>\n'
        )


@dataclass
class Service:
    name: str
    provider: str            # CICS | IMS | Db2 | MQ | Batch
    description: str
    status: str = "Started"
    # invoke wiring
    kind: str = "sql"        # sql | cics | static
    sql: str = ""            # for Db2 provider
    transaction: str = ""    # for CICS provider


@dataclass
class Api:
    name: str
    version: str
    description: str
    basePath: str
    status: str = "Started"
    # operation -> (method, path-suffix, service-name)
    operations: List[Tuple[str, str, str]] = field(default_factory=list)


class ZosConnectServer:
    def __init__(self, state):
        self.state = state
        self.cfg = ZosConnectConfig()
        self.services: Dict[str, Service] = {}
        self.apis: Dict[str, Api] = {}
        self.stats = {"requests": 0, "successes": 0, "failures": 0}
        self._seed()

    def _seed(self) -> None:
        self.services["accountInquiryService"] = Service(
            "accountInquiryService", "CICS", "CBSA account inquiry via CICS transaction OMEN",
            kind="cics", transaction="OMEN")
        self.services["customerQueryService"] = Service(
            "customerQueryService", "Db2", "Customer lookup via Db2 SQL",
            kind="sql", sql="SELECT * FROM GIBSON.EMPLOYEES")
        self.apis["accountsAPI"] = Api(
            "accountsAPI", "1.0.0", "Accounts REST API", "/accounts",
            operations=[("GET", "/{id}", "accountInquiryService")])
        self.apis["customersAPI"] = Api(
            "customersAPI", "1.0.0", "Customers REST API", "/customers",
            operations=[("GET", "/{id}", "customerQueryService")])

    # ── SAF authority resolution ──────────────────────────────────────────
    def _groups_of(self, userid: str) -> set:
        try:
            from gibson.apps.racf_admin import get_racf_store
            st = get_racf_store(self.state)
            return {g for g, members in st.groups.items() if userid.upper() in members}
        except Exception:
            return set()

    def authority(self, userid: str) -> set:
        """Return the set of authority levels {ADMIN, OPERATIONS, INVOKE, READER}
        the user holds, by RACF group membership (admin implies all)."""
        g = self._groups_of(userid)
        levels = set()
        if self.cfg.globalAdminGroup.upper() in g:
            levels |= {"ADMIN", "OPERATIONS", "INVOKE", "READER"}
        if self.cfg.globalOperationsGroup.upper() in g:
            levels |= {"OPERATIONS", "READER"}
        if self.cfg.globalInvokeGroup.upper() in g:
            levels |= {"INVOKE"}
        if self.cfg.globalReaderGroup.upper() in g:
            levels |= {"READER"}
        return levels

    def _authorized(self, userid: str, need: str) -> bool:
        if not self.cfg.requireAuth:
            return True
        return need in self.authority(userid)

    # ── audit ─────────────────────────────────────────────────────────────
    def _smf(self, userid: str, event: str, detail: str, result: str = "SUCCESS") -> None:
        try:
            from gibson.core.smf import record_smf
            record_smf(self.state, "123", userid, event, detail, result=result)
        except Exception:
            pass
        if result != "SUCCESS":
            try:
                self.state.audit.record_smf80(userid, "ZOSCONNECT", detail, result="FAILURE")
            except Exception:
                pass

    # ── the request entry point ───────────────────────────────────────────
    def handle(self, method: str, path: str, userid: str = "WSGUEST",
               *, body: bytes = b"", content_type: str = "application/json",
               query: Optional[Dict[str, str]] = None) -> Tuple[int, dict]:
        code, resp = self._handle_impl(method, path, userid, body=body,
                                       content_type=content_type, query=query)
        try:  # SENTRY CTI: let ScrAPI Bear auto-detect recon / SAF-deny / injection
            from gibson.apps.cti_scrapi import observe_api_event
            observe_api_event(self.state, userid, "", path,
                              "SUCCESS" if code < 400 else "FAILURE", code)
        except Exception:
            pass
        return code, resp

    def _handle_impl(self, method: str, path: str, userid: str = "WSGUEST",
                     *, body: bytes = b"", content_type: str = "application/json",
                     query: Optional[Dict[str, str]] = None) -> Tuple[int, dict]:
        query = query or {}
        method = method.upper()
        p = path.rstrip("/") or "/"

        # ---- RESTful administration surface -----------------------------
        if p == "/zosConnect/apis" and method == "GET":
            if not self._authorized(userid, "READER"):
                return self._deny(userid, "list APIs")
            return 200, {"apis": [self._api_summary(a) for a in self.apis.values()]}

        if p.startswith("/zosConnect/apis/") and method == "GET":
            name = p.split("/")[-1]
            api = self.apis.get(name)
            if not api:
                return self._notfound("API", name)
            if not self._authorized(userid, "READER"):
                return self._deny(userid, f"read API {name}")
            return 200, self._api_detail(api)

        if p == "/zosConnect/services" and method == "GET":
            if not self._authorized(userid, "READER"):
                return self._deny(userid, "list services")
            return 200, {"zosConnectServices": [self._svc_summary(s) for s in self.services.values()]}

        if p == "/zosConnect/services" and method == "POST":
            # deploy a SAR (admin authority)
            if not self._authorized(userid, "ADMIN"):
                return self._deny(userid, "deploy service")
            if content_type not in ("application/zip", "application/octet-stream"):
                return self._media_type(content_type)
            return 201, {"zosConnectServiceName": "deployedService", "status": "Started"}

        if p.startswith("/zosConnect/services/") and method == "GET":
            name = p.split("/")[-1]
            svc = self.services.get(name)
            if not svc:
                return self._notfound("service", name)
            if not self._authorized(userid, "READER"):
                return self._deny(userid, f"read service {name}")
            return 200, self._svc_detail(svc)

        if p.startswith("/zosConnect/services/") and method == "PUT":
            name = p.split("/")[-1]
            svc = self.services.get(name)
            if not svc:
                return self._notfound("service", name)
            if not self._authorized(userid, "OPERATIONS"):
                return self._deny(userid, f"change status of service {name}")
            status = (query.get("status") or "").lower()
            if status not in ("started", "stopped"):
                return 400, {"errorMessage": "BAQR0406W: The requested status is not valid. "
                             "Valid values are started or stopped."}
            svc.status = "Started" if status == "started" else "Stopped"
            self._smf(userid, "SERVICE-LIFECYCLE", f"{name} {svc.status}")
            return 200, self._svc_summary(svc)

        if p == "/zosConnect/operations/getStatistics" and method == "GET":
            if not self._authorized(userid, "READER"):
                return self._deny(userid, "get statistics")
            return 200, {"zosConnectStatistics": {
                "serverStartTime": "2026-07-04T00:00:00Z",
                "requestCount": self.stats["requests"],
                "successCount": self.stats["successes"],
                "failureCount": self.stats["failures"],
                "services": [{"ServiceName": s.name, "invokeCount":
                              self.stats["requests"] // max(1, len(self.services))}
                             for s in self.services.values()]}}

        # ---- API invoke -------------------------------------------------
        for api in self.apis.values():
            if p.startswith(api.basePath):
                return self._invoke(api, method, p, userid)

        return self._notfound("resource", p)

    # ── invoke: REST -> back end (this is where z/OS Connect meets Db2) ───
    def _invoke(self, api: Api, method: str, path: str, userid: str) -> Tuple[int, dict]:
        if api.status != "Started":
            return 503, {"errorMessage": f"BAQR0407W: The API {api.name} is stopped."}
        if not self._authorized(userid, "INVOKE"):
            return self._deny(userid, f"invoke API {api.name}")
        self.stats["requests"] += 1
        suffix = path[len(api.basePath):]
        for op_method, op_suffix, svc_name in api.operations:
            if op_method != method:
                continue
            # match /{id}
            if op_suffix.startswith("/{") and suffix.startswith("/") and suffix.count("/") == 1:
                arg = suffix[1:]
                svc = self.services.get(svc_name)
                if not svc or svc.status != "Started":
                    self.stats["failures"] += 1
                    return 503, {"errorMessage": f"BAQR0407W: The service {svc_name} is stopped."}
                result = self._call_backend(svc, arg, userid)
                self.stats["successes"] += 1
                self._smf(userid, "API-INVOKE", f"{api.name} {method} {suffix} -> {svc_name}")
                return 200, result
        self.stats["failures"] += 1
        return self._notfound("operation", f"{method} {suffix}")

    def _call_backend(self, svc: Service, arg: str, userid: str) -> dict:
        if svc.kind == "sql":
            try:
                from gibson.apps.db2_sim import Db2Simulator
                rows = Db2Simulator(self.state).run_sql(svc.sql, userid)
                return {"service": svc.name, "provider": "Db2", "rows": rows}
            except Exception as exc:
                return {"service": svc.name, "provider": "Db2", "error": str(exc)}
        if svc.kind == "cics":
            return {"service": svc.name, "provider": "CICS", "transaction": svc.transaction,
                    "accountId": arg, "status": "OK",
                    "message": f"CICS transaction {svc.transaction} invoked for {arg}"}
        return {"service": svc.name, "provider": svc.provider, "result": arg}

    # ── response helpers (JSON shapes + BAQ messages) ─────────────────────
    def _api_summary(self, a: Api) -> dict:
        return {"name": a.name, "version": a.version, "description": a.description,
                "apiUrl": f"https://{HOST}:{HTTPS_PORT}{a.basePath}",
                "documentation": f"https://{HOST}:{HTTPS_PORT}{a.basePath}/api-docs",
                "status": a.status}

    def _api_detail(self, a: Api) -> dict:
        d = self._api_summary(a)
        d["services"] = sorted({s for _, _, s in a.operations})
        d["operations"] = [{"method": m, "path": a.basePath + suf, "service": s}
                           for m, suf, s in a.operations]
        return d

    def _svc_summary(self, s: Service) -> dict:
        return {"ServiceName": s.name, "ServiceProvider": s.provider,
                "ServiceURL": f"https://{HOST}:{HTTPS_PORT}/zosConnect/services/{s.name}",
                "ServiceStatus": s.status}

    def _svc_detail(self, s: Service) -> dict:
        return {"zosConnectServiceName": s.name, "serviceDescription": s.description,
                "serviceProvider": s.provider,
                "serviceInvokeURL": f"https://{HOST}:{HTTPS_PORT}/zosConnect/services/{s.name}?action=invoke",
                "serviceStatusURL": f"https://{HOST}:{HTTPS_PORT}/zosConnect/services/{s.name}?action=status",
                "dataXformProvider": "DATA_UNAVAILABLE", "status": s.status}

    def _deny(self, userid: str, action: str) -> Tuple[int, dict]:
        self._smf(userid, "AUTH-FAILURE", f"not authorized to {action}", result="FAILURE")
        return 403, {"errorMessage":
                     "BAQR0419W: The user is not authorized to perform the requested action."}

    def _notfound(self, kind: str, name: str) -> Tuple[int, dict]:
        return 404, {"errorMessage": f"BAQR0404W: The {kind} {name} was not found."}

    def _media_type(self, ct: str) -> Tuple[int, dict]:
        return 415, {"errorMessage": f"BAQR0418W: An unsupported media type of {ct} was specified."}


def get_zosconnect(state) -> ZosConnectServer:
    srv = getattr(state, "_zosconnect", None)
    if srv is None:
        srv = ZosConnectServer(state)
        try:
            state._zosconnect = srv
        except Exception:
            pass
    return srv
