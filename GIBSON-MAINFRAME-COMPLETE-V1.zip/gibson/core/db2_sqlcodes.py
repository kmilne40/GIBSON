"""Db2 for z/OS SQLCODE / SQLSTATE vocabulary.

Real Db2 programs live and die by the SQLCODE returned in the SQLCA.  This
module gives Gibson's SQL engine the authentic return-code vocabulary and the
exact multi-line diagnostic block SPUFI / DSNTEP2 print on an error, so a failed
statement looks like a real one instead of a generic message.

``Db2Error`` subclasses ``ValueError`` so existing ``except ValueError`` callers
keep working, while new callers can read ``.sqlcode`` / ``.sqlstate`` and render
``.dsnt408_block()``.
"""
from __future__ import annotations

from typing import List


class Db2Error(ValueError):
    def __init__(self, sqlcode: int, sqlstate: str, text: str, *,
                 errp: str = "DSNXORS", tokens: str = ""):
        self.sqlcode = sqlcode
        self.sqlstate = sqlstate
        self.text = text
        self.errp = errp
        self.tokens = tokens
        super().__init__(f"SQLCODE={sqlcode}, SQLSTATE={sqlstate}, {text}")

    def dsnt408_block(self) -> List[str]:
        """The SPUFI / DSNTEP2 diagnostic block for a negative SQLCODE."""
        d = f"{self.sqlcode:<6}" if self.sqlcode >= 0 else f"{self.sqlcode}"
        hexcode = self.sqlcode & 0xFFFFFFFF
        return [
            f"DSNT408I SQLCODE = {self.sqlcode}, ERROR:  {self.text}",
            f"DSNT418I SQLSTATE   = {self.sqlstate} SQLSTATE RETURN CODE",
            f"DSNT415I SQLERRP    = {self.errp} SQL PROCEDURE DETECTING ERROR",
            f"DSNT416I SQLERRD    = {self.sqlcode}  0  0  -1  0  0 SQL DIAGNOSTIC INFORMATION",
            f"DSNT416I SQLERRD    = X'{hexcode:08X}'  X'00000000'  X'00000000'"
            f"  X'FFFFFFFF'  X'00000000'  X'00000000' SQL DIAGNOSTIC INFORMATION",
        ]


# ── factory helpers for the codes real programs hit most often ─────────────
def object_not_found(name: str) -> Db2Error:
    return Db2Error(-204, "42704", f"{name.upper()} IS AN UNDEFINED NAME", tokens=name)


def column_not_found(col: str) -> Db2Error:
    return Db2Error(-206, "42703",
                    f'"{col.upper()}" IS NOT VALID IN THE CONTEXT WHERE IT IS USED')


def syntax_error(sym: str = "") -> Db2Error:
    tok = sym or "<END-OF-STATEMENT>"
    return Db2Error(-104, "42601",
                    f'ILLEGAL SYMBOL "{tok}". SOME SYMBOLS THAT MIGHT BE LEGAL ARE: '
                    f'<KEYWORD> <IDENTIFIER>')


def duplicate_key(index: str = "") -> Db2Error:
    return Db2Error(-803, "23505",
                    "AN INSERTED OR UPDATED VALUE IS INVALID BECAUSE THE INDEX IN "
                    f'INDEX SPACE {index or "XREF0001"} CONSTRAINS COLUMNS OF THE TABLE '
                    "SO NO TWO ROWS CAN CONTAIN DUPLICATE VALUES")


def multiple_rows() -> Db2Error:
    return Db2Error(-811, "21000",
                    "THE RESULT OF AN EMBEDDED SELECT STATEMENT OR A SUBSELECT IN THE "
                    "SET CLAUSE OF AN UPDATE STATEMENT IS A TABLE OF MORE THAN ONE ROW")


def not_authorized(op: str, obj: str, authid: str = "") -> Db2Error:
    return Db2Error(-551, "42501",
                    f"{authid.upper() or 'USER'} DOES NOT HAVE THE PRIVILEGE TO PERFORM "
                    f"OPERATION {op.upper()} ON OBJECT {obj.upper()}")


def resource_unavailable(resource: str) -> Db2Error:
    return Db2Error(-904, "57011",
                    "UNSUCCESSFUL EXECUTION CAUSED BY AN UNAVAILABLE RESOURCE. REASON "
                    f"00C90084, TYPE OF RESOURCE 00000220, AND RESOURCE NAME {resource.upper()}",
                    errp="DSNXRResourceMgr")


def deadlock_timeout() -> Db2Error:
    return Db2Error(-911, "40001",
                    "THE CURRENT UNIT OF WORK HAS BEEN ROLLED BACK DUE TO DEADLOCK OR "
                    "TIMEOUT. REASON 00C9008E, TYPE OF RESOURCE 00000302, AND RESOURCE "
                    "NAME DSNDB06 .SYSTSTAB")


def null_no_indicator() -> Db2Error:
    return Db2Error(-305, "22002",
                    "THE NULL VALUE CANNOT BE ASSIGNED TO OUTPUT HOST VARIABLE NUMBER 1 "
                    "BECAUSE NO INDICATOR VARIABLE IS SPECIFIED")


# SQLCODE +100 (no row found) is a *warning*, returned in the SQLCA, not raised.
NOT_FOUND_ROW = {"SQLCODE": "+100", "SQLSTATE": "02000",
                 "MESSAGE": "DSNE610I NUMBER OF ROWS DISPLAYED IS 0"}
