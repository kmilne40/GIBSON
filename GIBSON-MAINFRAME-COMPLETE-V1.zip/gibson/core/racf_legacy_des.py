from __future__ import annotations

"""Training-only legacy RACF DES password hash generator.

Models the historic eight-character RACF DES password material used by Gibson
labs. It is not a real RACF database parser and must not be used against real
systems.

RACF legacy hash = ``DES(key = f(password), data = EBCDIC userid)`` where the
password->key transform is ``odd_parity(((ebcdic_byte ^ 0x55) << 1))`` per byte
and both password and userid are upper-cased, EBCDIC (cp037), and space-padded
(0x40) to 8 bytes. This is byte-exact with what John the Ripper's
``--format=racf`` computes; it is verified at import-optional call sites by
:func:`selftest` against the published CRACF ground-truth vectors.

Provider policy (this is the fix for the "hashes never crack" bug):
  1. pycryptodome / pycryptodomex ``DES``            (fast C, preferred)
  2. ``cryptography`` TripleDES with K1=K2=K3         (EDE collapses to single DES)
  3. vendored pure-Python DES in ``gibson.core._pure_des`` (can't-fail floor)
The result is ALWAYS a real DES hash. There is no SHA-256 / "simulator" branch
any more: the old fallback produced a correctly-sized but non-DES value that
``john --format=racf`` could never crack, and it did so silently whenever no C
provider was importable (e.g. a stripped ARM64 host).
"""

try:  # pycryptodomex, preferred import used by the original prototype
    from Cryptodome.Cipher import DES as _PYCRYPTO_DES  # type: ignore
except Exception:  # pragma: no cover - optional dependency path
    try:
        from Crypto.Cipher import DES as _PYCRYPTO_DES  # type: ignore
    except Exception:
        _PYCRYPTO_DES = None  # type: ignore

from gibson.core import _pure_des  # bundled, dependency-free, always available


def _crypto_des_encrypt(key8: bytes, block8: bytes):
    """Single DES via the `cryptography` library's TripleDES (K*3 => single DES)."""
    try:
        try:
            from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES
        except Exception:
            from cryptography.hazmat.primitives.ciphers.algorithms import TripleDES
        from cryptography.hazmat.primitives.ciphers import Cipher, modes
        enc = Cipher(TripleDES(key8 * 3), modes.ECB()).encryptor()
        return enc.update(block8) + enc.finalize()
    except Exception:
        return None


def _des_encrypt(key8: bytes, block8: bytes) -> bytes:
    """Encrypt one 8-byte block with single DES using the best provider present.

    Always returns a real DES result: falls through to the vendored pure-Python
    implementation when no C provider is importable, so a correct RACF hash is
    produced in every environment.
    """
    if _PYCRYPTO_DES is not None:
        return _PYCRYPTO_DES.new(key8, _PYCRYPTO_DES.MODE_ECB).encrypt(block8)
    ct = _crypto_des_encrypt(key8, block8)
    if ct is not None:
        return ct
    return _pure_des.des_encrypt_block(key8, block8)


# --------------------------------------------------------------------------- #
#  RACF password material                                                     #
# --------------------------------------------------------------------------- #
def _ebcdic8(value: str) -> bytes:
    raw = (value or "").upper()[:8].encode("cp037", errors="replace")
    return raw.ljust(8, b"\x40")


def _odd_parity(byte: int) -> int:
    b = byte & 0xFE
    ones = bin(b).count("1")
    return b | (0 if ones % 2 else 1)


def _password_key(password: str) -> bytes:
    pw = _ebcdic8(password)
    out = bytearray(8)
    for i, ch in enumerate(pw):
        out[i] = _odd_parity(((ch ^ 0x55) << 1) & 0xFF)
    return bytes(out)


def crypto_available() -> bool:
    """True when a real DES provider is available.

    Now always True because the pure-Python provider is bundled. Retained for
    callers/tests and so a build-time guard can still assert a live DES path.
    """
    try:
        return _des_encrypt(b"\x00" * 8, b"\x00" * 8) is not None
    except Exception:  # pragma: no cover
        return False


def des_provider() -> str:
    """Name of the provider that will actually be used (diagnostics/logging)."""
    if _PYCRYPTO_DES is not None:
        return "pycryptodome"
    if _crypto_des_encrypt(b"\x00" * 8, b"\x00" * 8) is not None:
        return "cryptography"
    return "pure-python"


def generate_legacy_racf_des_hash(userid: str, password: str) -> str:
    """Return the uppercase legacy RACF DES hash hex for userid/password.

    Byte-exact with ``john --format=racf``. Uses a C DES provider when present,
    otherwise the bundled pure-Python DES - never a non-DES substitute.
    """
    uid = (userid or "").upper()[:8]
    if not uid:
        raise ValueError("userid is required")
    key = _password_key(password or "")
    return _des_encrypt(key, _ebcdic8(uid)).hex().upper()


def format_john_racf_hash(userid: str, hash_hex: str) -> str:
    uid = (userid or "").upper()[:8]
    hx = (hash_hex or "").upper().strip()
    return f"{uid}:$racf$*{uid}*{hx}"


def verify_legacy_racf_des_hash(userid: str, candidate: str, hash_hex: str) -> bool:
    try:
        return generate_legacy_racf_des_hash(userid, candidate) == (hash_hex or "").upper().strip()
    except Exception:
        return False


# --------------------------------------------------------------------------- #
#  Known-answer self-test - CRACF ground-truth vectors (verified vs a real     #
#  RACF DB). Call at DB-build time so a broken crypto path fails LOUD instead  #
#  of writing uncrackable hashes.                                              #
# --------------------------------------------------------------------------- #
# (userid, password, expected legacy RACF DES hash)
RACF_KNOWN_ANSWER_VECTORS = (
    ("A", "A", "0F7DE80335E8ED68"),
    ("TESTTEST", "TESTTEST", "0FF48804F759193F"),
    ("AAAAAAAA", "AAAAAAAA", "062314297C496E0E"),
)


def selftest() -> None:
    """Raise RuntimeError unless the live DES path reproduces every known vector."""
    for uid, pw, expected in RACF_KNOWN_ANSWER_VECTORS:
        got = generate_legacy_racf_des_hash(uid, pw)
        if got != expected:
            raise RuntimeError(
                "RACF DES self-test FAILED "
                f"({uid}/{pw}: got {got}, expected {expected}); "
                f"provider={des_provider()}. Refusing to emit non-DES hashes."
            )


if __name__ == "__main__":  # quick manual check: python -m gibson.core.racf_legacy_des
    selftest()
    print(f"RACF DES self-test OK (provider={des_provider()})")
    for _uid, _pw, _ in RACF_KNOWN_ANSWER_VECTORS:
        print(f"  {_uid}/{_pw} -> {generate_legacy_racf_des_hash(_uid, _pw)}")
