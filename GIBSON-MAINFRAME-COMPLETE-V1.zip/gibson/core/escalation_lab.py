"""A hands-on privilege-escalation lab.

Seeds a realistic, discoverable finding: an automation started task, **AUTOMON**,
that runs under a RACF id (**AUTOOPER**) which has been granted the **OPERATIONS**
attribute - a classic real-world misconfiguration ("we gave the automation id
OPERATIONS to make it work").  A started task with OPERATIONS can read or alter
almost any data set, so anyone who can influence that task - by writing to its
PROCLIB member, for example - inherits that power.

Once set up, the finding surfaces through every tool the learner has:
  D STARTED                    -> flags AUTOMON as privileged
  ZSEC CARLA STCRISK           -> lists AUTOMON / AUTOOPER
  ZSEC CKFREEZE STC            -> RISK=YES on AUTOMON
  ZSEC STIG   (control ACP00294) -> FAIL, lowering the compliance score

The learner remediates with a single RACF command:
  ALTUSER AUTOOPER NOOPERATIONS
after which every check above clears - a complete discover -> understand ->
remediate -> verify loop.
"""
from __future__ import annotations

from typing import Any

LAB_OWNER = "AUTOOPER"
LAB_STC = "AUTOMON"


def is_active(state: Any) -> bool:
    return bool(getattr(state, "_escalation_lab", False))


def setup(state: Any) -> str:
    r = state.racf
    try:
        if r.get(LAB_OWNER) is None:
            r.adduser(LAB_OWNER, password="AUT0MAT3", default_group="STCGROUP")
            u = r.get(LAB_OWNER)
            if u is not None:
                u.name = "AUTOMATION SERVER STC ID"
        r.altuser(LAB_OWNER, attr_changes={"OPERATIONS": True})
    except Exception:
        pass
    # mirror into the CARLa store so TYPE=RACF queries see it too
    try:
        from gibson.apps.racf_admin import get_racf_store
        st = get_racf_store(state)
        st.users[LAB_OWNER] = {"USERID": LAB_OWNER, "NAME": "AUTOMATION SERVER STC ID",
                               "DFLTGRP": "STCGROUP", "ATTRS": {"OPERATIONS"},
                               "OMVS": {"UID": ""}, "TSO": {}, "CICS": {},
                               "MFA": {"ENABLED": "N"}, "REVOKED": "N"}
        st.groups.setdefault("STCGROUP", set()).add(LAB_OWNER)
    except Exception:
        pass
    # STARTED-class profile mapping AUTOMON.* -> AUTOOPER
    try:
        prof = getattr(state.dynamic_racf, "profiles", {}).setdefault("STARTED", {})
        prof["AUTOMON.*"] = type("P", (), {"attrs": {"USER": LAB_OWNER, "GROUP": "STCGROUP",
                                                     "TRUSTED": "NO"}})()
    except Exception:
        pass
    state._escalation_lab = True
    return guide(state)


def teardown(state: Any) -> str:
    state._escalation_lab = False
    try:
        state.racf.altuser(LAB_OWNER, attr_changes={"OPERATIONS": False})
    except Exception:
        pass
    try:
        from gibson.apps.racf_admin import get_racf_store
        get_racf_store(state).users.pop(LAB_OWNER, None)
    except Exception:
        pass
    return "ESCALATION LAB RESET - AUTOMON removed and AUTOOPER de-privileged."


def status(state: Any) -> str:
    from gibson.core.address_spaces import started_task_identities
    active = is_active(state)
    risky = [r for r in started_task_identities(state) if r["risk"]]
    L = [f"ESCALATION LAB STATUS: {'ACTIVE' if active else 'NOT SET UP'}", ""]
    if not active:
        L.append("Run  ZSEC LAB SETUP  to seed the scenario.")
        return "\n".join(L)
    if risky:
        L.append("FINDING PRESENT - privileged started tasks detected:")
        for r in risky:
            L.append(f"  {r['jobname']:<8} runs under {r['owner']} ({', '.join(r['risk'])})")
        L.append("")
        L.append("The finding is still open.  Remediate with:  ALTUSER AUTOOPER NOOPERATIONS")
    else:
        L.append("REMEDIATED - no started task runs with SPECIAL/OPERATIONS/UID(0).")
        L.append("Well done.  Run  ZSEC STIG  and watch control ACP00294 now PASS.")
    return "\n".join(L)


def guide(state: Any) -> str:
    return "\n".join([
        "ESCALATION LAB - PRIVILEGED STARTED TASK",
        "=" * 60,
        "Scenario seeded.  A started task AUTOMON now runs under the RACF id",
        "AUTOOPER, which holds the OPERATIONS attribute.",
        "",
        "STEP 1 - FIND IT.  Try any of:",
        "   D STARTED                 (operator view + privilege review)",
        "   ZSEC CARLA STCRISK        (CARLa query of privileged STCs)",
        "   ZSEC CKFREEZE STC         (the CKFREEZE snapshot, RISK column)",
        "   ZSEC STIG                 (control ACP00294 now FAILs)",
        "",
        "STEP 2 - UNDERSTAND IT.  A started task with OPERATIONS can access",
        "   almost any data set.  Whoever can write to its PROCLIB member, or",
        "   otherwise influence the task, inherits that authority.",
        "",
        "STEP 3 - REMEDIATE.  Remove the excess privilege:",
        "   ALTUSER AUTOOPER NOOPERATIONS",
        "",
        "STEP 4 - VERIFY.  Re-run the checks above - the finding clears and the",
        "   STIG compliance score rises.  Or  ZSEC LAB STATUS  to confirm.",
        "",
        "Reset the lab at any time with:  ZSEC LAB RESET",
    ])
