"""ACF2 HELP facility - same depth and format as GIBSON's RACF/TSO HELP.

Reuses the SYS1.HELP-member renderer from ``tso_help`` so ``HELP command``,
``command HELP``, ``HELP command SYNTAX|OPERANDS|FUNCTION`` and ``?`` all produce the
authentic z/OS help layout, but for ACF2 commands. Training content only.
"""
from __future__ import annotations

from typing import Optional

from gibson.apps.tso_help import HelpMember, _syntax, _render_member


ACF2_MEMBERS = {
    "SET": HelpMember(
        function="The SET (or T) command selects the ACF2 command setting that "
                 "subsequent commands operate on: LID for logonids, RULE for data set "
                 "access rules, RESOURCE for resource rules, CONTROL for GSO records, "
                 "and PROFILE for segment profiles.",
        syntax=_syntax("SET", ["LID | RULE | RESOURCE(type) | CONTROL(GSO)",
                               "PROFILE(GROUP) DIV(OMVS)"]),
        required="a setting", defaults="LID", aliases="T",
        operands=[
            ("LID", "Process logonid records (INSERT/CHANGE/LIST/DELETE)."),
            ("RULE", "Process data set access rule sets, keyed by $KEY (the HLQ)."),
            ("RESOURCE(type)", "Process resource rules for a 3-character type (mapped from a class)."),
            ("CONTROL(GSO)", "Process/display Global System Option records."),
            ("PROFILE(GROUP) DIV(OMVS)", "Process the OMVS division of group profiles."),
        ]),
    "LIST": HelpMember(
        function="The LIST command displays entries for the current setting: a full "
                 "logonid record in LID mode, a compiled rule set in RULE/RESOURCE "
                 "mode, or a group profile. LIKE(mask) lists many; UID(mask) lists "
                 "logonids by UID string.",
        syntax=_syntax("LIST", ["logonid | LIKE(mask) | UID(mask)", "$KEY(key)"]),
        required="a logonid, mask, or key", defaults="the current logonid",
        operands=[
            ("logonid", "List one logonid's full record (privileges, TSO/OMVS segments, statistics)."),
            ("LIKE(mask)", "List all logonids whose id matches the mask (- is the wildcard)."),
            ("UID(mask)", "List logonids whose UID string matches the mask."),
            ("$KEY(key)", "In RULE/RESOURCE mode, decompile and display the rule set for a key."),
        ]),
    "INSERT": HelpMember(
        function="The INSERT command defines a new logonid (LID mode) or stores a new "
                 "rule set (RULE/RESOURCE mode). In LID mode it accepts the full set of "
                 "ACF2 privilege, facility, TSO, and OMVS fields.",
        syntax=_syntax("INSERT", ["logonid PASSWORD(pw) [privileges] [fields]",
                                  "$KEY(key)  (in RULE/RESOURCE mode)"]),
        required="a logonid or key", defaults="NONE",
        operands=[
            ("PASSWORD(pw)", "Initial password for the logonid."),
            ("SECURITY | ACCOUNT | AUDIT | LEADER", "Privilege attributes to grant."),
            ("NON-CNCL", "Bypass rule validation (the ACF2 equivalent of unrestricted)."),
            ("TSO | CICS | JOB | STC | OPERATOR", "Facility privileges."),
            ("GROUP(grp) UID(n)", "Default group and OMVS UID number."),
            ("TSOACCT(a) TSOPROC(p)", "TSO segment fields."),
            ("HOME(path) OMVSPGM(pgm)", "OMVS segment fields."),
        ]),
    "CHANGE": HelpMember(
        function="The CHANGE command alters an existing logonid or rule set. Boolean "
                 "privileges are set by naming them and cleared with the NO- prefix "
                 "(e.g. NO-ACCOUNT). Valued fields are set as field(value).",
        syntax=_syntax("CHANGE", ["logonid [field | NO-field] ...",
                                  "$KEY(key)  (in RULE/RESOURCE mode)"]),
        required="a logonid or key", defaults="NONE",
        operands=[
            ("field", "Set a privilege or facility (e.g. AUDIT, OPERATOR)."),
            ("NO-field", "Clear a privilege or facility (e.g. NO-ACCOUNT, NOSECURITY)."),
            ("SUSPEND | NO-SUSPEND", "Suspend or resume the logonid."),
            ("field(value)", "Set a valued field (e.g. GROUP(SYS1), SHIFT(DAYONLY))."),
        ]),
    "DELETE": HelpMember(
        function="The DELETE command removes the current-setting entry: a logonid, a "
                 "rule set, or a group profile.",
        syntax=_syntax("DELETE", ["logonid | key"]),
        required="an entry name", defaults="NONE", operands=[]),
    "RECKEY": HelpMember(
        function="The RECKEY command adds or replaces a rule line in the rule set for a "
                 "key without recompiling the whole set. Each rule line grants access "
                 "to a UID mask.",
        syntax=_syntax("RECKEY", ["key ADD(UID(mask) R(A) W(A) ... [NEXTKEY(k)])"]),
        required="a key and ADD(...)", defaults="PREVENT for unlisted access",
        operands=[
            ("key", "The $KEY the rule line belongs to (HLQ or resource)."),
            ("UID(mask)", "The UID-string mask the line applies to (- matches all)."),
            ("R/W/A/E(A|L|P)", "Per-access permission: A allow, L allow+log, P prevent."),
            ("NEXTKEY(key)", "Chain evaluation to another rule set."),
        ]),
    "COMPILE": HelpMember(
        function="The COMPILE command compiles ACF2 rule source (a $KEY line followed "
                 "by UID rule lines) into a stored rule set. Use STORE to save it.",
        syntax=_syntax("COMPILE", ["* (then enter $KEY(...) and UID(...) lines)"]),
        required="rule source", defaults="NONE", operands=[]),
    "DECOMP": HelpMember(
        function="The DECOMP command decompiles a stored rule set back into ACF2 rule "
                 "source for the given key.",
        syntax=_syntax("DECOMP", ["$KEY(key) | key"]),
        required="a key", defaults="NONE", operands=[]),
    "ACCESS": HelpMember(
        function="The ACCESS command shows which rule lines in the matching rule set "
                 "apply to a data set or resource - the compiled access picture.",
        syntax=_syntax("ACCESS", ["DSNAME('dsn') | RESOURCE(name) TYPE(type)"]),
        required="a data set or resource", defaults="NONE", operands=[]),
    "TEST": HelpMember(
        function="The TEST command evaluates the access rules for a logonid against a "
                 "data set or resource and a service, reporting ALLOW, LOG, or PREVENT. "
                 "It uses the logonid's UID string and evaluates deny-by-default.",
        syntax=_syntax("TEST", ["DSNAME('dsn') LID(logonid) SERVICE(READ|WRITE|ALLOC|EXEC)",
                                "RSRCNAME('name') LID(logonid) SERVICE(READ)"]),
        required="a data set or resource", defaults="SERVICE(READ), LID(current)",
        operands=[
            ("DSNAME('dsn')", "The data set to test access against."),
            ("RSRCNAME('name')", "The resource to test (in RESOURCE mode)."),
            ("LID(logonid)", "The logonid whose UID string is evaluated."),
            ("SERVICE(svc)", "The access being tested: READ, WRITE, ALLOC, or EXEC."),
        ]),
    "SHOW": HelpMember(
        function="The SHOW command displays ACF2 system information: SHOW ACF2 (state "
                 "and modes), SHOW MODE, SHOW TSO, SHOW PSWD (password options), SHOW "
                 "DDSN (active data sets), SHOW OMVS, and more.",
        syntax=_syntax("SHOW", ["ACF2 | MODE | STATE | TSO | PSWD | DDSN | OMVS | GSO",
                                "CLASMAP | FIELDS | SYSTEMS | ACTIVE | PROGRAMS | LINKLST"]),
        required="a subcommand", defaults="NONE", operands=[]),
    "ACFRPT": HelpMember(
        function="The ACFRPTxx report generators summarise the ACF2 SMF trail: "
                 "ACFRPTPW (password/logon activity and violations), ACFRPTRV (resource "
                 "and access-rule violations), ACFRPTDS (data set access), and ACFRPTLL "
                 "(a logonid listing with UID strings and privileges).",
        syntax=_syntax("ACFRPTxx", ["ACFRPTPW | ACFRPTRV | ACFRPTDS | ACFRPTLL"]),
        required="a report name", defaults="NONE",
        operands=[
            ("ACFRPTPW", "Invalid password / authority log (logon activity)."),
            ("ACFRPTRV", "Resource and access-rule violations."),
            ("ACFRPTDS", "Data set access events."),
            ("ACFRPTLL", "Logonid listing with UID string and privileges."),
        ]),
    "XREF": HelpMember(
        function="XREF scope lists implement decentralised (scoped) administration. A "
                 "scope list names the logonids (XREF LID), resources (XREF RES), or "
                 "roles (XREF ROL) that a scoped administrator may control. SET "
                 "XREF(kind), then INSERT a scope id with entry masks.",
        syntax=_syntax("XREF", ["SET XREF(LID|RES|ROL)",
                                "INSERT scopeid mask [mask ...]", "LIST | LIST scopeid"]),
        required="a kind and scope id", defaults="unrestricted when no scope lists exist",
        operands=[
            ("scopeid", "Owner of the scope (a group or logonid)."),
            ("mask", "An entry mask the scope covers (- matches the rest)."),
        ]),
}

# aliases -> canonical
_ALIASES = {"T": "SET", "LIS": "LIST", "INS": "INSERT", "CHA": "CHANGE",
            "DEL": "DELETE", "DECOMPILE": "DECOMP",
            "ACFRPTPW": "ACFRPT", "ACFRPTRV": "ACFRPT", "ACFRPTDS": "ACFRPT",
            "ACFRPTLL": "ACFRPT"}


def _overview() -> str:
    lines = [
        "ACF2 COMMAND HELP",
        "  Enter  HELP command  or  command ?  for help on a specific command.",
        "  Enter  HELP command SYNTAX | OPERANDS | FUNCTION  to limit the display.",
        "  PF1 requests HELP for the command on the input line.",
        "",
        "Commands -",
    ]
    order = ["SET", "LIST", "INSERT", "CHANGE", "DELETE", "RECKEY", "COMPILE",
             "DECOMP", "ACCESS", "TEST", "SHOW"]
    blurbs = {
        "SET": "select the command setting (LID/RULE/RESOURCE/CONTROL/PROFILE)",
        "LIST": "display logonids, rule sets, or group profiles",
        "INSERT": "define a logonid or store a rule set",
        "CHANGE": "alter a logonid or rule set",
        "DELETE": "remove a logonid, rule set, or group profile",
        "RECKEY": "add a rule line to a key",
        "COMPILE": "compile rule source into a rule set",
        "DECOMP": "decompile a stored rule set",
        "ACCESS": "show the rule lines applying to a data set/resource",
        "TEST": "evaluate access for a logonid (ALLOW/LOG/PREVENT)",
        "SHOW": "display ACF2 options and state",
    }
    for c in order:
        lines.append(f"  {c:<10} {blurbs[c]}")
    lines.append("")
    lines.append("  END | QUIT   reset the setting to LID    RACF   return to RACF mode")
    return "\n".join(lines)


def acf2_help(argument: str = "") -> Optional[str]:
    """Return ACF2 help text, or None if not a documented ACF2 command."""
    arg = (argument or "").strip()
    if not arg:
        return _overview()
    tokens = arg.split()
    cmd = tokens[0].upper()
    section = None
    operand_kw = None
    for t in tokens[1:]:
        tu = t.upper()
        if tu.startswith("OPERANDS(") and tu.endswith(")"):
            section, operand_kw = "OPERANDS", tu[len("OPERANDS("):-1]
        elif tu in ("FUNCTION", "SYNTAX", "OPERANDS", "ALL"):
            section = None if tu == "ALL" else tu
    canonical = cmd if cmd in ACF2_MEMBERS else _ALIASES.get(cmd)
    if not canonical:
        return None
    return _render_member(canonical, ACF2_MEMBERS[canonical], section, operand_kw)
