# PHOSPHOR live-host smoke tests

These confirm, on real hardware, the paths that are currently validated against pcaps,
njelib, or GIBSON but **not yet against a live zPDT / z/OS host**. Run them from your
Kali/Pi with PHOSPHOR checked out. Everything here is read-only unless explicitly marked
DESTRUCTIVE, and the destructive steps need `--i-have-authorization`.

    python3 tools/smoketest.py --help

Legend: **PASS** works on the metal · **FAIL** broke (capture + send pcap) ·
**UNCONF** needs your eyes to confirm · **SKIP** not run.

## Batch mode - run everything at once

Each service is on a different port, so the easiest way to run the whole battery is a
config file. Copy the example, edit host/ports/creds, and run one command:

    cp tools/smoke.conf.example tools/smoke.conf
    # edit tools/smoke.conf
    python3 tools/smoketest.py --config tools/smoke.conf

Only the sections you keep in the file are run, each on its own host/port, with one
consolidated PASS/FAIL/UNCONF summary at the end. Delete a section to skip that service.
(Destructive steps like NJE `submit =` still also require `--i-have-authorization`.)

Without a config, `--all` runs every suite against `--host` using default ports
(23/992/175/446) - handy for a quick single-host sweep:

    python3 tools/smoketest.py --host <HOST> --all --no-verify

Run the individual suites below when you want to focus on one.

---

## 1. TN3270 + TLS / AT-TLS
What it confirms: telnet negotiation, model geometry, and TLS/AT-TLS + STARTTLS wrapping
against a real stack.

    python3 tools/smoketest.py --host <MVS> --tn3270 --model 2
    python3 tools/smoketest.py --host <MVS> --tn3270 --tls --no-verify --port 992
    python3 tools/smoketest.py --host <MVS> --tn3270 --starttls --no-verify

Expect PASS with BINARY/EOR/TTYPE negotiated and a non-blank screen. For TLS, the line
shows the negotiated version/cipher and whether the cert verified.

## 2. TN5250 single-ENTER  (the double-ENTER fix)
What it confirms: the pub400/IBM i fix so a single ENTER advances the screen.

    python3 tools/smoketest.py --host <IBMi> --tn5250 --port 992 --tls --no-verify

Reports whether the screen changed after ONE enter. This one is **UNCONF by design** -
eyeball it: one ENTER should advance the panel, not two. If it needs two, capture and send.

## 3. NJE recon + NMR reply  (the unconfirmed round-trip)
What it confirms: OPEN-probe reason codes, node sign-on, and - the key gap - that an
operator command (NMR) gets a **reply** back over a live JES2 session (the FCS the host
negotiates at sign-on).

    python3 tools/smoketest.py --host <JES2> --nje --nje-nodes NODEA,NODEB,POK \
        --nje-signon NODEA:MYNODE:nodepass --nje-cmd '$D NODE'

Expect PASS on OPEN/signon. The NMR line is **UNCONF** until a real host replies: if the
reply is empty, the host negotiated a different FCS at sign-on - capture the pcap so the
FCS can be wired in.

DESTRUCTIVE (submit a job that runs on the target, e.g. the RACF-backdoor JCL):

    python3 tools/smoketest.py --host <JES2> --nje \
        --nje-submit NODEA:MYNODE:nodepass:IBMUSER:id --i-have-authorization

## 4. DB2 DRDA fingerprint / credentials / result set  (FD:OCA on the metal)
What it confirms: EXCSAT fingerprint, SECCHK credential check, and native OPNQRY result
sets - including which column types decode correctly.

    python3 tools/smoketest.py --host <DB2> --port 446 --drda \
        --user IBMUSER --pass <pw> --rdb <LOCATION> \
        --sql 'SELECT NAME, CREATOR FROM SYSIBM.SYSTABLES FETCH FIRST 5 ROWS ONLY'

Expect PASS on fingerprint + credential check. The result-set line is **UNCONF** if the
query returns columns whose types PHOSPHOR's FD:OCA decoder doesn't yet cover (DECIMAL,
DATE/TIME, packed). For those, cross-check against `ibm_db` and send a pcap - that's the
data needed to extend the decoder. String/integer columns should just work.

## 5. PassTicket generation (offline)
    python3 tools/smoketest.py --ptkt IBMUSER:CICSPA01:<KEYHEX16>

Prints the ticket and the +/-1s window. To confirm end-to-end, log on to the application
with the generated ticket within +/-10 minutes of the host's GMT clock.

---

## When something FAILs or is UNCONF

Capture the exact exchange and send it back:

    sudo bash tools/capture.sh <host> <port>     # writes /tmp/phosphor-smoke-<port>.pcap
    # re-run the failing smoke test in another terminal while it captures

The pcap contains only that session's traffic to that host/port. With it, the specific
wire difference (FCS, FD:OCA type, negotiation quirk) can be fixed the same way the
tn3270 / tn5250 captures were.
