#!/usr/bin/env python3
"""PHOSPHOR live-host smoke tests.

Run this from your Kali/Pi against a real zPDT / z/OS host to confirm the paths that
are validated against pcaps / njelib / GIBSON but not yet against the metal.  It drives
PHOSPHOR's own modules, so a PASS means the real code path works on your host.

Read-only by default (connect, negotiate, fingerprint, OPEN-probe, a harmless SELECT).
The steps that change state on the target (NJE job submission, credential spray) only run
when you pass --i-have-authorization AND the specific flag, and they say so loudly.

Examples
  # TN3270 + TLS reachability and screen
  python3 tools/smoketest.py --host 192.168.0.96 --tn3270 --model 2
  python3 tools/smoketest.py --host mvs --port 992 --tn3270 --tls --no-verify

  # NJE recon + the NMR reply round-trip (the unconfirmed bit)
  python3 tools/smoketest.py --host 192.168.0.96 --nje --nje-nodes GIBSON,HAL,POK \
      --nje-signon GIBSON:HAL:GIBSONPW --nje-cmd '$D NODE'

  # DB2 DRDA fingerprint, credential check, and a real result set (FD:OCA decode)
  python3 tools/smoketest.py --host 192.168.0.96 --port 50000 --drda \
      --user IBMUSER --pass SYS1 --rdb GIBSONDB2 --sql 'SELECT NAME,CREATOR FROM SYSIBM.SYSTABLES'

  # PassTicket generation (offline)
  python3 tools/smoketest.py --ptkt IBMUSER:CICSPA01:E001193519561977

If something FAILS, capture the exchange and send it over:
  sudo bash tools/capture.sh <host> <port>        # writes /tmp/phosphor-smoke.pcap
"""
import argparse, os, sys, time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

_R = {"PASS": "\033[32m", "FAIL": "\033[31m", "SKIP": "\033[33m",
      "UNCONF": "\033[36m", "": "\033[0m"}
_results = []

def emit(status, name, detail="", tip=""):
    _results.append(status)
    c = _R.get(status, ""); z = _R[""]
    print(f"  [{c}{status:^6}{z}] {name}")
    if detail:
        for ln in str(detail).splitlines():
            print(f"           {ln}")
    if tip and status == "FAIL":
        print(f"           -> {tip}")


# ---------------------------------------------------------------- TN3270 / TLS
def check_tn3270(a):
    from phosphor.protocols.tn3270.client import client_for_model
    try:
        c = client_for_model(a.model)
        c.read_timeout = a.timeout
        kw = {}
        if a.tls:
            kw = dict(tls=True, tls_verify=not a.no_verify)
        elif a.starttls:
            kw = dict(tls_starttls=True, tls_verify=not a.no_verify)
        c.connect(a.host, a.port, **kw)
        neg = c.neg
        ready = neg.ready()
        rows = c.screen_get()
        nonblank = sum(1 for r in rows if r.strip())
        tls = getattr(c, "tls_info", None)
        detail = (f"device={neg.device_type} tn3270e={neg.tn3270e} "
                  f"BINARY={neg.local_binary}/{neg.remote_binary} EOR={neg.local_eor}/{neg.remote_eor}\n"
                  f"screen {len(rows)} rows, {nonblank} non-blank; first: {rows[0][:60] if rows else '(none)'!r}")
        if tls and tls.active:
            detail += f"\nTLS: {tls.summary()} peer_cn={tls.peer_cn}"
        emit("PASS" if (ready and nonblank) else "FAIL", "tn3270 connect + negotiate", detail,
             "host reachable? right port? try --model 2 and --port 23 (or 992 for TLS)")
    except Exception as e:
        emit("FAIL", "tn3270 connect + negotiate", repr(e),
             "connection refused/timeout -> check host/port/firewall")


def check_tls(a):
    # TLS is covered inside check_tn3270 when --tls/--starttls is set; this is a
    # standalone TLS-only reachability report.
    from phosphor.protocols import tls as T
    import socket
    try:
        raw = socket.create_connection((a.host, a.port), a.timeout)
        info = T.TLSInfo()
        T.wrap_socket(raw, a.host, verify=not a.no_verify, info=info)
        raw.close()
        emit("PASS", "TLS handshake", f"{info.summary()} peer_cn={info.peer_cn}"
             + ("" if info.verified else "  (cert NOT verified - testing mode)"))
    except Exception as e:
        emit("FAIL", "TLS handshake", repr(e),
             "wrong port for TLS? mainframe AT-TLS is often :992; add --no-verify for self-signed")


# ------------------------------------------------------------------- TN5250
def check_tn5250(a):
    from phosphor.protocols.tn5250.client import TN5250Client
    try:
        c = TN5250Client(); c.read_timeout = a.timeout
        c.connect(a.host, a.port, tls=a.tls, tls_verify=not a.no_verify)
        before = c.screen.text()
        c.send_enter()
        after = c.screen.text()
        advanced = before.strip() != after.strip()
        emit("UNCONF" if not advanced else "PASS", "tn5250 single-ENTER",
             f"enhanced={c.enhanced}  screen changed after ONE enter: {advanced}\n"
             f"(confirm by eye: the screen should advance on a single ENTER, not two)",
             )
    except Exception as e:
        emit("FAIL", "tn5250 connect", repr(e), "IBM i / 5250 host reachable on this port?")


# ---------------------------------------------------------------------- NJE
def check_nje(a):
    from phosphor.toolchain import nje as N
    nodes = [n.strip() for n in (a.nje_nodes or "").split(",") if n.strip()] or N.COMMON_NODES
    rhost = a.nje_rhost or "FAKE"
    try:
        found = 0
        for name in nodes:
            r = N.open_probe(a.host, name, rhost=rhost, port=a.port or N.NJE_PORT,
                             tls=a.tls, timeout=a.timeout)
            if r.reason in (N.R_OK, N.R_BAD_RHOST):
                found += 1
                tag = "ACK-trusted" if r.reason == N.R_OK else "exists"
                emit("PASS", f"NJE OPEN {name}", f"{tag}  " + "; ".join(r.findings))
            elif r.error:
                emit("FAIL", f"NJE OPEN {name}", r.error, "port 175 open? correct NJE port?")
        if not found:
            emit("UNCONF", "NJE node discovery", "no known nodes replied ACK/0x04 - "
                 "try real node names via --nje-nodes")
    except Exception as e:
        emit("FAIL", "NJE OPEN probe", repr(e))

    if a.nje_signon:
        try:
            oh, rh, pw = (a.nje_signon.split(":") + ["", ""])[:3]
            r = N.signon_test(a.host, oh, rh or rhost, pw, port=a.port or N.NJE_PORT,
                              tls=a.tls, timeout=a.timeout)
            emit("PASS" if r.signon_ok else "FAIL", f"NJE signon {oh}",
                 "; ".join(r.findings) or f"signon_ok={r.signon_ok}")
            if r.signon_ok and a.nje_cmd:
                rc = N.send_command(a.host, oh, rh or rhost, a.nje_cmd, password=pw,
                                    port=a.port or N.NJE_PORT, tls=a.tls, timeout=a.timeout)
                got_reply = any("reply:" in f for f in rc.findings)
                emit("PASS" if got_reply else "UNCONF", f"NJE NMR '{a.nje_cmd}'",
                     "\n".join(rc.findings),
                     )
                if not got_reply:
                    print("           -> empty reply: the host likely negotiated a different FCS at")
                    print("              signon. Capture it (tools/capture.sh) and send the pcap.")
        except Exception as e:
            emit("FAIL", "NJE signon/command", repr(e))

    if a.nje_submit:
        if not a.authorized:
            emit("SKIP", "NJE job submission", "destructive - re-run with --i-have-authorization")
        else:
            try:
                oh, rh, pw, runas, key = (a.nje_submit.split(":") + [""]*5)[:5]
                jcl = N.bundled_jcl().get(key, key)
                if os.path.isfile(jcl):
                    jcl = open(jcl).read()
                r = N.submit_job(a.host, oh, rh or rhost, jcl, password=pw,
                                 userid=runas or "IBMUSER", port=a.port or N.NJE_PORT,
                                 tls=a.tls, timeout=a.timeout)
                emit("PASS" if r.signon_ok else "FAIL", "NJE job submission (DESTRUCTIVE)",
                     "\n".join(r.findings))
            except Exception as e:
                emit("FAIL", "NJE job submission", repr(e))


# --------------------------------------------------------------------- DRDA
_SAFE_TYPES = {448, 452, 500, 496}   # CHAR/VARCHAR/SMALLINT/INTEGER decode is validated
def check_drda(a):
    from phosphor.protocols.drda import client as D
    try:
        r = D.probe(a.host, a.port or 446, userid=a.user or "", password=a.pw or "",
                    rdbnam=a.rdb or "", tls=a.tls, timeout=a.timeout)
        if not r.reachable:
            emit("FAIL", "DRDA reach", r.error or "unreachable", "is DDF up? port 446 (or 50000)?")
            return
        if not r.is_drda:
            emit("FAIL", "DRDA fingerprint", r.error or "no EXCSATRD",
                 "not a DRDA listener on this port")
            return
        emit("PASS", "DRDA fingerprint",
             f"{r.srvclsnm} {r.srvrlslv} location={r.srvnam}")
        if a.user:
            emit("PASS" if r.auth_ok else "FAIL", "DRDA credential check",
                 f"{a.user}: {'ACCEPTED' if r.auth_ok else r.secchk_text()}")
        if a.user and a.sql:
            sess = D.DrdaSession(a.host, a.port or 446, tls=a.tls, timeout=a.timeout)
            sess.open()
            ok, msg = sess.login(a.user, a.pw or "", a.rdb or "")
            if not ok:
                emit("FAIL", "DRDA SQL login", msg); return
            cols, rows = sess.query(a.sql)
            sess.close()
            risky = [c[0] for c in cols if c[1] not in _SAFE_TYPES]
            status = "PASS" if rows and not risky else ("UNCONF" if risky else "PASS")
            detail = f"{len(cols)} cols, {len(rows)} rows; sample: {rows[0] if rows else '(none)'}"
            if risky:
                detail += (f"\ncolumns with types PHOSPHOR's FD:OCA decoder does NOT yet "
                           f"confirm (DECIMAL/DATE/etc.): {risky}\n"
                           f"cross-check these against ibm_db; send a pcap if they look wrong")
            emit(status, "DRDA result set (FD:OCA)", detail)
    except Exception as e:
        emit("FAIL", "DRDA", repr(e))


# ----------------------------------------------------------------- PassTicket
def check_ptkt(a):
    from phosphor.toolchain import passticket as PT
    try:
        user, applid, key = a.ptkt.split(":")
        t = PT.generate_passticket(user, applid, key)
        win = PT.passticket_window(user, applid, key, spread=1)
        emit("PASS", "PassTicket generate",
             f"{user}/{applid} -> {t}\nwindow: " + ", ".join(f"t{o:+d}={x}" for o, x in win)
             + "\n(offline; test it by logging on to the app within +/-10 min of host GMT)")
    except Exception as e:
        emit("FAIL", "PassTicket generate", repr(e), "format: --ptkt USER:APPLID:KEYHEX16")


def _load_config(path):
    """Read an INI config so the whole battery can run from one file (batch mode).
    Sections: [default] [tn3270] [tls] [tn5250] [nje] [drda] [passticket]."""
    import configparser
    cp = configparser.ConfigParser()
    if not cp.read(path):
        raise SystemExit(f"config not found: {path}")
    return {sec: dict(cp.items(sec)) for sec in cp.sections()}


def _suite_args(base, cfg, section, default_port):
    """Clone the global args, overlay [default] then [section] from the config."""
    import argparse, copy
    ns = copy.copy(base)
    merged = {}
    merged.update(cfg.get("default", {}))
    merged.update(cfg.get(section, {}))
    def b(v): return str(v).strip().lower() in ("1", "true", "yes", "on")
    if "host" in merged: ns.host = merged["host"]
    ns.port = int(merged.get("port", base.port or default_port))
    if "timeout" in merged: ns.timeout = float(merged["timeout"])
    if "model" in merged: ns.model = merged["model"]
    for flag in ("tls", "starttls", "no_verify"):
        if flag in merged: setattr(ns, flag, b(merged[flag]))
    # per-suite fields
    m = {"nodes": "nje_nodes", "rhost": "nje_rhost", "signon": "nje_signon",
         "cmd": "nje_cmd", "submit": "nje_submit", "user": "user", "pass": "pw",
         "rdb": "rdb", "sql": "sql", "spec": "ptkt"}
    for k, attr in m.items():
        if k in merged:
            setattr(ns, attr, merged[k])
    return ns


def main():
    p = argparse.ArgumentParser(description="PHOSPHOR live-host smoke tests")
    p.add_argument("--host"); p.add_argument("--port", type=int, default=0)
    p.add_argument("--timeout", type=float, default=8.0)
    p.add_argument("--tls", action="store_true"); p.add_argument("--starttls", action="store_true")
    p.add_argument("--no-verify", action="store_true")
    p.add_argument("--model", default="2")
    p.add_argument("--tn3270", action="store_true"); p.add_argument("--tls-only", action="store_true")
    p.add_argument("--tn5250", action="store_true")
    p.add_argument("--nje", action="store_true")
    p.add_argument("--nje-nodes"); p.add_argument("--nje-rhost")
    p.add_argument("--nje-signon"); p.add_argument("--nje-cmd")
    p.add_argument("--nje-submit")
    p.add_argument("--drda", action="store_true")
    p.add_argument("--user"); p.add_argument("--pass", dest="pw"); p.add_argument("--rdb"); p.add_argument("--sql")
    p.add_argument("--ptkt")
    p.add_argument("--config", help="INI file: run every section it defines (batch mode)")
    p.add_argument("--all", dest="run_all", action="store_true",
                   help="run every suite against --host using default ports")
    p.add_argument("--i-have-authorization", dest="authorized", action="store_true")
    a = p.parse_args()

    print("\nPHOSPHOR smoke tests - authorised testing only\n" + "=" * 52)

    cfg = _load_config(a.config) if a.config else {}
    # which suites to run: config sections, or --all, or explicit flags
    want = {
        "tn3270": a.tn3270 or a.run_all or "tn3270" in cfg,
        "tls": a.tls_only or a.run_all or "tls" in cfg,
        "tn5250": a.tn5250 or a.run_all or "tn5250" in cfg,
        "nje": a.nje or a.run_all or "nje" in cfg,
        "drda": a.drda or a.run_all or "drda" in cfg,
        "ptkt": bool(a.ptkt) or "passticket" in cfg,
    }
    ports = {"tn3270": 992 if a.tls else 23, "tls": 992,
             "tn5250": 992 if a.tls else 23, "nje": 175, "drda": 446}

    def args_for(section, default_port):
        return _suite_args(a, cfg, section, default_port) if cfg else a

    if want["tn3270"]:
        sa = args_for("tn3270", ports["tn3270"])
        if not sa.port: sa.port = ports["tn3270"]
        check_tn3270(sa)
    if want["tls"]:
        sa = args_for("tls", ports["tls"])
        if not sa.port: sa.port = ports["tls"]
        check_tls(sa)
    if want["tn5250"]:
        sa = args_for("tn5250", ports["tn5250"])
        if not sa.port: sa.port = ports["tn5250"]
        check_tn5250(sa)
    if want["nje"]:
        sa = args_for("nje", ports["nje"])
        if not sa.port: sa.port = ports["nje"]
        check_nje(sa)
    if want["drda"]:
        sa = args_for("drda", ports["drda"])
        if not sa.port: sa.port = ports["drda"]
        check_drda(sa)
    if want["ptkt"]:
        sa = args_for("passticket", 0)
        if sa.ptkt: check_ptkt(sa)

    if not any(want.values()):
        p.print_help(); return

    print("=" * 52)
    for s in ("PASS", "FAIL", "UNCONF", "SKIP"):
        c = _results.count(s)
        if c:
            print(f"  {s}: {c}")
    print(f"  total checks: {len(_results)}")
    if "FAIL" in _results or "UNCONF" in _results:
        print("\n  For any FAIL/UNCONF, capture and send the pcap:")
        print("    sudo bash tools/capture.sh <host> <port>")
    sys.exit(1 if "FAIL" in _results else 0)


if __name__ == "__main__":
    main()
