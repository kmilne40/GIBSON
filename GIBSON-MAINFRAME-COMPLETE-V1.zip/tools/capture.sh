#!/usr/bin/env bash
# Capture a PHOSPHOR <-> host exchange so a failing smoke test can be diagnosed.
# Usage:  sudo bash tools/capture.sh <host> <port> [seconds]
# Then run the failing smoke test in another terminal while this is capturing.
set -u
HOST="${1:?usage: capture.sh <host> <port> [seconds]}"
PORT="${2:?usage: capture.sh <host> <port> [seconds]}"
SECS="${3:-60}"
OUT="/tmp/phosphor-smoke-${PORT}.pcap"

command -v tcpdump >/dev/null 2>&1 || { echo "tcpdump not installed: sudo apt install tcpdump"; exit 1; }

echo ">> capturing host $HOST port $PORT for ${SECS}s -> $OUT"
echo ">> now run the failing smoke test in another terminal"
timeout "$SECS" tcpdump -i any -s 0 -w "$OUT" "host $HOST and port $PORT" 2>/dev/null
echo ">> done: $OUT ($(du -h "$OUT" 2>/dev/null | cut -f1))"
echo ">> send that .pcap back for diagnosis (it contains only this session's traffic)."
