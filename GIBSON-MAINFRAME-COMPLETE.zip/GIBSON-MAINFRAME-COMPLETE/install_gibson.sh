#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/mfsim}"
SIM_ROOT="$DEFAULT_SIM_ROOT"
# The course packages are tested on Python 3.10 to 3.12, so one of those is
# preferred when it is installed beside a newer python3 (see require_python).
if [ -z "${PYTHON_BIN:-}" ]; then
  for _py in python3.12 python3.11 python3.10 python3; do
    command -v "$_py" >/dev/null 2>&1 && { PYTHON_BIN="$_py"; break; }
  done
fi
PYTHON_BIN="${PYTHON_BIN:-python3}"
MODE="venv"
VENV_DIR="${GIBSON_VENV_DIR:-$ROOT/.venv}"
UPGRADE_PIP=1
INSTALL_DEPS=1
WITH_WEB3270=0
PENTEST_TOOLS=""      # "" = ask once, 1 = install without asking, 0 = skip
MINIMAL=0             # 1 = GIBSON's core packages only, no course-tool packages

BLUE='\033[1;94m'
GREEN='\033[1;32m'
RED='\033[1;31m'
WHITE='\033[1;37m'
RESET='\033[0m'

say()  { printf '%b\n' "$*"; }
step() { say "${BLUE}==>${RESET} ${WHITE}$*${RESET}"; }
ok()   { say "${GREEN}[OK]${RESET} $*"; }
warn() { say "${RED}[!]${RESET} $*"; }

usage() {
  cat <<USAGE
Usage: ./install_gibson.sh [options]

Options:
  --venv              Install into $ROOT/.venv (default)
  --system            Install into the active/system Python instead of a venv
  --python PATH       Use a specific Python interpreter
  --sim-root PATH     Simulator root to seed (default: $DEFAULT_SIM_ROOT)
  --no-upgrade-pip    Skip pip/setuptools/wheel upgrades
  --skip-deps         Install Gibson without resolving Python dependencies
  --minimal           Install only GIBSON's core Python packages, without the
                      Pen-Test Shell course tools' packages (ezrecon, zniff,
                      cicspwn and the rest will then report NOT READY)
  --pentest-tools     Install the Pen-Test Shell's security tools (nmap, hydra,
                      nikto, wget, jumbo John) without asking
  --no-pentest-tools  Do not install them (run scripts/install-pentest-tools.sh later)
  --with-web3270      Also fetch/configure the web3270 browser-3270 add-on
                      (wren-creator/web3270; Docker) wired to GIBSON's TN3270
  -h, --help          Show this help
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --venv) MODE="venv" ;;
    --system) MODE="system" ;;
    --python) shift; PYTHON_BIN="$1" ;;
    --sim-root) shift; SIM_ROOT="$1" ;;
    --no-upgrade-pip) UPGRADE_PIP=0 ;;
    --skip-deps) INSTALL_DEPS=0 ;;
    --minimal) MINIMAL=1 ;;
    --with-web3270) WITH_WEB3270=1 ;;
    --pentest-tools) PENTEST_TOOLS=1 ;;
    --no-pentest-tools) PENTEST_TOOLS=0 ;;
    -h|--help) usage; exit 0 ;;
    *) warn "Unknown option: $1"; usage; exit 2 ;;
  esac
  shift
done

show_banner() {
  say "${BLUE}╔══════════════════════════════════════════════════════════════════════╗${RESET}"
  say "${BLUE}║${RESET} ${WHITE}Gibson Complete Dynamic Edition Installer${RESET}                     ${BLUE}║${RESET}"
  say "${BLUE}║${RESET} ${GREEN}z/OS-style training simulator bootstrap${RESET}                         ${BLUE}║${RESET}"
  say "${BLUE}╚══════════════════════════════════════════════════════════════════════╝${RESET}"
}

require_python() {
  if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    warn "Python interpreter not found: $PYTHON_BIN"
    exit 1
  fi
  step "Checking Python"
  "$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required")
print(f"Python {sys.version.split()[0]}")
if sys.version_info[:2] >= (3, 14):
    print("WARNING: the course tools are tested on Python 3.10 to 3.12. On this newer Python some of\n"
          "their packages may need compiling and zniff does not support it. Install python3.12 and run\n"
          "this again, or give it with --python python3.12.")
PY
  ok "Python ready"
}


python_minor_version() {
  "$PYTHON_BIN" - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
}

venv_works() {
  "$PYTHON_BIN" - <<'PY' >/dev/null 2>&1
import venv, ensurepip
PY
}

install_venv_package_if_possible() {
  [[ "$MODE" == "venv" ]] || return 0
  venv_works && return 0
  if [[ "$INSTALL_DEPS" == "0" ]]; then
    warn "Python venv support is missing, but --skip-deps/offline mode was requested."
    warn "Install the matching venv package manually before using --venv."
    return 1
  fi
  local pyver pkg_specific pkg_generic runner=""
  pyver="$(python_minor_version)"
  pkg_specific="python${pyver}-venv"
  pkg_generic="python3-venv"
  step "Python venv support is missing; detected Python $pyver"
  if command -v apt-get >/dev/null 2>&1; then
    if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
      runner=""
    elif command -v sudo >/dev/null 2>&1; then
      runner="sudo"
    else
      warn "Cannot install venv package automatically because sudo/root is unavailable."
      warn "Run: sudo apt-get update && sudo apt-get install -y $pkg_specific"
      warn "If unavailable, run: sudo apt-get install -y $pkg_generic"
      return 1
    fi
    step "Installing $pkg_specific or $pkg_generic using apt-get"
    $runner apt-get update
    if ! $runner apt-get install -y "$pkg_specific"; then
      $runner apt-get install -y "$pkg_generic"
    fi
    venv_works && { ok "Python venv support installed"; return 0; }
    warn "venv still unavailable after package installation."
    return 1
  fi
  if command -v dnf >/dev/null 2>&1 || command -v yum >/dev/null 2>&1 || command -v zypper >/dev/null 2>&1 || command -v apk >/dev/null 2>&1; then
    warn "Python venv support is missing. Install the Python venv/ensurepip package for this distribution."
    warn "Detected Python $pyver. Common package names include python3-venv, python${pyver}-venv, python3-pip, or py3-virtualenv."
    return 1
  fi
  warn "Python venv support is missing and no supported package manager was detected."
  warn "Install $pkg_specific or $pkg_generic, then rerun ./install_gibson.sh."
  return 1
}

ensure_pip() {
  if "$PYTHON_BIN" -m pip --version >/dev/null 2>&1; then
    return 0
  fi
  step "Bootstrapping pip"
  if ! "$PYTHON_BIN" -m ensurepip --upgrade; then
    warn "pip is not available for $PYTHON_BIN."
    warn "Install python3-venv/python3-pip for your distribution, or rerun with --system using a Python that has pip."
    exit 1
  fi
}

activate_env() {
  if [[ "$MODE" == "venv" ]]; then
    step "Preparing virtual environment"
    install_venv_package_if_possible
    if [[ ! -x "$VENV_DIR/bin/python" ]]; then
      if ! "$PYTHON_BIN" -m venv "$VENV_DIR"; then
        warn "Could not create virtual environment at $VENV_DIR."
        pyver="$(python_minor_version 2>/dev/null || echo 3)"
        warn "On Debian/Kali/Ubuntu install the matching venv package, for example: sudo apt install python${pyver}-venv or sudo apt install python3-venv"
        exit 1
      fi
    fi
    # shellcheck disable=SC1090
    source "$VENV_DIR/bin/activate"
    PYTHON_BIN="$VENV_DIR/bin/python"
    ensure_pip
    ok "Using virtual environment: $VENV_DIR"
  else
    warn "Installing into the active/system Python environment"
    ensure_pip
  fi
}

install_python_bits() {
  step "Installing Gibson and Python dependencies"
  if [[ "$UPGRADE_PIP" == "1" ]]; then
    "$PYTHON_BIN" -m pip install --upgrade pip setuptools wheel
  fi
  local pip_args=()
  if [[ "$INSTALL_DEPS" == "0" ]]; then
    pip_args+=(--no-deps)
  fi
  # The course tools in the Pen-Test Shell (ezrecon, zniff, cicspwn and the
  # rest) import dnspython, textual, aiohttp, scapy, PyYAML, py3270 and others,
  # which pyproject.toml keeps in the [pentest] and [ezrecon-live] extras. The
  # ISO always installed them and this script did not, which is why the same
  # tool worked on the ISO and failed here with ModuleNotFoundError.
  if [[ "$MINIMAL" == "1" ]]; then
    "$PYTHON_BIN" -m pip install ${pip_args[@]+"${pip_args[@]}"} -e "$ROOT"
  elif ! "$PYTHON_BIN" -m pip install ${pip_args[@]+"${pip_args[@]}"} -e "$ROOT[pentest,ezrecon-live]"; then
    # One package that will not build should not cost the rest. Every course
    # package now sits in pyproject's dependencies, so retrying the core
    # (`pip install -e .`) retried the same failing package: on Python 3.14,
    # where pygame had no ready-built package, the installer stopped there
    # with nothing installed, not even Flask or websockets, so neither the
    # dashboard nor the Pen-Test Shell could start. Instead, install each
    # dependency on its own (pip skips any whose marker does not apply), then
    # GIBSON itself without dependencies, and name whatever did not install.
    warn "Installing every package at once failed; installing them one at a time so one that will not build cannot stop the rest."
    local failed=() req
    while IFS= read -r req; do
      [[ -n "$req" ]] || continue
      "$PYTHON_BIN" -m pip install ${pip_args[@]+"${pip_args[@]}"} "$req" || failed+=("$req")
    done < <("$PYTHON_BIN" - "$ROOT/pyproject.toml" <<'PY'
import re, sys
text = open(sys.argv[1], encoding="utf-8").read()
try:
    import tomllib
    reqs = tomllib.loads(text)["project"]["dependencies"]
except ImportError:  # Python 3.10: read the list without tomllib
    block = re.search(r"^dependencies\s*=\s*\[(.*?)^\]", text, re.S | re.M).group(1)
    reqs = re.findall(r'^\s*"([^"]+)"', block, re.M)
print("\n".join(reqs))
PY
)
    "$PYTHON_BIN" -m pip install --no-deps -e "$ROOT"
    if ((${#failed[@]})); then
      warn "These packages did not install: ${failed[*]}"
      warn "GIBSON, the dashboard and the Pen-Test Shell run without them; tool-check names any course tool that needs one."
    fi
  fi
  "$PYTHON_BIN" - <<'PY'
from importlib.metadata import version, PackageNotFoundError
mods = ["flask", "passlib", "psutil", "requests", "websockets"]
missing = []
for name in mods:
    try:
        version(name)
    except PackageNotFoundError:
        missing.append(name)
if missing:
    raise SystemExit("Missing required package(s): " + ", ".join(missing))
print("Verified Python packages: " + ", ".join(f"{m} {version(m)}" for m in mods))
PY
  ok "Python packages installed"
}

seed_assets() {
  step "Seeding simulator files"
  mkdir -p "$SIM_ROOT/f/commands" "$SIM_ROOT/f" "$SIM_ROOT/logs"
  if [[ ! -f "$SIM_ROOT/GACF.DB" && -f "$ROOT/gibson/assets/GACF.DB" ]]; then
    cp "$ROOT/gibson/assets/GACF.DB" "$SIM_ROOT/GACF.DB"
  fi
  for f in "$ROOT"/gibson/assets/*; do
    [[ -f "$f" ]] || continue
    b="$(basename "$f")"
    case "$b" in
      GACF.DB) continue ;;
    esac
    cp -n "$f" "$SIM_ROOT/$b" 2>/dev/null || true
    cp -n "$f" "$SIM_ROOT/f/commands/$b" 2>/dev/null || true
    case "$b" in
      LISTCAT|SEARCH*|DISPLAY*|DPROGAPF|SETROPTS|*.TXT|*.txt)
        cp -n "$f" "$SIM_ROOT/f/commands/$b" 2>/dev/null || true
        ;;
    esac
  done
  chmod +x "$ROOT/run_gibson.sh" "$ROOT/gibsonctl.sh" "$ROOT/install_gibson.sh" 2>/dev/null || true
  ok "Simulator root prepared"
}

# The Pen-Test Shell wraps real nmap, hydra, nikto and friends, which are not
# part of GIBSON. They used to arrive only if someone ran toolbox-setup inside
# the shell, so a fresh install (on a Mac above all) had none of them and nmap
# always fell back to gibson-scan. Install them here, as the installing user.
setup_pentest_tools() {
  [[ "$PENTEST_TOOLS" == "0" ]] && return 0
  local helper="$ROOT/scripts/install-pentest-tools.sh"
  [[ -f "$helper" ]] || { warn "scripts/install-pentest-tools.sh not found; skipping security tools"; return 0; }
  step "Pen-Test Shell security tools"
  local args=()
  [[ "$PENTEST_TOOLS" == "1" ]] && args+=(-y)
  if GIBSON_SIM_ROOT="$SIM_ROOT" bash "$helper" ${args[@]+"${args[@]}"}; then
    ok "Pen-Test Shell security tools ready"
  else
    warn "Some security tools did not install. Re-run later with:"
    warn "  ./scripts/install-pentest-tools.sh -y"
  fi
}

setup_web3270() {
  [[ "$WITH_WEB3270" == "1" ]] || return 0
  step "Configuring web3270 browser-3270 add-on"
  if [[ -x "$ROOT/integrations/web3270/setup-web3270.sh" ]]; then
    if "$ROOT/integrations/web3270/setup-web3270.sh"; then
      ok "web3270 add-on configured"
    else
      warn "web3270 setup did not complete (needs git/network). Re-run later:"
      warn "  ./integrations/web3270/setup-web3270.sh"
    fi
  else
    warn "integrations/web3270/setup-web3270.sh not found; skipping add-on"
  fi
}

# Check rather than assume: import each course tool's packages with the
# Python that will run them, and look for the programs they call.
report_tool_readiness() {
  local tc="$ROOT/gibson/assets/pentest/tools/GIBSONscan/tool_check.py"
  [[ -f "$tc" ]] || return 0
  step "Pen-Test Shell course tools"
  "$PYTHON_BIN" "$tc" || warn "Some course tools are not ready; each line above says what fixes it."
}

finish() {
  say
  say "${GREEN}Installation complete.${RESET}"
  say "${WHITE}Next steps${RESET}"
  say "  1. cd scripts"
  say "  2. sudo ./grant-port-capabilities.sh     (press ENTER, then move back up: cd ..)"
  say "  3. ./gibsonctl.sh start"
  say "  4. IPL - at the console, type each reply and press ENTER after each:"
  say "       R 01,CLPA"
  say "       R 02,U"
  say "       R 03,Y"
  say "       R 04,1234"
  say "       R 05,GIBSON"
  say "       R 06,1337"
  if [[ "$MODE" == "venv" ]]; then
    say "${BLUE}Host commands:${RESET} $VENV_DIR/bin/gibson --list-volumes  (or: source $VENV_DIR/bin/activate, then gibson --list-volumes)"
  else
    say "${BLUE}Host commands:${RESET} gibson --list-volumes"
  fi
  say "${BLUE}Ports:${RESET} 2022 USS, 23 TSO/VTAM, 21 FTP, 80 CTI, 8443 Web Dashboard."
  say "${BLUE}Security tools:${RESET} ./scripts/install-pentest-tools.sh -y installs or repairs nmap, hydra, nikto, wget and jumbo John."
  if [[ "$WITH_WEB3270" == "1" ]]; then
    say "${BLUE}web3270:${RESET} starts automatically with ./gibsonctl.sh start (Docker) -> http://<host>:18080  |  disable: GIBSON_WEB3270=0"
  fi
}

show_banner
require_python
activate_env
install_python_bits
seed_assets
setup_pentest_tools
setup_web3270
report_tool_readiness
finish
