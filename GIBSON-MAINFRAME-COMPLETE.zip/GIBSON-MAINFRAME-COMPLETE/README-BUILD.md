# GIBSON Build Suite - single source of truth

This bundle holds the GIBSON application code in exactly one place and builds
every platform's installer from it, so there is no duplicated code to keep in
sync.

```
<tree root>/
  install_gibson.sh        the install Chapter 2 of the book documents
  gibsonctl.sh             start / stop / master console
  scripts/                 grant-port-capabilities.sh and friends
  gibson/  phosphor/  legacy/  tests/  pyproject.toml   the application
  build-linux.sh           -> GIBSON-linux-<arch>.tar.gz
  build-macos.command      -> GIBSON-Installer.pkg + GIBSON.dmg
  build-windows.bat        -> GIBSON-Setup.exe
  gibson.spec              shared PyInstaller spec (reads this directory)
  gibson_launcher.py       shared frozen entry point
  gibson.iss               Windows installer definition
  gibson.ico / gibson.png  shared icons
  requirements-build.txt   shared build dependencies
  sync-source.sh / .ps1    optional: fetch a source tree from git
  README-BUILD.md
```

Everything sits in one directory. It used to be split into `source/` and
`kit/`, which put `install_gibson.sh` one level down and made the install read
differently from the one Chapter 2 of the book documents, so the split is gone
and the build machinery now lives beside the code it freezes. A reader who
follows the book unzips, changes into the directory, and finds
`install_gibson.sh` and `scripts/` exactly where the chapter says they are.

The archive and the directory are named to match the book as well:
`GIBSON-MAINFRAME-COMPLETE-V1.zip` extracting to `GIBSON-MAINFRAME-COMPLETE`,
so Listing 2-3's `unzip` and `cd` lines are correct as printed. The whole
sequence was walked through as an ordinary non-root user to confirm it, from
`scripts/grant-port-capabilities.sh` through `./install_gibson.sh --venv` and
`./gibsonctl.sh start`, answering the six IPL replies at the console and
checking that ports 21, 23 and 80 bound without root.

Two things the chapter mentions are not in this tree and are chapter-side
corrections rather than code. There is no `gibson_startup.sh`; the script that
starts the services directly is `run_gibson.sh`, and the usual route is
`./gibsonctl.sh start`. There is no `requirements.txt` either, because
`install_gibson.sh` installs the package itself with `pip install -e .` and
takes its dependencies from `pyproject.toml`; `requirements-build.txt` here is
for the PyInstaller builds, not the lab. Listing 2-4 also shows the shell
prompt at `~` for `./gibsonctl.sh start`, which cannot work from the home
directory: you need to still be in this directory from the previous listing.

The build scripts now take the source tree to be their own directory. `GIBSON_SRC`
still overrides that, which is how you build a tree that lives somewhere else:

    GIBSON_SRC=/path/to/another/tree ./build-linux.sh

One consequence of sharing a directory is worth knowing. `install_gibson.sh`
creates `.venv` and `gibsonctl.sh` runs the lab from it, so the build scripts
deliberately use a separate `.venv-build`. Were they to share one, running a
build would install PyInstaller and the pinned build dependencies into the
environment the student's lab runs from. `sync-source.sh` likewise no longer
replaces the directory it sits in, because that would now carry off the build
machinery as well; it clones to a sibling directory and tells you to point
`GIBSON_SRC` at it.

## The two ways to use it

**Run from source (needs Python).** This tree is the full GIBSON with the web
suite, and it keeps the project's own routine, the one Chapter 2 of the book
walks through:

    cd scripts && sudo ./grant-port-capabilities.sh && cd ..
    ./install_gibson.sh --venv
    ./gibsonctl.sh start

Then open http://127.0.0.1:8443/  (sign in: admin / gibsonadmin!).

## Expired passwords on every logon path

Users added with `--adduser` now get an expired password in every security
mode, as ADDUSER does on z/OS, so each student chooses their own at first
logon. Put NOEXPIRED on a line to exempt that user. The expired flag is now
honoured wherever someone can log on, not only at TSO:

* TSO (3270 and line mode): the new-password screen, as before;
* FTP: `PASS oldpass/newpass/newpass`, z/OS FTP's documented format, giving
  `230-Password was changed.`; a plain PASS gets `530-The old password has
  expired` / `530 PASS command failed`;
* the USS shell (port 2022): it asks for the new password twice;
* CICS sign-on: DFHCE3528, then the New Password field.

The rules in SETROPTS (length, history, minimum change) apply to all of them.

## MFA: what was wrong, and authenticator apps

Checked against the code and by running it, GIBSON's MFA had three problems:

1. `MFA ENROLL userid TYPE(TOTP)` was not TOTP. It produced a fixed six-digit
   number derived from the secret that never changed over time, and the
   enrolment was never consulted at logon, so an enrolled user logged on
   with the password alone.
2. The system-wide `MFA ON` switch (IPL PIN + HHMM) was enforced only at the
   TSO logons. FTP, the USS shell and CICS sign-on let the same users in with
   the password alone.
3. There was no way to use a phone authenticator.

Now:

* **Real TOTP** (RFC 6238: HMAC-SHA1, 6 digits, 30 seconds, one step of clock
  drift, 160-bit secret), which is what IBM Z MFA's generic TOTP factor uses,
  so Microsoft Authenticator, Google Authenticator, Authy and the rest work.
* **Enrolment**, three ways: users enrol themselves at
  `https://<host>:8443/mfa/enroll` with their own userid and password (scan
  the QR code, type the first code), as on IBM Z MFA's web page; an
  administrator types `MFA ENROLL userid TYPE(TOTP)` at TSO and reads the
  setup key to the user; or the instructor runs
  `python -m gibson.cli --mfa-enroll STUDENT1` on the host, which draws the QR
  code in the terminal. A factor is pending until the first code is entered
  (on the page, at the host prompt, or `MFA VERIFY userid code`), so a
  half-finished enrolment never locks anyone out. `MFA REMOVE` / `MFA RESET`
  take it away or start again.
* **Logon**: TSO asks for the code on its own prompt; FTP and the USS shell take
  `password:code` in the password (IBM Z MFA compound in-band); CICS, whose
  password field holds only 8 characters, takes a one-time 8-character token
  from `https://<host>:8443/mfa/token` (IBM Z MFA's out-of-band token), valid
  for two minutes and once only.
* **MFA ON** now covers FTP, the USS shell and CICS too, with `password:PIN+HHMM`
  in-band or the /mfa/token page. IBMUSER stays exempt, as before.

Every enrolment, activation, token and failure goes to the security log, and
wrong passwords on the web pages count toward revocation. Still not covered:
the DRDA/Db2 port, IMS, z/VM and the web banking logons, which check the
password only. The QR code needs the segno package, now a dependency (pure
Python); without it the setup key still works.

## Background batch jobs, and secrets left on the spool

GIBSON's spool now fills with ordinary batch work, so SDSF, the LOG panel and
the FTP JES interface show a system in use: SMF dumps (IFASMFDP), HSM backups
(ADRDSSU), Db2 image copies and RUNSTATS (DSNUTILB), Db2 reports through
DSNTEP2 with real query output, payroll and ledger runs, OPERLOG archiving,
CICS journal prints and the occasional S0C7 abend. Each has the JESMSGLG,
JESJCL and JESYSMSG a real job has, plus the program's own SYSOUT, and job
numbers rise with time. About ten are already there the first time anyone
looks, then a new one arrives every two to seven minutes while someone is
looking, sometimes still executing and finishing a little later. The oldest
routine output is purged so the spool stays around thirty jobs.

In the training (vulnerable) profile six more jobs sit on the queue to show
what leaving output around costs. Every credential in them is fictional:

| Job | Owner | What a reader finds |
|---|---|---|
| DBLOAD | DB2LOAD | A Db2 password in the EXEC PARM, printed in JESJCL |
| PWRESET | SECADM | Two ALTUSER ... PASSWORD() commands echoed in SYSTSPRT |
| DB2GRANT | DB2ADM | A Db2 password on the Db2 command line processor's `-u` option in a BPXBATCH PARM, printed in JESJCL, plus a GRANT to PUBLIC and DBADM given to a marketing id |
| MKTEXTR | MKTUSER | Customer names, addresses, dates of birth and card data from GIBSON.CUSTOMERS and GIBSON.CARDS, in held output |
| PAYAPI | DEVUSER | An API key and a service password hard-coded in COBOL, in the compile listing |
| JENKSYNC | OMVSBAT | A CI token and a Git password in a BPXBATCH script's `set -x` trace, which the shell writes to STDERR |

Secure mode has the background work but none of these.

The jobs are built directly on the spool rather than run through the internal
reader, so they create no data sets, run no commands, write no SMF records
and touch nothing a student owns. They belong to batch and system ids, so as
on z/OS they are outside a student's default view: in SDSF an ordinary user
sees only their own jobs, and FTP's default JESJOBNAME and JESOWNER exclude
them. IBMUSER (SPECIAL) sees them all in SDSF ST, and in the training profile
anyone can reach them with `quote site jesjobname=*` and
`quote site jesowner=*`, which is the lesson. There is no thread: the jobs
are added when something looks at the spool. `GIBSON_AMBIENT_JOBS=0` turns
it off, and it stays off under the test suite unless a test sets
`GIBSON_AMBIENT_JOBS=1`.

## FTP JES and SQL modes

FTP's SITE FILETYPE=JES and FILETYPE=SQL now behave as on a z/OS V3R2 or ZD&T
system, with the reply texts and listing layouts taken from captures of real
servers. In JES mode, DIR lists jobs in the JESINTERFACELEVEL 2 layout,
filtered by JESJOBNAME, JESOWNER and JESSTATUS, DIR JOBnnnnn shows the spool
files, and GET JOBnnnnn, JOBnnnnn.x and JOBnnnnn.n retrieve output. GET of a
data set submits it and returns its output, and DELETE JOBnnnnn cancels the
job. In SQL mode, GET runs the SELECT in a data set against Db2. SITE takes
every JES and SQL parameter with z/OS's abbreviations, and STAT and HELP SITE
report them. The defaults are the real ones, so `dir` shows only jobs named
userid* until `quote site jesjobname=*`.
docs/FTP-ZOS-JES-SQL.md has the assessment, the before-and-after table, every
reply, which texts are confirmed and which inferred, and what still differs.
GIBSON_FTP_JESINTERFACELEVEL=1 selects level 1; GIBSON_FTP_SQL_LAB=0 turns off
the training hook that also runs SQL uploaded in SQL mode.

SQL queries work from every client, including the Linux and macOS ftp clients,
which switch to binary by themselves. The TSO `FTP` command takes `SITE FILE=JES`,
`SITE FILE=SQL` and the other SITE parameters, has QUOTE, and does JES and SQL
work through GIBSON's FTP server. In the Linux and macOS ftp client type `site`
in lower case or `quote site ...`; the Windows ftp client needs `quote site ...`.

## The gibson command on each build

The host switches (--list-volumes, --add-volume, --import-devmap, --reset,
--adduser, --deluser, --mfa-enroll, --diagnose) are typed as `gibson <options>`.
Where that command is:

* ISO, live or installed: /usr/local/bin/gibson, on the PATH. It runs through
  sudo against the service's state (/var/lib/gibson/mfsim, from
  /etc/default/gibson) and gives the folder back to gibsonsvc afterwards.
* Windows setup.exe: C:\Program Files\GIBSON\gibson.exe; the installer adds
  the folder to the system PATH, so a Command Prompt opened after installing
  finds it. It asks for administrator rights, and when it has to open its own
  window it waits for Enter before closing.
* macOS: /usr/local/bin/gibson, a link to GIBSON.app's gibson-cli.sh, made by
  the .pkg; after a DMG drag-install, READ ME FIRST.txt gives the one-line
  `sudo ln -sf` that makes it. It uses sudo when ~/mfsim holds root's files.
* Source install (install_gibson.sh): .venv/bin/gibson in the kit folder, or
  plain `gibson` after `source .venv/bin/activate`. `python -m gibson.cli`
  is the same thing.

## Workshop administration: --reset, --adduser, --deluser

Three switches for whoever runs a class. They act on GIBSON's state folder
(GIBSON_SIM_ROOT, ~/mfsim by default, or --sim-root) from the host's own
command line, need no logon, and are best run while GIBSON is stopped.

    python -m gibson.cli --reset                     # asks you to type RESET
    python -m gibson.cli --reset --yes --no-backup   # unattended, keeps no copy
    python -m gibson.cli --adduser class.txt
    python -m gibson.cli --deluser class.txt
    python -m gibson.cli --reset --yes --adduser class.txt --serve --with-ftp

**--reset** puts the simulated system back exactly as a new install has it.
Every dataset, RACF change, job, SMF and audit record, mail item, IPL answer
(so the IPL replies are asked for again) and Pen-Test Shell workspace is
removed and the default system is seeded again. The old state is moved to a
folder beside it called `<state folder>-backup-<date-time>` unless you add
`--no-backup`. Two host-side things are kept: the TLS certificate (certs/), so
clients that trusted it keep trusting it, and the security tools built from
source for the Pen-Test Shell (pentest/opt and pentest/src), so a reset never
forces John the Ripper to be rebuilt. Host-side credentials such as the mail
relay password never live in the state folder, so they are not touched. It
refuses to run while GIBSON answers on its ports (--force overrides), and it
refuses a folder that does not look like a GIBSON state folder, so a mistyped
--sim-root cannot empty your documents.

**--adduser LIST** and **--deluser LIST** read one user per line:

    # userid   password   [any further ADDUSER operands]
    STUDENT1   TRAIN01
    STUDENT2   TRAIN02    NAME('ALEX SMITH')
    INSTRUC1   TEACH001   SPECIAL OPERATIONS
    STUDENT3                                  <- password generated and printed

Commas work instead of spaces (a CSV export with a userid,password header row
is fine), and `--adduser STUDENT1:TRAIN01,STUDENT2:TRAIN02` or
`--deluser STUDENT1,STUDENT2` work inline. Each user goes through GIBSON's own
TSO ADDUSER and DELUSER commands issued by IBMUSER, so the RACF profile, the
group connection, SYS1.UADS, the SMF type 80 records and the RACF database
image are exactly what an administrator typing the commands produces. Each
new user must change the password at first logon, in every mode and on every
logon path (NOEXPIRED on a line exempts that user), and the output says so. A user that already exists is reported and
left alone; IBMUSER is never deleted; and DELUSER leaves the user's datasets,
as it does on z/OS (--reset clears them). The list is read and checked
before anything changes, so a malformed userid or a duplicate on line 30 stops
the run before the first user is added, rather than leaving half a class.

## EX in the ISPF 3.4 data set list

Typing EX in the line command column of the 3.4 data set list now executes that
data set as a CLIST or REXX exec, exactly as `EX 'dsn'` does at TSO READY or in
option 6: the same TSO command processor runs it, so the output, the SMF
records and the security checks are identical. The output appears on the same
TSO output panel option 6 uses, and END (PF3) or ENTER returns to the list you
came from.

* On a sequential data set, EX runs it directly.
* On a partitioned data set, EX opens the member list with a reminder, and EX
  next to a member runs that member. You can also type the member after the
  data set name in the list, as you already could for E, and use EX on it.
* EX is checked before the one-letter commands, so E (edit), B, V and the rest
  behave exactly as before; option 6 still returns to the command shell.

This is the 3270 ISPF; the raw-telnet ISPF's 3.4 is unchanged.

## Starting GIBSON: the IPL now happens in the browser

Starting GIBSON brings the services up immediately and opens the web Master
Console, which is the first thing the student sees. The system arrives
un-IPLed, exactly as a real machine would, and the console shows the
outstanding IEA and IEE requests with a banner explaining what to reply. The
student answers them on the console command line, in order:

    R 01,CLPA    R 02,U    R 03,Y    R 04,<4-digit PIN>
    R 05,<NAME>  R 06,SKIP

The console reports each request as it comes up, the status bar counts the
pending replies, and the right-hand panel flips from IPL ACTIVE to IPL
COMPLETE when the last reply is accepted. The IPL is required again on every
start, since the marker is cleared at startup.

This replaces the old behaviour, where the replies had to be typed into the
terminal window before any service would start. Nothing about the simulator
changed; the web console was already driving the same controller, so this is
the same IPL in a better place. The terminal window is now just a log. If you
prefer the old flow, set GIBSON_IPL_TERMINAL=1 and the replies are taken in the
terminal before services start, as before.

One consequence worth knowing: because the services now start before the IPL is
answered, the listeners are up while the console still says IPL ACTIVE. For a
training lab that is fine and the console tells the story correctly, but it is
a change from "IPL first, then services".

**Build a native installer (for people who should never see a build step).**
Run the matching script on the matching machine. Each one reads the tree it
sits in, freezes it, and produces a single distributable file:

    Windows : double-click build-windows.bat      ->  GIBSON-Setup.exe
    macOS   : ./build-macos.command               ->  GIBSON-Installer.pkg / .dmg
    Linux   : ./build-linux.sh                    ->  GIBSON-linux-<arch>.tar.gz

PyInstaller does not cross-compile, so run each on its own OS and CPU: an Apple
Silicon Mac makes the arm64 build, an Intel Mac the x86_64 build. The only
requirement on a build machine is an internet connection and about 2 GB free;
the scripts install Python, pip, PyInstaller and (Windows) the Inno Setup
compiler for you, including Python itself if it is missing.

## Office Mail and the internal SMTP listener

ISPF option M.8 is the Office Mail facility. User-to-user mail already works
without any server: the mail store classifies a recipient as internal when it
resolves to a RACF userid, either bare (GUEST) or at the internal domain
(guest@GIBSON.LOCAL), and deposits the note straight into that user's mailbox
dataset, for example GUEST.MAIL.IN. Mailboxes are auto-provisioned and
protected with ADDSD ... UACC(NONE) OWNER(the user), so the user reaches their
own mail and RACF still guards it from every other access path such as TSO,
ISPF 3.4 and LISTDS. A SPECIAL administrator still gets in.

On top of that there is a real SMTP listener, which now starts with the rest of
the lab rather than waiting to be asked for. It listens on port 25 (GIBSON_SMTP_PORT to change it,
GIBSON_SMTP_BIND to move it off loopback, --no-smtp to leave it out). It speaks a plain RFC 5321 subset:
HELO, EHLO, MAIL FROM, RCPT TO, DATA, RSET, NOOP, VRFY, HELP and QUIT, with no
TLS and no AUTH, so the conversation can be driven by hand over netcat and read
off the wire with Zniff. Mail that arrives is parsed and handed to the same
delivery code M.8 uses, so a note sent over the wire and a note composed in M.8
land in the same mailbox.

It refuses to relay. Only recipients that resolve to a local userid or the
internal domain are accepted; anything else is refused with a 550, and the
listener binds to 127.0.0.1 unless told otherwise. That matters because an
unauthenticated SMTP server that forwards mail is an open relay, which is a
real-world problem rather than a training one, and real nmap confirms this one
is not: its open-relay script reports "Server doesn't seem to be an open relay,
all tests failed". VRFY deliberately distinguishes known from unknown users,
because SMTP user enumeration is one of the things the listener exists to teach,
and nmap's smtp-enum-users script duly finds the lab's userids through it.

M.8's own SMTP_HOST default is left pointing at mail.sighberbank.com, so the
external-mail narrative is unchanged. If you want M.8's external path to go
through the local listener instead, set SMTP_HOST to 127.0.0.1, SMTP_PORT to 25
and TLS to NO in the CONFIGURE panel.

Note that it adds port 25 to what a port scan returns, which Chapter 6 does not
currently mention.

## The SMTP listener answers as a z/OS mail server

By default the listener presents itself as IBM's classic z/OS Communications
Server SMTP address space rather than as a Python script, so a port scan of the
lab identifies a mainframe and the listener can stand in as a research or
teaching honeypot. The greeting is built to the shape nmap's own service-probe
database carries for MVS, which is

    match smtp m|^220 ([-\w_.]+) running IBM MVS SMTP CS (\w+) on .*\r\n|
      p/IBM MVS smtpd/ v/$2/ o/MVS/ h/$1/ cpe:/o:ibm:mvs/

and a scan of the running listener therefore reports this:

    PORT   STATE SERVICE VERSION
    25/tcp open  smtp    IBM MVS smtpd V2R5
    Service Info: Host: GIBSON.LOCAL; OS: MVS; CPE: cpe:/o:ibm:mvs

The disguise goes beyond the banner, because a banner on its own does not
survive a conversation. The HELO reply is the real one, which answers a stranger
with "250 GIBSON.LOCAL is my domain name.  I've never heard of you!" and a
client claiming our own domain with "Yours too, I see!"; MAIL FROM and RCPT TO
answer a bare "250 OK"; DATA prompts with "354 Enter mail body.  End by new
line with just a '.'"; an accepted message is acknowledged with "250 Mail
Delivered"; and QUIT closes with "221 GIBSON.LOCAL running IBM MVS SMTP CS V2R5
closing connection". Those six replies are transcribed from real z/OS sessions
captured on public mailing lists rather than invented. There are no enhanced
status codes anywhere, which matters more than it looks, because enhanced codes
arrived with ESMTP and a server emitting them while advertising no such
extension gives itself away in one line.

HELP answers with a multi-line 214 block that lists the z/OS command set and
ends by naming the operating system, which is a second fingerprint surface
rather than decoration: nmap matches multi-line HELP output as readily as it
matches greetings, and its own OS/400 entry is matched entirely on a block of
that shape. The IBM-specific verbs are implemented too, so QUEU returns a spool
report (telnetting to port 25 and typing QUEU is the documented way to ask a
z/OS SMTP address space about its spool), VERB turns verbose mode on and off,
TICK accepts a ticket number, and the commands every SMTP server recognises but
almost none implements, SEND, SOML, SAML and TURN, answer 502 rather than 500.
The HELP block, the QUEU report and the VERB, TICK and EXPN replies are
reconstructed from the documented command set rather than captured, and the
source file says so for each one, so nobody mistakes a plausible reply for an
attested one.

Three environment variables tune it. GIBSON_SMTP_PERSONA=plain drops the
disguise and goes back to a modern ESMTP greeting advertising SIZE and
8BITMIME, which is the one to use when the exercise is about reading ordinary
SMTP rather than about fingerprinting a mainframe. GIBSON_SMTP_CS_LEVEL sets the
release in the banner, V2R5 by default, and any of the real levels such as V1R13
or V2R10 work. GIBSON_SMTP_HOSTNAME overrides the announced host name, which is
otherwise built from the simulator's host name and internal domain; it is
stripped down to a bare token whatever you set, because a space or a bracket in
there would stop the whole greeting matching the fingerprint.

EHLO is answered by default, still in the mainframe's voice, with the signature
domain line leading and only SIZE and 8BITMIME advertised. Set
GIBSON_SMTP_EHLO=refuse for the stricter RFC 821 voice of the oldest address
spaces, which answers 500 and pushes the client down the HELO path. Refusing is
arguably the more authentic answer, but it is not the default, because a scanner
that gets a 500 to EHLO stops there, so a honeypot collects less and the
Chapter 6 scan exercise shows less.

Using it as a honeypot takes one more deliberate step, because the listener
binds to 127.0.0.1 and nothing reaches it from outside until you set
GIBSON_SMTP_BIND=0.0.0.0 yourself. That is the right default, and the step
should stay deliberate: an SMTP listener that faces a network will be found
within hours, so put it somewhere you are willing to have found, keep it off a
machine that matters, and remember that everything it is told arrives from
strangers. What it will not do, whatever it is told, is forward mail, because
the no-relay rule is enforced on every recipient regardless of persona, so the
listener cannot be turned into someone else's outbound mail route. The console
audit line GIBSMTP001I records each delivery, with the TICK ticket number
appended when the client supplied one, which is the thread to pull on when
reading back what a visitor did.

One defect was found and fixed while verifying this against real nmap. Replies
were being flushed a line at a time, so each line of a multi-line reply went out
as its own TCP segment. A client that asks its socket for at least one line then
reads only the first line and leaves the rest buffered, so every later reply it
reads belongs to an earlier command, and nmap's library works exactly that way.
The drift made nmap's open-relay script read a trailing "250 HELP" left over
from the EHLO reply as acceptance of a foreign recipient and report the listener
as an open relay, which it is not. Replies are now written as one unit, the way
a real MTA writes them, and nmap now reports "Server doesn't seem to be an open
relay, all tests failed".

## What the builds were actually tested against

The Linux build was run end to end from this source and the frozen binary was
exercised rather than inspected, because a freeze either resolves every lazy
import and bundles every asset or it does not, and reading the spec does not
tell you which. The full freeze completed with no fall back to the lean retry,
and inside the frozen binary: nmap reports the SMTP listener as IBM MVS smtpd
V2R5 with cpe:/o:ibm:mvs, a note sent over port 25 lands in IBMUSER.MAIL.IN
ready to read in M.8, VRFY confirms IBMUSER and refuses an unknown userid, all
twelve bundled course tools start and print their usage with no missing module,
the target allowlist still refuses everything outside 127.0.0.1, localhost, ::1
and sighberbank.com, and `phosphor 127.0.0.1 2233 --client` connects to the lab
TN3270 listener and draws the logon screen.

Windows and macOS cannot be built here, so what holds for them is what they
share with Linux, which is nearly all of it: one spec, one launcher, one source
tree. The Windows installer definition takes dist\GIBSON\* with
recursesubdirs, so the frozen _internal directory and every bundled tool tree
go into the installer, and the Inno output name matches what build-windows.bat
copies to GIBSON-Setup.exe. The macOS script copies the same dist tree into
GIBSON.app/Contents/Resources/gibson and wraps it in the .pkg and the .dmg. The
genuinely platform-specific parts are the ones that cannot be proven without
the machine: Gatekeeper and SmartScreen on an unsigned build, pkgbuild needing
the Xcode command line tools, and pywinpty's native helpers for the Windows
ConPTY shell, which has a dependency-free pipe fallback behind it in any case.

Three defects turned up during that testing and are fixed.

The first mattered most. The bundled tool trees were copied into the workspace
only when it had no tools directory at all, which is right on a fresh machine
and wrong on every upgrade. A workspace seeded by an earlier GIBSON kept
whatever trees that version shipped, so everything added since (PHOSPHOR, the
PassTicket suite, the z/OS Enumeration toolkit, CATMAP, Privesc and racfhound)
never arrived, while the launchers for them were written regardless and pointed
at paths that were not there. The student got "[sandbox] phosphor not found
at ..." and no clue why, and anyone who had run an earlier GIBSON was affected,
which includes the author's own machine. The trees are now synced: a missing
tree is copied in, a file missing inside a tree you already have is added, and
a file you already have is never overwritten, because students are meant to be
able to edit these and an upgrade should not revert someone's work. The cost of
that last choice is that an upstream fix to a file you already have does not
reach you, so GIBSON_PENTEST_REFRESH=1 forces a clean copy and moves the old
tools directory aside rather than deleting it. A test now asserts that every
name in the course-tool table has a bundled tree behind it, which is the check
that would have caught this.

The second was the scope checker refusing an argument that held two colons,
because it read the whole token as a host:port pair. A curl inside the shell
with -w 'code:%{http_code} time:%{time_total}' was blocked for no reason.
Arguments are now split on whitespace and each piece judged on its own, which
also closes a gap in the other direction, since a host smuggled inside a
whitespace-joined argument used to be reported as one unresolvable blob and is
now checked properly.

The third was Start-GIBSON-highports.sh on Linux, which set no port overrides
at all despite its name, so a student who was not root watched every listener
fail to bind 23, 80 and 175. It now exports the high ports the way the macOS
equivalent always has.

One honest note on the test suite. It builds state from the live simulator root
rather than a throwaway one, so running it against a lab you have been using
gives different results from running it against a clean root. Against a clean
root, 1250 tests pass and 33 fail, and those 33 fail identically on the
pre-change baseline: they are subprocess and socket timeouts in this
environment plus two that assert on a hardcoded year. Set GIBSON_SIM_ROOT to a
scratch directory before running pytest if you want a reading that does not
depend on your lab's current state.

## The system tools the shell wraps, and how they arrive

The Pen-Test Shell wraps nmap, nc, curl, wget, dig, host, ping, hydra and nikto
with scope-guarded launchers, so every target they are handed is checked
against the lab allowlist before the real binary runs. Those wrappers enforce
scope; they do not contain the binaries, because shipping and signing somebody
else's security tools for three platforms inside a training installer is a
different undertaking from shipping a training lab. They find the tool on the
system PATH instead.

That is fine on Kali, where all of them are present, and on most Linux. It is
not fine on macOS, which ships curl, nc, ping, dig and host but no nmap, wget,
hydra or nikto, nor on Windows, which ships little beyond curl and ping. The
shell used to answer a missing tool with "nmap is not installed in this build
yet (added in the toolbox phase)", which names a phase that does not exist and
leaves the student nowhere. Three things now happen instead.

First, `toolbox-setup` installs them. It uses Homebrew on macOS, apt, dnf,
zypper, pacman or apk on Linux, and winget through `toolbox-setup.cmd` on
Windows, and it resolves the package-name differences (dig and host come from
bind or dnsutils, nc from netcat-openbsd or nmap-ncat). Run it bare and it
reports what is present and asks before installing; run `toolbox-setup -y` and
it does not ask. If Homebrew is absent on a Mac it says so, points at brew.sh
and at nmap.org, and tells you the lab still works without it.

Second, the wrappers say what to do. A missing tool now names `toolbox-setup`
and, where it helps, the single brew command, rather than referring to an
internal build phase.

Third, and most useful, nmap has a fallback. GIBSON carries its own TCP connect
scanner, `gibson-scan`, which needs nothing installed and runs inside GIBSON's
own Python like every other bundled tool. It takes nmap's `-p` forms, including
`-p-`, grabs service banners under `-sV`, accepts and ignores `-Pn`, `-n` and
`-T4` so the book's command lines still run, and defaults to the lab's own
ports so a bare scan finds GIBSON rather than walking 65535 connects. It is not
nmap and says so in its first line of output every time: no SYN scanning, no OS
detection, no NSE, no UDP. Typing `nmap` with no nmap installed prints the
install advice and then falls through to it, so the Chapter 6 discovery
exercise runs on a machine that has had nothing installed at all. On the lab it
reports port 25 as smtp with the z/OS greeting, 2233 as tn3270 with the telnet
option bytes, and the web ports with their Server headers.

Two traps were found and fixed while testing this, both of which would have
hit a Mac and neither of which shows up on a Kali box.

The scope checker ran under "#!/usr/bin/env python3". A stock macOS has no
python3 on PATH; typing it only offers to install the Xcode command line tools.
On such a Mac the checker could not start, and because a wrapper refuses the
command when its gate fails, every system tool was blocked with exit 7 whether
or not it was installed. The gate now runs through GIBSON's own interpreter,
which is always there, and a test asserts the allowlist still holds with no
system Python on PATH at all.

The PowerShell backend was missed by the first pass at this. The shell drives
cmd.exe and PowerShell as well as a POSIX PTY, each with its own wrapper set,
and the PowerShell one still promised the toolbox phase and had no fallback.
Its scope check is a separate implementation in PowerShell, and it carried the
same two-colon false positive the Python checker had, so that is now split on
whitespace the same way. Tests assert all three backends agree, and that the
generated .cmd files carry CRLF with no stray bare line feed.

And `toolbox-setup` was finding the shell's own wrappers. It is only ever on
PATH from inside the Pen-Test Shell, and that same PATH holds scope-guarded
wrappers named nmap, nc, curl and so on, so `command -v nmap` found the wrapper
and reported nmap as installed on precisely the machine that did not have it.
It now looks past its own directory, the way the wrappers themselves do.

## The security tools are now installed with GIBSON, not left for later

A fresh Mac install had no nmap, hydra, nikto or wget, so every nmap in the
Pen-Test Shell fell back to gibson-scan. Nothing in the install put them there:
they arrived only if someone opened the shell and typed `toolbox-setup`, which
nobody setting up a workshop machine would know to do. And inside the shell
GIBSON is usually running under sudo, which is exactly where Homebrew refuses
to work.

`scripts/install-pentest-tools.sh` now runs the same toolbox-setup from GIBSON's
own files, as the installing user, during installation:

* `install_gibson.sh` calls it after seeding ~/mfsim. It asks once (default
  yes); `--pentest-tools` installs without asking and `--no-pentest-tools`
  skips it.
* The macOS app and both .command launchers call it on first launch, before
  they switch to sudo, so Homebrew runs as the logged-in user. It asks once;
  after that a launch only prints a one-line reminder if anything is missing.
* `./gibsonctl.sh start` does the same. On a machine that already has the
  tools, such as Kali, it is silent.
* By hand at any time: `scripts/install-pentest-tools.sh -y` (in the Mac app,
  `install-pentest-tools.sh` sits next to run-gibson.sh).

It installs with Homebrew (installing Homebrew first if needed) or the Linux
package manager, builds from GitHub whatever a package cannot provide, and
sets up jumbo John, all into ~/mfsim/pentest where the shell looks.
`toolbox-setup --check` reports without installing, which is how later
launches stay quiet. GIBSON_SKIP_TOOLBOX=1 turns the whole step off.

## IND$FILE and FTP transfer fixes merged in

The transfer fixes made alongside PHOSPHOR 1.0.18 are merged into this build:
gibson/net/indfile/ft_tables.py (IND$FILE's own fixed ASCII/EBCDIC translation
table, used for text in both directions), and the matching changes to
gibson/core/indfile_options.py, gibson/services/tn3270_server.py and
gibson/services/ftp_server.py, together with the bundled PHOSPHOR 1.0.18. None
of those files had been changed by the zSecure Alert, mail or Pen-Test Shell
work, so the merge took them as they were.

Checked against a live GIBSON from this tree, with PHOSPHOR 1.0.18 for IND$FILE
and Python's ftplib for FTP, and then the same script against the previous build
as a control:

| Transfer | Previous build | This build |
|---|---|---|
| IND$FILE binary, 1,024 bytes | damaged from the 5th byte | identical |
| IND$FILE text with [ ] ^ \| £ é | `SAY A ]] B âXã ØY`, `Ù100`, `K©V` | identical |
| FTP text (ISO8859-1) with £ é | £ and é dropped | identical |
| FTP binary, 1,024 bytes | 512 bytes returned | identical |

## Secure mode: three fixes to how RACF behaves

**IBMUSER could be revoked in secure mode.** The secure profile treats IBMUSER
as the break-glass administrator, and the original ALTUSER handler rejected
`ALTUSER IBMUSER REVOKE` in secure mode. A later, richer ALTUSER handler took
over dispatch and did not carry the guard across, so the revoke went through
while `DELUSER IBMUSER` (still the old handler) was rejected. The guard is back,
and it also covers CONTAIN, which revokes. Vulnerable mode still lets IBMUSER be
revoked, as real RACF would.

**SETROPTS LIST misreported the secure posture.** The secure profile set its
CIS values on the configuration object, but SETROPTS LIST, the health checker
and password hashing read the RACF password policy, so a secure lab enforced
PROTECTALL(FAIL) while reporting "PROTECT-ALL IS NOT ACTIVE" and "OPERAUDIT IS
NOT IN EFFECT", and new passwords were still hashed with DES. The secure profile
now writes the baseline into the policy: PROTECTALL(FAIL), OPERAUDIT, KDFAES,
four generations of history, revoke after six failures and a 90-day interval.
The policy is saved after every SETROPTS command and both modes share one lab
folder, so secure mode keeps its policy in its own file,
setropts_password_policy.secure.json. The vulnerable lab's policy file is never
touched, and the baseline is re-applied on every secure start.

**ADDUSER claimed a password change it did not require.** It printed
"ICH01026I PASSWORD CHANGE REQUIRED AT NEXT LOGON" every time, while the user
could log on with the initial password and never change it. In the training lab
a forced first-logon change has always been opt-in through SETROPTS policy
(tests/parity_harness.py relies on that), so the message is now printed only
when the change really is required. Secure mode turns the policy on, so there,
as in RACF, a new password and an administrator's reset both expire and the
TSO/E LOGON panel demands a new one (ICH70008I); NOEXPIRED still overrides.

The full suite now has 25 failures, down from 28; the three that pass are the
tests for these fixes, and nothing new fails. New tests cover each fix,
including that the secure policy never leaks into the vulnerable lab and that
the logon panel enforces the expired password.

## toolbox-setup installed nothing on a Mac, because the shell is root

On a Mac the Pen-Test Shell's `toolbox-setup` reported nmap, wget, hydra and
nikto as missing and then installed none of them. The normal Mac launchers (the
GIBSON app, "Start GIBSON.command" and run-gibson.sh) start GIBSON with sudo so
that it can listen on ports 21, 23, 80 and 175, and the Pen-Test Shell is a
child of that process, so it is a root shell. Homebrew refuses outright to run
as root, and `toolbox-setup` simply called `brew install`, so on every Mac
started the normal way the install failed. The tests ran the script on Linux,
where the same sudo situation is handled by apt, and never took the macOS branch.

`toolbox-setup` now runs every Homebrew command as the Mac user who owns the
Homebrew installation. Root needs no password to act as another user, so this
works without prompting. When there is no Homebrew yet, the script works out the
user from SUDO_USER, which sudo leaves in the environment, and failing that from
whoever is logged in at the Mac's screen. Homebrew runs with a plain system PATH
and from the root directory, because the shell's PATH begins with the
scope-guarded wrappers and the lab's own curl wrapper would refuse Homebrew's
downloads from github.com as out of scope. If no non-root user can be found, it
never falls back to running Homebrew as root; it builds the tools from source
instead (see the next section).

When Homebrew is not installed at all, `toolbox-setup` now offers to install it
with the official installer from brew.sh, run as that same user. The installer
asks for the user's Mac password once, needs the user to be an administrator,
and may install Apple's Command Line Tools first. Answering no moves on to
building the tools from source (see the next section).

The tools also have to be found once installed. Homebrew puts them in
/opt/homebrew/bin on Apple Silicon and /usr/local/bin on Intel, and GIBSON
started from the app or through sudo often has neither on PATH, so the
wrappers would still have said "not installed". On a Mac the shell now adds
both folders to the end of PATH whether or not they exist yet, so tools
installed during a session are found at once, and the wrappers stay first on
PATH so every target is still checked against the allowlist. `toolbox-setup`
searches the same folders when it re-checks.

Homebrew has formulae for all four of nmap, wget, hydra and nikto, so a Mac now
gets the complete set. That is more than Windows, where winget has no hydra or
nikto package. Tests run the real script against fake uname, id, stat, sudo and
brew commands, so the macOS branch is exercised on any machine; they assert that
Homebrew runs as its owner with the clean PATH, that it is never run as root,
and that the offer to install Homebrew appears when it is missing.

## Every tool can now come from source, and jumbo John is part of the set

For workshops the toolbox has to finish complete on any machine, including a
Mac where Homebrew is not allowed or not wanted. `toolbox-setup` and
`john-setup` now share one library (bin/toolbox-lib.sh) and take every tool the
same way: the package manager first, then the tool's own source, fetched and
built into the workspace under opt/ (sources under src/). Whatever a machine
lacks to build, git and a compiler, is installed first: Apple's Command Line
Tools on a Mac, installed without a dialog through softwareupdate the way
Homebrew's own installer does it, or the distribution's build packages on
Linux, with each package retried on its own if the manager rejects the list.

The sources are nmap from github.com/nmap/nmap, hydra from
github.com/vanhauser-thc/thc-hydra, nikto from github.com/sullo/nikto and John
from github.com/openwall/john. wget is the one tool not developed on GitHub,
so it comes from GNU's release tarball (wget-latest.tar.gz), which carries a
ready-made configure script. nikto is Perl and insists on the XML::Writer
module, which macOS's Perl does not include; it is one pure-Perl file, so it
is fetched from CPAN into opt/perl5 and the nikto launcher points PERL5LIB at
it. A source build is offered when Homebrew is declined, when there is no
ordinary user to run it as, when a formula or package fails, or always with
`toolbox-setup --from-source`.

John needed particular care. Its RACF format compiles only against OpenSSL,
and a Mac has no OpenSSL headers, so a plain source build there would produce a
John without the one format Chapter 8 needs. On a Mac, Homebrew's OpenSSL is
used when it is present, and otherwise OpenSSL is built from
github.com/openssl/openssl into opt/openssl first; nmap, hydra and wget link
against it as well. Homebrew's own john-jumbo formula installs everything under
share/john but links only john into bin, so racf2john was never on PATH after
a Homebrew install; john-setup now puts launchers for both into opt/bin.
`toolbox-setup` offers jumbo John at the end, so `toolbox-setup -y` prepares a
whole workshop machine in one command, and it exits non-zero unless every tool
and jumbo John are ready, so a prep script can tell.

The shell's PATH is now the wrappers, then opt/bin, then the system. The
wrappers stay first, so every target is still scope-checked. opt/bin comes
before the system folders, so a jumbo John built there wins over a
distribution's core john. On a Mac, Homebrew's folders follow at the end.

What has and has not been verified: the tests run the real scripts on a
pretend Mac and a pretend Linux, with stand-ins for uname, id, sudo, Homebrew,
apt, git, make, curl and Apple's tools, and check that each path takes the
right steps and leaves the right launchers. They do not compile anything, so
the first real run of each source build on a Mac is its proof. Windows is
unchanged: winget provides nmap and wget, and hydra and nikto still have to be
installed by hand there.

## The SMTP listener now starts when you start GIBSON

Port 25 was never listening on macOS, and the reason is worth recording because
it is the kind of gap a test of the obvious path does not find. SMTP had to be
asked for with --with-smtp on the command line, and the frozen launcher's
no-argument path, which is what a double-clicked GIBSON.app and
Start-GIBSON.sh both run, has its own hardcoded flag list that did not include
it. Every test of `gibson --serve --with-smtp` passed while the way people
actually start GIBSON quietly left the mail listener out.

The default experience now asks for it, so starting GIBSON any of the normal
ways gives you port 25 along with everything else, and a scan reports
IBM MVS smtpd before you have configured anything. It still binds loopback
only, it still refuses to relay, and if the port is already taken the CLI says
so in one line and carries on without it. `--no-smtp` turns it off. The no-sudo
launchers set GIBSON_SMTP_PORT=2525 so the mail exercises work without root;
unset it to put the listener on the real port 25, which then needs the sudo
launcher, and that is the one the macOS app bundle uses.

A test now asserts that --serve, --with-tools, --with-smtp, --with-tn3270 and
--with-ftp all appear in that no-argument flag list, because that list is the
one real users meet and it had no coverage at all.

Auditing the other start paths for the same omission found two more. The
run-from-source install, which README-BUILD documents as one of the two ways to
use GIBSON, starts through gibsonctl.sh, and its own START_ARGS did not include
--with-smtp either, so a source install had no mail listener at all. And the
Windows Start Menu entry for the secure profile passed only "--secure --serve",
so that shortcut started neither the Pen-Test Shell nor any of the lab
services; the secure profile is the same lab with CIS-aligned settings rather
than a cut-down one, so it now starts the same set. Every way of starting
GIBSON on every platform now brings the mail listener up:

    frozen, no arguments     the macOS app bundle, the Windows Start Menu and
                             desktop shortcuts, the portable zip
    Start-GIBSON.sh          Linux, sudo, port 25
    Start-GIBSON-highports   Linux, no sudo, port 2525
    Start GIBSON.command     macOS, sudo, port 25
    high ports, no sudo      macOS, port 2525
    Secure profile shortcut  Windows, port 25
    ./gibsonctl.sh start     run-from-source, port 25

A third defect surfaced while proving the source path. The scripted,
non-interactive IPL sequence listed only five replies, R 01 through R 05, so
boot_complete was never reached and it always ended with GIBMCS010E and exit 3.
That is the path a headless start takes, which meant `./gibsonctl.sh start` on
a server could never finish the IPL and never started a single service. It now
answers R 06 as well, with SKIP by default and --ipl-dvca-pin to set a real
DVCA/CBSA/OMEN training PIN. Three tests that had been failing on the baseline
pass again as a result.

One deliberate change of behaviour on the sudo launchers, worth knowing before
you upgrade. They now pin GIBSON_SIM_ROOT to the invoking user's home before
sudo takes over, because whether sudo keeps HOME is a per-machine sudoers
setting, so the same build could put the lab in ~/mfsim on one Mac and
/var/root/mfsim on another, and the no-sudo launcher would then be running a
second, entirely separate lab with its own datasets, mailboxes and shell
workspace. Both launchers now agree on ~/mfsim everywhere. If you have been
running the macOS app and your state did land in /var/root/mfsim, this looks
like a fresh lab; the old one is still there and can be copied across.

## The web Master Console now shows the alert stream

The web console rendered the boot view plus the echo of whatever command you
typed, and nothing else. That is why it looked healthy: D A,L and the IPL
replies worked perfectly, because those go through the command path, while
every asynchronous message the rest of the simulator raised went only to the
OPERLOG file and the terminal console. The browser never saw a delivery over
SMTP, a RACF denial, a port-scan alert or repeated failed logons.

The terminal console has always had a loop that polls for events and prints
them. The web console had the command half of that loop and not the event half.
It does now: each poll of /console/state moves anything new from the logs into
the OPERLOG pane, where it accumulates below the boot view the way a real
console scrolls. The outstanding IPL requests stay visible, which matters
because that pane is where the IPL is answered.

Two details are worth recording. The poller is cached on the dashboard server
rather than built per request, because it keeps a file offset and a fresh one
seeks to the end of the log every time, which would be the same bug wearing a
different hat. And it tails audit.log and OPERLOG.log rather than draining
state.console_events, because that drain is destructive: a web console that
drained would steal events from a terminal console running beside it, and since
notify_console writes through to OPERLOG.log the file already carries
everything the in-memory queue does, plus whatever other processes log.

Only messages belong on a console, so the audit trail is filtered. Everything
from OPERLOG passes, and from the audit records only ALERT and WARNING, which
means denials, failed logons, revocations and port scans but not the routine
"SMF080I ... RESULT(SUCCESS)" dataset-access records. That split is quieter and
closer to a real system, where SMF type 80 records go to SMF and get read in
SDSF while the console carries WTOs and the RACF messages that warrant
attention. Left unfiltered, one piece of mail arrived in the pane behind
nineteen routine dataset reads. Set GIBSON_CONSOLE_ALL_EVENTS=1 for the
unfiltered firehose.

Wiring that up exposed two grading bugs in the event normalizer, both of which
also affected the terminal console. The severity grader scanned every value in
an audit record with plain substring tests, resource names included, so an
ordinary read of a dataset whose name ends in ALERTS was graded ALERT and shown
in red; any dataset with FAIL, VIOL or REVOKED in its name did the same. It now
reads the outcome rather than the resource, and because the record's result
field runs to the end of the line and carries trailing KEY=VALUE detail with
it, the outcome is taken as the words before the first such token. Separately,
PORT_SCAN with an underscore, which is how the EVENT key spells it, was never
matched at all: only the spaced "PORT SCAN" that appears in prose was. Twenty
eight tests cover the pump, the filter and both grading bugs, including the
exact audit line from a running lab that started this.

One unrelated hazard fixed while rebuilding: both build scripts began with
pkill -f on the frozen binary's PATH. pkill -f searches whole command lines, so
that pattern matches any ancestor shell whose command line happens to mention
that path, and the build then kills itself mid-run. They now match the process
name with pkill -x, which finds exactly the frozen binary and can never match a
shell.

## Dataset profile ownership, and three silent RACF parsing bugs

ADDSD accepted an OWNER(id) operand and threw it away. The profile came out
owned by whoever issued the command, so `ADDSD 'GUEST.MAIL.**' UACC(NONE)
OWNER(GUEST)` reported success and then listed as owned by IBMUSER. That is not
cosmetic, because access_decision grants the profile owner implicit ALTER, so
the operand the student typed was deciding access and being discarded.

Fixing it turned up two more in the same family. ADDSD read its UACC operand
only when it came immediately after the profile name, so `ADDSD 'X' OWNER(Y)
UACC(READ)` silently took the UACC(NONE) default. And PERMIT kept the
apostrophes that RACF's own dataset syntax requires: `PERMIT 'GUEST.MAIL.**'
CLASS(DATASET) ID(GUEST) ACCESS(ALTER)` defined a brand new profile whose name
literally contained quotes, put the access list on that, and left the real
profile empty. ADDSD, ALTDSD, DELDSD and LISTDSD all stripped quotes; PERMIT
and REVOKE did not. A student following the documented syntax got a success
message and no permit.

All three are fixed. OWNER is honoured by ADDSD, RDEFINE and ALTDSD; an
undefined owner is refused the way RACF refuses it, with ICH04003I, and no
profile is created; a group is accepted as an owner, since the access rules
already have a GROUP_OWNER path; UACC is found wherever it appears; and PERMIT
and REVOKE strip quotes so the permit lands on the profile you named. Where no
OWNER operand is given, the owner still defaults to the issuer exactly as
before, which is what keeps every existing command and chapter working.

The one place in GIBSON that passes OWNER is the Office Mail mailbox
provisioner, so that is where the behaviour changes, and it changes for the
better. Measured on the same inputs before and after:

    GUEST on GUEST.MAIL.IN    before: DENIED, NONE     after: ALTER via OWNER
    IBMUSER (SPECIAL)         before: ALTER via SPECIAL after: unchanged
    RUARIV, KEVIN01, SYSPROG  before: DENIED            after: unchanged

A user could not reach their own mailbox through RACF at all, because the owner
was IBMUSER and the PERMIT meant to grant them access had gone to the phantom
quoted profile. M.8 still worked because the mail store writes as a trusted
delivery agent, which is why nobody noticed. Nobody else gains anything: the
mailbox is still UACC(NONE) and still shut to every other ordinary user, and a
SPECIAL administrator still gets in. Twenty tests cover the operand parsing,
the refusal of an undefined owner, the quoted and unquoted PERMIT forms, the
absence of phantom profiles, and that access matrix.

Two existing quoted profiles may be sitting in a simulator state directory from
before the fix, named with apostrophes and owned by #SYSPROG. They are inert,
because a lookup for the real name can never match them, and nothing here
rewrites an existing RACF database, so they will linger until that lab is
reseeded. A fresh state directory never creates them.

## Starting SMTPD, and four reasons it looked broken

Port 25 could appear dead even with the listener implemented and asked for, and
there were four separate causes, every one of them quiet.

The started task is SMTPD while the listener is SMTP, and the service table was
searched by registered name only; the listener tokens were used solely to
colour a port display. So an operator typing `S SMTP` was told
`IEE305I SMTP NOT DEFINED TO GIBSON SERVICE TABLE`, and the same held for
`S FTP` against FTPD and `S DASH` against GIBDASH. A service is now found by
the name an operator actually types, with an exact name still winning so every
internal caller is unaffected.

In SDSF the slash form is how a command is issued, `/S SMTP` or `/D SVC,L`, and
that form matched no branch at all: it fell through to
`ISF753I COMMAND /s smtp NOT RECOGNIZED`. Only a bare `/` was handled. The
slash is now stripped and the rest run as an operator command.

A starter that could not bind was unguarded, and the state was set to STARTED
straight after it regardless, so a listener that never came up still reported
as running and the real reason escaped to the caller. A failed start now stays
STOPPED and answers with the reason and the remedy:

    IEE305I SMTPD START FAILED - [Errno 98] Address already in use
    IEE305I PORT 25 IS ALREADY HELD BY ANOTHER PROCESS
    IEE305I STOP THAT PROCESS, OR SET A DIFFERENT PORT AND RETRY
    IEE305I SMTP PORT OVERRIDE: GIBSON_SMTP_PORT

A privilege failure points at `scripts/grant-port-capabilities.sh` instead.

At startup the same failure printed one line to stdout, which gibsonctl.sh
redirects into logs/gibson.log, so the lab came up without mail and said
nothing: a clean start, exit zero, and an empty port 25. Worse, the SMTPD entry
claimed STARTED because its state came from the command-line flag rather than
from whether the bind succeeded, so `D SVC,L` and the dashboard reported a
listener that was not there. The failure is now reported on the console as an
alert, where the web Master Console shows it too, and the service table is set
from reality. The listeners are created before the service table is built,
which is why the failure is recorded on the state and read back during
registration.

Two more things turned up while tracing it. `D SVC,L` typed anywhere other than
the master console fell through to `IEE600I ... SIMULATED DISPLAY COMPLETE`
with no data, so the obvious way to check whether SMTPD was up told you
nothing; it now renders the real service table wherever it is typed. And
`gibsonctl.sh --no-ftp` replaced the entire argument list with `--serve`,
silently discarding the SMTP listener, the pen-test shell and the app server
along with FTP; it now drops only `--with-ftp`.

Twenty four tests cover the name resolution, the guarded start, the advice for
each failure reason, the honest service table, the SDSF slash form, the service
display and the gibsonctl flag handling.

## Three more reasons port 25 looked dead

The four causes above were all real, and port 25 could still come up empty
afterwards, because three further things were in the way and none of them was
in the code that serves mail.

The no-sudo launchers pinned the port away from 25. Both the Linux
`Start-GIBSON-highports.sh` and the macOS `Start GIBSON (high ports, no
sudo).command` exported `GIBSON_SMTP_PORT=2525`, on the reasoning that an
ordinary user cannot bind a privileged port and a working listener on 2525
beats a failed one on 25. The effect was that port 25 was never even
attempted on the path most people take, so the honest answer to "why is port
25 not listening" was "because this launcher asked for 2525". Neither
launcher sets it now, so mail goes to port 25 wherever it can, and the
fallback below covers the case where it cannot.

Binding a privileged port is now attempted and then recovered from, rather
than decided in advance. Ports below 1024 belong to root on Linux and macOS
alike, and the frozen builds have no file capabilities to lean on, so an
ordinary user double-clicking a launcher genuinely cannot have port 25.
Refusing outright would leave the Office Mail client in M.8 with nothing to
talk to, so the listener takes 2525 instead and says so where it cannot be
missed:

    IEE305I SMTPD CANNOT BIND PORT 25 - PERMISSION DENIED
    IEE305I SMTPD IS LISTENING ON PORT 2525 INSTEAD
    IEE305I MAIL WORKS, BUT A SCAN OF PORT 25 WILL FIND NOTHING
    IEE305I FOR PORT 25 START GIBSON AS ROOT, OR RUN grant-port-capabilities.sh

A port named explicitly through `GIBSON_SMTP_PORT` is never second-guessed:
that fails with the diagnostics above instead of quietly moving, because
somebody who asked for a particular port would rather know they did not get
it. A refused port above 1023 is a real fault and is not worked around
either. Running GIBSON as root, or granting capabilities with
`scripts/grant-port-capabilities.sh`, gets port 25 for an ordinary user on
Linux; both are verified, with and without the capability granted.

The port a fallback lands on is now the port everything reports. A listener
that moved used to leave `D SVC,L`, the dashboard and the open-port register
naming port 25 with nothing on it, because they all read the configured port
rather than the socket. The effective port is written back to the state and
the config, and the operator START path reads the port off the socket itself,
so the service table cannot drift from the listener again.

One more thing, found while tracing this and unrelated to mail: DB2's DAS
listener defaults to port 446, which is privileged, and it starts unless
`--no-db2` is passed. Neither no-sudo launcher overrode it, so both died on
startup with a bare `PermissionError` traceback before reaching the mail
listener at all. Both now set `GIBSON_DB2_TCP_PORT=4460` alongside the other
high ports.

## Which port mail listens on

Mail listens on **2525** by default, on every platform.

Port 25 is the realistic answer and 2525 is the one that works. Ports below
1024 belong to root on Linux and macOS alike, and the Windows and macOS builds
are run by double-clicking a launcher rather than through sudo, so a default of
25 meant mail failed to bind for exactly the people least equipped to diagnose
it. A default of 2525 binds without privilege everywhere, which is why it is
now the default.

Port 25 is still available, and is worth using when the point of the exercise
is that a scan finds an MTA on the port a real system uses:

    GIBSON_SMTP_PORT=25 ./gibsonctl.sh start

That needs root, or capabilities granted through
`scripts/grant-port-capabilities.sh` on Linux. The z/OS persona is identical on
either port, so an nmap service scan of 2525 still fingerprints the banner as
IBM MVS SMTP; what changes is only whether the port number itself is the
well-known one. A port named explicitly this way is never second-guessed: if it
cannot be bound the start fails loudly with the reason rather than quietly
moving elsewhere.

## Which address mail listens on

Mail binds `127.0.0.1` by default, and this is the one remaining reason a scan
can report port 25 closed while everything else in the lab answers.

Every other listener here, TN3270 and FTP and the dashboard and the rest, binds
`config.host`, which is `0.0.0.0`. Mail alone binds loopback, on the reasoning
that an unauthenticated MTA should not face a network. The consequence is worth
stating plainly, because it is easy to read as a fault: mail works normally on
the lab host, `telnet 127.0.0.1 25` gets the z/OS banner, and an nmap scan run
*on the lab host* finds port 25 exactly as intended. A scan from any other
machine reports it closed, because nothing is bound to this host's network
address. That is the expected result of the default, not a failure.

Whether to change it is a security decision rather than a configuration
detail, which is why it is documented here rather than switched. The listener
refuses to relay whatever it binds, so widening it does not turn the lab into
an open relay, but anyone who can reach the port could post mail into the
lab's own mailboxes. On an isolated classroom network that is the same bargain
every other deliberately vulnerable service here already makes. On a shared or
untrusted network it is not. `GIBSON_SMTP_BIND` selects the address and always
wins when set; the secure profile keeps mail on loopback regardless, since
being the hardened comparison is that profile's whole purpose.

## Answering "is port 25 listening" in one command

    ./gibsonctl.sh smtp-check

Four platforms, four launchers and two possible ports made this question
harder to answer than it should be, so it is now a command. It reports the
configured port and where that value came from, the bind address and what that
means for a scan from elsewhere, which user GIBSON is running as, whether
anything is listening on the wanted port and on 25 and 2525, the live banner
read back off the socket, and the last few SMTP lines from logs/gibson.log. A
fallback, a port override left set in a shell, a privileged-port refusal and a
loopback bind each produce a different and self-explanatory report.

## Real outbound mail, and why it does not use SYS1.EMAIL

M.8 can relay mail to the outside world. The credentials for doing so live on
the host, never in the simulated filesystem, and the reason is the whole design
rather than an implementation detail.

The mail facility already had outbound SMTP in `mail_transport.send_smtp`, with
STARTTLS, implicit SSL and AUTH, configured from `SYS1.EMAIL`. That remains
exactly as it was, because for the lab it is correct: a mail password sitting in
plain text in a browsable system dataset is an authentic finding and a good
teaching artifact, and `CREDS_B64` is base64, which looks like protection and
reverses in one command, which is a lesson in itself.

It is the wrong place for a real password. The exercises in this course teach
students to obtain RACF SPECIAL, abuse APF and read protected datasets, and the
mail facility creates `SYS1.EMAIL` deliberately so it can always be browsed, with
only the generic `SYS1.**` profile over it. Anything in there should be treated as
published. Relaying real mail with credentials stored there would hand every
attendee a working account on the operator's own domain, with that domain's
sending reputation behind it.

So the relay is a separate path in `gibson/apps/mail3270/mail_relay.py` that reads
no secret from anything the simulated system can reach. When it is enabled it
takes over external mail completely, which means editing mail configuration in
M.8 cannot redirect real mail, change the sender, or downgrade the transport.
The Configure panel says so on screen, because an operator who could not see
that would reasonably assume the password typed there is what goes on the wire.

Everything fails closed:

- Off unless `GIBSON_MAIL_RELAY` is set. A disabled relay and a misconfigured
  one report differently, so "I never turned this on" is distinguishable from
  "I turned it on and it is refusing".
- Nothing is sent unless the recipient's domain is in `GIBSON_MAIL_ALLOW_DOMAINS`.
  An empty allowlist denies everything, so the relay cannot do anything useful
  until somebody states who it may write to. Matching is exact or a true
  subdomain, so `example.org.evil.com` does not pass as `example.org`.
- Credentials come from `GIBSON_MAIL_SMTP_USER` and `GIBSON_MAIL_SMTP_PASS`, or
  from a file named by `GIBSON_MAIL_CREDS`. That file is refused if it sits
  inside `GIBSON_SIM_ROOT`, if it sits inside the GIBSON kit, which is what gets
  zipped and shipped with the book, or if it is group or world readable.
- Authentication over a cleartext connection is refused outright. The default is
  STARTTLS, and a lab full of people running packet captures is the last place
  to put a password on the wire.
- Volume is capped by `GIBSON_MAIL_MAX_PER_HOUR`, sixty by default, so a lab
  somebody has taken over cannot become a mail cannon.
- Every attempt is audited to the console and the security log, sent, blocked,
  throttled or failed alike. Real mail leaving a training lab should never
  happen quietly.
- Relayed mail carries `X-GIBSON-Relay` and `X-GIBSON-User` headers, so whoever
  receives it can tell it came from a training simulator and which lab user
  composed it.

Settings, all host side, all prefixed `GIBSON_MAIL_`:

    GIBSON_MAIL_RELAY=1                       enable it at all
    GIBSON_MAIL_SMTP_HOST=smtp.example.net    smart host
    GIBSON_MAIL_SMTP_PORT=587                 default 587
    GIBSON_MAIL_TLS=STARTTLS                  STARTTLS, SSL or NONE
    GIBSON_MAIL_FROM=lab@example.org          envelope and header sender
    GIBSON_MAIL_ALLOW_DOMAINS=example.org     comma separated, empty denies all
    GIBSON_MAIL_CREDS=/path/outside/the/lab   file holding SMTP_USER/SMTP_PASS
    GIBSON_MAIL_SMTP_USER=...                 or supply them directly
    GIBSON_MAIL_SMTP_PASS=...
    GIBSON_MAIL_MAX_PER_HOUR=60               volume cap

One recommendation that no amount of code can enforce. Relay as a dedicated
mailbox on a subdomain rather than a primary identity, because the entire
purpose of this lab is that its secrets get taken, and the measure of a good
design here is what it costs you when somebody succeeds.

Thirty three tests cover the refusals as much as the happy path: off by default,
the allowlist including the suffix trick, credentials inside the sim root or the
kit or left world readable, authentication without TLS, the rate limit, the
audit records, a transport failure reported rather than raised into the panel,
and both routing directions through M.8.

## The Master Console lost the SMF stream, and three reasons why

Three separate faults stacked up here, and the first was the worst because it
was a deliberate change that removed the thing the pane exists for.

A filter was added to the console event stream that passed OPERLOG in full and,
from the audit trail, only ALERT and WARNING. The reasoning was that SMF type 80
records belong in SMF and an operator console should carry WTOs and RACF
messages, and that one piece of mail arriving behind nineteen routine dataset
reads buries the alert a student is meant to notice. The reasoning was wrong
here. SMF records grade INFO and logons grade EVENT, so filtering on severity
removed the SMF stream, the connecting IP addresses and the IBMUSER and GUEST
logon records in one go, which is precisely the traffic an operator watching for
a scan is watching. It also left the alerts it was meant to highlight with no
surrounding context to be noticed against. The default is the full stream again,
and GIBSON_CONSOLE_ALERTS_ONLY=1 gives the quiet view to anyone who wants it.

Nothing was ever wrong with the colours, which is worth recording because it is
where you would look first. The console grades text rather than severity:
SMF080I matches the message-id pattern and renders amber, and a record carrying
DENIED, FAILED or ICH408I renders red. The lines had simply stopped arriving.

The SMTP listener recorded no security event at all. Every other listener calls
record_security_event with the peer address, which is how a connection reaches
the console with its source IP, and mail did not, so an nmap scan of the mail
port was invisible on the console even though the listener answered it with a
full z/OS banner. That is the wrong way round for a honeypot: the persona was
convincing and the fact that anyone had probed it went unreported. A connection
now records SMTPD CONNECT with the peer address and the port.

The SMF80 console line was rendered without the address. The logon and
port-scan branches both appended FROM <addr> and the general SMF80 branch did
not, so a record that carried the connecting IP arrived on the console without
it. That covered every SMF80 event other than a logon, a connection to a
listener included.

End to end, an nmap service scan of the mail port from another machine now
produces this on the console, in red, because ICH408I is in the red group:

    ICH408I SECURITY EVENT USER(SMTPD) EVENT(CONNECT) RESULT(SUCCESS)
            RESOURCE(SMTP) FROM 192.0.2.2

and nmap reports the port as `smtp IBM MVS smtpd V2R5`.

## Mail faces the network

Mail binds config.host, which is 0.0.0.0, so it is reachable from another
machine as every other listener here already was. It returned loopback
unconditionally before, on the reasoning that an unauthenticated MTA should not
face a network. Sound for a mail server and wrong for this one: the z/OS persona
exists to be found by a scan, and loopback made it invisible to every scan
except one run on the lab host itself, while TN3270, FTP, the dashboard and the
rest all faced the network. Mail was the only service in the lab that vanished
when a student scanned the box from the classroom, which read as a fault and was
not one.

Mail still refuses to relay whatever it binds, so what a visitor can do is post
into the lab's own mailboxes, which is the same bargain every other deliberately
vulnerable service here already makes. GIBSON_SMTP_BIND still wins when set, so
a single lab can be pinned back to loopback, and the secure profile keeps mail
on loopback regardless, since being the hardened comparison is that profile's
entire job.

## zSecure Alert (SE.A) and C2POLICE

The zSecure panel's SE option is now the Setup menu, and SE.A is a model of IBM
Security zSecure Alert: configurations in `C2P.C2PCUST`, the Set, Des, Sel, Ver
and Ref cycle, C2POLICE as a started task reading the SMF stream, and alerts to
the Master Console, CTI SENTRY, Office Mail and a SIEM over syslog or Splunk
HEC. `docs/ZSECURE-ALERT.md` is the guide; this section records what changed in the
code and why.

New package `gibson/apps/zalert`: `catalog` (alert definitions), `config` (the
library format, verify members, generic masks), `engine` (parsing and matching),
`destinations` (delivery, the allowlist, syslog and HEC), `police` (the started
task and library operations), `panels` (the ISPF dialogs) and `tutorial`.
`scripts/siem-sink.py` stands in for Splunk.

Three things in the existing code had to change for alerts to be correct.

ADDSD was never audited. Its reply is `ICH10010I DATASET PROFILE ... ADDED`, and
the audit hook in `tso.py` only fired on `DEFINED`, so creating a data set
profile, including one with `UACC(UPDATE)`, left no SMF record at all while
ALTDSD and RDEFINE did. Alert 1202 exists for exactly that case.

One RACF event writes two or three audit lines with different trailers, so a
naive reader counts every logon twice and every SETROPTS three times. A time
window cannot separate those copies from five password guesses fired as fast as
a tool can manage, which are also milliseconds apart; a window wide enough to
swallow the copies swallowed the guesses, and alert 1111 never saw its five. The
engine instead collapses lines that come from different writers for the same
event, and treats a repeated writer as a new event.

Alert delivery had to avoid feeding itself. Office Mail's normal delivery
provisions mailboxes by issuing RACF commands as IBMUSER, which land in SMF and
count towards alert 1120, so each alert e-mail would have contributed to the
next alert. Delivery writes the mailbox data set directly as C2POLICE, whose own
records the engine ignores, and a test runs several cycles to prove the count
stays put.

Operator integration: C2POLICE starts at boot (`--no-zalert` or `GIBSON_ZALERT=0`
to prevent it), appears in `D SVC,L`, stops with `P`, and answers `F C2POLICE,`
`REFRESH`, `COLLECT` and `STATUS` from the web Master Console, SDSF and TSO. The
curses Master Console runs as a separate process, so its MODIFY is queued to the
started task and the reply arrives through OPERLOG, as it would on z/OS. The web
console colours `C2Pnnnnx` ids by their final letter, and CTI SENTRY has a new
`/cti/zalert` page and `/cti/api/zalert` JSON.

Fifty-seven tests in `tests/test_zsecure_alert.py` cover the catalogue, the
library format and step tracking, each matcher against real audit lines, the
duplicate handling in both directions, both syslog formats, the allowlist, a
real HEC exchange with token checking, verify and refresh discipline, an edit
that does nothing until refreshed, end-to-end delivery, the feedback loop, the
cross-process MODIFY, the panels including authorisation, and the ADDSD fix.

## SE.A was unreachable from ISPF, and undefined-user logons were not audited

The first build of the zSecure Alert dialogs could not be reached the way
anyone actually arrives. GIBSON has two zSecure front ends: a full-screen
session, reached only by typing ZSEC on the ISPF option line, and the panel
behind ISPF option M.1. The dialogs were wired into the first only. On M.1, SE
ran the ZSEC SETUP report and printed it under the menu, anything other than
the seven listed codes was rejected, and the option field was four characters
wide, so SE.A and SE.A.A could not even be typed. The testing exercised the
full-screen session directly and never went in through ISPF, which is how this
shipped.

M.1 now hands SE and every SE path (SE.A, SE.A.A, SE.A.S and so on) to the
dialogs as a nested application, with PF3 climbing back one level at a time to
the M.1 menu, and the option field holds a full path. Both zSecure front ends
use the same entry, so they cannot drift apart again. The tests now go in
through ISPF M.1, and the whole configuration cycle has been driven over a real
TN3270 session with s3270: logon, ISPF, M.1, SE.A.A, the C E W S V F line
commands typed into the fields, "/" to refresh C2POLICE, and alerts raised from
a second terminal.

That exercise found a gap in the lab itself. The TSO/E LOGON panel audited a
wrong password and a revoked user but not a logon by an undefined userid, which
RACF audits as ICH408I ... USER AT TERMINAL NOT RACF-DEFINED. User-id
enumeration against TSO therefore left no SMF trail, and alert 1101 could never
fire from a real logon. Both the TSO/E LOGON panel and the line-mode logon now
write that record.

ZSEC ALERTS, offered on the line-mode zSecure menu and from TSO, printed the raw
SMF event review under the name ALERTS. It now reports C2POLICE's state and its
recent alerts, followed by the most recent SMF security events they are
evaluated against, and points to M.1, SE.A for configuration.

## Web terminal credentials are bound to the machine that made them

The web terminal mints a random Guacamole password the first time it runs and
stores it in `web-terminal/generated/guacamole-credentials.env`, reusing that
file on every later start. Because it only mints a new password when the file
is missing, a `generated/` directory that travelled inside a kit handed every
recipient the same password, and it is regenerated in any working tree where
the web terminal has been started, so it can quietly reappear in a kit after it
has been removed. The file now records the host that generated it, and a file
from any other host, or one written before this change with no host recorded,
is discarded and replaced. An exported `GIBSON_GUAC_PASSWORD` is still honoured.
The DMG and setup.exe builds were never affected, since the PyInstaller spec does
not bundle `web-terminal`.

## Keeping it in sync - there is nothing to sync

Because the run-from-source install and all three builds read the same one
directory, a change made once is picked up everywhere. Edit the code, run a
build, and that build reflects the change.

## Optional: fetch a source tree from git

If you keep the GIBSON web-suite source in a git repository (for example your
GitHub repo), fetch it alongside this tree before building:

    ./sync-source.sh  [git-url] [branch]        # macOS / Linux
    .\sync-source.ps1 -Repo <git-url> -Branch <branch>   # Windows

The repo must contain the GIBSON tree at its root (gibson/, phosphor/,
pyproject.toml, install_gibson.sh, ...). The fetched tree lands in a sibling
directory and the script prints the GIBSON_SRC line to build from it, so your
working tree and its build machinery are never overwritten.

## DASD volumes and the DEVMAP

Every data set now lives on a 3390 volume with a device number behind it, kept
in a ZD&T-format `devmap` in the state folder (generated on first start; an
older state folder is upgraded and no data set is stranded). The operator
commands D U, DS P and V show and change the devices; TSO ALLOCATE, ISPF 3.2 and
JCL (VOL=SER, UNIT, SPACE, DCB, dispositions, in every step) place data sets on
volumes with real 3390 space accounting; IEHLIST LISTVTOC and ISPF 3.4 with a
volume serial list a volume's VTOC, catalogued or not; a data set whose volume
is offline cannot be opened from TSO, ISPF, FTP or batch; and new volumes are
added with `--add-volume`, initialised with ICKDSF INIT and varied online, as on
ZD&T (`--import-devmap` reads a real ZD&T devmap, `--list-volumes` lists them).
Vulnerable mode seeds four exercises: a forgotten offline volume with an
uncatalogued RACF database copy, VTOC reconnaissance, an APF entry for a deleted
library on a named volume (with the IBM health check CSV_APF_EXISTS), and a
volume anyone may wipe. `GIBSON_DEVMAP=off` switches all of it off and restores
the previous behaviour exactly. The full guide, with keystroke-level steps, is
docs/DASD-DEVMAP.md.

How it was kept from regressing anything: tests/dasd_golden records the output
of every console, TSO, JCL, FTP and data set operation that shows or uses a
volume, as it was before this work, and tests/test_dasd_golden.py fails on any
difference not listed (with its reason) in tests/dasd_golden/expected/CHANGES.md.
With GIBSON_DEVMAP=off the output is identical to that baseline.

## Honest notes

The bundled course tools (ezrecon, zniff, tshocker, cicspwn, injector,
nje-assess and core phosphor) run inside GIBSON's own frozen Python, so no
separate Python is needed to use them. Core PHOSPHOR for Chapter 13 is included
as the terminal and audit client: `phosphor <host> --client` needs no unlock,
while `phosphor <host> --scan` and `--menu` need the one-time unlock code from
the book, exactly as the chapter describes. The PHOSPHOR desktop GUI and glass
CRT are not bundled (they need pygame/moderngl/pyglet and cannot run in the
headless shell); install PHOSPHOR on a workstation per Chapter 13 for those.

The z/OS enumeration toolkit from mainframed/Enumeration (MIT licence, with
some Java files carrying their own GPLv3 notices, all preserved) is bundled
under the shell's tools/Enumeration. These are REXX, JCL, Java and C artifacts
that run ON the mainframe rather than in the shell, so they are provided as
course material with a discovery command: type `enumeration` in the Pen-Test
Shell to list ENUM, ACCESS, APFCHECK, the OMVS tools, the ready-made JCL and
the ENUM.XMI transmit package, along with how to upload them to the lab host.
Note that PDSTEST.rexx, PDSACCESSTEST.rexx and Legacy/exfil.rx deliberately
write or move data, so they want disposable targets.

The Pen-Test Shell carries the attacker-side tooling for chapters 3 to 12:
ezrecon (ch6), zniff (ch7), tshocker (ch7), cicspwn (ch9), phosphor (ch3/ch9),
injector, njejcl, njeanalyze and nje-assess from NJElib (ch10), and the
PassTicket suite parse_db_ptkt, unmask_passticket and gen_passticket (ch8).
Type `tools` to list them and `enumeration` for the host-side toolkits.

The PassTicket tools and njeanalyze never open a network connection, so their
launchers skip the target allowlist check. That is deliberate: they work on an
exfiltrated RACF database and on captures, and their arguments include z/OS
dataset names such as SYS1.RACFDS which look exactly like hostnames to the
checker, so scope-checking them would block valid use while protecting nothing.
Every tool that does reach the network is still confined to 127.0.0.1 and
sighberbank.com.

Tools the chapters use that GIBSON implements inside the simulator rather than
in the shell are reached from the TSO READY prompt: CATMAP (`EX CATMAP`),
REXX.SEARCH, SEARCHRX, SYS0WN, ENUM and the ELV.SVC / ELV.SELF privilege
escalation scripts. Their upstream source is bundled under tools/CATMAP and
tools/Privesc for reference. RACFHound (ch12) is bundled as source only: it
needs its own pip install plus a running BloodHound instance and SSH to a real
z/OS, and the chapter gives a workflow rather than a command line.

The web 3270 Client page has been removed. Connect to the TN3270 listener with
the bundled phosphor client from the Pen-Test Shell (`phosphor 127.0.0.1 2233
--client`), which is verified against the frozen build and draws the real logon
screen.

Three course tools are installed on demand rather than frozen in, each with a
one-command setup in the Pen-Test Shell:

    john-setup         jumbo John the Ripper (chapter 8 RACF DES lab)
    bloodhound-setup   BloodHound CE on 127.0.0.1:8080 (chapter 12)
    racfhound-setup    RACFHound, which feeds that BloodHound

john-setup matters more than it looks. The `john` package on Debian and Ubuntu
is the CORE build, which ships neither racf2john nor the RACF crack format, so
the chapter 8 lab cannot run on it; Kali ships the jumbo build and is fine. The
script installs the package, re-checks for racf2john and the RACF format, and
when they are still missing it offers to build jumbo John from source and links
john and racf2john onto the shell PATH. Run `john-setup -y` to build without
being prompted. A verified build reports both RACF and RACF-KDFAES formats.

RACFHound and BloodHound are installed rather than frozen because RACFHound
pulls in pandas and paramiko and BloodHound is a separate server stack; freezing
them would roughly double every installer for a tool that still needs Docker and
a graph database. bloodhound-setup writes a compose file and brings up Postgres,
Neo4j and BloodHound CE bound to 127.0.0.1, then racfhound-setup installs
RACFHound into its own virtualenv and puts it on the shell PATH.
A few call a system binary you install yourself on the machine that runs GIBSON:
whois (EZRecon), libpcap/Npcap (zniff capture), and the x3270 s3270 binary
(cicspwn). `toolbox-setup` in the Pen-Test Shell installs whois along with the
wrapped network tools. The produced installers are unsigned, so Windows SmartScreen and
macOS Gatekeeper may warn on first run until you add code signing.

On macOS the build produces a real GIBSON.app and wraps it the way Mac users
expect. The disk image, GIBSON-<arch>.dmg, is the one to hand out: opening it
shows the GIBSON icon beside an Applications shortcut, you drag one onto the
other, and GIBSON then lives in Applications like any other app. A .pkg is
produced as well and installs the same GIBSON.app; it needs pkgbuild from the
Xcode Command Line Tools, so without those you get the .dmg alone (and a
.tar.gz if even hdiutil fails).

GIBSON is an interactive console program as well as a web service, since the
IPL reply sequence needs a terminal, so the app's executable opens Terminal and
runs the lab there rather than starting silently. It asks for a password once,
because the lab uses the standard mainframe ports 21, 23, 80 and 175 and macOS
reserves anything below 1024 for root. Anyone who would rather avoid that can
run "Start GIBSON (high ports, no sudo).command" from inside
GIBSON.app/Contents/Resources/gibson.

The build is not code-signed, so the first launch on someone else's Mac is
blocked by Gatekeeper. They right-click GIBSON in Applications and choose Open
once, which the disk image's READ ME FIRST.txt explains. Removing that step for
good needs an Apple Developer ID and notarization.

Run build-macos.command on the Mac whose CPU you are targeting, because
PyInstaller does not cross-compile: an Apple Silicon Mac produces the arm64
build and an Intel Mac the x86_64 build, and the arch is written into the file
name so the two never clash. If a double-click on build-macos.command is
refused, that is Gatekeeper on a freshly downloaded file: right-click it and
choose Open the first time, and if your unzip tool stripped the executable bit,
restore it once with "chmod +x build-macos.command".

Both build-macos.command and build-linux.sh behave like build-windows.bat if a
freeze ever stops short: they retry a lean build automatically and write a full
build-log.txt, so you are never left with a half-built folder and no explanation.
