"""
GIBSON launcher (frozen entry point for gibson / gibson.exe).

With NO arguments (the Start Menu shortcut / double-click) it gives the full
operator experience, designed so nothing depends on a full-screen terminal UI
(which is unreliable in a frozen Windows console):

    1. it prints the Master Console web sign-in details,
    2. it runs the IPL reply sequence in this terminal
         R 01,CLPA  R 02,U  R 03,Y  R 04,<4-digit PIN>  R 05,<NAME>  R 06,SKIP
       (equivalent to:  gibson --ipl-prestart-console)
    3. it starts all services (including the dashboard on :8443 and the
       pen-test shell on :8022),
    4. it opens the web Master Console in your browser automatically
         http://127.0.0.1:8443/console
       and keeps the services running in this window (Ctrl+C to stop).

The 8443 web suite carries the nav bar: Dashboard / Master Console / 3270
Client / Pen-Test Shell. Sign in with the dashboard credentials shown in the
terminal (default admin / gibsonadmin!).

With ANY arguments, the launcher is a drop-in for `python -m gibson.cli`,
so every flag still works, e.g.  gibson --diagnose,  gibson --secure --serve.

Special internal mode:  gibson --run-tool <script.py> [args...]
    Runs a bundled pen-test tool script inside GIBSON's own (frozen) Python
    runtime, which carries the tool dependencies. The scope-guarded launchers
    in the pen-test shell use this in frozen builds, where sys.executable is
    the GIBSON binary rather than a Python interpreter.

Writable runtime state (GACF.DB, IPL/boot state, logs, simulated datasets)
lives under %USERPROFILE%\\mfsim (Windows) or ~/mfsim (macOS/Linux) via
GIBSON_SIM_ROOT, so the installed program files stay read-only.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _run_tool_and_exit(argv) -> None:
    """Execute a bundled Python tool inside this (possibly frozen) runtime.

    Usage: gibson --run-tool <script.py> [tool args...]
    The script runs as __main__ with its own argv, using GIBSON's bundled
    interpreter and dependencies. SystemExit from the tool is propagated."""
    if not argv:
        print("[GIBSON] --run-tool needs a script path", file=sys.stderr)
        sys.exit(2)
    script = argv[0]
    tool_argv = argv[1:]
    if not os.path.isfile(script):
        print(f"[GIBSON] --run-tool: script not found: {script}", file=sys.stderr)
        sys.exit(127)
    import runpy
    # Make the tool's own directory importable (tools do `import ezrecon`, etc.)
    tool_dir = os.path.dirname(os.path.abspath(script))
    if tool_dir and tool_dir not in sys.path:
        sys.path.insert(0, tool_dir)
    sys.argv = [script] + list(tool_argv)
    try:
        runpy.run_path(script, run_name="__main__")
        sys.exit(0)
    except SystemExit as exc:
        sys.exit(int(exc.code) if isinstance(exc.code, int) else (0 if exc.code is None else 1))


def _stop_other_gibson() -> None:
    """Terminate any OTHER running GIBSON instance so this one can bind its
    ports (telnet/TSO, TN3270 :2233, dashboard :8443, tools :8022, etc.). This
    fixes the common case where an older gibson.exe is still holding :8443 and
    the browser keeps showing the old UI. Only processes named gibson/gibson.exe
    other than this one are touched, so nothing else is affected."""
    try:
        import psutil
    except Exception:
        return
    me = os.getpid()
    victims = []
    for proc in psutil.process_iter(["pid", "name", "exe"]):
        try:
            if proc.info["pid"] == me:
                continue
            name = (proc.info.get("name") or "").lower()
            exe = os.path.basename((proc.info.get("exe") or "")).lower()
            if name in ("gibson", "gibson.exe") or exe in ("gibson", "gibson.exe"):
                victims.append(proc)
        except Exception:
            continue
    if not victims:
        return
    print(f"[GIBSON] stopping {len(victims)} previous GIBSON instance(s) to free the ports...")
    for proc in victims:
        try:
            proc.terminate()
        except Exception:
            pass
    alive = victims
    try:
        _gone, alive = psutil.wait_procs(victims, timeout=3)
    except Exception:
        alive = victims
    for proc in alive:
        try:
            proc.kill()
        except Exception:
            pass
    import time
    time.sleep(1.0)


def _default_sim_root() -> Path:
    base = os.environ.get("GIBSON_SIM_ROOT")
    if base:
        return Path(base).expanduser()
    return Path.home() / "mfsim"


def _prepare_environment() -> Path:
    sim_root = _default_sim_root()
    os.environ.setdefault("GIBSON_SIM_ROOT", str(sim_root))
    # Master Console web sign-in. Defaults match what the terminal prints and
    # the dashboard's own default (admin / gibsonadmin!).
    os.environ.setdefault("GIBSON_DASHBOARD_USER", "admin")
    os.environ.setdefault("GIBSON_DASHBOARD_PASSWORD", "gibsonadmin!")
    # GIBSON's dedicated TN3270 listener. Connect to it with the bundled
    # phosphor client from the Pen-Test Shell (phosphor 127.0.0.1 2233
    # --client), or with any external 3270 emulator such as c3270.
    os.environ.setdefault("GIBSON_TN3270_PORT", "2233")
    try:
        sim_root.mkdir(parents=True, exist_ok=True)
    except Exception as exc:  # pragma: no cover
        print(f"[warn] could not create sim root {sim_root}: {exc}")
    return sim_root


def _console_url() -> str:
    port = os.environ.get("GIBSON_DASHBOARD_PORT", "8443")
    scheme = "https" if os.environ.get("GIBSON_SECURE") in ("1", "true", "TRUE") else "http"
    return f"{scheme}://127.0.0.1:{port}/console"


def _run_cli(argv_tail):
    """Invoke gibson.cli.main() with a specific argv, returning its exit code."""
    from gibson.cli import main as cli_main
    sys.argv = [sys.argv[0]] + list(argv_tail)
    try:
        cli_main()
        return 0
    except SystemExit as exc:
        return int(exc.code) if isinstance(exc.code, int) else (0 if exc.code is None else 1)


def _open_browser_later(url: str, delay: float = 3.0) -> None:
    import threading

    def _open():
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass

    threading.Timer(delay, _open).start()


def _default_experience(sim_root: Path) -> int:
    user = os.environ.get("GIBSON_DASHBOARD_USER", "admin")
    pw = os.environ.get("GIBSON_DASHBOARD_PASSWORD", "gibsonadmin!")
    url = _console_url()
    line = "=" * 70

    # Each start requires a fresh IPL, exactly like powering on a real machine.
    try:
        (sim_root / ".ipl_complete").unlink()
    except Exception:
        pass

    # The IPL reply sequence now runs in the web Master Console rather than in
    # this window. The console shows the outstanding IEA/IEE requests and takes
    # the replies, which is closer to a real operator console and means a
    # student never has to touch a terminal. Set GIBSON_IPL_TERMINAL=1 to get
    # the old behaviour, where the replies are made here before services start.
    terminal_ipl = os.environ.get("GIBSON_IPL_TERMINAL", "") in ("1", "true", "TRUE", "yes")

    print(line)
    print(" GIBSON mainframe security training simulator")
    print(f" state directory : {sim_root}")
    print(line)

    if terminal_ipl:
        print(" IPL reply sequence (terminal mode) - reply to each request in order:")
        print("   R 01,CLPA    R 02,U    R 03,Y    R 04,<4-digit PIN>")
        print("   R 05,<NAME>  R 06,SKIP")
        print(line)
        sys.stdout.flush()
        rc = _run_cli(["--ipl-prestart-console"])
        if rc not in (0, None):
            print(f"[GIBSON] IPL reply sequence did not complete (exit {rc}); not starting services.")
            return rc
        print()

    print(" MASTER CONSOLE (web)")
    print(" Your browser opens the Master Console automatically at:")
    print(f"     {url}")
    print(" Sign in with:")
    print(f"     Username : {user}")
    print(f"     Password : {pw}")
    print(line)
    if not terminal_ipl:
        print(" THE SYSTEM IS WAITING TO BE IPLed.")
        print(" Answer the outstanding requests in the Master Console command line,")
        print(" one at a time, in this order:")
        print("     R 01,CLPA    R 02,U    R 03,Y    R 04,<4-digit PIN>")
        print("     R 05,<NAME>  R 06,SKIP")
        print(" The console shows each request as it comes up and reports IPL")
        print(" complete when the last reply is accepted.")
        print(line)
    print(" The nav bar also has the Pen-Test Shell.")
    print(" Leave this window open while you use GIBSON. Press Ctrl+C to stop.")
    print(line)
    sys.stdout.flush()

    _open_browser_later(url, delay=3.0)

    # Full GIBSON training stack, matching gibsonctl.sh `start`, plus the
    # pen-test browser shell (--with-tools) on :8022 and the Office Mail SMTP
    # listener (--with-smtp) on :25. SMTP has to be asked for explicitly on the
    # command line, which meant that double-clicking the app started everything
    # EXCEPT the mail listener, so port 25 was never there for the chapter 6
    # scan or the M.8 exercises. It binds loopback only and refuses to relay,
    # and if the port is taken the CLI says so and carries on without it.
    return _run_cli([
        "--serve", "--with-ftp", "--with-tn3270",
        "--with-app8080", "--with-cbsa-api",
        "--with-dvca", "--with-dvca-web", "--with-fibs-web",
        "--with-tools", "--with-smtp",
    ])


def _run_python_and_exit(argv) -> None:
    """gibson --python [ARGS]: GIBSON's own Python, as `python3` would be.

    A frozen GIBSON (the Mac app) has no python3 beside it, only its own
    interpreter with every course package inside it, so the Pen-Test Shell's
    python3 and python come here. It takes the forms students use: a script
    with its arguments, -c CODE, -m MODULE, -V/--version, and nothing for an
    interactive prompt. (pip cannot add to a frozen GIBSON.)"""
    import runpy
    if not argv:
        import code
        code.interact(banner=f"Python {sys.version.split()[0]} (GIBSON's own, with the course packages)",
                      local={"__name__": "__main__"})
        sys.exit(0)
    head, rest = argv[0], list(argv[1:])
    try:
        if head in ("-V", "--version"):
            print(f"Python {sys.version.split()[0]}")
            sys.exit(0)
        if head == "-c":
            sys.argv = ["-c"] + rest[1:]
            exec(compile(rest[0] if rest else "", "<string>", "exec"), {"__name__": "__main__"})
            sys.exit(0)
        if head == "-m":
            if not rest:
                print("Argument expected for the -m option", file=sys.stderr); sys.exit(2)
            if rest[0] == "pip":
                print("pip cannot add packages to this GIBSON's own Python; every course package is already in it.",
                      file=sys.stderr)
                sys.exit(1)
            sys.argv = [rest[0]] + rest[1:]
            runpy.run_module(rest[0], run_name="__main__", alter_sys=True)
            sys.exit(0)
        _run_tool_and_exit(argv)
    except SystemExit as exc:
        sys.exit(int(exc.code) if isinstance(exc.code, int) else (0 if exc.code is None else 1))


def main() -> None:
    # Security tools bundled beside this program (the macOS build packs nmap,
    # hydra, nikto, wget, s3270 and John into tools/): put them on PATH first,
    # so every tool GIBSON runs, and the Pen-Test Shell it starts, finds them.
    try:
        from gibson.core import bundled_tools
        bundled_tools.add_to_path()
    except Exception:
        pass
    # Internal tool-runner mode (used by the pen-test shell in frozen builds).
    if len(sys.argv) >= 2 and sys.argv[1] == "--run-tool":
        _run_tool_and_exit(sys.argv[2:])
        return
    if len(sys.argv) >= 2 and sys.argv[1] == "--python":
        _run_python_and_exit(sys.argv[2:])
        return
    # PHOSPHOR, built into GIBSON: gibson --phosphor [ARGS] is `phosphor ARGS`,
    # so the Start menu and desktop can open its GUI (gibson --phosphor --gui).
    if len(sys.argv) >= 2 and sys.argv[1] == "--phosphor":
        from phosphor.cli import main as phosphor_main
        sys.argv = ["phosphor"] + sys.argv[2:]
        sys.exit(phosphor_main(sys.argv[1:]))

    sim_root = _prepare_environment()

    if len(sys.argv) == 1:
        _stop_other_gibson()
        rc = _default_experience(sim_root)
        sys.exit(rc)

    serving = any(a == "--serve" for a in sys.argv)
    if serving:
        _stop_other_gibson()
    from gibson.cli import main as cli_main
    try:
        cli_main()
    finally:
        if not serving:
            _pause_if_own_console()


def _pause_if_own_console() -> None:
    """On Windows, gibson.exe asks for administrator rights, so `gibson
    --list-volumes` typed in an ordinary Command Prompt runs in a new elevated
    console that would close the moment the command finishes. When this
    process is the only one attached to its console, wait for Enter so the
    output can be read. In an administrator Command Prompt nothing changes."""
    if os.name != "nt":
        return
    try:
        import ctypes
        buf = (ctypes.c_uint32 * 4)()
        if ctypes.windll.kernel32.GetConsoleProcessList(buf, 4) <= 1:
            input("\nPress Enter to close this window.")
    except Exception:
        pass


if __name__ == "__main__":
    main()
