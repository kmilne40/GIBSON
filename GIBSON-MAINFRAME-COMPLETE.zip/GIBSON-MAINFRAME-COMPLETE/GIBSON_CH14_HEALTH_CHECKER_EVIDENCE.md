# GIBSON Chapter 14 Health Checker Evidence

## Purpose

This file records the technical evidence used to implement the Chapter 14 Health Checker material and the matching GIBSON simulation. It is an engineering and editorial evidence file, not manuscript prose.

The implementation target is IBM Health Checker for z/OS as documented for z/OS 3.2. The supplied cumulative GIBSON code tree was treated as the source of truth for simulator behavior. Existing Markdown, text summaries, and changelogs were not used to infer current implementation behavior.

Research and validation date: **2026-10-03**.

## Authoritative working sources

- GIBSON source base: `GIBSON-MAINFRAME-CH10-13-14-CUMULATIVE.zip`
- Chapter source: `chapter14_hacking_mainframes_kev_final.docx`
- z/OS research target: **IBM z/OS 3.2**

Baseline GIBSON focused Chapter 10/13/14 suite before any Health Checker changes:

```text
62 passed, 32 warnings in 3.99s
```

The warnings were existing Python deprecation warnings, principally `datetime.utcnow()` and positional `maxsplit` usage.

## IBM documentation researched

The IBM documentation below was used as the primary technical authority. Some individual check pages retain older URL release labels even when the check explicitly applies to current releases; where that occurred, the applicability statement was checked before using the material.

### IBM Health Checker architecture and purpose

**Abstract for IBM Health Checker for z/OS**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=level-health-checker-zos-users-guide

Evidence used:

- Health Checker examines current active z/OS and sysplex settings and definitions.
- It compares them with IBM or installation recommendations.
- IBM explicitly describes it as a continuously running preventative and not as a diagnostic or monitoring tool.
- Its output consists of detailed messages describing potential problems and suggested actions.

This supports the manuscript distinction that Health Checker answers whether configuration currently deviates from recommended practice, while SMF, zERT, and subsystem telemetry provide evidence of activity that occurred.

### SDSF CK panel

**Health Check panel (CK)**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=panels-health-check-panel-ck

Evidence used:

- `CK` can be issued from an SDSF panel.
- IBM documents `CK (category|E|EH|EM|EL|EN|D|ALL)`.
- CK actions include Activate, Display, Refresh, Deactivate, Run, history, browse, and print.
- The panel separates `NAME`, `CheckOwner`, `State`, `Status`, and `Result`.
- IBM lists states/statuses including `INACTIVE`, `ENV N/A`, `SUCCESSFUL`, `EXCEPTION-LOW`, `EXCEPTION-MEDIUM`, and `EXCEPTION-HIGH`.

GIBSON implements a deliberately compact subset of the CK panel so it remains usable in its terminal width. It preserves the important separate columns for NAME, owner, state, status, and result. The compact training panel displays `EXCEPTION-MED` to align with the HZS detail/status form used by the book rather than spelling out `EXCEPTION-MEDIUM` in the CK row.

### Starting Health Checker and HZSPROC

**Starting IBM Health Checker for z/OS**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=command-starting-health-checker-zos

**Stopping and starting IBM Health Checker for z/OS manually**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=zos-stopping-starting-health-checker-manually

Evidence used:

- Health Checker normally starts automatically with z/OS.
- The default procedure is `HZSPROC`.
- IBM's standard HZSPROC uses `HZSPRM=PREV`.
- At the initial IPL, `PREV` behaves like `SYSPARM`, taking HZSPRM suffixes from the `HZS` system parameter.
- `STOP HZSPROC` stops the Health Checker started task. It is not the way to deactivate an individual check.

### HZSPRMxx and HZS= configuration

**Guidelines for HZSPRMxx parmlib members**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=command-guidelines-hzsprmxx-parmlib-members

**Specifying the HZSPRMxx members you want the system to use**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=checks-specifying-hzsprmxx-members-you-want-system-use

Evidence used:

- IBM supplies `HZSPRM00` as an optional default member with comments rather than mandatory site policy statements.
- HZSPRM members can be selected by the `HZS` system parameter in IEASYSxx.
- The standard procedure uses `HZSPRM='PREV'` and `PGM=HZSINIT` with `PARM='SET PARMLIB=&HZSPRM'`.

GIBSON therefore exposes:

```text
SYS1.PARMLIB(IEASYS00)  -> HZS=00
SYS1.PROCLIB(HZSPROC)   -> PROC HZSPRM='PREV', PGM=HZSINIT
SYS1.PARMLIB(HZSPRM00)  -> training/default-style policy member
```

These members are discoverable training representations. The Python Health Checker remains the live simulator implementation. The members are not falsely presented as an actual z/OS IPL parser controlling Python code.

### MODIFY HZSPROC commands

**Cheat sheet: examples of MODIFY hzsproc commands**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=command-cheat-sheet-examples-modify-hzsproc-commands

Evidence used:

- `F hzsproc,RUN,CHECK=(owner,name)` is a valid one-time run operation.
- `ACTIVATE`, `DEACTIVATE`, `REFRESH`, and `UPDATE` are Health Checker operations.
- A user does not manually enable or disable a check in the same sense. Health Checker can place checks in enabled/disabled controlled states depending on environmental conditions.

Implemented book-facing command subset:

```text
F HZSPROC,DISPLAY,CHECKS
F HZSPROC,DISPLAY,CHECK=(owner,name),DETAIL
F HZSPROC,RUN,CHECK=(owner,name)
F HZSPROC,ACTIVATE,CHECK=(owner,name)
F HZSPROC,DEACTIVATE,CHECK=(owner,name)
F HZSPROC,REFRESH,CHECK=(owner,name)
```

This is intentionally not a complete HZSPRM/MODIFY parser.

### HZS0201I and state/status separation

**HZS0201I**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=messages-hzs0201i

Evidence used:

- Detailed Health Checker display identifies owner and check name.
- `ACTIVE(ENABLED)` and `ACTIVE(DISABLED)` are distinct controlled states.
- Status describes the result of the last run and is separate from state.
- Detail output can include interval, last run, next scheduled run, severity, parameters, and other check attributes.

GIBSON now models state and status separately instead of using `ACTIVE` as both concepts.

### HZS0001I, HZS0002E, HZS0003E, HZS0004I

**Using HZS exception messages for automation**  
https://www.ibm.com/docs/en/zos/2.5.0?topic=zos-using-hzs-exception-messages-automation

The semantics remain applicable to current Health Checker behavior and are also reflected in current z/OS 3.2 message documentation.

Evidence used:

- `HZS0001I` is the low/informational exception wrapper.
- `HZS0002E` is the medium/eventual-action exception wrapper.
- `HZS0003E` is the high/critical-eventual-action exception wrapper.
- `HZS0004I` is the hardcopy-only wrapper.
- The HZS wrapper is followed by the component-specific exception message.

The old GIBSON use of these IDs as generic "started", "stopped", or "refreshed" acknowledgements was removed.

### HZSPRINT

**Using the HZSPRINT utility**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=output-using-hzsprint-utility

Evidence used:

- HZSPRINT is a batch utility.
- The program name is `HZSPRNT`.
- It writes Health Checker message-buffer output to SYSOUT.
- It can select one, multiple, or all checks.

GIBSON no longer presents `HZSPRINT` as if it were an MVS console summary command. Full `PGM=HZSPRNT` batch simulation was deliberately left outside the book-grade scope.

## JES_NJE_SECURITY evidence

**JES_NJE_SECURITY and JES_NJE_SECURITY_ssname**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=ibmjes-jes-nje-security-jes-nje-security-ssname

This check applies to JES2/JES3 NJE configurations and remains relevant to the z/OS 3.2 target. It verifies security-related NJE parameters, particularly for nodes the installation security product considers trusted.

The IBM check has dynamic severity behavior and a default low check severity. GIBSON models this as:

```text
CHECK SEVERITY: LOW-DYNAMIC
INTERVAL: 06:00
```

An insecure trusted socket can still generate a medium-severity exception.

**IAZH119E**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=messages-iazh119e

The message identifies sockets for trusted nodes that specify `SECURE=NO`. This is directly relevant to the Chapter 10 HAL training path.

**IAZH200I**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=messages-iazh200i

Used as the successful training result when the simulated JES_NJE_SECURITY evaluator finds no modeled NJE security errors.

### GIBSON live-state mapping

`JES_NJE_SECURITY` does not return a hard-coded result. It evaluates:

- actual RACF `RACFVARS &RACLNDE` membership in the GIBSON dynamic RACF state;
- actual GIBSON NJE node password/sign-on/security state represented by `NJENode`;
- actual socket/line `secure` state;
- the minimal additional NJE properties required for a meaningful Health Checker training result.

Initial HAL state produces:

```text
HZS0201I HEALTH CHECKER CHECK DETAIL
 CHECK(IBMJES,JES_NJE_SECURITY)
 STATE: ACTIVE(ENABLED)
 STATUS: EXCEPTION-MED
 CHECK SEVERITY: LOW-DYNAMIC
 INTERVAL: 06:00
HZS0002E CHECK(IBMJES,JES_NJE_SECURITY):
 IAZH119E 1 sockets for trusted nodes have specified SECURE=NO
 FINDING: HAL SOCKET(HAL) has SECURE=NO specified IAZH119E
```

The dynamic training remediation:

```text
$T SOCKET(HAL),SECURE=YES
```

updates the real GIBSON NJE runtime state. Rerunning:

```text
F HZSPROC,RUN,CHECK=(IBMJES,JES_NJE_SECURITY)
```

then produces:

```text
STATUS: SUCCESSFUL
IAZH200I The check has not found any errors in the JES2 NJE setup for local node GIBSON
```

This does **not** claim that GIBSON has created a real TLS session or real certificate relationship. It proves only that the simulated NJE security state used by the GIBSON Health Checker has changed. The manuscript explicitly keeps that training boundary visible.

## RACF Health Checker evidence

### RACF_ENCRYPTION_ALGORITHM

**RACF_ENCRYPTION_ALGORITHM**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=ibmracf-racf-encryption-algorithm

Evidence used:

- The check verifies that KDFAES is used for RACF password protection.
- IBM default severity is medium and interval is 24 hours.
- Non-KDFAES behavior includes `IRRH293E` / `IRRH295E` and an exception result.
- Successful KDFAES behavior includes `IRRH299I No exceptions are detected.`

GIBSON now reads its live password-policy algorithm. Changing the active SETROPTS training state changes the Health Checker result.

### RACF_PASSWORD_CONTROLS

**RACF_PASSWORD_CONTROLS**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=ibmracf-racf-password-controls

IBM default target values used:

```text
MIXEDCASE(YES)
REVOKE(3)
INTERVAL(90)
INITSTATS(YES)
PHRASEINT(365)
```

IBM default check severity is medium and interval is 24 hours. The check uses `IRRH283E` for exceptions and `IRRH284I` when no exceptions are detected.

GIBSON evaluates its live password-policy state for these controls rather than a static string.

### RACF_PROTECTALL_FAIL

**RACF_PROTECTALL_FAIL**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=ibmracf-racf-protectall-fail

The check validates that unprofiled datasets are denied and recommends `PROTECTALL(FAIL)`. GIBSON distinguishes:

- no PROTECTALL;
- PROTECTALL(WARNING);
- PROTECTALL(FAIL).

### RACF_SENSITIVE_RESOURCES

**RACF_SENSITIVE_RESOURCES**, z/OS 3.2  
https://www.ibm.com/docs/en/zos/3.2.0?topic=ibmracf-racf-sensitive-resources

Evidence used:

- The check evaluates sensitive system datasets and resources.
- For dataset protection it examines the covering profile, UACC, WARNING, and ID(*) where present.
- Missing profiles are considered in relation to PROTECTALL state.
- APF datasets can have maximum public access of READ. Public UPDATE/CONTROL/ALTER is a different risk.
- Explicit access by a legitimate privileged administrator is not the same as public UACC or ID(*) write access.

The old GIBSON APF evaluator treated any explicit UPDATE/CONTROL/ALTER permit as a broad exposure. That was replaced. The new evaluator focuses on the public/covering-profile protection model and does not mark `SYS1.LINKLIB` insecure merely because a named administrator has ALTER authority.

GIBSON uses high severity and an eight-hour interval for this check, matching the IBM check description used during research.

### CSFKEYS and CSFSERV class checks

The GIBSON checks:

```text
IBMRACF,RACF_CSFKEYS_ACTIVE
IBMRACF,RACF_CSFSERV_ACTIVE
```

are tied to the live GIBSON RACF class-activation state. They do not simply claim that cryptographic resource classes are active.

## ICSF Health Checker evidence

**Summary of changes for z/OS 3.1**, shown in z/OS 3.2 documentation  
https://www.ibm.com/docs/en/zos/3.2.0?topic=sc-summary-changes-zos-31-155

This records `ICSF_CLEAR_KEYS` and `ICSF_STATUS` as Health Checker additions introduced with z/OS 3.1.

**Two new ICSF health checks: ICSF_STATUS and ICSF_CLEAR_KEYS**  
https://www.ibm.com/docs/en/zos/3.1.0?topic=icsf-two-new-health-checks-status-clear-keys

Evidence used:

- `ICSF_STATUS` periodically checks whether ICSF is active, inactive, or ended abnormally.
- `ICSF_CLEAR_KEYS` scans active CKDS, PKDS, or TKDS contents for clear key objects.

GIBSON has meaningful state for whether its ICSF training control plane is started, so `IBMICSF,ICSF_STATUS` is implemented against live simulator state.

GIBSON does **not** contain real CKDS/PKDS/TKDS key records. Therefore `IBMICSF,ICSF_CLEAR_KEYS` is registered visibly but disabled and returns `ENV N/A`. Reporting "no clear keys" merely because GIBSON has no real key objects would be misleading.

Likewise, GIBSON does not model actual Crypto Express coprocessors/domains with independent master-key states. `IBMICSF,ICSF_MASTER_KEY_CONSISTENCY` is therefore registered disabled and returns `ENV N/A` rather than a false success.

## What GIBSON intentionally simplifies

GIBSON is a training simulator and does not reproduce every Health Checker control block, message-buffer behavior, logger, history record, policy parser, SDSF field, or shipped IBM check.

Intentional simplifications include:

- a focused ten-check registry instead of the complete IBM check catalog;
- a compact SDSF CK panel with the columns required by the manuscript;
- a limited `F HZSPROC` verb set rather than the complete HZSPRM/MODIFY grammar;
- structural HZS0200I/HZS0201I-style output, not byte-for-byte IBM panel reproduction;
- no System Logger/CKH history implementation;
- no full HZSPRM policy engine;
- no full HZSPRNT batch utility;
- no real NJE TLS handshake/certificate setup from `$T SOCKET(...),SECURE=YES`;
- no real Crypto Express hardware, clear-key records, or per-coprocessor master-key state.

Where the required state does not exist, the simulation uses `ENV N/A` or disables the check instead of claiming success.

## Live simulation state versus inspectable reference configuration

The following are live Python simulation state and affect check results:

- RACF `RACFVARS &RACLNDE` membership;
- NJE node and socket state;
- RACF password policy / SETROPTS training state;
- PROTECTALL training state;
- APF list and RACF DATASET profiles;
- CSFKEYS/CSFSERV class activation state;
- GIBSON ICSF started state.

The following members are provided so a reader can find the same configuration relationships discussed in the book:

```text
SYS1.PARMLIB(IEASYS00)
SYS1.PROCLIB(HZSPROC)
SYS1.PARMLIB(HZSPRM00)
```

These files are inspectable training representations. They do not silently replace the Python simulator's live state engine.

## Code changes

Modified from the authoritative cumulative GIBSON source:

```text
gibson/core/healthcheck.py
gibson/core/state.py
gibson/core/security_freeze.py
gibson/core/nje.py
gibson/core/sys1_library.py
gibson/core/datasets.py
gibson/apps/master_console.py
gibson/apps/sdsf.py
gibson/apps/tso.py
```

Added:

```text
tests/test_health_checker_zos32.py
GIBSON_CH14_HEALTH_CHECKER_EVIDENCE.md
```

## Dataset/member additions and changes

Added or extended:

```text
SYS1.PARMLIB(IEASYS00)  - adds HZS=00 to the training system parameters
SYS1.PROCLIB(HZSPROC)   - inspectable Health Checker started procedure
SYS1.PARMLIB(HZSPRM00)  - inspectable default-style training policy member
```

No unrelated Chapter 10, 13, or 14 datasets were intentionally removed or renamed.

## Automated test evidence

### Baseline before modification

Focused Chapter 10/13/14 suite against the untouched authoritative cumulative source:

```text
62 passed, 32 warnings in 3.99s
```

### Final focused suite

The same baseline suite plus the new dedicated Health Checker tests:

```text
75 passed, 32 warnings in 5.65s
```

This includes the existing Chapter 10 NJE/JES2/SMF tests, Chapter 13 zERT/configuration tests, Chapter 14 evidence/crypto tests, NJElib interoperability tests, CICS/Db2/z/OS Connect SMF tests, and the new Health Checker tests.

### Dedicated Health Checker tests

`tests/test_health_checker_zos32.py` covers:

- CK panel rendering and exception filters;
- separate owner/name identity;
- HZSPROC DISPLAY and DETAIL;
- RUN, ACTIVATE, DEACTIVATE, REFRESH;
- unknown-check behavior;
- live JES_NJE_SECURITY exception and remediation to SUCCESSFUL;
- KDFAES live-state transition;
- RACF password controls;
- PROTECTALL states;
- sensitive-resource public exposure versus legitimate administrator access;
- missing-profile behavior and PROTECTALL;
- CSFKEYS/CSFSERV class state;
- ICSF_STATUS live state;
- `ENV N/A` for unsupported ICSF hardware/key-object checks;
- HZS wrapper severity;
- preservation of generic non-HZSPROC MODIFY behavior;
- HZSPROC/HZSPRM/IEASYS member discoverability;
- retirement of misleading HZSPRINT console behavior.

## Broad regression result

A complete repository `pytest -q` run was started. The repository is large enough that the run exceeded the available execution window before completion. It reached approximately 23 percent in the first broad run and showed two failures before timeout.

Each observed failure was isolated and run independently against both the modified build and the untouched supplied baseline. Both reproduced identically on the untouched baseline and are therefore classified as **PRE-EXISTING**, not regressions introduced by the Health Checker work.

### Pre-existing failure 1

```text
tests/lang/test_rexx_hostsvc.py::test_signal_on_error
```

Both trees return:

```text
["'NO.SUCH.DATASET' NOT IN CATALOG", 'trapped rc 8']
```

while the test expects only:

```text
['trapped rc 8']
```

### Pre-existing failure 2

```text
tests/test_book_enhancements.py::test_book_network_racf_apf_rexx_smoke
```

Both trees fail because the test expects `SYS1.VULNAPF.LIB` in `EX SYS0WN.RX` output and the current source does not include that string in that output.

After excluding those two known failing modules, a further broad run reached approximately 29 percent before its execution window expired with no additional failures observed during that run.

No newly introduced regression was found in the executed focused or broad-regression windows.

## Manuscript evidence mapping

The new Chapter 14 subsection is intentionally short and sits in **Turn Hardening into Continuous Assurance**, immediately after the explanation of configuration drift and before the existing assurance-rhythm table.

Substantive manuscript statements map to evidence as follows:

| Manuscript statement | IBM evidence |
|---|---|
| Health Checker is preventative configuration assurance, not a replacement for runtime evidence | IBM Health Checker z/OS 3.2 User's Guide abstract/introduction |
| SDSF `CK` shows checks and separates name, owner, state, status and result | z/OS 3.2 SDSF Health Check panel (CK) |
| `SUCCESSFUL`, exception levels and `ENV N/A` are Health Checker statuses | z/OS 3.2 SDSF CK documentation and HZS0201I |
| Health Checker normally starts automatically and uses HZSPROC | z/OS 3.2 Starting IBM Health Checker for z/OS |
| `HZSPRM=PREV` and HZS/IEASYSxx relationship | z/OS Health Checker HZSPRM documentation |
| `F HZSPROC,DISPLAY...` and `RUN` are operator interfaces | z/OS 3.2 MODIFY HZSPROC documentation |
| HZS0002E is a medium/eventual-action exception wrapper | IBM HZS exception-message documentation |
| `JES_NJE_SECURITY` checks trusted-node NJE security configuration | IBMJES JES_NJE_SECURITY description |
| `IAZH119E` identifies trusted-node sockets with SECURE=NO | IBM JES2 IAZH119E message documentation |
| Health Checker and SMF answer different questions | IBM Health Checker architecture plus the existing Chapter 14 SMF evidence model |

## Chapter 14 scope and document QA

The new material uses one subsection and one new listing. No new figure was added.

Before Health Checker addition:

```text
Word count: 7382
Rendered pages: 21
Listings: 6
Figures: 7
Tables: 6
SEQ fields: 19
REF fields: 13
```

After Health Checker addition:

```text
Word count: 8027
Rendered pages: 23
Listings: 7
Figures: 7
Tables: 6
SEQ fields: 20
REF fields: 14
Unresolved REF targets: 0
Tracked insertions: 0
Tracked deletions: 0
```

Net manuscript growth is approximately 645 words and 2 rendered pages, within the implementation prompt's 600-900 word and approximately two-page limits.

The complete 23-page final DOCX was rendered and visually inspected. The Health Checker material uses the existing publisher styles, including `HeadB`, `Body`, `Literal`/`LiteralBold`, `Code`, `CodeWide`, and `CodeListingCaption`. The new listing uses a real `SEQ Listing` field and the narrative reference uses a real bookmark/`REF` field. Existing figure and table counts are unchanged.

No unresolved Word cross-reference target was found. No tracked-change markup was introduced.

## Remaining known gaps

| Area | Status | Remaining gap | Book impact | Recommended action |
|---|---|---|---|---|
| Health Checker core | Book-grade focused simulation | Not a complete HZS framework or full IBM check catalog | None for the new subsection | Keep scope focused unless a later chapter needs additional checks |
| SDSF CK | Implemented | Compact panel does not expose every IBM CK column/action/history function | Low | Add CKH/history only if the book later teaches check history |
| HZSPRM | Inspectable member + selected command subset | No complete persistent policy parser or policy history | Low | Add only if a future exercise requires policy override behavior |
| HZSPRINT/HZSPRNT | Misleading console command retired | Full `PGM=HZSPRNT` batch utility is not simulated | None for Chapter 14 | Leave as future enhancement unless batch export becomes a book requirement |
| ICSF_CLEAR_KEYS | `ACTIVE(DISABLED)` / `ENV N/A` | No real CKDS/PKDS/TKDS key records | Positive honesty boundary | Do not implement until a synthetic key-object model exists |
| ICSF_MASTER_KEY_CONSISTENCY | `ACTIVE(DISABLED)` / `ENV N/A` | No per-coprocessor/domain master-key state | Positive honesty boundary | Do not fake success; add only with a real training coprocessor/domain model |
| JES TLS remediation | Health Checker state is dynamic | `$T SOCKET(HAL),SECURE=YES` changes simulator state but does not create real certificates/TLS negotiation | Explicitly noted in manuscript | Preserve caveat; real TLS remains outside GIBSON's NJE transport model |
| Broad repository pytest | Partial | Full suite exceeded execution window | None if reported accurately | Continue full-suite cleanup separately; two observed failures are proven pre-existing |

## Final technical conclusion

The Health Checker addition is suitable for Chapter 14 because it creates a direct defensive assurance loop across the book:

```text
Chapter 10: identify and abuse weak NJE trust
Chapter 13: harden the trust relationship
Chapter 14: use Health Checker to detect configuration drift
SMF/zERT: preserve evidence of what actually happened
```

The simulator now supports that loop using live GIBSON state instead of fixed demonstration strings, while explicitly returning `ENV N/A` where GIBSON lacks the cryptographic or hardware state necessary for an honest result.
