# Course-mode validation, 9 November 2026

Validation platform: Python simulator executed on the working Linux host; not IBM z/OS or RACF. Source code adapted from attached `GIBSON-MAINFRAME-COMPLETE-V1(10).zip`.

- `pytest -q tests/test_racf_course_091126.py`: **5/5 pass**. Existing RACF regressions + course tests: **33/33 pass**.
- Independent sequential command-runner: **32/32 labs**, **152 commands**, **all 32 RACFCOURSE CHECK** responses `READY` on fresh state.
- Twelve naive text-scan REVIEW hits in the full transcript are false-positive keywords inside ordinary `LISTUSER` informational fields (`NOT DEFINED`) or the intended Health Checker `EXCEPTION` findings. They are not blocked dependency checks.
- Positive read of `PAYROLL.REPORT1` and `PAYROLL.REPORTS.DAILY` after generic `PAYROLL.**` permit: pass.
- Controlled read/deny/restore on `PAYROLL.MASTER`: pass.
- Explicit failure on nonexistent superior group and reused OMVS GID: pass.
- Capstone twelve-finding seed, check, reset and removal: pass.
- Prepared simulator state survives reload: pass.

**Limits**: The exercises are simulated. Passing the corrected source command sequence does not prove real RACF command authority, IBM utilities, program-control semantics, IMS/CICS/Db2 security exits, kernel ACL enforcement or IBM Health Checker behaviour. Interactive multi-learner deployment not executed in this test.
