# Six-Day RACF Security Course

## Using, Securing and Auditing RACF

The course runs on GIBSON's opt-in RACFCOURSE engine (`gibson/course_racf/`), which adds threat-led exercises and synthetic SMF audit evidence to the simulator.

**48 hands-on labs over six training days: 32 updated foundational labs plus 16 advanced labs.** The student/master manual embeds worked answers for all 48; the separate instructor guide has teaching notes, demonstration scripts, evidence interpretation and marking guidance. Both documents also have PDF copies.

### Where to find the deliverables

- `course_091126/manual/RACF_48_Lab_Master_Manual_With_Answers.docx` (master learner manual and all answers)
- `course_091126/manual/RACF_48_Lab_Master_Manual_With_Answers.pdf` (print/reading)
- `course_091126/manual/RACF_48_Lab_Instructor_Guide.docx`
- `course_091126/manual/RACF_48_Lab_Instructor_Guide.pdf`

### Starting one isolated learner instance

Run these commands from the `GIBSON-MAINFRAME-COMPLETE` folder, on Linux or macOS, after installing GIBSON with `./install_gibson.sh --venv`:

```sh
./course_091126/scripts/prepare-racf-course.sh student01
./course_091126/scripts/start-racf-course.sh student01
```

The preparation script sets `GIBSON_RACF_COURSE=1`, creates an isolated simulator state root (default `~/gibson-racf-audit/student01`) and seeds parent groups, instructor identities and reusable lab fixtures. It writes random setup credentials to a local mode-0600 file outside the distributed source tree. Use a **different instance and a different port set for each concurrent student**, or separate lab VMs/containers. Startup defaults to loopback rather than public network exposure.

### Course control and evidence commands

These `RACFCOURSE` commands are **simulator-only**, not IBM RACF z/OS commands:

```
RACFCOURSE PREPARE
RACFCOURSE PREFLIGHT
RACFCOURSE CHECK 1.3
RACFCOURSE CHECK 5.1
RACFCOURSE CHECK 6.8
RACFCOURSE INVENTORY
RACFCOURSE SCENARIO ACCESS
RACFCOURSE SCENARIO SETROPTS
RACFCOURSE SCENARIO SURROGATE
RACFCOURSE SCENARIO PRIVILEGE
RACFCOURSE SCENARIO CAMPAIGN
RACFCOURSE SMF LIST
RACFCOURSE SMF TYPE 80
RACFCOURSE SMF TYPE 119/11
RACFCOURSE SMF JOIN
RACFCOURSE DETECT
RACFCOURSE TTP
RACFCOURSE ACTORS
RACFCOURSE CASEFILE
RACFCOURSE SESSIONCHECK DEVUSR
RACFCOURSE REVOKE DEVUSR
RACFCOURSE SESSIONCHECK DEVUSR
RACFCOURSE CONTAIN DEVUSR
RACFCOURSE SESSIONCHECK DEVUSR
RACFCOURSE UNCONTAIN DEVUSR
RACFCOURSE SESSIONCHECK DEVUSR
RACFCOURSE RESUME DEVUSR
RACFCOURSE SESSIONCHECK DEVUSR
```

Other scenario names are ACCESS, SETROPTS, COMPONENT, MULTISOURCE, SURROGATE, PRIVILEGE, RECON, DB2, INSIDER, CAMPAIGN and RESET. Events include **synthetic** SMF 30, 80, 81, 83, 119 (subtypes 11/12), and 1154 (subtype 83). Their descriptions are teaching analogues, not a guarantee of IBM-record format/semantics or byte-for-byte output. No actual MVS SMF/SAF/Db2/USS packet capture takes place. Threat actors are discussed as hypothetical motives/capability models; no attribution can be concluded from sample synthetic events alone. Some commands implement teaching analogues of behaviour rather than every real RACF operand.

### Lab programme

- Days 1 to 4: 32 foundational labs covering identity, permissions, datasets, general resources, auditing, USS and Db2.
- Day 5: 8 new labs about evidence inventory, SMF 80/81/83/1154, zERT and correlation, SURROGAT, BPX/APF, detection engineering.
- Day 6: 8 new labs about TTPs, reconnaissance, privileged Db2 access, account containment, timelines, insider scenarios, attribution and final investigation.

### Deployment and security notes

- The course engine is **opt-in** through `GIBSON_RACF_COURSE=1`, so GIBSON behaves as normal unless it is set.
- Lab examples deliberately contain insecure configurations and simulated offensive activity; use a private training network.
- Do **not** execute `RACFCOURSE` strings against a real IBM RACF database. On real z/OS, use IBM-documented syntax and site-authorised operations.
- Leave cumulative lab objects in place until all dependent labs are complete; perform cleanup only during instructor-approved resets.

The instructor guide includes all 144 knowledge-check questions with their answers, and the simulated REVOKE, CONTAIN, UNCONTAIN and RESUME lab. The course-only SESSIONCHECK command shows the effect of those steps on a session; it does not perform native RACF or SAF enforcement.
