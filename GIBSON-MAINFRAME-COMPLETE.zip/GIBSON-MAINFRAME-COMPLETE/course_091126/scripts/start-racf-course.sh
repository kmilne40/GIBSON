#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
STUDENT="${1:-student01}"
if [[ ! "$STUDENT" =~ ^[a-zA-Z0-9_-]+$ ]]; then echo 'Invalid student ID' >&2; exit 2; fi
export GIBSON_RACF_COURSE=1
export GIBSON_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/gibson-racf-audit/$STUDENT}"
export GIBSON_GEO_ONLINE_ENABLED=0
export GIBSON_CTI_ONLINE_ENABLED=0
export GIBSON_HOST="${GIBSON_HOST:-127.0.0.1}"
export GIBSON_PORT="${GIBSON_PORT:-2323}"
export GIBSON_FTP_PORT="${GIBSON_FTP_PORT:-2121}"
export GIBSON_USS_PORT="${GIBSON_USS_PORT:-2202}"
export GIBSON_ZVM_PORT="${GIBSON_ZVM_PORT:-3323}"
export GIBSON_DB2_TCP_PORT="${GIBSON_DB2_TCP_PORT:-1446}"
export GIBSON_DB2_WS_PORT="${GIBSON_DB2_WS_PORT:-50001}"
export GIBSON_NJE_PORT="${GIBSON_NJE_PORT:-2175}"
export GIBSON_DASHBOARD_PORT="${GIBSON_DASHBOARD_PORT:-8443}"
export GIBSON_WEB_TERMINAL_PORT="${GIBSON_WEB_TERMINAL_PORT:-8023}"
export GIBSON_FIBS_WEB_PORT="${GIBSON_FIBS_WEB_PORT:-9080}"
export GIBSON_WELCOME_PORT="${GIBSON_WELCOME_PORT:-8088}"
cd "$ROOT"
printf 'Starting GIBSON-RACFnAUDIT-091126 (%s) on %s:%s\n' "$STUDENT" "$GIBSON_HOST" "$GIBSON_PORT"
exec "${PYTHON_BIN:-python3}" -m gibson.cli --serve --no-welcome --no-fibs-web --no-zvm --no-nje --no-lennox --host "$GIBSON_HOST" --port "$GIBSON_PORT"
