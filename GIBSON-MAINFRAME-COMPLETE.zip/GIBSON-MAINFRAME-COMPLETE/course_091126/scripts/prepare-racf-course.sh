#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
STUDENT="${1:-student01}"
if [[ ! "$STUDENT" =~ ^[a-zA-Z0-9_-]+$ ]]; then echo 'Student identifier must be letters, digits, underscore or hyphen.' >&2; exit 2; fi
export GIBSON_RACF_COURSE=1
export GIBSON_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/gibson-racf-audit/$STUDENT}"
export GIBSON_GEO_ONLINE_ENABLED=0
export GIBSON_CTI_ONLINE_ENABLED=0
mkdir -p "$GIBSON_SIM_ROOT"
printf 'Instance: GIBSON-RACFnAUDIT-091126\nSimulator root: %s\n' "$GIBSON_SIM_ROOT"
cd "$ROOT"
"${PYTHON_BIN:-python3}" -m gibson.cli --command 'RACFCOURSE PREPARE' --user IBMUSER
"${PYTHON_BIN:-python3}" -m gibson.cli --command 'RACFCOURSE PREFLIGHT' --user IBMUSER
printf '\nAccount credentials are in %s/racf_course/instructor-credentials.txt (chmod 600).\n' "$GIBSON_SIM_ROOT"
printf 'Do not share them with students; change course login secrets before classroom access.\n'
