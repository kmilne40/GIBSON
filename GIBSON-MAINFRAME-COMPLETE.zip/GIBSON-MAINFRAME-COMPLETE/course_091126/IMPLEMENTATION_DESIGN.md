# Implementation design: Using, Securing and Auditing RACF

**GIBSON instance:** `GIBSON-RACFnAUDIT-091126`  
**Source:** supplied `GIBSON-MAINFRAME-COMPLETE-V1(10).zip`  
**Course:** supplied 4-day RACF administration/assessment course; 32 labs  
**Implementation date:** 9 November 2026

## Decision and objective

**Possible on GIBSON:** all 32 teaching activities can be delivered as an *explicitly simulated* course in a private per-student GIBSON environment. **Not possible without real z/OS:** accurately running IBM RACFICE, IRRDBU00/IRRADU00, Db2 exits, certificate/private-key handling, actual USS kernel ACL enforcement, native SMF records or genuine Health Checker. The design prevents students from mistaking simulator output for proof from IBM software.

The course needs a **cumulative dependency graph**: one parent group must precede the child groups; child groups must precede their users; a group GID must precede OMVS identity exercises; data set profiles must exist before permits/access evidence; general resource and STARTED profiles must exist before refresh/review; evidence fixtures must be seeded before their labs; the capstone must be seeded *after* the regular labs.

## Implementation order and status

| Phase | Deliverable | Status in this build |
|---|---|---|
| 1. Inventory | Dependency tree and supported/unsupported command map | Complete: 32 labs mapped |
| 2. Fix dependencies | BANKLAB instructor seed; reject missing SUPGROUP; correct UID/GID and dataset permit handling | Implemented in course mode |
| 3. Reproducible fixtures | Instructor identities, actual simulator payroll files, mock USS ACL / Health Checker / certificates / Db2 | Implemented (mock surfaces explicitly labelled) |
| 4. Auditing | Controlled allowed/denied checks and synthetic SMF80-like evidence | Implemented for course command |
| 5. Capstone | Seed 12 weaknesses, check and restore snapshot | Implemented; instructor-only |
| 6. Validate | Smoke tests + sequential Run-this command replay | Pass on simulator; not tested against z/OS |
| 7. Student manual | Corrected 32 labs, dependency notes and setup, no destructive interim cleanup, original green/A5 design | Rewritten as DOCX + PDF |
| 8. Classroom deployment | Full multi-student GUI/UIs, per-learner isolation, site auth, instructor provisioning | Deployment guide provided; live multi-VM exercise not performed |

## Object dependency tree

```
SYS1 (built-in)
  BANKLAB (instructor PREPARE)
    PAYROLL (student lab 1.3) -> PAYUSR (lab 1.4)
    DEV     (student lab 1.3, GID 200102) -> DEVUSR (lab 1.4, UID 200101 lab 1.5)
    AUDIT   (student lab 1.3) -> AUDUSR (lab 1.4)
    WEBGRP  (student lab 1.3) -> used with pre-created WEBSTC
    STUDENT1, PAYADM, WEBSTC, USSADMIN (instructor PREPARE)
PAYROLL.MASTER + sample data (instructor PREPARE)
  PAYROLL.** generic profile (lab 2.1)
  PAYROLL group permit (lab 2.2)
  PAYROLL.MASTER discrete profile + permits (lab 2.3)
  access review, temporary deny, restore and audit (2.4, 2.5, 3.x)
FACILITY BANKLAB.PAYROLL.API (lab 2.6) -> RACLIST refresh (2.8)
STARTED WEBPAY.* (lab 2.7) -> combined account review (4.7)
Health, USS ACL, certificate/ring and Db2 scenario metadata (PREPARE) -> Day 3/4
12 capstone weaknesses (instructor START immediately before lab 4.8)
```

The original per-lab cleanup instructions must never be followed while later labs still depend on their objects. Deleting the four child groups, three student identities, `PAYROLL.**`, `PAYROLL.MASTER`, `WEBPAY.*` or `BANKLAB.PAYROLL.API` midcourse breaks downstream exercises. Temporary access changes are undone within the lab.

## Implementation details

The extension lives in `gibson/course_racf/engine.py` and is reached through `gibson/apps/tso.py`. The behavioural changes in `gibson/core/racf_dynamic.py` support superior-group and owner validation, GID fields and uniqueness and compatible permits. The feature is disabled unless `GIBSON_RACF_COURSE=1`; normal unrelated simulator instances should remain unchanged. This is a best-effort isolation boundary, not a formal proof that no other code path is affected.

`RACFCOURSE PREPARE` is idempotent in a simulator state. It uses random passwords for the instructor's non-protected setup identities and never writes them into the distributed archive. Instructors must treat the resulting local credentials as sensitive. Physical sample data sets are present and hold synthetic records; metadata-only USS paths/ACLs, Health Checker findings, certificates and Db2 controls are saved in `racf_course/*.json` under that simulator's root.

**Special fix discovered in end-to-end exercise:** GIBSON's dataset allocator ordinarily auto-creates discrete DATASET profiles. The sample report data sets must not carry auto-generated exact profiles before students define `PAYROLL.**`, otherwise that generic profile would never control their access. Course preparation removes only auto-generated IBMUSER owner/permit defaults for those two reporting samples, not custom profiles with nondefault access lists. Tests explicitly assert successful group access to both examples.

## Simulator test design

- Isolated new `GIBSON_SIM_ROOT` in each test.
- Feature gating: disabled by default, enabled only on an opt-in test instance.
- Hierarchy: missing superior must fail, valid parent must pass, duplicate group and GID rejected.
- Day 1 through Day 4: drive each corrected lab's `Run this` commands sequentially, assert all `RACFCOURSE CHECK` are `READY`.
- Effective access: test `PAYROLL.REPORT1`, `PAYROLL.REPORTS.DAILY`, and `PAYROLL.MASTER`, including a forced denial and subsequent permission restoration.
- Event evidence: confirm simulated audit event creation and report output.
- Capstone: seed twelve vulnerabilities, verify all twelve and restore pre-capstone snapshot; confirm capstone IDs vanish after restoration.
- Restart: confirm prepared objects persist in the same state root.
- Not yet verified: all user-facing 3270 screen workflows, a 20-user classroom on multiple simultaneous instances, deployment across Windows/macOS/Linux, IBM platform compatibility or real Db2/SMF/SYS1 security decisions.

## Deployment design

One **isolated simulator root and network boundary per student** is strongly recommended. For twenty students, use twenty containers or VMs with non-overlapping published ports, their own access controls, CPU/memory/storage caps, and one instructor-controlled master image. A single shared RACF namespace cannot let twenty students all create a group `PAYROLL` without collisions. Students should not see instructor-only credentials or reset functions. The runner defaults to loopback and remapped non-privileged ports. For remote classes, place each container behind an authenticated reverse proxy/VPN or Guacamole with no direct Internet reachability.

Use the full name `GIBSON-RACFnAUDIT-091126` as a **package/build and classroom label**; it is not meant to replace a z/OS eight-character system name, NETID or hostname field.

## Outstanding work before commercial classroom sign-off

1. Conduct instructor-led testing on actual 3270/ISPF user sessions, including individual students without special RACF authority.
2. Replace synthetic unload, Health Checker, certificates, USS ACL and Db2 evidence with exact, independently verified equivalents if the course must teach actual IBM utility operation rather than concepts.
3. Update the instructor guide, lab answer key and PowerPoint deck to match the revised Student Manual, because they were not rewritten in this release.
4. Run a 20-student simultaneous deployment test, including port routing, password resets, persistence, cleanup, grading and recovery from mistakes.
5. Perform a code-security review and compare course-mode changes against normal GIBSON regressions before production training.

**Acceptance criterion for this deliverable:** all 32 student command sequences complete against the course-specific GIBSON simulator baseline with dependencies present, coupled with accurate and prominent warnings for simulator-only evidence; fully equivalent behaviour on genuine IBM z/OS is **not** an acceptance criterion of this build.
