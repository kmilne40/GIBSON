# GIBSON-RACFnAUDIT-091126: Regression and z/OS 3.2 course verification

Date: 19 November 2026. Baseline: attached `GIBSON-MAINFRAME-COMPLETE(1).zip`. Candidate: updated 48-lab build from the same baseline. Environment: CPython simulator tests in this sandbox, **not IBM z/OS or ZD&T**.

## Scope and result

- All 1,909 original source files are present in the adapted build. **Zero removed**. 1,907 unchanged, and only two pre-existing Python files deliberately modified (`gibson/apps/tso.py` and `gibson/core/racf_dynamic.py`); opt-in course code and materials are additions.
- Core RACF command-handler adjustments are now isolated to `GIBSON_RACF_COURSE=1` where feasible. The ordinary TSO route does not import the course engine. One compatible optional `gid` field is added to the group data model.
- Matched comparison, 19 existing RACF-related test modules (same selection): **original 108 pass / 2 fail; adapted 108 pass / 2 fail**. No newly failing cases in that matched sample.
- Matched broader cross-subsystem sample covering JES, FTP, USS, CICS, Db2, MFA, TN3270 and SMF: **original 106 pass / 3 fail / 1 skipped**; adapted with four extra course tests **110 pass / 3 fail / 1 skipped**. Again, no newly failing existing tests in the matched sample.
- Latest corrected targeted course/RACF run: **45 pass / 1 fail**, the same pre-existing SETROPTS help-text expectation, and the ten dedicated course tests separately passed.
- Clean 48-lab simulation replay: **48/48 prerequisite checks ready**, **244 commands exercised**, **10 threat scenarios**, **0 flagged command errors**. The newly introduced synthetic REVOKE/CONTAIN/NOCONTAIN/RESUME distinction is verified by a dedicated automated test.
- Full 309-module GIBSON test catalogue was **not** executed, and real UI, concurrent user, distribution builds and deployed ZD&T tests have not been completed. It is **not possible to guarantee zero regressions** on these results alone.

## Existing test failures, reproduced before and after

1. `test_setropts_class_raclist_generic_refresh_help`: help text does not include the expected `SETROPTS PASSWORD HELP` marker. Existing on original.
2. `test_rest_gateway_fallback_starts_and_answers`: REST gateway did not start listening within the sandbox timeout. Existing on original. May be environmental; not adjudicated.
3. `test_mfa_totp_and_expiry` (two tests): QR SVG is blank in this sandbox, so MFA web enrolment checks fail. Existing on original.
4. `test_v3_corrective_regression::test_master_console_full_layout_survives_r05_r06_and_d_dvcapin`: expected master-console text differs. Existing on original.

The two matched suites overlap only partially. These are **not a count of six distinct problems found**, and test failure does not by itself prove a production regression.

## Instructor question and answer completeness

- All **48 lab headings** are present in the revised instructor guide.
- All **144 numbered knowledge questions** from the master manual are reproduced verbatim with a corresponding **144 model answers** in the instructor-guide appendix.
- The 16 advanced-lab discussion questions and model responses remain in the main instructor teaching notes.
- Both revised Word manuals render successfully: Instructor **60 pages (A4)**, Master **238 pages** with matching newly generated PDFs. Figures and simulator-output screenshots remain included.

## z/OS 3.2 and RACF incident response

On IBM systems, RACF `REVOKE` can restrict new use of an identity without necessarily stopping existing sessions. Supported RACF user ID containment is designed to prevent subsequent RACF-protected access by a contained identity, including from active sessions; it is **not a process killer or comprehensive network isolation measure**. Restoring a contained/revoked identity requires separately evaluating `NOCONTAIN` and `RESUME` in the correct operational order. The course teaches this with a clearly labelled synthetic model:

- `RACFCOURSE REVOKE userid`: simulated new logons denied; modelled active session access continues.
- `RACFCOURSE CONTAIN userid`: simulated new logons and subsequent protected access denied; synthetic SMF 80 event 92 recorded.
- `RACFCOURSE UNCONTAIN userid`: simulated containment cleared; revocation persists.
- `RACFCOURSE RESUME userid`: simulated revocation cleared.
- `RACFCOURSE SESSIONCHECK userid`: displays the two modelled decisions. **None of these commands alters real RACF or performs a SAF check.**

Real RACF command examples are `ALTUSER userid REVOKE`, `ALTUSER userid CONTAIN`, `ALTUSER userid NOCONTAIN` and `ALTUSER userid RESUME`. All require the corresponding RACF authority and change/incident approval. Inspect site-specific IBM z/OS 3.2 licensed documentation and installed service level before executing on production identities, particularly started-task IDs.

RACF SMF 80/81/83, type 1154 subtype 83 compliance evidence and Communications Server SMF 119 zERT subtype 11/12 are covered as distinct evidence families. GIBSON output is **synthetic JSON training data**, not byte-for-byte SMF or authentic record parsing. The zERT detail or aggregate by itself cannot prove exfiltration or identify a threat actor.

### Reference pages to verify against the installed z/OS 3.2 level

- IBM RACF user ID containment: https://www.ibm.com/docs/en/zos/3.2.0?topic=users-racf-user-id-containment
- IBM RACF SETROPTS: https://www.ibm.com/docs/en/zos/3.2.0?topic=syntax-setropts-set-racf-options
- IBM RACF type 80: https://www.ibm.com/docs/en/zos/3.2.0?topic=records-record-type-80-racf-processing-record
- IBM SMF 1154: https://www.ibm.com/docs/en/zos/3.2.0?topic=records-record-type-1154-x482-zos-compliance-evidence

These IBM URLs were identified in the original course material. Live IBM Docs access was unavailable during this verification, so **a fresh line-by-line check against IBM z/OS 3.2 documentation remains outstanding**. Native RACF/SMF/ZD&T runtime validation remains outstanding as well. Consequently this report does not assert absolute version correctness.

## Release recommendation

Suitable for a supervised GIBSON-based rehearsal of all 48 labs, with explicit simulation labelling. Before production delivery or claims of z/OS 3.2 behavioural parity: resolve known baseline failures, run the complete GIBSON test suite and multi-user network tests, verify z/OS 3.2 documentation, and rehearse privileged commands on an authorised isolated IBM z/OS 3.2 test image.
