## 2026-11-26  Installs on Python 3.14, and a tidier kit

* **GIBSON installs on Python 3.14.** pygame, which PHOSPHOR's desktop GUI
  uses, has no ready-built package for Python 3.14, and because every course
  package is a core dependency, the failed build stopped the whole install:
  nothing was installed, so neither the dashboard nor the Pen-Test Shell on
  port 8022 could start. Python 3.14 and later now get pygame-ce, the
  maintained fork, which is imported as pygame; older Pythons keep pygame, so
  the ISO, Mac and Windows builds are unchanged.
* **One package can no longer stop the install.** If installing everything
  at once fails, `install_gibson.sh` installs each package on its own, then
  GIBSON, and names anything that did not install.
* **The kit's documentation is current.** Old validation reports, patch
  notes and test evidence are gone. `README.md` is now the guide to
  installing this kit on Linux or WSL, `docs/release/` holds the current
  README for each release (Windows, Mac, and the Intel and AMD and arm64
  ISOs), and the zSecure Alert guide has moved to `docs/ZSECURE-ALERT.md`.

## 2026-11-20 (later)  nmap and Python on Windows, python3 everywhere, TShOcker on Windows

* **GIBSON for Windows now carries nmap and Python.** Nmap 7.993's own Windows
  build (without Npcap, which may not be bundled: -sS runs as -sT with a note,
  while -sV and the NSE scripts work) and python.org's Python 3.12.10 with pip
  and every course package, as python, python3 and pip. toolbox-setup.cmd now
  only offers Npcap, through winget, for raw scans and zniff's live capture.
* **python3, python and pip in every Pen-Test Shell are GIBSON's own Python**,
  with every course package: the ISO's /opt/gibson venv, the Windows bundle's
  Python, and in the frozen Mac app `gibson --python`, a new launcher mode that
  takes a script, -c, -m, --version or nothing for a prompt. Before, the
  computer's own python3 answered, which has none of them, so students had to
  pip install rich and the rest by hand.
* **TShOcker works on Windows.** It wrote its job to /tmp/rand.jcl, which on
  Windows is C:\tmp and does not exist, so it failed after the FTP login; it
  now uses the system's temporary folder. The invalid escape sequences in its
  logo (SyntaxWarnings on Python 3.12 and later) are fixed with its output
  unchanged, and it turns on ANSI colours in Windows consoles.
* **Pillow, pypdf and mmh3** are now installed with the course tools: ezrecon's
  image search imports Pillow unguarded, and nothing installed it.
  tests/test_course_tool_dependencies.py reads every import in the bundled
  tools and fails if one is not a declared dependency.
* **The tool test** now runs TShOcker's whole attack (submit over FTP, GIBSON's
  listener, a netcat session), the real nmap on Windows, and GIBSON's python3
  importing every course package and running a course script.

## 2026-11-20  GIBSON for Windows carries its own Pen-Test Shell tools

Setup puts GIBSON into WSL 2 when a PC can run it, and the Linux system there
has every tool. Many PCs can't (virtualisation off, an older Windows, a VM
without nested virtualisation), and they got native Windows mode, where the
Pen-Test Shell had only GIBSON's Python tools. Now native Windows mode has
the rest too, so a student's PC needs nothing but GIBSON-Setup.exe:

* **scripts/bundle_windows_tools.sh** builds, in MSYS2 on the build machine, a
  small self-contained Unix system that setup installs beside gibson.exe as
  native\tools: bash and the usual commands, Perl, hydra 9.7 and jumbo John
  with racf2john (built from the same pinned sources as the Mac's), nikto
  2.5.0 with XML::Writer, wget, curl, OpenBSD netcat, telnet and ftp
  (inetutils), whois, a ping that runs Windows' own, and the x3270 suite's
  ws3270 and wc3270, cross-built from 4.5ga6 with MinGW (they use Windows' own
  TLS, so they need nothing else). Licences and NOTICES.txt, with each
  component's version and source, go in native\tools\licenses.
* **nmap and Npcap are not included**, because their licences don't allow it.
  Typing nmap says so and runs gibson-scan with the same target and ports;
  gibson-scan now accepts -sT, and -sS (as a connect scan, saying so). zniff's
  live capture needs Npcap too, so it is the other thing native Windows mode
  can't do; the WSL toolset, the ISO and the Mac app can.
* **dig and host** in native Windows mode are GIBSON's own
  (scripts/windows/gibson_dns.py, on dnspython), since MSYS2 has neither and
  the last BIND with Windows programs is unsupported; they cover the course's
  forms including zone transfers, and are tested against a local DNS server.
* **The Windows Pen-Test Shell** runs the bundled bash (ConPTY), with the
  bundled tools straight after the scope-guarded wrappers, so every network
  tool is still scope-checked. Only the x3270 folder goes on gibson.exe's own
  PATH, because the MSYS2 folders have Unix programs named like Windows ones.
  tool-check also looks in the bundled folders on Windows.
* **build-windows.bat** adds windows-tools.zip (from the GIBSON for Windows
  release) to the build as step [3b]; without it the build still works, with
  only the Python tools. Batch and PowerShell files are now stored with CRLF
  line ends (.gitattributes), because cmd.exe can lose its place in an
  LF-only batch file.
* **Tested on CI**: GIBSON-Setup.exe is installed in native Windows mode on
  clean Windows Server 2022 and 2025 machines, GIBSON is started by the Start
  menu's own launcher, and every tool is tested against the running lab, both
  by scripts/ci/test-gibson-tools.sh in the bundled bash and by typing into the
  real Pen-Test Shell over its websocket (scripts/ci/windows-webshell-test.py).
* **A welcome page that cannot have port 80 no longer stops GIBSON.** Windows
  often holds port 80 itself (IIS, or an http.sys reservation; Windows Server
  2025 does out of the box), and the welcome page's failed bind ended all of
  GIBSON's start-up with a PermissionError, so the launcher showed "GIBSON
  could not start". Found by the Windows Server 2025 test. The page now moves
  to 8000, then 8888, and says so on the console, or GIBSON runs on without it;
  a port chosen with --welcome-port is used as given. The Windows launchers
  open the page wherever it is.
* **The ISO** is now built, booted and tested on CI too (.github/workflows/iso.yml):
  it boots in QEMU with BIOS, UEFI and UEFI Secure Boot, must start GIBSON by
  itself and log the student into the desktop, and the full tool test runs
  inside the booted live system through the QEMU guest agent. Only then are
  the ISO, its 350 MB parts, join tools carrying the new checksum, and the WSL
  image published.

## 2026-11-19  Every Pen-Test Shell tool inside the Mac app, tested on real Macs

The Mac build left nmap, hydra, nikto, wget, s3270 and jumbo John out of the
app, and the first launch on each student's Mac installed them with Homebrew:
5 to 30 minutes, an administrator account, Homebrew itself if it was missing,
and John compiled from source. That step was where Mac support calls came
from. VirtualBox on Apple Silicon cannot help either, because it runs only Arm
guests and the ISO is x86_64. Now the tools are built once, from source, and
shipped inside GIBSON.app, and the whole result is proven on real Macs:

* **scripts/bundle_macos_tools.py**, run by build-macos.command as step [3b],
  builds every tool from a pinned source with MACOSX_DEPLOYMENT_TARGET=11.0
  and OpenSSL 3.5 linked statically, in an environment that cannot see
  Homebrew, MacPorts or pkg-config: nmap 7.992 (with its own pcre, lua and
  libssh2), hydra 9.7 (its configure patched so it cannot search Homebrew's
  folders), wget 1.24.5, the x3270 suite 4.5ga6 (s3270, c3270), GNU inetutils
  2.5 (telnet and ftp, which macOS removed), jumbo John at a fixed commit, and
  nikto 2.5.0 with XML::Writer. Homebrew is no longer used at all: it builds
  for the build Mac's own macOS, so its programs refused older Macs. The
  bundler signs everything, then refuses the build if any program loads a
  library from outside the app, needs a newer macOS than 11, or fails to start
  with only the system on PATH. Licence texts and THIRD-PARTY-NOTICES.txt go
  in tools/licenses. GIBSON_SKIP_TOOL_BUNDLE=1 makes the old first-launch build.
* **build-macos.command** uses only python.org's Python (installing 3.12.10
  if it is missing), because an app frozen with Homebrew's Python only runs on
  the build Mac's macOS and Apple's /usr/bin/python3 is 3.9; it remakes a
  .venv-build that came from another Python, targets macOS 11 for everything
  pip compiles, and checks every Mach-O file in GIBSON.app against macOS 11
  before packaging. The PKG is now the file to hand out; its postinstall also
  clears any download quarantine.
* **gibson/core/bundled_tools.py**: the frozen launcher puts tools/bin on
  PATH, the Pen-Test Shell puts it straight after its scope-guarded wrappers
  and opt/bin (so every bundled tool is still scope-checked), and tool-check
  and install-pentest-tools.sh look there, so the first launch asks nothing.
  The app's launcher clears the download quarantine from its own files once
  the student has approved GIBSON. READ ME FIRST.txt, Chapter 2 and the new
  docs/release/README-MACOS.md give the macOS 15 Sequoia approval steps.
* **scripts/ci/test-gibson-tools.sh** runs every tool against a live GIBSON
  through the Pen-Test Shell's wrappers, 44 checks in all: nmap (connect,
  SYN, version, the tn3270-screen and http-title scripts), the scope guard
  refusing 8.8.8.8, hydra finding IBMUSER's FTP password, nikto, wget, curl,
  nc, ping, dig, host, telnet, the RACF chain (RACFDB BACKUP, a binary FTP
  download, racf2john, John cracking a password), s3270 and PHOSPHOR reaching
  TSO/E LOGON, cicspwn reading the CICS region, zniff capturing the TN3270
  session, FTP JES listing, TShOcker, ezrecon, nje-assess, injector, njejcl
  (with the job checked in JES), njeanalyze and the PassTicket tools. It
  passes against GIBSON on Linux, and .github/workflows/macos.yml runs it on
  clean macOS 14 and 15 Macs after installing the PKG with Homebrew moved away.
* **Bugs it found, now fixed everywhere**: the shell's wget wrapper was
  rejected by bash (an apostrophe in its hint ended a quoted echo), so wget
  never ran in the Pen-Test Shell on any platform; NJElib crashed with
  NameError on the first console message, which broke nje-assess, injector
  and njeanalyze; njejcl passed its "auto" --rip default straight to
  inet_aton and crashed before connecting; and tool-check reported PHOSPHOR
  ready without checking that its package was there.
* tests/test_macos_bundled_tools.py and tests/test_pentest_tool_fixes.py cover
  the relocation and minimum-macOS checks, the pinned sources and clean build
  environment, the hydra patch, the launchers, the shell's PATH order, a first
  launch that never reaches Homebrew, and the three tool bugs.

## 2026-11-16  A Windows install that cannot strand a student

setup.exe asked the student to choose between WSL 2 and the native build, and
a PC that could not run WSL 2 (virtualisation off, a VM without nested
virtualisation, HCS_E_HYPERV_NOT_INSTALLED) ended on an error box and a Start
menu that flashed and closed. Too many students would need help. Now:

* **No choice to make, and no dead end.** The mode page is gone. Setup always
  installs the native build and the WSL pieces, tries WSL 2 only when its check
  says it can work (so no pointless restart), and a WSL failure during setup or
  after the restart is logged, never shown as a blocking error. Ready to
  Install says which mode this PC gets and why. /SILENT installs with no
  questions; /MODE=native never touches WSL.
* **One launcher behind every shortcut.** windows/gibson-launch.ps1 uses the
  WSL GIBSON when it is installed and answers within two minutes; otherwise it
  terminates it (so it cannot take the ports later), says so in a ten-second
  message naming Fix WSL for GIBSON, and starts the native build. Stop GIBSON
  stops both modes. After the restart, Resume always ends in the launcher.
* **The native fallback is turnkey.** windows/gibson-native.ps1 runs the
  scripted IPL (--ipl-prestart-console, training PIN 0000, overridable with
  GIBSON_IPL_PIN), then --serve with every service, and opens the browser on an
  IPLed system. If the scripted IPL fails it drops to the interactive start.
  It runs as the signed-in user (RunAsInvoker), so there is no UAC prompt on
  each start, the lab lands in this user's profile, and Stop GIBSON can stop it.
* **gibson on the PATH follows the mode.** {app} is on the PATH (not
  {app}\native, which an upgrade now removes), and gibson.cmd runs the WSL
  GIBSON when it starts and the native build otherwise.
* fix-wsl.ps1 and fix-wsl.cmd ship with a Start menu entry; the VM check comes
  before the hypervisor check (a VM always reports the host's hypervisor); both
  WSL install paths pin --version 2.
* **Fixed after the first Windows 10 test** (the Start menu flashed a window
  and nothing ran; WSL reported WSL_E_DISTRO_NOT_FOUND). gibson-launch.ps1 ran
  two wsl.exe calls under ErrorActionPreference 'Stop', and Windows PowerShell
  5.1 turns wsl.exe's stderr into errors, so the launcher died before its
  native fallback. Every wsl.exe call now goes through a helper that cannot
  throw, the WSL distribution counts only if it is listed AND starts
  (wsl -d GIBSON -- true), and any unexpected error falls back to native.
  gibson-native.ps1 now runs gibson.exe hidden through cmd.exe with its output
  in gibson-ipl.log and gibson-server.log, checks that it is still running,
  and shows the last lines of output if it stops, instead of a console window
  that vanished on a crash. A failed scripted IPL is no longer fatal: GIBSON
  serves anyway and a message lists the six replies.
  The diagnostics from that PC (a VirtualBox VM, correctly sent to native)
  showed gibson.exe IPLing and answering on every port when run this way, and
  an earlier hidden IPL left running with no ports open, so the scripted IPL's
  input is now empty (< nul) and it can never wait for a key. New
  windows/gibson-diagnose.cmd, with a Start menu entry, collects one report.
* README, Chapter 1's gibson-command table and Chapter 2's setup.exe sections
  rewritten to match. tests/test_windows_wsl_installer.py covers all of it.

## 2026-11-14  Windows through WSL 2, Pen-Test Shell tools, ELV.APF, JES spool and MFA

Six fixes from the 2026-11-14 assessment report.

* **Windows now runs the real GIBSON, through WSL 2.** setup.exe used to install
  only the native Windows build, which worked where WSL was already present
  (the Pen-Test Shell borrowed WSL's bash and tools) and failed on a fresh
  Windows. It now turns on WSL 2 and the Virtual Machine Platform, installs
  Microsoft's WSL package (pinned to 2.7.13 and checked by SHA-256), restarts
  once if needed and carries on by itself at the next sign-in, and installs
  GIBSON-Linux.wsl, the ISO's own system without the desktop, where GIBSON runs
  as a service reachable at localhost. Windows 10 22H2 and Windows 11 are
  supported; on 11 22H2+ it sets networkingMode=mirrored, on 10 it relies on
  localhost forwarding. A sign-in keep-alive stops WSL idling the distribution,
  gibson.cmd runs the host commands inside it (translating Windows paths), and
  an upgrade keeps the lab. Machines that cannot run WSL 2 (too old, no
  virtualisation, blocked by policy) get the native build, which is installed
  either way as a fallback under {app}\native. New: iso/build-wsl.sh,
  windows/gibson-wsl.ps1, windows/gibson-keepalive.vbs, windows/gibson.cmd;
  rewritten gibson.iss and build-windows.bat; tests/test_windows_wsl_installer.py.
* **The Pen-Test Shell's course tools install wherever GIBSON installs.**
  ezrecon, zniff and cicspwn failed with ModuleNotFoundError on a source
  install because install_gibson.sh installed only GIBSON's core packages while
  the ISO installed the [pentest,ezrecon-live] extras. install_gibson.sh now
  installs those extras too (with a --minimal opt-out), toolbox-setup adds
  s3270 and any missing course-tool package into GIBSON's own Python, and a new
  tool-check (GIBSONscan/tool_check.py) imports each tool's packages with the
  Python that runs them and prints a readiness table, shown at the end of the
  install, in the shell banner and from the `tools` command. On Windows the
  shell never selects WSL's System32\bash.exe for a native GIBSON (a different
  system with a different network); it uses Git Bash or PowerShell. The build
  scripts no longer ship a lean build silently: a failed full freeze stops
  unless GIBSON_ALLOW_LEAN=1, a lean build is stamped LEAN, and each frozen
  build is checked for the course-tool packages before packaging. PHOSPHOR now
  prints why it ended (you quit, the host closed the session, or an error)
  instead of a bare "[+] disconnected". New
  tests/test_pentest_tool_readiness.py.
* **ELV.APF simulates the APF escalation again.** The bundled ELV.APF is the
  tool's own GitHub copy, which is missing an END after its WARNING-mode loop,
  so its LIST looped for ever once it met a WARNING-mode profile (this happens
  on a real z/OS too). GIBSON ships the corrected copy and replaces the broken
  member in a user's .TOOLS library on seed. SYS1.VULNLIB is now a real APF
  library (on SBSYS1) with the training profile's UACC(ALTER) planted weakness,
  so `EX 'ELV.APF' 'LIST'` shows it as writable and `EX 'ELV.APF' 'SYS1.VULNLIB'`
  escalates BOB to SPECIAL; secure mode makes it UACC(NONE) and the escalation
  is refused. The REXX engine now stops a runaway exec (the same host command
  1,000 times in its recent history, or ten minutes) with IRX0004I, tunable
  with GIBSON_REXX_MAX_REPEATS and GIBSON_REXX_MAX_SECONDS. (The report's guess
  that GIBSON's REXX interpreter diverged was wrong: the cause was the tool's
  missing END, and SITE JESINTERFACELEVEL needed no change.) New
  tests/test_apf_lab_elv.py and tests/test_real_enum_elvapf_end_to_end.py.
* **JES spool: one visibility rule, and the spool on DASD.** FTP JES mode and
  SDSF now share one rule for who may see a job (owner or submitter always;
  everyone in the training profile; only SPECIAL/OPERATIONS/AUDITOR in secure
  mode), so they never disagree. SDSF opens with OWNER set to the user's own id
  as on z/OS, `OWNER *`/`PREFIX *` widen it in the training profile, browsing
  another user's output is logged, and changing a job (P/C/A/H/O) needs
  JESSPOOL ALTER or gives ICH408I. The JES2 spool and checkpoint data sets
  named in JES2PARM now exist uncatalogued on their volumes (SYS1.HASPACE on
  SBSPL1, the checkpoints on SBCKP1/2), and `$D SPOOL` and SDSF's SP panel agree
  with JES2PARM and with each other. New tests/test_spool_visibility_jes2.py.
* **MFA: the QR code works, and it is checked at logon.** The self-service web
  page (/mfa/enroll) now shows the QR code for a factor an administrator has
  already enrolled, so the key MFA ENROLL printed and the code the app shows
  always match, and a new /mfa/admin page (behind the dashboard login) shows
  the QR code of every pending factor for a class to scan. The terminal QR code
  is drawn black-on-white whatever the terminal theme (authenticator apps will
  not read an inverted code), and `--mfa-enroll --qr-file FILE` saves it as PNG
  or SVG. A pending factor is announced at logon (IRRC115I) so it is never a
  surprise that it is not yet enforced, MFA STATUS and LISTUSER distinguish the
  PIN+HHMM switch from authenticator factors, and when no IPL PIN is set the
  token is HHMM alone and the prompt says so rather than asking for a PIN nobody
  was given. New tests/test_mfa_enrolment_qr.py.

## 2026-11-11  PHOSPHOR in the pen-test shell: Tab on the TSO/E logon panel

* `phosphor 127.0.0.1 --client` in the pen-test shell on the macOS and Windows
  apps showed a `phosphor[row,col]>` line prompt instead of PHOSPHOR's
  full-screen terminal, and Tab could not move from Userid to Password on the
  TSO/E logon panel. gibson.spec excluded curses from the frozen build, so
  PHOSPHOR fell back to its line client, and that client read the Tab key as
  an ordinary character: `IBMUSER<Tab>SYS1` reached TSO as the userid
  IBMUSERSYS1 (IKJ56420I). curses is now bundled (with windows-curses on
  Windows, from requirements-build.txt), so the full-screen client starts as
  it does on Linux and the ISO. The line client, which is still used with
  --repl or wherever curses cannot start, now treats Tab as a field move
  (`USERID<Tab>PASSWORD` then Enter) and has :tab and :btab, and PHOSPHOR now
  says why it is using the line client instead of switching silently.
  Text typed with :type, or before a Tab, now shows in its field at once
  (non-display fields such as Password stay blank); before, it only appeared
  after ENTER, so a userid typed with :type looked as if it had been lost. A frozen
  build adds the system terminfo directories when TERMINFO_DIRS is unset, so a
  bundled ncurses finds xterm-256color. tests/test_phosphor_client_tab_logon.py
  logs on through the line client with a Tab and checks the bundling.

## 2026-11-11  A real gibson command on every build

* `gibson --list-volumes` and the other host commands the guide shows now work
  as typed. On the ISO, /usr/local/bin/gibson (new) runs the command through
  sudo against the gibson service's state folder, /var/lib/gibson/mfsim, then
  hands the folder back to gibsonsvc; before, `gibson` was not on the PATH and
  the long form had to be typed. The Windows installer adds the install folder
  to the system PATH (and removes it on uninstall), and gibson.exe started
  with options in a window of its own now waits for Enter, since the
  administrator prompt opens a new console that would otherwise close at once.
  The macOS .pkg links /usr/local/bin/gibson to GIBSON.app's gibson-cli.sh, and
  the DMG's READ ME FIRST.txt gives the one-line command to do the same.
  install_gibson.sh says where its .venv/bin/gibson is.

## 2026-11-10  ISO: install to disk, and the VirtualBox black screen

* The ISO can now install GIBSON to a disk. "Install GIBSON to this computer's
  disk" on the boot menu starts the live system with the installer (Calamares)
  open, and the live desktop has an "Install GIBSON" launcher. It copies the
  whole system across (GIBSON, its lab, the desktop and the tools), sets up the
  user (student, automatic login, both changeable), and installs GRUB for UEFI
  with Secure Boot (shim) or BIOS. Files: iso/files/etc/calamares/,
  usr/local/bin/gibson-install, usr/local/bin/gibson-live-setup.
* Black screen on VirtualBox and VMware unless "safe graphics" was chosen:
  X picked the old "vmware" driver (xserver-xorg-video-vmware), which shows
  only a pointer on a black screen; and on an SVGA adapter the kernel's vmwgfx
  driver cannot drive, vmwgfx first removed the firmware framebuffer and then
  failed, leaving no display device at all. The vmware X driver is removed,
  X uses the modesetting driver on every kernel graphics device
  (etc/X11/xorg.conf.d/20-gibson-modesetting.conf), and vmwgfx is loaded only
  on VMware and VirtualBox (etc/modprobe.d/gibson-vmwgfx.conf and
  usr/local/sbin/gibson-gpu-gate). A "basic display" boot entry
  (gibson.vmwgfx=0) uses the firmware screen on VirtualBox or VMware.
* The kernel now stays in the live image (/boot without the initrd), which
  the installer needs; the ISO is about 70 MB larger.
* When the installer entry is chosen, the browser no longer opens over it.

## 2026-11-09  FTP SQL access, SITE FILE= in the TSO FTP client, SQL lab output

* SQL queries over FTP now work from Linux and macOS ftp clients. Those clients
  switch to binary by themselves (GIBSON's SYST says UNIX) and send TYPE I
  before every transfer, and GIBSON refused every SQL GET in TYPE I with 504.
  The query is now answered in either type. z/OS gives the 504; the difference
  is deliberate and documented in docs/FTP-ZOS-JES-SQL.md.
* The TSO `FTP` client (FTP at TSO READY, line mode and 3270) accepted only
  `SITE FILETYPE=` and answered `SITE FILE=JES` with "504 Unknown SITE
  option". It now uses the server's z/OS SITE parser (every parameter and
  abbreviation, the same replies), has QUOTE and LITERAL, and carries out GET,
  PUT, DIR, LS and DELETE in JES and SQL mode through GIBSON's FTP server:
  JES submission, job listings, spool retrieval, cancel and SQL queries.
  SEQ mode is unchanged.
* The SQL lab (PUT in SQL mode) also writes its report to a real data set,
  userid.name.RESULT, so it can be retrieved, and its job is named userid+Q so
  the default JESJOBNAME=userid* filter lists it. The old output file and the
  reply text are kept.
* Tests: tests/test_ftp_tso_client_jes_sql.py; the TYPE I case in
  tests/test_ftp_zos_jes_sql.py now expects the query result.

## 2026-11-09  DASD volumes and a ZD&T-format DEVMAP

Every data set now lives on a 3390 volume with a device number behind it.
Before, each data set's metadata named a volume (SBSYS1, WORK01, ...) that
nothing else knew about, and the console's D U output came from a fixed table
that did not agree with the volumes the data sets used.

New: gibson/core/dasd.py (volumes, 3390 geometry, the devmap and
dasd-state.json in the state folder), gibson/core/jcl_dd.py (continuation-aware
DD parsing), gibson/core/jes_dasd.py (step allocation, IEFBR14 with
dispositions, IEHLIST LISTVTOC, ICKDSF INIT) and gibson/core/dasd_lab.py (the
APF list with volumes, health check IBMCSV CSV_APF_EXISTS, and the security
exercises). Changed: the master console's device commands (D U, DS P, V,
D IPLINFO, D PROG,APF), the data set layer (volume checks, space, a data set
keeps its volume when re-allocated or given a new member, which fixes a bug
that moved it to WORK01), TSO ALLOCATE (which before did nothing for
DA() NEW, or created a junk data set for ALLOC DA('x') NEW), ISPF 3.2 and 3.4,
the line editors, FTP, JES, the escalation engine's APF test for the new
exercise only, the health checker and the CLI (--add-volume, --unit,
--devnum, --init, --list-volumes, --import-devmap).

Regression control: tests/dasd_golden records every volume-related output as
it was before (24 scenarios), tests/test_dasd_golden.py fails on any
difference not listed with its reason in tests/dasd_golden/expected/CHANGES.md,
GIBSON_DEVMAP=off reproduces the baseline exactly, and the full suite was run
after every phase against the pristine baseline (1523 passed / 27 failed,
the same 27 that fail without this change). Guide: docs/DASD-DEVMAP.md.

## 2026-07-29  Licensing added to the distribution (GIBSON Community and Educational Licence v1.0)

The distribution previously shipped with no licence of its own. The only licence
file in the tree was integrations/web3270/vendor/web3270/LICENSE, an MIT licence
covering vendored third-party code (Copyright (c) 2026 Britley), which grants
nothing in respect of GIBSON itself. Since the Licence conditions all rights on
acceptance of its terms, recipients of the archive had no granted rights at all.

The GIBSON Community and Educational Licence v1.0 (28 July 2026) is now included
at the archive root as LICENSE.md. The filename uses the American spelling
deliberately: the attribution block inside the Licence text directs readers to
"LICENSE.md", so the file and its own self-reference now agree. The text is a
byte-identical copy of the source document; nothing was reworded.

Project metadata was updated so the Licence travels with built artefacts as well
as the archive: pyproject.toml gains license-files = ["LICENSE.md"] under
[tool.setuptools], which places the Licence in the sdist and in the wheel's
.dist-info, plus the "License :: Other/Proprietary License" classifier. The
table form license = { file = ... } was avoided as it is deprecated in current
setuptools. The vendored MIT licence is untouched and stays where it is, as
Section 11 (Third-Party Material) requires. No code changed, so the test
baseline is unaffected.

## 2026-07-22  CICS panels reworked for cicspwn exploitation (file R/W, RACF bypass, TSQUEUE enum)

The CEMT and CEDA result panels were rebuilt to behave like real CICS panels so
the cicspwn exploitation paths (not just enumeration) work. cicspwn types an
80-character space-padded command at row 1 column 2 and reads resource attributes
in the abbreviated form; the previous information-rich table panels put a protected
title there, so cicspwn's typing overflowed into a protected field and locked the
keyboard. Row 1 is now one wide unprotected command line (like the blank entry
panel that already worked), resources render in real CEMT abbreviated form
(Fil(FILEA) Ope Ena Rea Upd Dsn(...)), SET returns a NORMAL response on the row
cicspwn checks, and a new CEMT INQUIRE TSQUEUE panel matches cicspwn's exact column
positions. The human-friendly table format was traded for this authenticity, as
agreed.

Verified live against the real cicspwn tool: --get-file no longer crashes and drives
the file open/enabled (both open and closed files), -e --bypass completes the RACF
bypass (CEMT->CSPS and CECI->CSPK copied and installed), and -e enumerates the
temporary-storage queues. Enumeration (-i), nmap cics-enum, cics-user-enum,
vtam-enum, the CEMT submenu context, CEMT SET filtering, the CEDA COPY RACF-bypass
lab, DVCA, and the bare-transaction menus were all re-checked and are unchanged.
DVCA is a separate application and was not touched. Two files changed:
gibson/apps/cics3270/cics_session.py and the golden-panel baseline
(tests/fixtures/golden_panels.json), which was re-baselined for the intended CEMT
change - that golden test now passes. 253 CICS-area tests pass; the remaining
failures are pre-existing and unrelated to this change. Still outstanding for a
future pass: reading actual file content (needs CECI EXEC-CICS variable
substitution) and the -s TSO shells (need the spool/IRDR internal reader).

## 2026-07-22  Merged the unshipped branch work: z/VM CP fixes and z/TPF Z-messages

A review of the repository branches (main, britley-work, zvm-cp-fixes) found that
two pieces of work were not present in the deployable release zip, confirming the
concern about an older build being shipped.

The zvm-cp-fixes branch (three commits: real CMS file storage wired into
FILELIST/RDRLIST/XEDIT, SET PRIVCLASS/SECUSER and MSG CP commands, and an ATTACH
implementation plus a DETACH fix) had never been merged and was absent from the
release zip. It was brought in with a three-way merge so the release zip's own
AMDISK/DIRMAINT additions were preserved rather than overwritten. The z/VM CP
command line now honours SET PRIVCLASS, SET SECUSER, MSG/MSGNOH, and device
ATTACH/DETACH, and CMS FILELIST/RDRLIST/XEDIT read and write real stored files.
Verified live over s3270: logon to z/VM, then each command returns the correct CP
response.

The z/TPF ZLINE, ZNETW, and ZPERF Z-messages (from the britley-work merge) were
present in the repository source tree but not in the release-zip lineage, so they
were ported in as well. ZLINE now shows teleprocessing line status, ZNETW the
network nodes, and ZPERF per-transaction performance counters, and the PRIME CRAS
ready line advertises them alongside the existing Z-messages.

All of this is isolated from the CICS/VTAM work done earlier - the branches touch
only gibson/apps/zvm and gibson/apps/ztpf, nothing under cics3270, cics.py, or
tn3270_server.py. Regression was verified accordingly: cicspwn still runs to
completion, nmap cics-enum still returns exactly the implemented transaction set,
the z/VM and z/TPF test files pass, and the only failing targeted tests are the
five that fail identically on the prior release zip (the CBSA/OMEN test, the OMVS
ping test, the SIT-state test, the socket-listener test, and golden panels). Five
files changed from the release zip: gibson/apps/zvm/zvm_session.py, cp_directory.py,
and cms.py, plus gibson/apps/ztpf/ztpf_engine.py and ztpf3270.py. Caveat: verified
in-sandbox against real s3270 4.1; the z/VM CMS storage and TPF counters were
exercised at the command level, not through every edge path the branch authors may
have intended.

## 2026-07-22  cicspwn and the nmap CICS scripts verified end-to-end (and the bugs that stopped them fixed)

To actually confirm rather than assert, the real tools were run against a live
GIBSON server. A genuine s3270 client drove the real cicspwn tool (py3270 was
patched locally to parse the s3270 4.1 status line - a client-side quirk, not a
GIBSON issue), and the four nmap CICS NSE scripts were run against a GIBSON server
on port 23. Getting them all working uncovered several real bugs.

cicspwn now runs to completion: it validates the applid, enumerates all six
supplied transactions (CEMT, CEDA, CECI, CECS, CEDF, CEBR), reads system
information (z/OS level, CICS TS level, default user, sysid, LU name, dataset and
library high-level qualifiers), lists active users, and checks JCL/spool and ESM
access. Two things had stopped it. Its CEDF probe sends "CEDF ,OFF" and expects
"EDF MODE OFF"; the backend did not return that and left a non-typable screen, so
the following CEBR probe crashed with a keyboard-locked error. CEDF now returns
"THIS TERMINAL: EDF MODE OFF" for any OFF form. Its CEBR probe expects the browse
screen; bare CEBR now goes straight to an authentic temporary-storage browse
(header line, "ENTER COMMAND ===>", top/bottom-of-queue markers) rather than a
menu, which is also how real CEBR behaves.

The nmap scripts now work with their defaults. tn3270-screen reads the full VTAM
screen. vtam-enum finds TSO, CICS, and IMS. cics-enum returns exactly GIBSON's
implemented transaction set and rejects the hundreds it does not implement - it
had been reporting every transaction as valid because F3 on the CICS good-morning
screen dropped the session back to VTAM, so cics-enum's navigation (F3 then CLEAR
to reach a blank screen) never actually reached CICS and every probe was typed at
the VTAM logon. PF3 on the good-morning screen now clears to a blank CICS entry and
stays in CICS, which is real CICS behaviour. cics-user-enum now distinguishes valid
from invalid userids: an unknown userid returns DFHCE3530, a known userid awaiting a
password returns DFHCE3523, and a known userid with a wrong password returns
DFHCE3520, so it correctly reports CICSUSER and IBMUSER while rejecting bogus names.
CESL was routed to the sign-on panel alongside CESN (both are sign-on transactions,
matching GIBSON's own LOGON_TRANSACTION model and cics-user-enum's default; the log
display remains on CSMT). CEST keeps the word SUPERVISORY in its panel header.

cicspwn's PF3-based applid validation and its bare-id transaction detection were
re-checked after these changes and are unaffected, because it clears the screen
before pressing PF3 and it types bare transaction ids (which still start fresh).

One test that pinned the old, non-authentic behaviour was updated:
test_cics_pf3_returns_to_vtam became test_cics_pf3_at_good_morning_stays_in_cics
and now asserts that PF3 on the good-morning screen stays in CICS. Four files changed
from the uploaded baseline: gibson/services/tn3270_server.py, gibson/apps/cics3270/cics_session.py,
gibson/apps/cics.py, and tests/test_cics3270_m2.py. The CICS-focused test set passes
except for five failures that fail identically on the uploaded baseline (the CBSA/OMEN
test, the OMVS ping test, the SIT-state test, the socket-listener test, and golden
panels), so this change introduces no new failures. Caveat as always: this was verified
in-sandbox against real s3270 4.1 and real nmap 7.94; your s3270 and py3270 versions
differ slightly, but the wire behaviour is what these checks exercised.

## 2026-07-22  CICS environment made fuller: CEDA, CEBR, CEMT SET, and CEOT/CMAC/CWTO/CEST

The 3270 CICS wrapper had a rich backend (gibson/apps/cics.py) sitting behind it
that it had stopped calling for several transactions, so those transactions only
showed their menus. The wrapper now routes their sub-commands to the backend, and
the missing pieces were filled in.

CEDA now processes its sub-commands instead of re-showing the menu. DISPLAY lists
programs, files, transactions, or a whole group; DEFINE and ADD create program and
transaction definitions; ALTER changes a definition (STATUS updates take effect);
INSTALL, CHECK, and DELETE report their standard DFHCE responses. DISPLAY GROUP(x)
and ALTER were added to the backend; the others were already there. A bare CEDA
still shows the menu, and CEDA COPY is unchanged, so the RACF-bypass alias lab and
cicspwn's transaction detection are untouched.

CEBR now performs a real temporary-storage and transient-data browse. CEBR queue
name reads the queue and paints the item list with item numbers, and an unknown
queue returns DFHRESP(QIDERR). A bare CEBR still shows the menu.

CEMT SET and PERFORM now apply the change through the backend and narrow the panel
to the named resource, with the DFHCE3553 response shown on the panel. CEMT SET
PROGRAM(name) DISABLED disables just that program and the panel reflects the new
status; the state change persists in the running region. INQUIRE was given the same
treatment, so CEMT INQUIRE PROGRAM(name) or FILE(name) shows a single resource
rather than the whole table, matching real CEMT. A name that does not exist returns
the authentic NOT FOUND response.

CEOT, CEST, CMAC, and CWTO now paint full panels rather than a one-line
acknowledgement. CEOT shows own-terminal status, CEST lists the terminals with an
INQUIRE and SET form, CWTO writes the message to the console and the CSMT log, and
CMAC looks up a catalogue of the common DFH messages (DFHAC2001, DFHAC2206,
DFHAC2236, DFHCE3549, DFHCE3590, DFHCE3553, DFHSN1100, DFHPA1104) and prints the
explanation, system action, and user response, with a graceful message for numbers
not held locally. The inauthentic "Transaction: x" echo line that used to precede
these panels was removed for the supervisory and definition transactions, since
real CICS paints the panel directly.

One thing to know about this build: the version that was uploaded did not contain
the earlier redisplay fix for cicspwn or the interactive-submenu fix, so this ship
re-includes both. If you were running the uploaded copy, that is why cicspwn and the
submenus looked broken again. Three files changed from the uploaded baseline:
gibson/services/tn3270_server.py (the redisplay fix), gibson/apps/cics3270/cics_session.py
(submenus, CEMT/CEDA/CEBR routing and filtering, and the supervisory panels), and
gibson/apps/cics.py (CEDA ALTER and DISPLAY GROUP). Verified live with real s3270:
cicspwn reaches CICS and gets its DFHAC2001, the CEMT/CEDA/CEBR submenus work, CEMT
SET filters and changes state, and CEOT/CEST/CMAC/CWTO render full panels. The
CICS-specific test files pass (22 passed), and the only failing targeted test,
test_golden_panels, fails identically on the uploaded baseline (cics_gm, cics_entry,
cics_cemt_task), so this change introduces no new failures. Honest remaining limits:
CEDA ALTER records the change but does not yet model every attribute, and CEST SET
acknowledges rather than persisting per-terminal service state.

## 2026-07-22  cicspwn applid validation fixed over the real 3270 wire, plus CICS interactive submenus restored

The 2026-07-21 fix below added an input field to the VTAM NOT FOUND panel. That
was correct against synthetic frames but wrong against a real terminal, and it
never actually let cicspwn through. Running an authentic s3270 client against a
live GIBSON server exposed why. The NOT FOUND panel is built by _simple_screen,
which lays down its label text with plain unprotected put() rather than as
protected fields. A real 3270 client therefore treats the whole panel as one
unformatted field. When cicspwn typed CICS and pressed Enter, the client returned
the entire screen buffer with no field delimiter, GIBSON could not locate the
command field, and the applid resolved to garbage (a run of D0 40 40 bytes shown
as }@@@@@@@@@@). The main VTAM logon panel does not have this problem because it
is built by render_3270 with genuine protected labels and one unprotected
logon_type field.

The field approach on the NOT FOUND panel has been reverted. In its place, a bare
AID at the VTAM screen (Enter, Clear, or a PA key with no applid typed) now
redisplays the real logon panel, which is what a genuine VTAM USS does. cicspwn
presses Enter on connect before it types anything, so it now stays on the working
logon panel and types CICS into the properly formatted logon_type field. Verified
end to end with real s3270: the connect Enter redisplays the logon panel, CICS
reaches the CICS good-morning, and CLEAR then PF3 produces the DFHAC2001 that
check_valid_applid keys on. All logon routes were re-checked live and are
unchanged: L CICS and CICS reach CICS, L TSO and TSO reach the TSO/E logon panel,
and L DB2 reaches the DB2 command processor. The net change to tn3270_server.py is
one small block in handle_vtam.

Separately, the CICS interactive submenus were restored. Typing a bare
transaction (CEMT, CECI, CECS, CEDA, CEBR, CEDF) still shows its menu, but the
menu previously threw away the transaction context, so typing the invited
sub-command afterwards was parsed as a fresh transaction id. That is why CEMT
followed by "I TASK" reported DFHAC2001 Transaction 'I' not recognized. The menu
now remembers which transaction it belongs to, so a follow-up sub-command such as
"I TASK", "Inquire", or "S PROGRAM(x)" is routed to that transaction exactly as
real CICS keeps CEMT conversational. A bare transaction id typed at a menu still
starts fresh, so cicspwn's availability probing, which types bare ids and scrapes
the menu row, is unaffected. PF3 now ends the active transaction and returns a
blank CICS screen instead of the not-recognized probe message.

CEMT Set and Perform were also wired so they no longer dead-end at the menu; they
now drive the resource panel with the verb reflected in the header, and the
overtype action column continues to apply state changes. All nine CEMT INQUIRE
resources render (TASK, FILE, PROGRAM, TRANSACTION, TERMINAL, SYSTEM, DSNAME,
LIBRARY, TDQUEUE), CECI runs its command interpreter, and CESN, CESF, COPS, CEOT,
CMAC, CWTO, CEST, CSGM, and CEDF all respond. Honest current limits: CEDA beyond
the COPY and INSTALL alias lab (DISPLAY, DEFINE, ALTER) and CEBR temporary-storage
browse still re-show their menus rather than fully processing sub-commands, CEMT
Set does not yet filter to a single named resource, and CEOT, CMAC, CWTO, and CEST
return a short generic acknowledgement rather than full authentic panels. Nothing
in the CICS environment was removed.

Only two files changed from the prior build: gibson/services/tn3270_server.py and
gibson/apps/cics3270/cics_session.py. The targeted test suite was run against a
clean extract of the prior build and against this build. The same six tests fail
in both (test_golden_panels, the CBSA and OMVS ping and SIT-state tests, and the
two socket-listener tests), so this change introduces no new failures, and the 22
CICS-specific tests pass. One unrelated observation worth noting: the VTAM banner
test is fragile because a persisted system_identity.json in the default sim_root
(left holding BANKSYS1 by a banking lab test) leaks into the banner through the
GIBSON_SYSTEM_HOSTNAME environment variable, which can make that test fail
depending on run order. That is a pre-existing test-isolation issue, not part of
this change.

## 2026-07-21  VTAM "application not found" screen now accepts input (cicspwn applid validation)

The VTAM USS screen that reports an unresolved applid (IST097I APPLICATION x NOT
FOUND / UNABLE TO ESTABLISH SESSION) was built without an unprotected input
field. A terminal that pressed Enter at the VTAM screen without first typing an
applid, which is exactly what cicspwn's connect routine does on connect, was
routed to this screen and then had nowhere to type. Because an empty Enter
resolves to the AID name rather than a blank applid, it landed on the fieldless
NOT FOUND panel and could never go on to select CICS, so cicspwn reported
"Applid CICS not valid" even though the CICS side was correct and does emit the
DFHAC2001 it keys on.

The NOT FOUND screen is now created with a real unprotected input field and the
cursor placed in it, matching how a genuine VTAM USS logon panel lets you retry.
The screen text is unchanged, so the nmap vtam-enum responses and the
valid-versus-invalid screen-diff behaviour are preserved, and every applid route
(TSO, CICS, DB2, DSN, SDSF, ISPF, ZVM, IMS, TPF) is untouched. The change is a
single line in handle_vtam's fallback. Verified end to end: after the connect
Enter the terminal can now type CICS, reach the CICS good-morning, and CLEAR then
PF3 produces DFHAC2001. Regression checked by diffing the full targeted test
surface (35 files covering VTAM, screens, applid routing, CICS, TSO, ISPF, DB2,
SDSF, panels and the 3270 datastream) against the unmodified build: identical
results, no new failures.

## 2026-07-20  SECEVENTS audit hygiene + stale-test corrections

SECEVENTS and the SMF80 audit trail were being flooded by simulation plumbing.
Recording an SMF80 event wrote it to the SYS1.MAN* journal, and each of those
dataset touches was itself RACF-audited, producing a self-referential cascade.
Separately, the realism engines (threat-intel RSS feeds, zSecure compliance,
SYSVIEW monitoring) rewrite their own FIBS.CTI/ZSEC/SYSVIEW journal datasets on
essentially every command, and each write was audited, so a single command
emitted roughly fifteen dataset-access records that buried real events.

The SMF recording engine now writes to its MAN journal through an unaudited
system path (datasets.read/write gained an audit=True keyword; internal system
writes pass audit=False). Routine successful writes to the internal telemetry
journals (FIBS.CTI.*, FIBS.ZSEC.*, FIBS.SYSVIEW.*) are no longer recorded as
SMF80 events; failures and warnings still are, and real dataset access is
untouched. A banking-lab login now records just the WEBBANK LOGON, which appears
at the top of SECEVENTS; per-command audit noise dropped from about fifteen
records to one. No test depended on the internal-journal audit events.

Test maintenance (stale tests, no feature change): corrected the REST gateway
test to the refactored App8080 router (binds cbsa_api_port, CBSA banking on
/accounts); removed a dead import to a deleted module that had been blocking the
REXX/JCL maturity tests from collecting; fixed the EXECIO test to the real z/OS
ALLOC-then-EXECIO convention; updated the expanded VTAM logon banner assertion
and exercised passive pure-ASCII mode via GIBSON_2023_PASSIVE; fixed a lynx test
mock signature; and skipped the one test targeting the removed REST /indfile
endpoint (IND$FILE works over DFT/CUT). A full baseline diff confirms zero
net-new regressions.
## 2026-07-20  TShocker training-shell port is changeable end to end

The TShocker lab lets a training shell listen on a chosen port, but the port could not
actually be changed through the tool. Two host-side gaps:

The `tshocker` OMVS tool generated its JES job with `PARM='%CATSO '` and put the mode and
port only in a REXX SAY line, so the port never reached the PARM that the JES engine parses
(_extract_tshocker_mode). A job built by `tshocker -l --lport 40000` therefore started no
listener on 40000 (or at all) when submitted. The generated PARM now carries the mode and
port (`PARM='%CATSO L 40000'` for a listener, `PARM='%CATSO R host port'` for a reverse
callback), so the chosen port flows through start_training_shell and the shell binds it.

The FTP internal-reader reply from a JES upload reported the listener only in prose
("Training shell (tshocker) listening on port 40002"). It now also carries a machine-parseable
`tshocker_port=<port>` on the final 250 line, so a client can extract the actual bound port
(which matters precisely because the port is now settable) and connect. Verified end to end:
a job with a chosen free port binds that port, the reply reports it, and the training-shell
banner answers on it. Downloads, SQL mode and non-lab uploads are unchanged.
## 2026-07-20  Clean-room SHOWMVS batch job, and IND$FILE ASCII upload fix

SHOWMVS. A clean-room SHOWMVS ships as a submittable batch job, SYS1.JCLLIB(SHOWMVS), written
from scratch for GIBSON (JCL + a bit of HLASM + REXX) and not derived from any other SHOWMVS
source. SUBMIT 'SYS1.JCLLIB(SHOWMVS)' runs two steps: an assemble-and-go HLASM step that locates
the CVT and ECVT in live storage and announces the run by WTO, then a batch-REXX step that walks
the control-block image and prints the configuration report. It reports the same classes of
information a SHOWMVS-style utility does, read live from the image: product/FMID/release, sysplex,
current job, master catalog DSN, security manager and RACF dataset, the SSCVT subsystem chain, the
SVC table (with any authorised user SVC flagged), the APF-authorised library list, the ASVT
address spaces, and the TIOT DD allocations. Sections GIBSON does not model (online CPUs, real and
extended storage size, IPL date/time/volser, the virtual storage map, the UCB device table, the
LPA queue, and page data sets) are named and reported as not modelled rather than fabricated.

To carry the in-stream REXX (which itself contains '/*'), the JCL in-stream parser now honours
DD DATA,DLM=xx in both the JES collector and the JCL package parser; plain DD * is unchanged. The
MVP catalog SHOWMVS note now points at the runnable job.

IND$FILE ASCII upload. Text-mode uploads corrupted while downloads were fine. Two host-side causes:
first, the EBCDIC-versus-ASCII detector used a printable-byte ratio, but EBCDIC space (0x40) and
much EBCDIC punctuation fall inside the ASCII printable range 0x20-0x7E, so space-heavy EBCDIC
(indented source, JCL, columnar data) was misdetected as untranslated ASCII and decoded as Latin-1
into '@@@@' and high-Latin garbage. Second, only the ASCII path normalised line endings, so EBCDIC
records sent with CRLF (0x0D 0x25) kept a stray CR on every line. The detector now decodes the
payload both ways and keeps whichever yields more real text, which is reliable because the wrong
interpretation always scores far lower, and both decode paths fold CR/CRLF/EBCDIC-NL to a single
newline. Verified across five payload shapes and five client encodings, plus an end-to-end upload
through the real DFT host. Downloads and binary transfers are unchanged.

## 2026-07-20  MVP catalog honesty (Workstream B: B1)

The MVP package manager (`gibson/apps/mvp/`) no longer presents compiled or binary packages as
if they run. GIBSON interprets z/OS, it is not a CPU emulator, so pre-built XMI load modules,
compiled COBOL/PL-I, and device/VTOC/tape tools cannot execute here.

Each `Package` now has a `runnable` property (true only when it ships real REXX that runs on the
engine) and a plain `note` explaining why a non-runnable package cannot execute (XMI binary,
compiled load module, no VTOC modelled, HLASM control-block tool pending the matured assembler,
already provided natively, RAKF tooling versus RACF, and so on). `RX MVP LIST` gains a `Runs`
column, `RX MVP SHOW` prints `Runnable:` and the note, and `RX MVP INSTALL` of a non-runnable
package now says so plainly ("NOT runnable in the simulator" plus the reason) instead of faking a
clean install of a usable command; the install JCL is still placed in `{user}.MVP.CNTL` for study.

The fake canned-SAY REXX stubs were removed: SHOWMVS, SHOWSS, DISKMAP, AUPGM and TSOAUTHC printed
fabricated data. SHOWMVS/SHOWSS are HLASM control-block tools (the SHOWMVS-class B3 targets);
DISKMAP needs a VTOC GIBSON does not model; AUPGM is a compiled/RAKF utility (use the runnable
LISTAPF/ENUM); TSOAUTHC gains real REXX in B2. The genuinely-runnable set is now the real
control-block walkers (ENUM, ELVAPF, ELVSVC, ELVSELF, ACEE, LISTAPF, WHOAMI, SUBSYS, CATLIST,
DDLIST, SMFSTAT) plus RANDOMPW, which actually generates passwords.

The SMP/E Software Manager derives its runnable set from this catalog, so it now seeds and offers
only genuinely-runnable tools. `tests/test_smpe_installer.py` and `tests/parity_harness.py` were
updated to exercise real tools (WHOAMI, SUBSYS) rather than the removed stubs. No new regressions.

## 2026-07-20  ENUM / ELV.APF run for real (Workstream A: A1, A2, A3)

The bare-command and `EX` paths for ENUM and ELV.APF no longer fall back to a canned Python
simulation. Both are the real third-party REXX tools now, run on the full engine against the
live control-block image, and when no real exec is installed TSO answers honestly with
`IKJ56500I ... NOT FOUND` instead of a fake result.

Resolver (A1). `_resolve_installed_exec` in `gibson/apps/tso.py` was widened to search the
conventional libraries a user actually uploads to, in order: the named dataset, then
`{user}.EXEC`, `{user}.REXX`, `{user}.CLIST`, the bare sequential `{user}.NAME`, a dotted
`{user}.ELV.APF`, the SMP/E `{user}.MVP.EXEC`, and finally the SYSEXEC then SYSPROC concat.
The built-in ENUM and ELV.APF simulations in `_simulated_rexx_tool` were removed and the
`_run_rexx` fallback now returns an honest not-found.

REXX engine gaps (A2). Closing these was needed to run the genuine ENUM (2150 lines, all 13
options) and ELV.APF (list and escalate) end to end:
  - indirect `PROCEDURE EXPOSE (listvar)`, including stem exposure and write-back so sibling
    routines share `findings.` / `tsoUsers.` arrays (this alone was the real cause of the
    APF / SEC / SVC / PATH / TSOT failures, not just the four gaps first identified);
  - `USERID()` and `SYSCALLS('ON')` builtins, plus an `ADDRESS SYSCALL` command environment
    implementing `setpwent` / `getpwent` / `endpwent` over the RACF OMVS segments (USSU);
  - `FORMAT()` made tolerant of raw non-numeric storage bytes (VERS/ALL no longer abort with
    a decimal conversion error);
  - `INDEX()` builtin added;
  - multi-argument `PARSE ARG a, b` (the comma selects successive call arguments) with a full
    argument vector, so `AddToArray name, value` accumulates correctly (WHO);
  - `ADDRESS 'TSO' 'NEWSTACK'` with a quoted string environment now parses env and command
    separately, and NEWSTACK / DELSTACK / QSTACK are handled as REXX data-stack operations;
  - TESTAUTH answers from the real `TSOAUTH(TESTAUTH)` profile (TSTA);
  - a label boundary now implicitly closes an unbalanced DO/SELECT group, and `_kw_do` no
    longer swallows the following label as an "optional control variable after END" - this is
    what let ELV.APF's `check_priv:` register and resolve;
  - `EXIT` inside a called function terminates the whole exec (a bare-command clause was
    swallowing the control-flow exception), fixing a spurious double escalation submit;
  - the clause guard is configurable via `GIBSON_REXX_MAX_CLAUSES`.

Control-block image. The ASVT was realigned to the real z/OS layout: `ASVTMAXU` is now set at
`ASVT+x'204'` and the ASCB pointer array starts at `ASVT+x'210'`, and each ASCB carries a CSCB
(with the `CHTRKID` address-space type byte) and an OUCB. This bounds ENUM's WHO loop (it was
reading a bogus max from a misaligned slot and tripping the clause limit) and lets it classify
started tasks, TSO users, system tasks, and OMVS users. `gibson/tools/elv_self.py` and
`tests/test_rexx_cbwalk.py` were updated to the same real offsets.

ELV.APF escalation persists a real RACF state change: with the precondition met (the user has
UPDATE/ALTER on a library that is on the APF list) the Level B assemble-and-run flips the user
to SPECIAL; without it the ACEE patch is transient and does not stick, exactly as before.

Tests. Added `tests/test_real_enum_elvapf_end_to_end.py` (runs the real ENUM all options and
ELV.APF list/escalate/gated; skips cleanly if the third-party tools are not present, locate
them with `GIBSON_REAL_TOOLS_DIR`). Two GIBSON tests that asserted the old canned ENUM/ELV.APF
sim output were updated to the new honest not-found contract. Full suite otherwise unchanged;
no new regressions.


## IND$FILE dispatch fix (real DFT authoritative; no fake-success)

The panel-mode (TSOAPP) command path could let a typed IND$FILE GET/PUT fall through to a
text-simulation handler that printed "TRANSFER COMPLETE" without sending any structured-field
bytes - a real 3270 emulator (PHOSPHOR, c3270) would see success on screen but receive no file.

Fix: `_tsoapp_indfile_command` now ALWAYS claims an IND$FILE command (returns (cmd, ready))
so it can never reach the text simulation; the packet handler runs the real DFT engine when
at a READY prompt, or returns an honest "get to READY - no data transferred" message otherwise.
Validated end-to-end over a real TCP socket against PHOSPHOR's client, both directions, byte-
perfect (see verify_indfile_interop.py). IND$FILE + TSOAPP tests updated and green.

## IND$FILE dispatch fix (real DFT authoritative; no fake-success)

The panel-mode (TSOAPP) command path could let a typed IND$FILE GET/PUT fall through to a
text-simulation handler that printed "TRANSFER COMPLETE" without sending any structured-field
bytes - a real 3270 emulator (PHOSPHOR, c3270) would see success on screen but receive no file.

Fix: _tsoapp_indfile_command now ALWAYS claims an IND$FILE command (returns (cmd, ready)) so
it can never reach the text simulation; the packet handler runs the real DFT engine when at a
READY prompt, or returns an honest "get to READY - no data transferred" message otherwise.
Validated end-to-end over a real TCP socket against PHOSPHOR's client, both directions,
byte-perfect (see verify_indfile_interop.py). IND$FILE + TSOAPP tests updated and green.

---

## 2026-07-18  IND$FILE ASCII upload host-side receive fix

The DFT host stored a text-mode (ASCII) upload with `raw.decode("cp037")` over the whole
blob, which turned the EBCDIC newline 0x15 (the record separator) into U+0085 and lost the
line structure. Now, in text mode, the host splits the received wire on 0x15 first, then
decodes each record CP037 and rejoins with `\n` (`gibson/services/tn3270_server.py`,
`_run_indfile_dft` PUT branch). Binary uploads are unchanged. This pairs with the PHOSPHOR
client fix that translates ASCII<->EBCDIC (the client had been shipping raw ASCII, which the
host then read as EBCDIC = scrambled). Verified end-to-end by verify_indfile_interop.py
(now covering ASCII) and phosphor tests/test_indfile_ascii.py. indfile tests: 6/6 green.

---

## 2026-07-18 (2)  SMP/E Software Manager: seed the source library + cover all MVP tools

Two issues on the SMP/E Software Manager (M.2) panel are resolved:

1. **`<userid>.REXX(name)` source library was missing.** The panel told you to "edit it
   first" and RECEIVE read from `<userid>.REXX(name)`, but that PDS was never created, so
   RECEIVE only ever staged a stub. `smpe.seed_rexx_pds()` now creates `<userid>.REXX` with
   real, runnable REXX source for every tool the first time the Software Manager is opened
   (existing members are left untouched, so your edits survive). RECEIVE also falls back to
   the catalog source for a known tool if the member is absent.

2. **Only 5 tools were installable; the MVP INSTALL repo had far more.** The Software
   Manager CSI is now derived from the MVP catalog's runnable-REXX tools. It lists all 17:
   the five core GIBSON security tools pre-APPLIED (ENUM, ELVAPF, ELVSVC, ELVSELF, ACEE) and
   twelve more as AVAILABLE (AUPGM, CATLIST, DDLIST, DISKMAP, LISTAPF, RANDOMPW, SHOWMVS,
   SHOWSS, SMFSTAT, SUBSYS, TSOAUTHC, WHOAMI). RECEIVE + APPLY any of them from the panel and
   it runs from TSO with `ex 'NAME'`. The Software Manager and `RX MVP INSTALL` now share one
   source of truth (`gibson/apps/mvp/catalog.py`).

`gibson/tools/smpe.py` + the RECEIVE handler in `gibson/apps/ispf3270/ispf_session.py`.
`tests/test_smpe_installer.py` grew to 16 assertions (source-library seeding, full tool
coverage, install-and-run of an AVAILABLE tool, catalog fallback). The XMI/JCL packages in
the MVP catalog (real MVS 3.8j software like RPF, REVIEW, ISPF) remain sim-only and are not
listed as REXX-installable, which is correct.

---

## 2026-07-18 (3)  PF3 at the TSO READY prompt no longer logs you off

**Bug:** at the native TSO READY prompt, pressing F3 sometimes bounced the user back to the
VTAM logon screen (or logged them off). In the 3270 serve loop, TSO_READY handled only
PF12/PF24 (RETRIEVE) specially; every other AID, PF3 included, fell through to
`handle_tso(text)`, which re-submitted the command field. When that field held a VTAM
keyword (CICS, DB2, `LOGON APPLID(...)`, LOGOFF, ...) `handle_tso` switched the session to
VTAM. So PF3 effectively re-ran whatever was in the field.

**Fix (`gibson/services/tn3270_server.py`):** PF3 (and PF15, the secondary END on many
keymaps) at TSO_READY is now a no-op that redraws READY without submitting, keeping anything
already typed. ENTER still submits normally; the change is scoped to PF3/PF15 at TSO_READY.
Added the `AID_PF15` constant. `tests/test_tso_pf3_ready.py` (5 assertions) drives the real
serve loop: PF3 with a stale VTAM keyword in the field stays at READY and never calls
handle_tso/handle_vtam, an empty prompt is a clean no-op, and ENTER still submits.

Note: three unrelated tests still fail in the broad run (`test_tso3270_m1`,
`test_cics3270_m2` on the RACF `verify_password("BOB","BOB")` fixture, and `test_ispf_core_m4`
on an ISPF READY assertion). All pre-existing, none touched by this change.

---

## 2026-07-18 (4)  restore the BOB/BOB training user

**Bug:** the standard non-admin training logon BOB/BOB was missing from the seeded RACF
users. Several TSO/CICS/ISPF scenarios and their tests log on as BOB/BOB, so they failed at
`verify_password("BOB","BOB")` / never reached READY (this is what tripped test_tso3270_m1,
test_cics3270_m2 and test_ispf_core_m4 - all three were the same missing-user cause).

**Fix:**
- Added BOB to the seed database `gibson/assets/GACF.DB` (md5crypt password, non-SPECIAL,
  owner #SYSPROG) so a fresh install has it.
- Added a programmatic fallback in `gibson/core/state.py` (mirroring the CICSUSER seed): if
  the loaded GACF has no BOB, seed BOB/BOB with no forced password change. This guarantees
  BOB regardless of the GACF source (fresh install, an older `~/mfsim/GACF.DB`, or a custom
  harness GACF).
- BOB is a plain user: not SPECIAL, not revoked, no forced password change. The `ADDUSER BOB`
  authority test still passes (authority is checked before the already-defined check).

`tests/test_bob_training_user.py` (8 assertions) locks it in: seeded + authenticates, case
folding, wrong-password rejection, non-admin, and the omitted-GACF fallback. The four
BOB-dependent tests (test_tso3270_m1, test_cics3270_m2, test_ispf_core_m4,
test_workstream_e_breadth) now pass.

Unrelated pre-existing failures remaining in the full run (not touched by this change):
`test_golden_panels` (three CICS panels drifted from their golden masters; BOB does not
appear in those panels) and `test_passticket_lab` / `test_rexx_jcl_transfer_audit_upgrade`
(both import a removed test module `tests.test_banking_tn3270_web_lab`).

---

## 2026-07-18 (5)  SMP/E catalog now upgrades existing installs (CSI reconcile)

Follow-up to the SMP/E catalog work. The earlier change only built the full 17-tool
catalog for a *fresh* CSI; an install that already had a saved `<userid>.SMPE.CSI` (from a
previous run) kept showing the old 5-tool set, so the new tools never appeared on upgrade.

`smpe.load_csi` now reconciles an existing CSI against the current runnable-tool catalog on
every load: any catalog tool the CSI does not list is added as AVAILABLE, while existing
rows and their APPLIED/RECEIVED status are left untouched, and the `<userid>.REXX` source
library is (re)ensured. Existing installs pick up the full set automatically on next open,
no data reset required. `tests/test_smpe_installer.py` now 20 assertions (adds a stale-CSI
reconcile case that preserves a user's RECEIVED row).

Note on the PF3-at-READY fix (prior entry): re-verified end to end through the real
`_login_complete` -> TSO_READY path - F3 with a residual VTAM keyword in the command field
stays at READY and never calls handle_tso/handle_vtam. The fix is in this build; a session
still bouncing to VTAM on F3 is running an older build (or an installer that predates it and
needs rebuilding).

---

## 2026-07-18 (6)  IND$FILE ASCII upload: tolerate untranslated-ASCII clients

A user uploading a REXX in ASCII mode saw it stored as EBCDIC-decoded garbage
('êáìîñáï.../À/È/ËÁÈ'). Root cause: the client had sent the file's raw ASCII bytes with no
ASCII->EBCDIC translation (an older client build), and GIBSON decoded them as CP037.

GIBSON's text-mode PUT now detects this. `_looks_like_untranslated_ascii` distinguishes a
raw-ASCII payload (almost entirely printable 7-bit) from EBCDIC (full of >=0x80 letter bytes
and 0x40 spaces); `_decode_text_upload` decodes ASCII payloads as ASCII (normalising CRLF)
and EBCDIC payloads via the CP037 + 0x15-record path as before. Conforming clients
(c3270/x3270, and PHOSPHOR with the CP037 fix) are unaffected; non-conforming clients now
store clean text instead of garbage. `tests/test_indfile_ascii_tolerance.py` (7 assertions).

Download is unchanged and correct: GIBSON serves EBCDIC (CP037) on GET, which the client
must translate back. A client that does not (an old build) will render a downloaded text
file as garbage - that is a client-side decode and cannot be fixed on the host. Current
PHOSPHOR does translate on both upload and download.
