# -*- mode: python ; coding: utf-8 -*-
#
# Single-source PyInstaller spec for GIBSON.
#
# The application code lives in ONE place, the directory this spec sits in,
# which is also the install tree the book documents. All three OS build
# scripts use this same spec, launcher, requirements and icons.
#
#   source location : $GIBSON_SRC, else this spec's own directory
#   launcher / icons : alongside this spec
#
import os
import sys
from PyInstaller.utils.hooks import collect_submodules, collect_data_files, collect_all
from PyInstaller.building.datastruct import Tree

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"

# SPECPATH is injected by PyInstaller and is the directory of this spec.
KIT = SPECPATH
SRC = os.environ.get("GIBSON_SRC") or os.path.abspath(KIT)
if not os.path.isdir(os.path.join(SRC, "gibson")):
    raise SystemExit(f"[gibson.spec] source tree not found under {SRC} "
                     f"(set GIBSON_SRC, or run this from the tree that holds gibson/)")

# Make the single source importable so collect_submodules can enumerate it.
if SRC not in sys.path:
    sys.path.insert(0, SRC)

LAUNCHER = os.path.join(KIT, "gibson_launcher.py")
ICON = None
if IS_WIN and os.path.exists(os.path.join(KIT, "gibson.ico")):
    ICON = os.path.join(KIT, "gibson.ico")
elif IS_MAC and os.path.exists(os.path.join(KIT, "gibson.icns")):
    ICON = os.path.join(KIT, "gibson.icns")

# --- Gibson's own code (cli.py loads services dynamically via __import__) ----
hiddenimports = (collect_submodules("gibson")
                 + collect_submodules("legacy")
                 + collect_submodules("phosphor"))

# --- Non-.py assets across the package ---------------------------------------
datas = collect_data_files("gibson", include_py_files=False)
datas += collect_data_files("legacy", include_py_files=False)
# PHOSPHOR's GUI reads its fonts, skins, bezel art and shaders from its package
datas += collect_data_files("phosphor", include_py_files=False)

# Asset dirs that are NOT import packages but are read/served as data, including
# the bundled pen-test tools under gibson/assets/pentest/tools (run via the
# launcher's --run-tool mode) and the vendored xterm assets. Tree() yields a TOC
# passed to COLLECT below.
asset_trees = []
for rel in ("gibson/assets", "gibson/apps/dvca/assets"):
    abspath = os.path.join(SRC, rel)
    if os.path.isdir(abspath):
        asset_trees.append(Tree(abspath, prefix=rel))

# --- Third-party packages with lazy/dynamic imports or bundled data ----------
def _collect_safe(pkg):
    global datas, hiddenimports
    try:
        _d, _b, _h = collect_all(pkg)
        datas += _d
        hiddenimports += _h
        return _b
    except Exception as exc:  # pragma: no cover
        print(f"[gibson.spec] note: could not collect '{pkg}': {exc}")
        return []

binaries = []
for pkg in ("passlib", "Crypto"):
    binaries += _collect_safe(pkg)

# pywinpty (ConPTY backend for the pen-test shell) ships native helper files
# (the winpty .pyd plus winpty.dll / winpty-agent.exe) that PyInstaller does
# not pick up from the bare import, so collect them explicitly. The shell also
# has a dependency-free pipe fallback, so this is best-effort.
if IS_WIN:
    binaries += _collect_safe("winpty")

# Bundled pen-test tool dependencies (the [pentest] extra), frozen in so the
# tools run inside GIBSON's own Python via `gibson --run-tool`.
# GIBSON_LEAN=1 skips these (guaranteed-buildable core); the build scripts retry
# lean if the full freeze ever fails, so an installer is always produced.
LEAN = os.environ.get("GIBSON_LEAN", "") in ("1", "true", "TRUE", "yes")
# Stamp the build, so tool-check (and anyone reading the folder) can say plainly
# that a lean build left the course tools' packages out.
_flavour = os.path.join(os.path.abspath("build"), "gibson_build_flavour.txt")
os.makedirs(os.path.dirname(_flavour), exist_ok=True)
with open(_flavour, "w", encoding="utf-8") as _f:
    _f.write("LEAN\n" if LEAN else "FULL\n")
datas += [(_flavour, ".")]
if LEAN:
    print("[gibson.spec] GIBSON_LEAN set: skipping bundled pen-test tool dependencies.")
else:
    for pkg in ("textual", "dns", "aiohttp", "whois", "shodan",
                "scapy", "typer", "yaml", "folium", "branca",
                "py3270", "bs4", "certifi", "charset_normalizer",
                "cryptography",
                # ezrecon's image search (Pillow), document metadata (pypdf)
                # and favicon hashing (mmh3); PHOSPHOR's desktop GUI (pygame,
                # with its SDL libraries, and numpy)
                "PIL", "pypdf", "mmh3", "pygame", "numpy"):
        binaries += _collect_safe(pkg)

hiddenimports += [
    "feedparser", "websockets", "websockets.legacy", "telnetlib3",
    "rich", "psutil", "httpx", "requests",
    "flask", "jinja2", "werkzeug",
    "email.mime.text", "email.mime.multipart",
]
hiddenimports += ["curses", "_curses", "curses.ascii", "curses.has_key", "curses.panel"]
if IS_WIN:
    hiddenimports += ["winpty"]

block_cipher = None

a = Analysis(
    [LAUNCHER],
    pathex=[SRC],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # curses stays in: PHOSPHOR's full-screen TN3270 client (phosphor --client in
    # the pen-test shell) needs it for Tab between fields, PF keys and the cursor.
    # Without it PHOSPHOR fell back to its line prompt, where Tab never reached
    # the TSO/E logon panel's PASSWORD field.
    excludes=["tkinter", "test", "unittest", "pytest"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="gibson",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=ICON,
    uac_admin=bool(IS_WIN),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    *asset_trees,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="GIBSON",
)
