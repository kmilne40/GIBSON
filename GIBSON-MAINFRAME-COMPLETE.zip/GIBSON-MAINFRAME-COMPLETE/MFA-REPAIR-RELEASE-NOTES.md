# GIBSON-RACFnAUDIT-091126 MFA Repair (2026-11-20)

Base: GIBSON-RACFnAUDIT-091126-QA-VERIFIED.zip. All existing files are retained.

Fixed:
- /enroll/mfa alias on dashboard port 8443, with /mfa/enroll still supported.
- Always scannable, high-contrast QR enrolment SVG using bundled BSD-licensed QR generation when segno is unavailable.
- Cross-process refresh of enrolled/activated TOTP factors stored in UADS.
- Cross-process refresh of the master-console IPL PIN. Atomic state updates to prevent partial writes.
- MFA status displays the actual GIBSON host local clock to help troubleshoot clock-based PIN entry.

Verification in CPython 3.13 lab harness:
- 37 MFA tests passed; 3 skipped.
- 10 RACF course tests passed.
- Additional broad subsystem groups run: 134 passed, 5 skipped, 1 known failure (ZSEC main menu expectation).
- Earlier combined whole-suite run timed out in a service test; the full simulator is not certified regression-free.
- Physical Microsoft Authenticator camera testing and multi-host deployed services have not been performed.

Enrol: https://<GIBSON_HOST>:8443/enroll/mfa (or /mfa/enroll), follow activation instructions.
If the old account was enrolled with a stale code, re-enrol the account in the simulator and delete the old Authenticator entry.
Clock-based PIN: check the master console's MFA STATUS display for GIBSON HOST CLOCK and use that local HHMM, not your workstation's clock if they differ.

Dependency notice:
QR fallback is bundled with its BSD license under gibson/_vendor/qrcode. No new pip dependency is required.

Known unresolved test failure from the selected broader tests:
  tests/test_v30_283_extra_dashboard_editor.py::test_zsecure_smpe_rss_commands
The expected 'ZSECURE MAIN MENU' string differs from existing ZSEC help output; not part of the MFA patch.
