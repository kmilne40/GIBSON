"""NJE security lab orchestration (Chapter 10).

Models the post-authentication half of the NJE kill chain once a node password
is known: NMR operator-command injection (iNJEctor.py) and cross-node job
execution via ``/*XEQ`` under a forged Job-Header identity (NJHTOUSR), including
the RACF persistence payload and the operator-visible forensics a SOC would see
($HASP122 / IEF403I / IRR010I / IEF404I and SMF type 80).

Everything runs inside Gibson against its own RACF state - it is a safe, self
contained training exercise.
"""
from __future__ import annotations

import re
import uuid
from typing import Dict, List, Tuple

from gibson.core.nje import CHAPTER10_NODES

_RACF_CMD = re.compile(r"^\s*(ADDUSER|ALTUSER|ALU|PERMIT|RDEFINE|RALTER)\b", re.I)
_XEQ = re.compile(r"/\*XEQ\s+(\w+)", re.I)
_JOBNAME = re.compile(r"^//(\w+)\s+JOB\b", re.I | re.M)


def _apply_racf(state, line: str, asuser: str) -> List[str]:
    """Apply one RACF command from the remote job, returning forensic lines."""
    out: List[str] = []
    u = line.strip()
    uu = u.upper()
    try:
        if uu.startswith("ADDUSER"):
            m = re.match(r"ADDUSER\s+(\w+)", u, re.I)
            pw = re.search(r"PASS(?:WORD)?\(([^)]*)\)", u, re.I)
            special = "SPECIAL" in uu
            omvs = "OMVS(" in uu
            if m:
                uid = m.group(1).upper()
                state.racf.adduser(uid, pw.group(1) if pw else "", special=special, omvs=omvs)
                out.append(f" IRR010I USERID {uid} CREATED.")
        elif uu.startswith(("ALTUSER", "ALU")):
            m = re.match(r"(?:ALTUSER|ALU)\s+(\w+)", u, re.I)
            if m:
                uid = m.group(1).upper()
                kw = {}
                if "SPECIAL" in uu:
                    kw["special"] = True
                if "OMVS(" in uu:
                    kw["omvs"] = True
                pw = re.search(r"PASS(?:WORD)?\(([^)]*)\)", u, re.I)
                if pw:
                    kw["password"] = pw.group(1)
                state.racf.altuser(uid, **kw)
                if "SPECIAL" in uu:
                    out.append(f" IRR008I USERID {uid} ALTERED - SPECIAL ATTRIBUTE SET.")
        elif uu.startswith(("PERMIT", "RDEFINE", "RALTER")):
            res = state.dynamic_racf.command(u, asuser)
            if res:
                out.append(" " + res.splitlines()[0])
    except Exception as exc:  # never break the lab
        out.append(f" IKJ56700A RACF COMMAND ERROR: {exc}")
    return out


def xeq_execute(state, *, rhost: str, ohost: str, jcl_text: str,
                asuser: str = "", src_ip: str = "10.10.10.1") -> Tuple[List[str], Dict]:
    """Execute a cross-node job (``/*XEQ OHOST``) under the forged identity
    ``asuser`` (NJHTOUSR).  Applies any RACF commands in the job's SYSTSIN to
    the OHOST's RACF, emits the operator-visible forensics, records SMF 80 and
    fires the HMS ``nje_exec`` detection.  Returns (log_lines, info)."""
    rhost = (rhost or "GIBSON").upper()
    ohost = (ohost or "HAL").upper()
    asuser = (asuser or "IBMUSER").upper()
    jm = _JOBNAME.search(jcl_text or "")
    jobname = jm.group(1).upper() if jm else "HCKRNJE"
    jobid = "JOB" + str(abs(hash(jcl_text)) % 90000 + 10000)
    corr = "NJE-XEQ-" + uuid.uuid4().hex[:8].upper()

    log: List[str] = []
    # $HASP122 - job received over the mesh, then IEF403I bracket
    log.append(f"{jobid} $HASP122 {jobname}({jobid} FROM {rhost} ) RECEIVED AT {ohost}")
    log.append(f"{jobid} IEF403I {jobname} - STARTED - TIME=10.57.32")

    # Emit the job-receive and step evidence at the point those simulated events
    # occur.  These are live records, not seeded rows, and all share one
    # correlation id so SMF TIMELINE/ALERTS can join the chain.
    try:
        from gibson.core.smf.writer import record_generic
        from gibson.core.smf.records.type30 import job_step
        record_generic(
            state, 26, asuser, "NJE_JOB_RECEIVED",
            f"NJE JOB {jobname} RECEIVED FROM {rhost}",
            subtype="JES2", result="SUCCESS", subsystem="JES2", source_component="NJE",
            extra={"JOBNAME": jobname, "JOBID": jobid, "CORRELATION_ID": corr,
                   "SOURCE_NODE": rhost, "TARGET_NODE": ohost, "DIRECTION": "INBOUND",
                   "SOURCE_IP": src_ip},
        )
        job_step(
            state, userid=asuser, jobname=jobname, stepname="TSOCMD",
            program="IKJEFT01", result="SUCCESS", correlation_id=corr,
            detail="IKJEFT01 EXECUTED",
        )
    except Exception:
        pass

    # Execute the simple read-only Chapter 10 examples as well as the RACF
    # persistence payload. The live NJE TCP service routes jobs through JES2;
    # this helper mirrors that result for unit/lab calls that invoke xeq_execute
    # directly. Mutating RACF lines remain handled by the dedicated path below.
    try:
        blocks = {}
        current = None
        for raw_line in (jcl_text or "").splitlines():
            mdd = re.match(r"^//([A-Z0-9#$@]+)\s+DD\s+\*", raw_line, re.I)
            if mdd:
                current = mdd.group(1).upper(); blocks[current] = []; continue
            if current is not None:
                if raw_line.strip().startswith("/*"):
                    current = None; continue
                blocks[current].append(raw_line.rstrip())
        if re.search(r"EXEC\s+PGM=IKJEFT", jcl_text or "", re.I):
            from gibson.apps.tso import TsoCommandProcessor
            proc = TsoCommandProcessor(state, asuser)
            for cmd in blocks.get("SYSTSIN", []):
                clean = cmd.strip()
                if not clean or _RACF_CMD.match(clean):
                    continue
                if clean.upper().startswith("LISTUSER") and len(clean.split()) == 1:
                    clean = f"LISTUSER {asuser}"
                response = proc.run(clean)
                log.append(f"{jobid} READY")
                log.append(f"{jobid} {clean}")
                log.extend(f"{jobid} {ln}" for ln in str(response).splitlines())
        if re.search(r"EXEC\s+PGM=BPXBATCH", jcl_text or "", re.I):
            parms = "\n".join(blocks.get("STDPARM", []) or blocks.get("STDIN", []))
            log.append(f"{jobid} BPXBATCH UNIX COMMAND PROCESSOR STARTED")
            if re.search(r"(?:^|\s)(?:SH\s+)?ID(?:\s|$)", parms, re.I):
                log.append(f"{jobid} uid=190000585({asuser}) gid=1100000209(TEST)")
            else:
                log.append(f"{jobid} BPXBATCH completed RC=0000")
    except Exception:
        pass

    # apply each RACF command line found in the job (the persistence payload)
    applied: List[str] = []
    for raw in (jcl_text or "").splitlines():
        if _RACF_CMD.match(raw):
            command = raw.strip()
            applied.append(command)
            log += [f"{jobid} READY"] + [f"{jobid}  {command}"]
            cmd_log = _apply_racf(state, command, asuser)
            log += [f"{jobid}{ln}" for ln in cmd_log]
            verb = command.upper().split(None, 1)[0]
            if verb == "ALU":
                verb = "ALTUSER"
            try:
                from gibson.core.smf.records.type80 import racf_event
                failed = any("ERROR" in ln.upper() or "DENIED" in ln.upper() for ln in cmd_log)
                racf_event(
                    state, userid=asuser, event_name=verb,
                    result="FAILURE" if failed else "SUCCESS", class_name="RACF",
                    resource_name=command[:160], jobname=jobname,
                    correlation_id=corr, detail=command, terminal="NJE",
                    source_ip=src_ip,
                )
            except Exception:
                pass

    log.append(f"{jobid} IEF404I {jobname} - ENDED - TIME=10.57.34")

    try:
        from gibson.core.smf.writer import record_generic
        record_generic(
            state, 26, asuser, "NJE_OUTPUT_PROCESSED",
            f"NJE JOB {jobname} OUTPUT PROCESSED", subtype="JES2",
            result="SUCCESS", subsystem="JES2", source_component="JES2",
            extra={"JOBNAME": jobname, "JOBID": jobid, "CORRELATION_ID": corr,
                   "SOURCE_NODE": rhost, "TARGET_NODE": ohost, "DIRECTION": "INBOUND"},
        )
        record_generic(
            state, 57, asuser, "NJE_SYSOUT_RETURN",
            f"SYSOUT RETURNED FOR {jobname}", subtype="NJE-SYSOUT",
            result="SUCCESS", subsystem="JES2", source_component="NJE",
            extra={"JOBNAME": jobname, "JOBID": jobid, "CORRELATION_ID": corr,
                   "SOURCE_NODE": ohost, "TARGET_NODE": rhost},
        )
    except Exception:
        pass

    # Keep the existing high-level security event/HMS trail for compatibility.
    try:
        state.record_security_event(
            src_ip, "NJE XEQ",
            f"JOB={jobname} FROM={rhost} AT={ohost} ASUSER={asuser} "
            f"RACF_CMDS={len(applied)}",
            service="NJE", result="SUCCESS", addr=src_ip, terminal="NJE",
            correlation_id=corr)
    except Exception:
        pass

    # HMS detection - cross-node execution / lateral movement
    try:
        from gibson.apps.cti_hms import trigger_ttp
        trigger_ttp(state, "nje_exec", src_ip=src_ip, userid=asuser,
                    detail=f"/*XEQ {ohost} as {asuser} (NJHTOUSR forged) from {rhost}")
    except Exception:
        pass

    info = {"jobname": jobname, "jobid": jobid, "ohost": ohost, "rhost": rhost,
            "asuser": asuser, "racf_cmds": applied, "correlation_id": corr}
    return log, info


def nmr_inject(state, network, command: str, *, src_ip: str = "10.10.10.1",
               asuser: str = "GIBSON") -> str:
    """Run an injected NMR operator command (iNJEctor.py) against the JES2
    command processor, firing the HMS ``nje_nmr`` detection."""
    reply = network.command(command) or "$HASP000 OK"
    try:
        state.record_security_event(
            src_ip, "NJE NMR", f"OPCMD={command.strip()}",
            service="NJE", result="SUCCESS", addr=src_ip, terminal="NJE")
    except Exception:
        pass
    try:
        from gibson.apps.cti_hms import trigger_ttp
        trigger_ttp(state, "nje_nmr", src_ip=src_ip, userid=asuser,
                    detail=f"NMR injection: {command.strip()}")
    except Exception:
        pass
    return reply


# The canonical Chapter-10 persistence payload (racf.jcl, Listing 10-14).
RACF_JCL = (
    "//HCKRNJE JOB (1234567),'ABC 123',CLASS=A,MSGLEVEL=(0,0),MSGCLASS=K\n"
    "/*XEQ HAL\n"
    "//TSOCMD  EXEC PGM=IKJEFT01\n"
    "//SYSTSPRT DD SYSOUT=*\n"
    "//SYSTSIN  DD *\n"
    "ADDUSER  Z4CK PASSWORD(Z4CKPASS)\n"
    "ALTUSER  Z4CK TSO(ACCTNUM(ACCT#) PROC(ISPFPROC)) SPECIAL\n"
    "ALTUSER  Z4CK OMVS(UID(31337) PROGRAM(/bin/sh) HOME(/))\n"
    "/*\n"
)
