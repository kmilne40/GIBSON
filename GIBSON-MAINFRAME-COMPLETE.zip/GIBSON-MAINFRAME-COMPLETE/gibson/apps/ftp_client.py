from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from gibson.core.state import GibsonState
from gibson.render import colors
from gibson.render.input import SocketInputDriver
from gibson.apps.omvs import OmvsEnvironment


@dataclass
class FtpSessionState:
    host: str
    port: int
    remote_user: str = ""
    authed: bool = False
    remote_prefix: str = ""
    local_prefix: str = ""
    transfer_type: str = "ASCII"
    filetype: str = "SEQ"
    password: str = ""


# Sentinel returned by handle_command() to signal the session should end.
_FTP_QUIT = object()


class TsoFtpClientApp:
    """TSO-style simulated FTP client.

    This is intentionally a training-safe client surface that mirrors the z/OS
    FTP command/subcommand workflow without attempting to emulate every wire
    detail. It supports common subcommands used in classrooms: USER, ASCII,
    BINARY/IMAGE, PWD, CD, LCD, LS, DIR, GET, PUT, DELETE, SITE, QUOTE, STATUS
    and QUIT/BYE.

    SITE (and QUOTE SITE) take every z/OS FTP SITE parameter with IBM's
    abbreviations, so SITE FILE=JES, SITE FILETYPE=SQL and SITE JESJOBNAME=*
    all work, with the replies z/OS gives. In SEQ mode GET and PUT copy data
    sets directly, as before. In JES and SQL mode they are carried out by
    GIBSON's own FTP server over the network, exactly as a real TSO FTP client
    would do, so JES submission, job listings, spool retrieval and SQL queries
    behave identically from TSO and from any other FTP client.
    """

    def __init__(self, state: GibsonState, userid: str, host: str = "127.0.0.1", port: int | None = None):
        self.state = state
        self.userid = userid.upper()
        self.env = OmvsEnvironment(state)
        self.s = FtpSessionState(host=host or "127.0.0.1", port=int(port or state.config.ftp_port), local_prefix=self.userid, remote_prefix=self.userid)
        from gibson.services import ftp_zos as zf
        self.zs = zf.FtpSession(self.userid, interface_level=zf.default_interface_level())
        self._site_log: list[str] = []     # SITE arguments, replayed on the server connection
        self._ftp = None                   # ftplib connection for JES and SQL mode

    # ------------------------------------------------------------ server link
    def _server(self):
        """A logged-on ftplib connection to the FTP server, with every SITE
        given so far replayed on it. Raises ConnectionError when unreachable."""
        import ftplib
        if self._ftp is not None:
            try:
                self._ftp.voidcmd("NOOP")
                return self._ftp
            except Exception:
                self._ftp = None
        host = self.s.host if self.s.host not in ("", "0.0.0.0") else "127.0.0.1"
        try:
            f = ftplib.FTP(timeout=60)
            f.connect(host, self.s.port)
            f.login(self.s.remote_user, self.s.password)
        except ftplib.error_perm as exc:
            raise ConnectionError(str(exc))
        except Exception as exc:
            raise ConnectionError(f"EZA1554I Connection to server {host} port {self.s.port} failed: {exc}")
        f.sendcmd("TYPE A")
        for arg in self._site_log:
            try:
                f.sendcmd("SITE " + arg)
            except ftplib.Error:
                pass
        self._ftp = f
        return f

    def _close_server(self) -> None:
        if self._ftp is not None:
            try:
                self._ftp.quit()
            except Exception:
                pass
            self._ftp = None

    def _site(self, arg: str) -> str:
        arg = arg.strip()
        self.zs.userid = (self.s.remote_user or self.userid).upper()
        reply = self.zs.site(arg).replace("\r\n", "\n")
        self.s.filetype = self.zs.filetype
        if arg:
            self._site_log.append(arg)
            if self._ftp is not None:
                try:
                    self._ftp.sendcmd("SITE " + arg)
                except Exception:
                    pass
        return reply

    @staticmethod
    def _quoted(name: str) -> str:
        return "'" + name.strip("'\"") + "'"

    def _open_data(self, cmd: str):
        """Open a passive data connection and send CMD: (socket, 1xx reply).
        ftplib's ntransfercmd swallows the 1xx reply, which z/OS users read."""
        import ftplib
        import socket
        f = self._server()
        host, port = f.makepasv()
        conn = socket.create_connection((host, port), timeout=60)
        try:
            first = f.sendcmd(cmd)
        except ftplib.Error:
            conn.close()
            raise
        if not first.startswith("1"):
            conn.close()
            raise ftplib.error_reply(first)
        return conn, first

    def _transfer_in(self, cmd: str) -> tuple:
        """RETR or LIST/NLST over the server link: (first reply, text, final reply)."""
        import ftplib
        f = self._server()
        try:
            conn, first = self._open_data(cmd)
        except ftplib.Error as exc:
            return "", "", str(exc)
        chunks = []
        with conn:
            while True:
                b = conn.recv(65536)
                if not b:
                    break
                chunks.append(b)
        try:
            final = f.voidresp()
        except ftplib.Error as exc:
            final = str(exc)
        text = b"".join(chunks).decode("utf-8", errors="replace").replace("\r\n", "\n")
        return first, text, final

    def _transfer_out(self, cmd: str, text: str) -> str:
        import ftplib
        f = self._server()
        try:
            conn, first = self._open_data(cmd)
        except ftplib.Error as exc:
            return str(exc)
        with conn:
            conn.sendall(text.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8", errors="ignore"))
        try:
            final = f.voidresp()
        except ftplib.Error as exc:
            final = str(exc)
        return "\n".join(x for x in (first, final) if x)

    @staticmethod
    def _is_jobid(arg: str) -> bool:
        from gibson.services import ftp_zos as zf
        a = (arg or "").strip().strip("'")
        return zf.parse_jobid(a) is not None or zf.is_jobid_pattern(a)

    def _jes_sql_command(self, op: str, args: list):
        """GET, PUT, LS, DIR and DELETE in JES or SQL mode, through the server."""
        ft = self.zs.filetype
        if op in {"LS", "DIR"}:
            if ft == "SQL":
                return None                       # listings are ordinary in SQL mode
            arg = args[0] if args else ""
            if arg and not self._is_jobid(arg) and "*" not in arg:
                arg = arg.upper()
            first, text, final = self._transfer_in(("NLST" if op == "LS" else "LIST") + (f" {arg}" if arg else ""))
            return "\n".join(x for x in (first, text.rstrip("\n"), final) if x)
        if op == "DELETE" or op == "DELE" or op == "MDELETE":
            if not args:
                return "EZA1737I DELETE requires a job id"
            target = args[0] if self._is_jobid(args[0]) else self._quoted(self._norm_remote(args[0]))
            import ftplib
            try:
                return self._server().sendcmd(f"DELE {target}")
            except ftplib.Error as exc:
                return str(exc)
        if op == "PUT":
            if not args:
                return "EZA1736I PUT requires a local name"
            local = self._norm_local(args[0])
            remote = self._norm_remote(args[1]) if len(args) >= 2 else self._norm_remote(args[0])
            text = self._read_target(self.userid, local)
            return self._transfer_out(f"STOR {self._quoted(remote)}", text)
        if op == "GET":
            if not args:
                return "EZA1735I GET requires a remote name"
            if ft == "JES" and self._is_jobid(args[0]):
                remote_arg = args[0].strip("'").upper()
                default = remote_arg.replace(".", ".F") if "." in remote_arg else remote_arg
            else:
                remote = self._norm_remote(args[0])
                remote_arg = self._quoted(remote)
                if "(" in remote:
                    leaf = remote.split("(", 1)[1].rstrip(")")
                else:
                    leaf = remote.split(".")[-1] if remote.count(".") >= 2 else remote.split(".")[-1]
                default = f"{leaf[:8]}.RESULT" if ft == "SQL" else f"{leaf[:8]}.OUTPUT"
            local = self._norm_local(args[1]) if len(args) >= 2 else self._norm_local(default)
            first, text, final = self._transfer_in(f"RETR {remote_arg}")
            out = [x for x in (first,) if x]
            if text:
                self._write_target(self.userid, local, text)
                lines = text.rstrip("\n").split("\n")
                shown = lines[:200]
                out += shown
                if len(lines) > len(shown):
                    out.append(f"... {len(lines) - len(shown)} more lines in '{local}'")
            out.append(final)
            if text:
                out.append(f"Output written to '{local}'")
            return "\n".join(out)
        return None

    def _norm_remote(self, operand: str) -> str:
        raw = (operand or "").strip().strip("'").strip('"')
        if not raw:
            return self.s.remote_prefix
        if raw.startswith("/"):
            return raw
        value = raw.upper()
        if value.startswith(self.s.remote_user + ".") or value.startswith(("SYS1.", "TCPIP.", "CEE.")):
            return value
        return f"{self.s.remote_prefix}.{value}" if self.s.remote_prefix else value

    def _norm_local(self, operand: str) -> str:
        raw = (operand or "").strip().strip("'").strip('"')
        if not raw:
            return self.userid
        if raw.startswith("/"):
            return raw
        value = raw.upper()
        if value.startswith(self.userid + ".") or "." in value and value.split(".", 1)[0] in self.state.racf.users:
            return value
        return f"{self.userid}.{value}" if self.userid else value

    def _read_target(self, owner: str, target: str) -> str:
        if target.startswith("/"):
            vp = self.env.resolve(f"/u/{owner.lower()}", target)
            return self.env.read_text(vp)
        return self.state.datasets.read(owner, target)

    def _write_target(self, owner: str, target: str, text: str) -> None:
        if target.startswith("/"):
            vp = self.env.resolve(f"/u/{owner.lower()}", target)
            self.env.write_text(vp, text)
            return
        self.state.datasets.write(owner, target, text)

    def _list_remote(self, prefix: str) -> str:
        if prefix.startswith("/"):
            vp = self.env.resolve(f"/u/{self.s.remote_user.lower()}", prefix)
            real = self.env.real_path(vp)
            if not real.exists():
                return "EZA1701I REMOTE PATH NOT FOUND"
            if real.is_dir():
                return "\n".join(sorted(p.name for p in real.iterdir())) or "EZA1698I NO FILES FOUND"
            return real.name
        rows = self.state.datasets.listcat(self.s.remote_user, prefix=prefix)
        return "\n".join(r.name for r in rows) if rows else "EZA1698I NO FILES FOUND"

    def _banner(self) -> str:
        return (
            f"{colors.CLEAR}{colors.BLUE}EZA1450I IBM FTP CS V3R2\n"
            f"EZA1466I Connecting to {self.s.host},{self.s.port} ...\n"
            f"220 GIBSONFTP READY{colors.RESET}\n"
        )

    def _status(self) -> str:
        return "\n".join([
            f"Connected to {self.s.host}.",
            f"Mode: {self.s.transfer_type}  FILETYPE={self.s.filetype}",
            f"Remote prefix: {self.s.remote_prefix}",
            f"Local prefix: {self.s.local_prefix}",
            f"Logged in as: {self.s.remote_user}",
        ])

    def run(self, driver: SocketInputDriver, send: Callable[[str], None]) -> None:
        send(self._banner())
        user = driver.read_line(f"User ({self.s.host}:(none)): ").text.strip().upper() or self.userid
        pw = driver.read_line("Password: ", hidden=True, mask=True).text.strip()
        self.state.racf.load(merge=True)
        if not self.state.racf.verify_password(user, pw):
            self.state.note_failed_logon(user, "127.0.0.1", port=self.state.config.ftp_port, service="FTP-CLIENT")
            send(colors.RED + "530 Login incorrect.\n" + colors.RESET)
            return
        self.s.remote_user = user
        self.s.remote_prefix = user
        self.s.authed = True
        self.s.password = pw
        send(colors.GREEN + f"230 {user} logged in.\n" + colors.RESET)
        while True:
            res = driver.read_line("ftp> ")
            if res.key == "EOF":
                return
            resp = self.handle_command(res.text)
            if resp is _FTP_QUIT:
                send("221 Quit\n")
                return
            if resp:
                send(resp + "\n")

    def handle_command(self, raw: str):
        """Process one ftp> command line and return the response text to show,
        or _FTP_QUIT to end the session.  Single source of truth shared by the
        ASCII loop (run) and the TN3270 FTP sub-mode, so the two paths can't
        drift apart."""
        raw = (raw or "").strip()
        if not raw:
            return ""
        parts = raw.split()
        op = parts[0].upper()
        args = parts[1:]
        try:
            if op in {"QUIT", "BYE", "EXIT"}:
                self._close_server()
                return _FTP_QUIT
            if op == "HELP":
                return "OPEN USER ASCII BINARY IMAGE PWD CD LCD LS DIR GET PUT DELETE SITE QUOTE STATUS QUIT BYE"
            if op == "OPEN":
                self.s.host = args[0] if args else self.s.host
                if len(args) >= 2 and args[1].isdigit():
                    self.s.port = int(args[1])
                return f"EZA1466I Connecting to {self.s.host},{self.s.port} ...\n220 GIBSONFTP READY"
            if op == "USER":
                if len(args) < 2:
                    return "EZA1618I USER requires userid password"
                user, pw = args[0].upper(), args[1]
                self.state.racf.load(merge=True)
                if not self.state.racf.verify_password(user, pw):
                    return "530 Login incorrect."
                self._close_server()
                self.s.remote_user = user
                self.s.remote_prefix = user
                self.s.authed = True
                self.s.password = pw
                return f"230 {user} logged in."
            if op in {"ASCII"}:
                self.s.transfer_type = "ASCII"
                return "200 Representation type is Ascii NonPrint"
            if op in {"BINARY", "IMAGE"}:
                self.s.transfer_type = "IMAGE"
                return "200 Representation type is Image"
            if op == "SITE":
                return self._site(raw.split(None, 1)[1] if len(parts) > 1 else "")
            if op in {"QUOTE", "LITERAL"}:
                rest = raw.split(None, 1)[1] if len(parts) > 1 else ""
                sub = rest.split(None, 1)
                if not sub:
                    return "EZA1460I QUOTE requires a command"
                if sub[0].upper() == "SITE":
                    return self._site(sub[1] if len(sub) > 1 else "")
                import ftplib
                try:
                    return self._server().sendcmd(rest).replace("\r\n", "\n")
                except ConnectionError as exc:
                    return str(exc)
                except ftplib.Error as exc:
                    return str(exc)
            if self.zs.filetype in ("JES", "SQL") and op in {"GET", "PUT", "LS", "DIR", "DELETE", "DELE", "MDELETE"}:
                try:
                    resp = self._jes_sql_command(op, args)
                except ConnectionError as exc:
                    return (f"{exc}\nFILETYPE={self.zs.filetype} needs the GIBSON FTP server "
                            f"({self.s.host} port {self.s.port}); start GIBSON with FTP enabled.")
                if resp is not None:
                    return resp
            if op == "PWD":
                return f'257 "{self.s.remote_prefix}" is the current remote prefix'
            if op == "CD":
                if not args:
                    return "EZA1701I CD requires a remote dataset prefix or USS path"
                self.s.remote_prefix = self._norm_remote(args[0])
                return f'250 Remote prefix changed to "{self.s.remote_prefix}"'
            if op == "LCD":
                if not args:
                    return "EZA1702I LCD requires a local dataset prefix or USS path"
                self.s.local_prefix = self._norm_local(args[0])
                return f'250 Local prefix changed to "{self.s.local_prefix}"'
            if op in {"LS", "DIR"}:
                prefix = self._norm_remote(args[0]) if args else self.s.remote_prefix
                return self._list_remote(prefix)
            if op == "GET":
                if not args:
                    return "EZA1735I GET requires a remote name"
                remote = self._norm_remote(args[0])
                local = self._norm_local(args[1]) if len(args) >= 2 else self._norm_local(args[0])
                text = self._read_target(self.s.remote_user, remote)
                self._write_target(self.userid, local, text)
                return f"250 GET successful: {remote} -> {local}"
            if op == "PUT":
                if not args:
                    return "EZA1736I PUT requires a local name"
                local = self._norm_local(args[0])
                remote = self._norm_remote(args[1]) if len(args) >= 2 else self._norm_remote(args[0])
                text = self._read_target(self.userid, local)
                self._write_target(self.s.remote_user, remote, text)
                return f"250 PUT successful: {local} -> {remote}"
            if op == "STATUS":
                return self._status()
            if op in {"DELETE", "DELE"}:
                if not args:
                    return "EZA1737I DELETE requires a remote name"
                target = self._norm_remote(args[0])
                self.state.datasets.delete(self.s.remote_user, target)
                return f"250 {target} deleted."
            return "502 Command not implemented"
        except PermissionError as exc:
            return f"550 {exc}"
        except FileNotFoundError:
            return "550 File not found"
        except Exception as exc:
            return f"550 Command failed: {exc}"
