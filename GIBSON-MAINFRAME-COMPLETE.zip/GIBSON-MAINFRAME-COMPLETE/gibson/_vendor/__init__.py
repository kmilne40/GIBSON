"""Bundled QR matrix generation for dependable offline MFA enrolment."""
