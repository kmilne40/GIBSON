#!/bin/bash
# Joins the GIBSON ISO parts back into GIBSON-live-amd64.iso and checks it.
# Mac: put this file in the same folder as all the .partN files and
# double-click it (if macOS refuses, right-click it and choose Open).
# Linux: run  bash join-gibson-iso.command  in that folder.
set -e
cd "$(dirname "$0")"
ISO=GIBSON-live-amd64.iso
SUM=dae929afcb0d5ddfc9bb70b71745dd63187d5b5821a64565778ecb7afb02348f

if [ ! -f "$ISO.part0" ]; then
  echo "No $ISO.part0 here: put all the parts in this folder and run me again."
  exit 1
fi
n=0; parts=""
while [ -f "$ISO.part$n" ]; do parts="$parts $ISO.part$n"; n=$((n+1)); done

echo "Joining $n parts into $ISO ..."
cat $parts > "$ISO"

echo "Checking the SHA-256 checksum (this takes a minute) ..."
if command -v sha256sum >/dev/null; then
  GOT=$(sha256sum "$ISO" | cut -d' ' -f1)
else
  GOT=$(shasum -a 256 "$ISO" | cut -d' ' -f1)
fi

if [ "$GOT" = "$SUM" ]; then
  echo
  echo "OK: $ISO is complete and matches the published checksum."
  echo "You can now burn it or write it to a USB stick with balenaEtcher."
  echo "The .part files can be deleted."
else
  echo
  echo "CHECKSUM MISMATCH: expected $SUM"
  echo "                   got      $GOT"
  echo "One of the parts is damaged or incomplete. Download it again and rerun."
  rm -f "$ISO"
  exit 1
fi
