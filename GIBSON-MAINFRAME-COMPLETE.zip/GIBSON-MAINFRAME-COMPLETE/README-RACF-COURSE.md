# GIBSON-RACFnAUDIT-091126: Six-Day RACF Security Course

## Using, Securing and Auditing RACF

This release is based on the **newly supplied GIBSON-MAINFRAME-COMPLETE(1).zip** source distribution. It is not based on a rollback to the previous course ZIP. The earlier opt-in RACFCOURSE engine was ported onto the new source, with a new `gibson/course_racf/advanced.py` module for threat-led exercises and synthetic SMF audit evidence.

**48 hands-on labs over six training days: 32 updated foundational labs plus 16 advanced labs.** The student/master manual embeds worked answers for all 48; the separate instructor guide has teaching notes, demonstration scripts, evidence interpretation and marking guidance. Both documents also have PDF copies.

### Where to find the deliverables

- `course_091126/manual/RACF_48_Lab_Master_Manual_With_Answers.docx` (master learner manual and all answers)
- `course_091126/manual/RACF_48_Lab_Master_Manual_With_Answers.pdf` (print/reading)
- `course_091126/manual/RACF_48_Lab_Instructor_Guide.docx`
- `course_091126/manual/RACF_48_Lab_Instructor_Guide.pdf`
- `course_091126/RACF_48_Lab_Dependency_Manifest.json`
- `course_091126/RACF_48_Lab_Execution_Trace.txt`
- `course_091126/figures_and_captured_output/` (diagram and output images)

### Starting one isolated learner instance

Run these commands from the extracted `GIBSON-RACFnAUDIT-091126` directory on a Linux/macOS host with GIBSON's documented Python dependencies:

```sh
./course_091126/scripts/prepare-racf-course.sh student01
./course_091126/scripts/start-racf-course.sh student01
```

The preparation script sets `GIBSON_RACF_COURSE=1`, creates an isolated simulator state root (default `~/gibson-racf-audit/student01`) and seeds parent groups, instructor identities and reusable lab fixtures. It writes random setup credentials to a local mode-0600 file outside the distributed source tree. Use a **different instance and a different port set for each concurrent student**, or separate lab VMs/containers. Startup defaults to loopback rather than public network exposure.

### Course control and evidence commands

These `RACFCOURSE` commands are **simulator-only**, not IBM RACF z/OS commands:

```
RACFCOURSE PREPARE
RACFCOURSE PREFLIGHT
RACFCOURSE CHECK 1.3
RACFCOURSE CHECK 5.1
RACFCOURSE CHECK 6.8
RACFCOURSE INVENTORY
RACFCOURSE SCENARIO ACCESS
RACFCOURSE SCENARIO SETROPTS
RACFCOURSE SCENARIO SURROGATE
RACFCOURSE SCENARIO PRIVILEGE
RACFCOURSE SCENARIO CAMPAIGN
RACFCOURSE SMF LIST
RACFCOURSE SMF TYPE 80
RACFCOURSE SMF TYPE 119/11
RACFCOURSE SMF JOIN
RACFCOURSE DETECT
RACFCOURSE TTP
RACFCOURSE ACTORS
RACFCOURSE CASEFILE
RACFCOURSE CONTAIN DEVUSR
RACFCOURSE UNCONTAIN DEVUSR
```

Other scenario names are ACCESS, SETROPTS, COMPONENT, MULTISOURCE, SURROGATE, PRIVILEGE, RECON, DB2, INSIDER, CAMPAIGN and RESET. Events include **synthetic** SMF 30, 80, 81, 83, 119 (subtypes 11/12), and 1154 (subtype 83). Their descriptions are teaching analogues, not a guarantee of IBM-record format/semantics or byte-for-byte output. No actual MVS SMF/SAF/Db2/USS packet capture takes place. Threat actors are discussed as hypothetical motives/capability models; no attribution can be concluded from sample synthetic events alone. Some commands implement teaching analogues of behaviour rather than every real RACF operand.

### Lab programme

- Days 1–4: 32 retained and corrected labs, identity, permissions, datasets, general resources, auditing, USS and Db2.
- Day 5: 8 new labs about evidence inventory, SMF 80/81/83/1154, zERT and correlation, SURROGAT, BPX/APF, detection engineering.
- Day 6: 8 new labs about TTPs, reconnaissance, privileged Db2 access, account containment, timelines, insider scenarios, attribution and final investigation.

### Automated validation

- Simulator course dependency checks: **48 of 48 READY**.
- Executed lab commands: **237** across all 48 labs with **zero flagged errors** in the test harness.
- Scenarios exercised: **10**.
- Selected new and existing simulator regression tests: **23 passed**.
- Word manuals rendered to PDF for visual layout review.

These results are from the Python-based simulator on the attached source, not real z/OS 3.2, actual student multiuser sessions, or end-to-end tests of every service exposed by GIBSON. See the trace and summary files for scope. 

### Deployment and security notes

- The original mainframe simulator features and build scripts are preserved. The course engine remains **opt-in** through `GIBSON_RACF_COURSE=1`.
- Lab examples deliberately contain insecure configurations and simulated offensive activity; use a private training network.
- Do **not** execute `RACFCOURSE` strings against a real IBM RACF database. On real z/OS, use IBM-documented syntax and site-authorised operations.
- Leave cumulative lab objects in place until all dependent labs are complete; perform cleanup only during instructor-approved resets.
- The original 4-day guides in earlier versions are superseded by this six-day edition.
