# GIBSON 8443 web suite - additions in this package

This package is the GIBSON-MAINFRAME-COMPLETE (PASSTICKET-LAB) tree with the
browser-facing 8443 suite added, the Master Console rendering reworked so it is
clean rather than crooked, and the newer PHOSPHOR client wired in behind the web
3270 client. The standard Python install routine is unchanged: install with
`./install_gibson.sh`, grant port capabilities if you need the low ports, then
start with `./gibsonctl.sh start` (or `./run_gibson.sh`). Everything below runs
on the existing dashboard port (8443), with the pen-test shell on its own port.

## What you get on port 8443

A shared nav bar now sits at the top of every page:

    Dashboard  |  Master Console  |  3270 Client  |  Pen-Test Shell

- **Master Console** (`/console`) - the IBM-style master console as a web page.
  Reply to the IPL requests with the chips (or type them), supply a 4-digit MFA
  PIN at R 04 and a name at R 05, and the system comes up. Type any console
  command (D A,L, D R,R, and so on) in the box and press Enter.
- **3270 Client** (`/client`) - the PHOSPHOR `--client` experience in the
  browser, backed by the newer PHOSPHOR V5.5 client you provided (vendored as a
  minimal pure-stdlib subset). Right-hand keypad (PF1-PF24, PA1-PA3, Attn,
  SysRq, Clear), an OPERATOR row (Reset, NewLn, Enter, MENU, STRIP3270,
  Settings, Help, Quit), a long `:` command box, colour rendering and the
  STRIP3270 unhide/unprotect audit toggles. It is model 4 (80x43) by default.
- **Pen-Test Shell** - a scope-locked browser terminal on its own port
  (GIBSON_TOOLS_PORT, default 8022), bound to 127.0.0.1 and behind the dashboard
  credentials. Targets are restricted to 127.0.0.1 and sighberbank.com (plus
  subdomains); everything else is blocked by the sandbox wrappers, with the
  authorised-targets banner shown on login. It works on all three platforms:
  Linux and macOS use a stdlib PTY, Windows uses ConPTY through pywinpty.
  The workspace (~/mfsim/pentest) is seeded with the wordlists and the bundled
  course tools (see below).

## Bundled tools and wordlists (pen-test shell)

Wordlists, seeded into ~/mfsim/pentest/wordlists/ :
  - users.txt, passwords.txt   - the GIBSON/TSO/IMS/CICS accounts and weak set
  - subdomains.txt             - 230 subdomain labels: the common+mainframe base,
                                 the Chapter 6 confirmed subdomains, and a
                                 mainframe-ecosystem extension (the "top 100" the
                                 chapter note asks for, and then some)
  - wordlist.txt               - same content under the exact name Chapter 6 uses;
                                 also copied to the workspace root so
                                 `ezrecon subdomains --wordlist wordlist.txt sighberbank.com`
                                 works as written in the book
  - domains.txt                - related apex-domain candidates for discovering
                                 other domains the org may own (passive DNS / CT)

Course tools, bundled under ~/mfsim/pentest/tools/ with scope-guarded launchers
on PATH (ezrecon, zniff, tshocker, cicspwn, injector, njecli, nje-assess):
  - EZRecon   (Chapter 6 recon) - the launcher is `ezrecon`
  - zniff     (mainframe sniffer)
  - TShOcker  (listener / reverse shell)
  - cicspwn   (CICS attack tool)
  - NJElib / iNJEctor (NJE assessment) - `injector`, `njecli`, `nje-assess`

Every launcher scope-checks its arguments first: a hostname/IP/URL that is not
127.0.0.1 / localhost / sighberbank.com (+subdomains) is blocked before the tool
runs, while filenames (wordlist.txt, JCL, configs) and sub-commands are ignored,
so normal tool usage is unaffected. The tools run under the same Python that runs
GIBSON.

Their runtime dependencies are a pip extra, kept out of the base install:

    pip install -e ".[pentest]"

That pulls textual, dnspython, aiohttp, python-whois, shodan, scapy, typer,
PyYAML, folium and py3270. A few tools also need a system binary: EZRecon whois
needs `whois`, zniff live capture needs libpcap, and cicspwn's py3270 needs the
`s3270` binary from the x3270 suite. Without the extra, the launchers still
enforce scope; the tool itself reports the missing dependency.

## The rendering fix (the crooked console)

The old web console colourised the terminal's ASCII box-art and shipped it in a
`<pre>`. In a browser the box-drawing glyphs do not always share the advance
width of ASCII, so the panel borders drifted and looked untidy. The console now
renders as two CSS panes (OPERLOG on the left, SYSTEM PROCESSING on the right)
built from structured data, so the panes always align. The colour palette
(amber message IDs, green status words, red severity, cyan labels) is preserved,
and the underlying console behaviour is unchanged - this is presentation only.

## Credentials

All three web UIs share one HTTP Basic credential pair, keeping this tree's
original default dashboard user:

    Username : admin
    Password : gibsonadmin!

Override with GIBSON_DASHBOARD_USER / GIBSON_DASHBOARD_PASSWORD.

## Files added or changed

Added:
  phosphor/                              vendored minimal PHOSPHOR V5.5 subset
                                         (tn3270 client + datastream + telnet +
                                         tls + core/screen), pure stdlib
  gibson/services/web_client.py          web 3270 client (PHOSPHOR-backed)
  gibson/services/tools_shell.py         pen-test browser shell (port 8022)
  gibson/assets/xterm/                   vendored xterm.js 5.3.0 + fit addon
  gibson/assets/pentest/                 users.txt, passwords.txt wordlists

Changed:
  gibson/services/dashboard.py           nav bar; /console, /console/state,
                                         /console/command, /client, /client/state,
                                         /client/key routes; colouriser; clean
                                         CSS console page; default user -> gibson
  gibson/apps/master_console.py          console_web_model() (structured data for
                                         the clean web render); NJE in the status
                                         panel; .ipl_complete marker so the web
                                         console reflects a completed IPL
  gibson/cli.py                          --with-tools flag + serve wiring
  gibsonctl.sh, run_gibson.sh            start the pen-test shell by default
  pyproject.toml                         include phosphor*; package xterm/pentest

## Pen-test shell on Windows (ConPTY)

The shell now runs on Windows through ConPTY (pywinpty). At connect time GIBSON
picks the best available shell in this order and enforces the same target
allowlist for each:

  1. bash      - Git for Windows or WSL bash (reuses the POSIX scope wrappers)
  2. BusyBox   - busybox ash, if busybox.exe is on PATH (same POSIX wrappers)
  3. PowerShell- scope-enforcing wrapper functions generated into a profile
  4. cmd.exe   - .cmd scope wrappers on PATH

For the closest parity with the Linux lab, install Git for Windows so bash is
present; the shell will use it automatically. If pywinpty is somehow missing,
the shell says so and tells you to `pip install pywinpty`. The scope check
(127.0.0.1 + sighberbank.com only) holds on every one of these shells.

## Honest caveats

- The course tools (EZRecon, zniff, TShOcker, cicspwn, NJElib/iNJEctor) are now
  bundled and scope-guarded. Their Python deps install via `.[pentest]`; a few
  need a system binary (whois, libpcap, s3270) as noted above.
- The standard network binaries (nmap, hydra, nikto, etc.) are still not
  bundled; their scope-guarded wrappers enforce the allowlist and report when the
  real binary is not installed on the host.
- Basic auth over plain HTTP is fine for a loopback training lab. Do not expose
  8443 or 8022 beyond localhost without TLS; secure mode already wraps the
  dashboard socket.
- The vendored phosphor/ subset is only what the web client needs. If you later
  depend on the full PHOSPHOR package on the host, point web_client.py at it and
  delete the vendored copy.
