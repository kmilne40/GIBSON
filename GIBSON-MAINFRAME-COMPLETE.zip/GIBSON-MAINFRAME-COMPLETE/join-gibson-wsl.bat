@echo off
rem Joins the GIBSON-Linux.wsl parts back together and checks them.
rem Put this file in the GIBSON-MAINFRAME-COMPLETE folder with all the .partN
rem files and GIBSON-Linux.wsl.sha256, and double-click it. setup.exe needs
rem GIBSON-Linux.wsl for the WSL 2 install.
setlocal
cd /d "%~dp0"
set F=GIBSON-Linux.wsl
if not exist "%F%.part0" ( echo No %F%.part0 here - put all the parts in this folder and run me again. & pause & exit /b 1 )
echo Joining the parts into %F% ...
copy /b "%F%.part0" "%F%" >nul || goto :fail
set N=1
:next
if not exist "%F%.part%N%" goto :joined
copy /b "%F%"+"%F%.part%N%" "%F%.tmp" >nul || goto :fail
move /y "%F%.tmp" "%F%" >nul
set /a N+=1
goto :next
:fail
echo The join failed. Check there is at least 1.5 GB free on this drive. & pause & exit /b 1
:joined
echo Joined %N% parts.
if not exist "%F%.sha256" ( echo Joined, but %F%.sha256 is not here to check against. & pause & exit /b 0 )
for /f "usebackq tokens=1" %%H in ("%F%.sha256") do set WANT=%%H
echo Checking the SHA-256 checksum ...
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%F%').Hash.ToLower()"`) do set GOT=%%H
if /i "%GOT%"=="%WANT%" ( echo. & echo OK: %F% is complete and matches the published checksum. & echo Keep it in this folder and run build-windows.bat. The .part files can be deleted. ) else ( echo. & echo CHECKSUM MISMATCH: expected %WANT% & echo                    got      %GOT% & echo One of the parts is damaged or incomplete. Download it again and rerun. & del "%F%" )
pause
