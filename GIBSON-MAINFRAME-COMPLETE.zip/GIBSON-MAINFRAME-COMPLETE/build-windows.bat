@echo off
REM ===========================================================================
REM  GIBSON - make the Windows installer (single-source edition). Double-click.
REM
REM  Builds GIBSON-Setup.exe from the ONE source tree at
REM  the directory this script sits in, so there is no per-platform copy of the code to
REM  keep in step. The script is written to always leave you with something you
REM  can hand out, and to tell you exactly what happened if anything goes wrong:
REM
REM    * installs Python 3.12 automatically if it is not already present
REM    * creates a local .venv-build and installs the libraries plus PyInstaller
REM    * freezes GIBSON with every course tool's Python package, then checks
REM      the frozen gibson.exe can import them all. If the full freeze fails it
REM      STOPS: a lean build (no ezrecon, zniff or cicspwn packages) is made
REM      only when you ask for one with  set GIBSON_ALLOW_LEAN=1  and is then
REM      stamped LEAN, so the Pen-Test Shell says so rather than failing later
REM    * installs the Inno Setup compiler automatically if it is missing
REM    * if Inno still cannot be obtained, produces GIBSON-portable.zip instead
REM      so there is always a distributable result
REM    * writes a complete transcript to build-log.txt for diagnosis
REM
REM  You need an internet connection and roughly 2 GB free. The only file you
REM  distribute is GIBSON-Setup.exe, or GIBSON-portable.zip as the fallback.
REM ===========================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "KIT=%~dp0"
rem The build machinery and the source share one directory now, so the
rem source is simply here. GIBSON_SRC still overrides it.
if defined GIBSON_SRC ( set "SRC=%GIBSON_SRC%" ) else ( set "SRC=%~dp0." )
title GIBSON installer builder
set "LOG=%~dp0build-log.txt"
echo GIBSON build started %date% %time% > "%LOG%"
echo source: %SRC% >> "%LOG%"

echo(
echo ==========================================================
echo   GIBSON  -  building your Windows installer (single source)
echo   source: %SRC%
echo   A full log is written to build-log.txt
echo ==========================================================
echo(

if not exist "%SRC%\gibson" (
    echo [X] Source not found at %SRC%  ^(expected a gibson\ directory beside this script^).
    echo [X] source missing >> "%LOG%"
    pause & exit /b 1
)

taskkill /IM gibson.exe /F >nul 2>&1

REM ---- 1. Python -----------------------------------------------------------
call :FIND_PY
if not defined PYEXE ( echo [0/6] Installing Python 3.12 automatically... & call :INSTALL_PY & call :FIND_PY )
if not defined PYEXE (
    echo [X] Python could not be installed automatically.
    echo     Install Python 3.12 64-bit from https://www.python.org/downloads/windows/
    echo     tick "Add python.exe to PATH", then run this again.
    echo [X] Python not found >> "%LOG%"
    pause & exit /b 1
)
echo [1/6] Python: %PYEXE%
echo Python: %PYEXE% >> "%LOG%"

REM ---- 2. venv + dependencies ----------------------------------------------
REM A venv of its own, NOT the .venv that install_gibson.sh creates. The source
REM and the build machinery share a directory now, so one shared .venv would mean
REM a build injecting PyInstaller into the environment the lab itself runs from.
echo [2/6] Installing dependencies (the first run downloads them, please wait)...
if not exist ".venv-build\Scripts\python.exe" (
    %PYEXE% -m venv .venv-build >> "%LOG%" 2>&1 || ( echo [X] Could not create the virtual environment. See build-log.txt. & pause & exit /b 1 )
)
set "VPY=.venv-build\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip >> "%LOG%" 2>&1
"%VPY%" -m pip install -r requirements-build.txt >> "%LOG%" 2>&1 || ( echo [X] Dependency install failed. See build-log.txt. & pause & exit /b 1 )

REM ---- 3. freeze (full, then lean retry) -----------------------------------
echo [3/6] Freezing GIBSON from the single source (full build)...
if exist "build" rmdir /s /q "build"
if exist "dist"  rmdir /s /q "dist"
set "GIBSON_SRC=%SRC%"
set "GIBSON_LEAN="
"%VPY%" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "%LOG%" 2>&1
if exist "dist\GIBSON\gibson.exe" goto :VERIFY
if not "%GIBSON_ALLOW_LEAN%"=="1" (
    echo(
    echo [X] The full build did not complete, so no installer was made. A lean
    echo     build would install cleanly and then fail in the Pen-Test Shell, so
    echo     it is not made unless you ask: set GIBSON_ALLOW_LEAN=1 and run again.
    echo     The exact error is at the end of build-log.txt.
    echo(
    pause & exit /b 1
)
echo       Full build did not complete - GIBSON_ALLOW_LEAN=1, so making a LEAN build...
echo [retry] lean build >> "%LOG%"
if exist "build" rmdir /s /q "build"
if exist "dist"  rmdir /s /q "dist"
set "GIBSON_LEAN=1"
"%VPY%" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "%LOG%" 2>&1
set "GIBSON_LEAN="
if exist "dist\GIBSON\gibson.exe" (
    echo       LEAN build made. ezrecon, zniff and cicspwn will report NOT READY in
    echo       the Pen-Test Shell; tool-check there says so. Do not hand this out
    echo       as the full GIBSON.
    goto :FROZE
)
echo(
echo [X] PyInstaller could not produce gibson.exe, even with the lean build.
echo     Please send me build-log.txt in this folder; the exact error is at the
echo     end of it (open it and copy the last 30 or so lines).
echo(
pause & exit /b 1

:VERIFY
rem Check rather than assume: gibson.exe must carry every package the course
rem tools need, or the Pen-Test Shell would fail in the classroom. The check
rem reads the module list PyInstaller packed into gibson.exe instead of running
rem it: the Windows gibson.exe asks for administrator rights, so Windows refuses
rem to start it from here ("Access is denied"), and security software may block
rem a brand-new unsigned program. Reading it needs neither.
set "CHECKOUT=%TEMP%\gibson-toolcheck.txt"
"%VPY%" "%SRC%\scripts\check_frozen_build.py" "dist\GIBSON\gibson.exe" > "%CHECKOUT%" 2>&1
set "CHECKRC=!errorlevel!"
type "%CHECKOUT%" >> "%LOG%"
if "!CHECKRC!"=="1" (
    echo(
    echo [X] gibson.exe was built without some of the course tool packages:
    echo(
    type "%CHECKOUT%"
    echo(
    echo     Send me the line above and the end of build-log.txt.
    echo(
    pause & exit /b 1
)
if not "!CHECKRC!"=="0" (
    rem The check itself could not read gibson.exe. Fall back to what the freeze
    rem reported: the spec prints "could not collect" for any package it missed.
    findstr /c:"could not collect" "%LOG%" >nul && (
        echo(
        echo [X] The freeze could not collect some course tool packages:
        findstr /c:"could not collect" "%LOG%"
        echo(
        pause & exit /b 1
    )
    echo       Note: could not read gibson.exe to double-check its packages:
    type "%CHECKOUT%"
    echo       The freeze reported every package collected, so the build continues.
) else (
    echo       Course tool packages all present in gibson.exe
)
:FROZE
echo       OK - dist\GIBSON\gibson.exe

REM ---- 3b. the Pen-Test Shell's tools ----------------------------------------
REM GIBSON for Windows carries its own tools beside gibson.exe, in tools\: bash,
REM hydra, jumbo John with racf2john, nikto, wget, curl, netcat, telnet, ftp,
REM dig, host and the x3270 suite (scripts\bundle_windows_tools.sh builds them
REM in MSYS2). They come as windows-tools.zip, from the GIBSON for Windows
REM downloads, or as a windows-tools folder. nmap and Npcap are not included:
REM their licences do not allow it. Without the tools the build still works,
REM but the Pen-Test Shell then has only GIBSON's own Python tools.
if not exist "windows-tools\usr\bin\bash.exe" if exist "windows-tools.zip" (
    echo       Unpacking windows-tools.zip...
    "%SystemRoot%\System32\tar.exe" -x -f "windows-tools.zip" >> "%LOG%" 2>&1
)
if exist "windows-tools\usr\bin\bash.exe" (
    echo [3b/6] Adding the Pen-Test Shell's tools ^(hydra, John, nikto, s3270 ...^)
    robocopy "windows-tools" "dist\GIBSON\tools" /E /NFL /NDL /NJH /NJS /NP >> "%LOG%" 2>&1
    if !errorlevel! GEQ 8 ( echo [X] Could not copy the tools into the build. See build-log.txt. & pause & exit /b 1 )
    if not exist "dist\GIBSON\tools\usr\bin\bash.exe" ( echo [X] The tools did not arrive in the build. & pause & exit /b 1 )
    echo       Tools added
) else (
    if "%GIBSON_REQUIRE_TOOLS%"=="1" (
        echo [X] windows-tools.zip is missing, and GIBSON_REQUIRE_TOOLS=1 asks for the tools.
        pause & exit /b 1
    )
    echo       Note: no windows-tools.zip here, so this build has only GIBSON's own Python
    echo       tools in the Pen-Test Shell. Put windows-tools.zip beside this script for the rest.
)

REM ---- 4. the WSL pieces -----------------------------------------------------
REM setup.exe installs GIBSON into WSL 2 by default, from two files in wsl\:
REM   GIBSON-Linux.wsl  the GIBSON Linux distribution (built on Linux by
REM                     iso/build-wsl.sh, and shipped with the ISO downloads)
REM   wsl.x64.msi       Microsoft's WSL package, so a machine with no WSL, or an
REM                     old one, needs neither the Microsoft Store nor internet
REM The WSL package is pinned by version and SHA-256 and checked after download.
set "WSL_MSI_VER=2.7.13"
set "WSL_MSI_SHA=A3505A50F4CC585551D11D9DE824BA4375448D7A68F2E71D3FB315FA986FC754"
echo [4/6] Gathering the WSL pieces...
if not exist "wsl" mkdir "wsl"
if not exist "wsl\GIBSON-Linux.wsl" if exist "GIBSON-Linux.wsl" copy /y "GIBSON-Linux.wsl" "wsl\GIBSON-Linux.wsl" >nul
if not exist "wsl\GIBSON-Linux.wsl" if exist "GIBSON-Linux.wsl.sha256" (
    echo [X] GIBSON-Linux.wsl.sha256 is here but GIBSON-Linux.wsl is not. Join its
    echo     download parts first: double-click join-gibson-wsl.bat
    pause & exit /b 1
)
if not exist "wsl\GIBSON-Linux.wsl" (
    echo [X] wsl\GIBSON-Linux.wsl is missing. Put GIBSON-Linux.wsl from the GIBSON
    echo     downloads beside this script ^(or in wsl\^), or build it on Linux with
    echo     sudo ./iso/build-iso.sh  then  sudo ./iso/build-wsl.sh
    echo [X] GIBSON-Linux.wsl missing >> "%LOG%"
    pause & exit /b 1
)
set "SUMFILE="
if exist "wsl\GIBSON-Linux.wsl.sha256" set "SUMFILE=wsl\GIBSON-Linux.wsl.sha256"
if not defined SUMFILE if exist "GIBSON-Linux.wsl.sha256" set "SUMFILE=GIBSON-Linux.wsl.sha256"
if defined SUMFILE (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=(Get-Content '%SUMFILE%' -TotalCount 1).Split(' ')[0]; $h=(Get-FileHash 'wsl\GIBSON-Linux.wsl' -Algorithm SHA256).Hash; if ($h -ne $w.ToUpper()) { exit 1 }" || (
        echo [X] wsl\GIBSON-Linux.wsl does not match %SUMFILE%. Download or join it again.
        pause & exit /b 1
    )
    echo       GIBSON-Linux.wsl checksum OK
)
call :WSL_MSI_OK
if not defined MSI_OK (
    echo       Downloading Microsoft's WSL %WSL_MSI_VER% package from GitHub...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://github.com/microsoft/WSL/releases/download/%WSL_MSI_VER%/wsl.%WSL_MSI_VER%.0.x64.msi' -OutFile 'wsl\wsl.x64.msi' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
    call :WSL_MSI_OK
)
if not defined MSI_OK (
    echo [X] Could not get Microsoft's WSL package with the expected checksum. Download
    echo     https://github.com/microsoft/WSL/releases/download/%WSL_MSI_VER%/wsl.%WSL_MSI_VER%.0.x64.msi
    echo     yourself and save it as wsl\wsl.x64.msi, then run this again.
    pause & exit /b 1
)
echo       WSL package %WSL_MSI_VER% OK

REM ---- 5. Inno Setup compiler ----------------------------------------------
echo [5/6] Checking for the Inno Setup compiler...
call :FIND_ISCC
if not defined ISCC (
    where winget >nul 2>&1
    if !errorlevel! EQU 0 (
        echo       Installing Inno Setup via winget ^(you may see a prompt^)...
        winget install -e --id JRSoftware.InnoSetup --silent --accept-package-agreements --accept-source-agreements >> "%LOG%" 2>&1
        call :FIND_ISCC
    )
)
if not defined ISCC (
    echo       Downloading Inno Setup directly...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://jrsoftware.org/download.php/is.exe' -OutFile 'innosetup-setup.exe' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
    if exist "innosetup-setup.exe" (
        innosetup-setup.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-
        del /q "innosetup-setup.exe" >nul 2>&1
        call :FIND_ISCC
    )
)
if not defined ISCC goto :NOINNO
echo       Compiler ready: "!ISCC!"

REM ---- 6. compile the installer --------------------------------------------
echo [6/6] Building the installer...
if exist "Output" rmdir /s /q "Output"
"!ISCC!" "gibson.iss" >> "%LOG%" 2>&1 || ( echo [X] Installer compile failed. See build-log.txt. & pause & exit /b 1 )
REM Copy whatever Inno produced to the single distributable name, whatever it
REM called it, so a filename drift can never leave you without GIBSON-Setup.exe.
if exist "Output\setup.exe" ( copy /y "Output\setup.exe" "GIBSON-Setup.exe" >nul ) else (
    for %%F in ("Output\*.exe") do copy /y "%%F" "GIBSON-Setup.exe" >nul
)
if not exist "GIBSON-Setup.exe" (
    echo [X] The installer compiled but no .exe appeared in Output. See build-log.txt.
    pause & exit /b 1
)

echo(
echo ==========================================================
echo   DONE   -^>   %~dp0GIBSON-Setup.exe
echo   Hand GIBSON-Setup.exe to your users. On Windows 10 22H2 or Windows 11 it
echo   turns on WSL 2, restarts once if needed, and installs the GIBSON Linux
echo   system with every Pen-Test Shell tool; elsewhere it installs GIBSON for
echo   Windows, which carries its own tools (all but nmap).
echo ==========================================================
echo(
explorer "%~dp0" >nul 2>&1
pause
exit /b 0

:NOINNO
REM Inno could not be obtained (no winget, and the download was blocked). Make a
REM portable zip so there is still something to distribute, and say so plainly.
echo       Inno Setup is not available and could not be downloaded on this machine.
echo       Producing a portable ZIP instead so you still have a distributable build...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\GIBSON\*' -DestinationPath 'GIBSON-portable.zip' -Force" >> "%LOG%" 2>&1
echo(
echo ==========================================================
echo   The application built correctly, but GIBSON-Setup.exe needs the Inno
echo   Setup compiler, which this machine could not install (no winget, or the
echo   download to jrsoftware.org was blocked by a firewall or proxy).
echo(
if exist "GIBSON-portable.zip" (
  echo   Fallback produced:  %~dp0GIBSON-portable.zip
  echo   Users unzip it and run gibson.exe - no installer needed.
)
echo(
echo   To get GIBSON-Setup.exe: install Inno Setup 6 once from
echo       https://jrsoftware.org/isdl.php
echo   then run this build again. Nothing else changes.
echo ==========================================================
echo(
explorer "%~dp0" >nul 2>&1
pause
exit /b 0

REM ===========================================================================
:WSL_MSI_OK
set "MSI_OK="
if not exist "wsl\wsl.x64.msi" goto :eof
powershell -NoProfile -ExecutionPolicy Bypass -Command "if ((Get-FileHash 'wsl\wsl.x64.msi' -Algorithm SHA256).Hash -ne '%WSL_MSI_SHA%') { exit 1 }" && set "MSI_OK=1"
goto :eof

:FIND_PY
set "PYEXE="
rem Only Python 3.10 to 3.12. A newer one (3.13, 3.14, 3.15) is not used even
rem when it is the only Python here: several course packages have no Windows
rem builds for it yet (frozenlist, PyYAML, windows-curses on 3.15), so the
rem freeze would leave them out. Python 3.12 is installed instead.
for %%V in (3.12 3.11 3.10) do ( if not defined PYEXE ( py -%%V -c "import sys" >nul 2>&1 && set "PYEXE=py -%%V" ) )
if not defined PYEXE ( for %%P in ("%LocalAppData%\Programs\Python\Python312\python.exe" "%LocalAppData%\Programs\Python\Python311\python.exe" "%ProgramFiles%\Python312\python.exe") do if not defined PYEXE if exist %%P set "PYEXE=%%~P" )
if not defined PYEXE ( python -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,12) else 1)" >nul 2>&1 && set "PYEXE=python" )
goto :eof

:INSTALL_PY
where winget >nul 2>&1
if !errorlevel! EQU 0 (
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements >> "%LOG%" 2>&1
    goto :eof
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile 'python-setup.exe' -UseBasicParsing } catch { exit 1 }" >> "%LOG%" 2>&1
if exist "python-setup.exe" ( python-setup.exe /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 & del /q "python-setup.exe" >nul 2>&1 )
goto :eof

:FIND_ISCC
set "ISCC="
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe") do if not defined ISCC if exist %%P set "ISCC=%%~P"
if not defined ISCC ( for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I" )
goto :eof
