#!/usr/bin/env bash
# ===========================================================================
#  Fetch a GIBSON source tree from a git repository (optional).
#
#  The source and the build machinery now share one directory, which is the
#  install layout the book documents. That means this script must NOT replace
#  the directory it lives in: doing so would take the build scripts, the spec
#  and the icons with it. So it clones into a sibling directory instead and
#  tells you how to build from there, which also lets you keep more than one
#  tree side by side.
#
#  The repo must contain the GIBSON tree at its root (gibson/, phosphor/,
#  pyproject.toml, install_gibson.sh, ...).
#
#  Usage:
#     ./sync-source.sh [git-url] [branch]
#  Defaults:
#     git-url : $GIBSON_REPO, else the OffensiveSec GIBSON repo
#     branch  : $GIBSON_BRANCH, else the repo default branch
# ===========================================================================
set -euo pipefail
cd "$(dirname "$0")"
REPO="${1:-${GIBSON_REPO:-https://github.com/kmilne40/GIBSON.git}}"
BRANCH="${2:-${GIBSON_BRANCH:-}}"
HERE="$(pwd)"
DEST="${GIBSON_SYNC_DEST:-$HERE/../gibson-source-$(date +%Y%m%d%H%M%S)}"

command -v git >/dev/null 2>&1 || { echo "[ERROR] git is not installed."; exit 1; }
echo "Syncing source from: $REPO ${BRANCH:+(branch $BRANCH)}"
echo "          into      : $DEST"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
if [ -n "$BRANCH" ]; then
  git clone --depth 1 --branch "$BRANCH" "$REPO" "$TMP/repo"
else
  git clone --depth 1 "$REPO" "$TMP/repo"
fi

if [ ! -d "$TMP/repo/gibson" ]; then
  echo "[ERROR] the repo does not contain a gibson/ directory at its root."
  echo "        Point this at the repo that holds the GIBSON web-suite source."
  exit 1
fi

# Never write over the directory this script lives in: the build machinery is
# in there now.
if [ "$(cd "$DEST" 2>/dev/null && pwd || true)" = "$HERE" ]; then
  echo "[ERROR] refusing to overwrite $HERE, which holds the build machinery."
  echo "        Set GIBSON_SYNC_DEST to a different directory."
  exit 1
fi
rm -rf "$TMP/repo/.git"
mkdir -p "$DEST"
cp -a "$TMP/repo/." "$DEST/"
DEST_ABS="$(cd "$DEST" && pwd)"
echo
echo "Done. The fetched tree is at:"
echo "    $DEST_ABS"
echo
echo "Build from it by pointing GIBSON_SRC at it, for example:"
echo "    GIBSON_SRC=\"$DEST_ABS\" ./build-linux.sh"
