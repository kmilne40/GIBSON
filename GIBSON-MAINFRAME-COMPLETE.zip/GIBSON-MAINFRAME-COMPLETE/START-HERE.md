# Start here

This folder is the whole GIBSON kit. Everything needed to build GIBSON-Setup.exe, the macOS packages, the Linux build and the ISO is in it, along with the guides and the release READMEs, so there is nothing to download separately apart from the large GIBSON Linux and ISO images.

## Building GIBSON-Setup.exe on Windows

1. If you have an older `GIBSON-MAINFRAME-COMPLETE` folder, rename it first (right-click it, choose **Rename**, and call it `GIBSON-MAINFRAME-COMPLETE-old`), so nothing old is mixed in with the new kit.
2. Right-click `GIBSON-MAINFRAME-COMPLETE.zip`, choose **Extract All...**, choose the folder that should hold it (for example `D:\GIBSON-BUILDS`), and click **Extract**.
3. Put `GIBSON-Linux.wsl` in the new `GIBSON-MAINFRAME-COMPLETE` folder. If the old folder has a `wsl` folder holding `GIBSON-Linux.wsl`, copy that whole `wsl` folder across. Otherwise put the `GIBSON-Linux.wsl.part0`, `GIBSON-Linux.wsl.part1` and `GIBSON-Linux.wsl.sha256` downloads in the new folder and double-click `join-gibson-wsl.bat`, then wait for `OK: GIBSON-Linux.wsl is complete and matches the published checksum.`
4. Put `windows-tools.zip` (from the GIBSON for Windows downloads) in the same folder, as it is, without unzipping it. It holds the Pen-Test Shell's tools for PCs without WSL 2 (hydra, John, nikto, s3270 and the rest), and the build adds them to GIBSON-Setup.exe as step [3b/6]. Without it the installer still works, but in Windows mode the shell has only GIBSON's own Python tools.
5. Double-click `build-windows.bat`. If SmartScreen appears, click **More info**, then **Run anyway**. When the window shows `DONE -> ...\GIBSON-Setup.exe`, press any key to close it.
6. `GIBSON-Setup.exe` in that folder is the only file to give to students.

To check that a folder has the current Windows launcher, open its `windows` folder in Explorer: `gibson-launch.ps1` is 7 KB and `gibson-native.ps1` is 9 KB, and `gibson-diagnose.cmd` is there. If GIBSON ever will not start on a PC, the Start menu entry **GIBSON diagnostics** collects a report, `GIBSON-diagnostics.txt` in the user's folder, to send with the question.

## Building the Mac disk image

1. On the Mac that will build GIBSON, install Apple's Command Line Tools: open **Terminal**, type `xcode-select --install`, press **Enter**, and click **Install**. Nothing else is needed. The build installs python.org's Python 3.12 by itself if it is missing, and it needs no Homebrew, because it builds every Pen-Test Shell tool from source.
2. Double-click `GIBSON-MAINFRAME-COMPLETE.zip` in Finder to unzip it.
3. In Terminal, type `cd ` with a space after it, drag the `GIBSON-MAINFRAME-COMPLETE` folder into the window, and press **Enter**. Then type `chmod +x build-macos.command` and press **Enter**, and `./build-macos.command` and press **Enter**.
4. The first build takes about 30 to 40 minutes, because it compiles the Pen-Test Shell tools into GIBSON; later builds reuse them and are quicker. It ends with `===== DONE =====`, and `Output/GIBSON-Installer-arm64.pkg` (on an Apple Silicon Mac) is the file to give to students, with `Output/GIBSON-arm64.dmg` as an alternative. Every tool is inside, built to run on macOS 11 and later, so students install nothing else.

The private `gibson-macos` repository on GitHub runs this same build on GitHub's own Macs, installs the PKG on clean macOS 15 and macOS 26 Macs and tests every tool against the running lab, so a PKG from a green run there has already been proven.

The same repository builds the other two the same way. Its ISO workflow builds the ISO and the WSL image, boots the ISO with BIOS, UEFI and Secure Boot, runs every tool test inside the booted live system, and only then publishes the ISO, its parts and the join tools as a release. Its Windows workflow builds windows-tools.zip and GIBSON-Setup.exe, installs the setup in Windows mode on clean Windows Server 2022 and 2025 machines, and tests every tool there, from a script and by typing into the Pen-Test Shell itself, before it publishes them.

## What else is here

| Where | What |
| --- | --- |
| `docs/guides/` | The GIBSON Mainframe Lab Guide and its two chapters, as PDF and Word files |
| `docs/release/README-WINDOWS.md` | The GitHub README for the GIBSON-Setup.exe release |
| `docs/release/README-ISO.md` | The GitHub README for the ISO release |
| `docs/release/README-MACOS.md` | The GitHub README for the macOS .dmg release |
| `README-BUILD.md` | How the kit is laid out and how each platform's build works |
| `CHANGELOG-GIBSON.md` | What changed, newest first |
| `join-gibson-wsl.bat`, `join-gibson-wsl.command` | Join the GIBSON-Linux.wsl download parts (Windows; Mac or Linux) |
| `join-gibson-iso.bat`, `join-gibson-iso.command` | Join the ISO download parts |
| `iso/fix-vboxdrv.sh` | Fixes VirtualBox's kernel module on a Linux host, for running the ISO in VirtualBox |
| `windows/` | The Windows launcher, the native runner, Fix WSL and the diagnostics script that setup installs |
