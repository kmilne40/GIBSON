#!/bin/bash
# Joins the GIBSON-Linux.wsl parts back together and checks them.
# Mac: double-click this file (if macOS refuses, right-click it, choose Open).
# Linux: run  bash join-gibson-wsl.command  in that folder.
# It is only needed on a Mac or Linux build machine; most people build
# GIBSON-Setup.exe on Windows and use join-gibson-wsl.bat there.
set -e
cd "$(dirname "$0")"
F=GIBSON-Linux.wsl
if [ ! -f "$F.part0" ]; then
  echo "No $F.part0 here: put all the parts in this folder and run me again."
  exit 1
fi
n=0; parts=""
while [ -f "$F.part$n" ]; do parts="$parts $F.part$n"; n=$((n+1)); done
echo "Joining $n parts into $F ..."
cat $parts > "$F"
if [ ! -f "$F.sha256" ]; then
  echo "Joined, but $F.sha256 is not here to check against. Keep the .sha256 file"
  echo "with the parts so the join can be verified."
  exit 0
fi
SUM=$(cut -d' ' -f1 < "$F.sha256")
echo "Checking the SHA-256 checksum ..."
if command -v sha256sum >/dev/null; then GOT=$(sha256sum "$F" | cut -d' ' -f1); else GOT=$(shasum -a 256 "$F" | cut -d' ' -f1); fi
if [ "$GOT" = "$SUM" ]; then
  echo; echo "OK: $F is complete and matches the published checksum."
  echo "Put it in the GIBSON-MAINFRAME-COMPLETE folder before running build-windows.bat."
  echo "The .part files can be deleted."
else
  echo; echo "CHECKSUM MISMATCH: expected $SUM"; echo "                   got      $GOT"
  echo "One of the parts is damaged or incomplete. Download it again and rerun."
  rm -f "$F"; exit 1
fi
