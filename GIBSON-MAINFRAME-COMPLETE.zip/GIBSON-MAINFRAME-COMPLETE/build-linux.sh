#!/usr/bin/env bash
# ===========================================================================
#  GIBSON Linux build - single-source edition.
#
#  Builds the frozen Linux app + tarball from the source tree that sits
#  alongside this script. There is no per-platform copy of the code.
#
#  Run it:   ./build-linux.sh      (from the directory it lives in)
#
#  Installs Python 3 + venv + pip automatically if missing (apt/dnf/yum/
#  zypper/pacman/apk, via sudo). Only needs an internet connection and ~2 GB
#  free. Builds natively for this machine's CPU.
# ===========================================================================
set -euo pipefail
cd "$(dirname "$0")"                       # the tree root
KIT="$(pwd)"
# The build machinery and the source now share one directory, the way the
# book's install expects, so the source is simply here. GIBSON_SRC still
# overrides it, which is how you build a tree from somewhere else.
SRC="${GIBSON_SRC:-$(pwd)}"                # the single master source
ARCH="$(uname -m)"

echo
echo "===== GIBSON Linux build  (arch: ${ARCH}) ====="
echo "  source : $SRC"
echo "  kit    : $KIT"
echo

[ -d "$SRC/gibson" ] || { echo "[ERROR] source not found at $SRC (expected a gibson/ directory beside this script)"; exit 1; }

# Match the process NAME only. pkill -f searches whole command lines, so a
# path pattern also matches any ancestor shell whose command line happens to
# mention that path, and the build then kills itself. The frozen binary is
# named "gibson", so -x finds exactly it and can never match a shell.
pkill -x gibson 2>/dev/null || true

find_py() { PYEXE=""; for c in python3.12 python3.11 python3.10 python3; do command -v "$c" >/dev/null 2>&1 && { PYEXE="$c"; return 0; }; done; return 1; }
venv_ok() { [ -n "${PYEXE:-}" ] && "$PYEXE" -c "import venv, ensurepip" >/dev/null 2>&1; }
sudo_run() { if [ "$(id -u)" -eq 0 ]; then "$@"; else sudo "$@"; fi; }
install_python() {
  echo "[0/4] Installing Python 3 + venv + pip (needs sudo/root)..."
  if command -v apt-get >/dev/null 2>&1; then sudo_run apt-get update && sudo_run apt-get install -y python3 python3-venv python3-pip
  elif command -v dnf >/dev/null 2>&1; then sudo_run dnf install -y python3 python3-pip
  elif command -v yum >/dev/null 2>&1; then sudo_run yum install -y python3 python3-pip
  elif command -v zypper >/dev/null 2>&1; then sudo_run zypper install -y python3 python3-venv python3-pip
  elif command -v pacman >/dev/null 2>&1; then sudo_run pacman -Sy --noconfirm python python-pip
  elif command -v apk >/dev/null 2>&1; then sudo_run apk add python3 py3-pip
  else echo "[!] No supported package manager; install Python 3.10+ with venv and pip, then re-run."; return 1; fi
}

if ! find_py || ! venv_ok; then install_python || true; find_py || true; fi
if [ -z "${PYEXE:-}" ] || ! venv_ok; then
  echo "[ERROR] Python 3 with venv unavailable. On Debian/Kali/Ubuntu: sudo apt-get install -y python3 python3-venv python3-pip"; exit 1
fi
echo "[1/4] Python: $PYEXE ($($PYEXE -c 'import platform;print(platform.python_version())'))"

# A venv of its own, NOT the .venv that install_gibson.sh creates. Before the
# source and the build machinery shared a directory those two lived apart; now
# they would be the same .venv, and a build would inject PyInstaller and its
# pinned build dependencies into the environment the student's lab runs from.
echo "[2/4] Creating .venv-build and installing dependencies..."
[ -x ".venv-build/bin/python" ] || "$PYEXE" -m venv .venv-build
VPY=".venv-build/bin/python"
"$VPY" -m pip install --upgrade pip >/dev/null
"$VPY" -m pip install -r requirements-build.txt

echo "[3/4] Freezing GIBSON from the single source (full build)..."
LOG="$KIT/build-log.txt"; echo "GIBSON Linux build $(date)" > "$LOG"
rm -rf build dist
set +e
GIBSON_SRC="$SRC" GIBSON_LEAN="" "$VPY" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "$LOG" 2>&1
set -e
if [ ! -x "dist/GIBSON/gibson" ] && [ "${GIBSON_ALLOW_LEAN:-0}" != "1" ]; then
  echo "[ERROR] The full build did not complete, so nothing was packaged. A lean build"
  echo "        would install cleanly and then fail in the Pen-Test Shell, so it is made"
  echo "        only on request: GIBSON_ALLOW_LEAN=1 $0. The error is at the end of $LOG."
  exit 1
fi
if [ ! -x "dist/GIBSON/gibson" ]; then
  echo "      Full build did not complete - GIBSON_ALLOW_LEAN=1, so making a LEAN build..."
  echo "[retry] lean build" >> "$LOG"
  rm -rf build dist
  set +e
  GIBSON_SRC="$SRC" GIBSON_LEAN=1 "$VPY" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "$LOG" 2>&1
  set -e
  if [ -x "dist/GIBSON/gibson" ]; then
    echo "      LEAN build made. ezrecon, zniff and cicspwn will report NOT READY in the"
    echo "      Pen-Test Shell (tool-check says so). Do not hand this out as the full GIBSON."
  fi
else
  # Check rather than assume: the frozen gibson must import every package the
  # course tools need, or the Pen-Test Shell would fail in the classroom.
  if ! "dist/GIBSON/gibson" --run-tool "$SRC/gibson/assets/pentest/tools/GIBSONscan/tool_check.py" --modules-only >> "$LOG" 2>&1; then
    echo "[ERROR] dist/GIBSON/gibson was built but cannot import every course tool package."
    echo "        The missing packages are listed near the end of $LOG."
    exit 1
  fi
fi
[ -x "dist/GIBSON/gibson" ] || { echo "[ERROR] dist/GIBSON/gibson was not produced, even with the lean build. See $LOG (last ~30 lines)."; exit 1; }
echo "      Portable build ready: dist/GIBSON/gibson"

cat > "dist/GIBSON/Start-GIBSON.sh" <<'EOS'
#!/usr/bin/env bash
cd "$(dirname "$0")"
# Same reasoning as the macOS launcher: pin the state directory before sudo, so
# the sudo and no-sudo launchers cannot end up running two separate labs.
echo "Starting GIBSON on standard ports (sudo required for 23/21/80/175)..."
exec sudo GIBSON_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/mfsim}" ./gibson
EOS
cat > "dist/GIBSON/Start-GIBSON-highports.sh" <<'EOS'
#!/usr/bin/env bash
cd "$(dirname "$0")"
# High ports, so this runs as an ordinary user with no sudo. Without these the
# listeners would try 23, 80 and 175, which Linux reserves for root, and every
# one of them would fail for a non-root student even though the script is
# called highports. The FTP value only matters once you add --with-ftp to the
# line below, since FTP is off unless asked for.
#
# GIBSON_SMTP_PORT is deliberately NOT set here. Mail stays on the real port
# 25 so a scan of this lab finds a mainframe MTA where one belongs, and if
# this user cannot bind 25 the listener falls back to 2525 by itself and says
# so on the console. Setting it here would mean port 25 was never even tried.
# GIBSON_DB2_TCP_PORT matters as much as the rest: DB2's DAS listener
# defaults to 446, which is privileged, and it is on unless --no-db2 is
# passed, so without this the no-sudo launcher died on startup with a bare
# PermissionError traceback before it ever reached the mail listener.
export GIBSON_PORT=2323 GIBSON_FTP_PORT=2121 GIBSON_NJE_PORT=1750 \
       GIBSON_WELCOME_PORT=8080 GIBSON_DB2_TCP_PORT=4460
echo "Starting GIBSON  telnet:2323  dashboard:8443  tools-shell:8022 ..."
exec ./gibson --serve --with-tn3270 --with-tools --with-smtp --with-app8080 --with-cbsa-api --with-dvca --with-dvca-web --with-fibs-web --no-welcome
EOS
chmod +x "dist/GIBSON/Start-GIBSON.sh" "dist/GIBSON/Start-GIBSON-highports.sh" "dist/GIBSON/gibson"

[ -f gibson.png ] && cp gibson.png "dist/GIBSON/gibson.png" || true
cat > "dist/GIBSON/Install-Desktop-Shortcut.sh" <<'EOS'
#!/usr/bin/env bash
HERE="$(cd "$(dirname "$0")" && pwd)"
APPS="$HOME/.local/share/applications"; mkdir -p "$APPS"
cat > "$APPS/gibson.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=GIBSON Mainframe Simulator
Comment=Deliberately vulnerable z/OS training simulator
Exec=$HERE/Start-GIBSON-highports.sh
Icon=$HERE/gibson.png
Terminal=true
Categories=Education;Security;
DESK
chmod +x "$HERE/Start-GIBSON-highports.sh" "$HERE/Start-GIBSON.sh" "$HERE/gibson" 2>/dev/null || true
echo "GIBSON shortcut installed - look for 'GIBSON Mainframe Simulator' in your apps menu."
EOS
chmod +x "dist/GIBSON/Install-Desktop-Shortcut.sh"

echo "[4/4] Packaging tarball..."
TAR="GIBSON-linux-${ARCH}.tar.gz"
rm -f "$TAR"; tar czf "$TAR" -C dist GIBSON
echo
echo "===== DONE ====="
echo "  Tarball to distribute : $KIT/${TAR}"
echo "  End users: unpack, then ./Start-GIBSON-highports.sh  (http://127.0.0.1:8443/, admin / gibsonadmin!)"
