; ============================================================================
;  GIBSON - Inno Setup installer script (single-source edition).
;  Compiled from the tree root by build-windows.bat after PyInstaller has
;  produced dist\GIBSON\ and the WSL pieces are in wsl\ (GIBSON-Linux.wsl, built
;  by iso/build-wsl.sh, and Microsoft's WSL package wsl.x64.msi).
;  Produces Output\setup.exe, copied to GIBSON-Setup.exe.
;  Paths are relative to this .iss file.
;
;  The install is built so it cannot fail and never needs the student to choose
;  anything. It always installs:
;    - GIBSON's native Windows build (under {app}\native), which runs on any
;      Windows 10 or 11 with no WSL, no virtualisation and no restart, and
;    - the GIBSON Linux system for WSL 2 (the ISO's own system, every tool),
;      which it sets up only when the machine can actually run it.
;
;  Afterwards, whatever happened, the one "GIBSON" shortcut starts GIBSON and
;  opens the browser. It uses the full Linux system when that is healthy and the
;  native build otherwise, deciding for itself (windows\gibson-launch.ps1). So a
;  machine that cannot run WSL still has a working GIBSON, and nothing a student
;  clicks ever opens and closes with no result.
;
;  Unattended: setup.exe /SILENT            full install, WSL set up if possible
;              setup.exe /SILENT /MODE=native   native only, never touch WSL
; ============================================================================

#define MyAppName "GIBSON Mainframe Simulator"
#define MyAppShortName "GIBSON"
#define MyAppVersion "0.5.0"
#define MyAppPublisher "Neuro Training Ltd / OffensiveSec.org"
#define MyAppURL "https://offensivesec.org"
#define MyAppExeName "gibson.exe"

[Setup]
AppId={{6D3581ED-74DE-4F16-B460-3E67E552D899}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppShortName}
DefaultGroupName={#MyAppShortName}
DisableProgramGroupPage=yes
LicenseFile=LICENSE.md
OutputDir=Output
OutputBaseFilename=setup
SetupIconFile=gibson.ico
UninstallDisplayIcon={app}\gibson.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
; The native build's folder goes on the system PATH so `gibson <options>` works
; in any Command Prompt; ChangesEnvironment tells open programs PATH changed.
ChangesEnvironment=yes
ArchitecturesInstallIn64BitMode=x64compatible
ArchitecturesAllowed=x64compatible
; The native build runs on Windows 10 1809 and later, so setup does too. WSL 2
; is set up only on Windows 10 22H2 (build 19045) and Windows 11, and only when
; the machine can run it; everywhere else GIBSON runs in native Windows mode.
MinVersion=10.0.17763

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"

[InstallDelete]
; Earlier versions installed the native build straight into {app}.
Type: files; Name: "{app}\gibson.exe"
Type: filesandordirs; Name: "{app}\_internal"

[Files]
Source: "windows\gibson-wsl.ps1"; Flags: dontcopy
Source: "dist\GIBSON\*"; DestDir: "{app}\native"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "windows\gibson-launch.ps1"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\gibson-native.ps1"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\gibson-wsl.ps1"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\gibson-keepalive.vbs"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\fix-wsl.ps1"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\fix-wsl.cmd"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\gibson-diagnose.cmd"; DestDir: "{app}\windows"; Flags: ignoreversion
Source: "windows\gibson.cmd"; DestDir: "{app}"; Flags: ignoreversion
Source: "gibson.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "windows\phosphor.ico"; DestDir: "{app}"; Flags: ignoreversion
; The WSL pieces are carried even when this machine cannot use them, so the
; full Linux toolset can be enabled later (Start menu: Fix WSL for GIBSON).
Source: "wsl\GIBSON-Linux.wsl"; DestDir: "{app}\wsl"; Flags: ignoreversion nocompression
Source: "wsl\wsl.x64.msi"; DestDir: "{app}\wsl"; Flags: ignoreversion nocompression

[Registry]
; Only {app} goes on the PATH: its gibson.cmd runs the WSL GIBSON when that is
; installed and the native gibson.exe otherwise, so "gibson" always works.
Root: HKLM; Subkey: "SYSTEM\CurrentControlSet\Control\Session Manager\Environment"; ValueType: expandsz; ValueName: "Path"; ValueData: "{olddata};{app}"; Check: NeedsAddPath(ExpandConstant('{app}'))

[Icons]
; The one launcher: it starts GIBSON (WSL if healthy, native otherwise) and
; opens the page, so it always lands somewhere working.
Name: "{group}\{#MyAppName}"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Console"; IconFilename: "{app}\gibson.ico"; Comment: "Start GIBSON and open the Master Console"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Console"; IconFilename: "{app}\gibson.ico"; Tasks: desktopicon
Name: "{group}\{#MyAppShortName} Dashboard"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Dashboard"; IconFilename: "{app}\gibson.ico"
Name: "{group}\{#MyAppShortName} Pen-Test Shell"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Shell"; IconFilename: "{app}\gibson.ico"
; PHOSPHOR's desktop GUI, which ships inside GIBSON (gibson.exe --phosphor --gui), run
; as the signed-in user like GIBSON itself, so it needs no administrator prompt.
Name: "{group}\PHOSPHOR"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""$env:__COMPAT_LAYER='RunAsInvoker'; Start-Process -FilePath '{app}\native\{#MyAppExeName}' -ArgumentList '--phosphor','--gui','127.0.0.1','23' -WindowStyle Hidden"""; IconFilename: "{app}\phosphor.ico"; Comment: "PHOSPHOR, the TN3270 / TN5250 audit terminal"
Name: "{group}\{#MyAppShortName} Welcome page"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Welcome"; IconFilename: "{app}\gibson.ico"
Name: "{group}\Stop {#MyAppShortName}"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Stop"; IconFilename: "{app}\gibson.ico"; Comment: "Stop GIBSON (both modes)"
Name: "{group}\Fix WSL for {#MyAppShortName}"; Filename: "{app}\windows\fix-wsl.cmd"; IconFilename: "{app}\gibson.ico"; Comment: "Enable or repair the full Linux toolset (WSL 2)"
Name: "{group}\{#MyAppShortName} diagnostics"; Filename: "{app}\windows\gibson-diagnose.cmd"; IconFilename: "{app}\gibson.ico"; Comment: "Collect a report of why GIBSON will not start"
; The full Linux system, when it is installed.
Name: "{group}\Full Linux toolset\{#MyAppShortName} Linux terminal"; Filename: "{sys}\wsl.exe"; Parameters: "-d GIBSON"; IconFilename: "{app}\gibson.ico"; Comment: "A shell on the GIBSON Linux system (needs the full Linux toolset)"
; The native Windows build on its own, for when you want it explicitly.
Name: "{group}\Native Windows\{#MyAppShortName} (native)"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-native.ps1"" -AppDir ""{app}"" -Action Start"; IconFilename: "{app}\native\{#MyAppExeName}"; Comment: "GIBSON's Windows build, without WSL"
Name: "{group}\Native Windows\{#MyAppShortName} - Diagnose"; Filename: "{app}\native\{#MyAppExeName}"; Parameters: "--diagnose"; IconFilename: "{app}\native\{#MyAppExeName}"; Comment: "Load state and print diagnostics"
Name: "{group}\Native Windows\{#MyAppShortName} - Secure profile"; Filename: "{app}\native\{#MyAppExeName}"; Parameters: "--secure --serve --with-ftp --with-tn3270 --with-app8080 --with-cbsa-api --with-dvca --with-dvca-web --with-fibs-web --with-tools --with-smtp"; IconFilename: "{app}\native\{#MyAppExeName}"; Comment: "Start GIBSON in the CIS-aligned secure profile"
Name: "{group}\Uninstall {#MyAppShortName}"; Filename: "{uninstallexe}"

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""GIBSON Mainframe Simulator"" dir=in action=allow program=""{app}\native\{#MyAppExeName}"" enable=yes profile=any"; Flags: runhidden; StatusMsg: "Adding Windows Firewall rule..."
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\windows\gibson-launch.ps1"" -AppDir ""{app}"" -Target Console"; Description: "Open {#MyAppName} now"; Flags: postinstall runasoriginaluser runhidden nowait skipifsilent; Check: OpenAfterInstall

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""GIBSON Mainframe Simulator"""; Flags: runhidden; RunOnceId: "DelGibsonFwRule"

[UninstallDelete]
Type: filesandordirs; Name: "{app}\native\_internal"

[Code]
var
  WslPossible: Boolean;
  WslReason: String;
  RebootNeeded: Boolean;

function PsExe: String;
begin
  Result := ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe');
end;

function PsArgsIn(Script, AppDir, Action: String): String;
begin
  Result := '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + Script + '" -AppDir "' +
            AppDir + '" -Quiet -Action ' + Action;
end;

function PsArgs(Script, Action: String): String;
begin
  Result := PsArgsIn(Script, ExpandConstant('{app}'), Action);
end;

function NativeOnly: Boolean;
begin
  Result := Lowercase(ExpandConstant('{param:MODE|}')) = 'native';
end;

{ Set up WSL only when it can actually work here and native-only was not asked
  for. This is what keeps installs restart-free unless WSL will really run: a
  machine with virtualisation off, or a VM without nested virtualisation, is
  never put through a pointless reboot. }
function AttemptWsl: Boolean;
begin
  Result := WslPossible and not NativeOnly;
end;

function RebootPending: Boolean;
begin
  Result := RebootNeeded;
end;

function OpenAfterInstall: Boolean;
begin
  { Launch now unless a restart is pending; after the restart the resume step
    opens it. The launcher itself picks WSL or native. }
  Result := not RebootNeeded;
end;

procedure CheckWsl;
var Code: Integer; Script: String;
begin
  WslPossible := False;
  ExtractTemporaryFile('gibson-wsl.ps1');
  Script := ExpandConstant('{tmp}\gibson-wsl.ps1');
  { The install folder is not known this early, so the check runs from the temp folder. }
  if not Exec(PsExe, PsArgsIn(Script, ExpandConstant('{tmp}'), 'Check'), '', SW_HIDE, ewWaitUntilTerminated, Code) then
  begin
    WslReason := 'the machine check could not be run';
    exit;
  end;
  case Code of
    0:  WslPossible := True;
    10: WslReason := 'this Windows is older than Windows 10 22H2';
    11: WslReason := 'virtualisation is turned off in the BIOS/UEFI';
    12: WslReason := 'WSL is turned off by a policy on this computer';
    13: WslReason := 'WSL 2 needs 64-bit Windows';
    14: WslReason := 'this is a virtual machine without nested virtualisation';
  else
    WslReason := 'the machine check ended with code ' + IntToStr(Code);
  end;
end;

procedure InitializeWizard;
begin
  CheckWsl;
end;

procedure StopRunningGibson;
var ResultCode: Integer;
begin
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/IM gibson.exe /F', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin StopRunningGibson; Result := ''; end;

procedure SetupWsl;
var Code: Integer; Script: String;
begin
  Script := ExpandConstant('{app}\windows\gibson-wsl.ps1');
  WizardForm.StatusLabel.Caption := 'Setting up the full Linux toolset (WSL 2)...';
  Exec(PsExe, PsArgs(Script, 'EnableFeatures'), '', SW_HIDE, ewWaitUntilTerminated, Code);
  if Code = 3010 then
  begin
    { WSL needs a restart to finish turning on. Finish by itself after sign-in. }
    RebootNeeded := True;
    ExecAsOriginalUser(PsExe, PsArgs(Script, 'ScheduleResume'), '', SW_HIDE, ewWaitUntilTerminated, Code);
    exit;
  end;
  if Code <> 0 then exit;   { the launcher falls back to native; no blocking message }
  WizardForm.StatusLabel.Caption := 'Installing the GIBSON Linux system...';
  ExecAsOriginalUser(PsExe, PsArgs(Script, 'InstallDistro'), '', SW_HIDE, ewWaitUntilTerminated, Code);
  { Whatever the result, the post-install launcher lands the student on WSL if
    it worked and on the native build if it did not. }
end;

function NeedRestart(): Boolean;
begin
  Result := RebootNeeded;
end;

function UpdateReadyMemo(Space, NewLine, MemoUserInfoInfo, MemoDirInfo, MemoTypeInfo,
  MemoComponentsInfo, MemoGroupInfo, MemoTasksInfo: String): String;
begin
  Result := MemoDirInfo + NewLine + NewLine + 'GIBSON will run in:' + NewLine;
  if AttemptWsl then
    Result := Result + Space + 'the full Linux system in WSL 2 (every Pen-Test Shell tool).' + NewLine +
              Space + 'Windows may restart once; setup then finishes by itself when you sign in.'
  else
    Result := Result + Space + 'native Windows mode (' + WslReason + ').' + NewLine +
              Space + 'The full Linux toolset can be added later: Start menu, GIBSON, Fix WSL for GIBSON.';
  if MemoTasksInfo <> '' then Result := Result + NewLine + NewLine + MemoTasksInfo;
end;

const EnvKey = 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment';
function NeedsAddPath(Dir: String): Boolean;
var Paths: String;
begin
  if not RegQueryStringValue(HKEY_LOCAL_MACHINE, EnvKey, 'Path', Paths) then
  begin Result := True; exit; end;
  Result := Pos(';' + Uppercase(Dir) + ';', ';' + Uppercase(Paths) + ';') = 0;
end;
procedure RemovePath(Dir: String);
var Paths: String; P: Integer;
begin
  if not RegQueryStringValue(HKEY_LOCAL_MACHINE, EnvKey, 'Path', Paths) then exit;
  P := Pos(';' + Uppercase(Dir) + ';', ';' + Uppercase(Paths) + ';');
  if P = 0 then exit;
  { P is the position of Dir's leading ';' in the padded string, so Dir starts at P in Paths }
  if P > 1 then Delete(Paths, P - 1, Length(Dir) + 1) else Delete(Paths, 1, Length(Dir) + 1);
  RegWriteExpandStringValue(HKEY_LOCAL_MACHINE, EnvKey, 'Path', Paths);
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    { An older install put the native folder on the PATH, ahead of gibson.cmd. }
    RemovePath(ExpandConstant('{app}\native'));
    if AttemptWsl then SetupWsl;
  end;
end;
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var Code: Integer;
begin
  if (CurUninstallStep = usUninstall) and FileExists(ExpandConstant('{app}\windows\gibson-wsl.ps1')) then
    { Stops GIBSON, removes the GIBSON distribution and the sign-in entry. WSL stays. }
    Exec(PsExe, PsArgs(ExpandConstant('{app}\windows\gibson-wsl.ps1'), 'Uninstall'), '', SW_HIDE, ewWaitUntilTerminated, Code);
  if CurUninstallStep = usPostUninstall then
  begin
    RemovePath(ExpandConstant('{app}'));
    RemovePath(ExpandConstant('{app}\native'));
  end;
end;
function InitializeUninstall(): Boolean;
var ResultCode: Integer;
begin
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/IM gibson.exe /F', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  Result := True;
end;
