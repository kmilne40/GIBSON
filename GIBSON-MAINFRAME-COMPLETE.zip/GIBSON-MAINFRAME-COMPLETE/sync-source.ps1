# ===========================================================================
#  Fetch a GIBSON source tree from a git repository (optional, Windows).
#
#  Use when you keep the GIBSON web-suite source in git and want a tree to
#  match the latest commit before building. The repo must contain the GIBSON
#  tree at its root (gibson\, phosphor\, pyproject.toml, install_gibson.sh, ...).
#
#  Usage (PowerShell):
#     .\sync-source.ps1 [-Repo <git-url>] [-Branch <branch>]
# ===========================================================================
param(
  [string]$Repo   = $env:GIBSON_REPO,
  [string]$Branch = $env:GIBSON_BRANCH
)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
if (-not $Repo) { $Repo = "https://github.com/kmilne40/GIBSON.git" }
# Never replace the directory this script lives in: the build machinery is
# in there now, so clone to a sibling and build with -Env:GIBSON_SRC.
$Here = (Get-Location).Path
$Dest = if ($Env:GIBSON_SYNC_DEST) { $Env:GIBSON_SYNC_DEST } else { (Resolve-Path "..").Path + "\gibson-source-" + (Get-Date -Format "yyyyMMddHHmmss") }

if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Write-Error "git is not installed."; exit 1 }
Write-Host "Syncing source from: $Repo $(if($Branch){"(branch $Branch)"})"
Write-Host "          into      : $Dest"

$Tmp = Join-Path $env:TEMP ("gibsrc_" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $Tmp | Out-Null
try {
  if ($Branch) { git clone --depth 1 --branch $Branch $Repo "$Tmp\repo" }
  else { git clone --depth 1 $Repo "$Tmp\repo" }

  if (-not (Test-Path "$Tmp\repo\gibson")) {
    Write-Error "the repo does not contain a gibson\ directory at its root. Point this at the GIBSON web-suite repo."
    exit 1
  }
  if (Test-Path $Dest) {
    $Bak = "$Dest.bak." + (Get-Date -Format "yyyyMMddHHmmss")
    Write-Host "Backing up current source to: $Bak"
    Move-Item -LiteralPath $Dest -Destination $Bak
  }
  Remove-Item -Recurse -Force "$Tmp\repo\.git" -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Path $Dest | Out-Null
  Copy-Item -Recurse -Force "$Tmp\repo\*" $Dest
  Write-Host "Done. source\ now matches $Repo. Run a build script next."
}
finally { Remove-Item -Recurse -Force $Tmp -ErrorAction SilentlyContinue }
