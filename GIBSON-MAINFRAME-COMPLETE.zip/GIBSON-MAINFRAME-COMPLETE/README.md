# GIBSON macOS build

This private repository builds GIBSON for Apple Silicon Macs on GitHub's own Macs, and proves it works before anyone receives it.

Every push to `main` runs `.github/workflows/macos.yml`, which does three things. It builds `GIBSON.app`, the PKG and the DMG with `build-macos.command` on a clean macOS 15 Mac with Homebrew moved out of the way, which proves the build needs nothing beyond Apple's Command Line Tools and python.org's Python. It then installs the PKG on clean macOS 15 and macOS 26 Macs, starts GIBSON, and runs `scripts/ci/test-gibson-tools.sh`, which tests every Pen-Test Shell tool against the running lab. Only when every test passes does it attach the installers to the run, as `GIBSON-macos-arm64-tested`.

To get the tested installers, open the **Actions** tab, open the latest green run, and download **GIBSON-macos-arm64-tested** from the **Artifacts** section at the bottom of the page.

The source is the same as `GIBSON-MAINFRAME-COMPLETE`; see `START-HERE.md` and `README-BUILD.md`.
