import sys, time, signal
from gibson.core.config import GibsonConfig
from gibson.core.state import GibsonState
cfg = GibsonConfig.from_env()
state = GibsonState.create(cfg)
try: state.nje._state = state
except Exception: pass
started = []
from gibson.services.telnet_server import serve_telnet
from gibson.services.ftp_server import serve_ftp
from gibson.services.nje_server import serve_nje
from gibson.services.db2_server import serve_db2das
for name, fn in [("telnet:23", serve_telnet), ("ftp:21", serve_ftp),
                 ("nje:175", serve_nje), ("db2das:50000", serve_db2das)]:
    try:
        srv = fn(state); started.append((name, srv)); print(f"[up] {name}", flush=True)
    except Exception as e:
        print(f"[FAIL] {name}: {e}", flush=True)
print("[ready] GIBSON services up", flush=True)
signal.pause()
