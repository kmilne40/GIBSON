#!/bin/bash
# ===========================================================================
#  GIBSON macOS build - single-source edition (Intel and Apple Silicon).
#
#  Builds the .pkg / .dmg from the ONE source tree at
#  the directory this script sits in. There is no per-platform copy of the code.
#
#  Double-click build-macos.command, or run ./build-macos.command.
#  Installs Python 3.12 from python.org automatically if it is missing.
#  Needs no Homebrew: every Pen-Test Shell tool is built from source into the app.
#  Builds natively: arm64 on Apple Silicon, x86_64 on Intel.
# ===========================================================================
set -euo pipefail
cd "$(dirname "$0")"                       # the tree root
KIT="$(pwd)"
SRC="${GIBSON_SRC:-$(pwd)}"                # the single master source
# Match the process NAME only. pkill -f searches whole command lines, so a
# path pattern also matches any ancestor shell whose command line happens to
# mention that path, and the build then kills itself.
pkill -x gibson 2>/dev/null || true

APP_NAME="GIBSON"; APP_VERSION="0.5.0"; BUNDLE_ID="org.offensivesec.gibson"; INSTALL_LOCATION="/Applications/GIBSON"

echo; echo "===== GIBSON macOS build (single source) ====="
echo "  host arch: $(uname -m)   source: $SRC"; echo
[ -d "$SRC/gibson" ] || { echo "[ERROR] source not found at $SRC (expected a gibson/ directory beside this script)"; exit 1; }

# GIBSON is frozen with the build Mac's Python, and the app then runs only on
# the macOS versions that Python was built for. python.org's installers are
# built to run on old macOS; Homebrew's Python is built for THIS Mac's macOS
# only, so an app frozen with it would refuse to start on older Macs, and
# Apple's /usr/bin/python3 is 3.9, older than GIBSON's 3.10 minimum. So only
# python.org's Python is used, and it is installed if it is missing.
PY_ORG_VER="3.12.10"
PY_ORG_PKG="https://www.python.org/ftp/python/${PY_ORG_VER}/python-${PY_ORG_VER}-macos11.pkg"
find_py() {
  PYEXE=""
  for v in 3.12 3.13 3.11 3.10; do
    c="/Library/Frameworks/Python.framework/Versions/$v/bin/python3"
    if [ -x "$c" ] && "$c" -c "import venv,ensurepip" >/dev/null 2>&1; then PYEXE="$c"; return 0; fi
  done
  return 1
}
install_python() {
  echo "[0/4] Installing Python ${PY_ORG_VER} from python.org (the build needs it; you will be asked for your password)..."
  local tmp; tmp="$(mktemp -d)/python.pkg"
  if curl -fsSL --retry 3 "$PY_ORG_PKG" -o "$tmp"; then
    sudo installer -pkg "$tmp" -target / || true
  fi
  rm -f "$tmp"
}
if ! find_py; then install_python; find_py || true; fi
if [ -z "${PYEXE:-}" ]; then
  echo "[ERROR] Python from python.org is needed to build GIBSON, and it could not be installed."
  echo "        Download the macOS installer for Python ${PY_ORG_VER} from https://www.python.org/downloads/macos/,"
  echo "        double-click it, follow the steps, then run this script again. (Homebrew's Python and"
  echo "        Apple's /usr/bin/python3 are not used: an app built with them would not run on older Macs.)"
  exit 1
fi
# Everything compiled from here on (pip packages without a ready-made wheel, and
# the bundled tools) targets macOS 11, so the app runs on every Mac from Big Sur.
export MACOSX_DEPLOYMENT_TARGET=11.0
echo "[1/4] Python: $PYEXE ($($PYEXE -c 'import platform;print(platform.python_version())'))"

# Regenerate the .icns whenever it is missing or older than the source png,
# so an updated icon actually reaches a Mac that has built here before.
if [ -f gibson.png ] && { [ ! -f gibson.icns ] || [ gibson.png -nt gibson.icns ]; }; then
  echo "      Generating gibson.icns..."
  ICONSET="$(mktemp -d)/gibson.iconset"; mkdir -p "$ICONSET"
  for sz in 16 32 64 128 256 512; do
    sips -z $sz $sz gibson.png --out "$ICONSET/icon_${sz}x${sz}.png" >/dev/null 2>&1 || true
    sips -z $((sz*2)) $((sz*2)) gibson.png --out "$ICONSET/icon_${sz}x${sz}@2x.png" >/dev/null 2>&1 || true
  done
  iconutil -c icns "$ICONSET" -o gibson.icns >/dev/null 2>&1 || echo "      (icns generation skipped)"
fi

# A venv of its own, NOT the .venv that install_gibson.sh creates. Before the
# source and the build machinery shared a directory those two lived apart; now
# they would be the same .venv, and a build would inject PyInstaller and its
# pinned build dependencies into the environment the student's lab runs from.
echo "[2/4] Creating .venv-build and installing dependencies..."
# A .venv-build made earlier from another Python (Homebrew's, say) would carry
# that Python into the app, so it is made again from python.org's.
if [ -x ".venv-build/bin/python" ] && \
   [ "$(.venv-build/bin/python -c 'import sys; print(sys.base_prefix)' 2>/dev/null)" != "$("$PYEXE" -c 'import sys; print(sys.base_prefix)')" ]; then
  echo "      .venv-build was made from a different Python; making it again."
  rm -rf .venv-build
fi
[ -x ".venv-build/bin/python" ] || "$PYEXE" -m venv .venv-build
VPY=".venv-build/bin/python"
"$VPY" -m pip install --upgrade pip >/dev/null
"$VPY" -m pip install -r requirements-build.txt
# pip takes the newest wheel THIS Mac can run, and some packages (NumPy 2, for
# one) publish faster builds for newer macOS only, so swap any of those for the
# same version's macOS 11 wheel, or the app would not start on older Macs.
"$VPY" "$SRC/scripts/macos_wheels_for_11.py" || { echo "[ERROR] A Python package has no build for macOS 11; see above."; exit 1; }

echo "[3/4] Freezing GIBSON from the single source (full build)..."
LOG="$KIT/build-log.txt"; echo "GIBSON macOS build $(date)" > "$LOG"
rm -rf build dist
set +e
GIBSON_SRC="$SRC" GIBSON_LEAN="" "$VPY" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "$LOG" 2>&1
set -e
if [ ! -x "dist/GIBSON/gibson" ] && [ "${GIBSON_ALLOW_LEAN:-0}" != "1" ]; then
  echo "[ERROR] The full build did not complete, so nothing was packaged. A lean build"
  echo "        would install cleanly and then fail in the Pen-Test Shell, so it is made"
  echo "        only on request: GIBSON_ALLOW_LEAN=1 $0. The error is at the end of $LOG."
  exit 1
fi
if [ ! -x "dist/GIBSON/gibson" ]; then
  echo "      Full build did not complete - GIBSON_ALLOW_LEAN=1, so making a LEAN build..."
  echo "[retry] lean build" >> "$LOG"
  rm -rf build dist
  set +e
  GIBSON_SRC="$SRC" GIBSON_LEAN=1 "$VPY" -m PyInstaller --noconfirm --log-level=INFO gibson.spec >> "$LOG" 2>&1
  set -e
  if [ -x "dist/GIBSON/gibson" ]; then
    echo "      LEAN build made. ezrecon, zniff and cicspwn will report NOT READY in the"
    echo "      Pen-Test Shell (tool-check says so). Do not hand this out as the full GIBSON."
  fi
else
  # Check rather than assume: the frozen gibson must import every package the
  # course tools need, or the Pen-Test Shell would fail in the classroom.
  if ! "dist/GIBSON/gibson" --run-tool "$SRC/gibson/assets/pentest/tools/GIBSONscan/tool_check.py" --modules-only >> "$LOG" 2>&1; then
    echo "[ERROR] dist/GIBSON/gibson was built but cannot import every course tool package."
    echo "        The missing packages are listed near the end of $LOG."
    exit 1
  fi
fi
[ -x "dist/GIBSON/gibson" ] || { echo "[ERROR] dist/GIBSON/gibson was not produced, even with the lean build. See $LOG (last ~30 lines)."; exit 1; }

# The Pen-Test Shell's security tools (nmap, hydra, nikto, wget, s3270, c3270,
# telnet, ftp and jumbo John), built from source into the app so a student's
# Mac installs nothing. This needs Apple's Command Line Tools on THIS Mac and no
# Homebrew at all (the build keeps Homebrew's folders out on purpose). Sources
# and builds are kept in .tools-build, so only the first build compiles them.
echo "[3b] Building the Pen-Test Shell tools into GIBSON (the first build takes 20 to 30 minutes) ..."
if [ "${GIBSON_SKIP_TOOL_BUNDLE:-0}" = "1" ]; then
  echo "      Skipped (GIBSON_SKIP_TOOL_BUNDLE=1): students' Macs will install the tools on first launch."
  echo "[tools] bundle skipped by request" >> "$LOG"
else
  set +e
  "$VPY" "$SRC/scripts/bundle_macos_tools.py" --dest "dist/GIBSON/tools" --work "$KIT/.tools-build" --log "$LOG"
  rc=$?
  set -e
  if [ "$rc" -ne 0 ]; then
    echo "[ERROR] The Pen-Test Shell tools could not be bundled; the reason is just above and in $LOG."
    echo "        Nothing was packaged. If Apple's Command Line Tools are missing, install them with"
    echo "        xcode-select --install  and run this again. To make a build whose students install the"
    echo "        tools with Homebrew on first launch instead, as older builds did:"
    echo "        GIBSON_SKIP_TOOL_BUNDLE=1 $0"
    exit 1
  fi
fi

cat > "dist/GIBSON/Start GIBSON.command" <<'EOS'
#!/bin/bash
cd "$(dirname "$0")"
# Install the Pen-Test Shell's security tools on first launch, as the logged-in
# user and BEFORE sudo: Homebrew refuses to run as root.
bash ./install-pentest-tools.sh --first-run
# Pin the lab's state directory to the invoking user's home before sudo takes
# over. Whether sudo keeps HOME is a per-machine sudoers setting (env_keep), so
# without this the lab could land in ~/mfsim on one Mac and /var/root/mfsim on
# another, and the no-sudo launcher would then be running a SECOND, separate
# lab with its own state. Passing it explicitly makes both agree everywhere.
echo "Starting GIBSON (sudo required for ports 23/21/80/175)..."
exec sudo GIBSON_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/mfsim}" ./gibson
EOS
cat > "dist/GIBSON/Start GIBSON (high ports, no sudo).command" <<'EOS'
#!/bin/bash
cd "$(dirname "$0")"
# GIBSON_SMTP_PORT is deliberately NOT set here. Mail stays on the real port 25
# so a scan of this lab finds a mainframe MTA where one belongs. macOS reserves
# everything below 1024 for root, so if this user cannot bind 25 the listener
# moves itself to 2525 and says so on the console; pinning it to 2525 here
# would mean port 25 was never tried even on a Mac that could have had it.
# GIBSON_DB2_TCP_PORT is here for the same reason: DB2's DAS listener wants
# 446, which macOS reserves for root, and it is on unless --no-db2 is passed,
# so without this the no-sudo launcher crashed before reaching the mail
# listener.
export GIBSON_PORT=2323 GIBSON_FTP_PORT=2121 GIBSON_NJE_PORT=1750 \
       GIBSON_WELCOME_PORT=8080 GIBSON_DB2_TCP_PORT=4460
# Install the Pen-Test Shell's security tools on first launch, as the logged-in
# user and BEFORE sudo: Homebrew refuses to run as root.
bash ./install-pentest-tools.sh --first-run
echo "Starting GIBSON  telnet:2323 dashboard:8443 tools:8022 ..."; exec ./gibson
EOS
# A space-free runner is what the app bundle hands to Terminal.
cat > "dist/GIBSON/run-gibson.sh" <<'EOS'
#!/bin/bash
cd "$(dirname "$0")"
cat <<'MSG'
==========================================================
  GIBSON mainframe security training simulator
==========================================================
GIBSON listens on the standard mainframe ports (21 FTP, 23 TN3270, 80 and
175 NJE). macOS reserves ports below 1024 for root, so it asks for your
password once, here in this window.

Prefer not to? Close this window and run instead:
  /Applications/GIBSON.app/Contents/Resources/gibson/Start GIBSON (high ports, no sudo).command
which runs everything on high ports with no password.

Sign in to the console at http://127.0.0.1:8443/  as  admin / gibsonadmin!

The lab keeps its datasets, mailboxes and Pen-Test Shell workspace in
~/mfsim, in your own home folder, whichever way you start it.
==========================================================
MSG
# Install the Pen-Test Shell's security tools on first launch, as the logged-in
# user and BEFORE sudo: Homebrew refuses to run as root.
bash ./install-pentest-tools.sh --first-run
exec sudo GIBSON_SIM_ROOT="${GIBSON_SIM_ROOT:-$HOME/mfsim}" ./gibson
EOS
# gibson-cli.sh: what /usr/local/bin/gibson points at, so `gibson <options>`
# (--list-volumes, --add-volume, --adduser, --mfa-enroll ...) works in Terminal
# against the same ~/mfsim the app uses. The app runs GIBSON with sudo, which
# leaves root-owned files in ~/mfsim, so this uses sudo too whenever it finds any.
cat > "dist/GIBSON/gibson-cli.sh" <<'EOS'
#!/bin/bash
DIR="/Applications/GIBSON.app/Contents/Resources/gibson"
ROOT="${GIBSON_SIM_ROOT:-$HOME/mfsim}"
if [ -d "$ROOT" ] && [ -n "$(find "$ROOT" ! -user "$(id -u)" -print -quit 2>/dev/null)" ]; then
  exec sudo GIBSON_SIM_ROOT="$ROOT" "$DIR/gibson" "$@"
fi
GIBSON_SIM_ROOT="$ROOT" exec "$DIR/gibson" "$@"
EOS
chmod +x "dist/GIBSON/gibson-cli.sh"
cp scripts/install-pentest-tools.sh "dist/GIBSON/install-pentest-tools.sh"
chmod +x "dist/GIBSON/install-pentest-tools.sh"
# The same runner as a .command file, which is what the app hands to Terminal:
# macOS opens a .command file in Terminal by itself, with no permission prompt.
cp "dist/GIBSON/run-gibson.sh" "dist/GIBSON/run-gibson.command"
chmod +x "dist/GIBSON/Start GIBSON.command" \
         "dist/GIBSON/Start GIBSON (high ports, no sudo).command" \
         "dist/GIBSON/run-gibson.sh" "dist/GIBSON/run-gibson.command"

ARCH="$(uname -m)"     # arm64 on Apple Silicon, x86_64 on Intel

# ---------------------------------------------------------------------------
# Build a real GIBSON.app so the Mac behaves the way Mac users expect: one
# icon, drag it to Applications, double-click to run. GIBSON is an interactive
# console program as well as a web service (the IPL reply sequence needs a
# terminal), so the bundle's executable opens Terminal and runs it there.
# ---------------------------------------------------------------------------
echo "[4/5] Building GIBSON.app ..."
APPDIR="build/GIBSON.app"
rm -rf "$APPDIR"
mkdir -p "$APPDIR/Contents/MacOS" "$APPDIR/Contents/Resources"
cp -R "dist/GIBSON/." "$APPDIR/Contents/Resources/gibson/"
[ -f gibson.icns ] && cp gibson.icns "$APPDIR/Contents/Resources/gibson.icns"

cat > "$APPDIR/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>              <string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key>       <string>${APP_NAME}</string>
  <key>CFBundleExecutable</key>        <string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key>        <string>${BUNDLE_ID}</string>
  <key>CFBundleVersion</key>           <string>${APP_VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${APP_VERSION}</string>
  <key>CFBundlePackageType</key>       <string>APPL</string>
  <key>CFBundleIconFile</key>          <string>gibson.icns</string>
  <key>LSMinimumSystemVersion</key>    <string>11.0</string>
  <key>NSHighResolutionCapable</key>   <true/>
  <key>LSApplicationCategoryType</key> <string>public.app-category.developer-tools</string>
</dict>
</plist>
PLIST

cat > "$APPDIR/Contents/MacOS/${APP_NAME}" <<'LAUNCH'
#!/bin/bash
# Open Terminal and run GIBSON there. GIBSON is interactive (the IPL reply
# sequence) so it needs a visible terminal, which a plain .app does not give.
APP="$(cd "$(dirname "$0")/.." && pwd)"
RUN="$APP/Resources/gibson/run-gibson.command"
# A downloaded .dmg marks every file in it as quarantined, and macOS would then
# stop each bundled tool (nmap, hydra, John) the first time it ran, one prompt
# per program. The student has just approved GIBSON itself, which is why this
# is running, so clear the mark from the app's own files, once.
if /usr/bin/xattr -lr "$APP/Resources" 2>/dev/null | /usr/bin/grep -q com.apple.quarantine; then
  /usr/bin/xattr -dr com.apple.quarantine "$APP/Resources" 2>/dev/null || true
fi
chmod +x "$RUN" 2>/dev/null
# Hand Terminal the .command file to open, the way a double-click in Finder
# does. Scripting Terminal with osascript instead made macOS ask the student
# whether GIBSON may "control Terminal", and a Don't Allow there meant GIBSON
# never started, with nothing on screen to say why.
exec /usr/bin/open -a Terminal "$RUN"
LAUNCH
chmod +x "$APPDIR/Contents/MacOS/${APP_NAME}"
echo "      OK - $APPDIR"

# Refuse an app that would not start on older Macs: every program and library
# inside it, GIBSON's own Python included, must run on macOS 11.
if ! "$VPY" "$SRC/scripts/bundle_macos_tools.py" --check-min-os "$APPDIR" --min 11.0 --log "$LOG"; then
  echo "[ERROR] Something inside GIBSON.app needs a newer macOS than 11, so it would not start on"
  echo "        older Macs. The files are listed above and in $LOG."
  exit 1
fi

echo "[5/5] Packaging (native arch: ${ARCH})..."
rm -rf Output stage dmgstage; mkdir -p Output
PKG=""; DMG=""; TARBALL=""

# .pkg: installs GIBSON.app into /Applications.
if command -v pkgbuild >/dev/null 2>&1; then
  mkdir -p "stage/Applications"
  cp -R "$APPDIR" "stage/Applications/"
  # postinstall links /usr/local/bin/gibson to the app, so `gibson <options>` works in Terminal.
  rm -rf pkgscripts; mkdir -p pkgscripts
  cat > pkgscripts/postinstall <<'PI'
#!/bin/sh
mkdir -p /usr/local/bin
ln -sf "/Applications/GIBSON.app/Contents/Resources/gibson/gibson-cli.sh" /usr/local/bin/gibson
# Installer does not mark installed files as downloaded, but clear the mark in
# case the app was copied in by hand first, so macOS never stops a bundled tool.
/usr/bin/xattr -dr com.apple.quarantine /Applications/GIBSON.app 2>/dev/null || true
exit 0
PI
  chmod +x pkgscripts/postinstall
  if pkgbuild --root "stage" --identifier "$BUNDLE_ID" --version "$APP_VERSION" --scripts pkgscripts \
              --install-location "/" "Output/${APP_NAME}-Installer-${ARCH}.pkg" >>"$LOG" 2>&1; then
    PKG="Output/${APP_NAME}-Installer-${ARCH}.pkg"
  else
    echo "      pkgbuild failed; see build-log.txt."
  fi
  rm -rf stage pkgscripts
else
  echo "      pkgbuild not found (Xcode Command Line Tools absent), so no .pkg."
  echo "      Run  xcode-select --install  once to get one next time."
fi

# .dmg: the familiar drag-to-Applications window.
mkdir -p dmgstage
cp -R "$APPDIR" "dmgstage/"
ln -s /Applications "dmgstage/Applications"
cat > "dmgstage/READ ME FIRST.txt" <<'RM'
GIBSON - installing on macOS

1. Drag the GIBSON icon onto the Applications shortcut beside it.
2. Open Applications and double-click GIBSON.

The build is not code-signed, so the very first launch is blocked by
Gatekeeper, and you approve it once:

  macOS 15 Sequoia and later: double-click GIBSON, click Done on the
  warning, then open System Settings > Privacy & Security, scroll down to
  "GIBSON was blocked", click Open Anyway, enter your password, and click
  Open Anyway again.

  macOS 14 Sonoma and earlier: right-click (or Control-click) GIBSON in
  Applications, choose Open, and click Open.

GIBSON opens a Terminal window and asks for your password, because the lab
uses the standard mainframe ports (21, 23, 80, 175) and macOS reserves
those for root. The console is then at http://127.0.0.1:8443/ and you sign
in with admin / gibsonadmin!

To run without a password on high ports instead, open
GIBSON.app > Contents > Resources > gibson and use
"Start GIBSON (high ports, no sudo).command".

To type GIBSON's host commands in Terminal (gibson --list-volumes,
gibson --add-volume, gibson --mfa-enroll and so on), run this once after
dragging GIBSON to Applications. It asks for your password:

  sudo mkdir -p /usr/local/bin && sudo ln -sf /Applications/GIBSON.app/Contents/Resources/gibson/gibson-cli.sh /usr/local/bin/gibson

The .pkg installer does this for you.
RM
if [ -x "dist/GIBSON/tools/bin/nmap" ]; then
  cat >> "dmgstage/READ ME FIRST.txt" <<'RM'

Every Pen-Test Shell tool (nmap, hydra, nikto, wget, s3270 and jumbo John
the Ripper) is inside GIBSON already, so there is nothing else to install.
Their licences are in GIBSON.app > Contents > Resources > gibson > tools >
licenses.
RM
fi
# hdiutil fails now and then with "Resource busy" while macOS is still indexing
# the staging folder, so it gets three tries.
for try in 1 2 3; do
  if hdiutil create -volname "$APP_NAME" -srcfolder "dmgstage" -ov -format UDZO \
                    "Output/${APP_NAME}-${ARCH}.dmg" >>"$LOG" 2>&1; then
    DMG="Output/${APP_NAME}-${ARCH}.dmg"; break
  fi
  sleep 10
done
[ -n "$DMG" ] || echo "      hdiutil could not build the disk image; see build-log.txt."
rm -rf dmgstage

if [ -z "$PKG" ] && [ -z "$DMG" ]; then
  tar czf "Output/GIBSON-macos-${ARCH}.tar.gz" -C dist GIBSON
  TARBALL="Output/GIBSON-macos-${ARCH}.tar.gz"
fi

echo; echo "===== DONE ====="
[ -n "$PKG" ] && echo "  Installer  : $PKG   <- hand this to students (double-click to install)"
[ -n "$DMG" ] && echo "  Disk image : $DMG   (alternative: drag GIBSON to Applications)"
[ -n "$TARBALL" ] && echo "  Portable   : $TARBALL"
cat <<'MSG'

  Both put GIBSON.app into /Applications. Double-clicking it opens a Terminal
  and starts the lab; the console is http://127.0.0.1:8443/ (admin / gibsonadmin!).

  The build is UNSIGNED, so the first launch on someone else's Mac is blocked
  by Gatekeeper. They right-click GIBSON in Applications and choose Open once.
  To remove that step for good you need an Apple Developer ID and notarization.
MSG
echo "  Native build for ${ARCH}: run this on an Apple Silicon Mac for the arm64"
echo "  build and on an Intel Mac for the x86_64 build; the arch is in the name."
