@echo off
rem Joins the GIBSON ISO parts back into GIBSON-live-amd64.iso and checks it.
rem Put this file in the same folder as all the .partN files and double-click it.
setlocal
cd /d "%~dp0"
set ISO=GIBSON-live-amd64.iso
set SUM=dae929afcb0d5ddfc9bb70b71745dd63187d5b5821a64565778ecb7afb02348f

if not exist "%ISO%.part0" (
  echo No %ISO%.part0 here - put all the parts in this folder and run me again.
  pause
  exit /b 1
)

echo Joining the parts into %ISO% ...
copy /b "%ISO%.part0" "%ISO%" >nul || goto :joinfail
set N=1
:nextpart
if not exist "%ISO%.part%N%" goto :joined
copy /b "%ISO%"+"%ISO%.part%N%" "%ISO%.tmp" >nul || goto :joinfail
move /y "%ISO%.tmp" "%ISO%" >nul
set /a N+=1
goto :nextpart

:joinfail
echo The join failed. Check there is at least 1.7 GB free on this drive.
pause
exit /b 1

:joined
echo Joined %N% parts.

echo Checking the SHA-256 checksum (this takes a minute) ...
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%ISO%').Hash.ToLower()"`) do set GOT=%%H

if /i "%GOT%"=="%SUM%" (
  echo.
  echo OK: %ISO% is complete and matches the published checksum.
  echo You can now burn it or write it to a USB stick with balenaEtcher or Rufus.
  echo The .part files can be deleted.
) else (
  echo.
  echo CHECKSUM MISMATCH: expected %SUM%
  echo                    got      %GOT%
  echo One of the parts is damaged or incomplete. Download it again and rerun.
  del "%ISO%"
)
pause
