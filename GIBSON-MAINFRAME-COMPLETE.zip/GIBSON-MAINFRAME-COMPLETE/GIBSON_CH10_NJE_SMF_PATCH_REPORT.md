# GIBSON Chapter 10 NJE/SMF and zERT Patch Report

## 1. Summary of changes

This patch keeps the existing GIBSON architecture and Chapter 10 command syntax intact. It adds the missing lab data and extends the existing central structured SMF writer rather than replacing it.

Implemented in this patch:

- Seeded harmless `PAYROLL.MASTER` training data.
- Preserved the exact Chapter 10 `TRANSMIT HAL.HACKER DATASET('PAYROLL.MASTER')` syntax.
- Added clear missing-dataset handling instead of an unrelated simulated abend.
- Added live simulated SMF 14/15/57/80 evidence around TRANSMIT.
- Added live NJE sign-on/sign-off/integrity evidence (types 55/56/58) in the NJE server path.
- Added live NJE/JES job evidence (types 26/30/57/80) with a shared correlation ID.
- Added `SMF ALERTS` and the correlated HIGH rule `INBOUND NJE JOB PERFORMED RACF CHANGE`.
- Preserved `Z4CK` as the RACF user created by the Chapter 10 payload and `H4CKR` as the rogue NJE node.
- Added the zERT TCP/IP profile workflow used by the book: `SYNTAXCHECK`, `OBEYFILE`, `D SMF`, `SET SMF=xx`, and named-stack `D TCPIP,TCPIP,NETSTAT,CONFIG`.
- Added a zERT training OBEYFILE member and stateful zERT configuration.
- Added simulated SMF 119 subtype 11 (detail) and subtype 12 (summary) records when zERT is active and a matching GIBSON network event occurs.
- Added focused regression/acceptance tests without renaming or redesigning existing commands.

## 2. Exact Chapter 10 and zERT commands tested

### NJE/NMR command bodies

The existing iNJEctor-compatible command parser was exercised with the exact command bodies used by the Chapter 10 shell examples:

```text
$D NJEDEF,NODENUM
$T NJEDEF,NODENUM=5
$T NODE(5),NAME=H4CKR
$ADD SOCKET(H4CKR),NODE=H4CKR,IPADDR=192.168.0.20
$T NODE(H4CKR),AUTH=(DEVICE=YES,JOB=YES,NET=YES,SYSTEM=YES)
```

All five were accepted. The final simulated node was `H4CKR`, node 5, with `DEVICE=YES,JOB=YES,NET=YES,SYSTEM=YES`. The external wrapper syntax from the book remains unchanged; existing NJElib/iNJEctor interoperability tests also pass.

### TRANSMIT

Tested exactly:

```text
TRANSMIT HAL.HACKER DATASET('PAYROLL.MASTER')
```

Result:

```text
INMR001I TRANSMIT CREATED
 SOURCE=PAYROLL.MASTER
 OUTDSN=IBMUSER.XMIT.MASTER
 RECIPIENT=HAL
```

The missing dataset path was also tested and now returns a clear TSO-style error, for example:

```text
IKJ56701I DATA SET NO.SUCH.DATASET NOT FOUND
```

### zERT operator workflow

Tested:

```text
D TCPIP
V TCPIP,TCPIP,SYNTAXCHECK,DSN=NETADMIN.TCPPARMS(ZERTON)
V TCPIP,TCPIP,OBEYFILE,DSN=NETADMIN.TCPPARMS(ZERTON)
D SMF
SET SMF=00
D TCPIP,TCPIP,NETSTAT,CONFIG
```

`NETADMIN.TCPPARMS(ZERTON)` contains:

```text
GLOBALCONFIG ZERT AGGREGATION
SMFCONFIG TYPE119 ZERTDETAIL ZERTSUMMARY
```

Before `OBEYFILE`, the simulated CONFIG report shows zERT/detail/summary as `No`. After applying the member it shows:

```text
SMF Parameters:
Type 119:
  ZertDetail:     Yes
  ZertSummary:    Yes

Global Configuration Information:
  ZERT:           Yes
    Aggregation:  Yes
    INTVAL:       SMF
    SYNCVAL:      00:00
```

`D SMF` reads the active multiline `SYS1.PARMLIB(SMFPRM00)` selection and reports Type 119 as active.

## 3. SMF types added and what triggers them

| Type | Simulated trigger implemented/extended by this patch |
| --- | --- |
| 14 | Source dataset read by `TRANSMIT`, including `PAYROLL.MASTER` |
| 15 | TRANSMIT package dataset write |
| 26 | Inbound NJE job received and NJE output/job processing completed |
| 30 | Executed JES step, including `IKJEFT01`/`BPXBATCH` through the existing JES step path |
| 55 | Successful remote NJE node sign-on |
| 56 | Rejected/unknown node, bad NJE sign-on password, or secure-mode sign-on lockout |
| 57 | NJE SYSOUT return and `TRANSMIT` data/output path |
| 58 | Clean NJE session sign-off |
| 80 | RACF/security changes and TRANSMIT security evidence; NJE/JES context now carries the job correlation ID |
| 119/11 | zERT connection-detail evidence after zERT detail is enabled |
| 119/12 | zERT summary evidence when zERT aggregation and summary recording are enabled |

These records are generated when the corresponding simulator action occurs. They are not seeded as static Chapter 10 evidence rows.

## 4. Wider SMF framework design

GIBSON already had a central structured SMF writer (`gibson/core/smf/writer.py`) and typed record modules for several subsystems. The patch extends that mechanism instead of introducing a second event store.

All new Chapter 10 events use the existing structured record format and carry, where relevant:

- record ID/type/subtype
- user ID
- job name/job ID
- event/result/detail
- timestamp/system identity
- correlation ID
- source/target NJE node
- source component/subsystem

`SMF LIST`, `SMF DETAIL`, and `SMF TIMELINE` remain intact. `SMF ALERTS` is additive.

The alert engine is rule-based and reads already-written SMF records. The first rule requires a related inbound Type 26, an `IKJEFT01` or `BPXBATCH` Type 30, and a Type 80 RACF-changing action. It deduplicates by rule and correlation/job identity so a multi-command persistence payload produces one incident rather than an alert storm.

## 5. SMF types implemented immediately

The patch specifically adds or extends live generation for 14, 15, 26, 30, 55, 56, 57, 58, 80, and zERT 119/11 and 119/12.

The wider current GIBSON codebase also already contains structured implementations for types including 7, 30, 80, 92, 100/101/102, 110, 119, 123 and ICSF-oriented evidence. Those pre-existing paths were not redesigned by this patch.

## 6. SMF types prepared as future hooks

The existing central writer can accept additional record types without altering `SMF LIST` or the dashboard event model. Types requested in the design prompt for which there is not yet a matching simulator event should remain future event hooks rather than fabricated records. This includes, depending on the associated feature actually being modelled, types 17/18, 20, 24, 42, 70-79, 81, 83, 90, 115/116 and 120.

No static evidence was added merely to make those types appear supported.

## 7. TRANSMIT / PAYROLL.MASTER validation

`PAYROLL.MASTER` is seeded through the normal default dataset catalogue with only fake training data:

```text
EMP001 J WILLIAMS 51000
EMP002 A CHEN     42250
EMP003 R VEK      73500
EMP004 B TAYLOR   61800
```

Running the exact Chapter 10 TRANSMIT command creates the XMIT package and a shared `XMIT-...` correlation chain containing:

- Type 14 `DATASET_READ` for `PAYROLL.MASTER`
- Type 15 `DATASET_WRITE` for the XMIT package
- Type 57 `NJE_TRANSMIT` to node `HAL`
- Type 80 `TRANSMIT` security evidence

## 8. Z4CK validation

A clean state does not contain `Z4CK`.

Executing the canonical Chapter 10 `racf.jcl` / `/*XEQ` training payload as `RUARIV` creates `Z4CK`, applies `SPECIAL`, and adds OMVS capability. The names remain deliberately separate:

- `H4CKR` = rogue NJE node
- `Z4CK` = RACF user created by the payload
- `HAL.HACKER` = TRANSMIT recipient

The canonical payload remains unchanged.

## 9. Alert/correlation validation

The canonical inbound RACF-changing NJE job now produces a shared correlation chain containing:

```text
Type 26  NJE_JOB_RECEIVED
Type 30  IKJEFT01
Type 80  ADDUSER Z4CK
Type 80  ALTUSER Z4CK ... SPECIAL
Type 80  ALTUSER Z4CK ... OMVS(...)
Type 26  NJE_OUTPUT_PROCESSED
Type 57  NJE_SYSOUT_RETURN
```

The resulting SOC view contains one deduplicated incident:

```text
HIGH  NJE-RACF-001  HCKRNJE  RUARIV  <correlation-id>  INBOUND NJE JOB PERFORMED RACF CHANGE
```

## 10. Regression test results

### New acceptance suite

`tests/test_ch10_smf_zert_patch.py`: **8 passed**.

It covers:

- `PAYROLL.MASTER` seed data
- exact TRANSMIT command and evidence
- missing dataset error path
- exact zERT console workflow
- zERT 119/11 and 119/12 generation after enablement
- successful NJE sign-on/sign-off producing 55/58
- bad NJE sign-on producing 56
- inbound server/JES RACF job correlation
- canonical `RUARIV`/`HCKRNJE`/`Z4CK` payload and deduplicated HIGH alert

### Targeted existing regression suite

Result: **48 passed, 1 skipped, 1 failed**.

The single failure is `tests/test_book_enhancements.py::test_book_network_racf_apf_rexx_smoke`, where an existing `SYS0WN.RX` output assertion expects `SYS1.VULNAPF.LIB`. The same failure was reproduced against the untouched uploaded source before/independently of this patch, so it is a pre-existing issue and was intentionally not changed as part of the NJE/zERT work.

A wider test collection contains 1200 tests. A full run was started and reached roughly one quarter of the suite before the execution window expired. The first two failures encountered were both independently reproduced against the clean uploaded build: the existing REXX `SIGNAL ON ERROR` output assertion and the existing `SYS0WN.RX` assertion. No patch-specific failure was encountered in that run before timeout.

## 11. Known limitations

- GIBSON remains a simulator; the EZZ/IEE messages are representative IBM-style simulator output, not byte-for-byte captures from a real z/OS console.
- `SYNTAXCHECK` intentionally validates the zERT statements modelled by GIBSON and accepts unrelated TCP/IP profile statements rather than attempting to reimplement the full IBM Communications Server profile grammar.
- zERT cryptographic classification is deliberately conservative. It reports TLS/SSH/IPsec only where the simulator path/port/application provides enough information; it does not pretend to inspect real cryptographic packets.
- zERT subtype 12 is simulated as an incrementing aggregation summary when matching simulator connections occur; it is not a wall-clock SMF interval writer.
- The two pre-existing regression failures described above have not been modified by this patch.

## 12. Book text/listing changes recommended

No Chapter 10 command syntax needs to change.

For the zERT section, GIBSON now supports the implementation sequence described in the book. The simulator's started procedure points its `PROFILE` DD at `SYS1.TCPPARMS(&PROF)` with `PROF=PROFILE`, so the permanent profile resolves to `SYS1.TCPPARMS(PROFILE)`. `NETADMIN.TCPPARMS(ZERTON)` is a separate lab OBEYFILE member for safely demonstrating `SYNTAXCHECK` and dynamic application before making the equivalent permanent profile change.

The distinction should remain explicit in the text: `GLOBALCONFIG...` and `SMFCONFIG...` are TCP/IP profile statements, while `VARY TCPIP...`, `DISPLAY TCPIP...`, `D SMF`, and `SET SMF=xx` are operator commands.

## IBM evidence for the zERT/operator workflow

The GIBSON zERT implementation was checked against IBM z/OS documentation:

- IBM z/OS 3.2, TCP/IP configuration data sets: `PROFILE.TCPIP` is first located through the `PROFILE` DD in the TCP/IP started procedure: https://www.ibm.com/docs/en/zos/3.2.0?topic=conventions-tcpip-configuration-data-sets
- IBM z/OS 3.2, `VARY TCPIP`: the TCP/IP address space supports both `SYNTAXCHECK` and `OBEYFILE`: https://www.ibm.com/docs/en/zos/3.2.0?topic=administration-vary-tcpip-command
- IBM, `VARY TCPIP,,SYNTAXCHECK`: validates profile syntax without changing active network configuration: https://www.ibm.com/docs/en/zos/3.1.0?topic=space-vary-tcpipsyntaxcheck
- IBM, `VARY TCPIP,,OBEYFILE`: dynamically applies TCP/IP profile changes without stopping/restarting the stack: https://www.ibm.com/docs/en/zos/2.5.0?topic=space-vary-tcpipobeyfile
- IBM z/OS 3.2, `SMFCONFIG`: `ZERTDETAIL` controls SMF 119 subtype 11 and requires `GLOBALCONFIG ZERT`; `ZERTSUMMARY` controls subtype 12 and requires `GLOBALCONFIG ZERT AGGREGATION`: https://www.ibm.com/docs/en/zos/3.2.0?topic=statements-smfconfig-statement
- IBM z/OS 3.2 Netstat CONFIG fields: `ZERT: Yes`, `Aggregation: Yes`, `INTVAL` and `SYNCVAL` expose the active zERT state: https://www.ibm.com/docs/en/zos/3.2.0?topic=ncfr-report-field-descriptions
- IBM z/OS SMF configuration: the active `SMFPRMxx` controls record selection, and updated SMF parameters can be activated using `SET SMF=xx`: https://www.ibm.com/docs/en/zos/3.2.0?topic=ssmfsp-statements-parameters-smfprmxx

