# zSecure Alert in GIBSON

GIBSON now models IBM Security zSecure Alert: the SE.A setup dialogs under the
zSecure panel, alert configurations kept in a customisation library, the
verify and refresh cycle, and C2POLICE, the started task that watches the SMF
stream as it is written and raises alerts. Alerts reach the Master Console as
`C2Pnnnnx` messages, the CTI SENTRY consoles, Office Mail in M.8, and a SIEM
such as Splunk over syslog or the HTTP Event Collector.

It is built to be as faithful to the product as a training system can be, and
where it goes further than the product it says so. A built-in tutorial at the
bottom of every alert panel walks a learner through the whole cycle and checks
the system at each step, so it only moves on when the work has really been
done.

## Getting there, keystroke by keystroke

1. Log on to TSO as IBMUSER through PHOSPHOR (or any TN3270 client).
2. At the `READY` prompt type `ISPF` and press ENTER.
3. On the ISPF Primary Option Menu, type `M.1` on the Option line and press
   ENTER. That is the Management menu, option 1, which is zSecure.
4. On the zSecure main menu, type `SE.A.A` on the Option line and press ENTER.
   You are now on the list of alert configurations.

`SE` alone gives the Setup menu, and `SE.A` the Setup Alert menu with its four
product options (A Alert, E E-mail, P PCI, S Sensitive) plus T Tutorial, which
is GIBSON's own and labelled as such.

You can also type `SE` on the M.1 menu and choose `A`, then `A` again; each PF3
climbs back one level, and the third returns you to the M.1 menu.

To use a line command, tab to the two-character field at the start of a row,
type the letter, and press ENTER. PF3 returns, PF7 and PF8 scroll.

The dialogs need a 3270 session (PHOSPHOR, x3270, the web terminal). From a
line-mode session or TSO, `ZSEC ALERTS` shows C2POLICE's status and its recent
alerts, but configuration is done in the panels.

## The configuration cycle

SE.A.A lists configurations with five step columns, as the product does:

| Column | Step | Line command |
|---|---|---|
| Set | General settings: interval, environment refresh, average, buffers | E |
| Des | Destinations: console, CTI, mail, syslog, Splunk HEC | W |
| Sel | Which alerts are switched on, and your own 4xxx alerts | S |
| Ver | Verify: generate and check the members | V |
| Ref | Refresh: promote the members to production | F |

A step reads `Req` until done and `OK` after. Changing anything after verifying
sends Ver and Ref back to `Req`. The other line commands are C Copy, I Insert,
D Delete and B Browse.

Three rules carry over from the product unchanged, because they are the lesson:

* You never edit **C2PDFL**, IBM's default. You copy it with C and change the
  copy.
* Verify writes members with the suffixes VS, VO, V, VE and VP into
  `C2P.C2PCUST`. Refresh copies them to the production members S, (none), E and
  P, and makes that configuration the active one.
* Nothing changes until the started task is told: type `/` on the SE.A.A
  command line, or issue `F C2POLICE,REFRESH` from the console. A monitoring
  change nobody refreshed is a monitoring change that did not happen.

## Alerts

The predefined alerts carry IBM's numbers and titles, from the zSecure Alert
User Reference Manual. Only those the simulator can genuinely observe are
offered, because an alert that could never fire teaches the wrong thing.

| Alert | Message | Title |
|---|---|---|
| 1101 | C2P1101W | Logon by unknown user |
| 1102 | C2P1102A | Logon with emergency user ID |
| 1103 | C2P1103E | Logon of a user ID with uid(0) (UNIX superuser) |
| 1105 | C2P1105E | System authority granted |
| 1106 | C2P1106W | System authority removed |
| 1111 | C2P1111E | Invalid password attempts exceed limit (5 in 6 minutes) |
| 1115 | C2P1115E | Too many violations |
| 1120 | C2P1120W | Major administrative activity |
| 1201 | C2P1201W | WARNING mode access on data set |
| 1202 | C2P1202E | UACC>=UPDATE on a DATASET profile |
| 1203 | C2P1203W | UACC>NONE on a DATASET profile |
| 1204 | C2P1204A | Update on APF data set |
| 1212 | C2P1212E | Access>=READ on site sensitive data set |
| 1213 | C2P1213A | Access>=UPDATE on site sensitive data set |
| 1410 | C2P1410A | UID(0) assigned |
| 1411 | C2P1411A | Permit issued on BPX.SUPERUSER |
| 1503 | C2P1503W | Global security countermeasure or option changed |
| 1504 | C2P1504W | RACF Resource class activated |
| 1505 | C2P1505E | RACF Resource class deactivated |

The WTO id is built from the alert number, as the product builds it, with a
final letter for severity: I information, W warning, E error, A action. On the
web Master Console E and A render red and I and W amber.

Alerts 4000 to 4999 are the range the product reserves for installation-defined
RACF alerts. GIBSON's own configuration ships three, as examples of exactly
that:

| Alert | Purpose |
|---|---|
| 4001 | Logon by a watched user (IBMUSER, GUEST) |
| 4002 | Network scan: three distinct ports from one address within a minute |
| 4003 | Any connection to the SMTP listener |

Create your own with line command I on the alert selection panel. The form
takes an event, result, user, resource, address and service (masks and CIDR
allowed), and an optional threshold: count, window, group by and distinct. The
panel shows the CARLa the alert corresponds to, and B on any alert shows its
CARLa.

KEVIN01, the account Chapter 5 finds with an OMVS UID of 0, triggers alert 1103
every time it logs on until the UID is corrected. Reading `KEV.PW.TEXT`, the CTF
unlock password, triggers 1212.

## Destinations

| Destination | Notes |
|---|---|
| WTO | `C2Pnnnnx text` on the Master Console, web and curses alike |
| CTI SENTRY | GIBSON's own: the dashboard alert overlay and `/cti/zalert` |
| E-mail | Userids and SE.A.E list names land in the M.8 Office Mail inbox; other addresses go through the outbound relay, off unless enabled on the host. Subject reads `Alert 1111: ...` as the product's does |
| Text message | Treated as e-mail to a gateway address, as the product does |
| SNMP trap | Shown for fidelity, not implemented; verify warns |
| UNIX syslog | RFC 3164 (the product's format for QRadar and Splunk) or RFC 5424, over UDP or TCP, to `host:port` addresses |
| Write to C2RSYSLG | The product's test option: syslog is written to the data set `C2P.C2RSYSLG` instead of sent |
| Splunk HEC | GIBSON's addition. zSecure Alert itself does not speak HEC; a forwarder or IBM Z Common Data Provider would. Offered so both routes can be practised |

SIEM forwarding in general settings chooses `ALERTS` (what zSecure Alert sends)
or `ALL`, which also sends every SMF record, the way a SIEM adapter would.

## Sending to Splunk

**Syslog, the way zSecure Alert does it.** In Splunk, add a data input under
Settings, Data inputs, UDP (or TCP), port 5514, sourcetype `syslog`. Or put this
in `inputs.conf`:

```
[udp://5514]
sourcetype = syslog
index = main
```

Then in SE.A.A, W next to your configuration: UNIX syslog `Y`, Addresses
`<splunk host>:5514`, Transport `UDP`, Format `RFC3164`, Write to C2RSYSLG `N`.
Verify, refresh, and `/`. A line arrives looking like this, and Splunk extracts
the key=value pairs without further configuration:

```
<35>Oct 21 09:56:18 GIBSON C2POLICE: C2P1111E alert=1111 sev=E user=GUEST addr=10.9.9.9 ...
```

The `<35>` is facility 4 (security) times eight, plus severity 3.

**HTTP Event Collector.** In Splunk, Settings, Data inputs, HTTP Event Collector,
New Token. Put the token on the GIBSON host, never in the lab:

```
export GIBSON_SIEM_HEC_TOKEN=<token>
```

Then W next to your configuration: Splunk HEC `Y`, URL
`https://<splunk host>:8088/services/collector/event`, and set Verify TLS to `N`
if Splunk is using its default self-signed certificate. Events arrive with
sourcetype `zos:zsecure:alert`, or `zos:smf:80` and so on for forwarded records.

**No Splunk?** `scripts/siem-sink.py` stands in for one. It receives syslog on UDP
and TCP 5514 and HEC on 8088, answers HEC exactly as Splunk does, and prints
each event:

```
python3 scripts/siem-sink.py --token 11111111-2222-3333-4444-555555555555
```

## Operator commands

| Command | Effect |
|---|---|
| `S C2POLICE` | Start the started task |
| `P C2POLICE` | Stop it |
| `F C2POLICE,REFRESH` | Reload the active configuration's production members |
| `F C2POLICE,COLLECT` | Take a CKFREEZE snapshot and refresh the environment now |
| `F C2POLICE,STATUS` | Show configuration, counts and destination statistics (GIBSON) |
| `D SVC,L` | C2POLICE appears in the service table |

From SDSF, prefix with a slash: `/F C2POLICE,STATUS`. From the curses Master
Console, which runs as a separate process, the console accepts the MODIFY and
C2POLICE's reply arrives a moment later through OPERLOG, as it would on z/OS.

## Host settings

| Variable | Default | Purpose |
|---|---|---|
| `GIBSON_SIEM_ALLOW` | `loopback,private` | Which addresses syslog and HEC may send to. Also CIDRs, host names, or `any` |
| `GIBSON_SIEM_HEC_TOKEN` | unset | The HEC token |
| `GIBSON_SIEM_HEC_TOKEN_FILE` | unset | Or a file holding it |
| `GIBSON_ZALERT` | `1` | `0` to stop C2POLICE starting at boot (or `--no-zalert`) |

## Two security notes worth teaching

Changing destinations needs SPECIAL or AUDITOR, standing in for update access to
the customisation library. Students reach SPECIAL in this lab as a matter of
course, so the allowlist matters: without it, a student could point the
forwarder at any host on the internet and exfiltrate the lab's audit trail, or
spray traffic at a third party. That is a finding worth discussing in its own
right, since on a real system whoever can change the alerting configuration can
also blind it.

The HEC token lives on the host for the same reason the mail relay's password
does: everything in the simulated catalogue should be treated as published.

## What is modelled, and what is not

Followed from the product: the SE.A menu and its options, the SE.A.A columns and
line commands, copying C2PDFL, the verify members (VS, VO, V, VE, VP) and the
production members after refresh, `MODIFY C2POLICE,REFRESH`, the general settings
and their defaults (interval 60, environment refresh 60, average 300, buffer
1024), the predefined alert numbers and titles, the 4000 to 4999 installation
range, WTO ids from the alert number, `Alert nnnn:` mail subjects, UNIX syslog in
RFC 3164, the C2RSYSLG test option, and alert 1111's threshold of five per six
minutes.

Simulated rather than reproduced: CARLa is shown, not executed by an alert
compiler; Extended Monitoring is a setting without the snapshot comparison
behind it; SNMP is not sent; the `C2P09nn` dialog messages are GIBSON's, not
the product's; the RFC 5424 structured-data ID `gibson@32473` uses the RFC 5612
documentation enterprise number; and the syslog field names are descriptive,
since the product's own list (the manual's Appendix C) was not available to
check against.
