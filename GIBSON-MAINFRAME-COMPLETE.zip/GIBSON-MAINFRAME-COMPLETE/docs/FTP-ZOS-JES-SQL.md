# GIBSON FTP against z/OS V3R2 FTP: JES and SQL modes

This note records how GIBSON's FTP server was assessed against the z/OS
Communications Server FTP server (the one in z/OS V3R2 and in IBM ZD&T), what
was changed so that FILETYPE=JES and FILETYPE=SQL behave as they do on a real
system, and what is still different.

## Sources

The reply texts and listing layouts come from captures of real systems wherever
one was available, and from IBM's FTP reply catalogue otherwise:

* a protocol capture of a z/OS 3.1 server ("IBM FTP CS 3.2") in the
  mvslovers/ftpd project, internals/ZOS_FTP_REFERENCE.md
  (https://github.com/mvslovers/ftpd);
* golden fixtures captured from a live z/OS system (IBM Z Xplore) in ro-ag/zftp,
  hfs/job_level1_test.txt, job_level2_test.txt, job_spool_test.txt and
  job_spool_abend.txt (https://github.com/ro-ag/zftp);
* V1R12 and V1R13 practitioner transcripts
  (https://thatmainframeguy.blogspot.com/2012/11/submit-or-retrieve-jobs-with-ftp.html,
  https://www.mslinn.com/mainframe/3000-run_jcl.html);
* IBM documentation: the FTP reply-code indexes (rc125, rc250, rc451, rc504,
  rc550), the JES interface level 1 and 2 descriptions, the SQL query support
  pages (sqlout, db2sqlquerysetchar), the FTP.DATA sample, APAR PH42618
  (SERVAUTH control of FILETYPE=JES), APAR PQ93390 (JESPUTGET polling) and
  APAR PN85359 (SQL NULL output).

Each behaviour below is marked **confirmed** (seen verbatim on a real system),
**documented** (IBM gives the text, but no capture was found) or **inferred**
(no source gives the exact text, so GIBSON follows the documented pattern).

## How GIBSON compared before this change

| Area | z/OS V3R2 | GIBSON before |
|---|---|---|
| SITE FILETYPE=JES / SQL reply | `200 SITE command was accepted` | `200 FILETYPE set to JES` |
| SITE FILETYPE=SEQ | accepted (the default type) | `504 Unknown FILETYPE` (only FILE was accepted) |
| Abbreviations (`site file=jes`, `jesjobn=`, `jesst=`) | accepted | only `FILETYPE=` |
| Several parameters on one SITE | accepted | not supported |
| Unknown SITE parameter | `200-Unrecognized parameter ...` then `200 SITE command was accepted` | `504 Unknown SITE option` |
| Bare SITE | `202 SITE not necessary; you may proceed` | 504 |
| JESJOBNAME, JESOWNER, JESSTATUS, JESENTRYLIMIT, JESLRECL, JESRECFM, JESGETBYDSN, JESPUTGETTO | supported | not supported |
| DB2=, SPREAD/NOSPREAD, SQLCOL= | supported | not supported |
| STAT | full 211 status block | not implemented (502) |
| HELP SITE | 214 list of SITE parameters | general HELP only |
| PUT in JES mode | `125 Sending Job to JES internal reader FIXrecfm 80`, `250-It is known to JES as JOBnnnnn`, `250 Transfer completed successfully.` | the 250 lines were right; the 125 line was `150 Opening data connection` |
| DIR in JES mode | JESINTERFACELEVEL 2 table: JOBNAME JOBID OWNER STATUS CLASS, RC=/ABEND=/(JCL error), n spool files | `JOBID JOBNAME OWNER STATUS RC` (not a z/OS layout), all of the user's jobs, no filters |
| DIR JOBnnnnn | the spool file table (ID STEPNAME PROCSTEP C DDNAME BYTE-COUNT) | not supported |
| LS / LS JOBnnnnn | job ids / JOBnnnnn.1 ... | not supported (sent the DIR text) |
| GET JOBnnnnn, JOBnnnnn.x | all spool files, each ended by ` !! END OF JES SPOOL FILE !!` | `----- DDNAME -----` banners |
| GET JOBnnnnn.n | one spool file, `125 Sending data set owner.jobname.jobid.Dnnnnnnn.ddname` | not supported |
| GET of a data set in JES mode | submits it and returns its output (JESPUTGET) | `550 File not found` |
| DELETE JOBnnnnn | `250 Cancel successful` | DELE not implemented (only the GIBSON `SITE JES PURGE` extension) |
| Job not selected by the filters | `550 Jobid JOBnnnnn not found for JESJOBNAME=..., JESSTATUS=... and JESOWNER=...` | returned regardless |
| Other users' jobs | governed by JESSPOOL | the check let every user through |
| GET in SQL mode | runs the SELECT in the data set and returns the result table | read the data set as text |
| PUT of JCL in SEQ mode | stores it as a data set | silently submitted anything starting with `//` or named *.JCL |
| PWD / CWD | `257 "'IBMUSER.'" is working directory.`; relative CWD appends | `257 "." is the current dataset prefix`; relative CWD replaced the prefix |
| DELE of a data set, CDUP, STRU, MODE | supported | not implemented |
| Active-mode data connections (PORT, EPRT) | supported | not implemented, so an ftp client in active mode could not transfer anything |

## What GIBSON does now

### Switching modes (confirmed)

    ftp> quote site filetype=jes       200 SITE command was accepted
    ftp> quote site file=sql           200 SITE command was accepted
    ftp> quote site filetype=seq       200 SITE command was accepted

`FILETYPE=FILE` is still accepted as SEQ, so older GIBSON scripts keep working.
Every parameter can be shortened to the capitals IBM documents (FILEtype,
JESJOBName, JESOwner, JESSTatus, JESENTRYLimit, JESLrecl, JESRecfm, SPRead,
NOSPRead, SQLCol), several can go on one SITE command, unknown ones give
`200-Unrecognized parameter '...' on SITE command.` followed by
`200 SITE command was accepted`, and invalid values give
`200-Jesstatus parameter (FOO) is invalid. Jesstatus ignored.` (documented
pattern). The ordinary allocation parameters clients send unprompted
(`SITE FIXrecfm 80`, RECFM=, LRECL=, TRACKS and so on) are accepted quietly.

### JES mode

**Submitting (confirmed).** `put job.jcl` replies

    125 Sending Job to JES internal reader FIXrecfm 80
    250-It is known to JES as JOB00042
    250 Transfer completed successfully.

The record format and length follow JESRECFM and JESLRECL. The TShOcker
training shell line is still added when the job starts one.

**Listing (confirmed).** GIBSON runs JESINTERFACELEVEL 2, as ZD&T's ADCD
FTP.DATA does. `dir` lists the jobs the filters select, newest first:

    125 List started OK for JESJOBNAME=IBMUSER*, JESSTATUS=ALL and JESOWNER=IBMUSER
    JOBNAME  JOBID    OWNER    STATUS CLASS
    IBMUSERA JOB00042 IBMUSER  OUTPUT A        RC=0000 3 spool files
    IBMUSERB JOB00041 IBMUSER  OUTPUT A        (JCL error) 3 spool files
    250 List completed successfully.

The defaults are JESJOBNAME=userid*, JESOWNER=userid and JESSTATUS=ALL, exactly
as on z/OS, so **a job whose name does not start with your userid is neither
listed nor retrievable until you widen the filter** with
`quote site jesjobname=*` (and `quote site jesowner=*` for other users' jobs).
That is the most common surprise on a real system, and GIBSON now reproduces
it. Completion shows as RC=nnnn, ABEND=Sxxx (or ABEND=222 for a cancelled
job) or (JCL error). With no matches the reply is `550 No jobs found for
JESJOBNAME=..., JESSTATUS=... and JESOWNER=...`; past JESENTRYLIMIT the list
stops with `250-JESENTRYLIMIT of 200 reached.  Additional entries not
displayed`.

`dir JOB00042` shows the job and its spool files (confirmed layout):

    JOBNAME  JOBID    OWNER    STATUS CLASS
    IBMUSERA JOB00042 IBMUSER  OUTPUT A        RC=0000
    --------
             ID  STEPNAME PROCSTEP C DDNAME   BYTE-COUNT
             001 JES2        N/A   X JESMSGLG       164
             002 JES2        N/A   X JESJCL          69
             003 JES2        N/A   X JESYSMSG       169
    3 spool files

`ls` lists job ids, `ls JOB00042` lists JOB00042.1, JOB00042.2 and so on, and
the reply is `250 Nlst completed successfully` (documented).

**Getting output (confirmed).**

* `get JOB00042 out.txt` or `get JOB00042.x out.txt`: `125 Sending all spool
  files for requested Jobid`, every spool file followed by the line
  ` !! END OF JES SPOOL FILE !!`, then `250 Transfer completed successfully.`
* `get JOB00042.2 jcl.txt`: one spool file, announced as `125 Sending data set
  IBMUSER.IBMUSERA.JOB00042.D0000003.JESJCL`.
* `550 Index 7 is greater than number of spool files for JOB00042` and
  `550 Jobid JOB09999 not found for JESJOBNAME=..., JESSTATUS=... and
  JESOWNER=...` for the error cases.
* Job ids can be given as JOB00042, J42 or J0000042; TSU and STC prefixes are
  understood too.

**Submit and wait (documented).** `get 'IBMUSER.CNTL(MYJOB)' out.txt` in JES
mode submits that data set and returns all of its output when it ends:
`125-Submitting job 'IBMUSER.CNTL(MYJOB)' FIXrecfm 80`, `125 When JOB00043 is
done, will retrieve its output`. **JESGETBYDSN** (`quote site jesgetbydsn`)
lets the remote name be a spool data set name instead, such as
`'IBMUSER.IBMUSERA.JOB00042.D0000003.JESJCL'` (the exact syntax IBM accepts is
not documented anywhere a capture could be found; this form is inferred).

**Cancelling (confirmed).** `delete JOB00042` replies `250 Cancel successful`
and the job leaves the queue. `delete JOB00042.1` is refused with `550 Invalid
cancel request`, as on z/OS.

**Who can see what.** The job's owner and submitter always can. In the
training (vulnerable) profile JESSPOOL is effectively unprotected, so
`quote site jesowner=*` exposes every user's job output: the real-world
finding this lab exists to teach. In secure mode only SPECIAL, OPERATIONS or
AUDITOR users see other people's jobs; anyone else gets `550 The user is not
authorized to access the job`. Every spool retrieval is written to the
security log.

**Level 1.** Set `GIBSON_FTP_JESINTERFACELEVEL=1` before starting GIBSON for
the IBM default level 1 behaviour: no header, only jobs named userid plus one
character are visible, `dir` ignores its argument, the filters cannot be
changed, and GET of a data set is refused. `quote site jesinterfacelevel=1` is
refused with `200-Unrecognized parameter`, as on z/OS, because it is an
FTP.DATA setting.

### SQL mode

`get` runs the SELECT stored in a data set or member against Db2 (the
subsystem named by `SITE DB2=`, default DB2) and returns the result table:

    ftp> quote site filetype=sql
    200 SITE command was accepted
    ftp> get whoadm.sql result.txt
    125 Sending data set IBMUSER.WHOADM.SQL
    250 Transfer completed successfully.

The default report format (NOSPREAD) introduces each section with a dashed
line whose first character says what follows: `s` the statement, `h` the
headings, `d` the data, `e` an error (documented; the exact layout is
inferred). Numbers are right-aligned and a NULL is a column of dashes
(confirmed, APAR PN85359). `quote site spread` gives tab-separated columns for
a spreadsheet; `quote site sqlcol=labels` uses labels (Db2 here keeps none, so
COL001, COL002 as z/OS does) and `names`/`any` use column names. SQL comments
(`--`) and sequence numbers in columns 73-80 are ignored and a trailing
semicolon is allowed.

Errors (documented):

* an SQL error (an unknown table, say) sends the Db2 messages in the data
  (`DSNT408I SQLCODE = -204 ...`) and ends `551 Transfer aborted: SQL
  PREPARE/DESCRIBE failure`;
* anything but a query (INSERT, UPDATE, DELETE) gives `551 Transfer aborted:
  unsupported SQL statement`; IBM's documents disagree between 551 and 554
  for this one, and 551 was chosen;
* an unknown subsystem gives `551 Transfer aborted: attempt to connect to DB2
  failed (00F30006)`;
* on z/OS, TYPE I gives `504 Filetype SQL requires type A (ASCII) or E
  (EBCDIC) or B (DBCS)`. GIBSON answers the query in TYPE I as well and sends
  the result as text. GIBSON's SYST reply says UNIX (the fingerprinting labs
  rely on it), so the Linux and macOS ftp clients switch to binary by
  themselves and send TYPE I before every transfer; with the 504 the SQL lab
  could not be used from them at all. This is a deliberate difference.

Listings in SQL mode are ordinary data set listings, as on z/OS.

**The SQL PUT lab is kept.** On z/OS a PUT in SQL mode simply stores the data
set. GIBSON stores it too, and in the training profile it still runs the
statement as a DSNTEP2 job and writes the report data set, because the manual's
lab ("quote site filetype=sql", "put whoadm.sql") depends on it; the reply then
carries one extra line starting `250-GIBSON SQL LAB:` so it is clear that this
part is GIBSON's. The report is written to a data set named after the upload,
with the last qualifier replaced by RESULT (`put whoadm.sql` stores
IBMUSER.WHOADM.SQL and writes IBMUSER.WHOADM.RESULT, which a GET in SEQ mode
retrieves), as well as to the older JOBWHO_HAS_SYSADM.txt-style file. The job
is named after the user (IBMUSERQ, BOBQ), so the default JESJOBNAME=userid*
filter lists it. Set `GIBSON_FTP_SQL_LAB=0` to turn the hook off; it is always
off in secure mode.

**Typing SITE in your client.** The ftp clients handle SITE themselves before
anything reaches GIBSON. The Linux and macOS client knows `site` only in lower
case, so `SITE FILE=SQL` gives `?Invalid command.` from the client; type
`site file=sql` or `quote site file=sql`. The Windows ftp client has no site
command at all; type `quote site file=sql` (or `literal site file=sql`).
`quote` works in every client. A hyphen instead of the equals sign
(`filetype-sql`) is not a SITE parameter, on z/OS or in GIBSON, and gets
`200-Unrecognized parameter`.

**The TSO FTP client.** The `FTP` command at TSO READY takes SITE and QUOTE
SITE with every parameter and abbreviation above, so `SITE FILE=JES`,
`SITE FILE=SQL` and `SITE JESJOBNAME=*` work there too, with the same replies.
In JES and SQL mode its GET, PUT, DIR, LS and DELETE are carried out by
GIBSON's FTP server over the network, as a real TSO FTP client does: PUT of a
JCL data set submits it, DIR lists jobs, GET JOBnnnnn.n retrieves spool into a
data set, and GET of a query in SQL mode writes the result table to
userid.member.RESULT and shows it on the screen. QUOTE sends any other command
to the server (QUOTE STAT, for example). In SEQ mode the client copies data
sets directly, as before. If GIBSON's FTP server is not running, JES and SQL
mode say so (EZA1554I).

### Also changed

* STAT reports the session: the file type line (`211-FileType JES (MVS Job
  Spool). JES Name is JES2`, confirmed), JESLRECL, JESRECFM and
  JESINTERFACELEVEL (confirmed), the JES filters, JESENTRYLIMIT, JESPUTGETTO,
  JESGETBYDSN, SQLCOL and SPREAD (inferred wording) and `211-SITE DB2
  subsystem name is DB2` (confirmed), ending `211 *** end of status ***`.
* HELP SITE lists the SITE parameters in z/OS's format.
* PWD and CWD work as for MVS data sets: `257 "'IBMUSER.'" is working
  directory.`, a quoted name replaces the prefix, an unquoted one is
  appended, and CDUP drops a qualifier.
* DELE deletes a data set in SEQ mode (`250 IBMUSER.X deleted.`).
* PORT and EPRT work, so a client in active mode can transfer files and
  listings. The server connects back only to the client's own address; a PORT
  naming another host (the FTP bounce attack) is refused with 501.
* A PUT of JCL in SEQ mode now stores it as a data set (it used to be
  submitted, so JCL could not be put into a PDS by FTP). Submission happens in
  JES mode, as on z/OS.
* Ordinary GET, PUT and DIR use the z/OS reply texts (`125 Sending data set
  ...`, `125 Storing data set ...`, `125 List started OK`, `250 Transfer
  completed successfully.`).

## Still different from z/OS

* The SEQ-mode DIR output is still in a Unix-like layout rather than z/OS's
  `Volume Unit Referred Ext Used Recfm Lrecl BlkSz Dsorg Dsname` table, and
  member lists are not shown for a PDS. Several tools read the current layout,
  so it was left alone.
* The greeting and SYST keep GIBSON's own text by design (the fingerprint
  tests depend on it); a real system answers SYST with `215 MVS is the
  operating system of this server. FTP Server is running on z/OS.`
* MKD, RMD, RNFR/RNTO, APPE, SIZE, MDTM, REST and the record-structure options
  (STRU R, SITE RDW) are not implemented.
* There are no TSU or STC entries in the JES listing, because GIBSON's JES
  holds only batch jobs. ACTIVE jobs therefore never appear, since GIBSON runs
  each job to completion as it is submitted.
* Spool files written by programs within a step mostly appear inside JESYSMSG
  rather than as their own SYSPRINT or SYSOUT entries, because that is how
  GIBSON's JES engine records them.
* The SERVAUTH check of APAR PH42618 (EZB.FTP.*.ACCESS.JES) is not modelled.
* The TSO `FTP` client's SEQ mode is still a direct copy between data sets
  rather than a network transfer, and it has no MGET, MPUT or LOCSITE.
* The texts marked inferred above could only be closed by comparing with a
  live ZD&T system.
