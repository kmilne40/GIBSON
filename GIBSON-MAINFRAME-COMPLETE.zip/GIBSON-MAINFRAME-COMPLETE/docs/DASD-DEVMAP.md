# DASD volumes and the DEVMAP

GIBSON's simulated z/OS now has real disks behind its volume serials. Every
data set lives on a 3390 volume, every volume sits on a device number, and the
device list is a ZD&T-format devmap in the state folder. The operator commands
that a z/OS systems programmer uses every day (D U, DS P, V) work against it,
new data sets are placed on the volume asked for with real 3390 space
accounting, and a data set whose volume is offline cannot be opened from TSO,
ISPF, FTP or batch, exactly as on a real system.

This guide is for the person running GIBSON and for students. Every mainframe
step is written out keystroke by keystroke.

## Contents

1. [What is where](#what-is-where)
2. [Operator commands](#operator-commands)
3. [Placing data sets on volumes](#placing-data-sets-on-volumes)
4. [Listing a volume's VTOC](#listing-a-volumes-vtoc)
5. [When a volume is offline](#when-a-volume-is-offline)
6. [Adding a volume, the ZD&T way](#adding-a-volume-the-zdt-way)
7. [Security exercises](#security-exercises)
8. [Switches and files](#switches-and-files)

## What is where

When GIBSON starts for the first time it writes `devmap` into the state folder
(by default `~/mfsim/devmap`) with these devices:

| Device | Volume | Model | What is on it |
|---|---|---|---|
| 0A80 | SBSYS1 | 3390-9 | System residence, the IPL volume (SYS1.PARMLIB, SYS1.PROCLIB, SYS1.LINKLIB) |
| 0A30 | SBRES1 | 3390-9 | Secondary residence (the RACF backup database) |
| 0A31, 0A32 | A3RES1, A3RES2 | 3390-9 | z/OS 3.2 target libraries |
| 0A81 to 0A8D | SBSYS2 ... SBHFS2 | 3390-9 / -3 | System data, page, UNIX files, Db2, spool, SMP/E, user data (SBUSR1 on 0A8A, SBUSR2 on 0A8B) |
| 0A8E | SBTEMP | 3390-3 | Temporary data sets (a small volume, useful for "out of space" exercises) |
| 0A8F | SBDLB1 | 3390-9 | Distribution libraries and old backups, **offline at IPL** |
| 0A90 | WORK01 | 3390-27 | TSO user and work data sets: the default volume |
| 0A91 to 0A97 | SBSMF1, SBPRD1, SBCKP1, SBCKP2, TK5RES, MVSRES, SPOOL1 | | SMF, product libraries, JES2 checkpoints, site libraries |

Volumes the system depends on (the IPL volume, page, spool, checkpoints,
WORK01 and the other system volumes) can be told to go offline, but like on
z/OS they only become *pending offline* because the system has them
allocated, and they keep working. The user and spare volumes (SBUSR1, SBUSR2,
SBWORK, SBTEMP, SBDLB1, and any you add) really go offline.

## Operator commands

Type these at the web Master Console (`http://localhost:8443/console`), in the
terminal Master Console, or after a `/` on the SDSF command line. In SDSF the
command runs as your userid, so RACF OPERCMDS rules apply (see the security
exercises).

| Command | What it shows or does |
|---|---|
| `D U,DASD,ONLINE` | Every online DASD: unit, status (O online, A allocated, A-PND pending offline), volume serial and use attribute (PRIV/RSDNT, STRG/RSDNT) |
| `D U,DASD,OFFLINE` | The devices that are offline |
| `D U,DASD` | Every DASD device, online or not |
| `D U,,,0A80,16` | Sixteen devices starting at 0A80 |
| `D U,VOL=SBUSR1` | Which unit a volume is mounted on (IEE455I if it is not mounted) |
| `DS P,0A80` | DEVSERV PATHS (IEE459I): model, cylinders, open data set count, paths |
| `V 0A8A,OFFLINE` | Vary a device offline (IEE303I); a system volume goes pending (IEF524I) |
| `V 0A8A,ONLINE` | Vary it back online (IEE302I) |
| `V 0A8A-0A8B,OFFLINE`, `V (0A8A,0A8B),ONLINE` | Ranges and lists |
| `D IPLINFO` | The IPL device and volume |
| `D PROG,APF` | The APF list, with the volume each library is authorised on |

To try it, at the Master Console:

1. Type `D U,DASD,ONLINE` and press **Enter**. Find SBUSR1 on 0A8A.
2. Type `V 0A8A,OFFLINE` and press **Enter**. The reply is
   `IEE303I 0A8A     OFFLINE`.
3. Type `D U,DASD,OFFLINE` and press **Enter**. 0A8A is listed.
4. Type `V 0A8A,ONLINE` and press **Enter** to bring it back.

## Placing data sets on volumes

**TSO.** At the READY prompt:

    ALLOCATE DA('IBMUSER.MY.DATA') NEW VOLUME(SBUSR1) TRACKS SPACE(10,5) RECFM(F,B) LRECL(80) BLKSIZE(27920)

Press **Enter**. Success is silent (READY), as on z/OS. `LISTDS 'IBMUSER.MY.DATA'`
then shows `--VOLUMES--  SBUSR1`. TSO ALLOCATE also takes CYLINDERS, BLOCK(n),
DIR(n) for a library, DSORG(PO|PS), LIKE('model.data.set'), and SHR / OLD / MOD
for existing data sets. The replies are the real ones: IGD17101I for a
duplicate name, IGD17272I when the volume has no room, IKJ56221I when the
volume is not mounted, IKJ56228I when the data set is not catalogued.

**ISPF 3.2.** Type the volume in **Volume serial** on the Allocate New Data Set
panel. Leave it blank for WORK01.

**JCL.** VOL=SER, UNIT, SPACE and DCB are honoured for every step, not just
IEFBR14, and the dispositions are carried out:

    //ALLOC    JOB (1),'ALLOCATE',CLASS=A,MSGCLASS=X
    //STEP1    EXEC PGM=IEFBR14
    //NEWDS    DD DSN=IBMUSER.ON.USR1,DISP=(NEW,CATLG),
    //            UNIT=3390,VOL=SER=SBUSR1,SPACE=(TRK,(10,5)),
    //            DCB=(RECFM=FB,LRECL=80,BLKSIZE=27920)
    //UNCAT    DD DSN=IBMUSER.UNCATALOGED,DISP=(NEW,KEEP),
    //            VOL=SER=SBUSR2,SPACE=(TRK,1)

The job log shows `IEF285I IBMUSER.ON.USR1 CATALOGED` and
`IEF285I   VOL SER NOS= SBUSR1.`; the second data set is KEPT, which means
it is on SBUSR2 but not in the catalogue (LISTCAT will not find it, LISTVTOC
and ISPF 3.4 with the volume serial will).

**Space.** Space is counted the way a 3390 counts it: 15 tracks a cylinder,
56664 bytes a track, and the number of blocks a track holds depends on the
block size (2 of 27998, 3 of 18452, 4 of 13682, 78 of 80). An allocation larger
than the volume's free space fails with IEF257I SPACE REQUESTED NOT AVAILABLE
(JCL) or IGD17272I (TSO). Try `SPACE=(CYL,4000)` on SBTEMP, a 3390-3.

**Abends.** With `GIBSON_DASD_ABENDS=on` a data set that outgrows its primary
and fifteen secondary extents abends B37, one with no secondary space D37, and
one on a full volume E37. This is off by default so that nothing that works
today starts failing.

## Listing a volume's VTOC

The VTOC (volume table of contents) lists every data set on a volume,
catalogued or not.

**Batch, IEHLIST.** Submit:

    //LISTV    JOB (1),'LISTVTOC',CLASS=A,MSGCLASS=X
    //STEP1    EXEC PGM=IEHLIST
    //SYSPRINT DD SYSOUT=*
    //DD1      DD UNIT=3390,VOL=SER=SBUSR1,DISP=OLD
    //SYSIN    DD *
      LISTVTOC VOL=3390=SBUSR1
      LISTVTOC FORMAT,VOL=3390=SBUSR1
    /*

To submit it: save the JCL as a member, for example `IBMUSER.JCL(LISTV)`, then
at READY type `SUBMIT 'IBMUSER.JCL(LISTV)'` and press **Enter**. To read the
output: type `ISPF` and press **Enter**, type `S.ST` in the Option field and
press **Enter**, type `S` next to LISTV and press **Enter**, and page down with
**PF8** to the SYSPRINT section. The first LISTVTOC gives names, dates and
types; FORMAT adds DSORG, RECFM, LRECL, block size, tracks and extents. Both
end with the free space (empty cylinders and tracks) and free DSCBs.

**ISPF 3.4.** From the ISPF Primary Option Menu type `3.4` and press **Enter**.
Clear **Dsname Level** (press **Erase EOF** with the cursor in it), type
`SBUSR1` in **Volume serial**, and press **Enter**. ISPF lists every data set
on SBUSR1, catalogued or not. With both a Dsname Level and a Volume serial,
only the data sets on that volume that match the level are listed.

## When a volume is offline

A data set whose volume is offline cannot be opened, from anywhere:

| From | What happens |
|---|---|
| TSO (ALLOCATE, SUBMIT, EDIT, DELETE, anything that opens it) | `IKJ56221I DATA SET ... NOT ALLOCATED, VOLUME NOT AVAILABLE` |
| ISPF (browse, view, edit, member list) | `Volume SBUSR1 not available` on the panel |
| ISPF 3.4 with that volume | `Volume SBUSR1 not mounted` |
| FTP GET / PUT | `550 Unable to allocate ...: volume SBUSR1 is not available` |
| JCL | `IEF233A M 0A8A,SBUSR1,...` mount request, `IEF702I ... UNABLE TO ALLOCATE`, the remaining steps `IEF272I ... NOT EXECUTED`, and the job ends with a JCL error |
| IDCAMS DELETE | `IDC0551I ** ENTRY ... NOT DELETED`, `IDC3003I ... CONDITION CODE IS 8` |

The catalogue is not on the volume, so LISTCAT and LISTDS still answer: you can
see that a data set exists and where it is, but not open it. Vary the volume
online and everything works again.

## Adding a volume, the ZD&T way

On ZD&T you create a volume file with `alcckd`, add a `device` line to the
devmap, restart, initialise the volume with ICKDSF and vary it online. GIBSON
follows the same steps.

1. With GIBSON stopped, on the host:

       python -m gibson.cli --add-volume WORK02 --unit 3390-9

   (from the GIBSON folder; on the ISO open **Terminal** and type
   `sudo systemctl stop gibson`, then
   `gibson --add-volume WORK02 --unit 3390-9` (the ISO's /usr/local/bin/gibson
   runs the command against the service's state in /var/lib/gibson/mfsim),
   then `sudo systemctl start gibson`). GIBSON prints the device number it
   chose (0AA0 for the first one) and the next steps. `--devnum 0AB0` picks the
   number; `--init` labels it and brings it online in one go.
2. Start GIBSON. At the Master Console type `D U,DASD,OFFLINE` and press
   **Enter**: 0AA0 is there, offline. `V 0AA0,ONLINE` fails with
   IEE103I UNIT 0AA0 NOT BROUGHT ONLINE because the volume has no label yet.
3. Submit an ICKDSF job to initialise it:

       //INITV    JOB (1),'ICKDSF',CLASS=A,MSGCLASS=X
       //STEP1    EXEC PGM=ICKDSF
       //SYSPRINT DD SYSOUT=*
       //SYSIN    DD *
         INIT UNITADDRESS(0AA0) NOVERIFY VOLID(WORK02) VTOC(0,1,14)
       /*

   The output shows ICK00700I (the device), the ICK003D "REPLY U TO ALTER
   VOLUME" question (GIBSON answers U for you and notes it on the console),
   ICK01314I with the VTOC location, and ICK00001I with condition code 0.
4. At the Master Console type `V 0AA0,ONLINE` and press **Enter**
   (IEE302I 0AA0 ONLINE), then `D U,VOL=WORK02`.
5. Use it: `ALLOCATE DA('IBMUSER.ON.WORK02') NEW VOLUME(WORK02) TRACKS SPACE(10,5)`.

ICKDSF INIT refuses a system volume, checks `VERIFY(volser)` against the
current label, and will not erase a volume that has data sets on it unless you
add `PURGE`; with PURGE every data set on the volume is gone, as on z/OS.

**Your own ZD&T layout.** `python -m gibson.cli --import-devmap /path/to/devmap`
adds the DASD of a real ZD&T devmap: volume serials come from the volume file
names, models from their sizes when the files are reachable, and addresses
GIBSON already uses are skipped. `--list-volumes` prints every device.

## Security exercises

These are seeded in vulnerable mode (the default). In secure mode none of them
exists and the RACF profiles below are UACC(NONE).

### 1. The forgotten volume

SBDLB1 on 0A8F was "the old backups volume" and is offline. On it is an
uncatalogued copy of the RACF database, `SYSBKUP.RACF.D230317.COPY`, with no
RACF profile protecting it. The vary command is protected by the OPERCMDS
profile `MVS.VARY.DEV`, which in vulnerable mode is UACC(UPDATE).

As a student (log on to TSO as BOB / BOB):

1. At READY type `ISPF` and press **Enter**. In the Option field type `S` and
   press **Enter** to open SDSF. On the COMMAND INPUT line type
   `/D U,DASD,OFFLINE` and press **Enter**: 0A8F is offline.
2. Type `/V 0A8F,ONLINE` and press **Enter**. It works, because UACC(UPDATE)
   lets anyone vary devices. (In secure mode: IEE345I VARY AUTHORITY INVALID.)
3. List the VTOC: ISPF `3.4`, clear Dsname Level, Volume serial `SBDLB1`,
   **Enter**. `SYSBKUP.RACF.D230317.COPY` is there, though LISTCAT never shows
   it because it is not catalogued.
4. Download it with FTP in binary (`ftp localhost`, log on as BOB, `binary`,
   `get 'SYSBKUP.RACF.D230317.COPY' racf.bin`) and in the Pen-Test Shell run
   `racf2john racf.bin > hashes.txt` and `john hashes.txt`.

The lesson: data sets on offline or forgotten volumes are invisible to the
catalogue, to most audits and to many people, but not to someone who can vary
a device online and read a VTOC. Protect OPERCMDS MVS.VARY.**, protect every
data set with a profile (SETROPTS PROTECTALL(FAIL)), and scratch old backups.

### 2. The VTOC names what you cannot read

As BOB, list SBUSR1 (`LISTVTOC VOL=3390=SBUSR1`, or ISPF 3.4 with Volume serial
SBUSR1). `FIBS.HR.SALARY.EXTRACT` is listed. Browsing it fails with ICH408I:
FIBS.HR.** is UACC(NONE). Reading a VTOC needs no access to the data sets on
it, so data set names are reconnaissance: they tell an attacker what is worth
going after and whose userid to target.

### 3. An APF library on the wrong volume

At the Master Console, `D PROG,APF` lists entry 017 `SBUSR2 SYS2.LEGACY.LOADLIB`,
a dynamic APF entry for a library that was deleted. The health check shows it
too: in SDSF type `CK` and press **Enter**, find `CSV_APF_EXISTS`
(EXCEPTION-LOW), type `S` next to it and press **Enter** to read
`CSVH0957E Problem(s) were found with data sets in the APF list`.

Nothing protects SYS2.**, so BOB can create the library, but only on the right
volume does it become authorised, exactly as on z/OS, where an APF entry names
both the data set and its volume:

    ALLOCATE DA('SYS2.LEGACY.LOADLIB') NEW DIR(10) TRACKS SPACE(5,5)

creates it on WORK01, which is *not* authorised (CSV_APF_EXISTS now says
`DS not on volume (on WORK01)`). Delete it and allocate it again with
`VOLUME(SBUSR2)`: now a program link-edited into it runs APF-authorised. The
fix: `SETPROG APF,DELETE,DSNAME=SYS2.LEGACY.LOADLIB,VOLUME=SBUSR2`, a
protective profile for SYS2.**, and CSV_APF_EXISTS kept clean.

### 4. Wiping a volume

DASDVOL SBDLB1 is UACC(ALTER), so any user may run ICKDSF INIT against it
(see "Adding a volume"): `INIT UNIT(0A8F) VERIFY(SBDLB1) VOLID(SBDLB1) PURGE`
erases every data set on it. In secure mode the profile is UACC(NONE) and the
job ends with ICH408I ... CL(DASDVOL) INSUFFICIENT ACCESS AUTHORITY.

## Switches and files

| Item | Meaning |
|---|---|
| `GIBSON_DEVMAP=off` | Switch the whole DASD layer off: the console shows the old fixed device table, no volume checks are made, and everything behaves exactly as before this feature |
| `GIBSON_DASD_ABENDS=on` | B37 / D37 / E37 space abends (off by default) |
| `<state folder>/devmap` | The ZD&T-format device list. Edit it with GIBSON stopped |
| `<state folder>/dasd-state.json` | Each device's label, model, status (ONLINE, OFFLINE, PENDING), use attribute and whether it is initialised |
| `<state folder>/dasd-lab.json` | Records that the security exercises were seeded, so they are not seeded again and an operator's changes survive a restart |
| `--reset` | Puts the devmap and the exercises back to the defaults with everything else |

An existing state folder from before this feature is upgraded on first start:
the devmap is generated, and any volume serial its data sets use that GIBSON
does not know gets a device of its own (from 0AA0), so no data set is ever
stranded.
