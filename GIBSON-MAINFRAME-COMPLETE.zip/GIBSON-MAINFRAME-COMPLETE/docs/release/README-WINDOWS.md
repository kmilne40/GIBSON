# GIBSON Mainframe Simulator for Windows

GIBSON is a deliberately vulnerable z/OS training simulator. It gives you TSO, ISPF, JES2 and SDSF, RACF, FTP with JES and SQL modes, DASD volumes, a Master Console, and a Pen-Test Shell full of mainframe assessment tools, so you can learn mainframe security without access to a real mainframe.

`GIBSON-Setup.exe` installs all of it on a Windows PC, and always ends with a GIBSON that works. When the PC can run WSL 2, it sets that up for you and installs the GIBSON Linux system, which is the same system as the GIBSON ISO with every Pen-Test Shell tool included, and Windows reaches it at `localhost`. When it can't, setup installs GIBSON's native Windows build instead, without stopping to ask. It installs without an internet connection, because everything it needs is inside the installer.

> **GIBSON is vulnerable on purpose.** Its training profile contains weak passwords, over-permissive RACF profiles and other planted findings for you to discover. Run it on your own PC or a trusted lab network, and never expose its ports to the internet.

## Download

| File | What it is |
| --- | --- |
| `GIBSON-Setup.exe` | The Windows installer (about 880 MB) |
| `windows-tools.zip` | Only for building GIBSON-Setup.exe yourself with build-windows.bat: the Pen-Test Shell tools it adds |

For a Mac, or for a bootable USB stick or virtual machine, use the macOS or ISO release instead.

To check the download, open PowerShell in the folder where you saved it and type:

```powershell
Get-FileHash .\GIBSON-Setup.exe -Algorithm SHA256
```

The hash it prints should be:

```
BCED9AAA20BDFE124E4F3B23B924D25A2A10E3667E8DB5777BD93EFE3BF01110
```

## What you need

To run GIBSON at all, you need any 64-bit Windows 10 (version 1809 or later) or Windows 11, about 4 GB of free disk space, and an account that can approve administrator prompts. That's enough for GIBSON's native Windows build, which needs no WSL, no virtualisation and no restart.

To get the full Linux toolset as well, which is the same system as the GIBSON ISO with every Pen-Test Shell tool, the PC also needs Windows 10 version 22H2 (build 19045) or Windows 11, with virtualisation turned on in the BIOS/UEFI setup (Intel VT-x or AMD-V). If you run Windows in a virtual machine, nested virtualisation has to be turned on at the host, in Hyper-V or VMware, because Microsoft doesn't support WSL 2 inside a VirtualBox VM.

You don't need to check any of this yourself. Setup checks the PC, sets up the full toolset when it can, and installs the native build either way, so GIBSON always works. The native build is the same simulator, and it carries its own Pen-Test Shell tools, nmap and Python included, so it needs nothing else installed either (see **The Pen-Test Shell** below).

## Installing

You don't choose anything, and the install can't fail. It always installs a GIBSON that works on this PC, and sets up the full Linux toolset as well when the PC can run it.

1. Double-click `GIBSON-Setup.exe`. The installer is not code-signed, so Windows SmartScreen may say it protected your PC: click **More info**, then **Run anyway**, and approve the administrator prompt.
2. Accept the licence and keep the suggested folder, `C:\Program Files\GIBSON`. Click **Next**.
3. Tick **Create a desktop shortcut** if you want one, click **Next**, then **Install**.
4. When it finishes, GIBSON opens in your browser.

If the PC can run the full Linux toolset in WSL 2 and has never had WSL, Windows restarts once during this and finishes by itself when you sign in again. If the PC can't run WSL 2, setup doesn't stop or ask: it installs GIBSON's native Windows build instead, which needs no WSL and no restart, and you can add the full toolset later from the Start menu with **Fix WSL for GIBSON**.

For a classroom, `GIBSON-Setup.exe /SILENT` installs without questions. Add `/MODE=native` to install the native build only and never touch WSL.

## First start

Open **GIBSON** from the Start menu or the desktop. Your browser opens on a running GIBSON. What you do next depends on which mode you're in, and GIBSON tells you:

- **Native Windows mode** (the common case on a laptop or a locked-down PC): GIBSON has already started itself, so the Master Console is ready and there's nothing to answer. Sign in as `admin` with the password `gibsonadmin!`. The MFA PIN for this system is `0000`.
- **Full Linux mode** (WSL 2): GIBSON starts like a real mainframe and waits to be IPLed. Sign in as `admin` / `gibsonadmin!`, then click in the command line at the bottom of the Master Console and type each reply, pressing **Enter** after each one:

   ```
   R 01,CLPA
   R 02,U
   R 03,Y
   R 04,1234
   R 05,GIBSON
   R 06,SKIP
   ```

   Use any four digits you like for the `R 04` reply. It becomes the MFA PIN. Wait until the panel on the right shows **IPL COMPLETE**.

## Connecting

| What | Where | Sign in |
| --- | --- | --- |
| Master Console | `http://localhost:8443/console` | admin / gibsonadmin! |
| Dashboard | `http://localhost:8443/` | admin / gibsonadmin! |
| Pen-Test Shell | `http://localhost:8022/` | admin / gibsonadmin! |
| TSO through a 3270 emulator such as wc3270 | `localhost` port 23 | IBMUSER / SYS1 |
| FTP | `localhost` port 21 | your TSO userid |
| Welcome page | `http://localhost/` | |

The other services are on their usual ports: USS 2022, NJE 175, Db2 446, the CBSA API 8080, the FIBS bank 9080 and SMTP 2525. If something else on the PC already uses port 80 (Windows itself often does, through IIS or a reservation), the welcome page moves to `http://localhost:8000/` and the Master Console says so; the Start menu's **GIBSON Welcome page** opens it there.

## The Start menu

| Entry | What it does |
| --- | --- |
| GIBSON Mainframe Simulator | Starts GIBSON and opens the Master Console. Uses the full Linux system if it's healthy, the native build otherwise, deciding for itself |
| GIBSON Dashboard | The same, opening the dashboard |
| GIBSON Pen-Test Shell | The same, opening the Pen-Test Shell |
| GIBSON Welcome page | The same, opening the welcome page |
| Stop GIBSON | Stops GIBSON, whichever mode it's in |
| Fix WSL for GIBSON | Enables or repairs the full Linux toolset (WSL 2) and says what to change if it can't |
| GIBSON diagnostics | Collects a report of why GIBSON won't start, about two minutes, and opens it in Notepad |
| Full Linux toolset | A Linux shell on the GIBSON system, when the full toolset is installed |
| Native Windows | Starts the native build explicitly, or runs it in secure or diagnose mode |

With the full Linux toolset, GIBSON also starts by itself, hidden, whenever you sign in to Windows, so it's usually ready a minute after you sign in. In native Windows mode it starts when you open it from the Start menu and runs in the background with no window to keep open, until you choose **Stop GIBSON** or sign out. If it ever stops as it starts, a message says so and shows its last lines of output.

## Commands

Setup puts `gibson` on your PATH, so GIBSON's host commands work in any new Command Prompt. For example:

```
gibson --list-volumes
gibson --help
```

With the full Linux toolset these run inside the GIBSON system against the same lab the service uses, and Windows paths in them are translated for you; in native Windows mode they run the native build against its lab in `%USERPROFILE%\mfsim`. In the **GIBSON Linux terminal**, `sudo systemctl status gibson` shows whether GIBSON is running and `journalctl -u gibson` shows its log.

In the Pen-Test Shell, type `tool-check` to see that every course tool is ready.

## The Pen-Test Shell

In native Windows mode the Pen-Test Shell is a bash shell, the same as on Linux and the Mac, so the course's commands work as printed. GIBSON carries its own tools for it: nmap, hydra, jumbo John the Ripper with racf2john, nikto, wget, curl, netcat (`nc`), telnet, ftp, whois, ping, dig and host, the x3270 suite's `s3270` and `c3270`, Python 3.12 with pip, and every course tool (ezrecon, zniff, cicspwn, tshocker, PHOSPHOR, the NJE and PassTicket tools, gibson-scan). Every network tool still goes through the scope guard, so only 127.0.0.1 and sighberbank.com can be reached.

`python3`, `python` and `pip` in the shell are GIBSON's own Python 3.12, which already has every package the course tools use, so a course script you run yourself (`python3 tools/...`) needs no `pip install`. A Python you installed on Windows yourself is a different one without those packages, and a very new one (3.15) cannot yet install some of them on Windows without a compiler.

One thing works differently in native Windows mode, because its licence doesn't allow it to be bundled: **Npcap**, the packet driver that nmap and zniff use on Windows. Without it:

- **nmap** scans with TCP connects. Version detection (`-sV`) and the NSE scripts work as usual; `-sS`, which needs raw packets, runs as `-sT`, and nmap says so.
- **zniff** can read capture files but not watch live traffic.

To add Npcap, open a Command Prompt, type `%USERPROFILE%\mfsim\pentest\bin\toolbox-setup.cmd` and press **Enter**; it offers to install Npcap with winget from its maker, after which you choose **Stop GIBSON** from the Start menu and open GIBSON again. The full Linux toolset in WSL 2 has none of these limits.

`dig` and `host` in native Windows mode are GIBSON's own, written on the dnspython library, because Windows has neither; they take the usual options, including zone transfers (`dig axfr @server zone`).

## Uninstalling

Open **Settings**, **Apps**, **Installed apps**, find **GIBSON Mainframe Simulator** and choose **Uninstall**. This removes GIBSON, its Linux system and the lab inside it. If you also used the native build, its lab in `%USERPROFILE%\mfsim` is left in place for you to delete. WSL itself stays installed, because other software may use it.

## If something goes wrong

| What you see | What to do |
| --- | --- |
| You wanted the full Linux tools but got native Windows mode | The PC can't run WSL 2 yet. Open **GIBSON**, then **Fix WSL for GIBSON**. It turns on what WSL needs, or says what to change in the BIOS or on a VM's host, then run **Fix WSL for GIBSON** once more. GIBSON picks up the full toolset by itself after that. |
| GIBSON opened in Windows mode and you expected WSL | The full Linux system didn't start this time. Run **Fix WSL for GIBSON**; nothing is lost, and the native build keeps working meanwhile. |
| `WSL_E_DISTRO_NOT_FOUND` | WSL is on the PC but GIBSON's Linux system didn't finish installing. GIBSON uses its native build meanwhile. Run **Fix WSL for GIBSON**, then `GIBSON-Setup.exe` again, to finish the full toolset. |
| Nothing happens after a restart | Open **GIBSON** from the Start menu; it starts whichever mode is ready. |
| The Master Console doesn't open | GIBSON can take a minute or two to start. Open **GIBSON Mainframe Simulator** from the Start menu again. |
| GIBSON doesn't start at all | Open **GIBSON diagnostics** from the Start menu and wait about two minutes. It opens a report, `GIBSON-diagnostics.txt` in your user folder, to send with your question. |
| The welcome page isn't at `http://localhost/` | Another program has port 80, so GIBSON put the page on `http://localhost:8000/` instead. Everything else is unaffected. |
| A course tool doesn't work | Type `tool-check` in the Pen-Test Shell; it names anything missing and how to fix it. |

Setup and GIBSON log what they do to `%ProgramData%\GIBSON\gibson-wsl.log` and, in `%LOCALAPPDATA%\GIBSON`, `gibson-wsl.log`, `gibson-launch.log`, `gibson-native.log`, and the native build's own output in `gibson-ipl.log` and `gibson-server.log`. Include them when you report a problem. To open the second folder, press **Windows+R**, type `%LOCALAPPDATA%\GIBSON` and press **Enter**.

## Licences

The tools bundled for the Pen-Test Shell are separate programs under their own licences, which are not GIBSON's. Each licence, with a list of the tools, their versions and where their source code is, is in `C:\Program Files\GIBSON\native\tools\licenses` and `NOTICES.txt` beside it.

GIBSON is released under the GIBSON Community and Educational Licence, version 1.0, for personal learning, community education, academic teaching and non-commercial research. Commercial rights are reserved. See `LICENSE.md` for the full terms.

Copyright © 2022 to 2026 Kev Milne. Published by Neuro Training Ltd / [OffensiveSec.org](https://offensivesec.org).
