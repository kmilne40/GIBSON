# Installing GIBSON on Windows with GIBSON-Setup.exe

This guide explains what GIBSON is, how to download and check `GIBSON-Setup.exe`, how to install it on a Windows 10 or 11 PC, what happens the first time it starts (including the IPL), and how to use the Master Console, the dashboard, the Pen-Test Shell and PHOSPHOR once it is running.

---

## Contents

1. [What is GIBSON?](#1-what-is-gibson)
2. [The two ways GIBSON runs on Windows](#2-the-two-ways-gibson-runs-on-windows)
3. [What you need](#3-what-you-need)
4. [Downloading and checking GIBSON-Setup.exe](#4-downloading-and-checking-gibson-setupexe)
5. [Installing GIBSON](#5-installing-gibson)
6. [Starting GIBSON for the first time](#6-starting-gibson-for-the-first-time)
7. [IPLing the mainframe](#7-ipling-the-mainframe)
8. [The Master Console and the dashboard (port 8443)](#8-the-master-console-and-the-dashboard-port-8443)
9. [The Pen-Test Shell (port 8022)](#9-the-pen-test-shell-port-8022)
10. [A first look at PHOSPHOR](#10-a-first-look-at-phosphor)
11. [FTP and the USS shell](#11-ftp-and-the-uss-shell)
12. [The Start menu](#12-the-start-menu)
13. [Starting and stopping GIBSON day to day](#13-starting-and-stopping-gibson-day-to-day)
14. [Command-line use](#14-command-line-use)
15. [What is different in native Windows mode](#15-what-is-different-in-native-windows-mode)
16. [Default accounts, passwords and ports](#16-default-accounts-passwords-and-ports)
17. [Troubleshooting](#17-troubleshooting)
18. [Uninstalling](#18-uninstalling)
19. [Licences](#19-licences)

---

## 1. What is GIBSON?

GIBSON is a self-contained mainframe education and penetration-testing lab. At its heart is a simulated IBM z/OS-style mainframe that gives you a master console with a real IPL sequence, TSO and ISPF logons over TN3270, JES2 and SDSF, a RACF-style security database, an FTP server with JES and SQL modes, DASD volumes, DB2 and CICS-style services, a UNIX System Services (USS) shell, a banking application with its own API, an SMTP listener, a zSecure-style alerting feed and a web dashboard, all running on one PC that you control and are free to break.

`GIBSON-Setup.exe` also installs:

- **PHOSPHOR**, a TN3270 and TN5250 terminal emulator and mainframe audit toolkit, with its own Start menu entry.
- **The Pen-Test Shell**, a shell in your browser with the course tools on its path (`ezrecon`, `zniff`, `cicspwn`, `tshocker`, `injector`, `nje-assess`, `njejcl`, `gibson-scan`, PHOSPHOR and more), together with real tools such as `nmap`, `hydra`, `nikto` and John the Ripper with `racf2john`.

Everything in the lab is deliberately fictional. The Pen-Test Shell's sandbox only allows targets in the lab itself (`127.0.0.1`, `localhost`, `::1` and the fictional `sighberbank.com` domain and its subdomains), so you can practise freely without any risk of touching a real system.

> **GIBSON is vulnerable on purpose.** Its training profile contains weak passwords, over-permissive RACF profiles and other planted findings for you to discover. Run it on your own PC or a trusted lab network, and never expose its ports to the internet.

---

## 2. The two ways GIBSON runs on Windows

You do not have to choose between these, because setup checks your PC and decides for you, but it helps to know which one you have, because the first start is slightly different.

| | Full Linux mode (WSL 2) | Native Windows mode |
|---|---|---|
| What it is | The same GIBSON Linux system as the GIBSON ISO, running in WSL 2 and reached from Windows at `localhost` | GIBSON's own Windows build, running directly on Windows |
| When setup uses it | When the PC can run WSL 2 | When it cannot, or when you install with `/MODE=native` |
| Needs | Windows 10 22H2 or Windows 11, and virtualisation turned on | Any 64-bit Windows 10 (1809 or later) or Windows 11 |
| Restart during setup | Once, if WSL has never been used on the PC | Never |
| IPL | You answer the six IPL replies, as on a real mainframe | Done for you automatically |
| Pen-Test Shell tools | Every tool, with no limits | Every tool, with the small differences in [section 15](#15-what-is-different-in-native-windows-mode) |

Whichever you end up with, the same Start menu entries, web addresses and passwords work, and you can move from native mode to full Linux mode later with **Fix WSL for GIBSON**.

---

## 3. What you need

| Item | Requirement |
|---|---|
| Windows | 64-bit Windows 10 version 1809 or later, or Windows 11 (Windows 10 22H2 or Windows 11 for full Linux mode) |
| Account | An account that can approve administrator (UAC) prompts |
| Disk space | At least 8 GB free on the system drive, to be comfortable with the installer, the native build and the Linux system |
| Memory | 4 GB of RAM or more |
| Virtualisation | Only for full Linux mode: Intel VT-x or AMD-V turned on in the BIOS or UEFI settings |
| Internet | Only for the download; setup itself works offline, because everything it needs is inside the installer |

> **Windows in a virtual machine.** Native Windows mode works in any virtual machine. Full Linux mode inside a virtual machine needs nested virtualisation turned on by the host (in Hyper-V or VMware), and Microsoft does not support WSL 2 inside a VirtualBox virtual machine, so in VirtualBox GIBSON uses native Windows mode.

---

## 4. Downloading and checking GIBSON-Setup.exe

1. Open <https://github.com/kmilne40/GIBSON/releases> in your browser and choose the newest Windows release.
2. Under **Assets**, click `GIBSON-Setup.exe` to download it (it is a little under 1 GB), and also click `SHA256SUMS` to download the checksum list.
3. When the download has finished, check that it arrived intact, because a browser sometimes stops a large download early without saying so:
   1. Open your **Downloads** folder in File Explorer, click in the address bar at the top, type `powershell` and press **Enter**.
   2. In the PowerShell window, type the following and press **Enter**:

      ```powershell
      Get-FileHash .\GIBSON-Setup.exe -Algorithm SHA256
      ```

   3. After a minute or so it prints a long string of letters and numbers under **Hash**.
   4. Type `Get-Content .\SHA256SUMS` and press **Enter**, and check that the string on the `GIBSON-Setup.exe` line is the same as the one under **Hash** (upper and lower case do not matter).

If the two are different, delete `GIBSON-Setup.exe`, download it again and repeat the check.

> The `windows-tools.zip` file in the same release is not needed to install GIBSON. It is only for people who build `GIBSON-Setup.exe` themselves from the source kit.

---

## 5. Installing GIBSON

1. Double-click `GIBSON-Setup.exe` in your **Downloads** folder.
2. The installer is not code-signed, so Windows SmartScreen may show **Windows protected your PC**. Click **More info**, then click **Run anyway**.
3. In the **User Account Control** box that asks whether to allow the app to make changes, click **Yes**.
4. On the **License Agreement** page, read the GIBSON Community and Educational Licence, click **I accept the agreement**, and click **Next**.
5. On the **Select Destination Location** page, keep the suggested folder, `C:\Program Files\GIBSON`, and click **Next**.
6. On the **Select Additional Tasks** page, tick **Create a desktop shortcut** if you want one, and click **Next**.
7. The **Ready to Install** page shows the install folder and, under **GIBSON will run in:**, which mode setup has chosen for this PC:
   - `the full Linux system in WSL 2 (every Pen-Test Shell tool).`, followed by a note that Windows may restart once, or
   - `native Windows mode (...)`, with the reason in brackets, for example `virtualisation is turned off in the BIOS/UEFI` or `this is a virtual machine without nested virtualisation`, followed by a note that the full Linux toolset can be added later with **Fix WSL for GIBSON**.

   Make a note of which one it says, and click **Install**.
8. The **Installing** page shows the progress bar. In full Linux mode, it then shows **Setting up the full Linux toolset (WSL 2)...** and **Installing the GIBSON Linux system...**, which can take several minutes. Setup also adds a Windows Firewall rule for GIBSON and adds the `gibson` command to your PATH.
9. On the final page, **Completing the GIBSON Mainframe Simulator Setup Wizard**:
   - If no restart is needed, leave **Open GIBSON Mainframe Simulator now** ticked and click **Finish**. GIBSON starts and your browser opens on it.
   - If setup has just turned WSL on for the first time, the page asks to restart the computer. Choose **Yes, restart the computer now** and click **Finish**. When you sign in again, setup finishes installing the GIBSON Linux system by itself and then opens GIBSON in your browser, so give it a few minutes before opening anything.

### Installing for a classroom

To install on many PCs without any questions, run the installer from an administrator Command Prompt:

| Command | What it does |
|---|---|
| `GIBSON-Setup.exe /SILENT` | A full install with no questions, setting up full Linux mode wherever the PC can run it |
| `GIBSON-Setup.exe /SILENT /MODE=native` | Native Windows mode only, never touching WSL and never restarting |

---

## 6. Starting GIBSON for the first time

1. If GIBSON did not open by itself at the end of setup, click **Start**, type `GIBSON`, and click **GIBSON Mainframe Simulator** (or double-click its desktop shortcut).
2. GIBSON starts hidden in the background, which takes up to a minute or two, and then your browser opens on the Master Console at `http://localhost:8443/console`.
3. Your browser asks you to sign in. Type the following and click **Sign in**:

| Field | Value |
|---|---|
| Username | `admin` |
| Password | `gibsonadmin!` |

4. Look at the top of the Master Console to see which mode you are in:
   - If the header already says **IPL complete - system up**, you are in **native Windows mode**, GIBSON has done the IPL for you with the MFA PIN `0000`, and you can go straight to [section 8](#8-the-master-console-and-the-dashboard-port-8443).
   - If the log shows `R 01 IEA101A SPECIFY SYSTEM PARAMETERS FOR RELEASE z/OS 03.02.00` waiting for a reply, you are in **full Linux mode** and GIBSON is waiting for you to IPL it, so carry on with [section 7](#7-ipling-the-mainframe).

---

## 7. IPLing the mainframe

An IPL (initial program load) is how a z/OS system is started, and the operator answers a short series of numbered requests at the master console. In full Linux mode, GIBSON asks for them each time the GIBSON Linux system starts.

1. In the Master Console, click in the command box at the bottom of the page.
2. Type each reply below and press **Enter** after each one, waiting for the next request to appear in the log before you type the next reply:

| You type | GIBSON is asking | What the reply means |
|---|---|---|
| `R 01,CLPA` | `IEA101A SPECIFY SYSTEM PARAMETERS` | Build the link pack area afresh (a "cold" start of the system code) |
| `R 02,U` | `IEA347A REPLY U TO USE DEFAULT IEASYS00` | Use the default system parameters member, IEASYS00 |
| `R 03,Y` | `IEA102A REPLY Y TO CONTINUE GIBSON IPL` | Carry on with the IPL; JES2, RACF, OMVS and TCP/IP then start |
| `R 04,1234` | `R 04 DEFINE 4-DIGIT MFA PIN FOR THIS IPL` | Sets the operator MFA PIN; any four digits will do, and when MFA is on, the token is the PIN followed by the time as HHMM |
| `R 05,GIBSON` | `R 05 IEE600A REPLY 05 WITH SYSTEM HOSTNAME` | Names the system GIBSON |
| `R 06,1337` | `R 06 DEFINE 4-DIGIT DVCAPIN OR SKIP` | Sets the training PIN for the DVCA, CBSA and OMEN banking labs; type `R 06,SKIP` instead if you do not need it |

3. The row of buttons under the console's header (`R 01,CLPA`, `R 02,U`, `R 03,Y`, `R 05,GIBSON`, `R 06,SKIP` and others) types the common replies for you, but `R 04` has no button, because you choose the PIN.
4. When the header shows **IPL complete - system up** and the **SYSTEM PROCESSING** panel on the right shows `IPL COMPLETE`, the mainframe is ready.

> In native Windows mode, if GIBSON ever cannot do the IPL by itself, a message box says so and lists the replies to type, which are the same as above with `R 04,0000` and `R 06,SKIP`.

---

## 8. The Master Console and the dashboard (port 8443)

**The Master Console** at <http://localhost:8443/console> has an **OPERLOG / ALERT STREAM** on the left, which shows console messages and security alerts as they happen, a **SYSTEM PROCESSING** panel on the right, which should show JES2, VTAM, CICS, DB2, USS and NJE `ACTIVE` and TSO `READY`, and the command box at the bottom. Try these, pressing **Enter** after each:

| Command | What it shows |
|---|---|
| `D A,L` | The active address spaces (JES2, RACF, TCPIP, TN3270, FTPD, CICS, DB2 and the rest) |
| `D R,R` | Any outstanding operator requests |
| `D IPLINFO` | When and how the system was IPLed |
| `help` | Every console command |

**The dashboard** at <http://localhost:8443/> (or **Dashboard** in the menu at the top of the page) is the **I3M Gibson Mainframe Operations Dashboard**. It shows active and recent users, the number of RACF users and JES jobs, a recent audit log of SMF records, a system summary, a map of connections and the status of every service. Security alerts (zSecure-style messages such as `C2P1213A`) pop up in red at the top right, and you can close each one with its **x** button.

Both use the same sign-in, `admin` / `gibsonadmin!`.

---

## 9. The Pen-Test Shell (port 8022)

The Pen-Test Shell is a bash shell in your browser, with the course tools on its path and a sandbox that only lets them reach the lab. It works the same way in both modes, so the course's commands work as printed.

1. Click **Start**, type `GIBSON`, and click **GIBSON Pen-Test Shell**, or go to <http://localhost:8022/>, or click **Pen-Test Shell** in the dashboard's menu.
2. Sign in with the same login as the dashboard, `admin` / `gibsonadmin!`.
3. The shell shows a banner that lists the **AUTHORISED TARGETS ONLY** (`127.0.0.1`, the local GIBSON lab, and `sighberbank.com`, the educational FIBS bank), the wordlists in `./wordlists/`, and the course tools, and ends with a `gibson-pentest:~$` prompt.
4. Try these commands, pressing **Enter** after each:

| Command | What it does |
|---|---|
| `scope` | Shows the targets the sandbox allows |
| `tools` | Lists every tool in the shell, with an example for each |
| `tool-check` | Checks that every course tool is ready, and says how to fix any that is not |
| `gibson-scan 127.0.0.1 -sV` | Scans the lab with GIBSON's built-in scanner |
| `nmap -sV 127.0.0.1` | Scans the lab with the real nmap |
| `phosphor 127.0.0.1 --client` | Opens PHOSPHOR's 3270 terminal inside the shell |

Any target that is not in the allowlist is refused by the sandbox, so `nmap 8.8.8.8`, for example, is blocked.

---

## 10. A first look at PHOSPHOR

PHOSPHOR is installed with GIBSON and has its own Start menu entry, which opens its desktop app already connected to GIBSON's TN3270 port.

1. Make sure GIBSON is running (the Master Console answers in your browser).
2. Click **Start**, type `PHOSPHOR`, and click **PHOSPHOR**.
3. PHOSPHOR opens on the GIBSON PRODUCTION LPAR logon screen, with the warning banner, your LU name and client address, and the line `LOGON using L TSO, L CICS, L DB2, L IMS, L ZVM or L TPF.` with the cursor at `Logon Type:`. Type `L TSO` and press **Enter**.
4. The **TSO/E LOGON** panel appears with the cursor in the `Userid ===>` field. Type `IBMUSER`, press **Tab** to move to the `Password ===>` field, type `SYS1`, and press **Enter**.
5. GIBSON shows `ICH70001I IBMUSER LAST ACCESS AT ...`, the GIBSON z/OS SECURITY TRAINING SYSTEM banner and `READY`. You are now at the TSO prompt.
6. Type `LISTCAT` and press **Enter** to list IBMUSER's datasets (`IBMUSER.JCL.LAB`, `IBMUSER.REXX.LAB`, `IBMUSER.MAIL.IN` and others). Press **F8** to page down and **F7** to page up.
7. Type `LOGOFF` and press **Enter** to log off, which returns you to the logon screen, and close the PHOSPHOR window when you have finished.

Notice that the Master Console's alert stream logs your logon as it happens, with messages such as `*TSO LOGON ALERT: IBMUSER signed on to TSO from 127.0.0.1`, which is the defender's view of what you have just done.

### PHOSPHOR in the Pen-Test Shell

You can do the same logon in the browser: in the Pen-Test Shell, type `phosphor 127.0.0.1 --client` and press **Enter**, follow steps 3 to 6 above, then type `LOGOFF` and press **Enter**, and type `:q` and press **Enter** to leave PHOSPHOR. While it runs, the line at the bottom of the screen reminds you of the keys: **Tab** moves between fields, **Enter** sends the screen, **Ctrl+K** opens an on-screen keypad (for PA1, PA2, Clear and the rest), and **:** opens PHOSPHOR's own command line.

PHOSPHOR's recon modes (`phosphor 127.0.0.1 --scan --yes` and `phosphor 127.0.0.1 --menu --yes`) need the unlock code from the *Hacking Mainframes* book, given once with `--unlock CODE`.

Any other TN3270 emulator, such as wc3270, also works: point it at `localhost` port `23`.

---

## 11. FTP and the USS shell

**FTP (port 21).** Press **Windows+R**, type `cmd` and press **Enter**, then type `ftp localhost` and press **Enter**. GIBSON answers with `220-GIBSON IBM FTP CS V3R2 at GIBSON`. Type `IBMUSER` as the user and `SYS1` as the password, type `dir` and press **Enter** to list datasets, and type `bye` and press **Enter** to leave. You can also type `ftp 127.0.0.1` in the Pen-Test Shell.

**USS shell (port 2022).** In the Pen-Test Shell, type `telnet 127.0.0.1 2022` and press **Enter**. At `login:` type `IBMUSER`, at `Password:` type `SYS1`, and you arrive at an `IBMUSER:/u/ibmuser$` prompt in GIBSON's z/OS UNIX System Services. Type `exit` and press **Enter** to leave.

---

## 12. The Start menu

Click **Start** and type `GIBSON` to find these entries, which all live in the **GIBSON** folder of the Start menu:

| Entry | What it does |
|---|---|
| **GIBSON Mainframe Simulator** | Starts GIBSON if it is not already running and opens the Master Console; uses full Linux mode when it is healthy and native mode otherwise, deciding for itself |
| **GIBSON Dashboard** | The same, opening the dashboard |
| **GIBSON Pen-Test Shell** | The same, opening the Pen-Test Shell |
| **GIBSON Welcome page** | The same, opening the welcome page |
| **PHOSPHOR** | Opens the PHOSPHOR desktop app connected to GIBSON |
| **Stop GIBSON** | Stops GIBSON, whichever mode it is in, and shows **GIBSON has stopped.** |
| **Fix WSL for GIBSON** | Turns on or repairs full Linux mode (WSL 2), or says what to change in the BIOS or on a virtual machine's host if it cannot |
| **GIBSON diagnostics** | Collects a report of why GIBSON will not start (about two minutes) and opens it in Notepad |
| **Full Linux toolset** ▸ **GIBSON Linux terminal** | A Linux shell on the GIBSON system, as the user `student`, when full Linux mode is installed |
| **Native Windows** ▸ **GIBSON (native)** | Starts the native build explicitly |
| **Native Windows** ▸ **GIBSON - Secure profile** | Starts the native build in the hardened, CIS-aligned profile |
| **Native Windows** ▸ **GIBSON - Diagnose** | Loads GIBSON's state and prints diagnostics |
| **Uninstall GIBSON** | Removes GIBSON |

---

## 13. Starting and stopping GIBSON day to day

**In full Linux mode**, GIBSON starts by itself, hidden, whenever you sign in to Windows, so it is usually ready a minute or so after you sign in. Each time the GIBSON Linux system starts, the mainframe waits for the IPL replies in [section 7](#7-ipling-the-mainframe).

**In native Windows mode**, GIBSON starts when you open **GIBSON Mainframe Simulator** from the Start menu, does its IPL by itself, and runs in the background with no window to keep open until you choose **Stop GIBSON** or sign out.

In either mode:

- To open GIBSON, click **GIBSON Mainframe Simulator**. If GIBSON is already running, it just opens the Master Console.
- To stop GIBSON, click **Stop GIBSON**.
- If GIBSON ever stops as it starts, a message box says so and shows the last lines of its output.

---

## 14. Command-line use

Setup puts the `gibson` command on your PATH, so GIBSON's host commands work in any **new** Command Prompt or PowerShell window, for example:

```text
gibson --list-volumes
gibson --help
```

In full Linux mode these run inside the GIBSON Linux system against the same lab that the running GIBSON uses, and in native Windows mode they run the native build against its lab in `%USERPROFILE%\mfsim`. Starting and stopping GIBSON itself is done from the Start menu, not with `gibson`.

In full Linux mode, open **GIBSON Linux terminal** from the Start menu (or type `wsl -d GIBSON` in a Command Prompt) for a shell on the GIBSON system, where you are the user `student` with passwordless `sudo`. There:

```bash
sudo systemctl status gibson      # is GIBSON running?
sudo systemctl restart gibson     # restart it (it will need a new IPL)
journalctl -u gibson -f           # follow its log (press Ctrl+C to stop)
```

---

## 15. What is different in native Windows mode

In native Windows mode the Pen-Test Shell is still a bash shell, and GIBSON carries its own tools for it: nmap, hydra, jumbo John the Ripper with racf2john, nikto, wget, curl, netcat (`nc`), telnet, ftp, whois, ping, dig and host, the x3270 suite's `s3270` and `c3270`, Python 3.12 with pip and every course tool. Every network tool still goes through the scope guard.

`python3`, `python` and `pip` in the shell are GIBSON's own Python 3.12, which already has every package the course tools use, so a course script that you run yourself needs no `pip install`.

One thing is different, because its licence does not allow it to be bundled: **Npcap**, the packet driver that nmap and zniff use on Windows. Without it, **nmap** scans with TCP connects (version detection with `-sV` and the NSE scripts work as usual, and `-sS` runs as `-sT`, which nmap tells you), and **zniff** can read capture files but cannot watch live traffic.

In native Windows mode, nmap in the Pen-Test Shell can stop with `dnet: Failed to open device lo0` or `Couldn't open a raw socket or eth handle`. If it does, add `--unprivileged -sT` to the command, for example `nmap --unprivileged -sT -sV -p 21,23 127.0.0.1`, which makes nmap use ordinary TCP connections. Full Linux mode does not have this problem, so if your PC can run WSL 2, **Fix WSL for GIBSON** is the better cure.

To add Npcap, press **Windows+R**, type `cmd` and press **Enter**, then type `%USERPROFILE%\mfsim\pentest\bin\toolbox-setup.cmd` and press **Enter**. It offers to install Npcap from its maker with winget. Afterwards, click **Stop GIBSON** in the Start menu and then open **GIBSON Mainframe Simulator** again.

Full Linux mode has none of these limits.

---

## 16. Default accounts, passwords and ports

These are lab accounts for a fictional system, published so that everyone starts from the same place.

| Where | Username | Password |
|---|---|---|
| Master Console and dashboard, <http://localhost:8443/> | `admin` | `gibsonadmin!` |
| Pen-Test Shell, <http://localhost:8022/> | `admin` | `gibsonadmin!` |
| TSO (port 23), FTP (port 21) and USS (port 2022) | `IBMUSER` | `SYS1` |
| IPL MFA PIN | native mode: `0000` (set for you) | full Linux mode: the four digits you typed at `R 04` |
| GIBSON Linux terminal (full Linux mode) | `student` | none needed (passwordless `sudo`) |

| Port | Service |
|---|---|
| 21 | FTP, dataset-aware (IBM FTP CS) |
| 23 | TN3270: VTAM logon screen, TSO, CICS and the rest |
| 80 | Welcome to Gibson page (8000 if Windows already uses port 80) |
| 175 | NJE (network job entry) |
| 446 | DB2 DRDA |
| 2022 | USS terminal |
| 2252 | NJE over TLS |
| 2525 | SMTP listener (receives mail, never relays) |
| 3270 | A second TN3270 listener (native Windows mode only) |
| 8022 | Pen-Test Shell (this PC only) |
| 8080 | CBSA, DVCA and hack3270 banking application server |
| 8443 | Master Console and dashboard (HTTP) |
| 9080 | FIBS Bank, the First International Bank of Scotland web application |
| 50001 | DB2 web service |

---

## 17. Troubleshooting

| What you see | What to do |
|---|---|
| You wanted full Linux mode but got native Windows mode | The PC cannot run WSL 2 yet. Open **Fix WSL for GIBSON** from the Start menu and click **Yes** on the administrator prompt. It turns on what WSL needs, or tells you what to change in the BIOS or on a virtual machine's host. After any restart it asks for, run **Fix WSL for GIBSON** once more, and GIBSON picks up full Linux mode by itself. |
| GIBSON opened in native mode although full Linux mode was working before | The Linux system did not start this time, and a message said **Starting GIBSON in Windows mode**. Run **Fix WSL for GIBSON**; nothing is lost, and native mode keeps working meanwhile. |
| `WSL_E_DISTRO_NOT_FOUND` | WSL is on the PC but the GIBSON Linux system did not finish installing. Run **Fix WSL for GIBSON**, then run `GIBSON-Setup.exe` again. |
| Nothing happens after the restart during setup | Open **GIBSON Mainframe Simulator** from the Start menu, and it starts whichever mode is ready. |
| The browser says the page cannot be reached | GIBSON can take a minute or two to start. Wait, then refresh the page or open **GIBSON Mainframe Simulator** again. |
| The Master Console keeps asking for the IPL replies | You are in full Linux mode and the Linux system has restarted. Type the six replies in [section 7](#7-ipling-the-mainframe) again. |
| The welcome page is not at `http://localhost/` | Another program has port 80, so GIBSON put the page on `http://localhost:8000/` instead. The **GIBSON Welcome page** entry opens it in the right place. |
| nmap says `dnet: Failed to open device lo0` or that it cannot open a raw socket | This happens in native Windows mode. Add `--unprivileged -sT` to the command, for example `nmap --unprivileged -sT -sV -p 21,23 127.0.0.1`, or switch to full Linux mode with **Fix WSL for GIBSON**, which does not have the problem. Running the shell as administrator does not help, because GIBSON deliberately runs as the signed-in user. |
| A course tool does not work | Type `tool-check` in the Pen-Test Shell, which names anything missing and how to fix it. |
| GIBSON does not start at all | Open **GIBSON diagnostics** from the Start menu and wait about two minutes. It opens `GIBSON-diagnostics.txt` in your user folder, which you can send with your question. |

### Log files

Setup and GIBSON write what they do to these files, which are worth including when you report a problem:

- `%ProgramData%\GIBSON\gibson-wsl.log` and `fix-wsl.log`, from setup's checks and **Fix WSL for GIBSON**.
- `%LOCALAPPDATA%\GIBSON\gibson-launch.log`, `gibson-wsl.log` and `gibson-native.log`, from starting GIBSON.
- `%LOCALAPPDATA%\GIBSON\gibson-ipl.log` and `gibson-server.log`, the native build's own output.

To open the second folder, press **Windows+R**, type `%LOCALAPPDATA%\GIBSON` and press **Enter**.

---

## 18. Uninstalling

1. Click **Start**, click **Settings**, click **Apps** and then **Installed apps**.
2. Find **GIBSON Mainframe Simulator**, click the **...** button beside it, click **Uninstall**, and click **Uninstall** again to confirm. On Windows 10, the page is called **Apps & features**, and you click **GIBSON Mainframe Simulator** and then **Uninstall**.

You can also click **Uninstall GIBSON** in the Start menu's **GIBSON** folder.

This stops GIBSON and removes it, its firewall rule, its PATH entry and the GIBSON Linux system with the lab inside it. If you also used native Windows mode, its lab in `%USERPROFILE%\mfsim` is left in place for you to delete. WSL itself stays installed, because other software may use it.

---

## 19. Licences

GIBSON is released under the GIBSON Community and Educational Licence, version 1.0, for personal learning, community education, academic teaching and non-commercial research. Commercial rights are reserved. See `LICENSE.md` for the full terms.

The tools bundled for the Pen-Test Shell are separate programs under their own licences, which are not GIBSON's. Each licence, with a list of the tools, their versions and where their source code is, is in `C:\Program Files\GIBSON\native\tools\licenses`, with `NOTICES.txt` beside it.

Copyright © 2022 to 2026 Kev Milne. Published by Neuro Training Ltd / [OffensiveSec.org](https://offensivesec.org).
