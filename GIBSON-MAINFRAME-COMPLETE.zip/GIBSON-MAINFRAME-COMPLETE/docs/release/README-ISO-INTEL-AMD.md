# Installing the GIBSON Mainframe Lab ISO (Intel and AMD, amd64)

This guide explains what GIBSON is, how to download the Intel and AMD (amd64) version of the GIBSON lab ISO, how to build a VirtualBox virtual machine for it, what you will see when the ISO starts up, and how to install GIBSON permanently onto the virtual machine's disk so that your work survives a reboot.

> **Which ISO is this?** This guide covers `GIBSON-live-amd64.iso`, which runs on any 64-bit Intel or AMD processor. If you are on an Apple Silicon Mac (M1, M2, M3 or later) or another ARM computer, you need the arm64 ISO instead, because the amd64 ISO will not boot there.

---

## Contents

1. [What is GIBSON?](#1-what-is-gibson)
2. [What you need](#2-what-you-need)
3. [Downloading the ISO](#3-downloading-the-iso)
4. [Installing VirtualBox](#4-installing-virtualbox)
5. [Creating the virtual machine](#5-creating-the-virtual-machine)
6. [Starting the ISO for the first time](#6-starting-the-iso-for-the-first-time)
7. [Trying GIBSON in the live session](#7-trying-gibson-in-the-live-session)
8. [Installing GIBSON to the virtual machine's disk](#8-installing-gibson-to-the-virtual-machines-disk)
9. [After the installation](#9-after-the-installation)
10. [Optional: reaching GIBSON from your own computer](#10-optional-reaching-gibson-from-your-own-computer)
11. [Troubleshooting](#11-troubleshooting)
12. [Default accounts and ports](#12-default-accounts-and-ports)

---

## 1. What is GIBSON?

GIBSON is a self-contained mainframe education and penetration-testing lab. At its heart is a simulated IBM z/OS-style mainframe, written in Python, that gives you a master console with a real IPL sequence, TSO logons over TN3270, an FTP server that understands datasets, a UNIX System Services shell, a RACF-style security database, a CICS-style banking application with its own API, an SMTP listener and a web dashboard, all running on a single machine that you control and are free to break.

The ISO packages all of this into a ready-made Ubuntu 24.04 desktop (XFCE) with GIBSON preinstalled, together with the PHOSPHOR 3270 terminal emulator, the `c3270` and `s3270` clients, and a set of tools for practising mainframe assessment, including `nmap` (with mainframe scripts), `hydra`, `nikto`, `john` (with `racf2john`), `git` and Python 3.

Everything in the lab is deliberately fictional, and the penetration-testing tools on the ISO are scoped so that they only work against the lab itself (`127.0.0.1`, `localhost`, `::1` and the fictional `sighberbank.com` domain), which means you can practise freely without any risk of touching a real system.

---

## 2. What you need

| Item | Requirement |
|---|---|
| Computer | A 64-bit Intel or AMD computer running Windows, macOS (Intel) or Linux |
| Virtualisation | Intel VT-x or AMD-V **enabled** in your computer's BIOS or UEFI settings |
| Free memory | At least 2 GB that you can give to the virtual machine (4 GB is better) |
| Free disk space | At least 30 GB: 25 GB for the virtual disk plus room for the ISO download |
| Software | Oracle VirtualBox 7.x (VMware Workstation and others also work, but this guide uses VirtualBox) |

> **Minimum virtual machine settings (required).** The GIBSON virtual machine **must** have at least **2 GB (2048 MB) of RAM**, a virtual hard disk of at least **25 GB**, and its network adapter **attached to NAT**. Smaller machines may boot the live session, but the installer and GIBSON's services will not run reliably on them.

---

## 3. Downloading the ISO

1. Open the GIBSON releases page at <https://github.com/kmilne40/GIBSON/releases> and choose the newest release.
2. Under **Assets**, click `GIBSON-live-amd64.iso` to download the complete ISO, and also click `GIBSON-live-amd64.iso.sha256` to download its checksum file. Save both into the same folder, for example your Downloads folder.
3. When the download has finished, it is worth checking that the ISO arrived intact before you use it, because a browser sometimes stops a large download early without saying so. Use the steps for your operating system below.

### Windows

1. Open the folder that holds the downloads in File Explorer, click in the address bar, type `powershell` and press **Enter**.
2. In the PowerShell window, type `Get-FileHash .\GIBSON-live-amd64.iso -Algorithm SHA256` and press **Enter**. The check takes a minute or so, and then prints a long string of letters and numbers under **Hash**.
3. Type `Get-Content .\GIBSON-live-amd64.iso.sha256` and press **Enter** to print the published checksum, and check that the two strings are the same (upper and lower case do not matter).

### macOS (Intel)

Open **Terminal** (in **Applications** ▸ **Utilities**), type `cd ~/Downloads` and press **Enter**, then type the following and press **Enter**:

```bash
shasum -a 256 -c GIBSON-live-amd64.iso.sha256
```

### Linux

Open a terminal in the folder that holds the downloads, type the following and press **Enter**:

```bash
sha256sum -c GIBSON-live-amd64.iso.sha256
```

On macOS and Linux, the command should print `GIBSON-live-amd64.iso: OK`.

> If the two checksums are different, or the command reports **FAILED**, the ISO did not download completely, so delete it, download it again and repeat the check.

---

## 4. Installing VirtualBox

VirtualBox is free and is published by Oracle, and because the installer and its steps change from version to version, please take them from VirtualBox's own sources rather than from this guide:

- **Download VirtualBox** for your operating system from the official downloads page: <https://www.virtualbox.org/wiki/Downloads>
- **Installation instructions** are in the official VirtualBox User Guide, in the chapter on installation details: <https://docs.oracle.com/en/virtualization/virtualbox/7.2/user/>
- **Help with problems** is available in the VirtualBox forums at <https://forums.virtualbox.org/>

While you are on the downloads page, it is also worth downloading the **VirtualBox Extension Pack** for the same version, although GIBSON does not need it.

> **Turn on hardware virtualisation first.** If VirtualBox later reports that VT-x or AMD-V is not available, restart your computer, enter its BIOS or UEFI setup (the key is usually **F2**, **F10**, **F12** or **Delete** during start-up, and your computer maker's documentation will say which), and enable the setting called *Intel Virtualization Technology*, *VT-x*, *AMD-V* or *SVM Mode*. On Windows, Hyper-V and the "Virtual Machine Platform" feature can also slow VirtualBox down, and the VirtualBox User Guide explains how they interact.

---

## 5. Creating the virtual machine

These steps were written against VirtualBox 7.2, and earlier 7.x versions look very similar.

1. Start **Oracle VirtualBox** and click **New** in the toolbar (or press **Ctrl+N**, or **Cmd+N** on a Mac).
2. On the **Virtual machine Name and Operating System** page:
   - In **VM Name**, type `GIBSON`.
   - In **VM Folder**, leave the default unless you want the machine stored on another drive.
   - Click the **ISO Image** box, choose **Other...**, find the `GIBSON-live-amd64.iso` file that you downloaded in section 3, and click **Open**.
   - VirtualBox detects the ISO as **Linux** and **Ubuntu (64-bit)**, which is correct.
   - The **Proceed with Unattended Installation** box is greyed out, which is also correct, because GIBSON has its own installer.
   - Click **Next**.
3. On the **Specify virtual hardware** page:
   - Set **Base Memory** to at least **2048 MB**. If your computer has 8 GB or more of RAM, **4096 MB** gives a noticeably smoother desktop.
   - Set **Number of CPUs** to **2** if you can spare them (1 works, but more slowly).
   - Leave **Use EFI** unticked. GIBSON boots either way, but the steps in this guide assume it is off.
   - Click **Next**.
4. On the **Specify virtual hard disk** page:
   - Leave **Create a Virtual Hard Disk Now** selected.
   - Set the size to at least **25.00 GB**. The disk grows as it fills, so it will not take 25 GB from your computer straight away.
   - Leave **Pre-allocate Full Size** unticked.
   - Click **Next**.
5. Check the **Summary** page and click **Finish**.

### Check the network and display settings

1. With **GIBSON** selected in the left-hand list, click **Settings** (or press **Ctrl+S**, or **Cmd+S** on a Mac).
2. Click **Network**. On the **Adapter 1** tab, make sure **Enable Network Adapter** is ticked and that **Attached to** is set to **NAT**. NAT is the VirtualBox default and is **required** for GIBSON, because it gives the lab internet access for updates while keeping it out of sight of the rest of your network.
3. Click **Display**. Make sure **Graphics Controller** is **VMSVGA**, raise **Video Memory** to **128 MB** (this lets the desktop use larger screen sizes), and leave **Enable 3D Acceleration** unticked. If the Video Memory slider is not shown, click **Expert** at the top of the Settings window to show every option.
4. Click **OK**.

---

## 6. Starting the ISO for the first time

1. Select **GIBSON** in the list and click **Start**.
2. A new window opens with the GIBSON boot menu. It waits **5 seconds** and then starts the first entry automatically. You can use the **Up** and **Down** arrow keys to choose another entry and press **Enter** to start it.

| Boot menu entry | When to use it |
|---|---|
| **GIBSON mainframe lab (live)** | The default. Starts GIBSON straight from the ISO so you can try it without changing the disk. |
| **Install GIBSON to this computer's disk** | Starts the live session and opens the installer automatically (see section 8). |
| **GIBSON mainframe lab (basic display: VirtualBox or VMware without the SVGA driver)** | Use this if the screen is black, garbled or stuck at a very small size. |
| **GIBSON mainframe lab (safe graphics: use if the screen stays black)** | A further fallback if the basic display entry also gives a black screen. |
| **GIBSON mainframe lab (text mode: no desktop, GIBSON still runs)** | No desktop at all, but every GIBSON service still starts. |
| **GIBSON mainframe lab (keep changes on this USB stick)** | For a USB stick only. Not needed in a virtual machine. |
| **GIBSON mainframe lab (copy into memory, then the USB or DVD can be removed)** | Copies the whole system into RAM. Needs plenty of memory. |
| **Troubleshooting: show every boot message** | Shows the full start-up log instead of the splash screen. |
| **Troubleshooting: check this USB stick or DVD for errors** | Checks the ISO for damage. |

3. After about a minute, the XFCE desktop appears and you are signed in automatically as the user **student**. In the live session, this account has no password.

> **Keyboard and mouse.** When you click inside the virtual machine window, VirtualBox may capture your mouse and keyboard. To release them, press the **Host key**, which is the **right Ctrl** key on Windows and Linux and the **left Cmd** key on a Mac, and is shown in the bottom-right corner of the virtual machine window.

---

## 7. Trying GIBSON in the live session

The live session runs entirely from the ISO, so anything you change is lost when you shut the virtual machine down. It is a good way to check that everything works before you install.

1. When the desktop appears, the web browser opens the GIBSON Master Console at `http://localhost:8443/console`.
2. When the browser asks you to sign in, type `admin` in **Username**, type `gibsonadmin!` in **Password**, and click **Sign in**.
3. The console shows the mainframe's IPL (initial program load) waiting for replies. See [Bringing the mainframe up (IPL)](#bringing-the-mainframe-up-ipl) in section 9 for what to type.

If you are happy that the lab runs, continue to section 8 to install it.

---

## 8. Installing GIBSON to the virtual machine's disk

Installing copies GIBSON onto the 25 GB virtual disk that you created, so that it starts from the disk every time, keeps your work, and no longer needs the ISO.

### Start the installer

Use whichever of these suits you:

- **From the live desktop:** click **Applications** in the top-left corner of the screen, point to **System**, and click **Install GIBSON**. (The same menu also lists **Install System**, which is the generic installer underneath, but **Install GIBSON** is the one to use.)
- **From the boot menu:** restart the virtual machine and choose **Install GIBSON to this computer's disk**, which opens the installer as soon as the desktop appears.

### Work through the installer

The installer (Calamares) opens with a list of steps down its left-hand side. Click **Next** at the bottom right to move through each one.

1. **Welcome.** Choose your language (for example **British English** or **American English**) and click **Next**.
2. **Location.** Click your region on the map, or choose **Region** and **Zone** from the lists (for example **Europe** and **London**), and click **Next**.
3. **Keyboard.** Choose the keyboard that matches yours (for example **English (UK)** or **English (US)**). You can type in the test box at the bottom of the page to check that keys such as **@**, **"** and **#** come out correctly. Click **Next**.
4. **Partitions.** Make sure **Select storage device** shows the VirtualBox disk (**VBOX HARDDISK**, about 25 GB). Choose **Erase disk**, leave the boot loader location as the master boot record of that disk, and click **Next**. This only erases the empty virtual disk inside the virtual machine, and nothing on your real computer is touched.
5. **Users.** Fill in the form, for example:
   - **What is your name?** `GIBSON Student`
   - **What name do you want to use to log in?** `student`
   - **What is the name of this computer?** `gibson`
   - **Choose a password to keep your account safe.** Type a password in both boxes. A password is required here, even though the live session did not need one, and you will need it if the screen locks.
   - Leave **Log in automatically without asking for the password** ticked if you want the lab to go straight to the desktop each time.
   - Click **Next**.
6. **Summary.** Check the choices and click **Install**.
7. In the box that asks whether you want to continue, click **Install Now**.
8. Wait while the installer copies the system. This usually takes about **7 minutes**, and the bar at the bottom shows progress.
9. When the page shows **All done.**, tick **Restart now** and click **Done**.
10. The virtual machine shows **Please remove the installation medium, then press ENTER**. GIBSON ejects the ISO from the virtual drive for you, so you only need to click inside the virtual machine window and press **Enter**.

If the machine starts the ISO's boot menu again instead of the installed system, shut it down, open **Settings** ▸ **Storage**, select the ISO under the optical drive, click the disc icon on the right, choose **Remove Disk from Virtual Drive**, click **OK**, and start the machine again.

---

## 9. After the installation

The installed system starts from the virtual disk, signs in as **student** (automatically, if you left that ticked), and starts GIBSON in the background as a system service.

The desktop has these icons:

| Icon | What it does |
|---|---|
| **Master Console** | Opens the GIBSON Master Console in the browser (sign in as `admin` / `gibsonadmin!`). |
| **Pen-Test Shell** | Opens the scoped penetration-testing shell. |
| **GIBSON Welcome** | Opens the welcome page with links to every service. |
| **3270** | Opens a 3270 terminal connected to the mainframe. |
| **PHOSPHOR** | Opens the PHOSPHOR 3270 emulator. |
| **Terminal** | Opens a Linux terminal (you can also press **Ctrl+Alt+T**). |
| **README-GIBSON.txt** | A short reference card for the lab. |

### Bringing the mainframe up (IPL)

Each time GIBSON starts, the mainframe performs an IPL and waits for operator replies, just as a real z/OS system does.

1. Double-click **Master Console** on the desktop and sign in with `admin` and `gibsonadmin!`.
2. Click in the **Reply or command** box at the bottom of the console. Type each reply below and press **Enter** after each one, waiting for the next message to appear before typing the next reply:

   ```text
   r 01,clpa
   r 02,u
   r 03,y
   r 04,1234
   r 05,GIBSON
   r 06,1337
   ```

   Reply `04` is the operator MFA PIN, and for reply `06` you can type `r 06,SKIP` instead of the PIN if you prefer.

3. When the console shows **IPL complete - system up**, the mainframe is ready. You can type `d iplinfo`, `d t` or `d a,l` in the same box to display IPL details, the time and the active jobs, or type `help` to list every command.

### Logging on to TSO

1. Double-click **Terminal** on the desktop (or press **Ctrl+Alt+T**).
2. Type `phosphor 127.0.0.1 23 --client` and press **Enter**. The VTAM logon screen appears.
3. Type `L TSO` and press **Enter**.
4. At the logon panel, type `IBMUSER` in the user ID field, press **Tab** to move to the password field, type `SYS1`, and press **Enter**.
5. When you see `READY`, you are at the TSO prompt and can type TSO commands.
6. To finish, type `LOGOFF` and press **Enter**, and then type `:q` and press **Enter** to close PHOSPHOR.

If you prefer a windowed emulator, type `phosphor --gui` instead, or double-click the **PHOSPHOR** or **3270** icon.

### Using FTP

In a terminal, type `ftp 127.0.0.1` and press **Enter**, then sign in with the name `IBMUSER` and the password `SYS1`. Type `bye` and press **Enter** to leave.

### Managing the GIBSON service

GIBSON runs as the system service `gibson.service`. The **student** account can use `sudo` without typing a password, so in a terminal you can type any of the following and press **Enter**:

```bash
sudo systemctl status gibson      # is it running?
sudo systemctl restart gibson     # restart the mainframe (it will need a new IPL)
journalctl -u gibson -f           # follow its log (press Ctrl+C to stop)
```

GIBSON's program files are in `/opt/gibson`, its data is in `/var/lib/gibson/mfsim`, and its start-up settings are in `/etc/default/gibson`.

### Checking that every service is listening

In a terminal, type `nmap localhost` and press **Enter**. You should see the ports listed in section 12.

### Installing extra tools

The virtual machine reaches the internet through NAT, so you can add Ubuntu packages in the normal way, for example:

```bash
sudo apt update
sudo apt install ncat tcpdump htop
```

### Shutting down

Click **Applications** in the top-left corner, click **Log Out**, and then click **Shut Down** in the box that appears, or type `sudo poweroff` in a terminal and press **Enter**. Closing the virtual machine window and choosing **Power off the machine** is the equivalent of pulling the plug, so it is best kept for when the system has stopped responding.

---

## 10. Optional: reaching GIBSON from your own computer

With NAT networking, the virtual machine can reach the internet but your own computer cannot reach the virtual machine directly. If you want to use a browser or a 3270 emulator on your own computer, add port forwarding rules in VirtualBox:

1. Shut the virtual machine down.
2. Select **GIBSON**, click **Settings**, and click **Network**. (Click **Expert** at the top of the window if the advanced options are hidden.)
3. On **Adapter 1**, which must still be **Attached to: NAT**, expand **Advanced** and click **Port Forwarding**.
4. Click the green **+** icon on the right to add each rule, filling in **Host IP** as `127.0.0.1`, **Host Port**, and **Guest Port**, for example:

| Name | Protocol | Host IP | Host Port | Guest Port | Use |
|---|---|---|---|---|---|
| console | TCP | 127.0.0.1 | 8443 | 8443 | Master Console and dashboard in your own browser |
| tn3270 | TCP | 127.0.0.1 | 3270 | 23 | A 3270 emulator on your own computer, pointed at `127.0.0.1` port `3270` |
| fibs | TCP | 127.0.0.1 | 9080 | 9080 | The FIBS banking application |

5. Click **OK**, click **OK** again, and start the virtual machine.

Setting **Host IP** to `127.0.0.1` keeps the forwarded ports visible only to your own computer and not to the rest of your network. The Pen-Test Shell (port 8022) only listens inside the virtual machine, so it cannot be forwarded.

---

## 11. Troubleshooting

**VirtualBox says VT-x or AMD-V is not available, or the machine is extremely slow.**
Enable hardware virtualisation in your computer's BIOS or UEFI settings, as described in section 4, and see the VirtualBox User Guide for details on Hyper-V.

**The screen stays black after the boot menu.**
Restart the virtual machine (**Machine** ▸ **Reset**, or **Host+R**), and choose **GIBSON mainframe lab (basic display: VirtualBox or VMware without the SVGA driver)** in the boot menu. If that is also black, choose **GIBSON mainframe lab (safe graphics: use if the screen stays black)**. GIBSON also switches to a safe display by itself if the desktop fails to start.

**The desktop is stuck at 800x600 and will not go larger.**
Shut the virtual machine down, open **Settings** ▸ **Display**, make sure **Graphics Controller** is **VMSVGA** and **Video Memory** is **128 MB**, and start it again. Then click **Applications** ▸ **Settings** ▸ **Display** inside GIBSON, choose a **Resolution** such as **1024x768** or **1280x800**, click **Apply**, and click **Keep this configuration**.

**The keyboard types the wrong symbols (for example `"` and `@` are swapped).**
The keyboard layout inside GIBSON does not match yours. Click **Applications** ▸ **Settings** ▸ **Keyboard**, open the **Layout** tab, untick **Use system defaults**, click **Add**, choose your layout, and move it to the top of the list.

**`john` says `open: /opt/john/run/john.log: Permission denied`.**
This is a known problem in the current ISO, and it is fixed for the next release. Until then, run John the Ripper with `sudo`, for example `sudo john hashes.txt` and then `sudo john --show hashes.txt`.

**The ISO fails its checksum.**
Download `GIBSON-live-amd64.iso` again and repeat the check in section 3, because the first download did not complete.

**The virtual machine will not start on an Apple Silicon Mac.**
The amd64 ISO only runs on Intel and AMD processors. Use the arm64 ISO and its guide instead.

---

## 12. Default accounts and ports

These are lab accounts for a fictional system, and they are published so that everyone starts from the same place.

| What | Name | Password |
|---|---|---|
| Linux desktop (live session) | `student` | none |
| Linux desktop (installed system) | `student` | the password you chose in the installer |
| Master Console and dashboard | `admin` | `gibsonadmin!` |
| TSO and FTP | `IBMUSER` | `SYS1` |

| Port | Service |
|---|---|
| 21 | FTP (dataset-aware) |
| 23 | TN3270 (VTAM and TSO) |
| 80 | Welcome page |
| 2022 | UNIX System Services shell |
| 2525 | SMTP listener (receives only, never relays) |
| 8022 | Pen-Test Shell (inside the virtual machine only) |
| 8080 | CBSA banking API |
| 8443 | Master Console and dashboard |
| 9080 | FIBS banking application |
