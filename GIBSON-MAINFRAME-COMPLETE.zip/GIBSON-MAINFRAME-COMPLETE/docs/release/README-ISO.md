# GIBSON Mainframe Simulator: Live ISO

GIBSON is a deliberately vulnerable z/OS training simulator. It gives you TSO, ISPF, JES2 and SDSF, RACF, FTP with JES and SQL modes, DASD volumes, a Master Console, and a Pen-Test Shell full of mainframe assessment tools, so you can learn mainframe security without access to a real mainframe.

The GIBSON ISO is a complete Linux system with GIBSON already installed and running. Boot it in a virtual machine or from a USB stick, and a minute or two later you're at the Master Console with everything ready, including nmap, hydra, nikto, John the Ripper with racf2john, x3270, c3270 and s3270. Nothing is written to the computer's own disk unless you choose to install it.

> **GIBSON is vulnerable on purpose.** Its training profile contains weak passwords, over-permissive RACF profiles and other planted findings for you to discover. Run it in a virtual machine or on a trusted lab network, and never expose its ports to the internet.

## What's new in version 0.5.0

- **APF escalation lab.** `ELV.APF` is in every user's TOOLS library, and `SYS1.VULNLIB` is a writable APF library, so a student can list it and escalate to RACF SPECIAL. Secure mode refuses the escalation.
- **SDSF and the spool.** SDSF opens with OWNER set to your own userid, and `OWNER *` and `PREFIX *` widen the view in the training profile. FTP and SDSF now agree on who may see which jobs. The JES2 spool and checkpoint data sets are on their volumes, and `$D SPOOL` and SDSF's SP panel report the same thing.
- **MFA that scans.** QR codes are drawn black on white, so authenticator apps read them from any terminal, and `/mfa/admin` shows the QR code of every pending factor for a class to scan. A pending factor is announced at logon.
- **tool-check.** Type `tool-check` in the Pen-Test Shell to see that every course tool is ready.

## Download

The ISO is about 1.6 GB, so it comes in five parts that you join back together.

| File | What it is |
| --- | --- |
| `GIBSON-live-amd64.iso.part0` to `part4` | The five parts of the ISO |
| `join-gibson-iso.bat` | Joins and checks the parts on Windows |
| `join-gibson-iso.command` | Joins and checks the parts on a Mac or Linux |

The joined ISO is 1,589,090,304 bytes, and its SHA-256 checksum is:

```
a6ca1abb3fede9c47e0102a0d938ece2264f980777c0534c136f1bdcadbf73b7
```

Parts from an earlier release won't join with these, so delete any old parts first.

## What you need

- A 64-bit (x86_64) PC, an Intel Mac, or a virtual machine on one
- 4 GB of memory (2 GB at the very least)
- For a real PC or Mac, a USB stick of 4 GB or more, which will be erased

Apple Silicon Macs (M1 to M4) can't boot the ISO, because it's built for x86_64. Use the native macOS app instead.

## Joining the parts

**On Windows**

1. Put all five parts and `join-gibson-iso.bat` in one folder with at least 1.6 GB free.
2. Double-click `join-gibson-iso.bat`. If SmartScreen says it protected your PC, click **More info**, then **Run anyway**.
3. Wait for `OK: GIBSON-live-amd64.iso is complete and matches the published checksum.`, then press any key to close the window. You can now delete the parts.

**On a Mac or Linux**

1. Put all five parts and `join-gibson-iso.command` in one folder.
2. On a Mac, double-click `join-gibson-iso.command`. If macOS refuses to open it, right-click it, choose **Open**, then click **Open** again. On Linux, open a terminal in the folder, type `bash join-gibson-iso.command` and press **Enter**.
3. Wait for the OK line.

If either script prints `CHECKSUM MISMATCH`, one part is damaged or incomplete. The script deletes the bad ISO, so download the parts again and rerun it.

## Running it in VirtualBox

This is the easiest way to start, because the virtual machine boots the ISO file directly. These steps use VirtualBox 7.

1. Click **New**. Type `GIBSON` in **Name**, set **Type** to **Linux** and **Version** to **Ubuntu (64-bit)**, and tick **Skip Unattended Installation** if offered. Click **Next**.
2. Set **Base Memory** to 4096 MB and **Processors** to 2. Click **Next**.
3. Choose **Do Not Add a Virtual Hard Disk**, click **Next**, then **Finish**, and click **Continue** if VirtualBox warns there's no disk.
4. Select the machine and click **Settings**:
   - **Storage**: click the empty optical drive, click the disc icon on the right, choose **Choose a disk file...** and select `GIBSON-live-amd64.iso`.
   - **Display**: set **Graphics Controller** to **VMSVGA** and **Video Memory** to 128 MB, and make sure **Enable 3D Acceleration** is off.
5. Click **OK**, then **Start**.

To reach GIBSON from your own computer's browser or 3270 emulator, either set the network to **Bridged Adapter**, or stay on NAT and add these port forwards under **Network**, **Advanced**, **Port Forwarding**:

| Name | Protocol | Host port | Guest port |
| --- | --- | --- | --- |
| tn3270 | TCP | 2323 | 23 |
| ftp | TCP | 2121 | 21 |
| console | TCP | 8443 | 8443 |
| pentest | TCP | 8022 | 8022 |

Then point your emulator at `localhost` port 2323 and your browser at `http://localhost:8443/console`.

VMware, QEMU and Proxmox work the same way: a 64-bit Linux machine with 4 GB of memory and no disk, with the ISO attached. In Hyper-V, use a **Generation 2** machine and set the Secure Boot template to **Microsoft UEFI Certificate Authority**.

## Running it on a real PC or Mac

**Write the ISO to a USB stick.** The easiest tool is [balenaEtcher](https://etcher.balena.io): click **Flash from file**, choose the ISO, click **Select target**, tick the USB stick (check the size so you don't pick another disk), and click **Flash!**. With Rufus on Windows, choose **Write in DD Image mode** when asked, because the default ISO mode can make a stick that won't start.

**Boot a PC from it.** Plug in the stick, switch the PC on, and press the one-time boot menu key as soon as the maker's logo appears: F12 on Dell, Lenovo, Acer and Gigabyte, F9 on HP, F8 or Esc on ASUS, F11 on MSI. Choose the USB stick, picking the entry starting **UEFI** if it's listed twice. Secure Boot can stay on, because the ISO uses the signed Ubuntu bootloader.

**Boot an Intel Mac from it.** Hold the **Option** key while switching on, then choose the orange **EFI Boot** disk. Macs with a T2 chip (most models from 2018 to 2020) need external boot allowed first: start with **Command+R**, open **Utilities**, **Startup Security Utility**, and choose **No Security** and **Allow booting from external media**.

## First start: the IPL

1. The desktop appears and signs in as `student` by itself.
2. The browser opens the Master Console at `http://localhost:8443/console` as soon as GIBSON is ready. Sign in as `admin` with the password `gibsonadmin!`.
3. GIBSON starts un-IPLed, like a real mainframe. Click in the command line at the bottom and type each reply, pressing **Enter** after each one:

   ```
   R 01,CLPA
   R 02,U
   R 03,Y
   R 04,1234
   R 05,YOURNAME
   R 06,SKIP
   ```

   Use any four digits you like for `R 04`. It becomes your MFA PIN for this IPL.
4. Wait until the panel on the right changes from IPL ACTIVE to **IPL COMPLETE**.

## Connecting

The desktop has an icon for each of these:

| What | Where | Sign in |
| --- | --- | --- |
| Master Console | `http://localhost:8443/console` | admin / gibsonadmin! |
| Welcome page | `http://localhost/` | |
| TSO through x3270 | `localhost` port 23 | IBMUSER / SYS1 |
| Pen-Test Shell | `http://localhost:8022/` | |
| Terminal | A shell with every assessment tool | |

The other services are on their usual ports: FTP 21, USS 2022, NJE 175, Db2 446, the CBSA API 8080, the FIBS bank 9080 and SMTP 2525. The keyboard is UK English; press **Alt+Shift** to switch to US.

## Managing GIBSON

GIBSON runs as the `gibson` system service, with its lab in `/var/lib/gibson/mfsim`. In the Terminal:

| Task | Command |
| --- | --- |
| Restart GIBSON | `sudo systemctl restart gibson` |
| Watch its log | `journalctl -u gibson -f` (**Ctrl+C** to stop) |
| Run a host command | `gibson --list-volumes`, or `gibson --help` for the rest |
| Change ports or services | `sudo nano /etc/default/gibson`, then restart |
| Switch to secure mode | Add `--secure` to `GIBSON_ARGS` in `/etc/default/gibson`, then restart |
| Find the machine's address | `ip -br addr` |

## Keeping your work

The live system starts fresh at every boot, which suits a classroom. There are two ways to keep your work:

- **On the USB stick.** On another Linux machine, use GParted to create an **ext4** partition labelled `casper-rw` in the free space on the stick. Then boot it and choose **keep changes on this USB stick** from the boot menu.
- **Install it to a disk.** Choose **Install GIBSON to this computer's disk** from the boot menu, or double-click **Install GIBSON** on the desktop. You need a disk of 12 GB or more, which will be erased; in VirtualBox, add a 20 GB virtual disk first. The installer walks you through location, keyboard, disk and a password for `student`, takes 10 to 30 minutes, and afterwards the machine boots straight into GIBSON with your work kept between restarts.

## If something goes wrong

| What you see | What to do |
| --- | --- |
| A black screen after the boot menu | Restart and choose **basic display** in VirtualBox or VMware, or **safe graphics** elsewhere. In VirtualBox, check 3D acceleration is off and the graphics controller is VMSVGA. |
| The PC ignores the USB stick | Write it again with balenaEtcher, or Rufus in DD Image mode. On older PCs, turn on **CSM** or **Legacy boot** in the firmware settings. |
| The boot stops part-way | Choose **show every boot message** to see where, then **check this USB stick or DVD for errors**. |
| The first start is very slow | Normal on a USB 2 stick or a VM without hardware virtualisation. The console opens by itself when GIBSON is ready, or use **copy into memory**. |
| The Master Console doesn't load | In the Terminal, `systemctl status gibson` shows whether GIBSON is running, and `journalctl -u gibson -f` shows why not. |
| A course tool doesn't work | Type `tool-check` in the Pen-Test Shell; it names anything missing. |

## Licence

GIBSON is released under the GIBSON Community and Educational Licence, version 1.0, for personal learning, community education, academic teaching and non-commercial research. Commercial rights are reserved. See `LICENSE.md` for the full terms.

Copyright © 2022 to 2026 Kev Milne. Published by Neuro Training Ltd / [OffensiveSec.org](https://offensivesec.org).
