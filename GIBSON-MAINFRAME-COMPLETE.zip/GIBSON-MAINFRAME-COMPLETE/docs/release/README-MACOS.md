# Installing GIBSON on a Mac

**For Apple Silicon Macs (M1 and later) running macOS 11 Big Sur or later.**

GIBSON for the Mac is an ordinary app, `GIBSON.app`, that runs natively and at full speed on an Apple Silicon Mac. Every Pen-Test Shell tool that the course uses is already inside it, including `nmap`, `hydra`, `nikto`, `wget`, `s3270`, jumbo John the Ripper with `racf2john`, `telnet` and `ftp`, so there is nothing else to install: no Homebrew, no Python and no virtual machine. You install one file, approve it once, and start GIBSON from Applications like any other app.

---

## Contents

1. [What is GIBSON?](#1-what-is-gibson)
2. [Before you start](#2-before-you-start)
3. [Downloading the installer](#3-downloading-the-installer)
4. [Installing GIBSON](#4-installing-gibson)
5. [Starting GIBSON](#5-starting-gibson)
6. [The IPL, in the Master Console](#6-the-ipl-in-the-master-console)
7. [The Pen-Test Shell](#7-the-pen-test-shell)
8. [A first look at TSO with PHOSPHOR](#8-a-first-look-at-tso-with-phosphor)
9. [Where everything is](#9-where-everything-is)
10. [Running GIBSON without your password (high ports)](#10-running-gibson-without-your-password-high-ports)
11. [Stopping GIBSON](#11-stopping-gibson)
12. [Uninstalling](#12-uninstalling)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. What is GIBSON?

GIBSON is a self-contained mainframe education and penetration-testing lab. At its heart is a simulated IBM z/OS-style mainframe that gives you a master console with a real IPL sequence, TSO logons over TN3270, an FTP server that understands datasets, a UNIX System Services (USS) shell, a RACF-style security database, JES2, NJE, Db2 and CICS-style services, a banking application with its own API, an SMTP listener, a zSecure-style alerting feed and a web dashboard, all running on your own Mac.

Everything in the lab is deliberately fictional, and the Pen-Test Shell only allows targets in the lab itself (`127.0.0.1` and the fictional `sighberbank.com`), so you can practise freely without any risk of touching a real system.

> **Which version do I need?** This app is the simplest way to run GIBSON on an Apple Silicon Mac, and you do not need VirtualBox for it. The Intel and AMD GIBSON ISO will not run in VirtualBox on an Apple Silicon Mac, because VirtualBox there runs only Arm systems. If you want the full GIBSON Linux desktop in a virtual machine instead, use the separate arm64 ISO and its own guide.

---

## 2. Before you start

You need:

| Item | Requirement |
|---|---|
| Mac | An Apple Silicon Mac (M1, M2, M3, M4 or later) |
| macOS | macOS 11 Big Sur or later |
| Disk space | About 1.5 GB free |
| Account | The password of an account that can install software |

To check your Mac, click the **Apple** menu at the top left of the screen and choose **About This Mac**. The **Chip** line should start with **Apple M**, and the **macOS** line gives the version.

---

## 3. Downloading the installer

1. Open <https://github.com/kmilne40/GIBSON/releases> in your browser and choose the newest Mac release.
2. Under **Assets**, click `GIBSON-Installer-arm64.pkg` to download it. It arrives in your **Downloads** folder.

If the release also lists a `SHA256SUMS` file, you can check that the download arrived intact: open **Terminal** (press **Command+Space**, type `Terminal` and press **Return**), type `shasum -a 256 ~/Downloads/GIBSON-Installer-arm64.pkg` and press **Return**, and check that the long string it prints matches the one beside `GIBSON-Installer-arm64.pkg` in `SHA256SUMS`.

---

## 4. Installing GIBSON

The installer is not signed with an Apple Developer ID, so macOS stops it the first time you open it, and you approve it once.

1. Open **Finder**, click **Downloads** in the sidebar, and double-click `GIBSON-Installer-arm64.pkg`.
2. macOS says that it could not verify the installer and did not open it. Click **Done** (on macOS 14 and earlier, the button is **OK**).
3. Click the **Apple** menu, choose **System Settings**, and click **Privacy & Security** in the sidebar. Scroll down to the **Security** section, where it says that "GIBSON-Installer-arm64.pkg" was blocked to protect your Mac, and click **Open Anyway**. Type your Mac password and click **Open Anyway** again.

   On macOS 14 Sonoma and earlier, you can instead go back to **Downloads**, right-click the file (or hold down **Control** and click it), choose **Open**, and click **Open**.

4. The GIBSON installer opens. Click **Continue** on each page, then click **Install**, type your Mac password when asked, and click **Close** at the end. If the installer offers to move itself to the Bin, you can let it.

GIBSON is now in your **Applications** folder, and the `gibson` command works in Terminal.

---

## 5. Starting GIBSON

1. Open **Applications** in Finder and double-click **GIBSON**, or press **Command+Space**, type `GIBSON` and press **Return**.
2. A Terminal window opens. GIBSON uses the standard mainframe ports, which macOS keeps for administrators, so it asks for your Mac password once. Type it and press **Return**. Nothing appears as you type, which is normal.
3. A few seconds later, your browser opens the Master Console at <http://127.0.0.1:8443/console>. When the browser asks you to sign in, type the username `admin` and the password `gibsonadmin!`, and click **Sign In**. Safari notes that the password will be sent unencrypted, which is expected here, because the connection never leaves your Mac.

> **Leave the Terminal window open while you use GIBSON.** It is the running system, and closing it stops GIBSON.

---

## 6. The IPL, in the Master Console

GIBSON starts like a real mainframe, so it waits to be IPLed (initial program load), and the yellow banner at the top of the console says so.

1. Click in the command line at the bottom of the console, where it says **Reply or command**.
2. Type each reply below and press **Return** after each one, waiting for the next request to appear before you type the next reply:

   ```text
   R 01,CLPA
   R 02,U
   R 03,Y
   R 04,1234
   R 05,GIBSON
   R 06,SKIP
   ```

   You can use any four digits you like for `R 04`, because they become your MFA PIN. You can also click the reply buttons under the banner instead of typing.

3. When the last reply is accepted, the top right of the console shows **IPL complete - system up**, and the panel on the right lists every subsystem as active.

What each reply means:

| Reply | What it does |
|---|---|
| `R 01,CLPA` | Builds the link pack area afresh (a "cold" start of the system code) |
| `R 02,U` | Uses the default system parameters member, IEASYS00 |
| `R 03,Y` | Carries on with the IPL, so JES2, RACF, OMVS and TCP/IP start |
| `R 04,1234` | Sets your operator MFA PIN for this IPL |
| `R 05,GIBSON` | Names the system GIBSON |
| `R 06,SKIP` | Skips the training PIN for the DVCA, CBSA and OMEN banking labs (type four digits, such as `R 06,1337`, if your exercise needs one) |

---

## 7. The Pen-Test Shell

1. Open <http://127.0.0.1:8022/> in a new browser tab and sign in the same way, with `admin` and `gibsonadmin!`. This is the shell that the course's exercises use.
2. Every target is checked against the lab's allowlist, so only `127.0.0.1` and `sighberbank.com` can be reached.
3. Type `tool-check` and press **Return**. Every course tool should say that it is ready, ending with all 13 course tools ready.

The security tools are inside GIBSON too, so the course's commands work straight away. For example:

```bash
nmap -Pn -p 21,23,80,175,8443 127.0.0.1
nmap -sV -Pn -p 21,23 127.0.0.1
```

The first scans the lab, and the second shows nmap recognising GIBSON's FTP and TN3270 services as IBM's.

Other useful commands in the shell are `scope`, which shows the targets the shell allows, and `tools`, which lists every tool with an example of each.

---

## 8. A first look at TSO with PHOSPHOR

PHOSPHOR, GIBSON's TN3270 terminal, is in the Pen-Test Shell too, so you can log on to TSO without installing a 3270 emulator.

1. In the Pen-Test Shell, type `phosphor 127.0.0.1 --client` and press **Return**. The GIBSON logon screen appears, with the cursor at `Logon Type:`.
2. Type `L TSO` and press **Return**.
3. At the **TSO/E LOGON** panel, type `IBMUSER` in the `Userid ===>` field, press **Tab** to move to the `Password ===>` field, type `SYS1`, and press **Return**.
4. When you see `READY`, you are at the TSO prompt. Type `LISTCAT` and press **Return** to list IBMUSER's datasets.
5. Type `LOGOFF` and press **Return** to log off, and then type `:q` and press **Return** to leave PHOSPHOR.

Any other 3270 emulator also works: point it at `127.0.0.1` port `23`.

---

## 9. Where everything is

While GIBSON is running, its services are all on your own Mac at `127.0.0.1`, so you reach them by typing these addresses into your browser or a 3270 emulator.

| What | Where | Sign in |
|---|---|---|
| Master Console | <http://127.0.0.1:8443/console> | `admin` / `gibsonadmin!` |
| Dashboard | <http://127.0.0.1:8443/> | `admin` / `gibsonadmin!` |
| Pen-Test Shell | <http://127.0.0.1:8022/> | `admin` / `gibsonadmin!` |
| TSO, through a 3270 emulator | `127.0.0.1` port `23` | `IBMUSER` / `SYS1` |
| FTP | `127.0.0.1` port `21` | your TSO userid |
| Welcome page | <http://127.0.0.1/> | |

The other services are on their usual ports:

| Port | Service |
|---|---|
| 25 | SMTP |
| 175 | NJE |
| 446 | Db2 |
| 2022 | USS |
| 8080 | CBSA API |
| 9080 | FIBS bank |

Your lab, with its datasets, mail and Pen-Test Shell workspace, is kept in the `mfsim` folder in your home folder.

---

## 10. Running GIBSON without your password (high ports)

If you would rather not give GIBSON your password, you can start it on high ports instead, which need no administrator rights:

1. Open **Applications** in Finder, right-click **GIBSON** (or hold down **Control** and click it), and choose **Show Package Contents**.
2. Open **Contents**, then **Resources**, then **gibson**.
3. Double-click **Start GIBSON (high ports, no sudo).command**.

In this mode, some services move to new ports:

| Service | Standard port | High-port mode |
|---|---|---|
| TSO (TN3270) | 23 | 2323 |
| FTP | 21 | 2121 |
| NJE | 175 | 1750 |
| Welcome page | 80 | 8080 |

The Master Console, dashboard and Pen-Test Shell stay on 8443 and 8022. In this mode, use `nmap -sT` instead of `nmap -sS`.

---

## 11. Stopping GIBSON

To stop GIBSON, close its Terminal window. Your lab is kept in the `mfsim` folder in your home folder, so the next start carries on where you left off.

---

## 12. Uninstalling

1. Drag **GIBSON** from **Applications** to the **Bin**.
2. Open **Terminal**, type the following, press **Return**, and give your password:

   ```bash
   sudo rm -f /usr/local/bin/gibson
   ```

3. If you also want to remove the lab's data, delete the `mfsim` folder in your home folder.

---

## 13. Troubleshooting

| What you see | What to do |
|---|---|
| "GIBSON" was blocked or could not be verified | Approve it once in **System Settings** ▸ **Privacy & Security** ▸ **Open Anyway**, as in step 3 of [Installing GIBSON](#4-installing-gibson). |
| The Terminal window asks for a password and nothing appears | That is normal. Type the password and press **Return**. |
| The browser does not open, or cannot reach `127.0.0.1:8443` | Check that GIBSON's Terminal window is still open, wait a few seconds, and type `http://127.0.0.1:8443/console` into the address bar yourself. |
| The console still shows the yellow "not been IPLed" banner | Type the six replies in the command line at the bottom, in order, as in [The IPL](#6-the-ipl-in-the-master-console). |
| A tool says that it is missing | Type `tool-check` in the Pen-Test Shell, and send what it shows with your question. |
| The installer will not open on an Intel Mac | This app is for Apple Silicon Macs only. |
