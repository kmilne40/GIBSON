# GIBSON Mainframe Simulator for macOS

GIBSON is a deliberately vulnerable z/OS training simulator. It gives you TSO, ISPF, JES2 and SDSF, RACF, FTP with JES and SQL modes, DASD volumes, a Master Console, and a Pen-Test Shell full of mainframe assessment tools, so you can learn mainframe security without access to a real mainframe.

`GIBSON-Installer-arm64.pkg` installs all of it on an Apple Silicon Mac as an ordinary app, and it runs natively at full speed with no virtual machine. Every Pen-Test Shell tool is inside the app already, including nmap, hydra, nikto, wget, the x3270 suite's s3270 and jumbo John the Ripper with racf2john, so there is nothing else to install and no Homebrew needed.

> **GIBSON is vulnerable on purpose.** Its training profile contains weak passwords, over-permissive RACF profiles and other planted findings for you to discover. Run it on your own Mac or a trusted lab network, and never expose its ports to the internet.

## Download

| File | What it is |
| --- | --- |
| `GIBSON-Installer-arm64.pkg` | The installer for Apple Silicon Macs (M1 and later). Use this one |
| `GIBSON-arm64.dmg` | The same app as a disk image, to drag to Applications yourself |

To check that your Mac has Apple Silicon, open the Apple menu and choose **About This Mac**: the **Chip** line should start with *Apple M*.

To check the download, open **Terminal** (in Applications, Utilities), type `shasum -a 256 ` with a space after it, drag the downloaded file into the Terminal window and press **Return**. The hash it prints should be the one beside your file:

```
9dd5c711db1bf0594f869256b601f2060dd6662eb94512b28ac8473ad47b3f6b  GIBSON-Installer-arm64.pkg
b9fd722d10866c20cc409abfe5958cac4c960dc0563bb5260903c1daf72f2372  GIBSON-arm64.dmg
```

## What you need

A Mac with Apple Silicon running macOS 11 Big Sur or later, about 1.5 GB of free disk space and an account that can approve administrator prompts. Nothing else: the app carries its own Python and every tool.

## Installing

The installer is not code-signed, so macOS stops it the first time, and you approve it once.

1. Double-click `GIBSON-Installer-arm64.pkg` in your **Downloads** folder. macOS says it could not verify it; click **Done** (or **OK** on macOS 14 and earlier).
2. Open the Apple menu, **System Settings**, **Privacy & Security**, scroll down to *"GIBSON-Installer-arm64.pkg" was blocked to protect your Mac*, click **Open Anyway**, enter your password and click **Open Anyway** again. On macOS 14 Sonoma and earlier you can instead right-click the file, choose **Open**, and click **Open**.
3. The installer opens. Click **Continue** on each page, then **Install**, give your password, and click **Close**.

GIBSON is now in **Applications**, and the `gibson` command works in Terminal.

If you use the disk image instead, drag **GIBSON** onto the **Applications** shortcut, then approve GIBSON itself the same way the first time you open it.

## First start

Double-clicking GIBSON opens a Terminal window, because GIBSON runs as a console program as well as a set of network services.

1. The window explains that GIBSON uses the standard mainframe ports (21, 23, 80 and 175), which macOS reserves for administrators, and asks for your Mac password once. Type it and press **Return**; nothing appears as you type, which is normal.
2. A few seconds later your browser opens the Master Console at `http://127.0.0.1:8443/console`. Sign in as `admin` with the password `gibsonadmin!`.
3. GIBSON starts like a real mainframe and waits to be IPLed, as the yellow banner says. Click in the command line at the bottom of the console and type each reply, pressing **Return** after each one (or click the reply buttons under the banner):

   ```
   R 01,CLPA
   R 02,U
   R 03,Y
   R 04,1234
   R 05,GIBSON
   R 06,SKIP
   ```

   Use any four digits you like for the `R 04` reply. It becomes the MFA PIN. The top right of the console then shows *IPL complete - system up*.

Leave the Terminal window open while you use GIBSON, because it is the running system. Closing it stops GIBSON.

## Connecting

| What | Where | Sign in |
| --- | --- | --- |
| Master Console | `http://127.0.0.1:8443/console` | admin / gibsonadmin! |
| Dashboard | `http://127.0.0.1:8443/` | admin / gibsonadmin! |
| Pen-Test Shell | `http://127.0.0.1:8022/` | admin / gibsonadmin! |
| TSO through a 3270 emulator | `127.0.0.1` port 23 | IBMUSER / SYS1 |
| FTP | `127.0.0.1` port 21 | your TSO userid |
| Welcome page | `http://127.0.0.1/` | |

The other services are on their usual ports: USS 2022, NJE 175, Db2 446, the CBSA API 8080, the FIBS bank 9080 and SMTP 25 (or 2525).

## The Pen-Test Shell

Every tool the course uses is inside GIBSON, so the shell is ready the first time you open it. Type `tool-check` there to see each one marked ready. The shell still runs every tool through its scope-guarded launchers, so targets outside the lab are refused.

## Without a password, on high ports

If you would rather not give GIBSON your password, open **Applications**, right-click **GIBSON**, choose **Show Package Contents**, open **Contents**, **Resources** and **gibson**, and double-click `Start GIBSON (high ports, no sudo).command`. TSO is then on port 2323, FTP on 2121, NJE on 1750 and the welcome page on 8080, while the console stays on 8443. nmap's SYN scans need administrator rights, so in this mode use `nmap -sT` instead of `nmap -sS`.

## Commands

GIBSON's host commands, such as `gibson --list-volumes`, are typed in Terminal. The installer sets this up for you. After a disk-image install, set it up once by typing this in Terminal, pressing **Return** and giving your password:

```
sudo mkdir -p /usr/local/bin && sudo ln -sf /Applications/GIBSON.app/Contents/Resources/gibson/gibson-cli.sh /usr/local/bin/gibson
```

## Uninstalling

Close GIBSON's Terminal window, drag **GIBSON** from Applications to the Bin, and type `sudo rm -f /usr/local/bin/gibson` in Terminal to remove the command link. The lab's data stays in `~/mfsim` in your home folder until you delete that folder too.

## If something goes wrong

| What you see | What to do |
| --- | --- |
| The installer or GIBSON was blocked, or could not be verified | Approve it once in **Privacy & Security**, as in step 2 of Installing |
| The Terminal window asks for a password and nothing appears as you type | That is normal; type it and press **Enter** |
| The browser cannot reach the console | Make sure GIBSON's Terminal window is still open, then type `http://127.0.0.1:8443/console` in the address bar yourself |
| The console shows a yellow *not been IPLed* banner | Answer the six IPL replies in the console's command line, in order |
| A Pen-Test Shell tool says it is missing | Type `tool-check` in the shell and send what it prints with your question |

## Licences

GIBSON is released under the GIBSON Community and Educational Licence, version 1.0, for personal learning, community education, academic teaching and non-commercial research. Commercial rights are reserved. See `LICENSE.md` for the full terms.

The security tools bundled for the Pen-Test Shell are separate programs under their own licences, which are not GIBSON's. Each licence, with a list of the tools, their versions and where their source code is, is in **GIBSON**, **Show Package Contents**, **Contents**, **Resources**, **gibson**, **tools**, **licenses**.

Copyright © 2022 to 2026 Kev Milne. Published by Neuro Training Ltd / [OffensiveSec.org](https://offensivesec.org).
